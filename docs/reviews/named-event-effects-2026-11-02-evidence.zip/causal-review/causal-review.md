# BE-04 bounded causal review

All 16 changed legacy games reproduce the matrix outcomes from both source trees: exactly 32 full diagnostic games. Every pair has an identical raw trace prefix and identical complete state/RNG before its first differing row. No first difference is merely the new accepted/acting-faction return metadata.

The first causes are eight repaired Legion placements, two Roman-owned removals on Aedui-executed Rhenus Events, and six decisions that now reject an ineffective Event. These are source-required behavior changes; this review found no new blocker.

## Per-game first causes

| Scenario | Seed | Parent outcome | Candidate outcome | First cause |
|---|---:|---|---|---|
| Pax Gallica? | 5 | Romans, 56 cards | Aedui, 56 cards | Legiones now places the required two Track Legions in Provincia. |
| Pax Gallica? | 11 | Belgae, 58 cards | Belgae, 42 cards | Aedui executes Rhenus; Romans now selects Ubii and removes its four Germans. |
| Pax Gallica? | 18 | Romans, 74 cards | Romans, 23 cards | Senate is off-track, so the prerequisite shift is impossible. Romans chooses Recruit/Build instead of ineffective Legiones. |
| Reconquest of Gaul | 4 | Aedui, 32 cards | Romans, 32 cards | No City is under Roman Control. Romans chooses March/Build instead of ineffective Sacking. |
| Reconquest of Gaul | 10 | Belgae, 47 cards | Belgae, 62 cards | Neither Germania Region is under or adjacent to Roman Control. Aedui chooses Battle/Trade instead of ineffective Rhenus. |
| The Great Revolt | 3 | Belgae, 45 cards | Aedui, 45 cards | Only Sugambri is legally reachable, and it contains no Germans. Romans chooses Seize/Build instead of ineffective Rhenus. |
| The Great Revolt | 5 | Aedui, 46 cards | Arverni, 46 cards | Legiones now places two Track Legions after flipping nonfirm Uproar to Firm. |
| The Great Revolt | 14 | Aedui, 46 cards | Belgae, 46 cards | Aedui executes Rhenus; Romans now selects Sugambri and removes its two Germans. |
| Ariovistus | 5 | Romans, 30 cards | Germans, 46 cards | Legiones now places the required two Track Legions in Provincia. |
| Ariovistus | 7 | Germans, 47 cards | Romans, 47 cards | Legiones now places the required two Track Legions in Provincia. |
| Ariovistus | 18 | Belgae, 43 cards | Romans, 43 cards | Legiones now places the required two Track Legions in Provincia. |
| The Gallic War | 1 | Romans, 84 cards | Romans, 100 cards | Neither Germania Region is under or adjacent to Roman Control; Ubii also contains Ariovistus. Romans chooses Seize/Build instead of ineffective A18. |
| The Gallic War | 5 | Romans, 30 cards | Aedui, 101 cards | Legiones now places the required two Track Legions in Provincia. |
| The Gallic War | 7 | Belgae, 70 cards | Belgae, 72 cards | Legiones now places the required two Track Legions in Provincia. |
| The Gallic War | 8 | Romans, 104 cards | Aedui, 104 cards | Sugambri has no qualifying Roman Control; the adjacent-to-Romans Ubii contains Ariovistus and is excluded. Romans chooses Seize/Build instead of ineffective A18. |
| The Gallic War | 18 | Arverni, 84 cards | Arverni, 101 cards | Legiones now places the required two Track Legions in Provincia. |

## State and RNG checks

For all eight Legiones executions, both sides start with the same legal Senate shift and at least two Track Legions. The parent shifts Senate but places zero; the candidate places two. The first changed fields are only spaces and the Legions track; RNG is identical. These are direct witnesses of the previously missing default source counts, not stochastic tie changes.

For the two Aedui Rhenus executions, both sides start with the same legal occupied target. The parent lacks a target and removes nothing. The candidate asks the named Roman owner, whose non-player choice removes the four Germans at Ubii (Pax 11) or two at Sugambri (Revolt 14). The first changed fields are only spaces and Available pieces; RNG is identical.

The other six first rows are different executable command choices, not result-only metadata. The target/source facts in causal-facts.json demonstrate their missing prerequisites. Romans and Aedui continue through their printed flowcharts. This can create ordinary Recruit/Diviciacus confirmations or consume the flowchart dice. In Gallic War seeds 1 and 8 the decision itself does not mutate state: the first complete post-state change occurs at the following execution. Its pre-state differs only because run_game has recorded the different selected action; the RNG before that execution still matches. Both raw first-choice and first complete post-state divergences are retained separately.

## Sources

Supplied Card Reference 2 requires the Senate shift and two Legions; its Tips exclude a failed prerequisite shift. Roman card instructions require two or “No Romans”. Card Reference 18 assigns the choice to Romans and restricts the Region by Roman Control. A Card Reference A18 adds “without Ariovistus”. Card Reference 23 requires a City at Roman Control. Chapter 5 §5.1 assigns optional named-faction choices to that faction; Chapter 8 §§8.1.1/8.2.1 exclude ineffective/unavailable non-player Events. No new rules interpretation was needed for these 16 first causes. A18 Scouted/Successor removals and the human choices for 23/26 have separate regression witnesses; they are not claimed as first causes in this sample.

## Provenance and retained limitations

Parent is clean committed 2edf53e6a0dae774b391e64ce883fdcc5f622ba9. Candidate executed frozen Python SHA256 9d4cc73f2efaa33b8e6ad871fb432ae43c7471d5222b1c13d9c9b571c0c3c4a8 across 422 files. During the candidate trace run, root committed those same bytes as 9e9191bc1c0eb5de13a5d578475d4f85042d2a6b. The trace command completed all 16 outcomes, passed its individual-file manifest recheck, then failed its final whole identity equality solely because the Git commit changed. The original failed log is retained. The separate verify-only end check and metadata-equivalence.json prove all Python bytes stayed fixed; no games were rerun.

Captured first rows initially replayed exactly for 16/16 parent and 15/16 candidate snapshots. The one candidate exception (Reconquest 10) came from diagnostic JSON sorting plain map keys: Trade details followed the reconstructed alphabetical space order and therefore produced a different Diviciacus confirmation signature. Restoring the actual ALL_REGIONS map insertion order reproduced the exact decision, full state/RNG and subsequent execution. See sorted-map-replay-exception.json; the initial failure and first follow-through harness boundary mismatch are preserved in their logs. This is a diagnostic-codec limitation, not a changed-source replay claim.

This analysis explains the earliest divergence of each changed run, not the full counterfactual contribution of every later action to the final winner. It uses exactly 16 selected legacy pairs at hash seed 0; it adds no statistical sample and changes no baseline. The independent full acceptance matrix already remains within its unchanged 15-point band.
