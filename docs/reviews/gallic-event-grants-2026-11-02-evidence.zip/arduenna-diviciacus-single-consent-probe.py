import json
from fs_bot import rules_consts as r
from fs_bot.board.pieces import place_piece
from fs_bot.cards.capabilities import activate_capability
from fs_bot.cards.base_arduenna_np import _battle_action
from fs_bot.commands.common import free_action_scope
from fs_bot.engine.execute import _execute_battle
from fs_bot.engine.agent import AGREEMENT, RETREAT
from fs_bot.state.state_schema import build_initial_state
out=[]
for roman_agrees in (False,True):
 s=build_initial_state(r.SCENARIO_GREAT_REVOLT,seed=67)
 s.update(current_card=67,next_card=3,non_player_factions={r.ARVERNI,r.BELGAE})
 place_piece(s,r.NERVII,r.ARVERNI,r.WARBAND,6)
 place_piece(s,r.NERVII,r.ROMANS,r.AUXILIA,1)
 place_piece(s,r.NERVII,r.ROMANS,r.LEGION,2,from_legions_track=True)
 place_piece(s,r.NERVII,r.AEDUI,r.WARBAND,2)
 activate_capability(s,38,r.EVENT_UNSHADED)
 calls=[]
 def agent(board,faction,request):
  if request.get('kind')==AGREEMENT:
   calls.append((faction,request.get('request_type')))
   return roman_agrees if request.get('request_type')=='diviciacus_defense' else False
  if request.get('kind')==RETREAT:return {'retreat':False,'region':None}
 s['decision_agent']=agent
 with free_action_scope(s,r.ARVERNI):
  result=_execute_battle(s,r.ARVERNI,_battle_action([r.NERVII]),_skip_absent_targets=True)
 assert calls==([(r.ROMANS,'diviciacus_defense')] + ([(r.AEDUI,'diviciacus')] if roman_agrees else [])),calls
 out.append({'roman_agrees':roman_agrees,'agreement_calls':calls,'errors':result.get('errors')})
print(json.dumps(out,indent=2))
