"""Fifth-audit Events witnesses. Assertions intentionally reproduce current defects.
Run from any location with PYTHONPATH pointing to the audited fs-bot checkout.
No production files, references, test expectations or baseline files are changed.
"""
import json
from copy import deepcopy

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, place_piece
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.cards.capabilities import get_capability_owner
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT, ACTION_COMMAND_SA
from fs_bot.engine.moves import validate_player_action
from fs_bot.engine.winter_campaign import winter_campaign_after_harvest
from fs_bot.map.map_data import is_region_playable
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.tools.seat_session import board_copy, validate_response


def clean(state):
    pools = validate_state(state)
    structure = check_structural_integrity(state)
    assert pools == structure == [], (pools, structure)
    return {'pool_errors': pools, 'structure_errors': structure}


def setup(scenario=rc.SCENARIO_GREAT_REVOLT, edition='second-edition'):
    state = setup_scenario(scenario, seed=17, card_edition=edition)
    state['non_player_factions'] = set()
    clean(state)
    return state


def play(state, actor, card, params, shaded=False):
    state['current_card'] = state['current_card_id'] = card
    action = {'command': rc.FIRST_DID_EVENT, 'details': {
        'card_id': card, 'event_params': params,
        'text_preference': rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED}}
    response = {'action': ACTION_EVENT, 'player_action': action}
    request = {'kind': 'turn', 'faction': actor, 'options': [ACTION_EVENT]}
    before = encode(board_copy(state))
    assert validate_response(state, request, deepcopy(response)) == response
    ok, preview = validate_player_action(state, actor, action)
    assert encode(board_copy(state)) == before, 'Preview mutated live state'
    result = execute_decision(state, actor, response)
    observed = {'durable_shape_accepted': True, 'preview_valid': ok,
                'preview': preview, 'result': result, **clean(state)}
    if not result.get('executed'):
        observed['atomic_rejection'] = encode(board_copy(state)) == before
        assert observed['atomic_rejection']
    return observed


def battle_fixture():
    # Controlled, source-valid physical position. Provincia's permanent Fort
    # remains present. Every Ally/Citadel has its matching named Tribe.
    state = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=17)
    state['card_edition'] = 'second-edition'
    state['non_player_factions'] = set()
    state['resources'][rc.BELGAE] = 10
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    place_piece(state, rc.SEQUANI, rc.BELGAE, rc.WARBAND)
    place_piece(state, rc.SEQUANI, rc.BELGAE, rc.LEADER, leader_name=rc.AMBIORIX)
    assert _ally_tribe(state, rc.TRIBE_SEQUANI, rc.ARVERNI, citadel=True)
    place_piece(state, rc.SEQUANI, rc.ARVERNI, rc.WARBAND, 4, piece_state=rc.REVEALED)
    clean(state)
    return state


def recipient_witnesses():
    out = []
    for edition in ('original', 'second-edition'):
        for card in (10, 63):
            for name, params in [('missing', {}), ('invalid_roman', {'faction': rc.ROMANS}),
                                 ('legal_belgae', {'faction': rc.BELGAE})]:
                state = setup(edition=edition)
                entry = {'edition': edition, 'card': card, 'case': name,
                         **play(state, rc.ROMANS, card, params, shaded=True)}
                assert entry['preview_valid'] and entry['result']['executed']
                entry['owner'] = get_capability_owner(state, card)
                entry['active_side'] = state['capabilities'][card]
                expected_owner = rc.BELGAE if name == 'legal_belgae' else None
                assert entry['owner'] == expected_owner
                if card == 63:
                    requests = []
                    def agent(board, faction, request):
                        if request['kind'] == 'winter_campaign':
                            requests.append(faction)
                            return {'decline': True}
                    state['decision_agent'] = agent
                    entry['harvest_consumer'] = winter_campaign_after_harvest(state)
                    entry['winter_campaign_requests'] = requests
                    assert requests == ([rc.BELGAE] if name == 'legal_belgae' else [])
                    assert (entry['harvest_consumer'] is None) == (name != 'legal_belgae')
                out.append(entry)
    # Trace Ballistae acquisition to the actual public Battle consumer.
    for name, params in [('missing', {}), ('legal_belgae', {'faction': rc.BELGAE})]:
        state = battle_fixture()
        acquisition = play(state, rc.ROMANS, 10, params, shaded=True)
        requests = []
        def agent(board, faction, request):
            if request['kind'] == 'ballistae_target':
                requests.append(faction)
                return {'target': {'piece_type': rc.CITADEL, 'tribe': rc.TRIBE_SEQUANI,
                                   'owner': rc.ARVERNI}}
        state['decision_agent'] = agent
        action = {'command': rc.CMD_BATTLE, 'sa': rc.SA_AMBUSH, 'sa_regions': [rc.SEQUANI],
                  'details': {'battle_plan': [{'region': rc.SEQUANI, 'target': rc.ARVERNI}]}}
        result = execute_decision(state, rc.BELGAE, {'action': ACTION_COMMAND_SA, 'player_action': action})
        assert result['executed'], result
        citadels = count_pieces(state, rc.SEQUANI, rc.ARVERNI, rc.CITADEL)
        assert citadels == (name == 'missing')
        assert requests == ([rc.BELGAE] if name == 'legal_belgae' else [])
        out.append({'case': 'ballistae_followthrough_' + name, 'acquisition': acquisition,
                    'battle_result': result, 'ballistae_requests': requests,
                    'surviving_arverni_citadels': citadels, **clean(state)})
    return out


def colony_witnesses():
    out = []
    for scenario, region, expected_playable in (
        (rc.SCENARIO_GREAT_REVOLT, rc.CISALPINA, False),
        (rc.SCENARIO_ARIOVISTUS, rc.BRITANNIA, False),
        (rc.SCENARIO_GREAT_REVOLT, rc.PROVINCIA, True),
        (rc.SCENARIO_ARIOVISTUS, rc.PROVINCIA, True),
    ):
        state = setup(scenario)
        before_ally = count_pieces(state, region, rc.ROMANS, rc.ALLY)
        assert is_region_playable(state, region, rc.ROMANS) is expected_playable
        entry = {'scenario': scenario, 'target': region,
                 'target_is_playable': expected_playable,
                 **play(state, rc.ROMANS, 71, {'region': region})}
        assert entry['preview_valid'] and entry['result']['executed']
        entry['roman_allies_added'] = count_pieces(state, region, rc.ROMANS, rc.ALLY) - before_ally
        entry['created_tribes'] = {t: info for t, info in state['tribes'].items() if info.get('region') == region}
        assert entry['roman_allies_added'] == 1 and len(entry['created_tribes']) == 1
        out.append(entry)
    # A real Gallia Togata gives a positive Cisalpina control with the same input.
    state = setup()
    gallia = play(state, rc.ROMANS, 5, {})
    assert gallia['result']['executed'] and is_region_playable(state, rc.CISALPINA, rc.ROMANS)
    legal = play(state, rc.ROMANS, 71, {'region': rc.CISALPINA})
    assert legal['result']['executed']
    out.append({'case': 'legal_after_gallia_togata', 'gallia': gallia, 'colony': legal,
                'roman_allies': count_pieces(state, rc.CISALPINA, rc.ROMANS, rc.ALLY)})
    return out


def forced_marches_witnesses():
    out = []
    for edition in ('original', 'second-edition'):
        for name, origin, destination, gallia in (
            ('legal_out_of_cisalpina_rejected', rc.CISALPINA, rc.PROVINCIA, True),
            ('legal_into_cisalpina_rejected', rc.PROVINCIA, rc.CISALPINA, True),
            ('ordinary_legal_control', rc.PROVINCIA, rc.SEQUANI, False),
            ('ordinary_nonplayable_control', rc.PROVINCIA, rc.CISALPINA, False),
        ):
            state = setup(edition=edition)
            if gallia:
                grant = play(state, rc.ROMANS, 5, {})
                assert grant['result']['executed']
            before = count_pieces(state, destination, rc.ROMANS, rc.AUXILIA)
            entry = {'edition': edition, 'case': name, 'origin': origin, 'destination': destination,
                     'origin_playable': is_region_playable(state, origin, rc.ROMANS),
                     'destination_playable': is_region_playable(state, destination, rc.ROMANS),
                     **play(state, rc.ROMANS, 32, {'moves': [{
                         'from_region': origin, 'to_region': destination,
                         'piece_type': rc.AUXILIA, 'count': 1, 'piece_state': rc.HIDDEN}]})}
            entry['auxilia_added_at_destination'] = count_pieces(state, destination, rc.ROMANS, rc.AUXILIA) - before
            if name == 'ordinary_legal_control':
                assert entry['result']['executed'] and entry['auxilia_added_at_destination'] == 1
            else:
                assert not entry['preview_valid'] and entry['result']['rejected']
                assert 'requires playable Regions' in entry['result']['reason']
                assert entry['auxilia_added_at_destination'] == 0
            out.append(entry)
    return out


if __name__ == '__main__':
    print(json.dumps({'audited_commit': 'bd30d522e8baa2d303b9e372d7d9c550351e91a5',
                      'recipient_acquisition': recipient_witnesses(),
                      'colony_geography': colony_witnesses(),
                      'forced_marches_geography': forced_marches_witnesses()}, indent=2))
