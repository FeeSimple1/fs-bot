# Twelfth comparison audit evidence

This archive records the seven findings on Falling Sky revision
`1563e41d84f61dfce43ce4008106eca2a1639aed`, compared with Liberty or Death
revision `2991ea279062773548ec390a1da75f3e85381702`.

The expected Python source SHA-256 is
`7cb64407ff5594eb2bbd671a8159c408410fa8cc26e7a784da7afe0fd47363db`.
The lane reports describe controlled fixtures, exact rules, previous work,
implementation comparisons, matched controls and remaining limits.
The validation directory contains fresh full-suite and held-out-game evidence,
plus independently copied probes and their two-hash-seed outputs.

Extract the archive outside the checkout. Set `FS_AUDIT_REPO` to the absolute
path of the audited Falling Sky checkout. Run from the extraction directory.

```sh
sha256sum -c SHA256SUMS
PYTHONPATH="$FS_AUDIT_REPO" python validation/verify_validation.py
PYTHONHASHSEED=0 python events/probe_events.py --repo "$FS_AUDIT_REPO" > /tmp/audit12-events.json
PYTHONHASHSEED=0 python battle/probe_battle.py "$FS_AUDIT_REPO" > /tmp/audit12-battle.json
PYTHONHASHSEED=0 python bots/probe_bots.py --repo "$FS_AUDIT_REPO" > /tmp/audit12-bots.json
PYTHONHASHSEED=0 python lifecycle/probe_lifecycle.py --repo "$FS_AUDIT_REPO" > /tmp/audit12-lifecycle.json
PYTHONHASHSEED=0 python lifecycle/probe_ally_priority.py --repo "$FS_AUDIT_REPO" > /tmp/audit12-allies.json
PYTHONHASHSEED=0 python frontend/probe_frontend.py --repo "$FS_AUDIT_REPO" > /tmp/audit12-frontend.json
cmp events/results.json /tmp/audit12-events.json
cmp battle/results.json /tmp/audit12-battle.json
cmp bots/results.json /tmp/audit12-bots.json
cmp lifecycle/results.json /tmp/audit12-lifecycle.json
cmp lifecycle/ally-results.json /tmp/audit12-allies.json
cmp frontend/results.json /tmp/audit12-frontend.json
```

Repeat the six probe commands with `PYTHONHASHSEED=987` and compare against
the corresponding `.hash987.json` records. The validator writes regenerated
summary files in the extracted validation directory. The source digest must
match. Current Git documentation status can differ from the original clean
baseline recorded in the captured evidence.

To repeat broader checks, install the repository's development requirements
and use the commands and seed sets in `validation/commands.json` from the
checkout. Use a fresh output directory. The full suite includes the existing
15-game balance canary. The separately captured 100-game guardrail belongs
to the baseline GitHub run identified in `baseline-github-checks.json`.
