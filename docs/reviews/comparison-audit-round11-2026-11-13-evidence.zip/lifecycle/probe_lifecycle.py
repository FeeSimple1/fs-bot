#!/usr/bin/env python3
"""LC11-01: public third-Winter Interlude reductions, no production patches."""
import argparse
from collections import Counter
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path)
    args = parser.parse_args()
    if args.repo:
        sys.path.insert(0, str(args.repo.resolve()))
    from fs_bot import rules_consts as rc
    from fs_bot.board.pieces import count_pieces, remove_piece, place_piece
    from fs_bot.engine.game_engine import get_sop_factions
    from fs_bot.engine.interlude_reductions import (
        ARVERNI_HALF, eligible_cohorts,
    )
    from fs_bot.engine.victory import check_any_victory
    from fs_bot.engine.winter import run_winter_round
    from fs_bot.state.setup import setup_scenario
    from fs_bot.state.state_schema import validate_state, check_structural_integrity

    def run(seed, first, second, *, human_remove=None):
        state = setup_scenario(rc.SCENARIO_GALLIC_WAR, seed=seed)
        # Human Rome may explicitly decline the later Britannia expedition;
        # the German seat normally uses the prescribed NP Interlude reducer.
        state['non_player_factions'] = set(get_sop_factions(state)) - {rc.ROMANS}
        for region in state['spaces']:
            count = count_pieces(state, region, rc.ARVERNI, rc.WARBAND)
            if count:
                remove_piece(state, region, rc.ARVERNI, rc.WARBAND, count)
        for region in (first, second):
            place_piece(state, region, rc.ARVERNI, rc.WARBAND, 4)
        # Controlled phase cursor, as in earlier Interlude audit witnesses.
        state['winter_count'] = 2
        state['current_card'] = state['current_card_id'] = rc.WINTER_CARD
        chosen = []
        if human_remove:
            state['non_player_factions'].remove(rc.GERMANS)

            def agent(board, faction, request):
                if request.get('stage') != ARVERNI_HALF:
                    return {'use_default': True}
                remaining = [dict(row) for row in request['cohorts']]
                removals = []
                # Use authored legal Ally choices to meet that independent quota.
                need = request['minimums'][rc.ALLY]
                while need:
                    row = next(r for r in eligible_cohorts(ARVERNI_HALF, remaining)
                               if r['piece_type'] == rc.ALLY)
                    amount = min(need, row['count'])
                    removals.append(dict(row, count=amount))
                    row['count'] -= amount
                    need -= amount
                row = next(r for r in eligible_cohorts(ARVERNI_HALF, remaining)
                           if r['piece_type'] == rc.WARBAND and r['region'] == human_remove)
                removals.append(dict(row, count=request['minimums'][rc.WARBAND]))
                chosen.extend(removals)
                return {'removals': removals}

            state['decision_agent'] = agent
        before = {'census_errors': validate_state(state),
                  'structure_errors': check_structural_integrity(state),
                  'threshold_winner': check_any_victory(state),
                  'warbands': {r: count_pieces(state, r, rc.ARVERNI, rc.WARBAND)
                               for r in (first, second)}}
        assert before['census_errors'] == before['structure_errors'] == []
        assert before['threshold_winner'] is None
        result = run_winter_round(state, britannia_decision=False)
        assert 'interlude' in result and not result['phases']['victory']['game_over']
        after = {'census_errors': validate_state(state),
                 'structure_errors': check_structural_integrity(state),
                 'warbands': {r: count_pieces(state, r, rc.ARVERNI, rc.WARBAND)
                              for r in (first, second)},
                 'scenario': state['scenario'],
                 'interlude_completed': state['interlude_completed']}
        assert after['census_errors'] == after['structure_errors'] == []
        adjustment = result['interlude']['step2_arverni']
        assert adjustment['warbands_to_available'] == 4
        return {'seed': seed, 'first': first, 'second': second,
                'human_remove': human_remove, 'before': before, 'after': after,
                'adjustment': adjustment, 'explicit_removals': chosen}

    protected = {}
    for region in (rc.VENETI, rc.CARNUTES, rc.PICTONES):
        rows = [run(seed, region, rc.SEQUANI) for seed in range(1, 13)]
        assert all(r['after']['warbands'] == {region: 4, rc.SEQUANI: 0} for r in rows)
        protected[region] = rows
    ordinary = [run(seed, rc.MANDUBII, rc.SEQUANI) for seed in range(1, 13)]
    ordinary_outcomes = Counter(
        rc.MANDUBII if r['after']['warbands'][rc.MANDUBII] == 0 else rc.SEQUANI
        for r in ordinary)
    assert set(ordinary_outcomes) == {rc.MANDUBII, rc.SEQUANI}
    arverni_last = [run(seed, rc.ARVERNI_REGION, rc.SEQUANI) for seed in (1, 2, 3)]
    assert all(r['after']['warbands'] == {rc.ARVERNI_REGION: 4, rc.SEQUANI: 0}
               for r in arverni_last)
    human = [run(1, region, rc.SEQUANI, human_remove=region)
             for region in (rc.VENETI, rc.CARNUTES, rc.PICTONES)]
    assert all(r['after']['warbands'] == {r['first']: 0, rc.SEQUANI: 4} for r in human)
    print(json.dumps({
        'id': 'LC11-01', 'assertions_passed': True,
        'source_revision': '702d60a3754ce94a73ead0d0148d647232ecd816',
        'protected_expansion_homes': protected,
        'ordinary_region_random_controls': ordinary,
        'ordinary_regions_removed_distribution': dict(ordinary_outcomes),
        'specified_arverni_last_controls': arverni_last,
        'human_legal_removal_controls': human,
        'case_count': 54,
        'scope': 'Actual Gallic War setup; canonical Arverni Warbands returned to Available '
                 'then eight placed as equal groups; third-Winter cursor supplied; public '
                 'run_winter_round reaches full Interlude with no threshold winner. '
                 'No mocks, monkeypatches, private reducer calls, or production edits. '
                 'Output records the affected Warband cohorts and validators, not an assertion '
                 'that every unrelated complete-board tie choice is hash-independent.',
    }, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
