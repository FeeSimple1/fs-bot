# Fifth comparison repair Batch 4 evidence

The parent is Falling Sky commit `e3786c46fe451ac1ea66115cc862eca43f52d900`.
`summary.json` identifies the tested Python sources and records the results.
`SHA256SUMS.json` contains the archive checksums. `parent-witnesses.json`
reproduces the fifth-audit Battle observations on the Batch 3 sources.

Run these checks from the relevant checkout with Python 3.12, pytest and
pytest-xdist. Use fresh output directories.

```sh
PYTHONHASHSEED=0 python -m pytest -q -n 5 --dist loadfile --tb=short --show-capture=no
python -m pytest -q --tb=short --show-capture=no fs_bot/tests/test_fifth_comparison_battle.py fs_bot/tests/test_battle*.py fs_bot/tests/test_stalwart_horse.py fs_bot/tests/test_horse_choice.py fs_bot/tests/test_capabilities_base.py fs_bot/tests/test_np_retreat*.py fs_bot/tests/test_base_arduenna_np.py fs_bot/tests/test_numidians_attack_cohort.py fs_bot/tests/test_release_compatibility.py
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out /path/to/results/bots-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 29-32 --card-edition second-edition --workers 2 --out /path/to/results/bots-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 29-32 --card-edition second-edition --out /path/to/results/fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 29-32 --card-edition second-edition --out /path/to/results/fuzz987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
```

Run the test file and create the original transcript from the parent
checkout. The test file produces eleven expected failures and five passing
controls. `PYTHONPATH=.` selects the checkout's engine.

```sh
PYTHONPATH=. python -m pytest -q --tb=short --show-capture=no /path/to/evidence/test_fifth_comparison_battle.py
PYTHONPATH=. PYTHONHASHSEED=0 python /path/to/evidence/verify_abatis_replay.py play /path/to/results/old-live default
```

Run the remaining transcript checks from the repaired checkout. Each replay
verifies the saved board, RNG and full decision log against its live session.

```sh
PYTHONPATH=. PYTHONHASHSEED=0 python /path/to/evidence/verify_abatis_replay.py play /path/to/results/new-live ally
PYTHONPATH=. PYTHONHASHSEED=0 python /path/to/evidence/verify_abatis_replay.py replay /path/to/results/old-live /path/to/results/old-replay
PYTHONPATH=. PYTHONHASHSEED=0 python /path/to/evidence/verify_abatis_replay.py replay /path/to/results/new-live /path/to/results/new-replay
```

The bot comparisons use the games recorded in the Batch 3 evidence. The
verified comparisons match the gameplay records, excluding timing and
source metadata. The fuzz logs and JSON match across the two hash seeds.
