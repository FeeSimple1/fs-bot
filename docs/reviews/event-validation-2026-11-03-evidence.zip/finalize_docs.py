from pathlib import Path
import hashlib,json,subprocess
HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'fs-bot'
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
source=json.loads((HERE/'final-prepared-source.json').read_text())
source={'commit':commit,'python_sha256':source['python_sha256'],'python_files':source['python_files']}
manifest=json.loads((HERE/'final-source-manifest.json').read_text())
for name,digest in manifest['files'].items():
    assert hashlib.sha256(subprocess.check_output(['git','show',f'{commit}:{name}'],cwd=REPO)).hexdigest()==digest,name
(HERE/'source-commit.json').write_text(json.dumps({'source':source,'matches_prepared_manifest':True,'prepared_base':'b17e2f6d8297501c16288cfd5de04ae61b19a774','integration_matrix_was_prepared_source':True},indent=2)+'\n')
(HERE/'committed-task-source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--full-index','8db858b14cd13856059d42db1ad3931e523b5ed4',commit,'--','fs_bot'],cwd=REPO))
p=REPO/'docs/human-choice-progress.json';progress=json.loads(p.read_text())
progress.update(updated='2026-11-03',closed=17,open=33,tested_source={**source,'note':'Committed Python tree exactly matches final prepared matrix and combined full-suite source. Documentation-only changes pending.','working_tree_changes':True})
for f in progress['findings']:
    if f['id'] in ('BE-11','BE-12','EXP-09'):
        f.update(status='closed',commits=(['b17e2f6d8297501c16288cfd5de04ae61b19a774'] if f['id']=='BE-12' else ['b17e2f6d8297501c16288cfd5de04ae61b19a774',commit]),report='reviews/event-validation-2026-11-03.md')
assert sum(f['status']=='closed' for f in progress['findings'])==17
assert len(progress['findings'])==50
p.write_text(json.dumps(progress,indent=2)+'\n')
report=(HERE/'report-final-draft.md').read_text().replace('{{SOURCE_COMMIT}}',commit)
assert '{{' not in report
(REPO/'docs/reviews/event-validation-2026-11-03.md').write_text(report)
r=json.loads((HERE/'matrix-02/integration-results.json').read_text())
r['matrix_source']=r.pop('source');r['source']=source
r['original_baseline_comparison']=r.pop('baseline_comparison')
r['baseline_refresh']=json.loads((HERE/'baseline-refresh.json').read_text())
r['passed']=True
r.update(audit_progress={'batch_closed':3,'batch_total':3,'closed':17,'open':33,'total':50,'percent':34},
    full_tests={'german_allegiances_standalone':6590,'combined':6728,'new_cases':177,'final_documentation':6728,'final_documentation_status':'pending execution'},
    immutable_source_inputs={'count':48,'unchanged':True},
    commits={'task_base':'8db858b14cd13856059d42db1ad3931e523b5ed4','german_allegiances':'b17e2f6d8297501c16288cfd5de04ae61b19a774','event_validation_and_baseline':commit},
    limits=['34 unverified inventory rows remain separate','Two source questions and nine provisional rulings unchanged','NPC pre-Battle Intimidate projection lead remains unverified and outside the original50','No exhaustive correctness or statistically conclusive balance claim'])
causal=json.loads((HERE/'causal-review/causal-summary.json').read_text())
r['causal_review']={'counts':causal['counts'],'first_cause_groups':causal['first_cause_groups'],'source':causal['source'],'limitations':causal['assessment'],'metadata_exception':causal['replay_exception_note'],'evidence':'causal-review/causal-summary.json'}
r['final_source_equivalence']=json.loads((HERE/'final-source-equivalence.json').read_text())
(REPO/'docs/reviews/event-validation-2026-11-03-results.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'source':source,'closed':17,'total':50,'report_written':True},indent=2))
