"""Reproduce audit-six observations on the audited Python source bytes."""
import argparse,hashlib,json,os,pathlib,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--out',required=True);a=p.parse_args()
root=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path(a.repo).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
source=json.loads((root/'validation/source.json').read_text());h=hashlib.sha256()
for file in sorted((repo/'fs_bot').rglob('*.py')):h.update(str(file.relative_to(repo)).encode()+b'\0'+file.read_bytes())
assert h.hexdigest()==source['source_sha256'],'Check out the audited source revision before running defect witnesses.'
probes=[('events/probe_events.py', 'events/probe_events-output.json'), ('frontend/probe_frontend.py', 'frontend/probe_frontend-output.json'), ('frontend/probe_enlist.py', 'frontend/probe_enlist-output.json'), ('battle/probe_battle.py', 'battle/probe_battle-output.json'), ('bots/probe_bots.py', 'bots/probe_bots-output.json'), ('lifecycle/probe_lifecycle.py', 'lifecycle/probe_lifecycle.json'), ('review/probe_aedui_fort.py', 'review/probe_aedui_fort-output.json')]
rows=[]
for script,expected in probes:
 env=dict(os.environ,PYTHONPATH=str(repo),PYTHONHASHSEED='0')
 r=subprocess.run([sys.executable,str(root/script)],cwd=repo,env=env,capture_output=True,text=True)
 actual=out/(pathlib.Path(script).stem+'.json');actual.write_text(r.stdout)
 match=r.returncode==0 and json.loads(r.stdout)==json.loads((root/expected).read_text())
 rows.append({'script':script,'expected':expected,'exit_code':r.returncode,'exact_json_match':match,'stderr':r.stderr})
summary={'all_pass':all(r['exact_json_match'] for r in rows),'source_sha256':h.hexdigest(),'witnesses':rows}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2));sys.exit(0 if summary['all_pass'] else 1)
