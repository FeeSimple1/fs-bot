# Ninth Falling Sky comparison evidence

Audited commit `f4c8372c396981c0a31dc6f4545e67f8c6f2e981`; Python SHA-256 `57a94d20440986063d7f86224a6074fa0ea2ce471e58e24e9c5dd349ec799033` (616 files).
Eight open repair groups: one high, seven medium. Production and protected sources unchanged.

Run `python run_witnesses.py --repo /absolute/path/to/fs-bot` with Python 3.12.
The standard-library runner verifies source bytes and reproduces all four confirmed
lane scripts at hash 0/987 with exact JSON agreement. Assertions pin defects, not
the intended repaired behavior. Each lane retains controls, findings and evidence;
frontend and lifecycle include saved public pending/phase states. Independent
reviews are under battle, lifecycle and validation; frontend was reviewed by the lead.

Validation logs describe 10,207 passing tests, 20 audited bot games, 20 mixed cases
across two hashes with replay (80 executions), zero hard findings and one soft
partial. See validation/summary.json for exact coverage and limitations. Its
source metadata names the audited parent. No new balance run or baseline change.

SHA256SUMS covers every other member. Constructed witnesses do not measure
encounter frequency or establish complete rules coverage.
