"""Battle Loss details at The Gallic War seed 17's first changed draw."""
from contextlib import redirect_stdout
from io import StringIO
import json

from fs_bot import rules_consts as rc
from fs_bot.cli.dispatcher import make_decision_func
from fs_bot.engine import execute
from fs_bot.engine.game_engine import get_sop_factions, play_card, start_game
from fs_bot.state.setup import setup_scenario

state = setup_scenario(rc.SCENARIO_GALLIC_WAR, seed=17)
state['non_player_factions'] = set(get_sop_factions(state))
original = execute.resolve_battle
rows = []


def combat(board, region, attacker, defender, **options):
    result = original(board, region, attacker, defender, **options)
    rows.append(dict(region=region, attacker=attacker, defender=defender,
        a33=board['capabilities'].get('A33'), attack=result['attack'],
        counterattack=result['counterattack']))
    return result


with redirect_stdout(StringIO()):
    start_game(state)
    decide = make_decision_func({}, stdin=StringIO(), stdout=StringIO(), pause=False)
    for _ in range(26):
        play_card(state, decide, execute=True)
    assert state['current_card'] == 'A24'
    execute.resolve_battle = combat
    play_card(state, decide, execute=True)
print(json.dumps(rows, indent=2))
