from pathlib import Path
import hashlib, io, json, platform, subprocess, tarfile, tempfile, zipfile
import xml.etree.ElementTree as ET
from fs_bot.tools.validation_metadata import source_identity

prefix = 'capability-queue-2026-11-05'
result = json.loads(Path('/tmp/fs-capability-queue-results.json').read_text())
assert source_identity() == result['source']
suite = ET.parse('/tmp/fs-capability-queue-full.xml').getroot().find('testsuite')
assert suite.attrib['tests'] == '8769'
assert all(suite.attrib[k] == '0' for k in ('failures', 'errors', 'skipped'))
assert sum(t.attrib['classname'].endswith('test_capability_queue') for t in suite) == 53
patch = subprocess.check_output(['git', 'diff', 'HEAD', '--', 'fs_bot'])
new_files = ('fs_bot/engine/capability_queue.py', 'fs_bot/cli/capability_queue.py',
             'fs_bot/tests/test_capability_queue.py')
with tempfile.TemporaryDirectory(prefix='fs-capability-queue-reconstruct-') as directory:
    root = Path(directory)
    parent = subprocess.check_output(['git', 'archive', result['source']['commit'], 'fs_bot'])
    with tarfile.open(fileobj=io.BytesIO(parent)) as archive:
        archive.extractall(root, filter='data')
    subprocess.run(['git', 'apply', '--unsafe-paths', '-'], cwd=root, input=patch, check=True)
    for name in new_files:
        (root / name).write_bytes(Path(name).read_bytes())
    files = sorted((root / 'fs_bot').rglob('*.py'))
    assert len(files) == 526
    digest = hashlib.sha256()
    for path in files:
        digest.update(str(path.relative_to(root)).encode()+b'\0'+path.read_bytes())
    assert digest.hexdigest() == result['source']['source_sha256']
result.update(full_suite=suite.attrib, python=platform.python_version(),
              source_reconstruction_verified=True,
              compatibility_limit='Older histories can stop at the new mandatory capability window or diverge under expanded human-response forecasts. PR-13 is adopted provisionally, subject to official correction.')
commands = [
 'python -m pytest -q --junitxml=/tmp/fs-capability-queue-full.xml',
 'python -m pytest -q fs_bot/tests/test_capability_queue.py fs_bot/tests/test_horse_queue.py fs_bot/tests/test_horse_choice.py fs_bot/tests/test_slingers_choice.py fs_bot/tests/test_base_arduenna_np.py fs_bot/tests/test_prospective_battle_observer.py fs_bot/tests/test_agent_interface.py fs_bot/tests/test_assistant_session.py fs_bot/tests/test_event_battle_choices.py',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --games 2 --workers 2 --out OUT',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
 'PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20',
 'PYTHONPATH=. python -m pytest -q /tmp/test_capability_queue_parent_proof.py --junitxml=OUT.xml',
 'PYTHONPATH=. python /tmp/fs-capability-queue-verify.py',
 'PYTHONPATH=. python /tmp/fs-capability-queue-package.py',
]
result['commands'] = commands
Path('docs/reviews/'+prefix+'-results.json').write_text(json.dumps(result, indent=2)+'\n')
p = Path('docs/reviews/'+prefix+'.md')
s = p.read_text().replace('Final full-suite and evidence inspection pending.',
 f"**8,769 tests pass**, with zero failures, errors or skips ({float(suite.attrib['time']):.2f} seconds).")
x = result['mixed']
s = s.replace('Frozen source, protected inputs, final results and archive checksums are\nverified separately.', f'''All ten standard NPC records complete and audit cleanly with four ranked
Factions, consistent winner/ranking output, no integrity findings and only
legal-decline diagnostics. Every gameplay field and final board hash matches
the parent, excluding elapsed seconds, commit and source identity.

The complete mixed-seat JSON outputs match across hash seeds 0 and 987. They
cover {x['human_turns']} human turns, {x['event_turns']} Event attempts and {x['events_ok']} successful Events, with zero hard
findings and zero partial games. Their digest is `{x['batch_digest'][:16]}`.
Internal replay gives 40 executions total. The historical 100-game balance
check passes the existing band, with a maximum difference of
{result['balance']['maximum_absolute_delta_percentage_points']} percentage points and {result['balance']['historical_baseline_winner_changes']} winner changes versus the historical baseline. Those
historical comparisons are separate from the ten exact parent/current NPC
comparisons.

All 49 protected inputs match the parent byte for byte, comprising 47 supplied
references, canonical constants and the historical balance baseline. Archive
checksums and reconstruction of all 526 Python files verify the accepted source
digest. All directed and focused runs pass. BE-09 closes under owner-adopted
provisional PR-13, subject to official correction.''')
p.write_text(s)
p = Path('docs/current-status.md')
p.write_text(p.read_text().replace('Validation pending the final full suite and evidence inspection.',
 '''**8,769 tests pass**, including 53 new cases, with 279 focused tests passing.
Ten standard NPC records/final hashes match the parent, mixed-seat results
agree across hash seeds with zero hard findings or partials, and the historical
100-game balance guard passes its unchanged band. The report records the
frozen source, protected inputs, evidence and cross-revision replay limit.''', 1))
entries = {}
for name in ['fs-capability-queue-full.xml', 'fs-capability-queue-full.log', 'fs-capability-queue-targeted.log', 'fs-capability-queue-directed.log', 'fs-capability-queue-directed.xml',
 'fs-capability-queue-mixed0.json', 'fs-capability-queue-mixed0.log', 'fs-capability-queue-mixed987.json',
 'fs-capability-queue-mixed987.log', 'fs-capability-queue-balance.log', 'fs-capability-queue-proof-parent.xml',
 'fs-capability-queue-proof-parent.log', 'fs-capability-queue-proof-final.xml', 'fs-capability-queue-proof-final.log',
 'test_capability_queue_parent_proof.py', 'fs-capability-queue-verify.py', 'fs-capability-queue-package.py']:
    entries['accepted/'+name] = Path('/tmp/'+name).read_bytes()
for label, directory in [('parent', '/tmp/fs-capability-queue-bots-parent'),
                         ('accepted', '/tmp/fs-capability-queue-bots-final')]:
    for path in Path(directory).iterdir():
        if path.is_file():
            entries[label+'/bots/'+path.name] = path.read_bytes()
for name in ['fs-capability-queue-initial.log', 'fs-capability-queue-directed-development.log']:
    entries['development/'+name] = Path('/tmp/'+name).read_bytes()
entries['development/README.txt'] = b'The first directed run failed 22 cases because the new test fixture wrote to a missing capability_owners map. The fixture was corrected to use set_capability_owner. A second run exposed one forecast fixture assuming its attacker could be human, while numeric 67 deliberately sets that seat to NPC. The final test uses a different human owner for the shared adapter. Accepted 53-case directed, 279-case focused and 8769-case full results are separate. No protected sources were changed.\n'
entries['accepted/source.patch'] = patch
entries['accepted/ruling.patch'] = subprocess.check_output(['git', 'diff', 'HEAD', '--', 'docs/provisional-rulings.md'])
entries['accepted/question.patch'] = subprocess.check_output(['git', 'diff', 'HEAD', '--', 'QUESTIONS.md'])
for name in new_files:
    entries['accepted/'+name] = Path(name).read_bytes()
protected = [p for p in Path('Reference Documents').rglob('*') if p.is_file()]
protected += [Path('fs_bot/rules_consts.py'), Path('fs_bot/tools/balance_baseline.json')]
entries['accepted/protected-inputs.json'] = json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}, indent=2).encode()
entries['accepted/results.json'] = json.dumps(result, indent=2).encode()
entries['commands.txt'] = ('\n'.join(commands)+'\n\nRun paired NPC batches and unchanged proof cases from their respective parent/current directories. Parent proof gives three behavioral failures and two passing controls; accepted proof gives five passing cases. All game matrices here are bounded general regression checks; directed tests exercise mandatory PR-13 windows.\n').encode()
entries['README.txt'] = (f"Parent {result['source']['commit']}. Apply accepted/source.patch and copy the three accepted/fs_bot new files to reconstruct the accepted source. Digest {result['source']['source_sha256']} across 526 files. Full suite 8769 passed, 53 new cases, 279 focused tests. Five probes give three parent failures and two passing controls; all five pass on the repair. Ten standard NPC records/final hashes match parent. Mixed-seat complete JSON matches across hash seeds 0/987, with zero hard findings or partials. The historical 100-game balance guard passes its unchanged 15-point band. Original bundle is 40/50 closed (80%); BE-09 closes under adopted provisional PR-13. {result['compatibility_limit']}\n").encode()
entries['SHA256SUMS.txt'] = ''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(entries.items())).encode()
p = Path('docs/reviews/'+prefix+'-evidence.zip')
with zipfile.ZipFile(p, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(p) as archive:
    assert archive.testzip() is None
    for line in archive.read('SHA256SUMS.txt').decode().splitlines():
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest
print(json.dumps(dict(suite=suite.attrib, archive_bytes=p.stat().st_size, source=result['source'])))
