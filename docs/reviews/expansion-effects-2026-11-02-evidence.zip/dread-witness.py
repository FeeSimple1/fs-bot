"""Run against either frozen baseline or repaired source, without changing it."""
import json
import sys
sys.path.insert(0, sys.argv[1])
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, place_piece
from fs_bot.cards.capabilities import activate_capability
from fs_bot.commands.raid import raid_in_region
from fs_bot.commands.rally import validate_recruit_region
from fs_bot.engine.execute import _execute_intimidate
from fs_bot.state.state_schema import build_initial_state

def state(hidden=3):
    s = build_initial_state(rc.SCENARIO_ARIOVISTUS, seed=4)
    s['non_player_factions'] = {rc.ROMANS, rc.AEDUI, rc.BELGAE, rc.GERMANS}
    place_piece(s, rc.UBII, rc.GERMANS, rc.LEADER, leader_name=rc.ARIOVISTUS_LEADER)
    place_piece(s, rc.UBII, rc.GERMANS, rc.WARBAND, hidden)
    place_piece(s, rc.UBII, rc.ROMANS, rc.AUXILIA, 3)
    activate_capability(s, 'A22', rc.EVENT_SHADED)
    return s
s = state()
entry = {'region': rc.UBII, 'target_faction': rc.ROMANS,
         'target_piece': rc.AUXILIA, 'target_state': rc.HIDDEN}
r = _execute_intimidate(s, rc.GERMANS, {'details': {'intimidate_plan': [entry]*3}})
print(json.dumps({'ordinary_three': r, 'auxilia_left': count_pieces(s, rc.UBII, rc.ROMANS, rc.AUXILIA)}))
s = state()
r = raid_in_region(s, rc.UBII, rc.GERMANS, [{'type': 'gain'}]*2)
print(json.dumps({'raid_two_plus_dread': r, 'auxilia_left': count_pieces(s, rc.UBII, rc.ROMANS, rc.AUXILIA)}))
s = state()
activate_capability(s, 'A22', rc.EVENT_UNSHADED)
place_piece(s, rc.UBII, rc.ROMANS, rc.FORT)
s['markers'][rc.UBII] = {rc.MARKER_INTIMIDATED: True}
print(json.dumps({'unshaded_marker_recruit': validate_recruit_region(s, rc.UBII)}))
