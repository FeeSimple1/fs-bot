from pathlib import Path
import hashlib
import io
import tarfile
import tempfile
import json
import platform
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from fs_bot.tools.validation_metadata import source_identity

prefix = 'setup-options-2026-11-04'
result = json.loads(Path('/tmp/fs-setup-options-results.json').read_text())
assert source_identity() == result['source']
suite = ET.parse('/tmp/fs-setup-options-full.xml').getroot().find('testsuite')
assert suite.attrib['tests'] == '8533'
assert all(suite.attrib[k] == '0' for k in ('failures', 'errors', 'skipped'))
assert sum(t.attrib['classname'].endswith('test_setup_options') for t in suite) == 68
# Reconstruct the exact accepted source from the parent plus archive inputs.
patch = subprocess.check_output(['git', 'diff', 'HEAD', '--', 'fs_bot'])
new_files = ('fs_bot/state/setup_options.py', 'fs_bot/tests/test_setup_options.py')
with tempfile.TemporaryDirectory(prefix='fs-setup-options-reconstruct-') as directory:
    root = Path(directory)
    parent_source = subprocess.check_output(['git', 'archive', result['source']['commit'], 'fs_bot'])
    with tarfile.open(fileobj=io.BytesIO(parent_source)) as archive:
        archive.extractall(root, filter='data')
    subprocess.run(['git', 'apply', '--unsafe-paths', '-'], cwd=root, input=patch, check=True)
    for name in new_files:
        (root / name).write_bytes(Path(name).read_bytes())
    digest = hashlib.sha256()
    files = sorted((root / 'fs_bot').rglob('*.py'))
    assert len(files) == 511
    for path in files:
        digest.update(str(path.relative_to(root)).encode() + b"\0" + path.read_bytes())
    assert digest.hexdigest() == result['source']['source_sha256']
result['source_reconstruction_verified'] = True
result['full_suite'] = suite.attrib
result['python'] = platform.python_version()
commands = [
 'python -m pytest -q --junitxml=/tmp/fs-setup-options-full.xml',
 'python -m pytest -q fs_bot/tests/test_setup.py fs_bot/tests/test_setup_options.py fs_bot/tests/test_game_engine.py fs_bot/tests/test_cli.py fs_bot/tests/test_card_edition.py fs_bot/tests/test_diviciacus_option.py fs_bot/tests/test_assistant_session.py fs_bot/tests/test_interlude.py fs_bot/tests/test_interlude_roman_choices.py',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --games 2 --workers 2 --out OUT',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
 'PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20',
 'PYTHONPATH=. python -m pytest -q /tmp/test_setup_options_parent_proof.py --junitxml=OUT.xml',
 'PYTHONHASHSEED=0 PYTHONPATH=. python /tmp/fs-setup-options-option-matrix.py',
 'PYTHONPATH=. python /tmp/fs-setup-options-verify.py',
 'PYTHONPATH=. python /tmp/fs-setup-options-package.py',
]
result['commands'] = commands
Path('docs/reviews/'+prefix+'-results.json').write_text(json.dumps(result, indent=2)+'\n')
p = Path('docs/reviews/'+prefix+'.md')
s = p.read_text().replace('Final full-suite and evidence inspection pending.',
 f"**8,533 tests pass**, with zero failures, errors or skips ({float(suite.attrib['time']):.2f} seconds).")
mixed = result['mixed']
s = s.replace('Frozen source, protected inputs, final results and archive checksums are\nverified separately.', f'''All ten standard NPC records complete and audit cleanly. Every gameplay field
and final board hash matches the parent, excluding elapsed seconds, commit and
source identity. All 34 optional-setup games complete and audit cleanly with
four ranked Factions, consistent winner/ranking output, no integrity findings
and only legal-decline diagnostics.

The complete mixed-seat JSON outputs match across hash seeds 0 and 987. They
cover {mixed['human_turns']} human turns, {mixed['event_turns']} Event attempts and {mixed['events_ok']} successful Events, with zero hard
findings and zero partial games. Their digest is `{mixed['batch_digest'][:16]}`.
Internal replay gives 40 executions total. The historical 100-game balance
check passes the existing band, with a maximum difference of
{result['balance']['maximum_absolute_delta_percentage_points']} percentage points and
{result['balance']['historical_baseline_winner_changes']} winner changes versus the historical baseline. Those historical comparisons
are separate from the ten exact parent/current NPC comparisons.

All 49 protected inputs match the parent byte for byte, comprising 47 supplied
references, canonical constants and the historical balance baseline. Archive
checksums and reconstruction of all 511 Python files verify the accepted source
digest. The first focused run exposed a mistaken test lookup of the pending
request envelope, corrected before acceptance. Its log remains in development
evidence and is excluded from accepted totals.''')
p.write_text(s)
p = Path('docs/current-status.md')
p.write_text(p.read_text().replace('Validation pending the final full suite and evidence inspection.',
 '''**8,533 tests pass**, including 68 new cases, with 545 focused tests passing.
All 34 optional-setup games complete and audit cleanly. Ten standard NPC
records/final hashes match the parent, mixed-seat results agree across hash
seeds, and the historical 100-game balance guard passes its unchanged band.
The report records source identity, protected inputs and raw evidence.''', 1))
entries = {}
for name in ['fs-setup-options-full.xml', 'fs-setup-options-full.log',
             'fs-setup-options-targeted.log', 'fs-setup-options-mixed0.json',
             'fs-setup-options-mixed0.log', 'fs-setup-options-mixed987.json',
             'fs-setup-options-mixed987.log', 'fs-setup-options-balance.log',
             'fs-setup-options-proof-parent.xml', 'fs-setup-options-proof-parent.log',
             'fs-setup-options-proof-final.xml', 'fs-setup-options-proof-final.log',
             'test_setup_options_parent_proof.py', 'fs-setup-options-verify.py',
             'fs-setup-options-package.py', 'fs-setup-options-option-matrix.py',
             'fs-setup-options-option-matrix.json', 'fs-setup-options-option-matrix.log']:
    entries['accepted/'+name] = Path('/tmp/'+name).read_bytes()
for label, directory in [('parent', '/tmp/fs-setup-options-bots-parent'),
                         ('accepted', '/tmp/fs-setup-options-bots-final')]:
    for path in Path(directory).iterdir():
        if path.is_file():
            entries[label+'/bots/'+path.name] = path.read_bytes()
for name in ['fs-setup-options-initial.log', 'fs-setup-options-retry.log',
             'fs-setup-options-pause.log']:
    entries['development/'+name] = Path('/tmp/'+name).read_bytes()
entries['development/README.txt'] = (b'The initial 67-case run had one test-only failure reading pending.kind instead of pending.request.kind. The next run passed 67 cases. A subsequent 68-case run added the switched-Winter pending/save/resume case. Accepted focused and full-suite logs are separate.\n')
entries['accepted/source.patch'] = patch
for name in ('fs_bot/state/setup_options.py', 'fs_bot/tests/test_setup_options.py'):
    entries['accepted/'+name] = Path(name).read_bytes()
protected = [path for path in Path('Reference Documents').rglob('*') if path.is_file()]
protected += [Path('fs_bot/rules_consts.py'), Path('fs_bot/tools/balance_baseline.json')]
entries['accepted/protected-inputs.json'] = json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}, indent=2).encode()
entries['accepted/results.json'] = json.dumps(result, indent=2).encode()
entries['commands.txt'] = ('\n'.join(commands)+'\n\nRun paired standard NPC batches and unchanged proof cases from their respective parent/current directories. Parent proof gives four behavioral failures and two passing controls; accepted proof gives six passing cases. The option matrix wraps setup_scenario with each legal nonstandard combination while retaining the native runner audit.\n').encode()
entries['README.txt'] = (f"Parent {result['source']['commit']}. Apply accepted/source.patch and copy both accepted/fs_bot new files to reconstruct Python sources. Accepted digest {result['source']['source_sha256']} across 511 files. Full suite 8533 passed, 68 new cases, 545 focused tests. Six behavioral probes yield four parent failures and two passing controls; all six pass on repaired source. Ten standard NPC records/final hashes match parent. All 34 option-matrix games complete and audit cleanly. Mixed-seat complete JSON agrees across hash seeds 0/987 with zero hard findings or partials. Historical 100-game balance check passes the unchanged 15-point band.\n").encode()
entries['SHA256SUMS.txt'] = ''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(entries.items())).encode()
p = Path('docs/reviews/'+prefix+'-evidence.zip')
with zipfile.ZipFile(p, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, data in sorted(entries.items()):
        z.writestr(name, data)
with zipfile.ZipFile(p) as z:
    assert z.testzip() is None
    for line in z.read('SHA256SUMS.txt').decode().splitlines():
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(z.read(name)).hexdigest() == digest
print(json.dumps(dict(suite=suite.attrib, archive_bytes=p.stat().st_size, source=result['source'])))
