# Eleventh comparison repair Batch 1 evidence

The repair closes EV11-01, EV11-02 and EV11-03. The tested parent was
`2963f7f1c8bcb0d2ded319477950b4e3117aba3e`. The repaired Python source
SHA-256 is `b52ed2a155095cd5b75938a3a02b2cbfe5708b1cf5c6faffda0f77c042f44035`
across 628 files, tested with Python 3.12.14. `protected-sources.json`
records the hashes of the 47 supplied references and canonical constants.
`SHA256SUMS` covers the other archive entries.

The parent Event witness matches the original eleventh audit's JSON.
The parent legacy outcomes come from the last tenth-audit batch, and its
second-edition and mixed-seat outcomes come from the eleventh audit. Their
metadata retain the original revisions and the parent Python digest. Paired
traces rerun every changed outcome on both revisions. The tests and games
use the same repaired Python bytes. The 27 balance checks were rerun after
installing the reviewed baseline data.

## Reproduce the results

Use the repository's development environment. Set `OUT` to an empty absolute
output directory, `EVIDENCE` to the extracted archive and `PARENT` to a clean
checkout of the tested parent. Run from the repaired checkout.

```bash
PYTHONHASHSEED=987 python -m pytest -q fs_bot/tests/test_eleventh_comparison_events.py
PYTHONHASHSEED=0 python -m pytest -q -n 4 --junitxml="$OUT/full.xml"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out "$OUT/legacy"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 57-60 --card-edition second-edition --workers 2 --out "$OUT/second-edition"
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 57-60 --card-edition second-edition --out "$OUT/fuzz0.json"
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 57-60 --card-edition second-edition --out "$OUT/fuzz987.json"
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20 --baseline "$EVIDENCE/previous-balance-baseline.json"
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
PYTHONPATH=. PYTHONHASHSEED=0 python "$EVIDENCE/trace_events.py" "$EVIDENCE/trace-tasks.json" > "$OUT/trace-repair.json"
PYTHONPATH=. PYTHONHASHSEED=0 python "$EVIDENCE/probe_lucterius_session.py"
PYTHONPATH=. python "$EVIDENCE/verify_results.py"
```

The comparison to the previous balance data reports the 20-point shift and
returns status 1. The current baseline reproduces all 100 outcomes. The
verifier checks archived records, exact coverage, checksums of protected
sources, replay equality, and source identity. The optional parallel pytest
run uses pytest-xdist. Run `python -m pytest -q` for the sequential suite.

```bash
cd "$PARENT"
PYTHONPATH=. PYTHONHASHSEED=0 python -m pytest -q "$EVIDENCE/test_eleventh_comparison_events.py"
PYTHONPATH=. PYTHONHASHSEED=0 python "$EVIDENCE/trace_events.py" "$EVIDENCE/trace-tasks.json" > "$OUT/trace-parent.json"
```
