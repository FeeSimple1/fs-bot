# Battle review for comparison audit 12

Reviewed Falling Sky commit `1563e41d84f61dfce43ce4008106eca2a1639aed` and
Liberty or Death commit `2991ea279062773548ec390a1da75f3e85381702`.
One medium-priority defect group is confirmed.

## BM12-01

Belgae, Arverni and German bot Battle forecasts omit Balearic Slingers opening fire.

Each bot sends its named Leader and one Hidden Warband into a Battle against
four Revealed Roman Auxilia at Carnutes after public activation of unshaded
Card 13. The printed flowcharts prohibit a Battle that can assign a Loss to
the named Leader. Slingers first inflicts two Losses, reaching the Leader
after the sole Warband. Seeds 1 and 7 both remove the Leader and Warband,
leave all four Auxilia, and charge the attacking bot one Resource.
The Belgic and Arverni actions include Ambush. The German action is a
Battle without a Special Ability.

| Bot | Forecast before opening fire, inflicted / suffered | Actual surviving attackers | Roman Auxilia remaining |
|---|---|---|---|
| Belgae | 2 / 0 | 0 | 4 |
| Arverni | 1 / 0 | 0 | 4 |
| Germans | 3 / 0 | 0 | 4 |

The ordinary gates call `predict_battle` without `earlier_battles`.
Opening fire is conditional on that parameter being supplied.
The existing forecast with an empty prior-Battle list exposes a possible
Leader Loss in every adverse case. The live executor applies Slingers
correctly. It also offers the Leader Loss in the recorded casualty request,
so the finding is supported before the random save/removal result.

The German Command-aware diagnostic reports four total Losses, because its
approximation includes a hypothetical Counterattack after opening fire has
removed both attackers. The live witness proves the two opening Losses.
This diagnostic overcount does not affect the confirmed Leader-safety
violation and is not counted as another finding.

## Source requirements

- `Reference Documents/Chapter 8:237–255` requires the Belgic favorable
  exchange and no Loss on Ambiorix, with March when his threat Battle fails.
- `Reference Documents/Chapter 8:576–595` requires no possible Loss on
  Vercingetorix and explicitly includes Capability effects.
- `Reference Documents/Ariovistus/Chapter A8:72–89` requires the German
  favorable exchange and no Loss on Ariovistus.
- `Reference Documents/Card Reference:125–136` provides Roman opening
  Slingers fire in an enemy Battle Command, including Ambush.
- `Reference Documents/Ariovistus/A Card Reference:126–131` supplies
  Stalwart's cancellation used by the German controls.

## Reproduction and controls

Run `python probe_battle.py /absolute/path/to/falling-sky`.
The script asserts all witness and control outcomes and prints JSON.
Hash seeds 0 and 987 produce byte-identical output across seventeen cases.

The six primary cases cover all three factions at seeds 1 and 7. Six matched
capability-absent controls retain the named Leader and Warband and remove the
forecast number of Auxilia. Three Command-only controls give each Leader
eight Warbands, apply the two opening Slingers Losses, and finish with the
Leader and six Warbands against zero Auxilia. Two German controls publicly
acquire shaded A31 after Slingers, cancel initial fire, and retain Ariovistus
and his Warband while removing three Auxilia.

Every fixture is a sparse `build_initial_state` board with canonical
`place_piece` calls, the permanent Provincia Fort, the actor marked
Non-player, and ten Resources. Every acquisition uses an authored validated
public Event action. The main action uses `dispatch_bot_turn` and public
`execute_decision`. The human Roman callback selects Carnutes for Slingers
and stands when asked about Retreat. It logs casualty requests and delegates
casualty choices. All seventeen cases have empty census and structural
findings before and after execution. Dispatch and both detached forecasts
preserve the board and RNG in these single-target positions.

These are constructed positions and controlled current-card metadata.
No claim is made about encounter frequency in naturally sampled games,
full-session save/resume behavior, or every Capability combination.
No production code or references were changed.

## Comparison and prior findings

The Liberty or Death review inspected `lod_ai/commands/battle.py:383–410`,
where bot scores call the same Force Level and Loss modifier functions used
at resolution (`battle.py:768–799`). It also inspected the engine checkpoint
paths at `lod_ai/engine.py:756–793` and whole-action checkpoint at
`engine.py:1055–1156`. The transferable lesson is to carry the actual combat
context into the shared calculation. Falling Sky's shared forecast already
supports the missing opening stage, and its Aedui consumer supplies that
context at `fs_bot/bots/aedui_bot.py:606–618`.

NP6-01 repaired pre-Attack defender counting and Ambiorix strength.
NP7-01 repaired omission of a legal Ambush in the candidate forecast.
NP8-01 repaired the Aedui additional-Battle consumer. BM6-01/02 and BM7-01
repaired live Slingers cancellation and alternate execution paths.
The new finding is the ordinary Belgic, Arverni and German forecast
consumers, demonstrated with correct live opening fire.

One repair group should wire opening-fire context and already selected
Battles into these three bot gates, including their Leader-safety tests and
first-Battle Ambush decisions. Preserve the once-per-Command choice by the
Roman owner, successful Stalwart cancellation, and the printed per-faction
decision rules. Do not replace missing context with unconditional fire in
every candidate Region.

## Coverage and excluded hypotheses

Inspected Battle attack/counterattack formulas, Retreat declaration and
survivor placement, opening Archers/Slingers orchestration, the shared
predictor, and all ordinary bot predictor call sites. Read the thirteen
adopted provisional rulings and compared findings against prior audit
ledgers.

Caesar Ambush forecasts intentionally retain a possible successful Caesar
test, matching the earlier conservative decision requirement, so that
candidate was rejected. The ambiguous A33 meaning of outnumbered had
already been retained as an unresolved source question in round 4 and was
not promoted to a finding. Archers and Horse omissions in the same
unscoped consumers remain static leads only. This report counts only the
dynamically demonstrated Slingers family.
