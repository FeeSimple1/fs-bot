# Human-choice audit brief

Repository: /workspace/scratch/534c265c65f4/fs-bot
Audit commit: 7e72fe7eda33c58b2f83457c39edf5b295a04f77
Python digest: c24adb23c9018071ed948e295a96fc4b17649e35fecabd985e77dedbfa32fcc5
Python: /workspace/scratch/534c265c65f4/fs-test-venv/bin/python
Output directory: /workspace/scratch/534c265c65f4/human-choice-audit-2026-10-29

The user requested a bounded, systematic audit of human-player choices after
the action-timing repair. Produce verified findings and coverage, not fixes.
Read CLAUDE.md and relevant supplied Reference Documents. Protected rules and
constants are read-only. PR-01 through PR-09 in docs/provisional-rulings.md are
already adopted. Q-TRADE-NP-REGION and Q-ELITE-NP-PIECES are existing separate
NP source ambiguities, not newly discovered human-interface bugs. No outside
research or other repositories. No production, test, baseline or rule edits.

Audit three layers separately: mechanics/typed action contract; terminal
menus and reactive prompts; durable assistant sessions. Raw callbacks may
explicitly defer to bots; this alone is not a durable-session defect. Existing
tests are evidence, not the source of the rules. Do not assume every gap is
fixed because tests pass. Verify which actor owns each choice and whether
legality/options update before input, with exact quantities, targets,
ordering, optional effects, physical ownership, card/board information,
save/resume/replay. Distinguish confirmed bugs from source ambiguities and
unverified interactions. Avoid broad strategic/bot-policy audits.

Inventory every choice family in your assigned domain. For Events enumerate
every assigned card identity/side/profile (including no-choice effects),
then group related choices where useful. Write <partition>.json containing:

- area and audited_commit
- coverage: entries with id, rule, choice, engine, cli, assistant, status
  (supported, confirmed-gap, source-question, or not-verified), evidence.
- findings: id, title, severity (high/medium/low), rule/source quotation,
  affected interfaces, expected, observed, precise code locations, minimal
  reproduction/probe path, related existing tests, recommended repair scope.
- checks_run and limitations.

Preserve minimal deterministic reproduction scripts/output in probes/.
Use valid initialized states and piece helpers; validate state where relevant.
Explain assumptions. Probes may demonstrate a bug without becoming failing
repository tests. Do not run a fresh full-game/balance matrix; root runs the
required full pytest once before the documentation commit. No sub-agents.
Send root confirmed high/medium findings early and a concise completion
summary. When sufficiently covered, freeze your outputs; don't grow scope.
