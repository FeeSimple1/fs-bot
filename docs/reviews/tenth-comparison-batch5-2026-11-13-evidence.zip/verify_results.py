"""Verify the archived Batch 5 test, replay, and balance evidence."""

import hashlib
import json
from pathlib import Path
from xml.etree import ElementTree

from fs_bot.tools.validation_metadata import source_identity
from prepare_comparison import (
    BALANCE_ROW, ROOT, compare_traces, load, original_balance, paired_runs,
)


def tests():
    cases = {'parent-directed': (22, 11), 'directed987': (22, 0),
             'focused': (212, 0), 'full': (10379, 0),
             'reviewed-guardrail': (27, 0)}
    summary = {}
    for name, (count, failures) in cases.items():
        suite, = ElementTree.parse(ROOT / f'{name}.xml').iter('testsuite')
        values = {'tests': count, 'failures': failures, 'errors': 0, 'skipped': 0}
        assert all(int(suite.get(key)) == n for key, n in values.items()), name
        summary[name] = dict(values, passed=count - failures, seconds=float(suite.get('time')))
    return summary


def main():
    repo = Path(__import__('fs_bot').__file__).resolve().parent.parent
    protected = load('protected-sources.json')
    assert len(protected) == 48
    assert all(hashlib.sha256((repo / path).read_bytes()).hexdigest() == sha
               for path, sha in protected.items())
    source = load('source.json')
    digest = source['source_sha256']
    assert digest == source_identity()['source_sha256']
    games, mixed, tasks, summary = paired_runs()
    assert tasks == load('trace-tasks.json')
    summary['first_changes'] = compare_traces(games, mixed, tasks, digest)
    summary['balance'], candidate = original_balance(games)
    assert summary == load('comparison.json')
    assert candidate == load('reviewed-baseline.json')
    assert candidate == json.loads((repo / 'fs_bot/tools/balance_baseline.json').read_bytes())
    log = (ROOT / 'balance-reviewed.log').read_text()
    rows = {f'{scenario}|{seed}': {'winner': faction, 'cards': int(cards)}
            for scenario, seed, faction, cards in BALANCE_ROW.findall(log)}
    assert rows == candidate['games'] and len(rows) == 100
    assert 'OK: balance within band.' in log
    result = {key: value for key, value in summary.items() if key != 'first_changes'}
    result['balance']['refreshed_matrix_matches'] = True
    result.update(source=source, tests=tests(), protected_files=len(protected))
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
