"""Read-only, independent acceptance checks over finalized run_batch evidence."""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import subprocess

repo = Path(__file__).resolve().parent.parent / 'fs-bot'
root = Path(__file__).resolve().parent / 'attempt3'
study = root / 'bots-legacy'
expected_scenarios = ('Pax Gallica?', 'Reconquest of Gaul', 'The Great Revolt', 'Ariovistus', 'The Gallic War')
expected_pairs = {(scenario, seed) for scenario in expected_scenarios for seed in range(1, 21)}
factions = ('Romans', 'Arverni', 'Aedui', 'Belgae', 'Germans')
metadata = json.loads((study / 'metadata.json').read_text())
summary = json.loads((study / 'summary.json').read_text())
source = json.loads((root / 'source.json').read_text())
records = [json.loads(line) for line in (study / 'games.jsonl').read_text().splitlines()]
failures = []

def check(condition, message):
    if not condition:
        failures.append(message)

check(len(records) == 100, f'Expected100 records, found{len(records)}')
pairs = [(r.get('scenario'), r.get('seed')) for r in records]
check(len(pairs) == len(set(pairs)), 'Duplicate scenario/seed pairs')
check(set(pairs) == expected_pairs, 'Scenario/seed coverage differs from exact5x20 matrix')
check(metadata['seeds'] == list(range(1, 21)), 'Incorrect metadata seeds')
check(metadata['scenarios'] == list(expected_scenarios), 'Incorrect metadata scenarios')
check(metadata['card_edition'] == 'legacy', 'Incorrect edition metadata')
check(metadata['hash_seed'] == 0, 'Incorrect hash seed')
check(metadata['all_factions_bots'] is True, 'Human seats in bot study')
check(metadata['source_sha256'] == source['source_sha256'], 'Frozen-source digest mismatch')
check(metadata['commit'] == source['commit'], 'Frozen-source commit mismatch')
sha = hashlib.sha256()
for path in sorted((repo / 'fs_bot').rglob('*.py')):
    sha.update(str(path.relative_to(repo)).encode() + b'\0' + path.read_bytes())
check(sha.hexdigest() == source['source_sha256'], 'Current Python source differs from tested digest')

for r in records:
    name = f"{r['scenario']} seed{r['seed']}"
    for flag in ('completed', 'game_completed', 'audit_completed'):
        check(r.get(flag) is True, f'{name}: {flag} is not true')
    check(not r.get('error') and not r.get('errors'), f'{name}: errors present')
    check(not r.get('integrity_findings'), f'{name}: integrity findings present')
    check(r.get('card_edition') == 'legacy', f'{name}: mixed edition')
    check(r.get('source_sha256') == source['source_sha256'], f'{name}: mixed source')
    check(r.get('commit') == source['commit'], f'{name}: mixed commit')
    check(type(r.get('cards')) is int and r['cards'] > 0, f'{name}: invalid card count')
    ending = r.get('ending_scenario')
    check(ending in expected_scenarios, f'{name}: unknown ending scenario')
    eligible = set(factions) - ({'Arverni'} if ending in ('Ariovistus', 'The Gallic War') else {'Germans'})
    ranking, emitted = r.get('final_ranking', []), r.get('engine_final_ranking', [])
    check(len(ranking) == 4 and {row[0] for row in ranking} == eligible,
          f'{name}: ranking does not contain four eligible factions')
    check(all(len(row) == 2 and type(row[1]) is int for row in ranking), f'{name}: malformed ranking')
    check(ranking == emitted, f'{name}: engine and recomputed rankings differ')
    check([row[1] for row in ranking] == sorted([row[1] for row in ranking], reverse=True),
          f'{name}: margins not ranked in descending order')
    check(r.get('winner') == ranking[0][0] == r.get('highest_margin_leader'),
          f'{name}: winner differs from top-ranked faction')
    check(r.get('winner_differs_from_highest_margin') is False and r.get('engine_ranking_output_missing') is False,
          f'{name}: ranking flags indicate failure')
    check(r.get('threshold_qualifiers') == [f for f, margin in ranking if margin > 0],
          f'{name}: threshold qualifiers disagree with positive margins')
    check(len(r.get('final_state_sha256', '')) == 64, f'{name}: missing state digest')
    check(r.get('termination') in ('optimates', 'threshold', 'final-winter-margin'), f'{name}: unexpected termination')
    for d in r.get('diagnostics', []):
        check(d.get('severity') == 'legal-decline', f'{name}: nonlegal diagnostic {d}')
    for d in r.get('diagnostic_occurrences', []):
        check(d.get('severity') == 'legal-decline', f'{name}: nonlegal diagnostic occurrence {d}')

baseline_bytes = subprocess.check_output(['git', 'show', 'HEAD:fs_bot/tools/balance_baseline.json'], cwd=repo)
check((repo / 'fs_bot/tools/balance_baseline.json').read_bytes() == baseline_bytes, 'Committed balance baseline was modified')
baseline = json.loads(baseline_bytes)['games']
comparison = {}
changed = []
max_delta = Fraction(0)
for scenario in expected_scenarios:
    rows = [r for r in records if r['scenario'] == scenario]
    current = Counter(r['winner'] for r in rows)
    prior = Counter(baseline[f'{scenario}|{seed}']['winner'] for seed in range(1, 21))
    totals = summary[scenario]
    check(totals['attempted'] == totals['completed'] == totals['engine_completed'] == 20,
          f'{scenario}: summary completion totals differ')
    check(totals['wins'] == dict(current), f'{scenario}: summary winners differ')
    check(totals['crashes'] == totals['integrity_flagged_games'] == totals['winner_margin_disagreements'] == 0,
          f'{scenario}: summary failure totals nonzero')
    deltas = {}
    for faction in factions:
        delta = Fraction(current[faction] - prior[faction], 20)
        max_delta = max(max_delta, abs(delta))
        deltas[faction] = {'baseline_wins': prior[faction], 'current_wins': current[faction],
                          'delta_exact': str(delta), 'delta_percentage_points': float(delta * 100)}
        check(abs(delta) <= Fraction(3, 20), f'{scenario}/{faction}: drift{delta} exceeds3/20')
    comparison[scenario] = deltas
    changed.extend(f"{scenario}|{r['seed']}" for r in rows
                   if r['winner'] != baseline[f"{scenario}|{r['seed']}"]['winner'])
report = {'passed': not failures, 'failures': failures, 'records': len(records),
          'source_sha256': source['source_sha256'], 'commit_base': source['commit'],
          'exact_band': '3/20', 'maximum_absolute_drift': str(max_delta),
          'changed_winners': changed, 'changed_winner_count': len(changed),
          'comparison': comparison}
(root / 'independent-legacy-review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
raise SystemExit(1 if failures else 0)
