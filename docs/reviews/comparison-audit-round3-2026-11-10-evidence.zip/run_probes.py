"""Rerun the final witnesses against a specified checkout into a new directory."""
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir(parents=True, exist_ok=False)
env = dict(os.environ, PYTHONPATH=str(repo), PYTHONHASHSEED='0')
scripts = [
    'probe_seasonal.py',
    'base-events/probe_events.py',
    'commands/probe_commands.py',
    'expansion/probe.py',
    'frontends/probe_eligibility_flag.py',
    'frontends/probe_journal_collision.py',
    'patterns/probe_dynamic_colony.py',
    'patterns/probe_razed_seize.py',
]
results = []
for script in scripts:
    args = [sys.executable, str(root / script)]
    if script == 'commands/probe_commands.py':
        args.append(str(repo))
    completed = subprocess.run(args, cwd=repo, env=env, text=True,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log = script.replace('/', '--').removesuffix('.py') + '.log'
    (out / log).write_text(completed.stdout)
    results.append({'script': script, 'returncode': completed.returncode, 'log': log})
    print(json.dumps(results[-1]), flush=True)
(out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
sys.exit(1 if any(item['returncode'] for item in results) else 0)
