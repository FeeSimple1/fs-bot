# EXP-05 / EXP-06 Roman compound Event grants

Branch: `repair/event-roman-2026-11-02`; base: `d3241e7`.
Commit: `1e52a3990c0bc7df9453d688b9b59ca238ed24c7` (not pushed).

## Rules and resulting behavior

Read `CLAUDE.md`, README/documentation/API orientation, all nine adopted provisional rulings, and the complete Reference Documents directory inventory. No protected references or constants were edited and no external rules were consulted.

- A Card Reference A20: “If Romans within 1 Region of Veneti, they may remove all Arverni from and free Seize there as if Roman Control and with no rolls for Gallic Rally.” Roman acceptance now precedes every removal. On acceptance, all actual Arverni Ally/Citadel and Hidden/Revealed/Scouted Warband pieces in Veneti are removed. A subsequent Roman Seize choice is made on that resulting board if ordinary Roman-presence requirements allow Seize. A nearby Roman Ally suffices to enable removal, but does not waive the ordinary presence requirement for Seize in Veneti. Harassment remains normal.
- A Card Reference A58: “Romans may free Battle anywhere in Belgica, then free Seize in Belgica as if Roman Control, with no Harassment or enemy Rally.” The Roman controller accepts/declines the entire benefit, including when another faction executes the Event. Accepted Battle and Seize components are chosen separately on current boards; multiple Belgica Regions are legal. Static-only Roman Forces may Battle. Seize waives Control and suppresses both Rally dice/opportunities and Harassment.
- §§5.1.1/5.1.3/5.4 retain normal Command selection and execute accepted components when possible. No Special Ability accompanies either grant. If the first component is impossible the second still resolves if possible.
- §§8.2.3/8.3.4/8.8.5: A58 first uses the actual Roman flowchart restricted to Battle in Belgica. Seize follows safe Dispersal first (non-Helvii, at player pieces, then Belgica), seeded tied Region/Tribe selection, then safe Forage. A20 does not waive the NP no-Harassment preference. A58's printed exception makes those Regions safe. There is no special Roman A20/A58 override in the Ariovistus Roman Event instructions.
- A20 shaded and its adopted PR-09 origin policy were not changed.

## API and CLI contracts for root documentation

All three request kinds below use `kind: free_action`, Roman request ownership, `acting_faction: Romans`, `card_id`, and `validate_default_response: true`.

1. `request_type: roman_event_accept`: respond exactly `{"accept":true}`, `{"decline":true}`, or `{"use_default":true}`. Default accepts the compound benefit. Decline does not remove Arverni, Battle, or Seize.
2. `request_type: roman_event_battle` (A58 only): an ordinary explicit Battle action selecting offered `allowed_regions` and current `battle_targets`. Multiple distinct Regions are allowed. `allow_decline:false`; `with_sa:false`. Optional `details.diviciacus_regions` remains supported and the CLI offers cooperation before planning. An accepted default with no NP choice is invalid; it does not evade a required human Battle.
3. `request_type: roman_event_seize`: ordinary action shape with `command: Seize`, ordered distinct `regions`, and `details.disperse_tribes` mapping every selected Region to its exact chosen Tribe list (empty lists mean Forage only). Request exposes every currently Subdued Tribe in `dispersible_tribes`, including choices beyond a scarce marker count, and `available_markers`. Optional `details.diviciacus_regions` is supported. No legacy `disperse_regions` or user-authored exception flags in this response. `allow_decline:false`.

Example Seize response (when offered on the current board):

```json
{"command":"Seize","regions":["Nervii"],"sa":"No SA","sa_regions":[],"details":{"disperse_tribes":{"Nervii":["Eburones"]}}}
```

The engine-owned Seize request alone carries `seize_as_if_control`, `seize_no_rally`, and `seize_no_harassment`. A temporary Region-scoped frame supplies both live execution and validation. Responses cannot supply these privileges through their details; ordinary Seize ignores prior undocumented `as_if_control`/`no_harassment` detail fields and retains ordinary rules. The low-level mechanical Seize API has a default-false `no_rally` keyword used by the trusted driver.

The validator is `engine.free_actions.validate_free_action_response`; previews discard the live callback and isolate the RNG. New grants reject `details.command_parts`, closing a confirmed fake-single-portion regional-scope bypass without changing unrelated generic grants.

Durable missing/illegal/stale responses keep the same request pending. Accepted choice journals survive rollback and save/load, and requests show the board at the actual stage. A refused optional Diviciacus loan reopens the still-required component with `attempt` and `previous_error`; an explicitly accepted default retains this behavior. The raw callback contract remains distinct: `None` uses existing NP priorities and may return a no-action outcome when those priorities find none.

Terminal prompts support board inspection, EOF interruption, acceptance, exact Battle/Tribe choices, validated defaults, and optional Diviciacus cooperation. Top-level ordinary Seize's existing menu/response behavior is unchanged; exact Tribe choice was added only to these new grants.

## Files and shared integration notes

New implementation: `fs_bot/cards/roman_event_grants.py`, `fs_bot/cli/roman_event_grants.py`.
New tests: `fs_bot/tests/test_roman_event_grants.py`, `fs_bot/tests/test_roman_event_sessions.py`.
Narrow wiring: A20 unshaded handler, existing A20/A58 unshaded resolver wrappers, `_execute_seize`, `commands/seize.py`, free-action validator/executor and CLI dispatch.

The six-line `tools/seat_session.py` exact-default gate is identical to the one in EXP-01 commit `60267c74b5e2ba99931bdd3812dda2bbe28cec91`. Root expressly asked that it remain in this isolated tested commit; integrate it once.

Two historical regression fixtures were corrected: A58 is not a no-op for a non-Roman executor, and an NP A20 Control-override fixture now uses Revealed opposition so it does not accidentally demand the newly enforced forbidden-Harassment Seize.

## Validation and preserved development failures

- Focused final candidate: 42 passed (`test_roman_event_grants.py` plus `test_roman_event_sessions.py`). Includes 4 complete `llm_seat` save/submit/replay flows (A20/A58 × both Ariovistus scenarios).
- Coverage: all executor factions, Roman decline before removals, all Arverni visibility classes, adjacency-only prerequisite, current-board multi-Region Battle then selective Seize, zero enemy Rally rolls, A20 versus A58 Harassment, static-force Battle, mandatory-default rejection, exact marker scarcity, ordinary Seize, client flag/Region/duplicate/Tribe/command-parts rejection, rollback, preview board/RNG/callback isolation, CLI board/EOF/cooperation, actual Diviciacus refusal for concrete and default plans, and raw fallback distinctions.
- `roman-pytest-full-attempt1.log`: 6,314 passed in 117.71s. Superseded, not accepted final-revision evidence: reviewer fixes and added tests were being made during that run.
- `roman-pytest-full-attempt2.log`: **6,322 passed in 120.49s**, final full suite on the immutable source committed as `1e52a3990c0bc7df9453d688b9b59ca238ed24c7`. Command: `/workspace/scratch/534c265c65f4/fs-test-venv/bin/python -m pytest -q -n 2`.
- Initial focused integration run: 4 failed / 422 passed (42.49s). Two failures were the obsolete assertions just described; two were missing legacy top-level no-effect result fields, which were restored. Tool output remains in the working transcript.
- Initial new-test run: 4 failed / 23 passed; three test expectations missed Nervii's second Subdued Tribe (+2 Forage) and one expected only two Rally rolls despite two ordinary Dispersals. Fixtures corrected to printed Tribe geography/procedure. Next run: 1 failed / 29 passed because the CLI test omitted the required “finish Dispersal” response; input corrected. Tool outputs remain in the transcript.
- Independent review found and caused repairs to static-only legal Battle menus, mandatory default semantics, optional loan retry, unrelated empty grant-frame signatures, and the fake `command_parts` scope bypass. Regression tests now cover each.

## Limits / compatibility

No new ruling was adopted. Source-derived changes intentionally alter affected historical Event outcomes and therefore can invalidate old affected transcripts; do not label those as guaranteed backward replay compatibility. Unrelated free-action requests do not acquire a new empty transient grant frame. No new save-format version or persistent game fact is introduced. Project-wide docs/progress register and merged outcome/census/hash/balance validation remain root-owned; this branch does not refresh any baseline or make claims about aggregate outcomes.

## Follow-up: refresh mandatory retries after live timing changes

The independent reviewer subsequently found a stale retry deadlock in initial commit `1e52a3990c0bc7df9453d688b9b59ca238ed24c7`: a human Belgae Event executor could remove the last Belgic Warband at A58's live `battle_command` window after Romans had accepted the benefit and chosen an explicit Battle default. The default then produced no Battle, but the mandatory retry reused the old Region/defender menu. A durable human had no legal response if no enemy remained.

The follow-up reconstructs `command_request` from the actual board at the start of every attempt, retaining `attempt`/`previous_error` separately. A component that becomes mechanically impossible skips to the next Event component under §5.1.3; when other legal Battle Regions remain, the retry offers only those current Regions and defenders. Explicit-default versus raw-callback-None behavior remains distinct.

Four source-derived regressions use the actual action-window/voluntary-removal machinery: both expansion scenarios, with either no remaining Battle or a static-only Roman/German Battle remaining in Morini. All four failed against the initial commit; full failure output is preserved in `roman-retry-regression-before.log`. The corrected focused suite passes **46 tests**. The independent reviewer rechecked the delta and reported no remaining blocker in the scoped Roman review.

Follow-up commit: `c9464c111d96d45efffb9bdab8452edc83818b36` (apply after `1e52a3990c0bc7df9453d688b9b59ca238ed24c7`; neither was pushed). Frozen full suite: **6,326 passed in 123.43s** with `/workspace/scratch/534c265c65f4/fs-test-venv/bin/python -m pytest -q -n 2`. Log: `roman-pytest-retry-followup.log`. This follow-up supersedes the initial commit's assertion of completeness for the live-timing retry edge; its original passing run remains a revision-specific checkpoint.
