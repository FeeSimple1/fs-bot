from pathlib import Path
import json,subprocess
from fs_bot import rules_consts as rc
from fs_bot.tools.validation_metadata import source_identity
parent='6e1b04d53c639d7503925d57dafdff22b01e4471';source=source_identity()
assert source['source_sha256']=='61faa08aa203d0af35e2c934093898fc5c5ed6836c100643d3fc21c3b097bdd8'
records={}
for label,directory in [('parent','/tmp/fs-shouts-bots-parent'),('final','/tmp/fs-shouts-bots-final')]:
 rows=[json.loads(x) for x in Path(directory+'/games.jsonl').read_text().splitlines()]
 records[label]={(r['scenario'],r['seed']):r for r in rows}
 assert set(records[label])=={(s,n) for s in rc.ALL_SCENARIOS for n in (1,2)}
 for row in rows:
  assert all(row[k] for k in ('completed','game_completed','audit_completed','final_state_sha256'))
  assert not row['errors'] and not row['integrity_findings']
  assert len(row['final_ranking'])==4 and not row['winner_differs_from_highest_margin'] and not row['engine_ranking_output_missing']
  assert all(d['severity']=='legal-decline' for d in row['diagnostics'])
ignored={'seconds','commit','source_sha256'}
for k,p in records['parent'].items():
 c=records['final'][k]
 assert {f:v for f,v in p.items() if f not in ignored}=={f:v for f,v in c.items() if f not in ignored},k
assert json.loads(Path('/tmp/fs-shouts-bots-final/metadata.json').read_text())['source_sha256']==source['source_sha256']
x=json.loads(Path('/tmp/fs-shouts-mixed0.json').read_text());y=json.loads(Path('/tmp/fs-shouts-mixed987.json').read_text())
assert x==y and not x['hard_findings'] and x['partial']==0 and all(r['game_completed'] for r in x['records'])
assert x['metadata']['source_sha256']==source['source_sha256']
protected=[p for p in Path('Reference Documents').rglob('*') if p.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
for p in protected:assert p.read_bytes()==subprocess.check_output(['git','show',parent+':'+str(p)])
result={'date':'2026-11-04','timezone':'America/Chicago','source':source,'python_files':len(list(Path('fs_bot').rglob('*.py'))),'protected_files':len(protected),'protected_files_unchanged':True,'targeted_passed':120,'new_tests':35,'parent_proof':{'behavioral_failures':25,'controls_passed':2,'deselected':8},'bots':{'games':10,'all_completed_and_audited':True,'all_gameplay_fields_and_final_hashes_equal':True,'excluded':sorted(ignored)},'mixed':x,'mixed_complete_json_equal':True,'hash_seeds':[0,987],'mixed_executions_including_replay':40,'original_progress':{'closed':30,'total':50,'percent':60,'open':20},'remaining':'CV-PERSISTENCE, BATTLE-RAMPAGE-VICTIM, BE-09 and the NPC Intimidate targeting lead remain open'}
Path('/tmp/fs-shouts-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':source,'new_tests':35,'targeted':120,'bots_equal':10,'mixed_equal':True,'hard_findings':x['hard_findings'],'partials':x['partial'],'human_turns':x['human_turns'],'event_turns':x['event_turns'],'events_ok':x['events_ok'],'protected':len(protected)}))
