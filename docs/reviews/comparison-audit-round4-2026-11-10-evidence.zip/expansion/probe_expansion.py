"""Round-four audit witnesses. Assertions describe observed defects, not desired rules.
Run from the audited repository with PYTHONPATH=$PWD python /path/to/probe_expansion.py.
Each fixture uses untouched Ariovistus scenario pieces (seed 317). Only controller
configuration and current/next Event identity are selected for a human Event.
"""
import json
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, get_available
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT
from fs_bot.engine.moves import validate_player_action
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import validate_state, check_structural_integrity
from fs_bot.tools.seat_session import validate_response, fingerprint, board_copy


def board(card):
    state = setup_scenario(rc.SCENARIO_ARIOVISTUS, seed=317)
    state['non_player_factions'] = set()
    state['current_card'], state['next_card'] = card, 'A67'
    assert validate_state(state) == []
    assert check_structural_integrity(state) == []
    return state


def action(card, params):
    return {'command': rc.FIRST_DID_EVENT, 'regions': [], 'sa': 'No SA', 'sa_regions': [],
            'details': {'card_id': card, 'text_preference': rc.EVENT_UNSHADED,
                        'event_params': params}}


def execute(state, card, actor, params):
    plan = action(card, params)
    response = {'action': ACTION_EVENT, 'player_action': plan}
    request = {'kind': 'turn', 'faction': actor, 'options': [ACTION_EVENT]}
    before = fingerprint(board_copy(state))
    accepted = validate_response(state, request, response)
    ok, preview = validate_player_action(state, actor, plan)
    assert fingerprint(board_copy(state)) == before
    assert accepted == response and ok and preview['executed']
    live = execute_decision(state, actor, accepted)
    assert live['executed'], live
    assert validate_state(state) == []
    assert check_structural_integrity(state) == []
    return {'durable_accepted': True, 'preview_accepted': ok, 'executed': live['executed'],
            'state_validation': [], 'structural_validation': []}


def abatis():
    results = []
    for label, params in [('missing_target', {}), ('wrong_target', {'region': rc.PROVINCIA}),
                          ('legal_target', {'region': rc.AEDUI_REGION})]:
        state = board('A64')
        assert count_pieces(state, rc.AEDUI_REGION, rc.AEDUI, rc.WARBAND) == 2
        assert not count_pieces(state, rc.PROVINCIA, rc.AEDUI, rc.WARBAND)
        result = execute(state, 'A64', rc.AEDUI, params)
        markers = [region for region, values in state['markers'].items()
                   if values.get(rc.MARKER_ABATIS) == rc.AEDUI]
        assert markers == ([rc.AEDUI_REGION] if label == 'legal_target' else [])
        results.append(dict(case=label, params=params, eligible_warbands=2,
                            abatis_regions=markers, **result))
    return results


def bellovaci():
    results = []
    for owner, kind in [(rc.ROMANS, rc.WARBAND), (rc.AEDUI, rc.AUXILIA),
                         (rc.ROMANS, rc.AUXILIA), (rc.AEDUI, rc.WARBAND)]:
        state = board('A69')
        params = {'ally_faction': rc.ROMANS, 'piece_faction': owner, 'piece_type': kind}
        troops_before = {rc.ROMANS: count_pieces(state, rc.ATREBATES, rc.ROMANS, rc.AUXILIA),
                         rc.AEDUI: count_pieces(state, rc.ATREBATES, rc.AEDUI, rc.WARBAND)}
        enemy_before = count_pieces(state, rc.ATREBATES, rc.BELGAE, rc.WARBAND)
        ally_before = state['tribes'][rc.TRIBE_BELLOVACI]['allied_faction']
        available = {rc.ROMANS: get_available(state, rc.ROMANS, rc.AUXILIA),
                     rc.AEDUI: get_available(state, rc.AEDUI, rc.WARBAND)}
        assert min(available.values()) >= 4
        result = execute(state, 'A69', rc.ROMANS, params)
        placed = {rc.ROMANS: count_pieces(state, rc.ATREBATES, rc.ROMANS, rc.AUXILIA) - troops_before[rc.ROMANS],
                  rc.AEDUI: count_pieces(state, rc.ATREBATES, rc.AEDUI, rc.WARBAND) - troops_before[rc.AEDUI]}
        legal = (owner, kind) in [(rc.ROMANS, rc.AUXILIA), (rc.AEDUI, rc.WARBAND)]
        assert sum(placed.values()) == (4 if legal else 0)
        assert state['tribes'][rc.TRIBE_BELLOVACI]['allied_faction'] == rc.ROMANS
        removed = enemy_before - count_pieces(state, rc.ATREBATES, rc.BELGAE, rc.WARBAND)
        assert removed == min(4, enemy_before)
        results.append(dict(case='legal_pair' if legal else 'impossible_pair', params=params,
                            valid_mobile_available=available, mobile_placed=placed,
                            belgic_warbands_removed=removed, bellovaci_before=ally_before,
                            bellovaci_after=state['tribes'][rc.TRIBE_BELLOVACI]['allied_faction'], **result))
    return results


if __name__ == '__main__':
    print(json.dumps({'EX4-01': abatis(), 'EX4-02': bellovaci()}, indent=2))
