"""Read-only audit probes; run from fs-bot with its audited interpreter.

These intentionally assert current observed behavior, not desired rules.
No repository files are changed. Initialized scenario states and piece helpers
are used; isolated interlude helpers are entered at their documented stage.
"""
import contextlib
import copy
import inspect
import io
import json
import tempfile
from pathlib import Path
from types import SimpleNamespace

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import (count_pieces, count_pieces_by_state, flip_piece,
                                 get_leader_in_region, place_piece, find_leader)
from fs_bot.board.control import refresh_all_control
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import validate_state
from fs_bot.state.serialize import load_game, encode, decode
from fs_bot.cli.display import HumanTurnDisplay
from fs_bot.cli.human_plan import _maybe_collect_transfer
from fs_bot.commands.transfer import transfer_resources
from fs_bot.engine.quarters import preview_relocations, validate_quarters_plan
from fs_bot.engine.interlude import (_adjust_german_forces, _cisalpina_relocation,
                                    run_interlude)
from fs_bot.engine.winter import run_winter_round
from fs_bot.engine.game_engine import _action_transaction
from fs_bot.tools.seat_session import SeatSession, DecisionPending, board_copy, validate_response
from fs_bot.tools import llm_seat


def state(scenario, seat=rc.ROMANS, seed=17):
    result = setup_scenario(scenario, seed=seed)
    from fs_bot.engine.game_engine import get_sop_factions
    result['non_player_factions'] = set(get_sop_factions(result)) - {seat}
    assert not validate_state(result)
    return result


def session(st, seat):
    result = SeatSession(st, {'seat': seat}, [], HumanTurnDisplay(io.StringIO()))
    st['decision_agent'] = result.reactive
    return result


def transaction(ss, function):
    def driver(*args):
        raise AssertionError('This probe does not call a turn driver')
    driver.transaction_checkpoint = ss.checkpoint
    driver.transaction_restore = ss.restore
    with _action_transaction(ss.state, driver):
        return function(ss.state)


out = {}

# A single Belgae human seat is explicit in the durable frontend's own init.
with tempfile.TemporaryDirectory() as tmp:
    args = SimpleNamespace(dir=tmp, scenario=rc.SCENARIO_GREAT_REVOLT,
                           seat=rc.BELGAE, seed=17, card_edition='legacy',
                           diviciacus_option=False)
    with contextlib.redirect_stdout(io.StringIO()):
        llm_seat.cmd_init(args)
    st, meta, _ = load_game(str(Path(tmp) / 'save.json'), validate=True)
    leader_region = find_leader(st, rc.BELGAE)
    out['great_revolt_single_belgae_seat'] = {
        'seat': meta['seat'], 'region': leader_region,
        'leader': get_leader_in_region(st, leader_region, rc.BELGAE),
        'expected_leader': rc.AMBIORIX, 'validation_errors': validate_state(st)}
    assert out['great_revolt_single_belgae_seat']['leader'] == rc.SUCCESSOR

# A1.5.2 forbids Arverni as Resource recipient in expansion scenarios.
st = state(rc.SCENARIO_ARIOVISTUS)
before = dict(st['resources'])
result = transfer_resources(st, rc.ROMANS, rc.ARVERNI, 3)
out['arverni_transfer'] = {'result': result, 'before': before,
                           'after': dict(st['resources']),
                           'validation_errors': validate_state(st)}
assert st['resources'][rc.ARVERNI] == 3
st = state(rc.SCENARIO_ARIOVISTUS, seat=rc.AEDUI)
plan = {'command': 'Rally', 'regions': [rc.AEDUI_REGION], 'sa': 'No SA',
        'sa_regions': [], 'details': {
            'rally_plan': {'citadels': [], 'allies': [], 'warbands': [rc.AEDUI_REGION]},
            'transfers': [{'to': rc.ARVERNI, 'amount': 3}]}}
response = validate_response(st, {'kind': 'turn', 'faction': rc.AEDUI,
                                 'options': ['command'], 'position': '1st_eligible'},
                             {'action': 'command', 'player_action': plan})
from fs_bot.engine.execute import execute_decision
result = execute_decision(st, rc.AEDUI, response)
out['arverni_transfer_durable_contract'] = {
    'validated_response': response, 'execution': result,
    'validation_errors': validate_state(st)}
assert result['executed'] and result['transfers'][0]['given'] == 3
menu = io.StringIO()
st = state(rc.SCENARIO_ARIOVISTUS)
st['resources'][rc.ROMANS] = 20
action = _maybe_collect_transfer(st, rc.ROMANS, {}, io.StringIO('y\n1\n12\n'), menu)
assert action['details']['transfers'] == [{'to': rc.ARVERNI, 'amount': 12}]
out['transfer_cli'] = {'plan': action, 'menu': menu.getvalue(),
                       'offers_13': '13) 13' in menu.getvalue()}

# Even when a Revealed Warband is present, tuple-count movement takes Hidden.
st = state(rc.SCENARIO_GREAT_REVOLT, seat=rc.BELGAE)
place_piece(st, rc.ATREBATES, rc.BELGAE, rc.WARBAND, 5)
flip_piece(st, rc.MORINI, rc.BELGAE, rc.WARBAND, 1,
           from_state=rc.HIDDEN, to_state=rc.REVEALED)
refresh_all_control(st)
assert not validate_state(st)
moves = [(rc.WARBAND, rc.MORINI, rc.ATREBATES, 1)]
assert not validate_quarters_plan(st, {rc.BELGAE: moves}, faction=rc.BELGAE)
after = preview_relocations(st, rc.BELGAE, moves)
unsupported = [(rc.WARBAND, rc.MORINI, rc.ATREBATES, 1, rc.REVEALED)]
out['quarters_visibility'] = {
    'origin_before': {p: count_pieces_by_state(st, rc.MORINI, rc.BELGAE, rc.WARBAND, p)
                      for p in (rc.HIDDEN, rc.REVEALED)},
    'origin_after': {p: count_pieces_by_state(after, rc.MORINI, rc.BELGAE, rc.WARBAND, p)
                     for p in (rc.HIDDEN, rc.REVEALED)},
    'explicit_visibility_errors': validate_quarters_plan(st, {rc.BELGAE: unsupported}, faction=rc.BELGAE),
    'validation_errors': validate_state(after)}
assert out['quarters_visibility']['origin_after'] == {rc.HIDDEN: 2, rc.REVEALED: 1}

# German player has no decision before its forced Interlude reductions.
st = state(rc.SCENARIO_GALLIC_WAR, seat=rc.GERMANS)
ss = session(st, rc.GERMANS)
before_map = sum(count_pieces(st, r, rc.GERMANS, rc.WARBAND) for r in st['spaces'])
result = transaction(ss, _adjust_german_forces)
ss.finish()
out['interlude_german_adjustments'] = {
    'result': result, 'warbands_before': before_map,
    'warbands_after': sum(count_pieces(st, r, rc.GERMANS, rc.WARBAND) for r in st['spaces']),
    'pending': ss.data['pending'], 'journal': ss.data['journal'],
    'validation_errors': validate_state(st)}
assert not ss.data['pending'] and not ss.log

# Cisalpina removal is automatic even though the Roman can relocate to Home.
st = state(rc.SCENARIO_GALLIC_WAR)
place_piece(st, rc.CISALPINA, rc.ROMANS, rc.AUXILIA, 1)
assert not validate_state(st)
ss = session(st, rc.ROMANS)
before_available = st['available'][rc.ROMANS][rc.AUXILIA]
result = transaction(ss, _cisalpina_relocation)
ss.finish()
out['interlude_cisalpina'] = {
    'result': result, 'pending': ss.data['pending'], 'accepted_choices': len(ss.log),
    'available_auxilia_increase': st['available'][rc.ROMANS][rc.AUXILIA] - before_available,
    'validation_errors': validate_state(st)}
assert not ss.data['pending'] and not ss.log

# All Interlude Roman options run to completion without any durable decision.
st = state(rc.SCENARIO_GALLIC_WAR)
st['winter_count'] = 3
tribe = next(t for t, x in st['tribes'].items() if not x.get('allied_faction') and not x.get('status'))
st['tribes'][tribe]['status'] = rc.MARKER_DISPERSED
assert not validate_state(st)
ss = session(st, rc.ROMANS)
result = transaction(ss, run_interlude)
ss.finish()
out['interlude_roman_options'] = {
    'britannia': result['step3_britannia'],
    'dispersed_tribe': tribe, 'dispersed_after': st['tribes'][tribe]['status'],
    'preserved_tribe': result['step5_spring']['roman_dispersed_kept'],
    'pending': ss.data['pending'], 'accepted_choices': len(ss.log),
    'validation_errors': validate_state(st)}
assert result['step3_britannia']['decision_source'] == 'np'
assert result['step3_britannia']['conducted']
assert not ss.data['pending'] and not ss.log

# First Pax Winter offers Quartering but no Roman Harvest placement request.
st = state(rc.SCENARIO_PAX_GALLICA)
st['current_card'] = st['current_card_id'] = rc.WINTER_CARD
ss = session(st, rc.ROMANS)
try:
    transaction(ss, run_winter_round)
    raise AssertionError('Expected human Quarters')
except DecisionPending:
    pending = ss.data['pending']
    assert decode(pending['request'])['kind'] == 'quarters_plan'
ss.import_inbox({'decision_id': pending['id'], 'response': {'use_default': True}})
result = transaction(ss, run_winter_round)
ss.finish()
out['pax_harvest'] = {
    'placement': result['phases']['harvest_belgica_legions'],
    'human_decision_kinds': [e.get('reactive') for e in ss.log],
    'pending': ss.data['pending'], 'validation_errors': validate_state(st)}
assert out['pax_harvest']['human_decision_kinds'] == ['quarters_plan']

# Record the exact setup contract, including the absence of optional selectors.
out['setup_signature'] = str(inspect.signature(setup_scenario))

# Representative game-run Battle phases preserve defender ownership and pause.
from fs_bot.engine.germans_battle import germans_phase_battle
from fs_bot.engine.arverni_phase import _arverni_phase_battle
reactions = []
for scenario, seat, attacker, region in [
    (rc.SCENARIO_GREAT_REVOLT, rc.BELGAE, rc.GERMANS, rc.MORINI),
    (rc.SCENARIO_ARIOVISTUS, rc.ROMANS, rc.ARVERNI, rc.VENETI),
]:
    st = state(scenario, seat=seat)
    if attacker == rc.GERMANS:
        place_piece(st, region, attacker, rc.WARBAND, 5)
        function = germans_phase_battle
    else:
        place_piece(st, region, attacker, rc.WARBAND, 3)
        place_piece(st, region, seat, rc.AUXILIA, 2, piece_state=rc.REVEALED)
        function = lambda board: _arverni_phase_battle(board, region, seat)
    assert not validate_state(st)
    ss = session(st, seat)
    before = encode(board_copy(st))
    try:
        transaction(ss, function)
        raise AssertionError('Expected defender reaction')
    except DecisionPending:
        request = decode(ss.data['pending']['request'])
        assert request['faction'] == seat
        assert encode(board_copy(st)) == before
        reactions.append({'scenario': scenario, 'seat': seat,
                          'kind': request['kind'], 'unchanged_when_pending': True})
out['game_run_phase_reactions'] = reactions
print(json.dumps(out, indent=2, sort_keys=True))
