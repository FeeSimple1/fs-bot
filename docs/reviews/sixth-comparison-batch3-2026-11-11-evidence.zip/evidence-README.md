# Sixth comparison repair Batch 3 evidence

The parent is `9ab48e08fd42e040bd8857d96ff15b540a34e08b`. The tested
Python source and accepted results are in `final/source.json` and
`final/summary.json`. `SHA256SUMS.json` covers every other archive member.

Run the following from the repaired checkout with Python 3.12, pytest and
pytest-xdist. Use fresh output paths.

```sh
PYTHONHASHSEED=0 python -m pytest -q -n 5 --dist loadfile --tb=short --show-capture=no --junitxml=pytest.xml
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 3 --out bots-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 41-44 --card-edition second-edition --workers 2 --out bots-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
```

The 100 reviewed records in `final/balance-baseline.json` passed the
15-point band. The parent batch and the reviewed baseline have their own
recorded outcomes.

The new cases can be rerun on the parent to reproduce 18 failures and
seven passing controls.

```sh
PYTHONPATH=. PYTHONHASHSEED=0 python -m pytest -q --tb=short /path/to/evidence/test_parent_battle.py
```

The earlier audited game records are in the Batch 2 evidence archive under
`final/bots-legacy` and `final/bots-second`. Each replay checks the source
hash, winner, game length and final board digest. Generate each trace in
its matching checkout, then compare the traces in the repaired checkout.

```sh
PYTHONPATH=. PYTHONHASHSEED=0 python /path/to/evidence/trace_battles.py record /path/to/evidence/trace-parent-input.json /path/to/parent-trace.json
PYTHONPATH=. PYTHONHASHSEED=0 python /path/to/evidence/trace_battles.py record /path/to/evidence/trace-repaired-input.json /path/to/repaired-trace.json
PYTHONPATH=. python /path/to/evidence/trace_battles.py compare /path/to/parent-trace.json /path/to/repaired-trace.json /path/to/first-divergences.json
PYTHONPATH=. python /path/to/evidence/verify_results.py /path/to/batch2-evidence/final
```

`final/paired-outcomes.json` covers all 120 game keys and
`final/first-divergences.json` records the first changed Battle calls
for all eight replays, including their shared starting board and RNG digests.
