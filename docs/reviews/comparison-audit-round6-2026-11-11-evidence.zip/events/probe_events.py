"""Audit-six witnesses. Assertions intentionally describe defects, not correct rules.
Run with PYTHONPATH=<fs-bot-root> Python against audited commit 86fb0c2.
"""
from copy import deepcopy
import json
from fs_bot import rules_consts as rc
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import build_initial_state,validate_state,check_structural_integrity
from fs_bot.state.serialize import encode
from fs_bot.board.pieces import place_piece,remove_piece,count_pieces,find_leader,get_leader_in_region,get_available
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.bots.bot_common import should_decline_event
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT

KEYS=('spaces','tribes','available','resources','eligibility','capabilities','capability_owners','markers','event_modifiers','fallen_legions','senate','legions_track','removed_legions','forced_ineligible','stay_eligible')
def effects(s): return {k:encode(s.get(k,{})) for k in KEYS}
def clean(s):
 assert count_pieces(s,rc.PROVINCIA,rc.ROMANS,rc.FORT)==1
 assert validate_state(s)==[],validate_state(s)
 assert check_structural_integrity(s)==[],check_structural_integrity(s)
def board(scenario=rc.SCENARIO_GREAT_REVOLT,card=57):
 s=build_initial_state(scenario,seed=1)
 place_piece(s,rc.PROVINCIA,rc.ROMANS,rc.FORT)
 s['non_player_factions']=set()
 s.update(current_card=card,current_card_id=card,can_play_event=True)
 for f in s['resources']:
  if f != rc.ARVERNI or scenario not in rc.ARIOVISTUS_SCENARIOS:s['resources'][f]=10
 clean(s);return s
def play(s,f,card,params,shaded=True):
 s['current_card']=s['current_card_id']=card
 r=execute_decision(s,f,{'action':ACTION_EVENT,'player_action':{'command':'Event','details':{'card_id':card,'text_preference':rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,'event_params':params}}})
 assert r['executed'] and not r.get('errors'),r
 clean(s);return r
def bot(s,f,card):
 s['current_card']=s['current_card_id']=card;s['can_play_event']=True
 a=dispatch_bot_turn(s,f)
 assert a['command']=='Event',a
 before=effects(s)
 r=execute_decision(s,f,{'action':ACTION_EVENT,'bot_action':a})
 assert r['executed'] and not r.get('errors'),r
 clean(s)
 return {'action':a,'execution':r,'effects_unchanged':effects(s)==before}
def missing_prefixes():
 rows=[]
 for omitted in ('removal','ally','both'):
  s=board();assert _ally_tribe(s,rc.TRIBE_CATUVELLAUNI,rc.ROMANS);clean(s)
  p={'warband_faction':rc.BELGAE,'warband_count':1}
  if omitted not in ('removal','both'):p['removal']={'type':'ally','tribe':rc.TRIBE_CATUVELLAUNI}
  if omitted not in ('ally','both'):p.update(ally_tribe=rc.TRIBE_CATUVELLAUNI,ally_faction=rc.BELGAE)
  control=deepcopy(s)
  r=play(s,rc.BELGAE,57,p)
  assert count_pieces(s,rc.BRITANNIA,rc.BELGAE,rc.WARBAND)==1
  expected_owner=rc.ROMANS if omitted in ('removal','both') else None
  assert s['tribes'][rc.TRIBE_CATUVELLAUNI]['allied_faction']==expected_owner
  full=dict(p,removal={'type':'ally','tribe':rc.TRIBE_CATUVELLAUNI},ally_tribe=rc.TRIBE_CATUVELLAUNI,ally_faction=rc.BELGAE)
  cr=play(control,rc.BELGAE,57,full)
  assert control['tribes'][rc.TRIBE_CATUVELLAUNI]['allied_faction']==rc.BELGAE
  rows.append({'omitted':omitted,'accepted':r,'observed_ally':expected_owner,'placed_warbands':1,'complete_control_ally':rc.BELGAE,'control':cr})
 return rows

def missing_np_plans():
 rows=[]
 # Genuine untouched setup, with current Event selected and its actor available.
 s=setup_scenario(rc.SCENARIO_ARIOVISTUS,seed=1)
 s['non_player_factions']={rc.ROMANS,rc.GERMANS,rc.AEDUI,rc.BELGAE}
 clean(s);c=deepcopy(s)
 result=bot(s,rc.GERMANS,'A35');assert result['effects_unchanged']
 # A legal full grant on exactly the same physical starting position.
 dest=rc.TREVERI
 assert count_pieces(c,dest,rc.GERMANS,rc.SETTLEMENT)==0
 before=(get_available(c,rc.GERMANS,rc.WARBAND),get_available(c,rc.GERMANS,rc.SETTLEMENT))
 cr=play(c,rc.GERMANS,'A35',{'placements':[{'region':dest,'piece_type':rc.WARBAND,'count':8},{'region':dest,'piece_type':rc.SETTLEMENT}]})
 assert (get_available(c,rc.GERMANS,rc.WARBAND),get_available(c,rc.GERMANS,rc.SETTLEMENT))==(before[0]-min(8,before[0]),before[1]-1)
 rows.append({'case':'A35 German shaded','bot':result,'legal_full_grant':cr,'control_placements':{'warbands':min(8,before[0]),'settlements':1}})
 # Roman A35 has a full-number directive. The bare default instead selects
 # Warbands for the Roman owner and silently places only the Ally.
 s=board(rc.SCENARIO_ARIOVISTUS,'A35');s['non_player_factions']={rc.ROMANS,rc.GERMANS,rc.AEDUI,rc.BELGAE};c=deepcopy(s)
 result=bot(s,rc.ROMANS,'A35')
 assert s['tribes'][rc.TRIBE_TREVERI]['allied_faction']==rc.ROMANS
 assert count_pieces(s,rc.TREVERI,rc.ROMANS,rc.AUXILIA)==0
 cr=play(c,rc.ROMANS,'A35',{'ally_faction':rc.ROMANS,'piece_faction':rc.ROMANS,'piece_type':rc.AUXILIA,'count':4},shaded=False)
 assert count_pieces(c,rc.TREVERI,rc.ROMANS,rc.AUXILIA)==4
 rows.append({'case':'A35 Roman unshaded','bot':result,'observed_auxilia':0,'control_auxilia':4,'legal_full_grant':cr})
 # A60's beneficiary is prescribed, so all five replacement gains are legal.
 s=board(rc.SCENARIO_ARIOVISTUS,'A60');s['non_player_factions']={rc.ROMANS,rc.GERMANS,rc.AEDUI,rc.BELGAE}
 assert _ally_tribe(s,rc.TRIBE_REMI,rc.ROMANS)
 place_piece(s,rc.ATREBATES,rc.ROMANS,rc.AUXILIA,4)
 clean(s);c=deepcopy(s)
 result=bot(s,rc.BELGAE,'A60');assert result['effects_unchanged']
 cr=play(c,rc.BELGAE,'A60',{'replacements':[{'from_type':rc.ALLY,'tribe':rc.TRIBE_REMI}]+[{'from_type':rc.AUXILIA,'piece_state':rc.HIDDEN}]*4})
 assert c['tribes'][rc.TRIBE_REMI]['allied_faction']==rc.BELGAE
 assert count_pieces(c,rc.ATREBATES,rc.BELGAE,rc.WARBAND)==4
 assert count_pieces(c,rc.ATREBATES,rc.ROMANS,rc.AUXILIA)==0
 rows.append({'case':'A60 Belgic shaded','bot':result,'control_replacements':5,'legal_full_grant':cr})
 return rows

def ineffective_ambiorix():
 # §8.1.1's own printed example, in the real setup position.
 s=setup_scenario(rc.SCENARIO_PAX_GALLICA,seed=1)
 s['non_player_factions']={rc.ROMANS,rc.ARVERNI,rc.AEDUI,rc.BELGAE};clean(s)
 assert get_leader_in_region(s,find_leader(s,rc.BELGAE),rc.BELGAE)==rc.AMBIORIX
 c=deepcopy(s)
 assert not should_decline_event(s,56,rc.BELGAE)
 result=bot(s,rc.BELGAE,56);assert result['effects_unchanged']
 # Removing the named Leader makes the exact same Event genuinely effective.
 origin=find_leader(c,rc.BELGAE);remove_piece(c,origin,rc.BELGAE,rc.LEADER);clean(c)
 control=bot(c,rc.BELGAE,56);assert not control['effects_unchanged']
 assert get_leader_in_region(c,find_leader(c,rc.BELGAE),rc.BELGAE)==rc.AMBIORIX
 # Actual intended fallback is available from the original board.
 fallback=deepcopy(s);fallback['can_play_event']=False
 a=dispatch_bot_turn(fallback,rc.BELGAE)
 assert a['command'] not in ('Event','Pass'),a
 return {'bot':result,'named_leader_present':True,'missing_leader_control':control,'available_flowchart_fallback':a}

if __name__=='__main__':
 print(json.dumps({'BE6-events-01':missing_prefixes(),'NP6-events-01':missing_np_plans(),'NP6-events-02':ineffective_ambiorix()},indent=2,sort_keys=True))
