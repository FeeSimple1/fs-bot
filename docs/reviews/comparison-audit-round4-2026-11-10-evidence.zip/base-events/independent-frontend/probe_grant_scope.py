# Independent reviewer copy includes permanent Provincia Fort, per Chapter1 1.4.2.
import copy,json,sys
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from fs_bot import rules_consts as r
from fs_bot.state.state_schema import build_initial_state,validate_state,check_structural_integrity
from fs_bot.board.pieces import place_piece,count_pieces
from fs_bot.state.serialize import encode
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.free_actions import validate_free_action_response
from fs_bot.engine import game_engine as ge

def state():
 s=build_initial_state(r.SCENARIO_GREAT_REVOLT,seed=1)
 s.update(current_card=9,current_card_id=9,non_player_factions=set())
 place_piece(s,r.PROVINCIA,r.ROMANS,r.FORT)
 place_piece(s,r.PROVINCIA,r.ROMANS,r.AUXILIA,3)
 place_piece(s,r.CARNUTES,r.ROMANS,r.AUXILIA,3)
 assert validate_state(s)==check_structural_integrity(s)==[]
 return s

def plan(shadow=False,legal=False):
 scout={'auxilia_moves':[{'from_region':r.SEQUANI if legal else r.CARNUTES,'to_region':r.MANDUBII if legal else r.VENETI,'count':1,'piece_state':r.HIDDEN}],'scout_targets':[]}
 details={'disperse_tribes':{r.SEQUANI:[]},'scout_plan':scout}
 if shadow:details.update(scout_plan=None,sa_details={'scout_plan':scout})
 return {'command':r.CMD_SEIZE,'regions':[r.SEQUANI],'sa':r.SA_SCOUT,'sa_timing':'after','details':details}

records=[]
for label,shadow,legal in [('canonical_outside',False,False),('shadow_outside',True,False),('legal_control',False,True)]:
 s=state();before=encode(s);requests=[]
 def agent(st,f,request):
  if request['kind']!='free_action':return None
  requests.append(copy.deepcopy(request))
  if request.get('request_type')=='mons_cevenna_march':return {'origin':r.PROVINCIA,'destination':r.SEQUANI,'group':{r.AUXILIA:2}}
  assert request['request_type']=='event_command'
  chosen=plan(shadow,legal)
  error=validate_free_action_response(st,f,request,chosen)
  requests[-1]['observed_validation_error']=error
  return chosen
 s['decision_agent']=agent
 event={'action':ge.ACTION_EVENT,'player_action':{'command':'Event','sa':'No SA','details':{'card_id':9}}}
 try:result=execute_decision(s,r.ROMANS,event);error=None
 except ValueError as e:result=None;error=str(e)
 stripped={k:v for k,v in s.items() if k!='decision_agent'}
 assert validate_state(s)==check_structural_integrity(s)==[]
 row={'case':label,'error':error,'result':result,'requests':requests,'unchanged':encode(stripped)==before,'auxilia':{z:count_pieces(s,z,r.ROMANS,r.AUXILIA) for z in [r.PROVINCIA,r.SEQUANI,r.CARNUTES,r.VENETI,r.MANDUBII]}}
 if label=='canonical_outside':assert result['rejected'] and row['unchanged']
 else:
  assert result['executed'],result
  assert row['auxilia'][r.MANDUBII if legal else r.VENETI]==1,row
 records.append(row)
out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True);(out/'observations.json').write_text(json.dumps(records,indent=2,default=str));print(json.dumps(records,indent=2,default=str))
