# Twelfth audit bot decisions lane

Audited Falling Sky `1563e41d84f61dfce43ce4008106eca2a1639aed` against Liberty or Death `2991ea279062773548ec390a1da75f3e85381702`. Source conclusions use the supplied Falling Sky references and respect the thirteen adopted provisional rulings.

Two medium-priority findings are confirmed by 24 directed executions. The fixture and output are deterministic across hash seeds 0 and 987. The probe changes no production files.

## NP12-01 — Aedui spreading March collapses three one-Warband groups into one large move

Section 8.6.5 first sends one Hidden Aedui from one origin into each of up to three eligible adjacent Regions, while keeping one Warband and existing Aedui Control at the origin. On the witness board four Hidden Aedui at Mandubii can send one each to the three destinations already chosen by their own planner, retaining one. No Warbands remain movable for an additional Control step.

Public dispatch selects March and spread_destinations Atrebates, Treveri and Carnutes. Public execution sends all three movable Warbands only to Atrebates. Treveri and Carnutes remain empty. All four natural command-only cases (two scenarios, two seeds) do this. Four matched explicit three-group player controls place one in each destination for the same two-Resource origin charge and retain Mandubii Control.

node_a_march records destinations without concrete one-Warband groups. The shared plan_expand_march_moves combines Control and spread destinations, visits each origin once, chooses one nearest destination and sends every Warband beyond the leave-behind. Its nonempty-effect check only asks whether any group can move, so the malformed allocation passes.

Four explicit three-group controls use normal execute_decision player_action, charge exactly two Resources once at Devastated Mandubii, preserve one origin Warband and Control, and add Hidden Aedui plus Control at all three destinations. Every probe has clean pre/post census and structural checks. Dispatch preserves board and RNG on these fixtures. All 24 output records are identical across hash seeds 0 and 987.

Prior comparative ledgers through round11 inspected. NP11-02 concerns a German expansion advance and was repaired using explicit groups. Existing Aedui unit tests inspect node plans, including spread_destinations, without asserting the three resulting arrivals. NP8-02 addressed Aedui Rally ability timing. FE6-02 concerned human Enlist split German March. This newly proved ordinary Aedui allocation path is distinct.

Sparse canonical mid-year boards initialized through build_initial_state, not untouched setup_scenario boards or a reconstructed full game history. The single Devastated marker represents a prior Arverni action. The probe does not invoke Winter victory or estimate natural frequency/balance. No Event, terminal, saved-session, expansion Leader or human Supply-disagreement claims. No independent allegation about additional Control movement, Scouted spreading, Diviciacus ordering or other faction expander consumers is counted.

Build executable Aedui groups in printed phase order on a projected board. Reserve one eligible Hidden-arrival Warband per spread destination, retain source Control and leave-behinds, then compute the additional minimum Control move from remaining unmoved pieces. Preserve origin billing and separate expansion Leader rules. Add result-level regressions rather than asserting only planner destination lists.

Sources and code are enumerated with line numbers in `findings.json`.

## NP12-02 — Aedui March drops the post-Command Trade opportunity when its initial Suborn choice is empty

Section 8.6.5 requires Trade or Suborn after March, following the current-state test in 8.6.3. Here March reduces Aedui Resources from 10 to 8, enabling the below-ten Trade condition. Non-player Roman agreement and the resulting Aedui Control yield twelve Resources under 4.4.1, producing 20 Resources after the demonstrated move.

With only Revealed Aedui present, public dispatch emits March with No SA and translates it as command-only. March executes and pays two Resources, then stops at eight Resources. The current ordinary Trade chooser returns Trade worth twelve. Changing only the preselected SA label to Suborn opens existing live rederivation, which itself chooses Trade and produces twenty Resources. Starting with Hidden Aedui also naturally reaches this correct live rederivation.

node_a_march calls only _determine_suborn_sa on the pre-March board. It carries no deferred Aedui post-Command intent when the returned label is No SA. The translator therefore chooses command-only. _execute_sa_confirmed returns on No SA, before the existing Aedui current-state Trade/Suborn branch can run.

Four source-required SA-label controls retain exact March moves and allow existing live rederivation to choose actual Trade, yielding twelve Resources. Four natural Hidden-force positive controls reach the same Trade without label changes. Four command-only controls correctly execute only the March at two Resources. Ordinary Trade forecasting and dispatch are board/RNG pure in these fixtures. All before/after census and structural checks pass.

Newly demonstrated ordinary Aedui March consumer of the post-Command opportunity defect class. NP8-02 repaired Aedui Rally, NP9-02 Arverni Rally/Belgic Raid, NP10-01 Arverni March and NP11-01 Belgic March. Those repair paths remain covered. This finding does not reopen their repaired consumers.

Sparse canonical mid-year boards initialized through build_initial_state, not untouched setup_scenario boards or a reconstructed full game history. The single Devastated marker represents a prior Arverni action. The probe does not invoke Winter victory or estimate natural frequency/balance. No Event, terminal, saved-session, expansion Leader or human Supply-disagreement claims. This proof uses the existing movement result to isolate the missing SA. NP12-01 may change that board and Trade yield when repaired, so a repair regression should compute the correct post-March yield. The public natural failure alone establishes the bug. The label control is an explicit diagnostic, not a claimed unmodified dispatch.

Carry an authorized deferred Aedui post-March ability decision or reliably forecast the completed board. Reuse the existing current-state Trade-to-Suborn choice and actual Supply declarations even if no pre-Command Suborn exists. Preserve true command-only restrictions and apply Britannia exclusion to actual executed crossings.

Sources and code are enumerated with line numbers in `findings.json`.

## Coverage and rejected candidates

Read Aedui Rally previews, Raid targeting and Resource reservations, March planning and ability selection, Roman Recruit preview and Seize conditions, shared ability execution and generic March expansion. Compared LoD Patriot committed source accounting, one-piece spreading, explicit March execution and post-March activity sequencing. Searched the comparative finding ledgers through round11 and reviewed the current provisional register for prior coverage.

Aedui Rally already forecasts its retained placements and its former empty-SA boundary is repaired. Current Aedui Raid targeting shares the canonical target validator and reserves victim Resources across Regions. Roman Recruit previews the preceding Build/Scout and shares remaining Available pools and Resources. These inspected paths yielded no new confirmed defect. Additional possible Scouted-arrival and Diviciacus movement issues were observed during static reading but were not fully reproduced or counted.

The sparse fixtures are deliberately local. They establish mandatory movement allocation and post-Command opportunity failures without claiming normal encounter rates or exhaustive bot coverage.

## Reproduction

```sh
PYTHONHASHSEED=0 python probe_bots.py --repo /absolute/fs-bot > results.rerun.json
PYTHONHASHSEED=987 python probe_bots.py --repo /absolute/fs-bot > results.rerun987.json
cmp results.json results.rerun.json
cmp results.rerun.json results.rerun987.json
```
