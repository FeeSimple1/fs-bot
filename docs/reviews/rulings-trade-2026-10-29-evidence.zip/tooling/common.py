"""Read-only source guards for the 29 October rulings/Trade validation batch."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'fs-bot'
PYTHON = ROOT.parent / 'fs-test-venv/bin/python'
SCENARIOS = ('Pax Gallica?', 'Reconquest of Gaul', 'The Great Revolt',
             'Ariovistus', 'The Gallic War')
BASELINE_SHA = '815b6f363134159b4cf5772abd4dc76a5e8e0be8fd0bb852dc571390504814f5'
PARENT = '724af60017b4ba959d402168b238065b43f22708'
MATRIX = {'bot_games': 150, 'mixed_unique_cases': 20,
          'mixed_executions_with_replay': 80, 'census_unique_cases': 25,
          'census_executions': 50, 'hash_seeds': [0, 7]}


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_text())


def write_json(path, data, *, exclusive=False):
    with path.open('x' if exclusive else 'w') as stream:
        json.dump(data, stream, indent=2, sort_keys=True)
        stream.write('\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def source_files():
    return {str(p.relative_to(REPO)): sha(p.read_bytes())
            for p in sorted((REPO / 'fs_bot').rglob('*.py'))}


def digest():
    value = hashlib.sha256()
    for path in sorted((REPO / 'fs_bot').rglob('*.py')):
        value.update(str(path.relative_to(REPO)).encode() + b'\0' + path.read_bytes())
    return value.hexdigest()


def fixture_files():
    return {str(p.relative_to(REPO)): sha(p.read_bytes())
            for p in sorted((REPO / 'fs_bot/tests/fixtures').rglob('*'))
            if p.is_file() and p.suffix not in ('.py', '.pyc', '.pyo')
            and '__pycache__' not in p.parts}


def runtime_files():
    paths = [p for pattern in ('pyproject.toml', 'pytest.ini', 'setup.cfg',
                              'setup.py', 'tox.ini', 'requirements*.txt')
             for p in REPO.glob(pattern) if p.is_file()]
    return {str(p.relative_to(REPO)): sha(p.read_bytes()) for p in sorted(set(paths))}


def protected_files():
    paths = [REPO / 'fs_bot/rules_consts.py']
    paths.extend(p for p in (REPO / 'Reference Documents').rglob('*') if p.is_file())
    return {str(p.relative_to(REPO)): sha(p.read_bytes()) for p in sorted(paths)}


def identity():
    return {'source_sha256': digest(), 'commit': git('rev-parse', 'HEAD').decode().strip(),
            'dirty': bool(git('status', '--porcelain', '--untracked-files=no').strip()
                          or any(p.endswith('.py') for p in git(
                              'ls-files', '--others', '--exclude-standard', '-z',
                              '--', 'fs_bot').decode().split('\0')))}


def validate_current(expected_sha, freeze=None):
    """Raise on any source/data/protected drift; no baseline refresh escape."""
    start = read(ROOT / 'starting-source.json')
    current = identity()
    if current['commit'] != PARENT or start['commit'] != PARENT:
        raise ValueError('HEAD/starting-source differ from scoped parent724af60')
    if current['source_sha256'] != expected_sha:
        raise ValueError('live Python source differs from explicitly supplied digest')
    baseline = (REPO / 'fs_bot/tools/balance_baseline.json').read_bytes()
    if (sha(baseline) != BASELINE_SHA or start['balance_baseline_sha256'] != BASELINE_SHA
            or baseline != git('show', PARENT + ':fs_bot/tools/balance_baseline.json')):
        raise ValueError('original815b balance baseline changed')
    if protected_files() != start['protected_files']:
        raise ValueError('protected reference/constant bytes or inventory changed')
    if freeze:
        for label, actual in (('source_files', source_files()),
                              ('fixture_files', fixture_files()),
                              ('runtime_files', runtime_files())):
            if actual != freeze[label]:
                raise ValueError(label + ' changed from frozen inventory')
        if freeze['protected_files'] != start['protected_files']:
            raise ValueError('protected manifest changed')
        if freeze['source_sha256'] != expected_sha or freeze['commit'] != PARENT:
            raise ValueError('attempt identity differs from requested source/parent')
        for name, expected in freeze['tooling_files'].items():
            if sha((ROOT / name).read_bytes()) != expected:
                raise ValueError('validation tooling changed during prepared attempt: ' + name)
    return current


def snapshot_inventory(run, dirname, inventory):
    for name, expected in inventory.items():
        raw = (REPO / name).read_bytes()
        if sha(raw) != expected:
            raise ValueError('source changed while freezing: ' + name)
        destination = run / dirname / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)


def verify_snapshots(run, freeze):
    for label, dirname in (('source_files', 'python-source'),
                           ('fixture_files', 'fixture-source'),
                           ('protected_files', 'protected-source'),
                           ('runtime_files', 'runtime-source')):
        actual = {str(p.relative_to(run / dirname)): sha(p.read_bytes())
                  for p in sorted((run / dirname).rglob('*')) if p.is_file()}
        if actual != freeze[label]:
            raise ValueError('frozen bytes missing/changed: ' + label)


def prepare(run, expected_sha, jobs):
    source = validate_current(expected_sha)
    run.mkdir()  # Exclusive: every failed attempt remains untouched.
    start = read(ROOT / 'starting-source.json')
    freeze = {'recorded_utc': utc(), 'python': platform.python_version(),
              'python_executable': str(PYTHON), **source,
              'balance_baseline_sha256': BASELINE_SHA,
              'balance_band_exact': '3/20', 'balance_baseline_updated': False,
              'source_files': source_files(), 'fixture_files': fixture_files(),
              'protected_files': start['protected_files'], 'runtime_files': runtime_files(),
              'matrix': MATRIX, 'jobs': jobs}
    for label, folder in (('source_files', 'python-source'),
                          ('fixture_files', 'fixture-source'),
                          ('protected_files', 'protected-source'),
                          ('runtime_files', 'runtime-source')):
        snapshot_inventory(run, folder, freeze[label])
    baseline = (REPO / 'fs_bot/tools/balance_baseline.json').read_bytes()
    (run / 'balance-baseline.json').write_bytes(baseline)
    manifest = (REPO / 'fs_bot/tests/fixtures/compatibility_8ef88e2/manifest.json').read_bytes()
    (run / 'fixture-manifest.json').write_bytes(manifest)
    freeze['fixture_manifest_sha256'] = sha(manifest)
    freeze['source_snapshot'] = {'directory': 'python-source', 'complete': True,
                                 'files': len(freeze['source_files']), 'source_sha256': expected_sha}
    (run / 'git-status.txt').write_bytes(git('status', '--short'))
    (run / 'git-diff.patch').write_bytes(git('diff', '--binary', 'HEAD'))
    tooling = {p.name: sha(p.read_bytes()) for p in sorted(ROOT.glob('*.py'))}
    for name in tooling:
        destination = run / 'tooling' / name
        destination.parent.mkdir(exist_ok=True)
        destination.write_bytes((ROOT / name).read_bytes())
    freeze['tooling_files'] = tooling
    validate_current(expected_sha, freeze)
    verify_snapshots(run, freeze)
    write_json(run / 'source.json', source, exclusive=True)
    write_json(run / 'freeze.json', freeze, exclusive=True)
    write_json(run / 'prepared-only.json', {'recorded_utc': utc(),
               'status': 'No tests or games launched; awaiting explicit full-suite invocation.'}, exclusive=True)
    return freeze


def execute(run, name, argv, hash_seed, freeze):
    """Exclusive raw log/status capture with periodic source/data guards."""
    status_path = run / (name + '.status.json')
    log_path = run / (name + '.log')
    if status_path.exists() or log_path.exists():
        raise ValueError('refusing to overwrite existing result: ' + name)
    status = {'name': name, 'argv': argv, 'cwd': str(REPO),
              'environment': {'PYTHONHASHSEED': str(hash_seed), 'PYTHONUNBUFFERED': '1'},
              'started_utc': utc(), 'source_sha256_before': digest(),
              'exit_code': None, 'source_changed': False, 'launched': False}
    write_json(status_path, status, exclusive=True)
    started = time.monotonic()
    process = None
    try:
        validate_current(freeze['source_sha256'], freeze)
        with log_path.open('x') as output:
            process = subprocess.Popen(argv, cwd=REPO, env=dict(
                os.environ, PYTHONHASHSEED=str(hash_seed), PYTHONUNBUFFERED='1'),
                stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
            status.update(pid=process.pid, launched=True)
            write_json(status_path, status)
            while True:
                try:
                    status['exit_code'] = process.wait(timeout=15)
                    break
                except subprocess.TimeoutExpired:
                    validate_current(freeze['source_sha256'], freeze)
        validate_current(freeze['source_sha256'], freeze)
    except BaseException as exc:
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        status['exit_code'] = process.returncode if process is not None else 125
        status['error'] = repr(exc)
        status['source_changed'] = isinstance(exc, ValueError)
        status['interrupted'] = isinstance(exc, KeyboardInterrupt)
    status.update(ended_utc=utc(), duration_seconds=time.monotonic() - started,
                  source_sha256_after=digest())
    status['runner_exit_code'] = (125 if status.get('error') or status['source_changed']
                                  else status['exit_code'])
    write_json(status_path, status)
    print(f"{name}: exit={status['exit_code']} runner={status['runner_exit_code']} "
          f"freeze_ok={not status['source_changed']}", flush=True)
    return status
