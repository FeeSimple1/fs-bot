"""Malformed durable response escapes into raw fallback after NP Supply refusal.

The existing deterministic fixture starts a complete Great Revolt setup and
relocates pieces with helpers, creating two Aedui-controlled Recruit Regions.
No test functions run. Both structure and piece conservation are checked.
"""
import copy
import io
import json
from pathlib import Path

from fs_bot import rules_consts as rc
from fs_bot.cli.display import HumanTurnDisplay
from fs_bot.commands.rally import supply_agreement_scope
from fs_bot.engine.supply_reconsideration import reconsider
from fs_bot.engine.game_engine import _action_transaction
from fs_bot.state.serialize import decode, encode
from fs_bot.state.state_schema import validate_state, check_structural_integrity
from fs_bot.tools.seat_session import SeatSession, DecisionPending, board_copy
from fs_bot.tests.test_np_aedui_supply_action import _state, _recruit
from fs_bot.tests.test_supply_refusal_choices import _run_declining_timing


def session_for(state):
    assert not validate_state(state)
    assert not check_structural_integrity(state)
    session = SeatSession(state, {'seat': rc.ROMANS}, [], HumanTurnDisplay(io.StringIO()))
    state['decision_agent'] = session.reactive
    return session


bad = {'replacement': {'command': rc.CMD_RECRUIT, 'sa': 'No SA', 'details': [1]}}

# First demonstrate through actual complete Command execution: the same bad
# response no longer holds the original Supply reconsideration pending.
session = session_for(_state(5))
before = encode(board_copy(session.state))
try:
    _run_declining_timing(session)
except DecisionPending:
    pass
pending = copy.deepcopy(session.data['pending'])
assert decode(pending['request'])['kind'] == 'supply_refusal'
session.import_inbox({'decision_id': pending['id'], 'response': bad})
try:
    # Unlike the helper above, do not automatically answer a newly changed
    # optional window: inspect exactly where the actual Command stopped.
    from fs_bot.tests.test_supply_refusal_choices import _run
    _run(session)
except DecisionPending:
    pass
after_pending = session.data['pending']
assert after_pending['id'] == pending['id']
assert decode(after_pending['request'])['kind'] == 'voluntary_removal'
assert session.data['queue'][0]['response'] == bad
assert encode(board_copy(session.state)) == before

# Isolate the actual engine-authored request boundary. The same SeatSession
# callback is used; a completed reconsideration must not silently default.
isolated = session_for(_state(5))
isolated.import_inbox([{'response': bad}])
isolated.checkpoint()
with supply_agreement_scope(isolated.state):
    returned = reconsider(isolated.state, rc.ROMANS, _recruit(), with_sa=False)
    request = decode(isolated.data['pending']['request'])
assert request['kind'] == 'supply_refusal'
assert returned == _recruit()
assert isolated.error is None
assert isolated.data['journal'] == []
isolated.finish()
assert isolated.data['pending'] is None

result = {
    'invalid_response': bad,
    'full_command_initial_pending': {'id': pending['id'], 'kind': 'supply_refusal'},
    'full_command_pending_after_invalid': {
        'id': after_pending['id'], 'kind': decode(after_pending['request'])['kind']},
    'full_command_rollback_preserved': True,
    'isolated_engine_request_kind': request['kind'],
    'isolated_returned_original_recruit_without_acceptance': True,
    'isolated_error': isolated.error,
    'isolated_pending_after_finish': isolated.data['pending'],
    'isolated_bad_queue_retained': isolated.data['queue'],
    'cause': 'AttributeError from replacement.details.get is swallowed by consult_agent as None',
}
text = json.dumps(result, indent=2)
Path(__file__).with_suffix('.out.json').write_text(text + '\n')
print(text)
