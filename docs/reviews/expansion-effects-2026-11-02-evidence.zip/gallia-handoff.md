# EXP-07 — A5 owner-directed evacuation

Worktree: `/workspace/scratch/534c265c65f4/fs-gallia-evacuation`

Branch: `repair/gallia-evacuation-2026-11-02`

Base: `95e7a206d5b6ff410d949573724cb2b145ed23d8`

## Scope and implementation

Only the unshaded A5 Cisalpina evacuation path was changed. The Event's
marker, three Roman Auxilia placement, March/Recruit geography, setup and
Interlude behavior retain their existing code. A5 shaded remains EXP-11.

`fs_bot/cards/gallia_evacuation.py` owns current-board physical enumeration,
legal destinations, strict allocation validation, seeded NP defaults and
resolution. `fs_bot/cli/gallia_evacuation.py` collects the corresponding
choices on a detached board and preserves board/b at every prompt. Existing
free-action and `_execute_event` transactions provide durable ownership,
rollback, save/load and replay. The generic free-action validator and CLI
dispatcher have narrowly named additions; the old incomplete loop is replaced
with a delegate.

Executor selects order when more than one owner is affected. Each owner then
selects its own complete allocation from the current board. In Ariovistus,
game-run Arverni allocate automatically. The plan can split each visibility
cohort among Homes and removal; Ally/Citadel identity includes the source
Tribe. Affected ownership cannot be overridden in the response. Human owners
may remove pieces despite legal movement options; NP defaults never do so.

German Settlement Regions are dynamic Homes. Cisalpina remains excluded even
when its outgoing Settlement would otherwise make it a Home. Tribe faction
restrictions, occupation, Dispersed status, City and Settlement limits remain
effective. Exact Tribe metadata is cleared at source and set at destination.
Movement preserves Hidden/Revealed/Scouted state and Leader identity; removal
uses ordinary helpers, including Diviciacus's removed pool.

NP defaults move all possible own pieces, choose the Leader destination with
most own pieces, provide four Warbands/Auxilia with a Leader as able, prefer
City/Remi Ally destinations and use seeded equal Region/Tribe ties. Owner
order benefits an affected executor first, then uses seeded equal ordering.
No Arverni March-only adjacency/Control rules are imported into direct moves.

## Source receipts

Full `CLAUDE.md` and all 47 Reference Documents inventory entries were read
before implementation; no protected references/constants/baseline were edited.
README/docs orientation and the current/provisional registers were consulted.
Only local Reference Documents supplied game rules.

* `Reference Documents/Ariovistus/A Card Reference`, A5: “Only Romans may
  stack there: non-Romans move their pieces there to their Home Regions or
  remove them.” “Pieces” includes structures; the text names non-Romans as
  actors for their own pieces rather than delegating those pieces to executor.
* `Reference Documents/Chapter 5`, §5.1: “Unless otherwise specified, the
  executing Faction makes all selections allowed for in implementing the text”.
  This assigns otherwise-unspecified owner-group order to executor; the
  explicit A5 owner assignment governs each group's disposition. Reviewer
  independently reconsidered and confirmed this reading. Cards47/48 explicitly
  prescribe printed initiative order; A5 does not. This is an application of
  the general source rule, not a new provisional ruling.
* Chapter5 §5.1.1: “Events may not violate stacking (1.4.2) unless their text
  explicitly changes stacking rules.” A5 changes Cisalpina exclusivity, not
  general Tribe/Settlement stacking elsewhere. §5.1.3 requires all possible
  portions of the Event to occur.
* Chapter1 §1.4.2: one Ally per Tribe circle; Cities hold Citadels; restricted
  Aedui/Arverni/Suebi locations and Dispersed restrictions still apply.
* `Ariovistus/Chapter A1`, A1.3.1: “Germanic Home Regions include any with
  Settlements in them”; Arverni Homes are Veneti, Carnutes, Pictones, Arverni.
  A1.4: “Stacking (A1.4.2) limits Settlements to one per Region”. A1.4's
  Diviciacus removal rule is preserved by `remove_piece`.
* Chapter8 §§8.3.1–8.3.4/8.4.1: benefit self first; “Place Leaders ... where
  the most own pieces”; equal candidates use random choice; Leader escort
  ends with at least four own Warbands/Auxilia as able; “Never voluntarily
  remove own pieces”. A8.2.3/A8.3.1 gives Settlements Citadel priority and
  Arverni Phase rules only “as applicable”. A6.2.2's March restrictions are
  not applicable to a direct A5 relocation.

There can be no legal Citadel in Cisalpina because it has no City. One
regression conservatively contains this impossible legacy-save condition,
rejecting overwrites of existing target Tribes. It is **not** a rules claim
about other Events that explicitly relocate/replace Citadels.

## Request/response contracts

Order request:

```json
{"kind":"free_action","request_type":"gallia_evacuation_order","card_id":"A5","owners":["Belgae","Germans"],"allow_decline":false,"free":true,"with_sa":false}
```

Owner order response: `{"owner_order":["Germans","Belgae"]}`. Every affected
owner must occur exactly once. Consulted faction is the Event executor.

Allocation request: `kind=free_action`, `request_type=gallia_evacuation`,
`card_id=A5`, `acting_faction=<affected owner>`, `origin=Cisalpina`,
`home_regions`, `pieces`, `allow_decline=false`, `free=true`, `with_sa=false`.
Each piece entry has stable `id`, canonical `piece_type`, integer `count`,
optional `piece_state`, `tribe`, `leader_name`, and legal `destinations`.
Every destination has `destination`; Allies/Citadels also specify `tribe`.

Allocation response:

```json
{"allocations":[{"piece_id":"Warband:Hidden","destination":"Ubii","count":2},{"piece_id":"Ally:Nori","destination":null,"count":1}]}
```

`destination:null` removes the physical piece(s). All source counts must be
allocated exactly; bool/negative/zero/excess counts, missing pieces, invalid
IDs, extra fields and illegal/occupied slots are rejected. Validation occurs
on a detached board/RNG and sequentially accounts for already selected target
slots. `{"use_default":true}` delegates explicitly; decline is forbidden.
Raw agent `None` retains NP fallback; a missing or invalid durable response
remains pending. CLI EOF interrupts rather than selecting a default.

The host's `HumanTurnDisplay.before_decision` runs before each request and
shows current/next card information and changes. Both live and preview board/b
inspection point to the board represented by that choice.

## Validation and compatibility

The independent review agent inspected module, menus, wiring and tests and
cleared the legal-state implementation for frozen full-suite testing.

* `gallia-targeted-01.log`: initial 14 passes/4 fixture failures, preserved.
  Failures were wrong test constant/API usage and using Belgic Homes for a
  hypothetical Citadel (no City exists there). Corrected fixtures, not rules.
* `gallia-targeted-02.log`: 18 passed.
* `gallia-targeted-03.log`: 29 passed after durable/CLI tests were added.
* `gallia-targeted-04.log`: 257 passed in 43.25s, including execute integration,
  normal Gallia geography/CLI, resumable turns, Parley, bonus timing.
* `gallia-full-01.log`: frozen full `pytest -q -n 2`: **6506 passed in
  119.98s**, exit status0. No source/test edits occurred during the run or
  between that run and commit. `git diff --check` also passed.

Coverage includes both owner orders on a legal Colony-created two-owner
Cisalpina, second-owner pending state after the first owner's moves, invalid
retry preserving ID/board/RNG, save/load and exact replay, human removal vs
forced-only NP removal, all visibility cohorts, dynamic Homes, Ally/Settlement
conservation/metadata, Diviciacus removal, automatic Arverni, and terminal
board/b/EOF/default paths. Existing map/Interlude tests remain in the full
suite. No broad strategic-outcome promise follows from these regressions.

Old affected human transcripts may lack newly required A5 owner/order choices.
Existing replay signatures stop at mismatches; this patch does not fabricate
consent or silently fill new human choices.

Parent owns documentation/progress report and final integration, commit
selection and push. Source/test commit:
`cf982d289fd350266c758f2ab0d71c858e7e9490` —
`Fix A5 owner-directed Cisalpina evacuation per 5.1 and A1.3.1`.
The worktree is clean. No push was made.
