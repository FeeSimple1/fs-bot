import json
from fs_bot import rules_consts as rc
import importlib.util
spec=importlib.util.spec_from_file_location('cv_fixture','/workspace/scratch/6dd8f67cdceb/fs-bot/fs_bot/tests/test_circumvallation.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
board=fixture.board
from fs_bot.cards.card_effects import execute_event
def place_marker(state,destination):
    state['event_params']={'target_region':destination}
    execute_event(state,4)
    return True
from fs_bot.board.pieces import count_pieces,place_piece,remove_piece
from fs_bot.commands.common import free_action_scope
from fs_bot.engine.execute import _execute_march
from fs_bot.engine.interlude import _step0_circumvallation
from fs_bot.battle.resolve import resolve_battle
from fs_bot.state.state_schema import validate_state

region=rc.MANDUBII
state=board();assert place_marker(state,region);assert not validate_state(state)
with free_action_scope(state,rc.ARVERNI):
    moved=_execute_march(state,rc.ARVERNI,{'command':rc.CMD_MARCH,'regions':[region],
        'sa':'No SA','sa_regions':[],'details':{'explicit_moves':[{'origin':region,
        'path':[rc.CARNUTES],'group':{rc.WARBAND:1}}]}})
movement_gap=bool(moved.get('executed') and count_pieces(state,region,rc.ARVERNI,rc.WARBAND)==3)
assert not validate_state(state)
state=board();assert place_marker(state,region)
remove_piece(state,region,rc.ROMANS,rc.AUXILIA)
last_roman_gap=rc.MARKER_CIRCUMVALLATION in state['markers'][region]
assert not validate_state(state)
state=board();place_piece(state,region,rc.ROMANS,rc.AUXILIA,5,piece_state=rc.REVEALED)
assert place_marker(state,region)
resolve_battle(state,region,rc.ARVERNI,rc.ROMANS,retreat_declaration=False)
remaining=count_pieces(state,region,rc.ROMANS,rc.AUXILIA)
attack_cleanup_gap=rc.MARKER_CIRCUMVALLATION in state['markers'][region]
assert not validate_state(state)
state=board();assert place_marker(state,region)
before=count_pieces(state,region,rc.ROMANS)
_step0_circumvallation(state)
interlude_gap=bool(before and count_pieces(state,region,rc.ROMANS)==0)
assert not validate_state(state)
result={'marked_force_can_march':movement_gap,'marker_survives_loss_of_last_roman':last_roman_gap,
        'roman_auxilia_after_four_marked_warbands_attack':remaining,
        'roman_auxilia_expected_with_fort_protection':5,'marker_survives_attack_on_romans':attack_cleanup_gap,
        'interlude_removes_unmarked_romans':interlude_gap,'all_boards_valid':True}
assert movement_gap and last_roman_gap and remaining==4 and attack_cleanup_gap and interlude_gap
print(json.dumps(result,indent=2))
