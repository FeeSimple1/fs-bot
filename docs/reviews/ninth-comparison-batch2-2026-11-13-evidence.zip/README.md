# Roman Quarters payment verification

This evidence covers LC9-01, the ninth comparison audit's second repair
batch. The directed tests use constructed positions across all five
scenarios. The paired game runs use the same editions and seeds as Batch 1.

- `parent/witness/` contains the original audit reproduction rerun against
  `1299b41`, including the five starting saves.
- `parent/directed.*` contains the new tests against the parent revision.
  Eight reproduce the defect and two controls pass.
- `parent/{legacy,second,fuzz*}` preserves the Batch 1 records under their
  original run identity. They were generated on a working tree based on
  `5f7d058` with the same Python source digest as committed Batch 1.
- `repair/` contains the directed, related and full suites, 120 bot games,
  the 100-game balance check, and mixed-player replay runs at both hash seeds.
- `verification.json` records the checks performed by `verify_evidence.py`.

With the archive extracted and the Batch 2 checkout on the import path,
verify the archived runs from the repository root.

```sh
PYTHONPATH=. python /path/to/evidence/verify_evidence.py
```

Rerun the directed tests and a sample of the other checks from that checkout.

```sh
python -m pytest -q fs_bot/tests/test_ninth_comparison_quarters.py
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 49-52 --card-edition second-edition --out /tmp/quarters-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 49-52 --card-edition second-edition --out /tmp/quarters-fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 49-52 --card-edition second-edition --out /tmp/quarters-fuzz987.json
python -m fs_bot.tools.balance_smoke --seeds 1-20
```
