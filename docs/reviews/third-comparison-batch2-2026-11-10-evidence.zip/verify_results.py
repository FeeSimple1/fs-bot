"""Check exact coverage, legality, source identities, replay and reviewed drift."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

root = Path(sys.argv[1]).resolve()
out = Path(__file__).resolve().parent
sys.path.insert(0, str(root))
from fs_bot import rules_consts as rc
from fs_bot.tools.validation_metadata import source_identity


def read(name):
    return json.loads((out / name).read_text())


source = read('source.json')
assert source_identity()['source_sha256'] == source['source_sha256']
suite = list(ET.parse(out / 'pytest.xml').getroot().iter('testsuite'))
counts = {k: sum(int(s.get(k, 0)) for s in suite)
          for k in ('tests', 'failures', 'errors', 'skipped')}
assert counts == {'tests': 9522, 'failures': 0, 'errors': 0, 'skipped': 0}, counts
parent_suite = list(ET.parse(out / 'parent-regressions.xml').getroot().iter('testsuite'))
parent_counts = {k: sum(int(s.get(k, 0)) for s in parent_suite)
                 for k in ('tests', 'failures', 'errors', 'skipped')}
assert parent_counts == {'tests': 50, 'failures': 28, 'errors': 0, 'skipped': 0}, parent_counts
cases = {(scenario, seed) for scenario in rc.ALL_SCENARIOS for seed in range(21, 25)}
bots = [json.loads(line) for line in (out / 'bots/games.jsonl').read_text().splitlines()]
assert len(bots) == 20 and {(r['scenario'], r['seed']) for r in bots} == cases
assert read('bots/metadata.json')['source_sha256'] == source['source_sha256']
for row in bots:
    assert row['source_sha256'] == source['source_sha256']
    assert all(row[k] is True for k in ('completed', 'game_completed', 'audit_completed'))
    assert not row['errors'] and not row['integrity_findings']
    assert row['final_state_sha256'] and len(row['final_ranking']) == 4
    assert not row['engine_ranking_output_missing'] and not row['winner_differs_from_highest_margin']
    assert all(d['severity'] == 'legal-decline' for d in row['diagnostics'])
parent_bots = {(r['scenario'], r['seed']): r for r in
               map(json.loads, (out / 'parent/bots/games.jsonl').read_text().splitlines())}
fuzz = read('fuzz0.json')
assert fuzz == read('fuzz987.json')
assert fuzz['metadata']['source_sha256'] == source['source_sha256']
assert fuzz['metadata']['replay'] and fuzz['metadata']['events'] and fuzz['metadata']['reactive']
assert fuzz['games'] == 20 and fuzz['hard_findings'] == 0
assert {(r['scenario'], r['seed']) for r in fuzz['records']} == cases
assert all(r['game_completed'] and not r['findings'] for r in fuzz['records'])
balance = read('balance.json')
assert balance['source']['source_sha256'] == source['source_sha256']
assert balance['guardrail_exit'] == 0
keys = {f'{scenario}|{seed}' for scenario in rc.ALL_SCENARIOS for seed in range(1, 21)}
assert set(balance['games']) == keys
baseline_path = root / 'fs_bot/tools/balance_baseline.json'
baseline = json.loads(baseline_path.read_text())
assert set(baseline['games']) == keys and baseline['games'] == balance['games']
assert balance['games'] == read('candidate2/balance.json')['games']
parent = read('parent/balance.json')['games']
stored = read('stored-baseline-before.json')['games']
cause = read('seasonal-cause.json')
assert cause['source']['source_sha256'] == source['source_sha256']
assert cause['all_100_winners_and_lengths_match_parent']
assert cause['games'] == parent and set(cause['games']) == keys
summary = {
    'source': source, 'pytest': counts, 'parent_regressions': parent_counts,
    'new_cases': 49, 'corrected_legacy_expectations': 1,
    'bots': {'records': 20, 'audit_failures': 0,
             'winners_changed_from_parent': sum(r['winner'] != parent_bots[r['scenario'], r['seed']]['winner'] for r in bots),
             'final_states_changed_from_parent': sum(r['final_state_sha256'] != parent_bots[r['scenario'], r['seed']]['final_state_sha256'] for r in bots)},
    'mixed': {k: fuzz[k] for k in ('games', 'human_turns', 'event_turns', 'events_ok', 'partial', 'hard_findings', 'batch_digest')},
    'mixed_hashes_identical': True,
    'mixed_records_changed_from_parent': sum(a != b for a, b in zip(fuzz['records'], read('parent/fuzz0.json')['records'])),
    'balance': {'games': 100, 'guardrail_exit': 0, 'band': 0.15,
                'winner_changes_from_parent': sum(balance['games'][k]['winner'] != parent[k]['winner'] for k in keys),
                'length_changes_from_parent': sum(balance['games'][k]['cards'] != parent[k]['cards'] for k in keys),
                'winner_changes_from_older_stored_baseline': sum(balance['games'][k]['winner'] != stored[k]['winner'] for k in keys),
                'baseline_sha256': hashlib.sha256(baseline_path.read_bytes()).hexdigest(),
                'old_baseline_sha256': hashlib.sha256((out / 'stored-baseline-before.json').read_bytes()).hexdigest(),
                'seasonal_counterfactual_matches_all_parent_outcomes': True},
    'card_edition': 'legacy', 'bot_and_mixed_seeds': [21, 22, 23, 24],
    'balance_seeds': list(range(1, 21)), 'hash_seeds': [0, 987],
}
(out / 'verification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
