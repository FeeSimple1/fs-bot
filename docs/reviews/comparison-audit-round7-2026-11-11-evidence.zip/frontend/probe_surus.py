"""Seventh comparison witness: Surus admits multiple base German March groups.

Run with PYTHONPATH pointing to the audited fs-bot checkout. This is an
observation script, not a production test asserting the incorrect rule.
"""
from copy import deepcopy
from io import StringIO
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces
from fs_bot.cli.display import HumanTurnDisplay
from fs_bot.cli.human_plan import _collect_march
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT, _action_transaction
from fs_bot.state.serialize import decode, encode, save_game, load_game
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.tools.seat_session import DecisionPending, SeatSession, board_copy


def board():
    state = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=7)
    state.update(current_card=51, current_card_id=51, next_card=49,
                 card_edition='second-edition', non_player_factions=set())
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    place_piece(state, rc.TREVERI, rc.AEDUI, rc.WARBAND, 4)
    check(state)
    return state


def check(state):
    result = {'schema': validate_state(state), 'structure': check_structural_integrity(state)}
    assert result == {'schema': [], 'structure': []}, result
    return result


def counts(state):
    return {r: count_pieces(state, r, rc.GERMANS, rc.WARBAND)
            for r in (rc.TREVERI, rc.NERVII, rc.SEQUANI)}


def action(kind):
    plan = {'origins': [rc.TREVERI], 'destinations': [rc.NERVII],
            'routes': {rc.TREVERI: [rc.NERVII]}}
    if kind in ('split', 'single_subset'):
        plan['groups'] = {rc.TREVERI: {rc.WARBAND: 2}}
    if kind == 'split':
        plan['extra_groups'] = [{'origin': rc.TREVERI, 'route': [rc.SEQUANI],
                                 'group': {rc.WARBAND: 2}}]
    if kind == 'explicit_split':
        plan = {'explicit_moves': [{'origin': rc.TREVERI, 'path': [destination],
                                    'group': {rc.WARBAND: 2}}
                                   for destination in (rc.NERVII, rc.SEQUANI)]}
    return {'command': rc.CMD_MARCH, 'sa': 'No SA', 'details': {'march_plan': plan}}


def play(state):
    return execute_decision(state, rc.BELGAE, {'action': ACTION_EVENT, 'player_action': {
        'command': rc.FIRST_DID_EVENT, 'details': {'card_id': 51,
        'text_preference': rc.EVENT_SHADED,
        'event_params': {'region': rc.TREVERI, 'count': 4}}}})


def run(kind):
    state = board()
    seen = []
    terminal_output = StringIO()
    terminal_input = StringIO('1\nNervii\n3\ny\nSequani\n1\n')
    submitted = []
    def agent(live, faction, request):
        seen.append({'faction': faction, 'kind': request['kind'],
                     'request_type': request.get('request_type')})
        if request['kind'] == 'free_action':
            if kind == 'terminal_split':
                plan = _collect_march(live, request['acting_faction'],
                                      terminal_input, terminal_output, True)
                selected = {'command': rc.CMD_MARCH, 'sa': 'No SA',
                            'details': {'march_plan': plan}}
            else:
                selected = action(kind)
            submitted.append(deepcopy(selected))
            return selected
    state['decision_agent'] = agent
    result = play(state)
    assert result['executed'] and result['free_actions'][0]['result']['executed'], result
    expected = {rc.TREVERI: 0, rc.NERVII: 4, rc.SEQUANI: 0}
    if kind == 'single_subset':
        expected = {rc.TREVERI: 2, rc.NERVII: 2, rc.SEQUANI: 0}
    elif kind in ('split', 'explicit_split', 'terminal_split'):
        expected = {rc.TREVERI: 0, rc.NERVII: 2, rc.SEQUANI: 2}
    assert counts(state) == expected
    output = {'case': kind, 'checks': check(state), 'result': result,
              'counts': counts(state), 'requests': seen, 'submitted': submitted}
    if kind == 'terminal_split':
        assert not terminal_input.read()
        assert 'March a SECOND group' in terminal_output.getvalue()
        output['terminal_output'] = terminal_output.getvalue()
    return output


def make_session(state, meta, log):
    session = SeatSession(state, meta, log, HumanTurnDisplay(StringIO()))
    state['decision_agent'] = lambda live, faction, request: (
        session.reactive(live, faction, request) if request['kind'] == 'free_action' else None)
    return session


def attempt(session):
    def driver(*args):
        pass
    driver.transaction_checkpoint = session.checkpoint
    driver.transaction_restore = session.restore
    with _action_transaction(session.state, driver):
        return play(session.state)


def durable():
    initial = board()
    session = make_session(deepcopy(initial), {'seat': rc.BELGAE}, [])
    try:
        attempt(session)
    except DecisionPending:
        pass
    else:
        raise AssertionError('Expected a durable free-action request')
    pending = deepcopy(session.data['pending'])
    assert decode(pending['request'])['acting_faction'] == rc.GERMANS
    assert encode(board_copy(session.state)) == encode(initial)
    with TemporaryDirectory(dir=Path(__file__).parent) as directory:
        path = Path(directory) / 'pending.json'
        save_game(session.state, path, meta=session.meta, log=session.log)
        restored, meta, log = load_game(path, validate=True)
    resumed = make_session(restored, meta, log)
    assert resumed.data['pending'] == pending
    resumed.import_inbox({'decision_id': pending['id'], 'response': action('split')})
    result = attempt(resumed)
    assert result['executed']
    resumed.finish()
    assert counts(restored) == {rc.TREVERI: 0, rc.NERVII: 2, rc.SEQUANI: 2}
    check(restored)
    replay = deepcopy(initial)
    replay['decision_agent'] = lambda live, faction, request: (
        decode(log[-1]['assistant_response']) if request['kind'] == 'free_action' else None)
    replay_result = play(replay)
    assert replay_result == result
    assert encode(board_copy(replay)) == encode(board_copy(restored))
    return {'case': 'durable_split', 'pending_saved_and_restored': True,
            'illegal_split_accepted': True, 'exact_replay': True,
            'counts': counts(restored), 'checks': check(restored), 'result': result}


if __name__ == '__main__':
    print(json.dumps({'FE7-01': [run(kind) for kind in
        ('single_all', 'single_subset', 'split', 'explicit_split', 'terminal_split')]
        + [durable()]}, indent=2))
