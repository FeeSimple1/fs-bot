# Eighth Falling Sky comparison evidence

Audited commit: `e62b0360c1b91032741ef8f6afa4d247c8ea2437`. Python SHA-256: `3c047ebcfef915efef8e1da308cd63484b1e6c735b8aba8e5c095de2c5d106b9` (611 files).
Eleven open findings; production and protected sources unchanged.

Run `python run_witnesses.py --repo /absolute/path/to/fs-bot` with Python 3.12.
The runner needs only the standard library. It verifies source bytes, runs all
five scripts under hash seeds 0 and 987 in temporary directories, and requires
exact agreement with recorded JSON. Assertions pin observed defects, so a
correct repair is expected to change their result. The source digest, rather
than the documentation commit identity, gates reproduction.

Each lane contains its final ledger, executable witness, output and available
independent review. Frontend and lifecycle include real saved states. All are
controlled valid fixtures with the exact reachability limits recorded in their
ledgers; they are not claimed natural full-game traces.

`validation/summary.json` and raw logs retain the full 10,116-test run, 20 audited
bot games, and 20 mixed cases repeated under two hashes with internal replay.
Its source metadata names the audited parent. The validation verifier's exact
commit guard is intentionally stricter than the portable witness runner.

The general validation passes do not detect the newly proven rules failures.
No outcome frequency, rules completeness, balance or bug-free claim is made.
`SHA256SUMS` covers every other file in this archive.
