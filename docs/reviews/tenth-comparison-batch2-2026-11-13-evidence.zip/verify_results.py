"""Verify Batch 2's Abatis regression and the paired validation records."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
from xml.etree import ElementTree

from fs_bot import rules_consts as rc
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


ROOT = Path(__file__).resolve().parent
REPO = Path(__import__('fs_bot').__file__).resolve().parent.parent
PARENT = '83e28d4e8f296ac0506552c9830dd26e0858f825'
PARENT_DIGEST = 'd0d118327578839fecd34ec27849f7226f022ce020df135332004843bf4db8e7'
BALANCE_ROW = re.compile(r'^\[(.+) seed= *(\d+)\] winner=(.+) \((\d+) cards\)$', re.M)


def load(name):
    return json.loads((ROOT / name).read_bytes())


def check_suites():
    expected = {'parent-directed': (6, 2), 'directed': (6, 0),
                'focused': (226, 0), 'full': (10308, 0)}
    result = {}
    for name, (tests, failures) in expected.items():
        suite, = ElementTree.parse(ROOT / f'{name}.xml').iter('testsuite')
        counts = {'tests': tests, 'failures': failures, 'errors': 0, 'skipped': 0}
        assert all(int(suite.get(key)) == value for key, value in counts.items()), name
        result[name] = dict(counts, passed=tests - failures, seconds=float(suite.get('time')))
    return result


def read_games(directory, edition, seeds, digest):
    metadata = load(f'{directory}/metadata.json')
    assert metadata['source_sha256'] == digest
    assert metadata['card_edition'] == edition and metadata['hash_seed'] == 0
    assert metadata['seeds'] == list(seeds)
    rows = [json.loads(line) for line in (ROOT / directory / 'games.jsonl').read_text().splitlines()]
    games = {(row['scenario'], row['seed']): row for row in rows}
    assert len(rows) == len(games) == 5 * len(seeds)
    assert set(games) == {(scenario, seed) for scenario in SCENARIOS for seed in seeds}
    for row in rows:
        assert row['source_sha256'] == digest and row['card_edition'] == edition
        assert row['completed'] and row['game_completed'] and row['audit_completed']
        assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row)
        assert len(row['final_state_sha256']) == 64
        assert all(d['severity'] == 'legal-decline' for d in row['diagnostic_occurrences'])
    return games


def outcomes(games):
    return {key: {field: row[field] for field in ('winner', 'cards')}
            for key, row in games.items()}


def compare_games(parent, repair):
    assert parent.keys() == repair.keys()
    fields = ('final_state_sha256', 'winner', 'cards', 'final_ranking',
              'interlude_completed', 'diagnostics', 'diagnostic_occurrences')
    for key, row in repair.items():
        assert all(row[field] == parent[key][field] for field in fields), key
    return {'games': len(repair), 'interludes': sum(r['interlude_completed'] for r in repair.values()),
            'diagnostic_occurrences': sum(len(r['diagnostic_occurrences']) for r in repair.values()),
            'changed_final_states': 0, 'changed_winners': 0, 'changed_card_counts': 0}


def check_balance(parent, repair):
    log = (ROOT / 'balance.log').read_text()
    assert 'OK: balance within band (6 winner changes)' in log
    records = {(s, int(k)): {'winner': f, 'cards': int(n)} for s, k, f, n in BALANCE_ROW.findall(log)}
    assert len(records) == 100 and records == outcomes(parent) == outcomes(repair)
    baseline = json.loads((REPO / 'fs_bot/tools/balance_baseline.json').read_text())['games']
    assert len(baseline) == len(records)
    drift = {}
    for scenario in SCENARIOS:
        old = Counter(baseline[f'{s}|{k}']['winner'] for s, k in records if s == scenario)
        new = Counter(record['winner'] for (s, _), record in records.items() if s == scenario)
        drift[scenario] = max(abs(old[f] - new[f]) for f in rc.FACTIONS) * 5
    largest = max(drift.values())
    assert largest == 10
    return {'games': 100, 'largest_shift_points': largest, 'band_points': 15,
            'winner_and_card_counts_agree': True, 'drift_by_scenario': drift}


def check_mixed(digest):
    for extension in ('json', 'log'):
        assert (ROOT / f'fuzz0.{extension}').read_bytes() == (ROOT / f'fuzz987.{extension}').read_bytes()
    current = load('fuzz0.json')
    prior = load('parent-fuzz0.json')
    assert prior['metadata']['source_sha256'] == PARENT_DIGEST
    assert current['metadata']['source_sha256'] == digest
    assert all(current['metadata'][key] for key in ('replay', 'events', 'reactive'))
    assert current['metadata']['card_edition'] == 'second-edition'
    assert current['metadata']['seeds'] == list(range(53, 57))
    assert current['records'] == prior['records']
    assert current['games'] == len(current['records']) == 20 and current['hard_findings'] == 0
    assert all(r['game_completed'] and not r['findings'] for r in current['records'])
    fields = ('games', 'human_turns', 'event_turns', 'events_ok', 'partial', 'hard_findings', 'batch_digest')
    return {key: current[key] for key in fields}


def main():
    source = load('source.json')
    digest = source['source_sha256']
    assert source_identity()['source_sha256'] == digest
    assert source['commit'] == PARENT and source['dirty']
    protected = load('protected-sources.json')
    assert len(protected) == 48
    assert all(hashlib.sha256((REPO / name).read_bytes()).hexdigest() == sha
               for name, sha in protected.items())
    suites = check_suites()
    games = {}
    for edition, seeds in (('legacy', range(1, 21)), ('second-edition', range(53, 57))):
        parent = read_games(f'parent-{edition}', edition, seeds, PARENT_DIGEST)
        repair = read_games(edition, edition, seeds, digest)
        games[edition] = compare_games(parent, repair)
        if edition == 'legacy':
            balance = check_balance(parent, repair)
    result = {'source': source, 'suites': suites, 'bot_games': games,
              'balance': balance, 'mixed': check_mixed(digest), 'protected_files': len(protected)}
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
