"""Verify the paired March witnesses, game runs and balance review."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
from xml.etree import ElementTree
from zipfile import ZipFile

from compare_traces import records, result_signature
from fs_bot import rules_consts as rc
from fs_bot.tools.error_census import _severity
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


HERE = Path(__file__).resolve().parent
REPO = Path(rc.__file__).resolve().parents[1]
PARENT = "2e7fe17af7aa1a18e29ea69a90b886887c2fe331"
PARENT_DIGEST = "95e58d60023a24eec5f2ca576b9d010f20faf4e23b4cacc2ae3e7c034a4c152d"
REPAIRED_DIGEST = "7cb64407ff5594eb2bbd671a8159c408410fa8cc26e7a784da7afe0fd47363db"
MATRIX = {"legacy": range(1, 21), "second-edition": range(57, 61)}
BASELINE = REPO / "fs_bot/tools/balance_baseline.json"


def load(path):
    return json.loads((HERE / path).read_bytes())


def verify_tests():
    expected = {"parent-final14": (14, 10), "directed0": (642, 0),
                "directed987": (642, 0), "full": (10449, 0)}
    totals = {}
    for name, (tests, failures) in expected.items():
        suite, = ElementTree.parse(HERE / f"{name}.xml").iter("testsuite")
        assert int(suite.get("tests")) == tests and int(suite.get("failures")) == failures, name
        assert int(suite.get("errors")) == int(suite.get("skipped")) == 0, name
        totals[name] = {"passed": tests - failures, "failed": failures}
    test = "test_eleventh_comparison_bot_march.py"
    assert (HERE / test).read_bytes() == (REPO / "fs_bot/tests" / test).read_bytes()
    return totals


def verify_witnesses(audit):
    assert audit.read("bots/results.json") == (HERE / "parent-witness.json").read_bytes()
    left, right = (HERE / f"final-repair-witness{seed}.json" for seed in (0, 987))
    assert left.read_bytes() == right.read_bytes()
    witness = load(left)
    seen = {row["name"]: row for row in witness["cases"]}
    assert witness["case_count"] == len(seen) == 12
    for row in seen.values():
        assert row["integrity_before"] == row["integrity_after"] == {"census": [], "structure": []}
        assert row["execution"]["executed"] and not row["execution"].get("errors"), row["name"]
    for name in ("belgic_new_enlist_omitted", "belgic_authored_enlist_control",
                 "belgic_existing_enlist_control"):
        row = seen[name]
        assert row["leader_region"] == rc.ATREBATES and row["german_hidden"] == 2
        assert row["german_revealed"] == 0 and row["execution"]["total_cost"] == 4
        enlist = row["execution"]["sa_execution"]
        assert enlist["executed"] and enlist["type"] == "german_march_hide"
    for name in ("belgic_stale_positive_control", "belgic_no_sa_control",
                 "belgic_absent_germans_control", "belgic_scoped_free_control"):
        row = seen[name]
        assert not row["german_hidden"] and not row["execution"].get("sa_execution", {}).get("executed")
    row = seen["german_surrounded_leader_raid"]
    assert row["leader_region"] == rc.CISALPINA and row["ubii_warbands"] == 1
    move, = row["execution"]["marches"]
    assert move == {"origin": rc.UBII, "final_region": rc.CISALPINA, "leader": True, "warbands": 25}
    assert row["execution"]["total_cost"] == 1 and row["resources"] == 9
    for name in ("german_authored_toward_control", "german_adjacent_target_control"):
        assert seen[name]["execution"]["command"] == rc.CMD_MARCH
        assert seen[name]["leader_region"] == rc.TREVERI
    for name in ("german_frost_control", "german_no_leader_control"):
        assert seen[name]["execution"]["command"] == rc.CMD_RAID
    return len(seen)


def read_games(get, edition, seeds, source):
    meta = json.loads(get(f"{edition}/metadata.json"))
    assert meta["source_sha256"] == source and meta["hash_seed"] == 0
    assert meta["card_edition"] == edition and meta["seeds"] == list(seeds) and meta["all_factions_bots"]
    rows = records(get(f"{edition}/games.jsonl"), edition)
    assert set(rows) == {(edition, scenario, seed) for scenario in SCENARIOS for seed in seeds}
    for row in rows.values():
        assert row["source_sha256"] == source and row["card_edition"] == edition
        assert row["completed"] and row["game_completed"] and row["audit_completed"]
        assert len(row["final_state_sha256"]) == 64
        assert not (row["errors"] or row["integrity_findings"] or _outcome_issues(row)), row
        for diagnostic in row["diagnostic_occurrences"]:
            assert diagnostic["severity"] == _severity(diagnostic["kind"], diagnostic["message"]) == "legal-decline"
    return rows


def verify_games(parent):
    totals, parent_games, repair_games = {}, {}, {}
    for edition, seeds in MATRIX.items():
        before = read_games(parent.read, edition, seeds, PARENT_DIGEST)
        after = read_games(lambda p: (HERE / p).read_bytes(), edition, seeds, REPAIRED_DIGEST)
        parent_games.update(before)
        repair_games.update(after)
        assert all(row["commit"] == PARENT for row in after.values())
        diff = {field: sum(before[key][field] != row[field] for key, row in after.items())
                for field in ("winner", "cards", "final_state_sha256")}
        totals[edition] = dict(games=len(after), changed=diff,
                               interludes=sum(r["interlude_completed"] for r in after.values()),
                               legal_declines=sum(len(r["diagnostic_occurrences"]) for r in after.values()))
    assert [totals[edition]["changed"]["winner"] for edition in MATRIX] == [19, 2]
    return parent_games, repair_games, totals


def verify_traces(parent_games, repair_games):
    trace = load("first-differences.json")
    seen = set()
    for row in trace["cases"]:
        key = row["edition"], row["scenario"], row["seed"]
        assert key not in seen and row["parent_exit_state"] != row["repair_exit_state"]
        assert len(row["same_entry_state"]) == 64 and row["card_index"] > 0
        seen.add(key)
        for name, matrix in (("parent", parent_games), ("repair", repair_games)):
            assert (row[f"{name}_winner"], row[f"{name}_card_count"],
                    row[f"{name}_final_state"]) == result_signature(matrix[key])
        if row["mechanism"] == "Belgic March Enlist":
            assert all(e["result"]["executed"] and e["result"]["sa"] == rc.SA_ENLIST
                       for e in row["after_enlist"]) and row["after_enlist"]
        else:
            assert row["mechanism"] == "German expansion March"
            assert row["parent_german_plans"] or row["repair_german_plans"]
    assert seen == {key for key in parent_games if parent_games[key]["winner"] != repair_games[key]["winner"]}
    assert trace["mechanisms"] == dict(Counter(r["mechanism"] for r in trace["cases"]))
    return {"changed_winners": len(seen), "first_differences": trace["mechanisms"]}


def verify_mixed(parent):
    for suffix in ("json", "log"):
        assert (HERE / f"fuzz0.{suffix}").read_bytes() == (HERE / f"fuzz987.{suffix}").read_bytes()
    before, after = json.loads(parent.read("fuzz0.json")), load("fuzz0.json")
    meta = after["metadata"]
    assert meta["commit"] == PARENT and meta["source_sha256"] == REPAIRED_DIGEST
    assert meta["card_edition"] == "second-edition" and meta["seeds"] == list(MATRIX["second-edition"])
    assert all(meta[flag] for flag in ("events", "reactive", "replay"))
    assert after["games"] == len(after["records"]) == 20 and after["hard_findings"] == 0
    assert {(r["scenario"], r["seed"]) for r in after["records"]} == {
        (scenario, seed) for scenario in SCENARIOS for seed in MATRIX["second-edition"]}
    assert all(r["game_completed"] and not r["findings"] for r in after["records"])
    info = {key: after[key] for key in ("games", "human_turns", "event_turns",
                                       "partial", "hard_findings", "batch_digest")}
    prior = {(r["scenario"], r["seed"]): r for r in before["records"]}
    info["changed_cases"] = sum(prior[r["scenario"], r["seed"]] != r for r in after["records"])
    return info


def verify_balance(parent_games, repair_games):
    def simple(matrix):
        return {f"{scenario}|{seed}": {k: row[k] for k in ("winner", "cards")}
                for (edition, scenario, seed), row in matrix.items() if edition == "legacy"}

    before, after = simple(parent_games), simple(repair_games)
    assert before == load("balance-baseline-parent.json")["games"]
    assert before.keys() == after.keys() and len(after) == 100
    assert after == json.loads(BASELINE.read_bytes())["games"]
    assert hashlib.sha256(BASELINE.read_bytes()).hexdigest() == (HERE / "balance-baseline-sha256.txt").read_text().strip()
    for log_name, limit, passed in (("balance-original", 20, False), ("balance", 20, True),
                                     ("canary", 3, True)):
        log = (HERE / f"{log_name}.log").read_text()
        rows = re.findall(r"^\[(.+) seed= *(\d+)\] winner=(.+) \((\d+) cards\)$", log, re.M)
        games = {f"{scenario}|{seed}": {"winner": winner, "cards": int(cards)}
                 for scenario, seed, winner, cards in rows}
        expected = {f"{scenario}|{seed}" for scenario in SCENARIOS for seed in range(1, limit + 1)}
        assert len(rows) == len(games) and set(games) == expected
        assert games == {key: after[key] for key in expected}
        assert ("OK: balance within band." if passed else "FAIL: a faction win rate moved beyond the band.") in log
    return {"games": len(after), "canary_games": 15, "changed": sum(before[k] != v for k, v in after.items()),
            "changed_winners": sum(before[k]["winner"] != v["winner"] for k, v in after.items()),
            "changed_card_counts": sum(before[k]["cards"] != v["cards"] for k, v in after.items())}


def main():
    assert source_identity()["source_sha256"] == REPAIRED_DIGEST
    assert len(list((REPO / "fs_bot").rglob("*.py"))) == 629
    reviews = REPO / "docs/reviews"
    with ZipFile(reviews / "comparison-audit-round11-2026-11-13-evidence.zip") as audit:
        protected = json.loads(audit.read("validation/protected-sources.json"))
        witness_count = verify_witnesses(audit)
    expected = {f.relative_to(REPO).as_posix() for f in (REPO / "Reference Documents").rglob("*") if f.is_file()}
    assert set(protected) == expected | {"fs_bot/rules_consts.py"}
    assert all(hashlib.sha256((REPO / path).read_bytes()).hexdigest() == digest
               for path, digest in protected.items())
    with ZipFile(reviews / "eleventh-comparison-batch4-2026-11-13-evidence.zip") as parent:
        before, after, totals = verify_games(parent)
        summary = dict(parent=PARENT, source_sha256=REPAIRED_DIGEST, protected_files=len(protected),
                       tests=verify_tests(), witnesses=witness_count, audited_games=totals,
                       trace=verify_traces(before, after), mixed=verify_mixed(parent),
                       balance=verify_balance(before, after))
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
