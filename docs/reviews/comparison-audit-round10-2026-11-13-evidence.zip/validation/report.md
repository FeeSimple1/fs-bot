# Tenth audit baseline validation

Validation passed on clean commit `ae238c6482a792dda98af4f1f9b11abf820a3964`. No production files were edited in this lane. The 620-file Python source digest remained `39076dca68ec449cf766e40256c765d2d36693c50989a2b0552745f208f94d45`; all 47 reference documents and `fs_bot/rules_consts.py` match the captured SHA-256 inventory.

| Check | Result |
| --- | --- |
| Full pytest suite, four workers, hash seed 0 | 10,279 passed; zero failures, errors, or skips; 126.34 seconds |
| Held-out audited bot games | All 20 completed, one game per five scenarios × seeds 53–56, second-edition cards |
| Bot errors / integrity findings / outcome ranking issues | 0 / 0 / 0 |
| Bot diagnostics | 150 groups, 388 occurrences; all classified legal declines |
| Interludes | Three completed: The Gallic War seeds 53, 54, 55 |
| Mixed-player games at hash seeds 0 and 987 | Both batches completed all 20 cases with internal replay, 80 executions in total |
| Cross-process determinism | Entire JSON files and entire console logs byte-identical |
| Mixed activity per batch | 560 human turns, 130 Event turns, 118 successful Events |
| Mixed hard findings | 0 |
| Mixed soft partial plans | 1: The Gallic War seed 54 |

The soft partial plan is recorded, not counted as a successful full plan. Its game completed with no hard finding, with human seats Belgae, Germans, and Romans; 43 human turns and 11 successful Events. Its state digest was `15114a3e873b5257`. The batch digest is `5c1e9e259b2dbe05b75db1d06e322828e414a182997eaf85aa90ef50d30a9fdb`.

The suite emitted five warnings from the external anyio pytest plugin importing the deprecated `CallSpec2` alias. No project warning or test failure was observed. The full suite includes the existing 15-game balance canary; this audit did not refresh its baseline or perform a fresh 100-game balance study. Sampled games and passing tests do not establish complete rules coverage.

## Reproduction

Run from the repository root with Python 3.12.14 and the existing test environment:

```bash
PYTHONHASHSEED=0 python -m pytest -q -n 4 --junitxml=../audit10/validation/pytest.xml > ../audit10/validation/pytest.log 2>&1
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 53-56 --card-edition second-edition --workers 2 --out ../audit10/validation/bots > ../audit10/validation/bots.log 2>&1
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 53-56 --card-edition second-edition --out ../audit10/validation/fuzz0.json > ../audit10/validation/fuzz0.log 2>&1
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 53-56 --card-edition second-edition --out ../audit10/validation/fuzz987.json > ../audit10/validation/fuzz987.log 2>&1
PYTHONPATH=. python ../audit10/validation/verify_validation.py
```

Actual interpreter: `/workspace/scratch/4aba5bd9b1ab/fs-bot/.venv/bin/python`.

`summary.json` records checked results; `source.json` and `protected-sources.json` identify the baseline. The verifier inspects every game record for completion, findings, edition, seed/scenario coverage, final state hashes, and diagnostic severity; confirms complete JSON and console equality; checks the JUnit result; and verifies the source and protected-file hashes again. Raw logs and full records are retained alongside this report.
