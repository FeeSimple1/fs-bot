# Sixth audit: Events evidence

Audited production `86fb0c2d8ddf86a4548a863dc9c9da27d0c708ad`; production tree remains clean. The authoritative results are `findings.json`, `probe_events.py`, and `probe_events-output.json`. The standalone probe passes seven public-entrypoint witness cases and their matched controls. Root and independent reviewer reran the final script with exact matching JSON.

| Final ID | Output key | Confirmed scope | Severity |
| --- | --- | --- | --- |
| BE6-01 | BE6-events-01 | Numeric57 shaded accepts missing mandatory removal, missing mandatory Ally, or both while placing a Warband | high |
| BE6-02 | NP6-events-01 | Missing NP parameters for A35 German shaded, A35 Roman unshaded, A60 Belgic shaded | medium |
| BE6-03 | NP6-events-02 | Numeric56 shaded is chosen with named Ambiorix already on the map | medium |

Run from `fs-bot`:

```sh
PYTHONPATH=. /workspace/scratch/5473f6589808/audit-venv/bin/python ../audit-round6-work/events/probe_events.py
```

The assertions intentionally describe current defects, so passing means the defective behavior and lawful comparison controls are reproduced. Each physical fixture and completed witness/control checks piece conservation through `validate_state`, Tribe/piece and other structural integrity through `check_structural_integrity`, and the permanent Provincia Fort. No production code is monkeypatched. A35 German and Flight56 use original scenario setup physical boards with current card and NP seats injected. The other fixtures are sparse, census-valid constructed states. These are controlled reproducibility proofs, not a claim of naturally played transcripts or frequency. In actual Ariovistus setup there are seven, not eight, German Warbands Available; the control places all seven plus one Settlement.

The first Flight probe used Great Revolt, which has the Successor rather than named Ambiorix; that fixture assertion correctly failed. It was corrected to the original Pax Gallica setup before finalization. The earlier failure is not an engine finding. The independent review final output is `../review/events-final-rerun.json`; an earlier failed/empty review output is superseded.

## Source and implementation coverage

Read base and Ariovistus card references, Chapter5 Event rules, Chapter8 Event choice/effectiveness priorities, Roman Ariovistus Event instructions, existing source decisions, and previous audit/repair ledgers. Trace coverage included Event dispatch and execution, Event effect/condition summaries and choice producers, numeric57 removal/Ally/Warband consumers, A35/A60 handlers, named Leader return target domains, capability consumers, base Event limits, expansion quantity/target validation, exact piece plans, Parley, Gallia evacuation, All Gaul Gathers, Migration, War Fleet, and Impetuosity. Source-defined scenario/edition differences were retained; base findings use base scenarios and A-card findings use Ariovistus. No exhaustive cross-edition matrix is claimed.

Liberty or Death comparison was limited to the authorized checkout at `2991ea279062773548ec390a1da75f3e85381702`. Its implementation lessons on orphaned consumers, parameter producer/consumer shapes, and card-handler long tails motivated checks; Falling Sky's own references decide all expected behavior. The demonstrated parameter seam has missing NP producers despite functioning complete explicit-parameter consumers.

## Prior-ledger distinction

BE6-01 is the surviving numeric57 mandatory-effect engine guard. Original BE-08 repaired that card's structured CLI menu shape; EX2-04 enumerated A30S/A56S/A65S quotas, and BE2-03 was Remi68U mandatory replacement. BE6-02 is NP plan generation, separate from EXP-08 human quantity/refund choices, EXP-09 listed geography/target limits, and EX3-03 A35 Dispersed marker replacement. BE6-03 is NP Event availability; earlier BE2-05 repaired actual shaded Flight return targets/Successor handling, and BE2-06 repaired unshaded victory scoring. EX2-05 is Kinship, unrelated.

## Negative and uncounted work

- Rejected Avaricum non-City replacement suspicion: Chapter5 explicitly instructs removal without replacement when stacking bars the replacement.
- Rejected a speculative German Raid/Ambush reservation requirement: no source basis was established for saving raiders for the subsequent action.
- A31 combat follow-up belongs to the combat partition and is not counted here.
- The broad exploratory no-op scan is retained as investigative scratch only. Its raw candidates are not bugs until lawful public flowchart witnesses and card-specific source controls establish a discrepancy. No other cards are inferred from the three confirmed groups.
- No production fixes, regression tests, commits, or documentation edits were made by this partition.
