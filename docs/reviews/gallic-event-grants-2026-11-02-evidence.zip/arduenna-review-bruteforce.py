"""Independent small allocation oracle; shares scoring, not search machinery."""
from copy import deepcopy
from itertools import product, permutations
import json

from fs_bot import rules_consts as r
from fs_bot.board.pieces import place_piece
from fs_bot.cards.arduenna import march_request
from fs_bot.cards.base_arduenna_np import plan, predicted_legion_losses
from fs_bot.engine.free_actions import execute_free_action_plan
from fs_bot.map.map_data import get_adjacent_for_state
from fs_bot.state.state_schema import build_initial_state

TARGETS = (r.NERVII, r.TREVERI)

def choices(s, origin, count):
    destinations = [origin] + [d for d in TARGETS if d != origin and d in get_adjacent_for_state(s, origin)]
    # Label individual counters, then quotient identical count allocations.
    allocations = set(tuple(assignment.count(d) for d in destinations)
                      for assignment in product(destinations, repeat=count))
    for allocation in sorted(allocations):
        moves = [(origin, d, n) for d, n in zip(destinations, allocation) if d != origin and n]
        # Different group order can select different original visibility.
        yield from permutations(moves) if moves else [()]

def action(moves):
    origins, routes, groups, extra = [], {}, {}, []
    for origin, destination, count in moves:
        if origin not in routes:
            origins.append(origin)
            routes[origin] = [destination]
            groups[origin] = {r.WARBAND: count}
        else:
            extra.append({'origin': origin, 'route': [destination], 'group': {r.WARBAND: count}})
    result = {'command': r.CMD_MARCH, 'sa': 'No SA', 'sa_regions': [], 'regions': origins,
              'details': {'march_plan': {'origins': origins, 'routes': routes,
                                        'destinations': list(dict.fromkeys(m[1] for m in moves)),
                                        'groups': groups, 'extra_groups': extra}}}
    return result

def oracle(s, origins):
    best, checked = 0, 0
    for combination in product(*(list(choices(s, o, n)) for o, n in origins)):
        board = deepcopy(s)
        moves = [m for local in combination for m in local]
        if moves:
            result = execute_free_action_plan(board, r.ARVERNI, march_request(67), action(moves))
            assert result['executed'], result
        checked += 1
        for size in (1, 2):
            for regions in permutations(TARGETS, size):
                from fs_bot.board.pieces import count_pieces
                if all(count_pieces(board, region, r.ARVERNI) and count_pieces(board, region, r.ROMANS)
                       for region in regions):
                    best = max(best, predicted_legion_losses(board, regions))
    return best, checked

results = []
for seed in range(6):
    s = build_initial_state(r.SCENARIO_GREAT_REVOLT, seed=seed)
    s['current_card'], s['next_card'] = 67, 3
    s['non_player_factions'] = {r.ARVERNI, r.ROMANS, r.AEDUI, r.BELGAE}
    origins = [(r.ATREBATES, 2), (r.SEQUANI, 1 + seed % 2), (r.NERVII, 1)]
    for o, count in origins:
        for n in range(count):
            visibility = (r.HIDDEN, r.REVEALED, r.SCOUTED)[(n + seed) % 3]
            place_piece(s, o, r.ARVERNI, r.WARBAND, piece_state=visibility)
    for target in TARGETS:
        place_piece(s, target, r.ROMANS, r.LEGION, 1 + seed % 2, from_legions_track=True)
    if seed >= 3:
        place_piece(s, r.TREVERI, r.ROMANS, r.AUXILIA)
    optimum, checked = oracle(s, origins)
    selected = plan(s)
    observed = selected['predicted_legion_losses'] if selected else 0
    assert observed == optimum, (seed, optimum, observed, selected)
    results.append({'seed': seed, 'enumerated_plans': checked, 'oracle_score': optimum,
                    'planner_score': observed, 'search_states': selected['search_states'] if selected else None})

print(json.dumps(results, indent=2))
