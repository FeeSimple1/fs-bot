Pre-commit local validation of PR-01 through PR-06, 24 October 2026.
The recorded base commit plus dirty source digest identifies the tested tree.
Python sources stayed frozen; documentation changed afterward.
Raw command paths describe this workspace; portable commands appear in the accompanying report.
The manifest hashes every other archive entry.
Remote CI is separate from this pre-push local evidence.
