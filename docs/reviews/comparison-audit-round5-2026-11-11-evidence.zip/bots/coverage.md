# Fifth audit bot partition

Audited Falling Sky `bd30d522e8baa2d303b9e372d7d9c550351e91a5`. Liberty or Death `2991ea279062773548ec390a1da75f3e85381702` supplied implementation clues from `coin-implementation-lessons.md`, especially the silent-bot-degradation, per-space/global-scope, and integrated-path lessons. Falling Sky references alone establish the findings.

## Reproduction

From the audited repository root, run `PYTHONPATH=. python /path/to/evidence/bots/probe_bots.py`. The script prints JSON and asserts the audited faulty observations plus legal controls. All twelve cases pass; repairs should reverse the defect assertions and retain the controls. `probe_bots-output.json` is the original output.

## Coverage and boundaries

- Read current repair state, prior 50/21/15/16 ledgers, source questions and relevant provisional-ruling contexts. No finding relies on an unresolved source question or extends PR-11/PR-12 beyond their named Events.
- Reviewed Aedui high-value trigger, per-Region Diviciacus veto, additional Battle selection, and German threat/Battle selection. Tested public `dispatch_bot_turn` plus public `execute_decision`, with `validate_response` for manually specified legal counterfactual Battles.
- Exercised both base and Ariovistus for the nonexistent-high-value target. Exercised target pollution and named-Leader modifier using separate controls. Command-only context deliberately excludes Ambush/Intimidate forecasting ambiguities.
- All pre/post fixtures pass `validate_state` and `check_structural_integrity`. The permanent Provincia Fort is present, Ally discs are tied to named Tribes, and piece placement uses canonical helpers. These sparse controlled legal-structure positions are not naturally reached sampled games.
- NP4-02 equality regression still passes and is not recounted. The new safety witnesses concern unselected opponents and actual Counterattack multiplication.
- BM4-02 defensive Retreat repairs remain separate; NP5-03 concerns an independent offensive German flowchart estimate.
- Roman A8.8.1 Diviciacus/victory gate was statically inspected and no defect claimed. Roman Settlement ranking repairs were checked in existing regression/source implementation without new dynamically confirmed issues.
- Raw `calculate_losses`/Abatis/Stalwart forecast mismatch suggested by another partition is uncounted here: German selection does not call that function, and no actual wrong consumer was proved.
- Other coarse Aedui/German forecast limitations (retreat alternatives, additional capability modifiers, Successor treatment, SA lookahead) are not counted without specific source-reviewed witnesses.

No production, test, reference or repository documentation file was modified by this partition.
