"""Package this batch only after explicit root acceptance and independent review.

No repository writes. No previous-batch archive, repository checkout, caches,
credentials or unrelated scratch files are included. Every member is read back
and checked against a manifest. Output is exclusive and limited to90MB.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import zipfile

from common import (ROOT, BASELINE_SHA, read, sha, write_json,
                    validate_current, verify_snapshots)


def evidence_identity(run):
    """Bind review to every accepted raw record, source snapshot and result."""
    files = {str(path.relative_to(run)): sha(path.read_bytes())
             for path in sorted(run.rglob('*'))
             if path.is_file() and '__pycache__' not in path.parts
             and path.suffix not in ('.pyc', '.pyo')}
    return {'accepted_attempt': run.name,
            'results_sha256': sha((run / 'results.json').read_bytes()),
            'evidence_sha256': sha(json.dumps(files, sort_keys=True,
                                             separators=(',', ':')).encode())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--accepted-attempt', required=True)
    parser.add_argument('--root-acceptance', type=Path, required=True)
    parser.add_argument('--independent-review', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    run = ROOT / args.accepted_attempt
    if (Path(args.accepted_attempt).name != args.accepted_attempt
            or not args.accepted_attempt.startswith('attempt')):
        parser.error('simple accepted attempt name beginning with attempt required')
    freeze, result = read(run / 'freeze.json'), read(run / 'results.json')
    if not result['passed'] or result['source']['source_sha256'] != freeze['source_sha256']:
        parser.error('accepted attempt lacks matching passing results')
    if not result['balance']['passed']:
        parser.error('the active frozen balance comparison must pass')
    policy = freeze.get('balance_policy', 'original')
    if policy == 'original':
        if freeze['balance_baseline_sha256'] != BASELINE_SHA or freeze['balance_baseline_updated']:
            parser.error('original policy must retain the original815b baseline')
    elif policy == 'reviewed-correction':
        reviewed = result.get('reviewed_balance', {})
        original = result.get('original_balance', {})
        if (freeze.get('original_baseline_sha256') != BASELINE_SHA
                or freeze.get('balance_baseline_updated') is not True
                or not original or not reviewed.get('passed')
                or reviewed.get('exact_records_match') is not True):
            parser.error('reviewed correction requires preserved original comparison and exact fresh baseline match')
    else:
        parser.error('unknown balance policy')
    validate_current(freeze['source_sha256'], freeze)
    verify_snapshots(run, freeze)
    reviewed_identity = evidence_identity(run)
    for label, path in (('root acceptance', args.root_acceptance),
                        ('independent review', args.independent_review)):
        review = read(path)
        if review.get('passed') is not True or review.get('source_sha256') != freeze['source_sha256']:
            parser.error(label + ' must state passed:true and exact source_sha256')
        if any(review.get(key) != value for key, value in reviewed_identity.items()):
            parser.error(label + ' does not bind this exact attempt, results and raw evidence')
    if args.output.exists():
        parser.error('output already exists; never overwrite evidence')
    entries = {}
    # Explicit directory selection: only this new batch, including failed
    # attempt evidence. No recursively discovered archives from past batches.
    for path in sorted(ROOT.glob('*.py')):
        entries['tooling/' + path.name] = path.read_bytes()
    for name in ('starting-source.json', 'tooling-assumptions.json'):
        if (ROOT / name).is_file():
            entries[name] = (ROOT / name).read_bytes()
    for folder in [ROOT / 'parent', *sorted(ROOT.glob('attempt*'))]:
        if not folder.is_dir():
            continue
        for path in sorted(folder.rglob('*')):
            if not path.is_file() or '__pycache__' in path.parts or path.suffix in ('.pyc', '.pyo', '.zip'):
                continue
            entries[str(path.relative_to(ROOT))] = path.read_bytes()
    entries['review/root-acceptance.json'] = args.root_acceptance.read_bytes()
    entries['review/independent-review.json'] = args.independent_review.read_bytes()
    credential_pattern = re.compile(rb'(?:github_pat_[A-Za-z0-9_]{40,}|gh[pousr]_[A-Za-z0-9]{30,})')
    flagged = [name for name, raw in entries.items() if credential_pattern.search(raw)]
    if flagged:
        raise ValueError('credential-like contents in proposed archive members; review locally: ' + repr(flagged))
    manifest = {'source_sha256': freeze['source_sha256'], 'accepted_attempt': args.accepted_attempt,
                **reviewed_identity,
                'parent_commit': freeze['commit'],
                'balance_policy': policy,
                'baseline_sha256': freeze['balance_baseline_sha256'],
                'original_baseline_sha256': BASELINE_SHA,
                'baseline_updated': freeze['balance_baseline_updated'],
                'original_balance_passed': result.get('original_balance', result['balance'])['passed'],
                'active_balance_passed': result['balance']['passed'],
                'local_validation_only': True, 'remote_ci_claimed_pass': False,
                'files': {name: {'sha256': sha(raw), 'bytes': len(raw)}
                          for name, raw in entries.items()}}
    entries['archive-manifest.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    with zipfile.ZipFile(args.output, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in entries.items():
            archive.writestr(name, raw)
    if args.output.stat().st_size >= 90_000_000:
        raise ValueError('archive exceeds conservative90MB cap; preserve and investigate')
    with zipfile.ZipFile(args.output) as archive:
        if archive.testzip() is not None or set(archive.namelist()) != set(entries):
            raise ValueError('archive integrity/member inventory failed')
        for name, raw in entries.items():
            if archive.read(name) != raw:
                raise ValueError('archive read-back differs: ' + name)
    receipt = {'path': str(args.output), 'sha256': sha(args.output.read_bytes()),
               'bytes': args.output.stat().st_size, 'members': len(entries),
               'uncompressed_bytes': sum(map(len, entries.values())), 'readback_verified': True,
               'credential_pattern_findings': 0,
               'source_sha256': freeze['source_sha256'], 'accepted_attempt': args.accepted_attempt}
    write_json(args.output.with_suffix('.receipt.json'), receipt, exclusive=True)
    print(json.dumps(receipt, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
