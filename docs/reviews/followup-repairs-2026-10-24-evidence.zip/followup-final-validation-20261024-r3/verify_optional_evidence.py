"""Independently verify every optional-rule index row and retained trajectory."""
from collections import Counter
import argparse
import hashlib
import json
from pathlib import Path
import sys

from run_optional_diviciacus import digest, summarize

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "fs-bot"
sys.path.insert(0, str(REPO))
from fs_bot import rules_consts as rc
from fs_bot.tools.validation_metadata import source_identity


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--directory", type=Path, default=ROOT / "optional-diviciacus")
    parser.add_argument("--expected-source", required=True)
    args = parser.parse_args()
    root, expected = args.directory, args.expected_source
    metadata = json.loads((root / "metadata.json").read_text())
    summary = json.loads((root / "summary.json").read_text())
    assert metadata["source"]["source_sha256"] == expected
    assert metadata["expected_games"] == 90
    assert metadata["diviciacus_option"] is True
    assert metadata["all_factions_bots"] is True
    assert metadata["hash_seed"] == 0
    records = [json.loads(line) for line in (root / "games.jsonl").read_text().splitlines()]
    scenarios = {rc.SCENARIO_PAX_GALLICA, rc.SCENARIO_RECONQUEST, rc.SCENARIO_GREAT_REVOLT}
    editions = {"legacy", "original", "second-edition"}
    expected_keys = {(scenario, edition, seed) for scenario in scenarios
                     for edition in editions for seed in range(201, 211)}
    assert len(records) == len(expected_keys) == 90
    assert {(r["scenario"], r["card_edition"], r["seed"]) for r in records} == expected_keys
    artifacts = []
    for record in records:
        assert all(record.get(key) is True for key in ("completed", "game_completed", "audit_completed")), record
        assert record["source_sha256"] == expected
        assert record["source_before"]["source_sha256"] == expected
        assert record["source_after"]["source_sha256"] == expected
        assert not any(record.get(key) for key in ("error", "errors", "integrity_findings", "extra_errors", "additional_integrity_findings")), record
        assert not any(d["severity"] != "legal-decline" for d in record["diagnostics"]), record
        path = root / record["artifact"]
        artifact = json.loads(path.read_text())
        assert artifact["record"] == record, path
        assert len(artifact["card_results"]) == len(artifact["card_audits"]) == record["cards"] == record["cards_audited"], path
        assert all(not audit["findings"] for audit in artifact["card_audits"]), path
        assert artifact["initial_state"]["diviciacus_option"] is True, path
        assert artifact["final_state"]["diviciacus_option"] is True, path
        assert digest(artifact["final_state"]) == record["canonical_final_state_sha256"], path
        assert digest({"state": artifact["final_state"], "card_results": artifact["card_results"]}) == record["state_and_trajectory_sha256"], path
        artifacts.append({"path": record["artifact"], "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    assert len(list((root / "games").glob("*.json"))) == 90
    derived = summarize(records, True, expected_keys)
    for key, value in derived.items():
        assert summary[key] == value, key
    assert source_identity()["source_sha256"] == expected
    result = {"records": len(records), "artifact_checks_passed": True, "errors": [],
              "accepted_evidence_directory": str(root), "source_sha256": expected,
              "artifacts": artifacts}
    (ROOT / "optional-evidence-verification.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "artifacts"}))


if __name__ == "__main__":
    main()
