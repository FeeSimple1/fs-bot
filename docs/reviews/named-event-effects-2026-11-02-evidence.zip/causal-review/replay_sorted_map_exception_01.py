"""Replay only the known sorted-map diagnostic codec exception, no full game."""
from copy import deepcopy
import contextlib, gzip, io, json, sys
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parents[1]/'fs-bot'))
from fs_bot import rules_consts as rc
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.cli.dispatcher import _translate_bot_action
from fs_bot.engine.game_engine import ACTION_EVENT
from fs_bot.engine.execute import execute_decision
from fs_bot.state.serialize import encode,decode
from fs_bot.tools.validation_metadata import source_identity
summary=json.loads((root/'first-divergences.json').read_text())
assert source_identity()['source_sha256']==summary['source']['candidate']['source_sha256']
replays=json.loads((root/'candidate-first-row-replays.json').read_text())['replays']
failed=[r for r in replays if not r['exact_replay']]
assert len(failed)==1 and failed[0]['scenario']=='Reconquest of Gaul' and failed[0]['seed']==10
r=failed[0]
entry=next(s for s in summary['pairs'] if (s['scenario'],s['seed'])==(r['scenario'],r['seed']))
pair=json.loads((root/entry['first_rows_file']).read_text())
row=pair['candidate']
state=decode(row['before'])
# trace_games sorted JSON object keys for compact diagnostics. Live setup
# builds spaces in ALL_REGIONS order, which Trade's unused detail list follows.
assert set(state['spaces'])==set(rc.ALL_REGIONS)
state['spaces']={region:state['spaces'][region] for region in rc.ALL_REGIONS}
assert encode(state)==row['before']
state['current_card_id']=state.get('current_card')
state['is_second_eligible']=row['position']=='2nd_eligible'
state['can_play_event']=ACTION_EVENT in row['options']
with contextlib.redirect_stdout(io.StringIO()):
 ba=dispatch_bot_turn(state,row['faction'])
 result={'action':_translate_bot_action(ba,row['options']),'bot_action':ba}
assert encode(result)==row['decision'], 'Restored map-order decision must be exact'
assert encode(state)==row['after'], 'Restored map-order post-state including confirmation/RNG must be exact'
with gzip.open(root/entry['trace_files']['candidate'],'rt') as f:
 trace=json.load(f)['trace']
nextrow=trace[row['index']+1]
assert nextrow['kind']=='execution'
assert encode(state)==nextrow['before']
with contextlib.redirect_stdout(io.StringIO()):
 executed=execute_decision(state,row['faction'],result)
assert encode(executed)==nextrow['result']
assert encode(state)==nextrow['after']
report={'scenario':r['scenario'],'seed':r['seed'],'card':r['card'],'source':source_identity(),
 'cause':'Diagnostic gzip JSON sorts plain dictionary keys. Decoding alphabetized spaces changes the order of unused Trade region detail metadata, which also changes its Diviciacus confirmation signature. Restoring original ALL_REGIONS insertion order reproduces the exact decision and full post-state/RNG.',
 'original_exact_replay_failure_retained':True,'restored_map_order_exact_decision':True,
 'restored_map_order_exact_post_state_and_rng':True,'following_actual_execution_exact_result':True,
 'following_actual_execution_exact_state_and_rng':True,'additional_full_games':0}
(root/'sorted-map-replay-exception.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
