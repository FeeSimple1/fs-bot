# Tenth audit: battle and capability lane

Audited Falling Sky `ae238c6482a792dda98af4f1f9b11abf820a3964`. One confirmed finding, BM10-01 (medium). Production and test files were not changed. All evidence is a controlled legal position, not an estimate of natural-game frequency.

## BM10-01 — Canceled Abatis makes Divination skip a required Aedui Battle

**Expected.** In Ariovistus, Carnutes contains Ariovistus and two German Warbands against two Belgic Warbands and the Belgic Aulerci Ally. Belgae previously acquired Abatis there through A64; Germans subsequently acquired shaded A31. A34 unshaded names non-player Aedui to command Germans. Stalwart cancels the earlier enemy Abatis's Battle effects. The German force therefore inflicts `(1 + 2 × ½) × 2 = 4` standing Losses, or two Losses if the Belgae Retreat. Standing reaches the Ally after both Warbands; Retreat puts the Ally first. Aedui must choose Battle under §8.6.2 as applied through §8.2.3.

**Observed.** The accepted public A34 Event chooses March and moves one German Warband from Carnutes to Pictones. Both Belgic Warbands and Aulerci remain. `calculate_losses` predicts two standing/one Retreat Losses, while the current resolver predicts and executes four/two. The high-value gate incorrectly returns false before reaching the more accurate Battle forecast. Public ordinary German Battle controls, both standing and Retreating, expose the Ally to a Loss and remove it. The canceled Abatis remains physically marked, correctly inert.

**Cause and scope.** `fs_bot/battle/losses.py:267–282` checks the raw Abatis owner when deciding whether to suppress Ariovistus's doubling. This bypasses `defender_abatis_active` at lines69–78. The live Attack path already uses that effective predicate at `fs_bot/battle/resolve.py:413–414,459–462`. `fs_bot/cards/divination_np.py:69–83` consumes the stale calculation, and its lines105–110 reject the Battle before the accurate `predict_battle` path is reached; lines714–720 then fall through to March. Repair should make the public loss estimate use the same effective Abatis protection as live Battle, preserving real Fort/Citadel protection and the counterattack exception. Add an A34 dispatcher regression covering the public consequence, not just formula agreement. Other consumers of `calculate_losses` should be checked within that repair, without treating untested consumers as findings.

**Rule anchors (supplied source only).** `Reference Documents/Ariovistus/A Card Reference:126–131` (Stalwart), `146–150` (Divination), `288–292` (Abatis); `Reference Documents/Ariovistus/Chapter A3:118–131` (German Battle and Ariovistus doubling); `Reference Documents/Chapter 3:311–323` (Gallic Loss calculation and halving); `Reference Documents/Chapter 8:105–118,448–462` (Event-driven flowcharts and Aedui guaranteed high-value Loss). A64 is acquired before A31 to avoid the §5.1.2 later-Event precedence issue. A34 grants a command and supplies no conflicting Battle modifier. No new owner ruling is needed.

| Public A34 control | Expected | Observed | Raw standing / actual standing Losses |
| --- | --- | --- | --- |
| Abatis, then Stalwart, Ariovistus | Battle | March | 2 / 4 |
| Stalwart, no Abatis, Ariovistus | Battle | Battle | 4 / 4 |
| Abatis, no Stalwart, Ariovistus | March | March | 1 / 1 |
| Neither capability, Ariovistus | Battle | Battle | 4 / 4 |
| Abatis then Stalwart, no Ariovistus | March | March | 1 / 1 |

Every case acquires capabilities through validated public `execute_decision` Events. Setup uses `build_initial_state`, `place_piece` and `_ally_tribe`, retains the mandatory Provincia Fort, and uses finite stock with 20 Resources per player faction. Before and after every Event and witness, `validate_state` and `check_structural_integrity` return empty lists. Event and command responses also pass durable turn-response validation. No mocked production function, artificial RNG, or direct piece/count mutation is used. The direct Battle controls use the ordinary public command dispatcher and genuine defender callbacks; every roll remains seeded.

**Prior-audit distinction.** `docs/reviews/comparison-audit-round7-2026-11-11.md:290–292` expressly excluded “A31/Abatis forecast drift” because it lacked a finalized public consequence. This audit supplies that missing consequence in the A34 dispatcher. BM5-02 repaired human Abatis casualty selection; it did not repair Ariovistus forecast doubling. BM5-01, BM6-01 and BM7-02 repaired separate Legio X, opening-effect and Fort-save consumers. No previously counted defect is reopened.

**Limits.** The confirmed result is the A34 unshaded non-player Aedui command choice with an earlier enemy Abatis and later Stalwart. No claim of general event chronology tracking, exhaustive A31 coverage, bot-frequency measurement, or additional physical-ownership defect. Existing unresolved Elite/Optimates/Circumvallation questions remain excluded.

## Comparator inspection and verification

Actually inspected authorized `lod-bot` commit `2991ea279062773548ec390a1da75f3e85381702`: `lod_ai/commands/battle.py:832–854` removes borrowed Common Cause War Parties through their real piece tag and the canonical removal helper; `lod_ai/tests/test_year_end_wi_free_battle.py:1–19,31–77` captures an alternate Battle entry path using a focused deterministic legal-state witness. The engineering lesson checked here is to preserve real ownership in fixtures and validate the outer Event/Command path, since a correct core Battle does not prove a correct alternate entry/decision path. No Liberty or Death rule is imported into Falling Sky.

Reproduce:

```bash
/workspace/scratch/4aba5bd9b1ab/fs-bot/.venv/bin/python /workspace/scratch/521fc7ecea8c/audit10/battle/probe_battle.py --repo /workspace/scratch/521fc7ecea8c/falling-sky
```

`results.json` contains five public A34 cases and two public Battle controls, including acquisition results, predictions, physical before/after counts, observed commands and validation results. `findings.json` supplies the machine-readable finding.
