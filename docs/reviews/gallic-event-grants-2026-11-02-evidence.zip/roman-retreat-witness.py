import importlib.util
import json
import sys
from pathlib import Path

repo, test_path = sys.argv[1:]
sys.path.insert(0, repo)
from fs_bot.engine import execute
spec = importlib.util.spec_from_file_location('retreat_regressions', test_path)
tests = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tests)
results = []
for name, fn in sorted(vars(tests).items()):
    if not name.startswith('test_'):
        continue
    cases = [(True, False), (False, True)] if name.startswith('test_retreat_static') else [()]
    for args in cases:
        try:
            fn(*args)
            outcome = 'pass'
        except AssertionError:
            outcome = 'assertion_failed'
        results.append({'test': name, 'args': args, 'outcome': outcome})
print(json.dumps({'module': execute.__file__, 'results': results}, indent=2))
