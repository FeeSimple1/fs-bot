# Ninth Falling Sky / Liberty or Death comparison audit

**12 November 2026. Eight new repair groups: one high and seven medium. All eight are open.**
The eighth audit remains closed at eleven of eleven groups. This audit changes documentation and evidence only.

Audited commit: `f4c8372c396981c0a31dc6f4545e67f8c6f2e981`. Python source SHA-256: `57a94d20440986063d7f86224a6074fa0ea2ce471e58e24e9c5dd349ec799033` across **616 Python files**, Python 3.12.14. Comparator: `FeeSimple1/lod-bot` at `2991ea279062773548ec390a1da75f3e85381702`.

[Finding ledger](comparison-audit-round9-2026-11-12.json) · [Portable evidence](comparison-audit-round9-2026-11-12-evidence.zip) · [Current status](../current-status.md)

## Method and coverage

Repeated the authorized engineering comparison: alternate consumers, forecast-versus-execution consistency, post-action decisions, complete Event effects, relocation accounting, and durable human views. Liberty or Death supplied engineering patterns only. Game-rule conclusions use supplied Falling Sky/Ariovistus references and the adopted project rulings. All 47 reference files plus canonical constants were inventoried and their hashes remain unchanged. Prior comparative ledgers and relevant earlier follow-ups were checked for duplicates.

Five focused lanes reviewed combat, bot flowcharts, Events, lifecycle, and human frontends; a sixth ran independent validation. Combat review produced no separately counted mechanics finding, and handed the Morbihan display issue to the frontend lane. Each promoted group has executable public-path evidence, controls, source/code review and an independent rerun. The lead additionally reran all four final witness scripts under hash seeds 0 and 987 and required byte-identical results.

Fixtures use canonical piece operations and physical/structural validation. Sparse boards, controlled current-card metadata, and direct public phase entry are disclosed per finding; they are not presented as naturally sampled encounters. Unavailable expansion numeric33 examples were discarded during independent review.

## Confirmed findings

| ID | Priority | Finding |
|---|---|---|
| EV9-01 | Medium | Alpine Tribes non-player placement never selects higher-priority own Allies |
| EV9-02 | Medium | Romans select Lost Eagle without its Fallen Legion or qualifying destination |
| EV9-03 | High | Alpine Tribes places non-Romans in Cisalpina after Gallia Togata forbids them |
| LC9-01 | Medium | Roman non-player Quarters payment planning forgets arrivals in a later-visited Region |
| NP9-01 | Medium | Arverni Devastate forecasts piece presence instead of actual mandatory casualties |
| NP9-02 | Medium | Arverni Rally and Belgic Raid omit newly required post-Command Special Ability transitions |
| UI9-01 | Medium | Enlist Raid omits Baggage Trains' third Warband in the menu and compact plan |
| UI9-02 | Medium | Morbihan's pending combat display restores removed Warbands and mixes physical pieces with synthetic Control |

## Validation

- **10,207 existing tests pass**, no failures/errors/skips; 214.746 seconds JUnit, five workers. Six external anyio/pytest deprecation warnings are preserved.
- **20/20 audited bot games complete**, second-edition seeds 49–52 across all five scenarios. Two Gallic War Interludes; zero errors, inventory/structure findings or ranking issues. All 106 grouped diagnostics / 236 incidents are legal declines.
- **20 mixed-player cases** repeated at hash seeds 0/987 with internal replay: 80 executions, byte-identical JSON and stdout, 722 human turns and 195 Event turns per sample, 178 completed Events, one matching soft partial plan, zero hard findings. The partial is Pax Gallica seed 49; it is not counted as a successful complete human plan.
- Both audited-parent GitHub checks passed: [CI](https://github.com/FeeSimple1/fs-bot/actions/runs/43360419464) and [Package installation](https://github.com/FeeSimple1/fs-bot/actions/runs/43360419406). These are checks for the audited source revision, not for the later documentation commit.
- No new balance matrix or baseline refresh: gameplay sources are unchanged. Clean general tests do not establish rules completeness, and did not detect the directed failures below.

## Suggested repair sequence

| Batch | Findings | Work |
|---|---|---|
| 1 | EV9-01, EV9-02, EV9-03 | Alpine Tribes placement priorities and stacking; Lost Eagle applicability. |
| 2 | LC9-01 | Roman Quarters payments after relocation. |
| 3 | UI9-01, UI9-02 | Enlist Raid quantities and Morbihan pending displays. |
| 4 | NP9-01, NP9-02 | Arverni Devastate forecasts and post-Command Special Ability transitions. |

Turn each defective witness into a source-derived regression, preserve its controls, then run the full suite and appropriate game/replay checks. Explain any outcome drift before changing a balance baseline. NP9-02 groups two distinct post-Command consumers under one repair group; it does not recount the repaired Aedui case.

## Finding details

### EV9-01 — Alpine Tribes non-player placement never selects higher-priority own Allies

**Status:** Open. **Priority:** medium.

**Expected:** On the controlled Ariovistus board, either Romans or Aedui should place three own Allies in three eligible Regions. Chapter 8 gives own Allies priority over other mobile pieces. With no own mobile counters Available, those same three Allied Tribe placements remain possible.

**Observed:** Unmodified dispatch selects A40 unshaded. Romans place six Auxilia; Aedui place nine Warbands; neither places any Ally. When their respective mobile pools are empty, both select and successfully execute the entire Event without any game effect, despite three legal own Ally placements. An explicit source-required Ally plan on the same public executor places three Allies with no errors.

**Cause:** _derive_card_A40 chooses one mobile piece type from faction identity, iterates near Cisalpina, and returns no plan when that pool is empty. It contains no Ally branch. Public NPC execution uses that derived plan.

**Sources:** [Reference Documents/Ariovistus/A Card Reference:196-205](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Ariovistus/A%20Card%20Reference#L196); [Reference Documents/Chapter 8:120-157](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Chapter%208#L120)

**Implementation:** [fs_bot/engine/execute.py:6382-6410](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/engine/execute.py#L6382); [fs_bot/engine/execute.py:3456-3467](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/engine/execute.py#L3456); [fs_bot/cards/card_effects.py:3250-3285](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/cards/card_effects.py#L3250)

**Controls:** Same board, explicit three-Allies plan at Nori/Ubii/Sequani places three own Allies for both factions, including empty-mobile pools. With all nearby Tribes already Allied to Germans, Aedui instead legally place nine Warbands, demonstrating that mobile placement is a valid lower-priority fallback.

**Earlier-audit distinction:** Round-two coverage A40/unshaded was only supported-limited-witness for zero and three-Region mixed category limits; EXP-08 fixed shaded A40 optional quantities. BE7-01 repaired Oppida dependent Citadel placements. None covers A40 NPC omission of the Ally category. This is separate from EV9-03 stacking validation.

**Repair scope:** Derive legal own Allied Tribe choices first under §§8.2.3/8.3.1, respecting one category per Region, three-Region maximum, available counters, ordinary Tribe stacking, live map restrictions and seeded tie selection. Use own mobile fallback only after Ally opportunities are exhausted. Preserve optional human quantity/category choices and shaded behavior.

**Fixture:** build_initial_state Ariovistus seed1, permanent Provincia Fort, ten Resources per seated faction, four NPC seats, current Event A40; no other Forces. Empty-mobile cases place the entire own mobile pool at Carnutes through place_piece. Three-Allies controls use public execute_decision with authored parameters only.

**Limits:** Constructed lawful positions, not sampled encounter rates. Confirmed for Romans and Aedui unshaded A40; no claim about German/Belgic shaded instructions or full priority coverage of all Events.

**Evidence:** `events/probe_events.py`; `events/probe_events-output.json` in the portable archive. The lane ledger and independent review preserve additional detail.

### EV9-02 — Romans select Lost Eagle without its Fallen Legion or qualifying destination

**Status:** Open. **Priority:** medium.

**Expected:** Unshaded numeric33 is ineffective unless a Fallen Legion exists and a playable Region contains both a Roman Legion and a non-Aedui Warband. Romans must continue their flowchart when either prerequisite is absent.

**Observed:** Roman public dispatch selects Lost Eagle and the public executor reports executed=true while board, pieces, resources, Senate and eligibility remain unchanged. Directed Great Revolt/Reconquest cases isolate zero Fallen, no qualifying Warband, and only an Aedui Warband beside a Legion. An untouched Pax physical setup with current Event33 independently produces the zero-Fallen no-op. With the Event disabled, directed boards have a non-Pass Recruit continuation.

**Cause:** The generic PLACES_LEGIONS effectiveness flag accepts any Legion on the track or in Fallen. Numeric33 has no specialized np_event_available branch. The handler correctly refuses placement when Fallen or destination is absent, so the missing preselection check consumes the bot Event opportunity.

**Sources:** [Reference Documents/Card Reference:327-336](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Card%20Reference#L327); [Reference Documents/Chapter 8:30-37](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Chapter%208#L30); [Reference Documents/roman_bot_event_instructions.txt:10-12](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/roman_bot_event_instructions.txt#L10)

**Implementation:** [fs_bot/cards/event_eval.py:335-339](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/cards/event_eval.py#L335); [fs_bot/cards/event_eval.py:1127-1133](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/cards/event_eval.py#L1127); [fs_bot/cards/event_conditions.py:119-125](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/cards/event_conditions.py#L119); [fs_bot/cards/card_effects.py:1402-1433](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/cards/card_effects.py#L1402)

**Controls:** Add only the missing Fallen Legion (via place_piece from track then remove_piece to Fallen) or non-Aedui Warband. On every paired control, the same dispatch/execution now places exactly one Fallen Legion at Sequani. Aedui-only Warbands explicitly do not meet the printed target requirement. Numeric33 is excluded from expansion cases because A33 replaces it.

**Earlier-audit distinction:** WS3-02 concerned shaded Lost Eagle Senate suppression and expiry; it did not inspect unshaded selection. EV8-02 concerned shaded Pompey/Gallia Togata conditional removals. This is a new source-pool/Region prerequisite consumer, with no reopened shaded-lifetime issue.

**Repair scope:** Share a current-state unshaded33 applicability predicate requiring actual Fallen supply plus legal target geometry with NPC Event selection. Preserve human partial/no-effect execution policy, shaded Senate effect, allowed non-Aedui factions, and seeded target choices where applicable.

**Fixture:** Sparse canonical Great Revolt and Reconquest seed1, permanent Provincia Fort, one Legion and two Auxilia at Sequani, optional single Arverni or Aedui Warband and zero/one Fallen. The screen prevents an enemy threat branch preceding Event. All physical preparation uses canonical helpers. Separate untouched Pax setup changes only current card/can-play/NPC metadata.

**Limits:** Base scenarios only. The unchanged physical Pax setup is not a natural drawn-card game trace. No rate or balance inference. Early exploratory numeric33 expansion-current states were rejected from final evidence because the card is replaced in those decks.

**Evidence:** `events/probe_events.py`; `events/probe_events-output.json` in the portable archive. The lane ledger and independent review preserve additional detail.

### EV9-03 — Alpine Tribes places non-Romans in Cisalpina after Gallia Togata forbids them

**Status:** Open. **Priority:** high.

**Expected:** After actual unshaded A5 activation, Cisalpina permits only Roman pieces. A40 may place non-Romans in other legal nearby Regions, but supplies no explicit stacking exception. The Aedui bot must filter Cisalpina out, and the live handler must not place an authored non-Roman cohort there.

**Observed:** Public A5 activation places its marker and three Roman Auxilia. The subsequent ordinary Aedui A40 bot Event places three Aedui Warbands into Cisalpina, although is_region_playable(state,Cisalpina,Aedui) is false. A separate public authored A40 with only that forbidden placement also succeeds. Both preserve physical census and structural invariants, showing why those checks alone miss the rule violation.

**Cause:** A40 derivation queries static scenario/capability geography without recipient faction or Gallia Togata regional marker. Its handler checks only static adjacency to Cisalpina and then calls the physical placement helper. Neither consumer checks the active Roman-only stacking restriction.

**Sources:** [Reference Documents/Ariovistus/A Card Reference:9-13](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Ariovistus/A%20Card%20Reference#L9); [Reference Documents/Ariovistus/A Card Reference:196-205](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Ariovistus/A%20Card%20Reference#L196); [Reference Documents/Chapter 5:25-36](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Chapter%205#L25)

**Implementation:** [fs_bot/engine/execute.py:6390-6407](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/engine/execute.py#L6390); [fs_bot/cards/card_effects.py:3244-3285](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/cards/card_effects.py#L3244); [fs_bot/map/map_data.py:390-403](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/map/map_data.py#L390)

**Controls:** The same authored Aedui placement succeeds before A5, when Cisalpina is legally playable. After A5, three Aedui Warbands in each of Ubii/Sequani/Provincia remain legal; a Roman two-Auxilia placement in Cisalpina also remains legal and increases its three existing Auxilia to five.

**Earlier-audit distinction:** BE5-02 covered Colony creation in forbidden geography; BE5-03 covered Forced Marches recognizing legal Cisalpina. This is the distinct A40 placement producer and live handler bypassing active faction stacking. EV9-01 covers NPC piece-category preference, not location legality; the authored consumer proves the independence.

**Repair scope:** Use recipient-aware live geography and stacking for A40 candidate generation and every placement category in the live handler; preserve legitimate Roman Cisalpina placement, nearby non-Roman placements, category/Region caps, optional quantities and event transaction behavior. The geography check must read active Event markers rather than only capability IDs.

**Fixture:** build_initial_state Ariovistus seed1 with permanent Provincia Fort, current A5, four NPC seats and ten Resources. Invoke real public A5 unshaded execution, set current Event A40, then invoke unmodified Aedui dispatch plus public execution. No marker is manually assigned.

**Limits:** Confirmed in Ariovistus after a real A5 activation. No Interlude or base-game A40 reachability claim. Chapter5 §5.1.1 expressly requires Event text to change stacking; A40 geographic range alone is not such an override under §5.1.2.

**Evidence:** `events/probe_events.py`; `events/probe_events-output.json` in the portable archive. The lane ledger and independent review preserve additional detail.

### LC9-01 — Roman non-player Quarters payment planning forgets arrivals in a later-visited Region

**Status:** Open. **Priority:** medium.

**Expected:** After moving 2 Auxilia from Devastated Morini into isolated Roman Nervii with 1 Auxilia, pay 6 of 20 Resources for all 3, without rolls.

**Observed:** Unmodified public quarters_phase moves the 2 Auxilia, pays 2 Resources for only 1, rolls [2,5] for the others, and removes 1. All five scenarios reproduce with clean before/after census and structure.

**Cause:** The planner accumulates arrivals in remaining[hop], then later overwrites that entry with the original destination cohort during its normal Region loop.

**Sources:** [Reference Documents/Chapter 8:974-981](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Chapter%208#L974); [Reference Documents/Chapter 6:84-98](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Chapter%206#L84); [Reference Documents/Ariovistus/Chapter A6:139-142](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Ariovistus/Chapter%20A6#L139)

**Implementation:** [fs_bot/bots/roman_bot.py:1873-1925](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/bots/roman_bot.py#L1873); [fs_bot/bots/roman_bot.py:1936-1949](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/bots/roman_bot.py#L1936); [fs_bot/engine/winter.py:404-428](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/engine/winter.py#L404); [fs_bot/engine/winter.py:578-609](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/engine/winter.py#L578); [fs_bot/engine/quarters.py:510-570](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/engine/quarters.py#L510)

**Controls:** Same public physical plan with pay3; automatic reverse-direction relocation; automatic stationary stack; automatic insufficient-budget case; validated save/load repeat in all five scenarios.

**Earlier-audit distinction:** WS7-01 was non-Roman planner wiring; original WS-F05 was human visibility; Q12 wired Romans. None reported this arrival-accounting overwrite.

**Repair scope:** Derive payment counts from the legal post-relocation board or preserve original stayers plus all arrivals. Preserve free garrisons, Supply agreements, affordability, visibility, ordered payments and human choices.

**Limits:** Controlled public Quarters fixtures, no natural encounter-frequency claim. No production changes, monkeypatches or manual physical-count edits. No full-suite/game-matrix execution by this lane.

**Evidence:** `lifecycle/probe_lifecycle.py`; `lifecycle/results.json` in the portable archive. The lane ledger and independent review preserve additional detail.

### NP9-01 — Arverni Devastate forecasts piece presence instead of actual mandatory casualties

**Status:** Open. **Priority:** medium.

**Expected:** Devastate only when it forces removal of a Legion or two Auxilia, or at least one enemy piece and at least as many Roman plus Aedui pieces combined as Arverni pieces.

**Observed:** Public Rally+Devastate removes one of four Arverni Warbands against one Legion or two Auxilia, removes no Romans, and places a Devastated marker. Conversely, four Arverni versus three Aedui misses lawful one-for-one Devastation.

**Cause:** _check_devastate uses roman_legions>0, roman_auxilia>=2, and comparisons of total pieces instead of one-quarter/one-third removal counts; live rederivation reuses it.

**Sources:** [Reference Documents/Chapter 8:645-655](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Chapter%208#L645); [Reference Documents/Chapter 4:121-137](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Chapter%204#L121); [Reference Documents/Chapter 8:701-711](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Chapter%208#L701)

**Implementation:** [fs_bot/bots/arverni_bot.py:1271-1289](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/bots/arverni_bot.py#L1271); [fs_bot/engine/execute.py:4980-4999](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/engine/execute.py#L4980); [fs_bot/engine/devastate_losses.py:10-22](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/engine/devastate_losses.py#L10)

**Controls:** Three Legions correctly lose one; one Auxilium correctly causes no SA; Command-only suppresses SA. Direct validated Devastate on a detached post-Rally copy of the false-negative witness removes one Arverni and one Aedui.

**Earlier-audit distinction:** Not CMD-DEVASTATE-LOSSES physical choices, CM2-03 repeated Regions, or NP6-03 Roman Rampage threat. No prior ledger repairs Arverni Devastate removal forecasts.

**Repair scope:** Compute mandatory casualty totals and forced casualty types, compare actual Roman+Aedui/Arverni removals, and share across pre-Command/live selection without changing human casualty ownership.

**Limits:** Controlled legal Great Revolt boards, public dispatch+execution, no whole-game occurrence-rate claim; no Battle/capability/dice/borrowed forces. Canonical physical helpers and clean pre/post integrity.

**Evidence:** `bots/probe_bots.py`; `bots/probe_bots-output.json` in the portable archive. The lane ledger and independent review preserve additional detail.

### NP9-02 — Arverni Rally and Belgic Raid omit newly required post-Command Special Ability transitions

**Status:** Open. **Priority:** medium.

**Expected:** After Rally, Arverni resolve newly legal Entreat. After Raid leaves no Hidden Warbands for Rampage, Belgae continue to legal Enlist.

**Observed:** Arverni Rally creates two Hidden Warbands beside a Roman Auxilium but retains No SA; Roman remains and Resources 7 instead of replacement and 6. Belgic Raid Reveals its two Warbands, live Rampage declines, and two adjacent German Warbands stay Revealed instead of Enlist March hiding them.

**Cause:** Arverni SA is selected on the pre-Rally board and No SA blocks live rederivation. Belgic live Rampage handles stale plans with an endpoint decline instead of the printed Enlist fallback.

**Sources:** [Reference Documents/Chapter 8:661-675](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Chapter%208#L661); [Reference Documents/Chapter 8:710-711](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Chapter%208#L710); [Reference Documents/Chapter 4:107-120](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Chapter%204#L107); [Reference Documents/Chapter 8:304-338](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Chapter%208#L304); [Reference Documents/Chapter 8:376-389](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Chapter%208#L376)

**Implementation:** [fs_bot/bots/arverni_bot.py:928-940](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/bots/arverni_bot.py#L928); [fs_bot/engine/execute.py:4784-4786](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/engine/execute.py#L4784); [fs_bot/engine/execute.py:4824-4829](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/engine/execute.py#L4824); [fs_bot/bots/belgae_bot.py:959-974](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/bots/belgae_bot.py#L959); [fs_bot/engine/execute.py:4893-4908](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/engine/execute.py#L4893)

**Controls:** Natural positive controls: initial Hidden Arverni allows Entreat; third Belgic Hidden Warband survives Raid to Rampage. No-target and Command-only negatives. Identical failing-board execution controls change only SA label to Entreat/Enlist; existing live executor derives targets and yields source-required results.

**Earlier-audit distinction:** NP8-02 repaired Aedui Rally and its Druids grant, not Arverni or Belgic consumers. Grouped as one new late-state SA repair group with two proven subcases; no old Aedui recurrence counted.

**Repair scope:** Forecast or defer the complete printed post-Command SA chains, preserving genuine Command-only and human choices, one-SA limit, SoP action, resources, Event/Britannia restrictions.

**Limits:** Two controlled base-game ordinary Command consumers. SA-label controls explicitly identified as source-required inputs, not natural dispatch. No monkeypatch, human callback, or whole-game frequency claim. All census/structural checks clean.

**Evidence:** `bots/probe_bots.py`; `bots/probe_bots-output.json` in the portable archive. The lane ledger and independent review preserve additional detail.

### UI9-01 — Enlist Raid omits Baggage Trains' third Warband in the menu and compact plan

**Status:** Open. **Priority:** medium.

**Expected:** With shaded Baggage Trains owned by Germans, Enlist may use three Hidden German Warbands in one Raid. Ariovistus' four-piece Enlist cap does not restrict that legal quantity.

**Observed:** The supported terminal menu offers only two or one and rejects an attempted three. Public execute_decision refuses the compact count=3 Enlist subplan, leaving Germans at ten Resources; the equivalent explicit three gain actions succeeds, revealing all three and increasing Resources to thirteen.

**Cause:** Both human_plan's quantity menu and enlist_free's compact plan validation hard-code a maximum of two instead of using the acting German faction's Capability-aware Raid limit.

**Sources:** [Reference Documents/Card Reference:75-82](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Card%20Reference#L75); [Reference Documents/Chapter 4:199-222](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Chapter%204#L199); [Reference Documents/Ariovistus/Chapter A4:44-53](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Ariovistus/Chapter%20A4#L44)

**Implementation:** [fs_bot/cli/human_plan.py:900-909](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/cli/human_plan.py#L900); [fs_bot/commands/enlist_free.py:183-195](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/commands/enlist_free.py#L183)

**Controls:** Capability-owned count=2 succeeds; no-Capability expanded count=3 correctly refuses; no-Capability count=2 succeeds. The actual supported terminal planner and CLI reactive frontend leave live state unchanged while collecting the plan.

**Earlier-audit distinction:** NP7-02 repaired ordinary non-player Raid planners; FE6-02 concerned multiple Enlist March groups. Neither covers this human Enlist Raid menu or its compact plan parser.

**Repair scope:** Share max_raiders_per_region for Germans across menu and compact validation, cap by present Hidden Warbands and the expansion Enlist limit, and preserve actual Capability ownership, base/expansion rules and explicit-action validation.

**Fixture:** Sparse canonical Ariovistus seed19; permanent Provincia Fort, Boduognatus with three Hidden German Warbands at Sugambri, one Hidden Belgic Warband at Carnutes. Germans acquire numeric8 shaded through the public Event executor.

**Limits:** Controlled legal positions, not natural frequency. The ordinary terminal plan can use only two; the expanded programmatic plan is a successful control, not evidence that the menu supports three. The outer raw executor completes its Command and reports the refused SA separately. No NPC-planning or whole-session transactional failure is claimed.

**Evidence:** `frontend/probe_frontend.py`; `frontend/probe_frontend-output.json` in the portable archive. The lane ledger and independent review preserve additional detail.

### UI9-02 — Morbihan's pending combat display restores removed Warbands and mixes physical pieces with synthetic Control

**Status:** Open. **Priority:** medium.

**Expected:** Pending human decisions should show the surviving physical Warbands at their real origins and Control consistent with that physical board, while explaining their temporary combined Battle presence separately.

**Observed:** At the real SeatSession Roman casualty prompt after A20 shaded and Slingers opening fire, the survivor ledger has three Arverni Warbands and Available has 32, but board, snapshot and active-force summary show the original four. The region table labels Carnutes Arverni-controlled while showing only two Roman Auxilia there, and Pictones Aedui-controlled while showing two Arverni versus one Aedui. Saved pending sessions reproduce the discrepancy.

**Cause:** morbihan_display.physical_view and active-force text use original sources instead of survivors. The region table combines physical-view piece cells with the raw synthetic Battle state's Control.

**Sources:** [Reference Documents/Ariovistus/A Card Reference:51-56](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Ariovistus/A%20Card%20Reference#L51); [Reference Documents/Card Reference:125-136](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Card%20Reference#L125); [Reference Documents/Chapter 1:85-104,192-205](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/Reference%20Documents/Chapter%201#L85); [docs/provisional-rulings.md:282](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/docs/provisional-rulings.md#L282)

**Implementation:** [fs_bot/cards/morbihan_display.py:86-110](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/cards/morbihan_display.py#L86); [fs_bot/cli/display.py:147-153](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/cli/display.py#L147); [fs_bot/cli/display.py:516-523](https://github.com/FeeSimple1/fs-bot/blob/f4c8372c396981c0a31dc6f4545e67f8c6f2e981/fs_bot/cli/display.py#L516)

**Controls:** Without Slingers the original four-Warband count is correct, but synthetic table Control remains wrong. In both cases pre-pause rollback, pending ID, validated save/load, accepted Slingers/casualty journal replay, and resumed final state exactly match uninterrupted execution. Final accounting is correct and all pre/post census/structure checks are empty.

**Earlier-audit distinction:** BM7-01 wired opening capabilities into fixed Battles and BM8-01 corrected Archers mechanics. This is a separate surviving display consumer; casualty accounting and final piece returns are not corrupted. PR-09 supplies only the already-adopted origin tie-break, not a new display ruling.

**Repair scope:** Build physical counts, controls and active-force summaries from current surviving cohorts. Keep physical and temporary combat state distinct without moving live counters or changing accepted decisions, pending identity or replay.

**Fixture:** Ariovistus seed7, permanent Provincia Fort; Arverni Veneti Ally and two Hidden Warbands each at Veneti/Pictones; Aedui two Warbands at Veneti and one at Pictones; two Revealed Roman Auxilia at Carnutes. Numeric13 and A20 execute publicly; Roman decisions use the actual durable session and transaction machinery.

**Limits:** Controlled real pending-decision consumer, not a natural full-game trace. Presentation defect only: the final game state and physical inventory are correct. Original sources may remain for historical explanation but must not be labeled current forces.

**Evidence:** `frontend/probe_frontend.py`; `frontend/probe_frontend-output.json` in the portable archive. The lane ledger and independent review preserve additional detail.

## Reproduction and exclusions

Extract the evidence and run `python run_witnesses.py --repo /path/to/fs-bot` with the audited Python sources. The runner requires their exact byte digest, copies probes into temporary directories, repeats each at hash 0/987 and compares preserved JSON. These assertions describe observed defects and should change after repair. `SHA256SUMS` covers every other archive member.

Known Circumvallation persistence work, the documented Aedui subsidy approximation, and unresolved Optimates/Elite/Trade and other source questions remain separate. No new ruling was required. The current-Event/Stalwart lead was excluded under section5.1.2; a reproducible observation alone is not enough to label behavior wrong. Combat checks passed 347 existing targeted regressions without adding a new combat finding.

The Morbihan defect concerns what the human sees while deciding: final casualty accounting and resumed state remain correct. The Quarters witness is a controlled public phase, not a whole sampled Winter. No bug frequency, balance impact or bug-free claim follows from these samples.
