#!/usr/bin/env python3
"""Reproduce the recorded defects on the audited Python source revision."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

EXPECTED = '3c047ebcfef915efef8e1da308cd63484b1e6c735b8aba8e5c095de2c5d106b9'
CASES = [
    ('battle', 'probe_battle.py', 'probe_battle-output.json', False),
    ('bots', 'probe_bots.py', 'probe_bots-output.json', False),
    ('events', 'probe_events.py', 'probe_events-output.json', False),
    ('frontend', 'probe_winter_campaign.py', 'probe_winter_campaign-output.json', True),
    ('lifecycle', 'witness_lifecycle.py', 'results.json', True),
]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    args = parser.parse_args()
    repo = args.repo.resolve()
    evidence = Path(__file__).resolve().parent
    digest = hashlib.sha256()
    files = sorted((repo / 'fs_bot').rglob('*.py'))
    for path in files:
        digest.update(str(path.relative_to(repo)).encode() + b'\0' + path.read_bytes())
    if len(files) != 611 or digest.hexdigest() != EXPECTED:
        raise SystemExit('Source differs from audited revision; these assertions pin defects, not repaired expectations.')
    results = []
    for lane, script, output, writes_output in CASES:
        outputs = []
        for seed in (0, 987):
            with tempfile.TemporaryDirectory(prefix='fs-audit8-') as temporary:
                work = Path(temporary) / lane
                work.mkdir()
                shutil.copy2(evidence / lane / script, work / script)
                command = [sys.executable, str(work / script)]
                if lane == 'bots':
                    command += ['--repo', str(repo)]
                env = dict(os.environ, PYTHONPATH=str(repo), PYTHONHASHSEED=str(seed),
                           PYTHONDONTWRITEBYTECODE='1')
                run = subprocess.run(command, cwd=repo, env=env, capture_output=True, check=True)
                data = (work / output).read_bytes() if writes_output else run.stdout
                json.loads(data)
                outputs.append(data)
        expected = (evidence / lane / output).read_bytes()
        assert outputs[0] == outputs[1] == expected, f'{lane}: output differs'
        results.append({'lane': lane, 'hash_seeds': [0, 987], 'exact_match': True,
                        'output_sha256': hashlib.sha256(expected).hexdigest()})
    print(json.dumps({'source_sha256': EXPECTED, 'python_files': len(files),
                      'all_witnesses_match': True, 'results': results}, indent=2))

if __name__ == '__main__':
    main()
