"""Record each unchanged balance game, then run its normal guardrail."""
from concurrent.futures import ProcessPoolExecutor
import json
from pathlib import Path
import sys

from fs_bot import rules_consts as rc
from fs_bot.tools import balance_smoke
from fs_bot.tools.validation_metadata import source_identity


def play(key):
    return balance_smoke.play_bot_game(*key)


def main():
    out = Path(sys.argv[1])
    source = source_identity()
    keys = [(scenario, seed) for scenario in rc.ALL_SCENARIOS for seed in range(1, 21)]
    with ProcessPoolExecutor(max_workers=4) as workers:
        played = dict(zip(keys, workers.map(play, keys)))
    assert source_identity() == source
    balance_smoke.play_bot_game = lambda scenario, seed: played[scenario, seed]
    status = balance_smoke.main(['--seeds', '1-20'])
    out.write_text(json.dumps({'source': source,
                               'games': {f'{s}|{n}': r for (s, n), r in played.items()},
                               'guardrail_exit': status}, indent=2) + '\n')
    return status


if __name__ == '__main__':
    raise SystemExit(main())
