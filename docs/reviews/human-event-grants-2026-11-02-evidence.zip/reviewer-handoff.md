# Independent Event-grant review

Reviewer: `/root/event_grant_review`. Read-only production review of EXP-01–06; no repository edits or commits. Source base d3241e7. Read CLAUDE.md and supplied protected rules/card references; PR01–09 adopted. This is an intermediate review record, not a claim that the combined final tree passed validation.

## Source decisions

- §§5.1/5.1.3: executor chooses unless text names another; carry out all possible accepted text. NPC selection priorities do not limit concrete human legality.
- A21/A57: first Battle mandatory when possible, no Retreat; second optional in the actual first Region, Retreat allowed. Static Forces remain legal attackers/defenders. Ordinary A70/A31 capability exceptions remain.
- A19 shaded: executor chooses origin/destination; all Roman mobile pieces March one adjacent step to Germans. NPC German no-Fort/outnumber filters are not human restrictions. Actual March hiding applies; one hop has no intermediate Harassment.
- A20/A58: optional compound belongs to Romans regardless of executor. A20 preserves ordinary Harassment; A58 suppresses it. Both suppress the stated enemy Rally rolls/windows. Specific NP card instructions do not override the ordinary Roman §8.8.5 safe-Seize priorities; §8.3.4 ties remain seeded.
- A29: freshly placed German Warbands Raid; executor directs Raid and its intrinsic optional Intimidate. Physical German ownership remains.
- A69: newly placed surviving Warbands receive the full-Loss bonus; residents still participate at their normal rate. Human legal zero-Loss Ambushes remain available; NP default retains the established positive-Loss filter. §4.3.3 says Ambush Regions “begin with” the required Hidden advantage.
- A67: single leading “may” permits beneficiary to decline the entire sequence before changes. After acceptance, March and later Command are mandatory when mechanically possible. §3.1 requires one or more Regions; base67 Tips and parallel Card72 Tips require actual movement “into”, excluding an in-place March. Contrast Card6's independently optional clauses. Final Hide covers all friendly target residents and arrivals; a Scouted piece loses its marker once, becoming Revealed.
- A67 German whole-grant/default refusal remains distinct from an accepted human sequence. The specific German instruction calls for safe movement “to take Germanic Control of a Region with player pieces” and then Battle that player. Under §§8.2.1/8.2.3, preserve the established no-plan refusal when the old German resolver returns an empty result; do not append a new standalone Hide effect to that refusal. An actually executed NP sequence and an explicitly accepted human sequence retain the final Hide. This narrow preservation was source-checked after the main review; the movement agent owns its regression and final validation.

## Reviewed and resolved boundaries

- SeatSession's engine-owned `validate_default_response` gate validates explicit defaults before normalization. Raw callback None remains the legacy fallback contract; durable missing/invalid input must stay pending. Mandatory no-NP-default cases have tests.
- Human Event Battle requests own no-Retreat/SA/actor authority; clients cannot spoof exceptions. Detached previews do not consume live RNG or callbacks.
- A58 static-only Battle legality repaired. Specialized Roman acceptance/Battle/Seize collectors route through common display/board handling.
- Roman Seize privileges live in a temporary engine-owned, Region-limited scope. Unrelated scopes suppress/restore it without adding an empty persistent field. Client exception fields and namespaced command_parts spoofing are rejected.
- Main's combined A19/EXP01/Roman free-action, CLI and SeatSession dispatch was inspected: no lost hooks found.
- EXP01 reoffers the same mandatory Battle phase after explicit Diviciacus refusal; raw None preserves one-attempt fallback.
- A29/A69 exact physical cohort ledgers and human versus NP target/default split reviewed. A69's trusted `_require_ambush` keyword rechecks cohort survival and ordinary Ambush legality after command/Region timing, before defense. It does not downgrade invalid ordinary prerequisites to Battle. Explicit defensive Diviciacus cancellation is preserved. Later retreat-choice/attack windows occur after Battle begins, so do not undo established Ambush status; loss cohorts remain live.
- A67 frozen-origin implementation reviewed: original groups/unused pieces have exact owner/visibility cohorts, aggregate reservations, origin Hide once, surviving groups transferred into movement, no arrival reused or rehidden at a later selected origin. Ordinary `_march_with_harassment` defaults remain unchanged. Current focused tests cover preformation removal, moving-group removal, future-origin removal, split groups, Diviciacus and Harassment. Review found the mandatory retry issue below.

## Final delta checks — resolved

1. **Roman mandatory stale request after target removal — fixed and rereviewed.** Reproduced accepted A58 explicit default with Romans at Nervii and final enemy removed at battle_command. First attempt failed, then same stale allowed_regions request was reissued despite no remaining legal Battle. The final `_component` now rebuilds the request from the current board at each iteration, skips a now-impossible component before Seize, and preserves retry attempt/error when alternatives remain. Four live-window regressions cover no remaining target and a remaining static-only target in both scenarios. Delta review passed.
2. **A67 mandatory Diviciacus refusal — fixed and rereviewed.** Reproduced Romans with two own Auxilia at Atrebates, Aedui Warbands/Diviciacus present, accepted March two to Nervii with requested loan. Aedui refusal previously returned executed=False and advanced to Command/Hide although own two remained a legal March. Final `resolve_stage` distinguishes explicit plans/defaults from raw None, retries failed explicit stages while a fresh mechanical witness exists, and preserves owner/stage/attempt/error. March and Command refusal regressions plus durable refused-March pending/save/load/replay cover the correction. Delta review passed.

**Final independent disposition:** no remaining blocking finding in the scoped EXP-01–06 source/architecture review. Production-agent final full suites and the parent's final integrated-tree validation remain separate evidence; this reviewer did not rerun those suites or claim a final integrated revision.

No broader 44-finding re-audit was performed. Parent owns final integrated tests, documentation and audit disposition.
