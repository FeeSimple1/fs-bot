import json
from collections import Counter
from fs_bot.tools import player_fuzz as pf
from fs_bot import rules_consts as rc
original=pf._compare_dry_vs_live
observed=[]
def inspect(res,seats,expected):
    walk=Counter()
    for card in (res or {}).get('card_results',[]):
        for faction,record in (card.get('turn_result',{}).get('actions_taken') or {}).items():
            if faction not in seats:
                continue
            key=(card.get('card'),faction)
            index=walk[key];walk[key]+=1
            wanted=expected.get(key+(index,))
            live=pf._sig(record.get('execution'))
            if wanted is not None and wanted==live and (wanted[3] or (wanted[4] and wanted[4][1])):
                observed.append({'card':card.get('card'),'faction':faction,
                    'signature':pf._sanitize(wanted),'execution':pf._sanitize(record.get('execution'))})
    return original(res,seats,expected)
pf._compare_dry_vs_live=inspect
result=pf.play_game(rc.SCENARIO_PAX_GALLICA,2)
print(json.dumps({'record':result,'partial_details':observed},indent=2))
