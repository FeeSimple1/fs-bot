"""Package reviewed final evidence without relabeling superseded outcomes."""
import argparse
from copy import deepcopy
import gzip
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'fs-bot'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--attempt', required=True)
args = parser.parse_args()
assert Path(args.attempt).name == args.attempt
RUN = ROOT / args.attempt

def read(path):
    return json.loads(path.read_text())

original = read(RUN / 'results.json')
acceptance = read(RUN / 'baseline-acceptance.json')
candidate_review = read(RUN / 'independent-candidate-review.json')
balance = read(RUN / 'post-baseline/balance.status.json')
tests = read(RUN / 'post-baseline/tests.status.json')
assert original['pytest']['exit_code'] == 0
assert all(f.startswith('balance/') for f in original['failures'])
assert candidate_review['candidate_data_audit_passed']
assert balance['passed'] and balance['exit_code'] == tests['exit_code'] == 0
assert balance['band_percentage_points'] == acceptance['band_percentage_points'] == 15
assert not balance['band_changed'] and not acceptance['band_changed']
baseline = (REPO / 'fs_bot/tools/balance_baseline.json').read_bytes()
assert baseline == (RUN / 'balance-candidate.json').read_bytes()
assert hashlib.sha256(baseline).hexdigest() == acceptance['new_baseline_sha256'] == balance['baseline_sha256']
assert hashlib.sha256((RUN / 'results.json').read_bytes()).hexdigest() == acceptance['original_results_sha256']
sys.path.insert(0, str(REPO))
from fs_bot.tools.validation_metadata import source_identity
digest = original['source']['source_sha256']
assert source_identity()['source_sha256'] == digest
assert tests['source']['source_sha256'] == tests['source_after']['source_sha256'] == digest
assert balance['source']['source_sha256'] == balance['source_after']['source_sha256'] == digest
suites = ET.parse(RUN / 'post-baseline/tests.xml').getroot().findall('.//testsuite')
counts = {key: sum(int(s.attrib[key]) for s in suites)
          for key in ('tests', 'errors', 'failures', 'skipped')}
assert counts['tests'] == original['pytest']['tests']
assert counts['errors'] == counts['failures'] == counts['skipped'] == 0

summary = {key: deepcopy(original[key]) for key in
           ('source', 'bot_batches', 'mixed_seats', 'strict_census', 'runner', 'pytest')}
summary.update(schema_version=1, accepted_attempt=args.attempt, passed=True,
               acceptance='Source-backed repairs, clean implementation matrix, independently reviewed baseline refresh, and fresh unchanged-band verification.',
               original_verification_passed=original['passed'],
               original_verification_failures=original['failures'],
               original_verification_path=f'{args.attempt}/results.json',
               original_balance=original['balance'],
               reviewed_baseline_refresh=acceptance,
               post_refresh_balance={k:v for k,v in balance.items() if k != 'records'},
               post_refresh_pytest=dict(counts, exit_code=tests['exit_code'],
                                        elapsed_seconds=tests['elapsed_seconds']),
               matrix_bot_games=200, fresh_balance_games=100,
               matrix_plus_fresh_balance_bot_executions=300,
               evidence_archive='second-batch-2026-10-27-evidence.zip',
               limits=['Original guardrail failure remains failed and preserved.',
                       'Diagnostic traces and superseded attempts are not pooled with the accepted matrix.',
                       'First behavioral divergence is not proof that it alone determines a winner.',
                       'Census records aggregate success rather than individual successful-game rows.',
                       'These checks do not establish exhaustive human-choice or rules coverage.',
                       'Q-O38 remains unresolved; prior unshaded behavior and six provisional rulings remain unchanged.'])
summary['superseded_attempts'] = []
for path in sorted(ROOT.glob('attempt*')):
    if not path.is_dir() or path == RUN or not (path / 'source.json').exists():
        continue
    summary['superseded_attempts'].append({'attempt': path.name,
        'source': read(path / 'source.json'), 'accepted': False,
        'disposition_file': str((path / 'disposition.json').relative_to(ROOT))
                            if (path / 'disposition.json').exists() else None})
payload = (json.dumps(summary, indent=2, sort_keys=True) + '\n').encode()
(ROOT / 'final-results.json').write_bytes(payload)
dest = REPO / 'docs/reviews'
(dest / 'second-batch-2026-10-27-results.json').write_bytes(payload)

files = sorted(p for p in ROOT.rglob('*') if p.is_file()
               and '__pycache__' not in p.parts and p.suffix not in ('.pyc', '.zip')
               and p.name != 'ARCHIVE_MANIFEST.json')
manifest = {}
for path in files:
    content = path.read_bytes()
    inspected = gzip.decompress(content) if path.suffix == '.gz' else content
    assert not any(secret in inspected for secret in (b'github_' + b'pat_', b'gh' + b'p_')), path.name
    manifest[str(path.relative_to(ROOT))] = {'bytes': len(content),
        'sha256': hashlib.sha256(content).hexdigest()}
manifest_path = ROOT / 'ARCHIVE_MANIFEST.json'
manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
archive = dest / 'second-batch-2026-10-27-evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in files + [manifest_path]:
        output.write(path, str(path.relative_to(ROOT)))
with zipfile.ZipFile(archive) as checked:
    assert checked.testzip() is None
    for name, item in manifest.items():
        content = checked.read(name)
        assert len(content) == item['bytes'] and hashlib.sha256(content).hexdigest() == item['sha256']
print(json.dumps({'accepted_attempt': args.attempt, 'tests': counts['tests'],
                  'archive_files': len(files)+1, 'archive_bytes': archive.stat().st_size,
                  'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}, indent=2))
