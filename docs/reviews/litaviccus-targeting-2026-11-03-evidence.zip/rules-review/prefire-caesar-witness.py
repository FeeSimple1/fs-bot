from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece
from fs_bot.cards.capabilities import activate_capability
from fs_bot.cards import litaviccus_np as policy
from fs_bot.state.state_schema import build_initial_state,validate_state
import json
s=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=45)
s['non_player_factions']={rc.BELGAE,rc.ROMANS,rc.ARVERNI,rc.AEDUI}
place_piece(s,rc.CARNUTES,rc.BELGAE,rc.LEADER,leader_name=rc.AMBIORIX)
place_piece(s,rc.CARNUTES,rc.BELGAE,rc.WARBAND,3)
place_piece(s,rc.CARNUTES,rc.ROMANS,rc.AUXILIA,2)
place_piece(s,rc.CARNUTES,rc.ROMANS,rc.LEGION,3,from_legions_track=True)
place_piece(s,rc.CARNUTES,rc.ROMANS,rc.LEADER,leader_name=rc.CAESAR)
activate_capability(s,13,rc.EVENT_UNSHADED)
print(json.dumps({'integrity':validate_state(s),'outcomes':list(policy._outcomes(s,rc.CARNUTES)),'plan':policy.plan(s)},indent=2))
