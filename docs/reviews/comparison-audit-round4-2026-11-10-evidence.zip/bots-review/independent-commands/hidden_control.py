"""Independent legal no-destination Retreat control; run with FS on PYTHONPATH."""
import json
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces_by_state
from fs_bot.board.control import refresh_all_control
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND
from fs_bot.engine.agent import RETREAT, RETREAT_DISPOSITION

state = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=1)
place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
state['non_player_factions'] = set()
state['resources'][rc.ROMANS] = 20
place_piece(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA, 4)
place_piece(state, rc.CARNUTES, rc.AEDUI, rc.WARBAND, 2)
refresh_all_control(state)
requests = []

def agent(board, faction, request):
    if faction != rc.AEDUI:
        return None
    if request['kind'] == RETREAT:
        requests.append({'kind': request['kind'], 'legal_regions': request['legal_regions']})
        return {'retreat': True, 'region': None}
    if request['kind'] == RETREAT_DISPOSITION:
        requests.append({'kind': request['kind'], 'legal_regions': request['legal_regions']})
        return {'region': None, 'stay_hidden_warbands': 1, 'stay_leader': False}
    return None

state['decision_agent'] = agent
assert not validate_state(state) + check_structural_integrity(state)
result = execute_decision(state, rc.ROMANS, {
    'action': ACTION_COMMAND,
    'player_action': {
        'command': rc.CMD_BATTLE, 'sa': 'No SA', 'regions': [rc.CARNUTES],
        'details': {'battle_plan': [{'region': rc.CARNUTES, 'target': rc.AEDUI}]},
    },
})
assert result['executed'] and not result['errors'], result
assert count_pieces_by_state(state, rc.CARNUTES, rc.AEDUI, rc.WARBAND, rc.HIDDEN) == 1
assert not validate_state(state) + check_structural_integrity(state)
assert all(not request['legal_regions'] for request in requests)
print(json.dumps({'requests': requests, 'result': result,
                  'hidden_survivors': 1, 'integrity_errors': []}, indent=2))
