import io,json,copy
from fs_bot import rules_consts as rc
from fs_bot.state.setup import setup_scenario
from fs_bot.state.serialize import encode,decode
from fs_bot.state.state_schema import validate_state
from fs_bot.tools.seat_session import SeatSession,DecisionPending,validate_response
from fs_bot.cli.display import HumanTurnDisplay
from fs_bot.engine.game_engine import resolve_card_turn,ACTION_COMMAND,ACTION_LIMITED_COMMAND,ACTION_EVENT,ACTION_PASS
from fs_bot.board.pieces import count_pieces


def position():
    st=setup_scenario(rc.SCENARIO_GREAT_REVOLT,seed=4,human_factions=(rc.ROMANS,rc.BELGAE))
    st['non_player_factions']={rc.ARVERNI,rc.AEDUI}
    st['current_card']=st['current_card_id']=16
    st['next_card']=None
    st['eligibility']={f:rc.ELIGIBLE if f in (rc.ROMANS,rc.BELGAE) else rc.INELIGIBLE for f in st['eligibility']}
    assert validate_state(st)==[]
    return st

st=position(); session=SeatSession(st,{'seat':rc.BELGAE},[],HumanTurnDisplay(io.StringIO()))
def driver(state,faction,options,position):
    if faction==rc.ROMANS:
        return {'action':ACTION_COMMAND,'player_action':{'command':rc.CMD_SEIZE,'regions':[rc.PROVINCIA],
                     'details':{'disperse_tribes':{rc.PROVINCIA:[]}}}}
    return session.ask(state,faction,{'kind':'turn','options':options,'position':position})
driver.transaction_checkpoint=session.checkpoint;driver.transaction_restore=session.restore;driver.transaction_complete=session.transaction_complete
try: resolve_card_turn(st,driver,execute=True)
except DecisionPending: pass
pending=session.data['pending'];request=decode(pending['request']);assert request['options']==[ACTION_LIMITED_COMMAND,ACTION_PASS],request
response={'action':ACTION_LIMITED_COMMAND,'player_action':{'command':'Event','details':{'event_params':{'target_region':rc.PROVINCIA}}}}
assert validate_response(st,request,response)==response
before=count_pieces(st,rc.PROVINCIA,rc.ROMANS,rc.AUXILIA)
session.import_inbox({'decision_id':pending['id'],'response':response})
result=resolve_card_turn(st,driver,execute=True);session.finish()
after=count_pieces(st,rc.PROVINCIA,rc.ROMANS,rc.AUXILIA)
assert after==before+6,(before,after,result)
assert result['actions_taken'][rc.BELGAE]['execution']['command']=='Event'
print(json.dumps({'case':'event_as_limited_command','offered':request['options'],'submitted':response,'roman_auxilia_before':before,'roman_auxilia_after':after,'executed':result['actions_taken'][rc.BELGAE]['execution']},default=str))

st=position();request={'kind':'turn','faction':rc.ROMANS,'options':[ACTION_EVENT]}
response={'action':ACTION_EVENT,'player_action':{'command':'Event','details':{'card_id':13,'text_preference':'unshaded'}}}
assert validate_response(st,request,response)==response
from fs_bot.engine.execute import execute_decision
result=execute_decision(st,rc.ROMANS,response)
assert result['executed'] and 13 in st['capabilities'],result
print(json.dumps({'case':'off_card_event','current_card':st['current_card'],'submitted':response,'capabilities':st['capabilities'],'result':result},default=str))

st=position(); request={'kind':'turn','faction':rc.ROMANS,'options':[ACTION_EVENT]}
response={'action':ACTION_EVENT,'player_action':{'command':'Event','sa':rc.SA_SCOUT,'sa_regions':[rc.SEQUANI],
 'details':{'event_params':{'target_region':rc.PROVINCIA},'scout_plan':{'auxilia_moves':[{'from_region':rc.PROVINCIA,'to_region':rc.SEQUANI,'count':1,'piece_state':rc.HIDDEN}],'scout_targets':[]}}}}
assert validate_response(st,request,response)==response
before=count_pieces(st,rc.SEQUANI,rc.ROMANS,rc.AUXILIA)
result=execute_decision(st,rc.ROMANS,response)
after=count_pieces(st,rc.SEQUANI,rc.ROMANS,rc.AUXILIA)
assert after==before+1 and result['sa_execution']['executed'],result
print(json.dumps({'case':'ungranted_special_ability_with_event','current_card':st['current_card'],'submitted':response,'destination_auxilia_before':before,'destination_auxilia_after':after,'result':result},default=str))
