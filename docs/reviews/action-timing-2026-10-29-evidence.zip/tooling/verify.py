"""Independently verify action-timing evidence without simulating any games."""
from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
import statistics
import subprocess
import xml.etree.ElementTree as ET

from common import (verify_test_inventory, execution_environment,
                    protected_files, runtime_files, check_baseline_policy,
                    ORIGINAL_BASELINE_SHA)

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "fs-bot"
BOT_SCENARIOS = ("Pax Gallica?", "Reconquest of Gaul", "The Great Revolt", "Ariovistus", "The Gallic War")
OTHER_SCENARIOS = ("Pax Gallica?", "The Great Revolt", "Reconquest of Gaul", "Ariovistus", "The Gallic War")
FACTIONS = ("Romans", "Arverni", "Aedui", "Belgae", "Germans")


def read(path):
    return json.loads(path.read_text())


def digest():
    value = hashlib.sha256()
    for path in sorted((REPO / "fs_bot").rglob("*.py")):
        value.update(str(path.relative_to(REPO)).encode() + b"\0" + path.read_bytes())
    return value.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attempt", default="attempt1")
    parser.add_argument("--report-name", help="fresh explicit JSON report name; preserve earlier verification results")
    parser.add_argument("--test-prefix", default="tests", help="explicit full-suite output prefix; earlier failures remain untouched")
    parser.add_argument("--allow-committed-tree", action="store_true",
                        help="evidence remains tied to its recorded base commit after the repairs are committed")
    args = parser.parse_args()
    args.skip_pytest = False
    run = ROOT / args.attempt
    if any(Path(v).name != v for v in (args.attempt, args.test_prefix)) or (args.report_name and Path(args.report_name).name != args.report_name):
        parser.error("simple path components required")
    failures = []
    checked = 0

    def check(condition, message):
        nonlocal checked
        checked += 1
        if not condition:
            failures.append(message)

    source = read(run / "source.json")
    freeze = read(run / "freeze.json")
    report = {"source": source, "attempt": args.attempt, "failures": failures,
              "bot_batches": {}, "pytest_checked": not args.skip_pytest}
    check(digest() == source["source_sha256"], "current Python source digest differs from frozen source")
    current_commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip()
    if not args.allow_committed_tree:
        check(current_commit == source["commit"], "current commit differs from frozen commit")
    check(freeze["source_sha256"] == source["source_sha256"], "freeze/source digest mismatch")
    check(source["commit"] == "5ee485e43132e9080a083efece79c66af80afef8", "wrong parent for action-timing scope")
    policy = freeze.get('balance_policy', 'original')
    try:
        review_identity = check_baseline_policy(freeze, source['source_sha256'], run=run)
    except (ValueError, KeyError, OSError) as exc:
        check(False, 'baseline policy proof failed: ' + str(exc))
        review_identity = None
    report['balance_policy'] = policy
    report['baseline_review_identity'] = review_identity
    start = read(ROOT / "starting-source.json")
    check(freeze["protected_files"] == start["protected_files"] and len(freeze["protected_files"]) == 48,
          "protected source inventory differs from parent")
    check(protected_files() == freeze['protected_files'], 'live protected inventory changed')
    check(runtime_files() == freeze['runtime_files'], 'live runtime/configuration inventory changed')
    for label, directory in (("fixture_files", "fixture-source"), ("protected_files", "protected-source"),
                              ("runtime_files", "runtime-source")):
        frozen = {str(p.relative_to(run / directory)): hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in sorted((run / directory).rglob("*")) if p.is_file()}
        check(frozen == freeze[label], f"frozen {label} bytes missing/changed")
        for name, expected in freeze[label].items():
            check((REPO / name).is_file() and hashlib.sha256((REPO / name).read_bytes()).hexdigest() == expected,
                  f"live {label} differs: {name}")
    live_fixtures = {str(p.relative_to(REPO)): hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in sorted((REPO / "fs_bot/tests/fixtures").rglob("*"))
                     if p.is_file() and p.suffix not in (".py", ".pyc", ".pyo") and "__pycache__" not in p.parts}
    check(live_fixtures == freeze["fixture_files"], "fixture file inventory changed")
    for name, expected in freeze["tooling_files"].items():
        check(hashlib.sha256((run / "tooling" / name).read_bytes()).hexdigest() == expected,
              f"frozen tooling changed: {name}")
    report["protected_sources"] = {"files": len(freeze["protected_files"]), "unchanged": freeze["protected_files"] == start["protected_files"]}
    report["fixtures"] = {"files": len(freeze["fixture_files"]), "frozen_bytes_verified": True}
    check(freeze["balance_band_exact"] == "3/20", "freeze changed the balance tolerance")
    snapshot = (run / "balance-baseline.json").read_bytes()
    original_path = run / 'original-balance-baseline.json'
    original_snapshot = original_path.read_bytes() if original_path.exists() else snapshot
    committed = subprocess.check_output(["git", "show", f"{source['commit']}:fs_bot/tools/balance_baseline.json"], cwd=REPO)
    live_baseline = (REPO / "fs_bot/tools/balance_baseline.json").read_bytes()
    check(original_snapshot == committed, "original baseline snapshot differs from frozen committed baseline")
    check(hashlib.sha256(original_snapshot).hexdigest() == ORIGINAL_BASELINE_SHA,
          'original815b baseline bytes were not preserved')
    check(snapshot == live_baseline, "active baseline differs from its frozen snapshot")
    check(hashlib.sha256(snapshot).hexdigest() == freeze["balance_baseline_sha256"], "baseline hash mismatch")
    fixture_snapshot = (run / "fixture-manifest.json").read_bytes()
    check(hashlib.sha256(fixture_snapshot).hexdigest() == freeze["fixture_manifest_sha256"], "frozen fixture manifest digest mismatch")
    check(fixture_snapshot == (REPO / "fs_bot/tests/fixtures/compatibility_8ef88e2/manifest.json").read_bytes(), "fixture manifest changed since frozen matrix")
    check(set(freeze["source_files"]) == {str(p.relative_to(REPO)) for p in (REPO / "fs_bot").rglob("*.py")}, "source file inventory differs from freeze")
    check(freeze["matrix"] == {"bot_games": 150, "mixed_unique_cases": 20, "mixed_executions_with_replay": 80, "census_unique_cases": 25, "census_executions": 50, "hash_seeds": [0, 7]}, "frozen matrix differs from agreed action-timing coverage")
    frozen_snapshot = {str(p.relative_to(run / "python-source")): hashlib.sha256(p.read_bytes()).hexdigest()
                       for p in sorted((run / "python-source").rglob("*.py"))}
    check(frozen_snapshot == freeze["source_files"], "complete per-attempt frozen source bytes missing or changed")
    for name, expected_hash in freeze["source_files"].items():
        check((REPO / name).is_file() and hashlib.sha256((REPO / name).read_bytes()).hexdigest() == expected_hash,
              f"source file changed: {name}")

    def metadata(meta, tool, scenarios, seeds, edition, context):
        expected = {"metadata_version": 1, "tool": tool, "commit": source["commit"],
                    "source_sha256": source["source_sha256"], "scenarios": list(scenarios),
                    "seeds": list(seeds), "card_edition": edition, "python": freeze["python"]}
        for key, value in expected.items():
            check(meta.get(key) == value, f"{context}: metadata {key} mismatch")
        check(type(meta.get("dirty")) is bool, f"{context}: missing dirty provenance")

    ledger = read(run / "runner-status.json")
    expected_names = {"bots-legacy", "bots-original", "bots-second-edition", "fuzz0", "fuzz7", "census0", "census7"}
    check(ledger["passed"] is True, "runner did not pass")
    check(len(ledger["jobs"]) == 7 and {j["name"] for j in ledger["jobs"]} == expected_names,
          "runner job coverage differs from seven required commands")
    planned = {j["name"]: j for j in freeze["jobs"]}
    for job in ledger["jobs"]:
        name = job["name"]
        check(job == read(run / f"{name}.status.json"), f"{name}: status differs from ledger")
        check(job["exit_code"] == 0 and job.get("runner_exit_code") == 0 and job["source_changed"] is False, f"{name}: nonzero exit or changed source")
        check(job["source_sha256_before"] == job["source_sha256_after"] == source["source_sha256"],
              f"{name}: source differs between process boundaries")
        check(job["argv"] == planned[name]["argv"], f"{name}: argv differs from frozen plan")
        check(job["environment"]["PYTHONHASHSEED"] == str(planned[name]["hash_seed"]), f"{name}: hash seed mismatch")
        check(job['environment'] == execution_environment(planned[name]['hash_seed']),
              f'{name}: execution environment differs from sanitized runner')
        check((run / f"{name}.log").is_file() and (run / f"{name}.log").stat().st_size > 0, f"{name}: missing log")
    report["runner"] = {"passed": ledger["passed"], "job_exit_codes": {j["name"]: j["exit_code"] for j in ledger["jobs"]}}

    all_rows = []
    for edition, seeds in (("legacy", range(1, 21)), ("original", range(201, 206)),
                           ("second-edition", range(201, 206))):
        context = "bots-" + edition
        folder = run / context
        meta = read(folder / "metadata.json")
        metadata(meta, "run_batch", BOT_SCENARIOS, seeds, edition, context)
        check(meta.get("hash_seed") == 0 and meta.get("all_factions_bots") is True,
              f"{context}: incorrect hash seed or seat configuration")
        check(meta.get("games_per_scenario") == len(seeds), f"{context}: wrong games_per_scenario")
        rows = [json.loads(line) for line in (folder / "games.jsonl").read_text().splitlines()]
        expected = {(s, n, edition) for s in BOT_SCENARIOS for n in seeds}
        actual = [(r.get("scenario"), r.get("seed"), r.get("card_edition")) for r in rows]
        check(len(actual) == len(set(actual)) and set(actual) == expected, f"{context}: incorrect exact record coverage")
        summary = read(folder / "summary.json")
        check(set(summary) == set(BOT_SCENARIOS), f"{context}: incorrect summary scenarios")
        for row in rows:
            name = f"{context}/{row['scenario']}/{row['seed']}"
            for flag in ("completed", "game_completed", "audit_completed"):
                check(row.get(flag) is True, f"{name}: {flag} is not true")
            check(not row.get("error") and row.get("errors") == [], f"{name}: errors present or missing errors field")
            check(row.get("integrity_findings") == [], f"{name}: integrity findings present or missing field")
            check(row.get("source_sha256") == source["source_sha256"] and row.get("commit") == source["commit"],
                  f"{name}: mixed source identity")
            check(type(row.get("cards")) is int and row["cards"] > 0, f"{name}: invalid card count")
            ending = row.get("ending_scenario")
            check(ending in BOT_SCENARIOS, f"{name}: invalid ending scenario")
            eligible = set(FACTIONS) - ({"Arverni"} if ending in ("Ariovistus", "The Gallic War") else {"Germans"})
            ranking = row.get("final_ranking", [])
            ranking_valid = (isinstance(ranking, list) and len(ranking) == 4
                             and all(isinstance(r, list) and len(r) == 2 and type(r[1]) is int for r in ranking)
                             and {r[0] for r in ranking} == eligible)
            check(ranking_valid, f"{name}: malformed/ineligible final ranking")
            if ranking_valid:
                check(row.get("engine_final_ranking") == ranking, f"{name}: emitted and recomputed rankings differ")
                precedence = ["Romans", "Germans", "Aedui", "Belgae"] if "Germans" in eligible else ["Romans", "Arverni", "Aedui", "Belgae"]
                check(ranking == sorted(ranking, key=lambda item: (-item[1], precedence.index(item[0]))), f"{name}: all-NP equal-margin precedence mismatch")
                check([r[1] for r in ranking] == sorted((r[1] for r in ranking), reverse=True), f"{name}: unsorted margins")
                check(row.get("winner") == ranking[0][0] == row.get("highest_margin_leader"), f"{name}: winner disagreement")
                check(row.get("threshold_qualifiers") == [f for f, margin in ranking if margin > 0], f"{name}: qualifier disagreement")
            check(row.get("winner_differs_from_highest_margin") is False and row.get("engine_ranking_output_missing") is False,
                  f"{name}: invalid ranking audit flags")
            check(bool(re.fullmatch(r"[0-9a-f]{64}", row.get("final_state_sha256", ""))), f"{name}: invalid final-state digest")
            check(row.get("termination") in ("optimates", "threshold", "final-winter-margin"), f"{name}: invalid termination")
            for field in ("diagnostics", "diagnostic_occurrences"):
                check(isinstance(row.get(field), list), f"{name}: {field} missing")
                check(all(d.get("severity") == "legal-decline" for d in row.get(field, [])), f"{name}: nonlegal {field}")
            diagnostic_fields = ("severity", "kind", "message", "faction", "command")
            grouped = Counter()
            for d in row["diagnostics"]:
                check(type(d.get("count")) is int and d["count"] > 0, f"{name}: invalid diagnostic count")
                grouped[tuple(d.get(k) for k in diagnostic_fields)] += d["count"]
            check(grouped == Counter(tuple(d.get(k) for k in diagnostic_fields) for d in row["diagnostic_occurrences"]), f"{name}: diagnostic group/occurrence mismatch")
            check(row.get("diagnostic_coverage") == "returned-cards-only", f"{name}: diagnostic scope absent")
            check(type(row.get("ended_on_final_winter")) is bool, f"{name}: missing final-Winter flag")
            check(row["termination"] != "final-winter-margin" or (row["ended_on_final_winter"] is True and not row["threshold_qualifiers"]), f"{name}: final Winter termination inconsistent")
            check(type(row.get("interlude_completed")) is bool, f"{name}: missing Interlude flag")
            if row["scenario"] != "The Gallic War":
                check(ending == row["scenario"] and row["interlude_completed"] is False, f"{name}: unexpected scenario transition")
            elif ending != "The Gallic War":
                check(ending == "Pax Gallica?" and row["interlude_completed"] is True, f"{name}: inconsistent Interlude transition")
        for scenario in BOT_SCENARIOS:
            subset = [r for r in rows if r["scenario"] == scenario]
            accepted = [r for r in subset if r["completed"] and r["audit_completed"] and not r.get("error")
                        and not r["errors"] and not r["integrity_findings"]
                        and all(d["severity"] == "legal-decline" for d in r["diagnostics"])]
            total = summary[scenario]
            checks = {"card_edition": edition, "attempted": len(subset), "completed": len(accepted),
                      "engine_completed": sum(r["game_completed"] for r in subset), "crashes": sum(bool(r.get("error") or r["errors"]) for r in subset), "integrity_flagged_games": sum(bool(r["integrity_findings"]) for r in subset),
                      "winner_margin_disagreements": 0,
                      "wins": dict(Counter(r["winner"] for r in accepted)),
                      "highest_margin_leaders": dict(Counter(r["highest_margin_leader"] for r in accepted)),
                      "terminations": dict(Counter(r["termination"] for r in accepted)),
                      "interlude_games": sum(r["interlude_completed"] for r in subset),
                      "cards_mean": statistics.mean(r["cards"] for r in accepted) if accepted else None,
                      "cards_median": statistics.median(r["cards"] for r in accepted) if accepted else None,
                      "cards_range": [min(r["cards"] for r in accepted), max(r["cards"] for r in accepted)] if accepted else None,
                      "winters": dict(Counter(str(r["winters"]) for r in accepted)),
                      "decisions": sum(r["decisions"] for r in subset),
                      "simultaneous_threshold_games": sum(len(r["threshold_qualifiers"]) > 1 for r in accepted)}
            incidents, diagnosed_games = Counter(), Counter()
            for row in subset:
                for diagnostic in row["diagnostics"]:
                    incidents[diagnostic["severity"]] += diagnostic["count"]
                diagnosed_games.update({d["severity"] for d in row["diagnostics"]})
            checks.update(diagnostic_incidents=dict(incidents), diagnostic_games=dict(diagnosed_games))
            for key, value in checks.items():
                check(total.get(key) == value, f"{context}/{scenario}: summary {key} disagrees with records")
        report["bot_batches"][edition] = {"games": len(rows), "seeds": list(seeds), "scenarios": list(BOT_SCENARIOS),
             "accepted": sum(r["completed"] for r in rows),
             "winner_counts": {s: dict(Counter(r["winner"] for r in rows if r["scenario"] == s)) for s in BOT_SCENARIOS},
             "interlude_completed": sum(r["interlude_completed"] for r in rows)}
        all_rows.extend(rows)

    def compare_baseline(raw, gate_name, *, label, required, updated):
        baseline = json.loads(raw)['games']
        baseline_sha = hashlib.sha256(raw).hexdigest()
        check(set(baseline) == {f'{s}|{n}' for s in BOT_SCENARIOS for n in range(1, 21)},
              label + ': baseline does not contain exact100 legacy keys')
        comparisons, changed, maximum, breaches = {}, [], Fraction(0), []
        for scenario in BOT_SCENARIOS:
            rows = [r for r in all_rows if r['scenario'] == scenario and r['card_edition'] == 'legacy']
            before = Counter(baseline[f'{scenario}|{seed}']['winner'] for seed in range(1, 21))
            after = Counter(r['winner'] for r in rows)
            deltas = {f: Fraction(after[f] - before[f], 20) for f in FACTIONS}
            maximum = max(maximum, *(abs(d) for d in deltas.values()))
            for faction, delta in deltas.items():
                if abs(delta) > Fraction(3, 20):
                    breaches.append({'scenario': scenario, 'faction': faction, 'exact_change': str(delta)})
                    if required:
                        check(False, f'{label}/{scenario}/{faction}: drift {delta} exceeds unchanged3/20 band')
            seeds = sorted(r['seed'] for r in rows if baseline[f"{scenario}|{r['seed']}"]['winner'] != r['winner'])
            changed.extend(f'{scenario}|{seed}' for seed in seeds)
            comparisons[scenario] = {'before': dict(before), 'after': dict(after),
                'exact_rate_change': {f: str(d) for f, d in deltas.items()},
                'percentage_point_change': {f: float(d * 100) for f, d in deltas.items()},
                'changed_winner_seeds': seeds}
        changed_records = [{'key': f"{r['scenario']}|{r['seed']}",
            'before': baseline[f"{r['scenario']}|{r['seed']}"],
            'after': {key: r[key] for key in ('winner', 'cards')}} for r in all_rows
            if r['card_edition'] == 'legacy' and baseline[f"{r['scenario']}|{r['seed']}"] !=
            {key: r[key] for key in ('winner', 'cards')}]
        changed_records.sort(key=lambda row: row['key'])
        gate = read(run / gate_name)
        check(gate['source_sha256'] == source['source_sha256'] and gate['baseline_sha256'] == baseline_sha,
              label + ': gate provenance mismatch')
        check(gate['changed_records'] == len(changed_records) and gate['changed_winners'] == len(changed),
              label + ': gate outcome counts mismatch')
        check(gate['changed'] == changed_records and gate['breaches'] == breaches,
              label + ': gate changed records/breaches mismatch')
        check(gate['passed'] == (not breaches), label + ': gate outcome mismatch')
        check(gate.get('exact_records_match') == (not changed_records), label + ': exact-match flag mismatch')
        check(gate.get('baseline_updated') is updated, label + ': baseline update flag mismatch')
        return {'passed': not breaches, 'baseline_sha256': baseline_sha, 'band_percentage_points': 15,
            'exact_band': '3/20', 'baseline_updated': updated, 'maximum_absolute_drift': str(maximum),
            'breaches': breaches, 'changed_winner_count': len(changed), 'changed_winners': changed,
            'scenarios': comparisons, 'changed_record_count': len(changed_records),
            'changed_card_count_count': sum(r['before']['cards'] != r['after']['cards'] for r in changed_records),
            'changed_records': changed_records, 'exact_records_match': not changed_records,
            'same_audited_legacy_games_reused': True, 'extra_balance_games': 0}

    original_balance = compare_baseline(original_snapshot, 'original-balance-gate.json',
        label='original_balance', required=policy == 'original', updated=False)
    active_balance = compare_baseline(snapshot, 'legacy-balance-gate.json',
        label='active_balance', required=True, updated=freeze['balance_baseline_updated'])
    report['original_balance'] = original_balance
    report['balance'] = active_balance
    if policy == 'reviewed-correction':
        check(active_balance['exact_records_match'] is True,
              'fresh legacy100 winner/card records differ from reviewed same-source baseline')
        report['reviewed_balance'] = active_balance
    maximum = Fraction(active_balance['maximum_absolute_drift'])
    changed = active_balance['changed_winners']

    fuzz = [read(run / f"fuzz{h}.json") for h in (0, 7)]
    check(fuzz[0] == fuzz[1], "mixed-seat JSON differs across hash seeds 0 and 7")
    for hash_seed, data in zip((0, 7), fuzz):
        context = f"fuzz{hash_seed}"
        metadata(data["metadata"], "player_fuzz", OTHER_SCENARIOS, range(1, 5), "legacy", context)
        for option in ("reactive", "events", "replay"):
            check(data["metadata"].get(option) is True, f"{context}: {option} disabled")
        rows = data["records"]
        actual = [(r["scenario"], r["seed"]) for r in rows]
        expected = {(s, n) for s in OTHER_SCENARIOS for n in range(1, 5)}
        check(len(actual) == len(set(actual)) == data["games"] == 20 and set(actual) == expected,
              f"{context}: incorrect exact scenario/seed coverage")
        check(data["hard_findings"] == 0 and not data["by_kind"], f"{context}: hard findings")
        check(all(r["game_completed"] is True and not r["findings"] and r["card_edition"] == "legacy" for r in rows),
              f"{context}: incomplete game, findings, or incorrect edition")
        for field in ("human_turns", "event_turns", "events_ok", "partial"):
            check(data[field] == sum(r[field] for r in rows), f"{context}: {field} disagrees with records")
        check(data["partial"] == 0, f"{context}: partial random plans present")
        batch = hashlib.sha256()
        for row in rows:
            check(bool(re.fullmatch(r"[0-9a-f]{16}", row["digest"])), f"{context}: malformed replay digest")
            check(type(row["rejected"]) is int and row["rejected"] >= 0, f"{context}: invalid rejected count")
            batch.update(f"{row['scenario']}|{row['seed']}|legacy|{row['digest']}".encode())
        check(batch.hexdigest() == data["batch_digest"], f"{context}: batch digest does not match case digests")
    report["mixed_seats"] = {"unique_cases": 20, "executions_including_replay": 80, "hash_seeds": [0, 7],
          "cross_hash_equal": fuzz[0] == fuzz[1], "hard_findings": fuzz[0]["hard_findings"], "partial": fuzz[0]["partial"],
          "rejected_random_plans_per_hash": sum(r["rejected"] for r in fuzz[0]["records"]),
          "batch_digest": fuzz[0]["batch_digest"],
          "limitation": "Rejected random plans are disclosed separately; completion is not complete human-choice coverage."}

    census = [read(run / f"census{h}.json") for h in (0, 7)]
    check(census[0] == census[1], "strict census JSON differs across hash seeds 0 and 7")
    for hash_seed, data in zip((0, 7), census):
        context = f"census{hash_seed}"
        metadata(data["metadata"], "error_census", OTHER_SCENARIOS, range(1, 6), "legacy", context)
        check(data["metadata"]["strict"] is True, f"{context}: strict mode disabled")
        check(data["games"] == data["completed"] == 25 and data["failed_games"] == 0 and data["failures"] == [],
              f"{context}: failed or missing games")
        check(data["illegal"] == 0 and all(k == "legal-decline" or n == 0 for k, n in data["by_severity"].items()),
              f"{context}: defect-class diagnostics")
        counts = Counter()
        for incident in data["counts"]:
            check(incident["severity"] == "legal-decline", f"{context}: nonlegal incident")
            counts[incident["severity"]] += incident["n"]
        check(dict(counts) == data["by_severity"] and sum(counts.values()) == data["total"],
              f"{context}: diagnostic aggregates disagree")
    report["strict_census"] = {"unique_cases": 25, "executions": 50, "hash_seeds": [0, 7],
          "cross_hash_equal": census[0] == census[1], "defects": sum(n for k, n in census[0]["by_severity"].items() if k != "legal-decline"),
          "by_severity_per_hash": census[0]["by_severity"],
          "coverage_evidence": "Exact tool metadata plus aggregate completion; the census tool does not emit per-game success records."}
    if not args.skip_pytest:
        try:
            exact_suite = verify_test_inventory(run, freeze, prefix=args.test_prefix)
        except (ValueError, KeyError, OSError) as exc:
            check(False, 'exact pytest collection failed: ' + str(exc))
        else:
            check(exact_suite['exact_collection'] is True, 'pytest collection was not exact')
            report['pytest_collection'] = exact_suite
        test_status = read(run / f"{args.test_prefix}.status.json")
        check(test_status.get("runner_exit_code") == 0 and test_status.get("source_changed") is False,
              "pytest runner failed or source changed")
        check(test_status.get("exit_code") == 0, "pytest process exit status is not zero")
        check(test_status.get("balance_baseline_sha256") == hashlib.sha256(live_baseline).hexdigest(),
              "final pytest baseline differs from live explicitly verified baseline")
        check(test_status.get("fixture_files_before") == test_status.get("fixture_files_after")
              and bool(test_status.get("fixture_files_before")), "final pytest fixture inventory changed or is absent")
        for path, expected in test_status.get("fixture_files_after", {}).items():
            check(hashlib.sha256((REPO / path).read_bytes()).hexdigest() == expected,
                  f"final pytest fixture changed: {path}")
        report["pytest_prefix"] = args.test_prefix
        check(test_status.get("source", {}).get("source_sha256") == source["source_sha256"]
              and test_status.get("source_after", {}).get("source_sha256") == source["source_sha256"],
              "pytest source identity differs across execution boundaries")
        check(test_status.get("source", {}).get("commit") == source["commit"]
              and test_status.get("source_after", {}).get("commit") == source["commit"],
              "pytest commit differs from frozen commit")
        check(test_status.get("cwd") == str(REPO) and "pytest" in test_status.get("argv", []),
              "pytest launch metadata is incomplete")
        suites = ET.parse(run / f"{args.test_prefix}.xml").getroot().findall(".//testsuite")
        check(bool(suites), "JUnit has no test suite")
        totals = {key: sum(int(s.attrib[key]) for s in suites) for key in ("tests", "errors", "failures", "skipped")}
        check(totals["tests"] >= 5777 and all(totals[k] == 0 for k in ("errors", "failures", "skipped")),
              "full suite has failures/skips or fewer tests than the parent5ee485e baseline")
        totals["time"] = sum(float(s.attrib["time"]) for s in suites)
        totals["exit_code"] = test_status["exit_code"]
        report["pytest"] = totals
    report["checks"] = checked
    report["passed"] = not failures
    report["accepted_attempt"] = args.attempt if report["passed"] else None
    output = run / (args.report_name or ("matrix-results.json" if args.skip_pytest else "results.json"))
    if output.exists():
        parser.error("report exists; preserve it and supply a fresh --report-name")
    output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k not in ("bot_batches", "balance")}, indent=2))
    print(f"Bot records: {len(all_rows)}; maximum balance drift: {maximum}; changed winners: {len(changed)}")
    print(f"Independent verification {'PASS' if report['passed'] else 'FAIL'}: {output}")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
