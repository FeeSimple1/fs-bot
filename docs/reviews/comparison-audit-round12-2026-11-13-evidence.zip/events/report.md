# Twelfth audit Events lane

The audit confirms two medium-priority Event groups on Falling Sky `1563e41d84f61dfce43ce4008106eca2a1639aed`, using Liberty or Death `2991ea279062773548ec390a1da75f3e85381702` as the implementation comparator. Production code and references were read without editing. The thirteen provisional rulings were checked and do not alter these printed targeting requirements.

## Verified results

| Finding | Failure | Controlled proof |
|---|---|---|
| EV12-01 | Unshaded Sappers drains the wrong faction in seven cases and wastes the Event with no Citadel in two cases. | Seven exact-target controls, a correct Roman Arverni-priority control and two normal Command controls. |
| EV12-02 | Drought chooses Morini in twelve cases and removes NP Belgae. Six Roman cases also lose their own Auxilia. | Twelve exact Carnutes controls remove the legal player enemy and preserve Morini. |

The finalized `probe_events.py` uses production setup, canonical piece/tribe helpers, natural `dispatch_bot_turn`, public `execute_decision`, and explicit player-plan controls. Every execution passes physical census and structural integrity. Queries preserve the full encoded board and RNG. Hash seeds 0 and 987 produce byte-identical JSON. There are 43 executions, comprising 21 failure witnesses and 22 controls. These positions demonstrate the paths and carry no claim about encounter rates.

## Comparison inspected

`lod_ai/bots/base_bot.py` lines459–553 previews Event effects on detached copies, completes known grants, and removes nonsemantic state before comparing effects. This suggests checking Sappers' actual Resource effect during admission. `lod_ai/cards/effects/late_war.py` lines110–144 constructs eligible Waxhaws targets and ranks the printed priorities before a seeded tie choice. `lod_ai/cards/effects/early_war.py` lines313–333 selects replacement targets from the actual eligible force. These latter patterns expose Drought and Sappers' map/faction-order fallbacks. The games' distinct rules are resolved from Falling Sky's supplied references.

## Coverage and excluded observations

The read review covered Event parameter dispatch, the per-card derivation registry, generic effectiveness flags, current Event condition guards, Sappers, Drought, Camulogenus, Celtic Rites, The Province, named-owner effects, exact-piece Event plans and the recent Shifting Loyalties repair. Prior comparison JSON ledgers and the human-choice inventory were searched for overlap.

An exploratory setup sweep visited non-Capability Event cards in all five scenario decks at seed1, using each playable faction as the sole NP seat. It recorded 62 executions with no changes in a bounded list of material fields. Those raw observations are leads only. Some may involve conditional grants, absent human responses, tracked effects outside that list, prior issues or valid zero-result execution. Only the Sappers cases were promoted after focused source proof and controls. The exploratory sweep remains in scratch analysis. The published evidence contains only the two finalized, controlled findings.

Celtic Rites' missing Aedui unshaded producer was rejected because its instruction uses shaded text. Camulogenus with no Available Warbands still queues its Command and therefore was not counted from the placement-only branch. Numeric Sappers in expansion was excluded because its card identity is replaced. Existing Optimates and Circumvallation questions were left under their current dispositions. Round5 held exploratory Sappers target cases without counting them. EV12-01 now supplies concrete confirmation of that earlier lead.

## Reproduction

```sh
PYTHONHASHSEED=0 python probe_events.py --repo /absolute/path/to/fs-bot > rerun.json
cmp results.json rerun.json
PYTHONHASHSEED=987 python probe_events.py --repo /absolute/path/to/fs-bot > rerun987.json
cmp results.json rerun987.json
```

`findings.json` records precise source/code/comparator lines, fixture limits, controls, overlap and suggested repair scopes. No whole-suite or full-game validation is claimed by this lane.
