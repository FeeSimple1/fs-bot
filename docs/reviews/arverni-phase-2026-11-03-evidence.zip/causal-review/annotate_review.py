"""Assert the concrete rule mechanism of each first divergent phase Rally."""
from collections import Counter
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / 'fs-bot'))
from fs_bot import rules_consts as rc
from fs_bot.board.control import calculate_control
from fs_bot.state.serialize import decode

attempt = HERE / 'attempt1'
review = json.loads((attempt / 'review-summary.json').read_text())
assert review['all_first_divergences_within_phase']
counts = Counter()
rows = []
for item in review['reviews']:
    first = json.loads((attempt / item['first_divergence_file']).read_text())
    original = decode(first['parent']['result'])
    corrected = decode(first['candidate']['result'])
    before = decode(first['preceding_candidate']['board'])
    assert first['parent']['stage'] == '_arverni_phase_rally-after'
    assert original['citadels_placed'] == corrected['citadels_placed']
    upgrades = {region for region, _ in original['citadels_placed']}
    extra_after_upgrade = {region: original['warbands_placed'][region]
                           for region in upgrades if region in original['warbands_placed']}
    assert all(region not in corrected['warbands_placed'] for region in upgrades)
    removed_allies = [entry for entry in original['allies_placed']
                     if entry not in corrected['allies_placed']]
    assert all(calculate_control(before, region) != rc.ARVERNI_CONTROL
               for region, _ in removed_allies)
    assert all(entry in original['allies_placed'] for entry in corrected['allies_placed'])
    expected = {region: number for region, number in original['warbands_placed'].items()
                if region not in upgrades}
    for region, _ in removed_allies:
        # All four observed missing-Control cases are Home Regions with no
        # pre-existing Ally/Citadel, so their legal Rally places one Warband.
        assert region in rc.ARVERNI_HOME_REGIONS_ARIOVISTUS
        expected[region] -= 1
    assert expected == corrected['warbands_placed'], (item, expected)
    assert extra_after_upgrade or removed_allies
    mechanisms = []
    if extra_after_upgrade:
        counts['extra_warbands_after_city_upgrade'] += 1
        mechanisms.append('A6.2.1: no Warband placement in a Region that already upgraded its Ally to a Citadel')
    if removed_allies:
        counts['ally_without_arverni_control'] += 1
        mechanisms.append('A6.2.1/3.3.1: Ally placement requires Arverni Control; Home Warband option remains legal')
    if item['rng_changed']:
        counts['rng_changed_with_candidate_filtering'] += 1
        assert extra_after_upgrade
        mechanisms.append('Filtering the forbidden post-upgrade Warband Regions shortens the shuffled candidate list; the consequent RNG position change is expected')
    rows.append({key: item[key] for key in ('scenario', 'seed', 'card_index', 'current_card')} |
                {'mechanisms': mechanisms, 'removed_extra_warbands_after_upgrade': extra_after_upgrade,
                 'removed_allies_without_control': [{'region': region, 'tribe': tribe,
                    'prior_control': calculate_control(before, region)} for region, tribe in removed_allies],
                 'input_board_and_rng_equal': item['equal_before_board_and_rng'],
                 'full_audited_result_reproduced': item['outcome_reproduced'],
                 'evidence': 'attempt1/' + item['first_divergence_file']})

seize = {}
for label in ('parent', 'candidate'):
    seize[label] = json.loads((HERE / ('seize-rally-' + label + '.json')).read_text())
for old, new in zip(seize['parent']['cases'], seize['candidate']['cases']):
    assert not old['integrity'] and not new['integrity']
    assert old['scenario'] == new['scenario']
    if new['initial_arverni_warbands'] == 0:
        assert (old['final_carnutes_warbands'], old['final_carnutes_allies']) == (2, 1)
        assert (new['final_carnutes_warbands'], new['final_carnutes_allies']) == (1, 0)
    else:
        assert (old['final_carnutes_warbands'], old['final_carnutes_allies']) == (5, 1)
        assert (new['final_carnutes_warbands'], new['final_carnutes_allies']) == (3, 1)

result = {'candidate_source_sha256': review['candidate_sha256'],
          'parent_source_sha256': review['parent_sha256'],
          'paired_changed_outcome_games': len(rows), 'complete_trace_executions': 2 * len(rows),
          'base_records_semantically_identical': review['base_games'],
          'source_mechanism_counts_overlapping': dict(counts),
          'all_reviewed': True, 'unexplained_first_divergences': [],
          'rows': rows, 'seize_rally_integration_cases': 4,
          'seize_rule': 'A3.2.3 expressly directs automatic Arverni free Rally from Dispersed markers through A6.2.1.',
          'seize_scope': 'Direct response to a supplied successful roll in both expansion scenarios; does not retest Dispersal or the die trigger.',
          'limits': 'First-divergence review explains why paired trajectories separate. It is not an exhaustive proof of every later decision or a claim that all rule interactions are correct.'}
(HERE / 'causal-source-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'rows'}, indent=2))
