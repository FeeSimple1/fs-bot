# BE-04 evidence guide

This bundle covers optional named-faction choices for numeric 2U/18U/23U/26S
and the adjacent A18U removal correction. The repository report and results
JSON provide the published summary; this archive preserves the underlying
checks, including failed intermediate and diagnostic attempts.

Accepted Python source comprises 422 files, SHA-256
`9d4cc73f2efaa33b8e6ad871fb432ae43c7471d5222b1c13d9c9b571c0c3c4a8`.
It was first validated as prepared changes over `2edf53e`, then committed as
`9e9191bc1c0eb5de13a5d578475d4f85042d2a6b`. The prepared patch, per-file
source manifest and source-commit verification distinguish these identities.

- `full-01` and `documentation-full-01` each record 6,872 passing tests with
  no failures, errors or skips. These are repeated suites, not independent cases.
- `matrix-01/integration-results.json` and `integration_checks.py` record
  150 audited bot games, 30 distinct mixed-seat cases (120 executions counting
  replay and hash repetition), and 20 strict-census executions.
- Parent legacy records were reused from the previous acceptance matrix only
  after confirming byte-identical parent Python source. `task-baseline.json`
  records that provenance. The balance baseline is unchanged and passes its
  existing 15-percentage-point guard; the largest observed change is 10 points.
- `causal-review/` contains exactly 16 selected parent/candidate pairs (32
  diagnostic games), raw traces, first divergences, source-grounded findings
  and a sealed file manifest. It explains earliest divergences, not all later
  actions or statistical faction balance. It adds no independent outcome sample.
- `reviewer-causal-verification.json` independently verifies all 32 trace
  hashes, outcomes, frozen source and the bounded first-cause conclusions.
- `protected-before.json` and `release-preflight.json` verify all 49 protected
  inputs: 47 supplied references, rules constants and the existing baseline.

Two diagnostic limitations are intentionally retained. The candidate trace
command completed all 16 games, then failed its whole-identity comparison
because the source commit occurred during the run. Every Python file remained
identical, confirmed independently against the committed tree. Separately,
31 of 32 initial captured-row replays were exact: sorted diagnostic JSON lost
map insertion order in one snapshot. Restoring the original order reproduced
its exact decision, state/RNG and following execution. Both original failures
and the subsequent verification are included; neither is relabeled as an
originally clean diagnostic run.

Earlier focused failures and witness attempts are explained by their handoffs.
The final accepted witnesses and focused logs are identified there. Do not
substitute a failed intermediate candidate for the accepted source identity.
The archive's `evidence-index.json` hashes every other included entry; the
packaging helper verifies each hash and ZIP integrity after writing.
