"""Verify Batch 4's frontend and replay repairs and paired games."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
from xml.etree import ElementTree

from fs_bot import rules_consts as rc
from fs_bot.state.serialize import decode
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


ROOT = Path(__file__).resolve().parent
REPO = Path(__import__('fs_bot').__file__).resolve().parent.parent
PARENT = '4cef37157157c3b3ec04886d3b6713bacd1605cb'
PARENT_DIGEST = '2e12f8ee077efec1d87e9b0d2661c078619b4fc3ea22c31eceae69aa51ae177c'
BALANCE_ROW = re.compile(r'^\[(.+) seed= *(\d+)\] winner=(.+) \((\d+) cards\)$', re.M)


def load(name):
    return json.loads((ROOT / name).read_bytes())


def tests():
    cases = {'parent-cases': (19, 9), 'directed': (47, 0),
             'directed987': (28, 0), 'full': (10357, 0)}
    results = {}
    for name, (n, failures) in cases.items():
        suite, = ElementTree.parse(ROOT / f'{name}.xml').iter('testsuite')
        checks = {'tests': n, 'failures': failures, 'skipped': 0, 'errors': 0}
        assert all(int(suite.get(key)) == expected for key, expected in checks.items())
        results[name] = dict(checks, seconds=float(suite.get('time')), passed=n - failures)
    return results


def audited_games(folder, edition, seeds, digest):
    metadata = load(f'{folder}/metadata.json')
    assert metadata['source_sha256'] == digest and metadata['hash_seed'] == 0
    assert metadata['card_edition'] == edition and metadata['seeds'] == list(seeds)
    rows = [json.loads(line) for line in (ROOT / folder / 'games.jsonl').read_text().splitlines()]
    games = {(row['scenario'], row['seed']): row for row in rows}
    assert len(rows) == len(games) == len(SCENARIOS) * len(seeds)
    assert set(games) == {(scenario, seed) for scenario in SCENARIOS for seed in seeds}
    for row in rows:
        assert row['source_sha256'] == digest and row['card_edition'] == edition
        assert row['completed'] and row['game_completed'] and row['audit_completed']
        assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row)
        assert len(row['final_state_sha256']) == 64
        assert all(d['severity'] == 'legal-decline' for d in row['diagnostic_occurrences'])
    return games


def compare_games(parent, repair):
    fields = ('winner', 'cards', 'final_ranking', 'final_state_sha256',
              'interlude_completed', 'diagnostics', 'diagnostic_occurrences')
    assert parent.keys() == repair.keys()
    for key, row in repair.items():
        assert all(row[field] == parent[key][field] for field in fields), key
    return {'games': len(repair), 'interludes': sum(row['interlude_completed']
                                                   for row in repair.values()),
            'legal_declines': sum(len(row['diagnostic_occurrences']) for row in repair.values()),
            'changed_final_states': 0, 'changed_winners': 0, 'changed_card_counts': 0}


def balance(games):
    log = (ROOT / 'balance.log').read_text()
    assert 'OK: balance within band (6 winner changes)' in log
    records = {(scenario, int(seed)): (faction, int(cards))
               for scenario, seed, faction, cards in BALANCE_ROW.findall(log)}
    assert len(records) == 100
    assert records == {key: (row['winner'], row['cards']) for key, row in games.items()}
    baseline = json.loads((REPO / 'fs_bot/tools/balance_baseline.json').read_text())['games']
    shifts = {}
    for scenario in SCENARIOS:
        old = Counter(baseline[f'{s}|{k}']['winner'] for s, k in records if s == scenario)
        new = Counter(f for (s, _), (f, _) in records.items() if s == scenario)
        shifts[scenario] = max(abs(old[f] - new[f]) for f in rc.FACTIONS) * 5
    assert max(shifts.values()) == 10
    return {'games': 100, 'largest_shift_points': 10, 'band_points': 15,
            'drift_by_scenario': shifts}


def mixed(digest):
    for ext in ('log', 'json'):
        assert (ROOT / f'fuzz0.{ext}').read_bytes() == (ROOT / f'fuzz987.{ext}').read_bytes()
    before, after = load('parent-fuzz0.json'), load('fuzz0.json')
    assert before['metadata']['source_sha256'] == PARENT_DIGEST
    assert after['metadata']['source_sha256'] == digest
    assert all(after['metadata'][key] for key in ('replay', 'events', 'reactive'))
    assert after['metadata']['card_edition'] == 'second-edition'
    assert after['metadata']['seeds'] == list(range(53, 57))
    assert after['games'] == len(after['records']) == 20 and after['hard_findings'] == 0
    assert all(row['game_completed'] and not row['findings'] for row in after['records'])
    compatibility = load('mixed-display-compat.json')
    changed = 0
    for old, new, check in zip(before['records'], after['records'], compatibility, strict=True):
        assert (new['scenario'], new['seed']) == (check['scenario'], check['seed'])
        assert new['digest'] == check['raw']
        assert dict(new, digest=check['without_battle_display']) == old
        changed += old['digest'] != new['digest']
    assert changed == 14
    keys = ('games', 'human_turns', 'event_turns', 'events_ok', 'partial', 'hard_findings',
            'batch_digest')
    return dict({k: after[k] for k in keys}, changed_display_digests=changed)


def legacy_replay():
    records = []
    for record_seed, resume_seed in ((0, 987), (987, 0)):
        recorded = load(f'legacy-record-{record_seed}.json')
        assert recorded == load(f'legacy-resume-{resume_seed}.json')
        assert recorded['error'] is None and recorded['pending']['id'] == 'd000003'
        request = decode(recorded['accepted']['assistant_request'])
        assert request['faction'] == rc.AEDUI and request['requesting_faction'] == rc.ROMANS
        records.append({'record_hash': record_seed, 'resume_hash': resume_seed,
                        'region': request['context']['region'], 'pending': recorded['pending']['id']})
    assert {r['region'] for r in records} == {rc.VENETI, rc.AEDUI_REGION}
    return records


def main():
    source = load('source.json')
    digest = source['source_sha256']
    assert source_identity()['source_sha256'] == digest
    assert source['commit'] == PARENT and source['dirty']
    protected = load('protected-sources.json')
    assert len(protected) == 48
    assert all(hashlib.sha256((REPO / name).read_bytes()).hexdigest() == sha
               for name, sha in protected.items())
    games = {}
    for edition, seeds in (('legacy', range(1, 21)), ('second-edition', range(53, 57))):
        old = audited_games(f'parent-{edition}', edition, seeds, PARENT_DIGEST)
        new = audited_games(edition, edition, seeds, digest)
        games[edition] = compare_games(old, new)
        if edition == 'legacy':
            balance_result = balance(new)
    print(json.dumps({'source': source, 'suites': tests(), 'bot_games': games,
                      'mixed': mixed(digest), 'balance': balance_result,
                      'legacy_replay': legacy_replay(), 'protected_files': len(protected)},
                     indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
