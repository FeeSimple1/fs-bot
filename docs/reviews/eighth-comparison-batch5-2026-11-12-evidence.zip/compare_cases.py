"""Select paired bot and mixed-player games whose outcomes differ."""

from pathlib import Path
import json


def key(row):
    return row['scenario'], row['seed'], row['card_edition']


def records(root, name):
    path = root / name
    if path.is_file():
        values = json.loads(path.read_text())['records']
    else:
        values = [json.loads(line) for line in (path / 'games.jsonl').read_text().splitlines()]
    result = {key(row): row for row in values}
    assert len(result) == len(values)
    return result


def main():
    cases = (('final-legacy', 'legacy', 'final_state_sha256'),
             ('final-second', 'second', 'final_state_sha256'),
             ('fuzz0-final.json', 'mixed', 'digest'),
             ('fuzz-ci0.json', 'ci', 'digest'))
    for name, group, digest_key in cases:
        parent = records(Path('parent'), name)
        current = records(Path('.'), name)
        assert parent.keys() == current.keys()
        changed = sorted(k for k in current if current[k][digest_key] != parent[k][digest_key])
        fields = ('winner', 'cards', 'termination') if group in ('legacy', 'second') else (
            'human_turns', 'event_turns', 'events_ok', 'partial')
        print(group, len(current), 'changed:', len(changed),
              {field: sum(current[k][field] != parent[k][field] for k in current)
               for field in fields})
        Path(f'{group}-changed.json').write_text(json.dumps(changed, indent=2) + '\n')


if __name__ == '__main__':
    main()
