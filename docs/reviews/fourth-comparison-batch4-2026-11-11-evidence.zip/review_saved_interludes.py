"""Read and continue the two archived Gallic War saves from this checkout."""
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
from pathlib import Path
import importlib.util
import json
import sys

from fs_bot.state.serialize import encode, load_game
from fs_bot.tools.validation_metadata import source_identity

fixtures = Path('fs_bot/tests/fixtures/compatibility_8ef88e2')
spec = importlib.util.spec_from_file_location('fixture_driver', fixtures / 'generate.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
records = {}
for name in ('pre-interlude', 'post-interlude'):
    path = fixtures / f'{name}.json'
    state, meta, log = load_game(path, validate=True)
    before = encode(state)
    with redirect_stdout(StringIO()):
        result = driver.continue_fixture(name, state, meta, log)
    records[name] = dict(file_sha256=sha256(path.read_bytes()).hexdigest(),
                         continued_sha256=driver.digest(result), before=before,
                         continued=encode(result['state']))
Path(sys.argv[1]).write_text(json.dumps(dict(source=source_identity(), fixtures=records), indent=2) + '\n')
