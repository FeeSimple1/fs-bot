# Fourth Falling Sky comparison audit evidence

Audited Falling Sky `b951908af2b21cc87a7e27d9a5314b3f257d0147` and Liberty or Death
`2991ea279062773548ec390a1da75f3e85381702`. No gameplay source or protected
reference was modified. `findings.json` counts 16 new groups, 11 high and
5 medium, and identifies prior-ledger distinctions and proposed repair batches.

Run all ten final scripts against the audited checkout. The output directory
must not exist. The runner verifies the exact Python source digest first.

```sh
python run_probes.py /path/to/fs-bot /path/to/new-results
```

Only Python and the game package are needed for these probes. The separately
recorded full test suite used pytest. The probe assertions preserve observed
defects; they must be reversed into source-correct expectations during repairs.
This runner intentionally rejects a different source revision.

## Accepted evidence

- `portable-final/results.json` names all ten final scripts, their SHA-256
  hashes and successful exits. Its outputs are the root's final independent
  reruns after all fixture corrections.
- Each partition's `findings.json` and coverage file record exact source/code
  references, controls, fixture assumptions, rejected leads and scope limits.
- Independent source review appears in `base-events/independent-frontend/`,
  `bots-review/independent-commands/`, `commands/independent-expansion.*`,
  `expansion/independent-bots-review.json`, `frontend/independent-seasonal/`,
  and `seasonal/independent-base-events-review.md`.
- `validation-summary.json`, `validation-exits.json`, `source.json`,
  `pytest.log`, `bots/`, `fuzz0.*`, and `fuzz987.*` contain the general suite
  and exact second-edition seeds 25–28 matrices. Fuzz files match byte for byte.
  One soft partial plan is distinct from a hard finding. No new balance matrix
  was run.

## Superseded and exploratory records

Earlier exploratory scripts and outputs remain for provenance. They are not
the accepted witnesses unless named in `run_probes.py` and their hashes match
`portable-final/results.json`. In particular, initial controlled fixtures
omitted Provincia's permanent Fort, and initial negative-Harvest allocation
used restricted Home Tribes incorrectly. Final scripts correct both issues.
Assembly's final second-SA witness Builds an Ally at Helvii, with the permanent
Fort retained. The corrected independent reviewer also executes both legal
Special Abilities in either order to verify that the missing choice matters.

Files under `exploratory/`, `superseded/`, `run1/`, `scope1/`, `second-sa1/`,
files named `before-fort`, and preliminary root `independent/` reruns are
historical. The accepted root rerun is `portable-final/`. Other independent
reviewers bind their reruns to script hashes in their review records.

The controlled positions are source-reviewed fixtures, not claims about
frequency in complete games. The Interlude Nori control removes one obsolete
record in a diagnostic clone only. The negative-Harvest finding concerns the
0–45 Resource bound and does not settle treatment of negative awards against
positive balances. A33 Wailing Women's outnumbering definition is separately
recorded as an unconfirmed source question and is excluded from the 16 groups.
