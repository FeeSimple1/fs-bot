"""Round-five lifecycle witnesses. Run with fs-bot root on PYTHONPATH.

WS5-01 assertions describe the audited defect, not correct behavior. Its repair
tests must invert the defective outcomes. The Optimates observation is an
unconfirmed source question and must not be inverted without a ruling. No engine, RNG, or victory monkeypatches.
"""
from copy import deepcopy
import json

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_on_map, count_pieces, move_piece
from fs_bot.cards.card_effects import _ally_tribe, _unally_tribe
from fs_bot.engine.execute import _execute_event
from fs_bot.engine.victory import calculate_victory_score, check_any_victory
from fs_bot.engine.winter import run_winter_round
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import check_structural_integrity, validate_state


def integrity(state):
    census, structure = validate_state(state), check_structural_integrity(state)
    assert census == structure == [], (census, structure)
    assert count_pieces(state, rc.PROVINCIA, rc.ROMANS, rc.FORT) == 1
    for tribe, info in state['tribes'].items():
        restriction = rc.TRIBE_FACTION_RESTRICTION.get(tribe)
        assert not restriction or info['allied_faction'] in (None, restriction)
    return {'census': census, 'structure': structure, 'permanent_fort': True,
            'restricted_tribe_owners_valid': True}


def home_city_case(region, tribe, step, missing):
    state = setup_scenario(rc.SCENARIO_GALLIC_WAR, seed=21)
    # Romans are human, so their explicit decision to decline the expedition
    # is legal. Other human choices delegate to the raw API's default policy.
    state['non_player_factions'] = {rc.AEDUI, rc.GERMANS, rc.BELGAE}
    move_piece(state, rc.PROVINCIA, region, rc.ROMANS, rc.LEGION)
    # Keep every Faction below its victory threshold in both controls and
    # witnesses. Removing the home Ally alone would otherwise give Rome 16.
    assert _ally_tribe(state, rc.TRIBE_NAMNETES, rc.BELGAE)
    if missing:
        _unally_tribe(state, tribe)
    state['winter_count'] = 2
    state['current_card'] = rc.WINTER_CARD
    before_integrity = integrity(state)
    assert check_any_victory(state) is None
    before_map = count_on_map(state, rc.ROMANS, rc.LEGION)
    before_track = sum(state['legions_track'].values())
    roman_score = calculate_victory_score(state, rc.ROMANS)
    result = run_winter_round(state, britannia_decision=False)
    assert result['winter_count'] == 3 and 'interlude' in result
    assert not result['phases']['victory']['game_over']
    assert state['interlude_completed'] and state['scenario'] == rc.SCENARIO_PAX_GALLICA
    assert not result['interlude']['step3_britannia']['conducted']
    assert state['tribes'][tribe]['allied_faction'] in (rc.AEDUI, rc.ARVERNI)
    after_map = count_on_map(state, rc.ROMANS, rc.LEGION)
    after_region = count_pieces(state, region, rc.ROMANS, rc.LEGION)
    track_delta = sum(state['legions_track'].values()) - before_track
    assert before_map == 6
    assert (after_region, after_map, track_delta) == ((0, 5, 1) if missing else (1, 6, 0))
    return dict(region=region, home_tribe_initially_missing=missing,
                entry_roman_score=roman_score, no_winner_at_entry=True,
                winters_resolved=result['winter_count'],
                restoration=result['interlude'][step],
                legions_on_map_before=before_map, legions_on_map_after=after_map,
                legion_in_home_region_after=after_region,
                legions_track_change=track_delta,
                before_integrity=before_integrity, after_integrity=integrity(state))


def optimates_cases():
    state = setup_scenario(rc.SCENARIO_PAX_GALLICA, seed=21)
    state['non_player_factions'] = {rc.ROMANS, rc.AEDUI, rc.ARVERNI, rc.BELGAE}
    # Source-legal controlled alliances yield Roman score 13 with no Faction
    # meeting its victory condition. Every physical disc comes from Available.
    extras = {rc.GERMANS: [rc.TRIBE_UBII, rc.TRIBE_SEQUANI, rc.TRIBE_HELVETII],
              rc.ARVERNI: [rc.TRIBE_CARNUTES, rc.TRIBE_PICTONES],
              rc.BELGAE: [rc.TRIBE_MORINI, rc.TRIBE_NERVII]}
    for faction, tribes in extras.items():
        for tribe in tribes:
            assert _ally_tribe(state, tribe, faction)
    before_integrity = integrity(state)
    assert check_any_victory(state) is None
    assert calculate_victory_score(state, rc.ROMANS) == 13
    event = _execute_event(state, rc.ARVERNI, {'details': {
        'card_id': 20, 'text_preference': rc.EVENT_UNSHADED}}, human=True)
    assert event['executed'] and not event.get('errors')
    assert state['event_modifiers']['optimates_active']
    state['current_card'] = rc.WINTER_CARD
    first = run_winter_round(state)
    assert first['phases']['victory']['skipped'] == '1st Winter special rule'
    assert state['winter_count'] == 1
    assert check_any_victory(state) is None
    assert calculate_victory_score(state, rc.ROMANS) == 13
    first_integrity = integrity(state)
    before_second = count_on_map(state, rc.ROMANS, rc.LEGION)
    assert before_second == 8
    outcomes = []
    for active in (True, False):
        trial = deepcopy(state)
        if not active:
            # Diagnostic control isolates the active Event; no engine patched.
            trial['event_modifiers'].pop('optimates_active')
        second = run_winter_round(trial)
        victory = second['phases']['victory']
        after_second = count_on_map(trial, rc.ROMANS, rc.LEGION)
        if active:
            assert victory['game_over'] and victory['optimates_end']
            assert after_second == 0
        else:
            assert not victory['game_over'] and not victory.get('optimates_end')
            assert after_second == 12
        outcomes.append(dict(optimates_active=active, winter_count=trial['winter_count'],
                             actual_victory_phases_reached=1, victory=victory,
                             legions_before=before_second, legions_after=after_second,
                             integrity=integrity(trial)))
    return dict(before_integrity=before_integrity, event=event,
                first_winter_victory=first['phases']['victory'],
                first_winter_integrity=first_integrity, second_winter=outcomes)


if __name__ == '__main__':
    result = {'audit_commit': 'bd30d522e8baa2d303b9e372d7d9c550351e91a5',
              'WS5-01': [home_city_case(region, tribe, step, missing)
                         for region, tribe, step in (
                             (rc.AEDUI_REGION, rc.TRIBE_AEDUI, 'step2_aedui'),
                             (rc.ARVERNI_REGION, rc.TRIBE_ARVERNI, 'step2_arverni'))
                         for missing in (False, True)],
              'Q-OPTIMATES-PAX-PHASE-COUNT': optimates_cases()}
    print(json.dumps(result, indent=2, sort_keys=True))
