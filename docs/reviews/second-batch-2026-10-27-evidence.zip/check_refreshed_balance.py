"""Run the unchanged balance command and compare every result to reviewed data.

This script does not replace or approve the baseline. Run only after a
separately documented review and installation of the exact candidate bytes.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'fs-bot'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--attempt', default='attempt4')
args = parser.parse_args()
assert Path(args.attempt).name == args.attempt
RUN = ROOT / args.attempt
OUT = RUN / 'post-baseline'
OUT.mkdir(exist_ok=True)
sys.path.insert(0, str(REPO))
from fs_bot.tools.validation_metadata import source_identity

expected = json.loads((RUN / 'source.json').read_text())
candidate_bytes = (RUN / 'balance-candidate.json').read_bytes()
baseline_path = REPO / 'fs_bot/tools/balance_baseline.json'
assert baseline_path.read_bytes() == candidate_bytes
assert source_identity()['source_sha256'] == expected['source_sha256']
argv = [sys.executable, '-m', 'fs_bot.tools.balance_smoke', '--seeds', '1-20']
status = dict(argv=argv, cwd=str(REPO), environment={'PYTHONHASHSEED': '0'},
              source=source_identity(), exit_code=None,
              baseline_sha256=hashlib.sha256(candidate_bytes).hexdigest(),
              band_percentage_points=15, band_changed=False)
path = OUT / 'balance.status.json'
assert not path.exists(), 'Keep earlier evidence rather than overwriting it'
path.write_text(json.dumps(status, indent=2) + '\n')
start = time.monotonic()
with (OUT / 'balance.log').open('x') as output:
    process = subprocess.run(argv, cwd=REPO, env=dict(os.environ, PYTHONHASHSEED='0'),
                             stdout=output, stderr=subprocess.STDOUT)
status.update(exit_code=process.returncode, elapsed_seconds=time.monotonic()-start,
              source_after=source_identity())
log = (OUT / 'balance.log').read_text()
matches = re.findall(r'^\[(.+) seed=\s*(\d+)\] winner=(.+) \((\d+) cards\)$', log, re.M)
rows = {f'{scenario}|{int(seed)}': {'winner': winner, 'cards': int(cards)}
        for scenario, seed, winner, cards in matches}
candidate = json.loads(candidate_bytes)['games']
checks = {
    'exit_zero': process.returncode == 0,
    'source_unchanged': status['source_after']['source_sha256'] == expected['source_sha256'],
    'baseline_unchanged': baseline_path.read_bytes() == candidate_bytes,
    'exact_100_keys': len(matches) == len(rows) == 100 and rows.keys() == candidate.keys(),
    'all_winners_and_card_counts_match': rows == candidate,
    'tool_reports_pass': 'OK: balance within band.' in log,
}
status.update(checks=checks, passed=all(checks.values()), records=rows)
path.write_text(json.dumps(status, indent=2, sort_keys=True) + '\n')
print(json.dumps({k:v for k,v in status.items() if k != 'records'}, indent=2))
raise SystemExit(0 if status['passed'] else 1)
