"""Package the accepted BE-11/12 and EXP-09 evidence with content verification."""
from pathlib import Path
import hashlib
import json
import zipfile

out = Path(__file__).resolve().parent
repo = out.parent / 'fs-bot'
selected = []
directories = {'parent-bots-legacy', 'bots-legacy', 'bots-original',
               'bots-second-edition', 'causal-review'}
excluded = {'evidence-index.json', 'accepted-results-draft.json', 'report-draft.md', 'report-final-draft.md'}
for path in sorted(out.rglob('*')):
    relative = path.relative_to(out)
    if not path.is_file() or path.name in excluded or path.name.endswith('.tmp'):
        continue
    if '__pycache__' in relative.parts:
        continue
    if len(relative.parts) > 1 and (relative.parts[0] in directories or relative.parts[0].startswith('matrix-')):
        selected.append(path)
    elif len(relative.parts) == 1 and path.suffix in {'.log', '.txt', '.xml', '.json', '.py', '.md', '.patch'}:
        selected.append(path)
index = {str(path.relative_to(out)): {
    'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    'bytes': path.stat().st_size} for path in selected}
manifest = out / 'evidence-index.json'
manifest.write_text(json.dumps(index, indent=2) + '\n')
archive = repo / 'docs/reviews/event-validation-2026-11-03-evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
    for path in [*selected, manifest]:
        handle.write(path, path.relative_to(out))
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
    for name, info in index.items():
        assert hashlib.sha256(handle.read(name)).hexdigest() == info['sha256']
result = {'path': archive.name,
          'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
          'bytes': archive.stat().st_size, 'entries': len(index) + 1,
          'crc_and_manifest_verified': True}
path = repo / 'docs/reviews/event-validation-2026-11-03-results.json'
data = json.loads(path.read_text())
data['evidence_archive'] = result
path.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps(result, indent=2))
