# Independent sixth-audit review

Reviewed Falling Sky `86fb0c2d8ddf86a4548a863dc9c9da27d0c708ad`, using the supplied references, existing rulings and earlier finding ledgers. Liberty or Death's authorized comparison supplies audit patterns only. No production source, tests, canonical constants or reference inputs were edited by this reviewer.

## Reviewed findings

- NP6-01: Accept the residual Belgic and Arverni offensive forecasts as one repair group. The witnesses isolate normal Command-only Battle, include favorable/unfavorable controls, and prove the actual post-Attack losses through both resolver and public execution. Ambiorix's contribution is part of the same estimate consumer group. This differs from the fifth round's German offensive forecast and fourth round's defensive Retreat forecast.
- NP6-02: Accept one combined high-value guarantee group with two explicit consumers: Arverni count a screened Legion as a forced Loss; Aedui omit the Roman defender's legal Fort absorption option. These are separate reproduced failures of the guarantee, not claims that their implementations are identical. The Aedui evidence lives in `review/probe_aedui_fort.py`; the root independently reran it because this reviewer authored it. Both differ from NP5-02's wholly absent high-value defender.
- NP6-03: Accept Roman Rampage threat detection. Section 8.8.1 expressly includes Rampage; section 4.5.2 supplies its actual eligibility and quantity rules. The use of “Loss roll” in the threat sentence does not erase the expressly included no-roll Rampage. Controls distinguish legal capacity from absent Leader and Fort immunity.
- FE6-01: Accept the single-Special-Ability Event path's bypass of Aedui's one-Region Ambush cap. Card 52 expressly retains usual space-selection rules. Ordinary rejection, two-ability rejection, legal one-Ambush result, pending save/resume and replay are reproduced.
- FE6-02: Accept the missing Ariovistus Enlist split-group choice. A3.4 replaces base 3.4, and A4.5.1 gives no exception restoring the original game's single moving group. The terminal witness and actual ordinary German Limited Command establish the omitted legal choice. This is not a claim about a specified unsupported JSON field. No durable-session coverage is claimed for this second finding.
- WS6-01: Accept the Germans Phase multiple-Allies-per-Region Rally. Section 6.2.1 explicitly retains the Rally procedure, whose one-Ally-per-Region limit is not replaced by section 3.4.1's additional Warbands. Both direct phase-step and complete phase witnesses are preserved.
- WS6-02: Accept the Germans Phase repeated movement of arrivals. The complete phase proof measures origin inventory after the actual Rally, independently of the Rally defect. The direct March witness also isolates it without Rally.
- WS6-03: Accept the missing player-Control priority within the add-Control destination tier. The printed nested priority is explicit; nonplayer and unconquerable controls isolate the omitted comparison.
- BE6-01, Event mandatory-clause group: Accept numeric57's skipped mandatory removal/Ally while its optional Warbands commit. Complete choices on cloned positions perform the omitted effects.
- BE6-02, Event NP-parameter group: Accept A35/A60 missing nonplayer parameters as one shared execution-planning group, including Roman A35's explicit full-Auxilia instruction. The untouched A35 German setup has only seven Available Warbands; the final witness correctly uses those seven plus one Settlement.
- BE6-03, Event ineffective-selection group: Accept Flight of Ambiorix with named Ambiorix already on the map. Section 8.1.1 gives this exact example; the final witness uses the actual Pax Gallica setup and a missing-Leader control.
- Battle cancellation groups: Accept the source conclusions for A31 unshaded versus shaded15 and A31 shaded versus unshaded13. Opposite sides and separate consumers distinguish them from earlier A31 fixes; the Horse-enhanced Slingers symptom belongs to the Slingers group. The final extended phase evidence and consolidated BM6-01 through BM6-03 disposition appear below.

## Independent verification

The five fifth-round regression test files passed **94 tests** on the audited source. This is focused regression coverage, not a claim that every interaction of each repaired rule has been exhausted.

Independent executions of the bot, lifecycle, frontend, Enlist and final Event probes matched their supplied JSON byte-for-byte. The frozen final Battle probe also matched byte-for-byte. The seventh probe, covering the Aedui Fort case and authored by this reviewer, was independently rerun by the root reviewer with an exact match. All accepted fixture checks passed the production inventory and structural validators. These are controlled source-based reproductions, not sampled-frequency estimates.

The first attempted Event rerun failed an audit-fixture assertion: Great Revolt begins with a Belgic Successor, not named Ambiorix. No engine failure was inferred. The Event author corrected this to untouched Pax Gallica, and the final rerun is separately stored in `events-final-rerun.json`; the earlier empty `events-rerun.json` is not accepted evidence. This reviewer did not observe the author's earlier A35 eight-Warband exploration; the accepted final probe uses the actual seven-piece Available pool.

No arbitrary count target was applied. Related symptoms with a common repair mechanism were grouped. Existing open source questions are not new confirmed defects. Static leads without complete public-path evidence remain excluded.

## Final Battle review and grouping verdict

The frozen final Battle probe independently reran and exactly matched `battle/probe_battle-output.json` (`review/battle-final-rerun.json`). Accept **BM6-01**, combining the two Phalanx cancellation consumers described above; **BM6-02**, combining alternate German Ambush pathways that omit the Command-scoped Slingers effect; and **BM6-03**, the extra defenders selected by Consuetudine.

BM6-02's full public Card 17 unshaded witness uses an explicit empty German March followed by one Roman-directed German Ambush against Aedui. Card 13 explicitly permits third-party Roman Auxilia fire, so that route supplies a full Event entrypoint without pretending base Germans take player turns. Its Card 53 witness has no German Control at the Battle Region, excluding local Rally interference. The normal engine German Battle control is labeled only as an API comparison. No claim is made that every alternate direct-resolver pathway or every Capability has been tested.

BM6-03's four Germans face two Aedui Warbands and two Roman Auxilia, so they have no local Control or Ally and receive no local Rally reinforcement. Card 53's express Hidden-enemy exception does not replace German Battle's Step 1 selection of one defender per Region. Two different physical defenders incur Losses in the public Event, while the ordinary phase control affects one. The defect survives the earlier source-correct Hidden exception and differs from authored repeated-Region Battle plans.

Recommended final denominator: **14 repair groups**. Keep the Aedui/Arverni guarantee consumers combined in NP6-02; keep the two Phalanx omissions combined in BM6-01; keep the A35/A60 parameter omissions combined; do not split the Horse-enhanced Slingers variant, mirrored scenarios, phase/Event routes, or individual controls into extra findings. All fourteen are open at the audited revision; this audit implements no repairs.
