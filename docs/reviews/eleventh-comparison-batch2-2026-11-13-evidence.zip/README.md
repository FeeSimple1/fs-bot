# Eleventh comparison repair Batch 2 evidence

Batch 2 closes BM11-01. The tested parent is
`52821136c4aa07d2df79dee48edbb1ec09945c12`. The repaired Python SHA-256 is
`4bb6812831b996cdb8941c6684650ff1e6661e5db0963bd1733f802188711a31` across
628 files, tested with Python 3.12.14. `SHA256SUMS` covers the other entries.
Verify it from the extracted directory with `sha256sum -c SHA256SUMS`.

The parent public Event witness matches the original eleventh audit. The
same six fixtures exercise the repaired Event at two hash seeds. The three
added regression cases fail against the parent code and pass after the
repair. Archived Batch 1 game results retain their original checkout metadata
and match the parent's Python source digest. The paired game records agree
on all gameplay fields. The balance run matches the reviewed Batch 1 data.

## Reproduce

Use the repository's development environment. Set `OUT` to an empty absolute
output directory, `EVIDENCE` to the extracted archive, and `PARENT` to a clean
checkout of the tested parent. Run from the repaired checkout.

```bash
PYTHONHASHSEED=0 python "$EVIDENCE/probe_battle.py" --repo "$PARENT"
PYTHONHASHSEED=0 python "$EVIDENCE/probe_battle.py" --repo . --repaired
PYTHONHASHSEED=987 python "$EVIDENCE/probe_battle.py" --repo . --repaired
PYTHONHASHSEED=0 python -m pytest -q -n 4 --junitxml="$OUT/full.xml"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out "$OUT/legacy"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 57-60 --card-edition second-edition --workers 2 --out "$OUT/second-edition"
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 57-60 --card-edition second-edition --out "$OUT/fuzz0.json"
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 57-60 --card-edition second-edition --out "$OUT/fuzz987.json"
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
PYTHONPATH=. python "$EVIDENCE/verify_results.py"
```

The focused tests are in `test_tenth_comparison_battle.py`,
`test_divination_np.py`, `test_divination_frost.py` and
`test_sixth_comparison_bot_forecasts.py` under `fs_bot/tests`. To see the
three expected parent failures, run the archived test file with the parent
checkout on `PYTHONPATH`.

```bash
cd "$PARENT"
PYTHONPATH=. PYTHONHASHSEED=0 python -m pytest -q "$EVIDENCE/test_tenth_comparison_battle.py"
```
