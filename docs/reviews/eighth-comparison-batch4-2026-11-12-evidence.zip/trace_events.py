"""Reproduce first differences from the paired Event repair runs."""

import argparse
import hashlib
import json
from pathlib import Path
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import _count_on_legions_track
from fs_bot.engine import execute, game_engine
from fs_bot.state.serialize import encode
from fs_bot.tools import player_fuzz, run_batch
from fs_bot.tools.validation_metadata import source_identity


def digest(value):
    return hashlib.sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def board_hash(state):
    return digest({k: v for k, v in state.items() if k != 'decision_agent'})


def trace(task, mixed):
    cards, events = [], []
    play_card = game_engine.play_card
    execute_event = execute._execute_event
    derive = execute._derive_event_params

    def record_event(state, faction, action, *, human=False):
        card = action.get('details', {}).get('card_id', state.get('current_card'))
        row = None
        if card in (2, 3, 5, 'A5', 32):
            row = {'card': card, 'faction': faction, 'human': human,
                   'senate': state.get('senate', {}).get('position'),
                   'track_legions': _count_on_legions_track(state)}
            events.append(row)
        result = execute_event(state, faction, action, human=human)
        if row is not None:
            row['result'] = result
        return result

    def record_params(state, faction, card, shaded):
        params = derive(state, faction, card, shaded)
        if events:
            row = events[-1]
            if (row['card'], row['faction']) == (card, faction) and not row['human']:
                row['params'] = params
        return params

    def record_card(state, decide, **kwargs):
        events.clear()
        row = {'ordinal': len(cards) + 1, 'scenario': state['scenario'],
               'card': state['current_card'], 'before_sha256': board_hash(state),
               'before_rng_sha256': digest(state['rng'].getstate())}
        result = play_card(state, decide, **kwargs)
        row.update(after_sha256=board_hash(state),
                   after_rng_sha256=digest(state['rng'].getstate()),
                   actions=result.get('turn_result', {}).get('actions_taken', {}),
                   events=list(events), winner=result.get('winner'))
        cards.append(row)
        return result

    with (patch.object(game_engine, 'play_card', record_card),
          patch.object(run_batch, 'play_card', record_card),
          patch.object(execute, '_execute_event', record_event),
          patch.object(execute, '_derive_event_params', record_params)):
        if mixed:
            scenario, seed, edition = task
            result = player_fuzz.play_game(scenario, seed, card_edition=edition)
            assert result['game_completed'] and not result['findings'], result
            outcome = {'digest': result['digest']}
        else:
            result = run_batch.play_one(task)
            assert result['completed'], result['errors']
            assert cards[-1]['after_sha256'] == result['final_state_sha256']
            outcome = {key: result[key] for key in
                       ('winner', 'cards', 'winters', 'termination', 'final_state_sha256')}
    return {'task': task, 'cards': cards, 'outcome': outcome}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pairs', type=Path)
    parser.add_argument('--mixed', action='store_true')
    args = parser.parse_args()
    games = [trace(task, args.mixed) for task in json.loads(args.pairs.read_text())]
    print(json.dumps(encode({'source': source_identity(), 'games': games}), indent=2,
                     sort_keys=True))


if __name__ == '__main__':
    main()
