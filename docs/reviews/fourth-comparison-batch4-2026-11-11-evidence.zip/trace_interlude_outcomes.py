"""Replay paired outcomes through the Gallic War Interlude."""
from concurrent.futures import ProcessPoolExecutor
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
from pathlib import Path
import json
import sys

from fs_bot import rules_consts as rc
from fs_bot.cards.capabilities import get_active_capabilities
from fs_bot.cli.dispatcher import make_decision_func
from fs_bot.engine.game_engine import get_sop_factions, play_card, start_game
from fs_bot.engine.victory import calculate_victory_score
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.tools.validation_metadata import source_identity


def replay(row):
    scenario, seed, edition = (row[key] for key in ('scenario', 'seed', 'card_edition'))
    state = setup_scenario(scenario, seed=seed, card_edition=edition)
    state['non_player_factions'] = set(get_sop_factions(state))
    decide = make_decision_func({}, stdin=StringIO(), stdout=StringIO(), pause=False)
    transition = None
    with redirect_stdout(StringIO()):
        start_game(state)
        for draw in range(1, 201):
            if transition is None:
                before = sha256(json.dumps(encode(state), sort_keys=True).encode()).hexdigest()
            result = play_card(state, decide, execute=True)
            if transition is None and state['interlude_completed']:
                interlude = result['winter_result']['winter_result']['interlude']
                transition = dict(draw=draw, before=before, resolved_card=result['card'],
                    first_card=state['current_card'], upcoming=state['next_card'],
                    dealt=state['played_cards'] + state['deck'], tribes=len(state['tribes']),
                    has_nori=rc.TRIBE_NORI in state['tribes'],
                    score=calculate_victory_score(state, rc.ROMANS),
                    active_capabilities=encode(get_active_capabilities(state)),
                    deck_result=interlude['step10_deck'])
            if result['game_over']:
                break
    assert (result['winner'], draw) == (row['winner'], row['cards'])
    assert transition is not None
    return dict(scenario=scenario, seed=seed, card_edition=edition, winner=row['winner'],
                cards=draw, interlude=transition)


def read(root, side):
    for edition in ('legacy', 'second'):
        for line in (root / f'{side}-{edition}' / 'games.jsonl').read_text().splitlines():
            record = json.loads(line)
            if record['interlude_completed']:
                yield record


def compare(parent, repair, output):
    before = json.loads(parent.read_text())['games']
    after = json.loads(repair.read_text())['games']
    comparisons = []
    for old, new in zip(before, after, strict=True):
        keys = ('scenario', 'seed', 'card_edition')
        assert all(old[key] == new[key] for key in keys)
        a, b = old['interlude'], new['interlude']
        assert (a['draw'], a['resolved_card'], a['before']) == (b['draw'], b['resolved_card'], b['before'])
        assert a['has_nori'] and not b['has_nori']
        assert b['tribes'] + 1 == a['tribes']
        assert b['score'] + 1 == a['score']
        comparisons.append(dict(**{key: new[key] for key in keys}, parent=old, repaired=new,
                                deck_changed=a['dealt'] != b['dealt']))
    output.write_text(json.dumps(comparisons, indent=2) + '\n')


if __name__ == '__main__':
    if sys.argv[1] == 'compare':
        compare(*map(Path, sys.argv[2:]))
    else:
        side, root, output = sys.argv[1:]
        with ProcessPoolExecutor(max_workers=2) as pool:
            records = sorted(read(Path(root), side), key=lambda row: (row['card_edition'], row['seed']))
            traces = list(pool.map(replay, records))
        Path(output).write_text(json.dumps(dict(source=source_identity(), games=traces), indent=2) + '\n')
