# Ninth comparison repair evidence, Batch 1

Parent `5f7d0583f29784812f65eca9829c9b631ce43820`. Python 3.12.14.
The repaired source digest and file count are in `source.json`.

Run the verifier from the repaired checkout with this archive extracted.

```sh
PYTHONPATH=. python /path/to/evidence/verify_results.py
```

`parent-reproduced` runs the final directed module from outside the parent
checkout with the parent on `PYTHONPATH`. `focused` includes the neighboring
Event, timing and bot tests. `full-before-baseline` records the failed
balance canary, and `full` records the suite with the reviewed outcomes.
The full runs use five pytest-xdist workers and hash seed 0.

The two audited bot samples use hash seed 0 and two workers.

```sh
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 49-52 --card-edition second-edition --workers 2 --out second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 49-52 --card-edition second-edition --out fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 49-52 --card-edition second-edition --out fuzz987.json
```

The additional mixed sample uses second-edition seeds 201–203 at hash seeds
0 and 7. Both mixed samples include reactive decisions, Events and replay.
Parent legacy records come from the eighth audit's final repair evidence.
Parent second-edition and mixed records come from the ninth audit evidence.
Their Python sources have the parent digest regardless of report commit.

`trace_events.py` records the actual plans and the first differing card on
both checkouts. Use the case lists `legacy-changed.json`, `second-changed.json`
and `mixed-changed.json` with the final list's `--mixed` option. Run with
`PYTHONHASHSEED=0 PYTHONPATH=.` from the applicable checkout. `verification.json`
combines the verified results and the first differences. Parent probes
and their original output are also included.

The balance logs use `python -m fs_bot.tools.balance_smoke --seeds 1-20` and
the canary uses `--seeds 1-3 --band 0.40`. The before and reviewed files
preserve both sets of reference outcomes. `SHA256SUMS` covers every other
archive member.
