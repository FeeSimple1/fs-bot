"""Read-only round-eight witnesses; defect assertions describe the audited revision.

Run from fs-bot: PYTHONPATH=. .venv/bin/python ../audit8-work/battle/probe_battle.py
No monkeypatches, production edits, repository tests, or direct piece-count writes.
"""
import json
from copy import deepcopy

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, count_pieces_by_state, place_piece
from fs_bot.engine.arverni_phase import run_arverni_phase
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND, ACTION_EVENT
from fs_bot.state.state_schema import (
    build_initial_state, check_structural_integrity, validate_state,
)

REGION = rc.CARNUTES
checks = 0


def check(state):
    global checks
    schema = validate_state(state)
    structure = check_structural_integrity(state)
    assert not schema, schema
    assert not structure, structure
    checks += 1


def position(scenario):
    state = build_initial_state(scenario, seed=7)
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    state['non_player_factions'] = set()
    for faction in state['resources']:
        state['resources'][faction] = 20
    check(state)
    return state


def event(state, card, faction, *, shaded=False, params=None):
    state['current_card'] = card
    check(state)
    result = execute_decision(state, faction, {
        'action': ACTION_EVENT,
        'player_action': {'command': rc.FIRST_DID_EVENT, 'details': {
            'card_id': card,
            'text_preference': rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,
            'event_params': params or {},
        }},
    })
    assert result['executed'] and not result.get('errors'), result
    check(state)
    return result


def battle(state, attacker, defender):
    check(state)
    result = execute_decision(state, attacker, {
        'action': ACTION_COMMAND,
        'player_action': {'command': rc.CMD_BATTLE, 'sa': 'No SA',
                          'regions': [REGION], 'details': {'battle_plan': [
                              {'region': REGION, 'target': defender}]}},
    })
    assert result['executed'] and not result.get('errors'), result
    check(state)
    return result


def phase(state):
    # Zero Resources makes Raid inapplicable; Frost lawfully suppresses March.
    for faction in state['resources']:
        state['resources'][faction] = 0
    check(state)
    result = run_arverni_phase(state, is_frost=True)
    assert len(result['battle']['battles']) == 1, result
    assert result['battle']['battles'][0]['region'] == REGION
    check(state)
    return result


def record(state, requests):
    def agent(_board, owner, request):
        requests.append({'owner': owner, 'request': deepcopy(request)})
        if request['kind'] == 'retreat':
            return {'retreat': False}
        if request.get('request_type') == 'fixed_event_battle':
            return {'region': REGION, 'defender': rc.ARVERNI}
        # Raw callback delegation retains normal casualty choice; these
        # witnesses have only ordinary soft troops, so no save-roll choices.
        return None
    state['decision_agent'] = agent


def pieces(state):
    return {faction: {
        'warbands': count_pieces(state, REGION, faction, rc.WARBAND),
        'auxilia': count_pieces(state, REGION, faction, rc.AUXILIA),
        'allies': count_pieces(state, REGION, faction, rc.ALLY),
    } for faction in (rc.ROMANS, rc.ARVERNI, rc.AEDUI, rc.BELGAE, rc.GERMANS)}


def stage(state, *, archers=None, phalanx=None):
    # Every active Capability is acquired through a public Event; A31 is
    # deliberately later than 27, avoiding Dueling Events precedence doubt.
    if archers is not None:
        event(state, 27, rc.AEDUI, shaded=archers == rc.EVENT_SHADED)
    if phalanx is not None:
        event(state, 'A31', rc.ROMANS, shaded=phalanx == rc.EVENT_SHADED)
    requests = []
    record(state, requests)
    check(state)
    return requests


def evidence(state, result, requests):
    assert count_pieces(state, rc.PROVINCIA, rc.ROMANS, rc.FORT) == 1
    # Temporary Battle contexts must not leak after a committed operation.
    assert not any(key in state for key in (
        '_combined_battle_force', '_diviciacus_force', '_battle_elite_warbands',
        '_morbihan_projection', '_battle_excluded_leader', '_battle_auxilia_only'))
    return {'pieces': pieces(state), 'result': result, 'requests': requests,
            'census': 'clean', 'structure': 'clean'}


cases = {}
# BM8-01: Card 2's automatic-Legion clause is inert because no Legion exists.
# Ordinary, fixed Event and automatic Phase share the same 6-vs-4 combat.
for mode in ('ordinary', 'legiones', 'arverni_phase'):
    for archers in (False, True):
        scenario = (rc.SCENARIO_ARIOVISTUS if mode == 'arverni_phase'
                    else rc.SCENARIO_GREAT_REVOLT)
        state = position(scenario)
        place_piece(state, REGION, rc.ARVERNI, rc.WARBAND, 6)
        place_piece(state, REGION, rc.ROMANS, rc.AUXILIA, 4)
        requests = stage(state, archers=rc.EVENT_SHADED if archers else None)
        if mode == 'ordinary':
            result = battle(state, rc.ARVERNI, rc.ROMANS)
        elif mode == 'legiones':
            result = event(state, 2, rc.ARVERNI, shaded=True,
                           params={'battle_region': REGION})
        else:
            result = phase(state)
        remaining = count_pieces(state, REGION, rc.ROMANS, rc.AUXILIA)
        assert remaining == (0 if mode == 'ordinary' and archers else 1)
        assert count_pieces(state, REGION, rc.ARVERNI, rc.WARBAND) == 6
        cases[f'BM8-01_{mode}_archers_{archers}'] = evidence(state, result, requests)

# Different fixed grant, and Arverni defend: no-Counterattack exception is kept.
for archers in (False, True):
    state = position(rc.SCENARIO_GREAT_REVOLT)
    place_piece(state, REGION, rc.ARVERNI, rc.WARBAND, 6)
    place_piece(state, REGION, rc.AEDUI, rc.WARBAND, 4)
    requests = stage(state, archers=rc.EVENT_SHADED if archers else None)
    result = event(state, 36, rc.AEDUI)
    assert result['free_actions'][0]['defender'] == rc.ARVERNI
    assert result['free_actions'][0]['result']['counterattack'] is None
    assert count_pieces(state, REGION, rc.ARVERNI, rc.WARBAND) == 4
    assert count_pieces_by_state(state, REGION, rc.AEDUI, rc.WARBAND, rc.HIDDEN) == 4
    cases[f'BM8-01_morasses_archers_{archers}'] = evidence(state, result, requests)

# BM8-02a: later Stalwart should cancel shaded Archers against German attacker.
for attacker, archers, stalwart in (
    (rc.GERMANS, False, False), (rc.GERMANS, True, False),
    (rc.GERMANS, True, True), (rc.GERMANS, False, True),
    (rc.BELGAE, True, True),
):
    state = position(rc.SCENARIO_ARIOVISTUS)
    place_piece(state, REGION, attacker, rc.WARBAND, 4)
    place_piece(state, REGION, rc.ARVERNI, rc.WARBAND, 6)
    requests = stage(state, archers=rc.EVENT_SHADED if archers else None,
                     phalanx=rc.EVENT_SHADED if stalwart else None)
    result = battle(state, attacker, rc.ARVERNI)
    assert count_pieces(state, REGION, attacker, rc.WARBAND) == (1 if archers else 2)
    assert count_pieces(state, REGION, rc.ARVERNI, rc.WARBAND) == (5 if archers else 4)
    cases[f'BM8-02_stalwart_{attacker}_archers_{archers}_a31_{stalwart}'] = evidence(
        state, result, requests)

# BM8-02b: later Inflexible should cancel unshaded Archers benefiting German defender.
# Complete legal Arverni Phase avoids asking automatic Arverni to take a player turn.
for defender, archers, inflexible in (
    (rc.GERMANS, False, False), (rc.GERMANS, True, False),
    (rc.GERMANS, True, True), (rc.GERMANS, False, True),
    (rc.BELGAE, True, True),
):
    state = position(rc.SCENARIO_ARIOVISTUS)
    place_piece(state, REGION, rc.ARVERNI, rc.WARBAND, 6)
    place_piece(state, REGION, defender, rc.WARBAND, 4)
    requests = stage(state, archers=rc.EVENT_UNSHADED if archers else None,
                     phalanx=rc.EVENT_UNSHADED if inflexible else None)
    result = phase(state)
    assert count_pieces(state, REGION, defender, rc.WARBAND) == (2 if archers else 1)
    assert count_pieces(state, REGION, rc.ARVERNI, rc.WARBAND) == 6
    cases[f'BM8-02_inflexible_{defender}_archers_{archers}_a31_{inflexible}'] = evidence(
        state, result, requests)

print(json.dumps({'audited_commit': 'e62b0360c1b91032741ef8f6afa4d247c8ea2437',
                  'seed': 7, 'case_count': len(cases),
                  'integrity_checks_passed': checks, 'cases': cases},
                 indent=2, sort_keys=True))
