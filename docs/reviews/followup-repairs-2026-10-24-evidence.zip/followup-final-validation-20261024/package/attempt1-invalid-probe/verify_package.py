"""Build and independently check the frozen local distribution."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import venv
import zipfile

ROOT = Path('/workspace/scratch/534c265c65f4/fs-bot')
OUT = Path(__file__).resolve().parent
EXPECTED = '190ac6925ac2a6cff5df491cb02fea1858880c0d4ba8854887f49c3a8174be0f'


def source_digest():
    digest = hashlib.sha256()
    for path in sorted((ROOT / 'fs_bot').rglob('*.py')):
        digest.update(str(path.relative_to(ROOT)).encode() + b'\0' + path.read_bytes())
    return digest.hexdigest()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(command, log, *, cwd=ROOT, env=None):
    with (OUT / log).open('w', encoding='utf-8') as handle:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=handle,
                                stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f'{log}: command exited {result.returncode}')


before = source_digest()
if before != EXPECTED:
    raise RuntimeError(f'Source freeze mismatch before build: {before}')
commands = []
build_command = [sys.executable, '-m', 'build', '--no-isolation',
                 '--outdir', str(OUT / 'dist')]
commands.append(build_command)
build_env = dict(os.environ, PYTHONPATH='/workspace/scratch/534c265c65f4/fs-build-tools')
run(build_command, 'build.log', env=build_env)
wheel, = (OUT / 'dist').glob('*.whl')
sdist, = (OUT / 'dist').glob('*.tar.gz')

references = []
with zipfile.ZipFile(wheel) as archive:
    for path in sorted((ROOT / 'Reference Documents').rglob('*')):
        if path.is_file():
            relative = path.relative_to(ROOT / 'Reference Documents').as_posix()
            data = archive.read('fs_bot/_references/' + relative)
            if data != path.read_bytes():
                raise RuntimeError(f'Bundled reference mismatch: {relative}')
            references.append({'path': relative, 'sha256': sha(path)})
    baseline = ROOT / 'fs_bot/tools/balance_baseline.json'
    if archive.read('fs_bot/tools/balance_baseline.json') != baseline.read_bytes():
        raise RuntimeError('Bundled balance baseline is not the refreshed baseline')
    if any(n.startswith('fs_bot/tests/') for n in archive.namelist()):
        raise RuntimeError('Development tests unexpectedly included in installed package')

with tempfile.TemporaryDirectory(prefix='fsbot-final-package-') as temporary:
    outside = Path(temporary)
    venv.EnvBuilder(with_pip=True).create(outside / 'env')
    python = outside / 'env' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    install = [str(python), '-m', 'pip', 'install', '--no-index', '--no-deps', str(wheel)]
    commands.append(install)
    run(install, 'install.log', cwd=outside)
    smoke = [str(python), '-I', str(ROOT / 'scripts/smoke_installed.py')]
    commands.append(smoke)
    run(smoke, 'installed-smoke.log', cwd=outside)
    optional_script = '''
import json
from fs_bot import rules_consts as rc
from fs_bot.state.setup import setup_scenario
from fs_bot.cards.card_effects import execute_event
from fs_bot.board.pieces import find_leader
from fs_bot.state.serialize import save_game,load_game,encode
from fs_bot.state.state_schema import validate_state
from pathlib import Path
results=[]
for scenario in rc.BASE_SCENARIOS:
    s=setup_scenario(scenario,seed=613,diviciacus_option=True)
    assert s['diviciacus_option'] is True
    s['event_params']={'target_region':rc.AEDUI_REGION}
    execute_event(s,rc.CARD_O38)
    assert find_leader(s,rc.AEDUI)==rc.AEDUI_REGION
    assert not validate_state(s)
    save_game(s,Path('optional-save.json'))
    loaded,_,_=load_game(Path('optional-save.json'),validate=True)
    assert encode(loaded)==encode(s)
    results.append(scenario)
print(json.dumps({'optional_diviciacus_scenarios':results,'save_resume':'passed'}))
'''
    run([str(python), '-I', '-c', optional_script], 'installed-option-smoke.log', cwd=outside)
    run([str(python), '-I', '-c', 'import json;from fs_bot.version import engine_identity;print(json.dumps(engine_identity(),sort_keys=True))'],
        'installed-identity.json', cwd=outside)

run([sys.executable, '-c', 'import json;from fs_bot.version import engine_identity;print(json.dumps(engine_identity(),sort_keys=True))'],
    'source-identity.json')
installed_identity = json.loads((OUT / 'installed-identity.json').read_text())
source_identity = json.loads((OUT / 'source-identity.json').read_text())
if installed_identity != source_identity:
    raise RuntimeError('Installed engine identity differs from frozen source')
after = source_digest()
if after != before:
    raise RuntimeError(f'Source changed during package validation: {after}')
summary = {
    'source_freeze_sha256_before': before,
    'source_freeze_sha256_after': after,
    'engine': installed_identity,
    'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'git_dirty': bool(subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()),
    'artifacts': [{'name': p.name, 'size': p.stat().st_size, 'sha256': sha(p)} for p in (sdist, wheel)],
    'unchanged_references': references,
    'balance_baseline_sha256': sha(baseline),
    'install_index_disabled': True,
    'runtime_dependencies_installed': [],
    'installed_smoke': 'passed',
    'optional_diviciacus_smoke': 'passed',
    'commands': commands,
}
(OUT / 'verification.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': 'passed', 'source_sha256': after,
                  'reference_files_verified': len(references),
                  'artifacts': summary['artifacts']}, indent=2))
