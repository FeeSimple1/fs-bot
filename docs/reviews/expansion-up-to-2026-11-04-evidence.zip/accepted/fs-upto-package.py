from pathlib import Path
import hashlib,json,platform,re,subprocess,xml.etree.ElementTree as ET,zipfile
from fs_bot.tools.validation_metadata import source_identity
prefix='expansion-up-to-2026-11-04';result=json.loads(Path('/tmp/fs-upto-results.json').read_text())
assert source_identity()['source_sha256']==result['source']['source_sha256']=='e81fb7e8e9c8db1965ce44ebcb13b4f3d40f6d6507341ada0a0b6d6d25652c58'
suite=ET.parse('/tmp/fs-upto-full.xml').getroot().find('testsuite')
assert suite.attrib['tests']=='8191' and all(suite.attrib[k]=='0' for k in ('errors','failures','skipped'))
assert Path('/tmp/test_expansion_up_to_parent.py').read_bytes()==Path('fs_bot/tests/test_expansion_up_to.py').read_bytes()
proof=ET.parse('/tmp/fs-upto-parent.xml').getroot().find('testsuite')
assert proof.attrib['tests']=='25' and proof.attrib['failures']=='17' and proof.attrib['errors']=='0'
assert all('assert' in t.find('failure').attrib['message'].lower() for t in proof if t.find('failure') is not None)
target_log=Path('/tmp/fs-upto-targeted-frozen.log').read_text()
match=re.search(r'\n(\d+) passed in ',target_log)
assert match and int(match[1])==292 and 'failed' not in target_log
result['full_suite']=suite.attrib;result['parent_suite']=proof.attrib;result['python']=platform.python_version()
Path('docs/reviews/'+prefix+'-results.json').write_text(json.dumps(result,indent=2)+'\n')
p=Path('docs/reviews/'+prefix+'.md');s=p.read_text().replace('Final full suite pending.',f"**8,191 tests pass** in the final full suite ({float(suite.attrib['time']):.2f} seconds), with zero failures, errors or skips.");s=s.replace('Parent behavioral proof pending.', '''An isolated parent runs the unchanged test file through existing engine APIs:
**17 behavioral failures** reproduce ignored authored quantities/physical choices
and omitted Scouted removals; **eight controls pass**, with 62 cases deselected.
All failures are behavior assertions, not missing new helper imports.''');s=s.replace('Results pending final inspection.', '''All ten native-bot records complete and audit successfully, with no errors or
integrity findings, four ranked factions, consistent winner/ranking fields and
nonempty final hashes. Every gameplay field and final hash matches the parent;
only elapsed seconds, commit and source digest are excluded from comparison.
Both mixed-seat outputs agree in complete JSON across hash seeds: 247 human
turns, 77 Event attempts, 75 successful Events, zero hard findings, zero partials,
batch digest `5dd20da48e8e672b`. Internal replay makes 40 executions in total.
The focused regressions explicitly exercise the new request; unchanged mixed
outcomes alone do not establish that those particular Events were reached.''')
b=result['balance_smoke'];s=s.replace('Balance results pending.',f"The check passes, with a largest absolute difference of {b['maximum_absolute_delta_percentage_points']} percentage points and {b['historical_baseline_winner_changes']} winner changes versus the historical baseline. These are not changes versus the parent.");p.write_text(s)
p=Path('docs/current-status.md');s=p.read_text().replace('Validation: see the final report and machine-readable results.', '''**8,191 tests pass**, including 87 new cases; 292 targeted tests pass. Ten
native-bot gameplay records/final hashes match parent. Forty mixed executions
agree across hash seeds with zero hard findings or partials. The 100-game
historical balance check passes its unchanged baseline and 15-point band.
See the report for the frozen source digest and evidence bounds.''',1);p.write_text(s)
entries={}
for file in ['/tmp/fs-upto-full.xml','/tmp/fs-upto-full.log','/tmp/fs-upto-targeted-frozen.log','/tmp/fs-upto-parent.xml','/tmp/fs-upto-parent.log','/tmp/test_expansion_up_to_parent.py','/tmp/fs-upto-mixed0.json','/tmp/fs-upto-mixed0.log','/tmp/fs-upto-mixed987.json','/tmp/fs-upto-mixed987.log','/tmp/fs-upto-balance.log','/tmp/fs-upto-verify.py','/tmp/fs-upto-package.py']:
 entries['accepted/'+Path(file).name]=Path(file).read_bytes()
for label,directory in [('parent','/tmp/fs-upto-bots-parent'),('accepted','/tmp/fs-upto-bots-final')]:
 for p in Path(directory).iterdir():
  if p.is_file():entries[label+'/bots/'+p.name]=p.read_bytes()
entries['accepted/results.json']=json.dumps(result,indent=2).encode()
entries['accepted/source.patch']=subprocess.check_output(['git','diff','HEAD','--','fs_bot'])
new_files=['fs_bot/cards/expansion_up_to.py','fs_bot/cli/expansion_up_to.py','fs_bot/tests/test_expansion_up_to.py']
for name in new_files:entries['accepted/'+name]=Path(name).read_bytes()
protected=[p for p in Path('Reference Documents').rglob('*') if p.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
entries['accepted/protected-inputs.json']=json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected},indent=2).encode()
entries['commands.txt']=b'''Accepted source: parent feaed4bce9f1be8ebe2a514f074332958e091ee6 plus accepted/source.patch and the three accepted/fs_bot Python files.
python -m pytest -q --junitxml=/tmp/fs-upto-full.xml
python -m pytest -q fs_bot/tests/test_expansion_up_to.py fs_bot/tests/test_card_effects.py fs_bot/tests/test_expansion_event_validation.py fs_bot/tests/test_event_action_windows.py fs_bot/tests/test_event_timing_planning.py fs_bot/tests/test_assistant_session.py
In isolated unmodified parent checkout, with unchanged new test file copied outside the tree:
PYTHONPATH=/tmp/fs-upto-parent python -m pytest -q /tmp/test_expansion_up_to_parent.py -k 'a40_author_selects_exact_number_of_regions or a60_author_selects_auxilia_resource_tradeoff or a51_author_selects_exact_physical_removals or a51_default_also_removes_eligible_scouted_warbands or a51_six_can_mix_visibility_without_touching_unselected_cohort or raw_delegation_keeps_maximum_default' --junitxml=/tmp/fs-upto-parent.xml
In parent and accepted trees separately, with distinct output directories:
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --games 2 --workers 2 --out OUT
In accepted tree:
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out /tmp/fs-upto-mixed0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out /tmp/fs-upto-mixed987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
PYTHONPATH=. python /tmp/fs-upto-verify.py
PYTHONPATH=. python /tmp/fs-upto-package.py
'''
entries['README.txt']=b'Accepted Python source e81fb7e8e9c8db1965ce44ebcb13b4f3d40f6d6507341ada0a0b6d6d25652c58 over parent feaed4bce9f1be8ebe2a514f074332958e091ee6. Apply source.patch and add the three accepted/fs_bot Python files to reconstruct frozen sources. Full suite:8191 passed; 87 new cases. Isolated-parent proof:17 behavioral failures, eight controls pass, 62 deselected. All ten native-bot records/final hashes match parent except timing/source provenance. Mixed outputs agree in complete JSON across hash seeds0/987, with zero hard findings and zero partials, 40 executions including replay. The 100-game historical balance smoke uses unchanged seeds1-20/allfive scenarios/baseline/15-point band. It is not a parent-delta count or a full rules-compliance proof. See report for bounds.\n'
entries['SHA256SUMS.txt']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(entries.items())).encode()
p=Path('docs/reviews/'+prefix+'-evidence.zip')
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(entries.items()):z.writestr(name,data)
print(json.dumps({'full_suite':suite.attrib,'targeted':292,'evidence_bytes':p.stat().st_size,'source':result['source']}))
