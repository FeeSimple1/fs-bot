"""Run with PYTHONPATH pointing to the desired immutable or live source tree."""
import json

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, place_piece
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.engine.execute import _execute_event
from fs_bot.state.state_schema import build_initial_state, validate_state


for card in (35, 46):
    for at_war in (False, True):
        state = build_initial_state(rc.SCENARIO_ARIOVISTUS, seed=35046)
        state.update(current_card=card, next_card=47, at_war=False)
        state['non_player_factions'] = {rc.AEDUI, rc.BELGAE, rc.GERMANS}
        state['eligibility'][rc.ROMANS] = rc.INELIGIBLE
        for region, tribe in ((rc.ARVERNI_REGION, rc.TRIBE_ARVERNI),
                              (rc.PICTONES, rc.TRIBE_PICTONES)):
            _ally_tribe(state, tribe, rc.ARVERNI)
            place_piece(state, region, rc.ARVERNI, rc.WARBAND, 3)
            if at_war:
                place_piece(state, region, rc.ROMANS, rc.AUXILIA)
        consulted = []
        state['decision_agent'] = lambda board, actor, request: consulted.append(
            {'actor': actor, 'kind': request.get('kind'), 'request_type': request.get('request_type')})
        result = _execute_event(state, rc.ROMANS, {'command': 'Event', 'details': {
            'card_id': card, 'text_preference': rc.EVENT_SHADED,
            'event_params': {'faction': rc.ARVERNI}}}, human=True)
        print(json.dumps({'card': card, 'at_war_fixture': at_war,
            'executed': result.get('executed'), 'reason': result.get('reason'),
            'grants': [{'kind': grant['kind'], 'command': grant['result'].get('command'),
                        'executed': grant['result'].get('executed'),
                        'provisional_ruling': grant['result'].get('provisional_ruling')}
                       for grant in result.get('free_actions', [])],
            'arverni_citadel': count_pieces(state, rc.ARVERNI_REGION, rc.ARVERNI, rc.CITADEL),
            'roman_eligibility': state['eligibility'][rc.ROMANS],
            'consulted': consulted, 'validation_errors': validate_state(state)}, sort_keys=True))
