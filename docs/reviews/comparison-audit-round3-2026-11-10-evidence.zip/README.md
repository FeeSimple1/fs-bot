# Third Falling Sky comparison audit evidence

Audited Falling Sky `3c23a3414c3e870e274ef63c278db8cb3f1ee747` and Liberty or Death `2991ea279062773548ec390a1da75f3e85381702`.
The consolidated `findings.json` counts 15 groups. The partition ledgers retain
original local IDs, including BE3-02 and EX3-02 merged into XC3-01.

Run the eight final witness scripts against a checkout of the audited revision.
The result directory must not already exist. Python and the game package are
sufficient for the probes; the recorded full suite additionally used pytest.

```sh
python run_probes.py /path/to/fs-bot /path/to/new-results
```

Assertions preserve the defective outcomes, not the desired rules. A repaired
checkout should fail the relevant old-defect assertion. Full saved-session
journeys, controlled positions, primitive-level witnesses, legal marker fixtures,
positive controls, and coverage limits are identified in partition notes and the
consolidated ledger. The runner exits nonzero if any witness does not reproduce.

`independent/` contains independent reruns and per-finding source review.
`portable-rerun/` contains the final orchestration results. `validation/`
contains the passing 9,411-test log/JUnit report and exact matching mixed-seat
records at both hash seeds. Four soft partial plans are not hard findings.

Exploratory scripts/outputs are retained, explicitly superseded by the final
scripts named in run_probes.py. The frontend preliminary next-card assertion
failed and was corrected to observe end-card eligibility. No gameplay or
reference changes were made, and no new balance matrix is claimed.
