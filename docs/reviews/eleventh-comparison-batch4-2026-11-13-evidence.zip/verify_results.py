"""Verify the Winter Campaign repair and its paired validation outputs."""

import hashlib
import json
from pathlib import Path
import re
from xml.etree import ElementTree
from zipfile import ZipFile

from fs_bot import rules_consts as rc
from fs_bot.tools.error_census import _severity
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


HERE = Path(__file__).resolve().parent
REPO = Path(rc.__file__).resolve().parents[1]
PARENT = '0c2e6fa8098480ac84676d5e61dcb119ae8a3a4d'
PARENT_DIGEST = 'c22251669bf85ddc8726ffeb16b94f373be09abae5f10af6ae80ee41f02746c0'
REPAIRED_DIGEST = '95e58d60023a24eec5f2ca576b9d010f20faf4e23b4cacc2ae3e7c034a4c152d'
MATRIX = {'legacy': range(1, 21), 'second-edition': range(57, 61)}


def load(path):
    return json.loads((HERE / path).read_bytes())


def verify_tests():
    expected = {'parent-final-directed': (9, 9), 'directed0': (187, 0),
                'directed987': (187, 0), 'full': (10435, 0)}
    totals = {}
    for name, (tests, failures) in expected.items():
        suite, = ElementTree.parse(HERE / f'{name}.xml').iter('testsuite')
        assert int(suite.get('tests')) == tests and int(suite.get('failures')) == failures, name
        assert int(suite.get('errors')) == int(suite.get('skipped')) == 0, name
        totals[name] = {'passed': tests - failures, 'failed': failures}
    return totals


def verify_frontend():
    assert (HERE / 'audit-results.json').read_bytes() == (HERE / 'parent-witness.json').read_bytes()
    assert (HERE / 'repair-witness0.json').read_bytes() == (HERE / 'repair-witness987.json').read_bytes()
    parent, repair = [load(name)['UI11-01'] for name in ('parent-witness.json', 'repair-witness0.json')]
    controls = {'durable_combined_plan_controls', 'terminal_free_german_command_controls',
                'ordinary_terminal_borrowing_controls'}
    assert all(parent[name] == repair[name] for name in controls)
    assert len(parent['blocked_terminal']) == len(repair['repaired_terminal']) == 5
    assert {row['scenario'] for row in repair['repaired_terminal']} == set(SCENARIOS)
    for row in repair['repaired_terminal']:
        action, = row['result']['actions']
        assert action['actions'] == 2 and row['result']['remaining_actions'] == 0
        assert action['plan']['command'] == rc.CMD_RAID and action['plan']['sa'] == rc.SA_ENLIST
        assert action['result']['sa_execution']['executed']
        assert row['physical']['belgic_resources'] == 2
        assert row['physical']['germans'][rc.CARNUTES] == {rc.HIDDEN: 0, rc.REVEALED: 2, rc.SCOUTED: 0}
        assert row['planning_board_unchanged'] and row['integrity'] == {'census': [], 'structure': []}
    return {'fixed_scenarios': len(repair['repaired_terminal']),
            'paired_controls': sum(len(repair[name]) for name in controls)}


def read_games(get, edition, seeds, source):
    meta = json.loads(get(f'{edition}/metadata.json'))
    assert meta['source_sha256'] == source and meta['hash_seed'] == 0
    assert meta['card_edition'] == edition and meta['seeds'] == list(seeds) and meta['all_factions_bots']
    rows = [json.loads(line) for line in get(f'{edition}/games.jsonl').splitlines()]
    indexed = {(r['scenario'], r['seed']): r for r in rows}
    assert len(indexed) == len(rows)
    assert set(indexed) == {(scenario, seed) for scenario in SCENARIOS for seed in seeds}
    for row in rows:
        assert row['source_sha256'] == source and row['card_edition'] == edition
        assert row['completed'] and row['game_completed'] and row['audit_completed']
        assert len(row['final_state_sha256']) == 64
        assert not (row['errors'] or row['integrity_findings'] or _outcome_issues(row)), row
        for diagnostic in row['diagnostic_occurrences']:
            assert diagnostic['severity'] == _severity(diagnostic['kind'], diagnostic['message']) == 'legal-decline'
    return indexed


def verify_games(parent):
    counts = {}
    for edition, seeds in MATRIX.items():
        previous = read_games(parent.read, edition, seeds, PARENT_DIGEST)
        repaired = read_games(lambda p: (HERE / p).read_bytes(), edition, seeds, REPAIRED_DIGEST)
        metadata = {'commit', 'source_sha256', 'seconds'}
        for key, row in repaired.items():
            assert row['commit'] == PARENT
            assert {k: v for k, v in row.items() if k not in metadata} == {
                k: v for k, v in previous[key].items() if k not in metadata}, key
        counts[edition] = {'games': len(repaired), 'interludes': sum(r['interlude_completed'] for r in repaired.values()),
                           'legal_declines': sum(len(r['diagnostic_occurrences']) for r in repaired.values())}
    return counts


def verify_mixed(parent):
    for suffix in ('json', 'log'):
        assert (HERE / f'fuzz0.{suffix}').read_bytes() == (HERE / f'fuzz987.{suffix}').read_bytes()
    before, after = json.loads(parent.read('fuzz0.json')), load('fuzz0.json')
    assert before['metadata']['source_sha256'] == PARENT_DIGEST
    assert after['metadata']['commit'] == PARENT and after['metadata']['source_sha256'] == REPAIRED_DIGEST
    assert after['metadata']['card_edition'] == 'second-edition'
    assert after['metadata']['seeds'] == list(MATRIX['second-edition'])
    assert all(after['metadata'][flag] for flag in ('events', 'reactive', 'replay'))
    assert after['records'] == before['records'] and after['batch_digest'] == before['batch_digest']
    assert after['games'] == len(after['records']) == 20 and after['hard_findings'] == 0
    assert {(r['scenario'], r['seed']) for r in after['records']} == {
        (scenario, seed) for scenario in SCENARIOS for seed in MATRIX['second-edition']}
    assert all(r['game_completed'] and not r['findings'] for r in after['records'])
    return {key: after[key] for key in ('games', 'partial', 'hard_findings', 'batch_digest')}


def verify_balance():
    log = (HERE / 'balance.log').read_text()
    rows = re.findall(r'^\[(.+) seed= *(\d+)\] winner=(.+) \((\d+) cards\)$', log, re.M)
    games = {f'{scenario}|{seed}': {'winner': winner, 'cards': int(cards)}
             for scenario, seed, winner, cards in rows}
    baseline = REPO / 'fs_bot/tools/balance_baseline.json'
    assert hashlib.sha256(baseline.read_bytes()).hexdigest() == (HERE / 'balance-baseline-sha256.txt').read_text().strip()
    assert len(rows) == len(games) == 100 and games == json.loads(baseline.read_bytes())['games']
    assert 'OK: balance within band.' in log
    return {'games': len(games), 'changed_outcomes': 0}


def main():
    assert source_identity()['source_sha256'] == REPAIRED_DIGEST
    assert len(list((REPO / 'fs_bot').rglob('*.py'))) == 628
    reviews = REPO / 'docs/reviews'
    with ZipFile(reviews / 'eleventh-comparison-batch2-2026-11-13-evidence.zip') as audit:
        protected = json.loads(audit.read('protected-sources.json'))
    expected = {f.relative_to(REPO).as_posix() for f in (REPO / 'Reference Documents').rglob('*') if f.is_file()}
    assert set(protected) == expected | {'fs_bot/rules_consts.py'}
    assert all(hashlib.sha256((REPO / path).read_bytes()).hexdigest() == digest
               for path, digest in protected.items())
    test = 'test_eighth_comparison_winter_campaign.py'
    assert (HERE / test).read_bytes() == (REPO / 'fs_bot/tests' / test).read_bytes()
    with ZipFile(reviews / 'eleventh-comparison-batch3-2026-11-13-evidence.zip') as parent:
        summary = {'parent': PARENT, 'source_sha256': REPAIRED_DIGEST, 'protected_files': len(protected),
                   'tests': verify_tests(), 'frontend': verify_frontend(), 'audited_games': verify_games(parent),
                   'mixed_seats': verify_mixed(parent), 'balance': verify_balance()}
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
