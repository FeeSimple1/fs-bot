"""Reproduce unauthorized eligibility metadata through ordinary file sessions."""
import contextlib,io,json,tempfile
from types import SimpleNamespace
from pathlib import Path
from fs_bot import rules_consts as rc
from fs_bot.tools import llm_seat
from fs_bot.state.serialize import load_game,decode
from fs_bot.board.pieces import count_pieces
from fs_bot.engine import game_engine

def run(flag):
 end_cards=[]
 original=game_engine.adjust_eligibility
 def observe(state, actions):
    original(state, actions)
    end_cards.append({'card':state['current_card'],'roman_eligibility':state['eligibility'][rc.ROMANS], 'roman_action':actions.get(rc.ROMANS)})
 game_engine.adjust_eligibility=observe
 with tempfile.TemporaryDirectory() as directory:
    args=SimpleNamespace(dir=directory,scenario=rc.SCENARIO_GREAT_REVOLT,seed=46,seat=rc.ROMANS)
    with contextlib.redirect_stdout(io.StringIO()):
        llm_seat.cmd_init(args)
        llm_seat.cmd_play(args)
    path=Path(directory)/'save.json'; sent=False; initial=None
    for i in range(30):
        state,meta,log=load_game(path,validate=True)
        pending=meta['assistant_session']['pending']; assert pending
        request=decode(pending['request'])
        if request['kind']=='turn':
            if sent: break
            assert state['current_card']==16
            initial={'current_card':state['current_card'],'id':pending['id'],'request':request,'eligibility':state['eligibility'][rc.ROMANS],'auxilia':count_pieces(state,rc.PROVINCIA,rc.ROMANS,rc.AUXILIA)}
            response={'action':'command','player_action':{'command':'Recruit','regions':[rc.PROVINCIA],'sa':'No SA','details':{'recruit_plan':[{'region':rc.PROVINCIA,'action':'place_auxilia','count':1}]}}}
            if flag: response['free_action']=True
            sent=True
        else: response={'use_default':True}
        with contextlib.redirect_stdout(io.StringIO()):
            code=llm_seat.cmd_submit(SimpleNamespace(dir=directory,decision_id=pending['id'],response=json.dumps(response)))
        if code: raise AssertionError((code,request,response))
    else: raise AssertionError('Did not finish ordinary Recruit')
    game_engine.adjust_eligibility=original
    recorded=next(entry for entry in log if entry.get('action')=='command')
    return {'end_cards':end_cards,'injected_free_action':flag,'initial':initial,'next_turn_card':state['current_card'],'next_turn':request,'eligibility':state['eligibility'][rc.ROMANS],'auxilia':count_pieces(state,rc.PROVINCIA,rc.ROMANS,rc.AUXILIA),'recorded':recorded}

if __name__=='__main__':
 rows=[run(False),run(True)]
 assert rows[0]['end_cards'][0]['roman_eligibility']==rc.INELIGIBLE
 assert rows[1]['end_cards'][0]['roman_eligibility']==rc.ELIGIBLE
 assert rows[1]['recorded']['free_action'] is True
 print(json.dumps(rows,default=str,indent=2))
