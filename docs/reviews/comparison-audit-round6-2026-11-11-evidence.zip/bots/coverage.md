# Sixth audit: bot flowchart partition

Audited Falling Sky `86fb0c2d8ddf86a4548a863dc9c9da27d0c708ad`; comparator Liberty or Death `2991ea279062773548ec390a1da75f3e85381702`.

Read `CLAUDE.md`, the provisional ruling register, previous 50/21/15/16/11 finding titles and relevant historical dispositions. Source references, not comparator game rules, govern findings. No production files edited.

Compared `coin-implementation-lessons.md` sections D/E/F and `docs/audit_set_but_never_applied_s76.md` section5 with current bot planners. Focused on independent arithmetic consumers, exact flowchart thresholds, actual casualty identity, legal Special Ability threats and named Leader scope.

## Executed

`PYTHONHASHSEED=0 PYTHONPATH=<fs-bot-root> python bots/probe_bots.py`

18 assertion-backed controlled cases: 11 Belgic/Arverni forecast cases;2Arverni forcedLegion cases;5Roman Rampage-threat cases. Each begins from `build_initial_state`, uses canonical helpers for pieces, preserves permanentProvinciaFort, checks pre/post inventory census and structure. Every actual bot action goes through public dispatch and execute. Legal alternatives go through player-response validation and execute; standingBattle raw resolver separately establishes Attack/Counterattack counts. No monkeypatches or non-seeded RNG.

Independent reviewer added2Aedui Fort cases in `review/probe_aedui_fort.py`; merged underNP6-02.

## Counted

- NP6-01: Belgic/Arverni duplicated forecast omits surviving defender step; namedAmbiorix attack rate omitted in same estimate family.
- NP6-02: existing high-value piece does not establish forced Loss. Arverni screenedLegion and independently reviewed Aedui Fort-protectedAlly.
- NP6-03: Roman R1 staleRampage capacity and missing legality checks.

## Checked but not counted as additional findings

- German repaired predictor now delegates to shared resolveLosses-backed estimator; Aedui Diviciacus target-scoped protection preserved. Existing fifth regressions are separate root/reviewer validation.
- Roman ordinary favorable-Battle predicate already delegates to shared survivor predictor.
- Arverni/Belfic Ambush, Capability, Devastate/Rampage/Enlist pre-Battle preview integration has additional static simplifications; no additional count without source-backed fixture.
- Arverni equal-opponent ordering, Roman Besiege prerequisites, and successor identity cases not exhaustively audited in this partition.

These are sparse legal engine states, not a claim that all situations occur in the sampled game matrix or an estimate of encounter frequency. Passing ordinary engine tests and complete games does not prove these exact bot flowchart choices.
