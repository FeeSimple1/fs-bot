# BE-12 — German Allegiances shaded

Base `8db858b14cd13856059d42db1ad3931e523b5ed4`.
Worktree `fs-german-allegiances`, branch
`repair/german-allegiances-2026-11-03`. Parent owns integration and push.

## Source and corrected contract

Card Reference65 shaded: “Where you have Control, remove or replace 5
Germanic Warbands and 1 German Ally with your own (Auxilia for Warbands).”
The source applies exactly five/one to the extent possible, not an optional
zero-to-five effect (§5.1.3). Every selection belongs to the executor (§5.1).
An eligible target need not be replaced: a human can select removal alone.
Romans replace Warbands with Auxilia; Gallic executors use their own
Warbands. New troop counters enter Hidden. Allied Tribe identity is exact.

§5.1.1 requires removal rather than replacement when the replacement pool is
empty or placement violates stacking. In particular, replacing a German
Suebi Ally with a non-German Ally is illegal; the valid target is removed.
The handler must not reject the entire effect for that fallback, claim a
replacement without a counter, or place a Gallic Auxilia.

The same printed verb applies to both piece types, with no “then” between
them. Player-ordered entries are supported. This permits placing a scarce
Available troop in the player's chosen Region; later selected replacements
with an exhausted pool still remove the German target. The independent
reviewer confirmed this source reading. No new provisional ruling is used.

Each current physical target must be in a Region Controlled by the executor.
The initial plan validates all physical targets and quotas before mutation.
Normal removal of enemy Germans cannot lose that Control. A genuine timing
interruption may change it, so the exact target and current Control are
rechecked before each atomic remove/replace pair. No resident counter is
substituted for an invalidated selection.

## Public parameter shape

Shaded integer card65 uses `event_params.replacements`, an ordered list with
one entry per physical counter (maximum five Warbands plus one Ally):

```json
{"replacements":[
  {"region":"Nervii","piece_type":"Warband","piece_state":"Scouted","replace":true},
  {"region":"Nervii","piece_type":"Ally","tribe":"Nervii","replace":false}
]}
```

This is valid only when the selected two counters satisfy the required
current-board totals. Warbands require exact `piece_state`; Allies require
exact `tribe`; both require `region`, `piece_type` and strict Boolean
`replace`. Duplicate Warband cohort entries are legal only within the actual
physical count. Unknown fields, forged faction/count fields, duplicate
Allies, unavailable visibility, illegal Control, under-quota and over-quota
plans are rejected. `[]` is legal when there are no eligible targets.

The existing `timing_actions` entry field and `stage_timing_actions` parameter
retain the action-window contract. `65.replacements` is the new entry step.
The terminal collector offers exact current targets and removal/replacement
for each on a detached board, with `board`/`b` and EOF preserving live state.
The complete plan belongs to the existing turn decision, not a new reactive
request kind. Missing or invalid durable input must remain pending.

Legacy `warband_replacements` Region-only plans and
`ally_replacement_tribe` do not describe the new physical choices. They are
not silently converted into hidden-first replacements; affected historical
transcripts require new exact input. Unshaded65 and A65 retain their prior
handlers and identities.

## Non-player execution

The old shaded implementation had no NP parameter deriver. The new deriver
chooses replacement where possible, respects all mandatory physical targets,
prefers own Ally placement, applies City/Remi priority, selects the Region
with most affected Warbands, exhausts it, and removes Hidden before Revealed
before Scouted (§§8.2.3, 8.3.1, 8.3.4, 8.4.1). Equal Region/Tribe choices
use only the seeded state RNG. Applicability checks consume no live RNG or
input. The specific Belgic instruction requires an increase in Belgic
Allies/Citadels, so Warband-only benefits or a restricted Suebi replacement
do not make this Event available to the Belgic bot. Humans retain those
legal choices.

## Related shared durable defect

The real saved-session test caught an additional defect:
`game_engine._maybe_execute` raised `ActionRejected` for invalid human
Commands, but omitted `ACTION_EVENT`. A failed Event handler rolled back
its pieces, yet the outer engine still consumed the Event decision and
eligibility. Root assigned the shared repair to BE-12. Explicit execution or
validation errors now carry an engine-produced `rejected: true` marker;
`ACTION_EVENT` uses the genuine-human rejection transaction for that marker.
Unmarked ineffective Events remain permitted, and NP decisions are excluded
as before. No human-readable reason-string inference controls rejection.
The regression preserves the failed input's pending ID/board/log,
then accepts a corrected mixed removal/replacement plan, saves and replays
the exact final state. Accepted or legal partial Events remain accepted.

## Evidence and verification

- `allegiance-witness.py` extracts the original65 function verbatim from the
  base commit; its supported old parameters and the new explicit parameters
  act on identical physical positions. `allegiance-witness.json` shows the
  old handler removes five German Warbands but leaves Belgae at10, whereas
  the repaired handler leaves Belgae at15. Both states pass integrity.
- `allegiance-existing-01.log`:254 existing card/Event-grant checks passed.
- `allegiance-tests-01.log`: early new tests ran before handler delegation;
  25failed/7passed. Retained as development evidence, not accepted validation.
- `allegiance-tests-02.log`:34passed/1failed; the genuine durable rejection
  defect above, fixed without weakening the assertion.
- `allegiance-tests-03.log`:35passed after the shared rejection fix. A child
  had briefly used this filename for its 34-test passing subset; the later
  parent run replaced that successful subset log. Failed01/02 remain intact.
- `allegiance-focused-04.log`:38passed/1fixture error (nonexistent `rc.REMI`);
  corrected to the canonical `TRIBE_TO_REGION[TRIBE_REMI]` mapping.
- `allegiance-focused-05.log`:203passed, including all39new cases and related
  action-window/Event-grant checks.
- `allegiance-full-01.log`/`.xml`:6,589passed/1failure. The initial blanket
  human Event rejection broke the established legal ineffective-Event test.
  The test was retained and the structured rejection marker introduced.
- `allegiance-rejection-06.log`:59passed after the correction, including the
  existing ineffective-Event regression, real durable invalid retry, direct
  invalid-parameter rejection markers and accepted zero-target Event.
- `allegiance-full-02.log`/`.xml`: **6,590 passed in 118.21s**, exit0;
  zero failures, errors or skips. The same frozen Python bytes were committed
  after independent review cleared the refined rejection marker.

All47 supplied reference files were inventoried and the relevant source
text read. Protected references, constants and the balance baseline remain
unchanged. This does not close other base Event exact-choice findings,
unshaded65's separate guided German March decisions, or A65's distinct
expansion effects. Parent owns progress counts and project documentation.

## Final handoff

Commit **`b17e2f6d8297501c16288cfd5de04ae61b19a774`**; no push. The tracked
worktree is clean; one unrelated preexisting temporary ZIP remains untracked.
Final Python source has410files, SHA-256
`823637debbebc09b3efe4748e26f114f03745a28e60a683ea608f3c3a39f3a8a`.
No Python edits occurred during the accepted full run or before commit.

Integration merge points: named65 branch in CLI `_collect_event_params`,
parameter-schema override65, event-availability early65/shaded branch,
`_EVENT_PARAM_DERIVERS[65]`, and the structured rejection flags in
`execute_decision`/`_execute_event`. **Retain `rejected: true` when merging
the base validator agent's widened human `event_params` object guard.**
The shared `game_engine._maybe_execute` now rejects only marked human Event
failures; keep the unchanged ineffective-Event test passing.
