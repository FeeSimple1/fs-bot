"""Unchanged probes against APIs available before the Slingers repair."""
import pytest
from fs_bot import rules_consts as rc
from fs_bot.state.state_schema import build_initial_state
from fs_bot.board.pieces import place_piece, count_pieces
from fs_bot.cards.capabilities import activate_capability
from fs_bot.engine.execute import _execute_battle

REGIONS=(rc.TREVERI,rc.MANDUBII)


def position(defender=rc.AEDUI, auxiliaries=(6,2)):
    st=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=11)
    st['resources'][rc.BELGAE]=10
    st['non_player_factions']=set(rc.FACTIONS)-{rc.ROMANS}
    for r,n in zip(REGIONS,auxiliaries):
        place_piece(st,r,rc.BELGAE,rc.WARBAND,6)
        if n:place_piece(st,r,rc.ROMANS,rc.AUXILIA,n)
        if defender!=rc.ROMANS:place_piece(st,r,defender,rc.WARBAND,6)
    activate_capability(st,13,rc.EVENT_UNSHADED)
    action={'sa':None,'sa_regions':[],
            'details':{'battle_plan':[{'region':r,'target':defender} for r in REGIONS]}}
    return st,action


def combat_probe(monkeypatch):
    rows=[]
    def combat(st,region,attacker,defender,**kwargs):
        rows.append((region,count_pieces(st,region,attacker,rc.WARBAND)))
        return {}
    monkeypatch.setattr('fs_bot.engine.execute.resolve_battle',combat)
    return rows


@pytest.mark.parametrize('defender',[rc.ROMANS,rc.AEDUI])
def test_roman_selects_smaller_second_region(defender,monkeypatch):
    st,action=position(defender)
    seen=[]
    def agent(board,faction,request):
        if request['kind']=='slingers_region':
            seen.append(faction)
            return {'region':REGIONS[1]}
    st['decision_agent']=agent
    rows=combat_probe(monkeypatch)
    _execute_battle(st,rc.BELGAE,action)
    assert seen==[rc.ROMANS]
    assert rows==[(REGIONS[0],6),(REGIONS[1],5)]


def test_both_capabilities_give_full_prefire(monkeypatch):
    st,action=position(auxiliaries=(2,0))
    action['details']['battle_plan']=action['details']['battle_plan'][:1]
    activate_capability(st,59,rc.EVENT_UNSHADED)
    rows=combat_probe(monkeypatch)
    _execute_battle(st,rc.BELGAE,action)
    assert rows==[(REGIONS[0],4)]


def test_npc_uses_first_applicable_region(monkeypatch):
    st,action=position()
    action['details']['battle_plan'].reverse()
    rows=combat_probe(monkeypatch)
    _execute_battle(st,rc.BELGAE,action)
    assert rows==[(REGIONS[1],5),(REGIONS[0],6)]


def test_standard_prefire_default_control(monkeypatch):
    st,action=position()
    rows=combat_probe(monkeypatch)
    _execute_battle(st,rc.BELGAE,action)
    assert rows==[(REGIONS[0],3),(REGIONS[1],6)]


def test_inactive_unshaded_control(monkeypatch):
    st,action=position()
    activate_capability(st,13,rc.EVENT_SHADED)
    rows=combat_probe(monkeypatch)
    _execute_battle(st,rc.BELGAE,action)
    assert rows==[(r,6) for r in REGIONS]
