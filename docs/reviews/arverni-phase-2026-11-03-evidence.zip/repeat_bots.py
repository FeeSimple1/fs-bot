"""Repeat selected audited bot games under a second Python hash seed."""
import argparse
import json
import os
import platform
import sys
from pathlib import Path
from integration_matrix import REPO, SCENARIOS, identity, write_json
sys.path.insert(0, str(REPO))
from fs_bot.tools.run_batch import play_one
parser = argparse.ArgumentParser()
parser.add_argument('--out', required=True)
args = parser.parse_args()
out = Path(args.out)
assert not out.exists(), 'Never overwrite an earlier run'
before = identity()
rows = [play_one((scenario, seed, 'legacy')) for scenario in SCENARIOS for seed in range(1, 6)]
assert identity() == before, 'Source changed during repeat'
write_json(out, {'metadata': {'source': before, 'python': platform.python_version(),
                             'hash_seed': int(os.environ['PYTHONHASHSEED']),
                             'edition': 'legacy', 'seeds': list(range(1,6))}, 'records': rows})
print(json.dumps({'games': len(rows), 'completed': sum(r['completed'] for r in rows)}))
raise SystemExit(0 if all(r['completed'] for r in rows) else 1)
