"""Verify the preserved Batch 1 test, replay, and outcome records."""

from collections import Counter
import json
from pathlib import Path
from xml.etree import ElementTree

from fs_bot import rules_consts as rc
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


EVIDENCE = Path(__file__).resolve().parent
PARENT = '33c722e941292f8cb0a66e3cedc0d5efa995b0e2'
PARENT_DIGEST = '3c047ebcfef915efef8e1da308cd63484b1e6c735b8aba8e5c095de2c5d106b9'


def load(name):
    return json.loads((EVIDENCE / name).read_text())


def outcome_key(row):
    return row['scenario'], row['seed'], row['card_edition']


def test_totals(name):
    suites = list(ElementTree.parse(EVIDENCE / name).iter('testsuite'))
    return {k: sum(int(s.get(k, 0)) for s in suites)
            for k in ('tests', 'failures', 'errors', 'skipped')}


def read_batch(directory, seeds, edition, digest):
    meta = load(f'{directory}/metadata.json')
    assert meta['source_sha256'] == digest
    assert set(meta['scenarios']) == set(SCENARIOS)
    assert meta['seeds'] == list(seeds) and meta['card_edition'] == edition
    assert meta['hash_seed'] == 0
    records = [json.loads(line) for line in
               (EVIDENCE / directory / 'games.jsonl').read_text().splitlines()]
    keyed = {outcome_key(r): r for r in records}
    assert len(records) == len(keyed) == len(SCENARIOS) * len(seeds)
    assert set(keyed) == {(s, n, edition) for s in SCENARIOS for n in seeds}
    for row in records:
        assert row['source_sha256'] == digest
        assert all(row[k] is True for k in ('completed', 'game_completed', 'audit_completed'))
        assert not row.get('error') and not row['errors'] and not row['integrity_findings']
        assert not _outcome_issues(row)
        assert len(row['final_state_sha256']) == 64
        assert all(d['severity'] == 'legal-decline' for d in row['diagnostics'])
        assert all(d['severity'] == 'legal-decline' for d in row['diagnostic_occurrences'])
        assert sum(d['count'] for d in row['diagnostics']) == len(row['diagnostic_occurrences'])
    return keyed, meta


def compare_batches(current, parent):
    keys = ('final_state_sha256', 'winner', 'cards', 'winters', 'ended_on_final_winter')
    changes = {key: [list(k) for k in current if current[k][key] != parent[k][key]]
               for key in keys}
    return {'games': len(current), 'interludes': sum(r['interlude_completed'] for r in current.values()),
            'diagnostic_incidents': sum(len(r['diagnostic_occurrences']) for r in current.values()),
            'changes': changes}


def compare_traces(old, new, previous_games, current_games, changes, source):
    assert old['source']['commit'] == PARENT and old['source']['source_sha256'] == PARENT_DIGEST
    assert not old['source']['dirty']
    assert new['source']['source_sha256'] == source['source_sha256']
    assert new['source']['commit'] == PARENT
    expected = {tuple(row) for row in changes['changes']['final_state_sha256']}
    trace_keys = {(rc.SCENARIO_GALLIC_WAR, g['seed'], 'legacy') for g in new['games']}
    assert trace_keys == expected and len(trace_keys) == 6
    review = []
    for a, b in zip(old['games'], new['games'], strict=True):
        key = (rc.SCENARIO_GALLIC_WAR, a['seed'], 'legacy')
        assert a['seed'] == b['seed']
        for run, matrix in [(a, previous_games), (b, current_games)]:
            assert all(matrix[key][k] == v for k, v in run['outcome'].items())
        before, after = next((x, y) for x, y in zip(a['cards'], b['cards']) if x != y)
        assert before['card'] == after['card'] == rc.WINTER_CARD
        assert before['number'] == after['number']
        assert before['before_sha256'] == after['before_sha256']
        assert before['before_rng_sha256'] == after['before_rng_sha256']
        assert before['winter_count_before'] == after['winter_count_before'] == 6
        assert before['remaining_winters'] == after['remaining_winters'] == 1
        assert before['is_final'] and not after['is_final']
        if after['game_over']:
            assert before['game_over'] and before['winner'] == after['winner']
            assert after['winner'] == after['threshold_winner_before']
            assert before['after_without_finality_sha256'] == after['after_without_finality_sha256']
            change = 'corrected-finality-marker'
        else:
            assert before['game_over'] and not after['threshold_winner_before']
            assert 'spring' in after['phases']
            assert b['outcome']['winters'] == 8 and b['outcome']['ended_on_final_winter']
            assert a['outcome']['winner'] == rc.AEDUI and b['outcome']['winner'] == rc.BELGAE
            change = 'continues-to-last-winter'
        review.append({'seed': a['seed'], 'first_change': change,
                       'parent_boundary': before, 'fixed_boundary': after,
                       'parent_outcome': a['outcome'], 'fixed_outcome': b['outcome']})
    assert Counter(row['first_change'] for row in review) == {
        'corrected-finality-marker': 4, 'continues-to-last-winter': 2}
    return review


def main():
    source = load('source.json')
    assert source['commit'] == PARENT
    assert source_identity()['source_sha256'] == source['source_sha256']
    parent_tests = test_totals('directed-parent.xml')
    directed_tests = test_totals('directed-fixed.xml')
    full_tests = test_totals('pytest.xml')
    assert parent_tests == dict(tests=10, failures=5, errors=0, skipped=0)
    assert directed_tests == dict(tests=103, failures=0, errors=0, skipped=0)
    assert full_tests == dict(tests=10126, failures=0, errors=0, skipped=0)

    legacy, legacy_meta = read_batch('bots-legacy', range(1, 21), 'legacy', source['source_sha256'])
    second, second_meta = read_batch('bots-second', range(45, 49), 'second-edition', source['source_sha256'])
    assert legacy_meta['commit'] == second_meta['commit'] == PARENT
    old_legacy, old_legacy_meta = read_batch('parent/bots-legacy', range(1, 21), 'legacy', PARENT_DIGEST)
    old_second, old_second_meta = read_batch('parent/validation/bots-second', range(45, 49), 'second-edition', PARENT_DIGEST)
    legacy_summary = compare_batches(legacy, old_legacy)
    second_summary = compare_batches(second, old_second)
    assert not any(second_summary['changes'].values())
    review = compare_traces(load('trace-parent.json'), load('trace-fixed.json'),
                            old_legacy, legacy, legacy_summary, source)

    fuzz = load('fuzz0.json')
    for extension in ('json', 'log'):
        assert (EVIDENCE / f'fuzz0.{extension}').read_bytes() == (EVIDENCE / f'fuzz987.{extension}').read_bytes()
    expected = {(s, n, 'second-edition') for s in SCENARIOS for n in range(45, 49)}
    assert len(fuzz['records']) == fuzz['games'] == len(expected)
    assert {outcome_key(r) for r in fuzz['records']} == expected
    assert not fuzz['hard_findings'] and not fuzz['partial']
    assert all(r['game_completed'] and not r['findings'] for r in fuzz['records'])
    assert fuzz['metadata']['source_sha256'] == source['source_sha256']
    assert all(fuzz['metadata'][k] for k in ('reactive', 'events', 'replay'))
    for key in ('human_turns', 'event_turns', 'events_ok'):
        assert fuzz[key] == sum(r[key] for r in fuzz['records'])
    assert fuzz['records'] == load('parent/validation/fuzz0.json')['records']
    balance = (EVIDENCE / 'balance.log').read_text()
    assert 'OK: balance within band (2 winner changes)' in balance
    assert '2 game(s) changed winner: The Gallic War|1, The Gallic War|7' in balance

    print(json.dumps({
        'source': source, 'parent_directed': parent_tests, 'fixed_focused': directed_tests,
        'full_suite': full_tests, 'legacy': legacy_summary, 'second_edition': second_summary,
        'parent_game_sources': {'legacy': old_legacy_meta, 'second_edition': old_second_meta},
        'paired_trace_review': review,
        'mixed': {**{k: fuzz[k] for k in ('games', 'human_turns', 'event_turns', 'events_ok',
                                          'partial', 'hard_findings', 'batch_digest')},
                  'hash_seeds': [0, 987], 'json_and_stdout_match': True,
                  'all_records_match_parent': True},
        'balance': {'games': 100, 'band_percentage_points': 15, 'max_drift_percentage_points': 10,
                    'changed_winners': 2, 'passed': True, 'baseline_refreshed': False},
    }, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
