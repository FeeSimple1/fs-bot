"""Round-five witnesses, asserting observed defects at audited bd30d522.
Run from the fs-bot checkout with PYTHONPATH=. python /path/probe_battle.py.
"""
import json
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND, ACTION_EVENT
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.tools.seat_session import validate_response
from fs_bot.cards.card_data import get_ariovistus_event_card_ids


def board(seed=1):
    state = build_initial_state(rc.SCENARIO_ARIOVISTUS, seed=seed)
    state['non_player_factions'] = set()
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    for f in (rc.ROMANS,rc.GERMANS,rc.AEDUI): state['resources'][f] = 20
    return state


def integrity(state):
    errors = {'census': validate_state(state), 'structure': check_structural_integrity(state)}
    assert not any(errors.values()), errors
    return errors


def event(state, card, faction, shaded=False, params=None):
    state['current_card'] = card
    result = execute_decision(state, faction, {'action': ACTION_EVENT, 'player_action': {'command': rc.FIRST_DID_EVENT, 'regions': [], 'sa': 'No SA', 'sa_regions': [], 'details': {'card_id': card, 'text_preference': rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED, 'event_params': params or {}}}})
    assert result['executed'] and not result.get('errors'), result
    return result


def battle(state, attacker, defender):
    response = {'action': ACTION_COMMAND, 'player_action': {
        'command': rc.CMD_BATTLE, 'sa': 'No SA', 'regions': [rc.CARNUTES],
        'details': {'battle_plan': [{'region': rc.CARNUTES, 'target': defender}]}}}
    validate_response(state, {'kind': 'turn', 'faction': attacker, 'options':[ACTION_COMMAND]}, response)
    result = execute_decision(state, attacker, response)
    assert result['executed'] and not result.get('errors'), result
    return result


def legio(stalwart, legio):
    state = board()
    place_piece(state,rc.CARNUTES,rc.ROMANS,rc.LEADER,leader_name=rc.CAESAR)
    place_piece(state,rc.CARNUTES,rc.ROMANS,rc.LEGION,1,from_legions_track=True)
    place_piece(state,rc.CARNUTES,rc.GERMANS,rc.WARBAND,8)
    if stalwart:event(state,'A31',rc.GERMANS,True)
    if legio:event(state,15,rc.ROMANS)
    before=integrity(state)
    requests=[]
    def choice(s,owner,req):
        requests.append({'owner':owner,'kind':req['kind'],'num_losses':req.get('num_losses')})
        if req['kind']=='retreat':return {'retreat':False}
        return None
    state['decision_agent']=choice
    result=battle(state,rc.ROMANS,rc.GERMANS)
    return {'stalwart':stalwart,'legio_x':legio,'before':before,'after':integrity(state),
            'german_survivors':count_pieces(state,rc.CARNUTES,rc.GERMANS,rc.WARBAND),
            'battle_result':result,'requests':requests}


def abatis(marker=True):
    state=board()
    place_piece(state,rc.CARNUTES,rc.ROMANS,rc.LEGION,4 if marker else 2,from_legions_track=True)
    place_piece(state,rc.CARNUTES,rc.AEDUI,rc.WARBAND)
    _ally_tribe(state,rc.TRIBE_AULERCI,rc.AEDUI)
    if marker:event(state,'A64',rc.AEDUI,params={'region':rc.CARNUTES})
    before=integrity(state)
    requests=[]
    def choose(s,owner,req):
        requests.append({'owner':owner,'kind':req['kind'],'pieces':req.get('pieces')})
        if req['kind']=='retreat':return {'retreat':False}
        if req['kind']=='loss_order':
            allies=[p for p in req['pieces'] if p[0]==rc.ALLY]
            return allies or [req['pieces'][0]]
        return None
    state['decision_agent']=choose
    result=battle(state,rc.ROMANS,rc.AEDUI)
    return {'marker_initially':marker,'before':before,'after':integrity(state),
            'ally_after':state['tribes'][rc.TRIBE_AULERCI]['allied_faction'],
            'abatis_after':state['markers'].get(rc.CARNUTES, {}).get(rc.MARKER_ABATIS),
            'requests':requests,'battle_result':result}



def diviciacus_abatis(marker=True):
    state=board(seed=2)
    place_piece(state,rc.CARNUTES,rc.ROMANS,rc.LEGION,4 if marker else 2,from_legions_track=True)
    place_piece(state,rc.CARNUTES,rc.AEDUI,rc.WARBAND)
    place_piece(state,rc.CARNUTES,rc.AEDUI,rc.LEADER,leader_name=rc.DIVICIACUS)
    if marker:event(state,'A64',rc.AEDUI,params={'region':rc.CARNUTES})
    else:_ally_tribe(state,rc.TRIBE_AULERCI,rc.AEDUI)
    before=integrity(state)
    requests=[]
    def choose(s,owner,req):
        requests.append({'owner':owner,'kind':req['kind'],'pieces':req.get('pieces')})
        if req['kind']=='retreat':return {'retreat':False}
        return None
    state['decision_agent']=choose
    result=battle(state,rc.ROMANS,rc.AEDUI)
    return {'before':before,'after':integrity(state),'requests':requests,
            'diviciacus_after':count_pieces(state,rc.CARNUTES,rc.AEDUI,rc.LEADER),
            'abatis_after':state['markers'].get(rc.CARNUTES,{}).get(rc.MARKER_ABATIS),
            'battle_result':result}


def main():
    assert {15,'A31','A64'}.issubset(get_ariovistus_event_card_ids())
    out={'legio_cases':[legio(True,True),legio(True,False),legio(False,True)],
         'abatis_cases':[abatis(True),abatis(False)],
         'diviciacus_abatis':diviciacus_abatis(),
         'diviciacus_ally_control':diviciacus_abatis(False),
         'deck_coexistence':{str(card):card in get_ariovistus_event_card_ids() for card in (15,'A31','A64')}}
    print(json.dumps(out,indent=2,default=str))
    assert [x['german_survivors'] for x in out['legio_cases']]==[4,6,3]
    a,c=out['abatis_cases']
    assert a['ally_after']==rc.AEDUI and a['abatis_after'] is None
    assert c['ally_after'] is None
    assert out['diviciacus_abatis']['diviciacus_after']==0
    assert out['diviciacus_abatis']['abatis_after']==rc.AEDUI
    assert out['diviciacus_ally_control']['diviciacus_after']==1
    assert len([x for x in a['requests'] if x['kind']=='loss_order'])==1
    assert len([x for x in c['requests'] if x['kind']=='loss_order'])==2

if __name__=='__main__':main()
