# Additional independent source review: UI10-02

Section 4.5.1 (`Reference Documents/Chapter 4:215–222`) assigns the free
German Limited Command choices to the player executing Enlist. Section
3.4.2 (`Chapter 3:354–358`) permits any Warbands to stay behind, so either
initial cohort can be selected in one legal base-game group. Sections
3.3.2 and 3.4 form the group, apply origin visibility changes and move
that group. Section 4.2.2 (`Chapter 4:83–86`) correctly converts a Scouted
Warband to Revealed when it would otherwise Hide.

The defect is losing the selected cohort across that conversion: the
accepted Scouted counter should move as Revealed, while the unselected
Hidden counter remains at the origin. Substituting the latter changes
the player's choice. Conversion from Scouted to Revealed itself is
required and correct. Automatic Germans-Phase priorities do not remove
the Enlist player's explicit choice. No new interpretation is needed.
