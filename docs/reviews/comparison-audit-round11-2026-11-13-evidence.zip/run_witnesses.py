"""Reproduce eleventh-audit witnesses on the audited Falling Sky source."""

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    repo = args.repo.resolve()
    env = dict(os.environ, PYTHONPATH=str(repo), PYTHONDONTWRITEBYTECODE='1')
    identity = json.loads(subprocess.check_output([
        sys.executable, '-c',
        'import json; from fs_bot.tools.validation_metadata import source_identity; '
        'print(json.dumps(source_identity()))'], cwd=repo, env=env))
    source = json.loads((root / 'validation/source.json').read_text())
    assert identity['source_sha256'] == source['source_sha256'], identity
    protected = json.loads((root / 'validation/protected-sources.json').read_text())
    for path, digest in protected.items():
        assert hashlib.sha256((repo / path).read_bytes()).hexdigest() == digest, path

    def run_lane(lane):
        probe = root / lane / f'probe_{lane}.py'
        outputs = []
        for seed in ('0', '987'):
            expected = (root / lane / 'results.json').read_bytes()
            with tempfile.TemporaryDirectory(prefix='falling-sky-audit11-') as temp:
                run = subprocess.run([sys.executable, str(probe), '--repo', str(repo)],
                                     cwd=temp, env=dict(env, PYTHONHASHSEED=seed),
                                     capture_output=True, timeout=240)
            assert run.returncode == 0, (lane, seed, run.stderr.decode())
            assert not run.stderr, (lane, seed, run.stderr.decode())
            json.loads(run.stdout)
            assert run.stdout == expected, (lane, seed, 'preserved output mismatch')
            outputs.append(run.stdout)
        assert outputs[0] == outputs[1], lane
        return {'lane': lane, 'hash_seeds': [0, 987], 'byte_identical': True,
                'preserved_output_matches': True,
                'sha256': hashlib.sha256(outputs[0]).hexdigest()}

    lanes = ('battle', 'bots', 'events', 'frontend', 'lifecycle')
    with ThreadPoolExecutor(max_workers=3) as executor:
        results = list(executor.map(run_lane, lanes))
    print(json.dumps({'source_sha256': identity['source_sha256'],
                      'protected_files_verified': len(protected),
                      'witnesses': results}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
