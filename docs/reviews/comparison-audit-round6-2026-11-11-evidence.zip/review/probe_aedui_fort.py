"""Source-derived witness for Aedui high-value target guarantee versus Fort absorption."""
import json
from fs_bot import rules_consts as rc
from fs_bot.state.state_schema import build_initial_state,validate_state,check_structural_integrity
from fs_bot.board.pieces import place_piece,count_pieces
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND
from fs_bot.engine.victory import check_victory

def run(fort=True):
 s=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=1)
 s['non_player_factions']={rc.AEDUI,rc.BELGAE,rc.ARVERNI}
 s['can_play_event']=False;s['_command_with_sa']=False;s['resources'][rc.AEDUI]=10
 place_piece(s,rc.PROVINCIA,rc.ROMANS,rc.FORT)
 place_piece(s,rc.CARNUTES,rc.AEDUI,rc.WARBAND,4)
 assert _ally_tribe(s,rc.TRIBE_CARNUTES,rc.ROMANS)
 for t in (rc.TRIBE_AEDUI,rc.TRIBE_VENETI):assert _ally_tribe(s,t,rc.AEDUI)
 if fort:place_piece(s,rc.CARNUTES,rc.ROMANS,rc.FORT)
 before={'census':validate_state(s),'structure':check_structural_integrity(s)}
 assert not any(before.values()),before
 assert check_victory(s,rc.AEDUI)
 requests=[]
 def agent(st,owner,req):
  requests.append({'owner':owner,**req})
  if req['kind']=='loss_order' and owner==rc.ROMANS and fort:return [(rc.FORT,None)]
  if req['kind']=='retreat':return {'retreat':False}
 s['decision_agent']=agent
 action=dispatch_bot_turn(s,rc.AEDUI)
 result=execute_decision(s,rc.AEDUI,{'action':ACTION_COMMAND,'bot_action':action})
 assert result['executed'] and not result.get('errors'),result
 after={'census':validate_state(s),'structure':check_structural_integrity(s)}
 assert not any(after.values()),after
 return {'fort_initial':fort,'before':before,'after':after,'action':action,'result':result,
 'roman_ally_survived':s['tribes'][rc.TRIBE_CARNUTES]['allied_faction']==rc.ROMANS,
 'fort_survived':count_pieces(s,rc.CARNUTES,rc.ROMANS,rc.FORT),'requests':requests}
if __name__=='__main__':
 out=[run(),run(False)]
 assert out[0]['action']['command']==rc.CMD_BATTLE
 assert out[0]['roman_ally_survived'] and not out[1]['roman_ally_survived']
 print(json.dumps(out,indent=2))
