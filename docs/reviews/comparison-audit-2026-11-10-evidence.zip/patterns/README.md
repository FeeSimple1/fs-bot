# Cross-cutting comparison evidence

The audit uses Falling Sky `b23c8cd73c9747e6e39157a042a1af13cc703a48` and Liberty or Death `2991ea279062773548ec390a1da75f3e85381702`.

XC2-01 reproduces a saved, accepted two-Region Limited Recruit through the file-based assistant. A one-element `command_parts` field substitutes a smaller plan during validation while the executor acts on the outer `recruit_plan`. The same outer plan is rejected when the extra field is absent.

Run from the Falling Sky repository root.

```sh
PYTHONPATH=. python ../comparison-audit-2026-11-10/patterns/probe_shadow_parts.py
```

The probe asserts the current defective outcome. `shadow-parts-result.json` preserves the observed result. `findings.json` records source sections, code locations in both repositories, repair scope and coverage limits. Gameplay files were not edited.
