"""Old-API probes: six repaired behavior failures and two legacy controls."""
import pytest
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces
from fs_bot.cards.card_effects import execute_event
from fs_bot.state.state_schema import build_initial_state


def position():
    state=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=17)
    state['executing_faction']=rc.AEDUI
    state['event_params']={}
    place_piece(state,rc.SEQUANI,rc.ARVERNI,rc.WARBAND,3,piece_state=rc.SCOUTED)
    place_piece(state,rc.SEQUANI,rc.ARVERNI,rc.WARBAND,3,piece_state=rc.HIDDEN)
    place_piece(state,rc.SEQUANI,rc.ROMANS,rc.AUXILIA,2,piece_state=rc.REVEALED)
    place_piece(state,rc.SEQUANI,rc.AEDUI,rc.WARBAND,10)
    return state


def selection(action=None):
    entry={'region':rc.SEQUANI,'target_faction':rc.ARVERNI,'piece_type':rc.WARBAND,
           'piece_state':rc.SCOUTED,'count':1}
    if action:entry['action']=action
    return entry


@pytest.mark.parametrize('count',[0,2])
def test_lucterius_smaller_auxilia_quantity(count):
    state=position();state['event_params']={'choice':'auxilia','count':count}
    execute_event(state,19)
    assert count_pieces(state,rc.PROVINCIA,rc.ROMANS,rc.AUXILIA)==count


def test_lucterius_smaller_exact_warband_quantity():
    state=position();state['event_params']={'choice':'warbands','removals':[selection()]}
    execute_event(state,19)
    assert count_pieces(state,rc.SEQUANI,rc.ARVERNI,rc.WARBAND)==5


@pytest.mark.parametrize('mode',['remove','replace'])
def test_hostages_live_choice_removes_and_optionally_replaces(mode):
    state=position();seen=[]
    def agent(board,faction,request):
        if request['kind']=='event_piece_choice':
            seen.append(request)
            return {'selections':[selection(mode)]}
    state['decision_agent']=agent
    execute_event(state,22)
    assert len(seen)==1
    assert count_pieces(state,rc.SEQUANI,rc.ARVERNI,rc.WARBAND)==5
    assert count_pieces(state,rc.SEQUANI,rc.AEDUI,rc.WARBAND)==(11 if mode=='replace' else 10)


def test_hostages_legacy_auxilia_target_gives_gallic_warband():
    state=position();state['event_params']={'replacements':[{'region':rc.SEQUANI,
        'target_faction':rc.ROMANS,'piece_type':rc.AUXILIA}]}
    execute_event(state,22)
    assert count_pieces(state,rc.SEQUANI,rc.AEDUI,rc.WARBAND)==11


def test_legacy_lucterius_maximum_default_control():
    state=position();execute_event(state,19)
    assert count_pieces(state,rc.PROVINCIA,rc.ROMANS,rc.AUXILIA)==5


def test_legacy_hostages_warband_replacement_control():
    state=position();state['event_params']={'replacements':[{'region':rc.SEQUANI,
        'target_faction':rc.ARVERNI,'piece_type':rc.WARBAND}]}
    execute_event(state,22)
    assert count_pieces(state,rc.SEQUANI,rc.AEDUI,rc.WARBAND)==11
