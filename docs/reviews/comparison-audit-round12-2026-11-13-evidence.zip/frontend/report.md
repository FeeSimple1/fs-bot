# Twelfth comparison audit — human interfaces

The focused frontend review confirms no new defect. Four scripted terminal controls passed on the pinned Falling Sky revision `1563e41d84f61dfce43ce4008106eca2a1639aed`. Their outputs match byte for byte under hash seeds 0 and 987. A separate selection of 113 existing regressions passed.

## Cross-repository comparison

The Liberty or Death checkout is `2991ea279062773548ec390a1da75f3e85381702`. The review read its actual detached action simulation and commit code in `lod_ai/engine.py`, lines 947–972, and its human free-operation handling at lines 652–704. The latter retains the original state and restores it if a human operation fails. The special-ability wizard in `lod_ai/interactive_cli.py`, lines 1017–1070, tests accompanying-command restrictions using copies of state and context. Its Muster planning at lines 700–740 carries earlier placements into the preview for subsequent choices. These supplied concrete comparisons for checking whether Falling Sky computes later options on the evolving preview, prevents reusing physical pieces, and leaves the live board and RNG intact during collection.

Falling Sky's rules judgments use `Reference Documents/Chapter 4`, lines 43–63 for Build and lines 69–81 for Scout. The adopted rulings in `docs/provisional-rulings.md` were reviewed. No new rules interpretation is introduced.

## Executed controls

| Case | Scenarios | Verified behavior |
|---|---|---|
| March in place followed by Build | The Great Revolt, Ariovistus | The real terminal offers both Fort placement and an Ally at Helvetii in Sequani in the same Build. Public execution spends two Resources on March and four on Build, leaving 14 from 20. |
| March in place followed by Scout | The Great Revolt, Ariovistus | The terminal moves one Hidden Auxilia from Morini to Nervii and excludes that arrival from further Scout movement. The other Auxilia Reveals at Morini to mark one Hidden Belgic and one Revealed Arverni Warband Scouted. March costs two Resources. |

Every control begins with `build_initial_state` and canonical piece placements. A Roman Fort is placed in Provincia to satisfy its structural requirement. The positions are sparse constructed boards with a Roman victory threshold already exceeded. They test individual actions and menus, and do not establish normal-game encounter rates or Victory Phase behavior. No full setup, full turn sequencing or pending-session interruption is claimed.

Each control invokes `collect_player_action` with the real reactive CLI agent and an input stream that supplies menu labels. The stream automatically chooses to remove no pieces at voluntary-removal prompts and declines optional Resource gifts. No production function or rules mechanic is mocked. The plan passes the same `validate_response` turn validation used by SeatSession, then executes through public `execute_decision`. A serialized and reloaded board executes the identical plan and produces an identical result and final board/RNG. Census and structural integrity are clean before and after. The collection itself preserves the original board and RNG exactly.

`probe_frontend.py` reproduces these controls. `results.json` and `results.hash987.json` contain plans, results, integrity checks and full transcripts. The first exploratory Build run exhausted its test input at the optional gift prompt. The input stream was completed and both final hash-seed runs pass.

The separate test invocation used `test_build_order.py`, `test_scout_allocations.py`, `test_scoped_german_settle.py` and `test_cli_supply_refusal.py`. All 113 tests pass. The only warning is an external anyio plugin using the deprecated pytest CallSpec2 alias. Some existing tests use their own mocks. The four new audit controls do not.

## Static review and rejected candidates

The review also inspected `fs_bot/cli/human_plan.py`, `free_actions.py`, `command_interruptions.py`, `command_timing.py`, `sa_timing.py`, `roman_timing.py`, `quarters.py`, `supply.py`, `frumentum.py`, `reactive.py`, `base_event_limits.py`, `german_guidance.py`, `mons_cevenna.py` and `assembly_of_gaul.py`, plus `fs_bot/tools/seat_session.py`, the shared action validator, typed Event schema, Build and Settle mechanics.

The legacy Build collector only authors one operation per Region. This was not retained as a normal terminal defect because the live reactive agent enables the current collector, which passes the Fort-and-Ally controls. The generic Settle fallback begins with Regions containing German pieces. German Control requires German pieces, and the live scalar collector dynamically checks newly placed adjacent Settlements, so that initial suspicion did not demonstrate an omitted legal target. Scoped free-action menus pass candidate plans through the shared grant validator, and reviewed previous audits already cover missing Winter Enlist combinations, repeated Winter Battles, March drop-offs and Quarters replay signatures.

The review of these additional consumers was static except for the explicitly identified 113 existing tests. The four fresh controls establish only the behaviors in the table. They provide no general proof that every human choice is exposed or that all serialized pending decisions resume correctly.
