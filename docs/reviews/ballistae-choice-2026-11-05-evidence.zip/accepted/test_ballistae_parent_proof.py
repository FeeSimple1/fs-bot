"""Behavior probes using only APIs that already exist in the parent."""
import pytest
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces
from fs_bot.cards.capabilities import activate_capability, set_capability_owner
from fs_bot.engine.execute import _execute_battle
from fs_bot.state.state_schema import build_initial_state


def position(owner=rc.BELGAE, permanent=False):
    st = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=17)
    st['non_player_factions'] = set(rc.FACTIONS) - {owner}
    st['resources'][owner] = 10
    region = rc.PROVINCIA if permanent else rc.SEQUANI
    defender = rc.ROMANS if permanent else rc.AEDUI if owner == rc.ARVERNI else rc.ARVERNI
    place_piece(st, region, owner, rc.WARBAND)
    if owner in (rc.BELGAE, rc.ARVERNI):
        place_piece(st, region, owner, rc.LEADER,
                    leader_name=rc.AMBIORIX if owner == rc.BELGAE else rc.VERCINGETORIX)
    piece = rc.FORT if permanent else rc.CITADEL
    place_piece(st, region, defender, piece)
    if not permanent:
        st['tribes'][rc.TRIBE_SEQUANI]['allied_faction'] = defender
    soft = rc.AUXILIA if permanent else rc.WARBAND
    place_piece(st, region, defender, soft, 4, piece_state=rc.REVEALED)
    activate_capability(st, 10, rc.EVENT_SHADED)
    set_capability_owner(st, 10, owner)
    action = {'sa':rc.SA_AMBUSH,'sa_regions':[region],
              'details':{'battle_plan':[{'region':region,'target':defender}]}}
    return st, region, defender, piece, action


@pytest.mark.parametrize('owner',[rc.BELGAE,rc.ARVERNI,rc.AEDUI])
def test_owner_declines_post_ambush_removal(owner):
    st, region, defender, piece, action = position(owner)
    seen = []
    def agent(board,faction,request):
        if request['kind']=='ballistae_target':
            seen.append(faction)
            return {'decline':True}
    st['decision_agent']=agent
    result = _execute_battle(st,owner,action,_ambush_anywhere=True)
    assert result['executed'] and not result['errors']
    assert seen==[owner]
    assert count_pieces(st,region,defender,piece)==1


def test_provincia_permanent_fort_survives_post_ambush():
    st, region, defender, piece, action = position(permanent=True)
    try:
        result = _execute_battle(st,rc.BELGAE,action)
    except Exception as exc:
        pytest.fail('Post-Ambush removal attempted the permanent Fort: '+str(exc))
    assert result['executed'] and not result['errors']
    assert count_pieces(st,region,defender,piece)==1


def test_raw_default_control():
    st, region, defender, piece, action = position()
    result = _execute_battle(st,rc.BELGAE,action)
    assert result['executed'] and not result['errors']
    assert count_pieces(st,region,defender,piece)==0


def test_wrong_capability_owner_control():
    st, region, defender, piece, action = position()
    set_capability_owner(st,10,rc.AEDUI)
    result = _execute_battle(st,rc.BELGAE,action)
    assert result['executed'] and not result['errors']
    assert count_pieces(st,region,defender,piece)==1
