"""Round-five bot witnesses. Run with PYTHONPATH pointing at audited fs-bot.

These assertions intentionally demonstrate the audited defects. They are not
rule-correct regression expectations. All counters are placed with helpers in
controlled initialized positions; no claim is made of sampled-game reachability.
"""
from copy import deepcopy
import json

from fs_bot import rules_consts as rc
from fs_bot.battle.resolve import resolve_battle
from fs_bot.board.pieces import count_pieces, get_leader_in_region, place_piece
from fs_bot.bots.aedui_bot import node_a4, node_a_rally
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.bots.german_bot import _estimate_battle_losses
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND
from fs_bot.state.state_schema import (
    build_initial_state, check_structural_integrity, validate_state,
)
from fs_bot.tools.seat_session import validate_response


def integrity(state):
    assert validate_state(state) == [], validate_state(state)
    assert check_structural_integrity(state) == [], check_structural_integrity(state)


def board(scenario=rc.SCENARIO_ARIOVISTUS, seed=5):
    state = build_initial_state(scenario, seed=seed)
    state['non_player_factions'] = set(
        (rc.ROMANS, rc.AEDUI, rc.BELGAE, rc.GERMANS)
        if scenario in rc.ARIOVISTUS_SCENARIOS else
        (rc.ROMANS, rc.AEDUI, rc.BELGAE, rc.ARVERNI))
    state['can_play_event'] = False
    state['_command_with_sa'] = False
    state['resources'][rc.AEDUI] = 10
    if scenario in rc.ARIOVISTUS_SCENARIOS:
        state['resources'][rc.GERMANS] = 10
    # Permanent Fort required even in these deliberately sparse positions.
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    integrity(state)
    return state


def execute_bot(state, faction, action):
    result = execute_decision(state, faction,
                              {'action': ACTION_COMMAND, 'bot_action': action})
    assert result.get('executed') and not result.get('errors'), result
    integrity(state)
    return result


def execute_player(state, faction, action):
    response = {'action': ACTION_COMMAND, 'player_action': action}
    validate_response(state, {'kind': 'turn', 'faction': faction,
                             'options': [ACTION_COMMAND]}, response)
    result = execute_decision(state, faction, response)
    assert result.get('executed') and not result.get('errors'), result
    integrity(state)
    return result


def battle_action(attacker, defender, region=rc.CARNUTES):
    return {'command': rc.CMD_BATTLE, 'regions': [region], 'sa': 'No SA',
            'details': {'battle_plan': [{'region': region, 'target': defender}]}}


def target_contamination():
    rows = []
    for unrelated_germans in (0, 10):
        state = board()
        place_piece(state, rc.CARNUTES, rc.AEDUI, rc.LEADER,
                    leader_name=rc.DIVICIACUS)
        place_piece(state, rc.CARNUTES, rc.AEDUI, rc.WARBAND)
        _ally_tribe(state, rc.TRIBE_CARNUTES, rc.BELGAE)
        if unrelated_germans:
            place_piece(state, rc.CARNUTES, rc.GERMANS, rc.WARBAND,
                        unrelated_germans)
        integrity(state)
        legal = deepcopy(state)
        action = dispatch_bot_turn(state, rc.AEDUI)
        assert node_a4(state) == 'Yes'
        assert action['command'] == ('Pass' if unrelated_germans else rc.CMD_BATTLE)
        if not unrelated_germans:
            execute_bot(state, rc.AEDUI, action)
        result = execute_player(legal, rc.AEDUI, battle_action(rc.AEDUI, rc.BELGAE))
        assert legal['tribes'][rc.TRIBE_CARNUTES]['allied_faction'] is None
        assert get_leader_in_region(legal, rc.CARNUTES, rc.AEDUI) == rc.DIVICIACUS
        assert count_pieces(legal, rc.CARNUTES, rc.AEDUI, rc.WARBAND) == 1
        assert count_pieces(legal, rc.CARNUTES, rc.GERMANS, rc.WARBAND) == unrelated_germans
        rows.append({'uninvolved_german_warbands': unrelated_germans,
                     'bot_action': action, 'legal_belgic_battle': result,
                     'legal_battle_diviciacus_survives': True,
                     'legal_battle_aedui_warbands': 1,
                     'legal_battle_uninvolved_germans_unchanged': True})
    return rows


def dangerous_counterattack():
    rows = []
    for leader in (rc.ARIOVISTUS_LEADER, rc.SUCCESSOR):
        state = board(seed=6)
        place_piece(state, rc.CARNUTES, rc.AEDUI, rc.LEADER,
                    leader_name=rc.DIVICIACUS)
        place_piece(state, rc.CARNUTES, rc.AEDUI, rc.WARBAND,
                    piece_state=rc.REVEALED)
        place_piece(state, rc.CARNUTES, rc.GERMANS, rc.LEADER,
                    leader_name=leader)
        place_piece(state, rc.VENETI, rc.AEDUI, rc.WARBAND, 2)
        _ally_tribe(state, rc.TRIBE_VENETI, rc.BELGAE)
        integrity(state)
        projection = resolve_battle(deepcopy(state), rc.CARNUTES, rc.AEDUI,
                                    rc.GERMANS, retreat_declaration=False)
        action = dispatch_bot_turn(state, rc.AEDUI)
        assert action['command'] == rc.CMD_BATTLE
        assert any(row['region'] == rc.CARNUTES
                   for row in action['details']['battle_plan'])
        result = execute_bot(state, rc.AEDUI, action)
        actual_diviciacus = get_leader_in_region(state, rc.CARNUTES, rc.AEDUI)
        assert actual_diviciacus == (None if leader == rc.ARIOVISTUS_LEADER
                                     else rc.DIVICIACUS)
        assert projection['counterattack']['losses_requested'] == (
            2 if leader == rc.ARIOVISTUS_LEADER else 1)
        rows.append({'enemy_leader': leader, 'bot_action': action,
                     'public_execution': result, 'diviciacus_after': actual_diviciacus,
                     'direct_battle_details': projection})
    return rows


def nonexistent_high_value_target():
    rows = []
    for scenario in (rc.SCENARIO_GREAT_REVOLT, rc.SCENARIO_ARIOVISTUS):
        for has_enemy_ally in (False, True):
            state = board(scenario)
            place_piece(state, rc.CARNUTES, rc.AEDUI, rc.WARBAND, 8)
            place_piece(state, rc.CARNUTES, rc.BELGAE, rc.WARBAND)
            if has_enemy_ally:
                _ally_tribe(state, rc.TRIBE_CARNUTES, rc.BELGAE)
            integrity(state)
            legal_rally = deepcopy(state)
            action = dispatch_bot_turn(state, rc.AEDUI)
            assert action['command'] == rc.CMD_BATTLE
            assert action['details']['battle_plan'][0]['priority'] == 'high_value'
            result = execute_bot(state, rc.AEDUI, action)
            row = {'scenario': scenario, 'has_enemy_ally': has_enemy_ally,
                   'bot_action': action, 'public_execution': result}
            if not has_enemy_ally:
                rally = node_a_rally(legal_rally)
                assert rally['command'] == rc.CMD_RALLY
                rally_result = execute_bot(legal_rally, rc.AEDUI, rally)
                assert legal_rally['tribes'][rc.TRIBE_CARNUTES]['allied_faction'] == rc.AEDUI
                row.update({'legal_next_branch_rally': rally,
                            'legal_next_branch_execution': rally_result,
                            'legal_next_branch_gains_carnutes_ally': True})
            rows.append(row)
    return rows


def german_loss_forecast():
    rows = []
    for auxiliaries, warbands, ariovistus in ((4, 6, False), (6, 6, False),
                                             (12, 6, False), (6, 4, True)):
        state = board()
        place_piece(state, rc.CARNUTES, rc.GERMANS, rc.WARBAND, warbands,
                    piece_state=rc.REVEALED)
        place_piece(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA, auxiliaries,
                    piece_state=rc.REVEALED)
        if ariovistus:
            place_piece(state, rc.CARNUTES, rc.GERMANS, rc.LEADER,
                        leader_name=rc.ARIOVISTUS_LEADER)
        integrity(state)
        legal_battle = deepcopy(state)
        projected = resolve_battle(deepcopy(state), rc.CARNUTES, rc.GERMANS,
                                   rc.ROMANS, retreat_declaration=False)
        estimate = _estimate_battle_losses(state, rc.CARNUTES, rc.ROMANS)
        action = dispatch_bot_turn(state, rc.GERMANS)
        assert action['command'] == (rc.CMD_BATTLE if auxiliaries == 4 else rc.CMD_MARCH)
        actual_result = execute_bot(state, rc.GERMANS, action)
        legal_result = execute_player(legal_battle, rc.GERMANS,
                                       battle_action(rc.GERMANS, rc.ROMANS))
        expected_losses = (6, 0) if ariovistus else (3, (auxiliaries - 3)//2)
        assert (projected['attack']['losses_requested'],
                projected['counterattack']['losses_requested']) == expected_losses
        assert count_pieces(legal_battle, rc.CARNUTES, rc.ROMANS, rc.AUXILIA) == (
            auxiliaries - expected_losses[0])
        assert count_pieces(legal_battle, rc.CARNUTES, rc.GERMANS, rc.WARBAND) == (
            warbands - expected_losses[1])
        rows.append({'roman_auxilia': auxiliaries, 'german_warbands': warbands,
                     'ariovistus': ariovistus, 'coarse_estimate': estimate,
                     'actual_attack_and_counterattack': expected_losses,
                     'bot_action': action, 'bot_execution': actual_result,
                     'legal_battle_execution': legal_result,
                     'direct_battle_details': projected})
    return rows


if __name__ == '__main__':
    findings = {
        'NP5-01': {'uninvolved_faction': target_contamination(),
                   'counterattack_multiplier': dangerous_counterattack()},
        'NP5-02': nonexistent_high_value_target(),
        'NP5-03': german_loss_forecast(),
        'inventory_and_structure': 'passed for every pre/post fixture',
        'cases': 12,
    }
    print(json.dumps(findings, indent=2, sort_keys=True))
