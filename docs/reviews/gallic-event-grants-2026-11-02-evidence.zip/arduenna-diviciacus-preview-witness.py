import json
from fs_bot import rules_consts as r
from fs_bot.board.pieces import place_piece
from fs_bot.cards.capabilities import activate_capability
from fs_bot.cards import base_arduenna_np as policy
from fs_bot.state.state_schema import build_initial_state
s=build_initial_state(r.SCENARIO_GREAT_REVOLT,seed=67)
s.update(current_card=67,next_card=3,non_player_factions={r.ARVERNI,r.BELGAE})
place_piece(s,r.NERVII,r.ARVERNI,r.WARBAND,6)
place_piece(s,r.NERVII,r.ROMANS,r.AUXILIA,1)
place_piece(s,r.NERVII,r.ROMANS,r.LEGION,2,from_legions_track=True)
place_piece(s,r.NERVII,r.AEDUI,r.WARBAND,2)
activate_capability(s,38,r.EVENT_UNSHADED)
before=list(policy._outcomes(s,[r.NERVII]))
original=policy._copy
def copy_without_forced_agreement(state):
    result=original(state)
    result.pop('_diviciacus_preview',None)
    return result
policy._copy=copy_without_forced_agreement
after=list(policy._outcomes(s,[r.NERVII]))
print(json.dumps({'current':before,'without_forced_agreement':after},indent=2))
