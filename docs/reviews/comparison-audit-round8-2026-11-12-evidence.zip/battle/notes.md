# Eighth audit Battle partition

Two new repair groups, supported by `probe_battle.py` and its recorded JSON:

- **BM8-01 (high):** shaded Massed Gallic Archers still does not reach fixed numeric2/numeric36 Battles or the automatic Arverni Phase. Six Arverni versus four Auxilia leaves one Roman in the fixed/phase routes, while the ordinary Battle control correctly leaves none. Morasses also proves the defensive-Arverni branch without confusing its no-Counterattack exception.
- **BM8-02 (medium):** both sides of German Phalanx miss the corresponding Archers effect. Stalwart still permits the initial Loss to German attackers; Inflexible still permits the one-Loss reduction benefiting German defenders. A31 is acquired after 27 in every pair. Non-German and capability-off controls retain correct behavior.

All 18 cases use public execution or full automatic phase entry, lawful helper-created counters, and the permanent Provincia Fort. There are 104 validation calls, each checking schema and structural integrity. No production edits or repository test writes. `findings.json` records exact source/code lines, expected/observed behavior, earlier-audit distinctions, repair boundaries and fixture limitations.

Run from `fs-bot`:

```sh
PYTHONPATH=. .venv/bin/python ../audit8-work/battle/probe_battle.py
```

The script asserts the present defects, so a correct repair should stop it passing. It does not estimate occurrence frequency or winner impact. Round7 explicitly left both Archers topics as unproved leads; this audit does not reopen its repaired Slingers/Horse/Ballistae cases. No Elite finding is claimed.
