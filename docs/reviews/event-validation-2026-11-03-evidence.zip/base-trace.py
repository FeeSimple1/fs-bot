import copy, hashlib, json, os, sys
sys.path.insert(0, os.getcwd())
import fs_bot.engine.execute as execute
from fs_bot.tools.balance_smoke import play_bot_game
import fs_bot.rules_consts as rc
orig = execute.execute_decision
trace = []
def canonical(st):
    return json.loads(json.dumps(st, default=lambda x: sorted(x) if isinstance(x, set) else (x.getstate() if hasattr(x, 'getstate') else str(type(x))), sort_keys=True))
def wrap(st, faction, decision):
    before = canonical(st)
    result = orig(st, faction, decision)
    after = canonical(st)
    trace.append(dict(card=st.get('current_card'), faction=faction, decision=canonical(decision), result=canonical(result), before=before, after=after))
    return result
execute.execute_decision = wrap
result = play_bot_game(rc.SCENARIO_GALLIC_WAR, int(sys.argv[1]))
with open(sys.argv[2], 'w') as f: json.dump(dict(outcome=result, trace=trace), f, sort_keys=True)
print(result)
