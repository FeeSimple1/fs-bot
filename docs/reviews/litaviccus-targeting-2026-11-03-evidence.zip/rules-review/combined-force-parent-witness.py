from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, count_pieces_by_state, place_piece
from fs_bot.engine.execute import _resolve_card45_battle
from fs_bot.state.state_schema import build_initial_state, validate_state
import json
state=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=45)
state['non_player_factions']={rc.BELGAE}
place_piece(state,rc.CARNUTES,rc.AEDUI,rc.WARBAND,2)
place_piece(state,rc.CARNUTES,rc.ROMANS,rc.AUXILIA,4)
state['decision_agent']=lambda current,actor,request: {'retreat':False} if request['kind']=='retreat' else None
result=_resolve_card45_battle(state,rc.BELGAE)
print(json.dumps({'result':result,'aedui_remaining':count_pieces(state,rc.CARNUTES,rc.AEDUI,rc.WARBAND), 'aedui_hidden':count_pieces_by_state(state,rc.CARNUTES,rc.AEDUI,rc.WARBAND,rc.HIDDEN),'roman_auxilia':count_pieces(state,rc.CARNUTES,rc.ROMANS,rc.AUXILIA),'integrity':validate_state(state)},indent=2))
