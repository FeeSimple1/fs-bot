"""Replay changed winners on both revisions and capture the first divergent draw."""
from concurrent.futures import ProcessPoolExecutor
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
from pathlib import Path
import json
import sys

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import get_effective_faction_pieces
from fs_bot.cli.dispatcher import make_decision_func
from fs_bot.engine import execute
from fs_bot.engine.game_engine import get_sop_factions, play_card, start_game
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.tools.validation_metadata import source_identity


def digest(state):
    return sha256(json.dumps(encode(state), sort_keys=True).encode()).hexdigest()


def replay(case):
    scenario, seed, edition, expected_winner, expected_cards = case
    state = setup_scenario(scenario, seed=seed, card_edition=edition)
    state['non_player_factions'] = set(get_sop_factions(state))
    bot = make_decision_func({}, stdin=StringIO(), stdout=StringIO(), pause=False)
    old_retreat = execute._battle_retreat_options
    cards = []

    def retreat(board, region, attacker, defender, ambush, **battle):
        result = old_retreat(board, region, attacker, defender, ambush, **battle)
        if not board.get('_diviciacus_preview'):
            retreats.append(dict(region=region, attacker=attacker, defender=defender,
                ambush=ambush, declaration=result['retreat_declaration'],
                destination=result['retreat_region'], forces={
                    faction: encode(get_effective_faction_pieces(board, region, faction))
                    for faction in (attacker, defender)}))
        return result

    def decide(board, faction, options, position):
        response = bot(board, faction, options, position)
        plan = response['bot_action']
        details = plan.get('details', {})
        decisions.append(dict(faction=faction, action=response['action'],
            command=plan.get('command'), sa=plan.get('sa'), regions=plan.get('regions'),
            targets=details.get('battle_plan'), destinations=details.get('destinations')))
        return response

    execute._battle_retreat_options = retreat
    try:
        with redirect_stdout(StringIO()):
            start_game(state)
            while state['current_card'] is not None:
                before = digest(state)
                retreats, decisions = [], []
                result = play_card(state, decide, execute=True)
                cards.append(dict(card=result['card'], before=before, after=digest(state),
                                  retreats=retreats, decisions=decisions))
                if result['game_over']:
                    break
    finally:
        execute._battle_retreat_options = old_retreat
    winner = result.get('winner')
    assert (winner, len(cards)) == (expected_winner, expected_cards), (case, winner, len(cards))
    return dict(scenario=scenario, seed=seed, edition=edition, cards=cards, winner=winner)


def cases(parent, repair, side):
    def records(path):
        rows = [json.loads(line) for line in (path / 'games.jsonl').read_text().splitlines()]
        return {(r['scenario'], r['seed']): r for r in rows}

    for subdir, edition in [('legacy', 'legacy'), ('second', 'second-edition')]:
        before = records(parent / f'parent-{subdir}')
        after = records(repair / subdir)
        assert before.keys() == after.keys()
        for key in sorted(after):
            if before[key]['winner'] != after[key]['winner']:
                row = before[key] if side == 'parent' else after[key]
                yield *key, edition, row['winner'], row['cards']


def compare(parent, repair, output):
    original = json.loads(parent.read_text())
    corrected = json.loads(repair.read_text())
    changes = []
    for old, new in zip(original['traces'], corrected['traces'], strict=True):
        assert all(old[key] == new[key] for key in ('scenario', 'seed', 'edition'))
        for draw, (old_card, new_card) in enumerate(zip(old['cards'], new['cards']), 1):
            if old_card['after'] != new_card['after']:
                assert (old_card['before'], old_card['card']) == (new_card['before'], new_card['card'])
                changes.append(dict(scenario=new['scenario'], seed=new['seed'], edition=new['edition'],
                    draw=draw, card=new_card['card'], pre_card_hash=new_card['before'],
                    parent=dict(winner=old['winner'], cards=len(old['cards']),
                                decisions=old_card['decisions'], retreats=old_card['retreats']),
                    repair=dict(winner=new['winner'], cards=len(new['cards']),
                                decisions=new_card['decisions'], retreats=new_card['retreats'])))
                break
        else:
            raise ValueError(f"Missing first difference in {new['scenario']} seed {new['seed']}")
    output.write_text(json.dumps(changes, indent=2) + '\n')


if __name__ == '__main__':
    if sys.argv[1] == 'compare':
        compare(*map(Path, sys.argv[2:]))
    else:
        side, parent, repair, output = sys.argv[1:]
        with ProcessPoolExecutor(max_workers=2) as pool:
            traces = list(pool.map(replay, cases(Path(parent), Path(repair), side)))
        Path(output).write_text(json.dumps(dict(source=source_identity(), traces=traces)) + '\n')
