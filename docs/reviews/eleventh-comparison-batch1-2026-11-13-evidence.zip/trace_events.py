"""Observe Event effects and the first differing cards in paired games."""

import argparse
from concurrent.futures import ProcessPoolExecutor
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import find_leader, get_leader_in_region
from fs_bot.cards.capabilities import get_active_capabilities
from fs_bot.engine import execute, game_engine
from fs_bot.state.serialize import encode
from fs_bot.tools import player_fuzz, run_batch
from fs_bot.tools.validation_metadata import source_identity

CARDS = (19, 50, 52)


def digest(value):
    return hashlib.sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def snapshot(state):
    excluded = {'rng', 'decision_agent', '_card_turn', '_resolved_card'}
    return {'board': digest({k: v for k, v in state.items() if k not in excluded}),
            'rng': digest(state['rng'].getstate())}


def event_state(state):
    region = find_leader(state, rc.ARVERNI)
    leader = get_leader_in_region(state, region, rc.ARVERNI) if region else None
    return {'leader': [region, leader], 'resources': dict(state['resources']),
            'carnutes': dict(state['tribes'].get(rc.TRIBE_CARNUTES, {})),
            'capabilities': dict(get_active_capabilities(state)),
            'owners': dict(state.get('capability_owners', {}))}


def trace(entry):
    task, mixed = entry['task'], entry['mixed']
    cards = []
    active_card = None
    board = None
    play_card = game_engine.play_card
    resolve = execute._execute_event

    def observe_event(state, faction, plan, **options):
        if state is not board or state['current_card'] not in CARDS:
            return resolve(state, faction, plan, **options)
        before = event_state(state)
        result = resolve(state, faction, plan, **options)
        active_card['events'].append({'faction': faction, 'human': options.get('human', False),
                                      'before': before, 'after': event_state(state),
                                      'result': result})
        return result

    def observe_card(state, decide, **options):
        nonlocal active_card, board
        row = {'ordinal': len(cards) + 1, 'card': state['current_card'],
               'scenario': state['scenario'], 'before': snapshot(state)}
        active_card, board = row, state
        if row['card'] in CARDS:
            row['events'] = []
        result = play_card(state, decide, **options)
        row['after'] = snapshot(state)
        if row['card'] in CARDS:
            row['actions'] = result['turn_result']['actions_taken']
        cards.append(row)
        return result

    with ExitStack() as stack:
        stack.enter_context(patch.object(game_engine, 'play_card', observe_card))
        stack.enter_context(patch.object(run_batch, 'play_card', observe_card))
        stack.enter_context(patch.object(execute, '_execute_event', observe_event))
        if mixed:
            scenario, seed, edition = task
            outcome = player_fuzz.play_game(scenario, seed, card_edition=edition)
            assert outcome['game_completed'] and not outcome['findings'], outcome
        else:
            record = run_batch.play_one(task)
            assert record['completed'], record
            outcome = {key: record[key] for key in ('winner', 'cards', 'final_state_sha256')}
    return {'task': task, 'mixed': mixed, 'outcome': outcome, 'cards': cards}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('tasks', type=Path)
    parser.add_argument('--workers', type=int, default=2)
    args = parser.parse_args()
    tasks = json.loads(args.tasks.read_text())
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        games = list(pool.map(trace, tasks))
    print(json.dumps(encode({'source': source_identity(), 'games': games}), sort_keys=True))


if __name__ == '__main__':
    main()
