"""Independently verify second-batch evidence without simulating any games."""
from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
import statistics
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "fs-bot"
BOT_SCENARIOS = ("Pax Gallica?", "Reconquest of Gaul", "The Great Revolt", "Ariovistus", "The Gallic War")
OTHER_SCENARIOS = ("Pax Gallica?", "The Great Revolt", "Reconquest of Gaul", "Ariovistus", "The Gallic War")
FACTIONS = ("Romans", "Arverni", "Aedui", "Belgae", "Germans")


def read(path):
    return json.loads(path.read_text())


def digest():
    value = hashlib.sha256()
    for path in sorted((REPO / "fs_bot").rglob("*.py")):
        value.update(str(path.relative_to(REPO)).encode() + b"\0" + path.read_bytes())
    return value.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attempt", default="attempt1")
    parser.add_argument("--skip-pytest", action="store_true",
                        help="verify matrix while the independently owned full suite is running")
    parser.add_argument("--allow-committed-tree", action="store_true",
                        help="evidence remains tied to its recorded base commit after the repairs are committed")
    args = parser.parse_args()
    run = ROOT / args.attempt
    failures = []

    def check(condition, message):
        if not condition:
            failures.append(message)

    source = read(run / "source.json")
    freeze = read(run / "freeze.json")
    report = {"source": source, "attempt": args.attempt, "failures": failures,
              "bot_batches": {}, "pytest_checked": not args.skip_pytest}
    check(digest() == source["source_sha256"], "current Python source digest differs from frozen source")
    current_commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip()
    if not args.allow_committed_tree:
        check(current_commit == source["commit"], "current commit differs from frozen commit")
    check(freeze["source_sha256"] == source["source_sha256"], "freeze/source digest mismatch")
    check(freeze["balance_band_exact"] == "3/20" and freeze["balance_baseline_updated"] is False,
          "freeze changed the baseline policy")
    snapshot = (run / "balance-baseline.json").read_bytes()
    committed = subprocess.check_output(["git", "show", f"{source['commit']}:fs_bot/tools/balance_baseline.json"], cwd=REPO)
    check(snapshot == committed == (REPO / "fs_bot/tools/balance_baseline.json").read_bytes(),
          "baseline is not byte-identical to the frozen committed baseline")
    check(hashlib.sha256(snapshot).hexdigest() == freeze["balance_baseline_sha256"], "baseline hash mismatch")
    for name, expected_hash in freeze["source_files"].items():
        check((REPO / name).is_file() and hashlib.sha256((REPO / name).read_bytes()).hexdigest() == expected_hash,
              f"source file changed: {name}")

    def metadata(meta, tool, scenarios, seeds, edition, context):
        expected = {"metadata_version": 1, "tool": tool, "commit": source["commit"],
                    "source_sha256": source["source_sha256"], "scenarios": list(scenarios),
                    "seeds": list(seeds), "card_edition": edition, "python": freeze["python"]}
        for key, value in expected.items():
            check(meta.get(key) == value, f"{context}: metadata {key} mismatch")
        check(type(meta.get("dirty")) is bool, f"{context}: missing dirty provenance")

    ledger = read(run / "runner-status.json")
    expected_names = {"bots-legacy", "bots-original", "bots-second-edition", "fuzz0", "fuzz7", "census0", "census7"}
    check(ledger["passed"] is True, "runner did not pass")
    check(len(ledger["jobs"]) == 7 and {j["name"] for j in ledger["jobs"]} == expected_names,
          "runner job coverage differs from seven required commands")
    planned = {j["name"]: j for j in freeze["jobs"]}
    for job in ledger["jobs"]:
        name = job["name"]
        check(job == read(run / f"{name}.status.json"), f"{name}: status differs from ledger")
        check(job["exit_code"] == 0 and job["source_changed"] is False, f"{name}: nonzero exit or changed source")
        check(job["source_sha256_before"] == job["source_sha256_after"] == source["source_sha256"],
              f"{name}: source differs between process boundaries")
        check(job["argv"] == planned[name]["argv"], f"{name}: argv differs from frozen plan")
        check(job["environment"]["PYTHONHASHSEED"] == str(planned[name]["hash_seed"]), f"{name}: hash seed mismatch")
        check((run / f"{name}.log").is_file() and (run / f"{name}.log").stat().st_size > 0, f"{name}: missing log")
    report["runner"] = {"passed": ledger["passed"], "job_exit_codes": {j["name"]: j["exit_code"] for j in ledger["jobs"]}}

    all_rows = []
    for edition, seeds in (("legacy", range(1, 21)), ("original", range(201, 211)),
                           ("second-edition", range(201, 211))):
        context = "bots-" + edition
        folder = run / context
        meta = read(folder / "metadata.json")
        metadata(meta, "run_batch", BOT_SCENARIOS, seeds, edition, context)
        check(meta.get("hash_seed") == 0 and meta.get("all_factions_bots") is True,
              f"{context}: incorrect hash seed or seat configuration")
        check(meta.get("games_per_scenario") == len(seeds), f"{context}: wrong games_per_scenario")
        rows = [json.loads(line) for line in (folder / "games.jsonl").read_text().splitlines()]
        expected = {(s, n, edition) for s in BOT_SCENARIOS for n in seeds}
        actual = [(r.get("scenario"), r.get("seed"), r.get("card_edition")) for r in rows]
        check(len(actual) == len(set(actual)) and set(actual) == expected, f"{context}: incorrect exact record coverage")
        summary = read(folder / "summary.json")
        check(set(summary) == set(BOT_SCENARIOS), f"{context}: incorrect summary scenarios")
        for row in rows:
            name = f"{context}/{row['scenario']}/{row['seed']}"
            for flag in ("completed", "game_completed", "audit_completed"):
                check(row.get(flag) is True, f"{name}: {flag} is not true")
            check(not row.get("error") and row.get("errors") == [], f"{name}: errors present or missing errors field")
            check(row.get("integrity_findings") == [], f"{name}: integrity findings present or missing field")
            check(row.get("source_sha256") == source["source_sha256"] and row.get("commit") == source["commit"],
                  f"{name}: mixed source identity")
            check(type(row.get("cards")) is int and row["cards"] > 0, f"{name}: invalid card count")
            ending = row.get("ending_scenario")
            check(ending in BOT_SCENARIOS, f"{name}: invalid ending scenario")
            eligible = set(FACTIONS) - ({"Arverni"} if ending in ("Ariovistus", "The Gallic War") else {"Germans"})
            ranking = row.get("final_ranking", [])
            ranking_valid = (isinstance(ranking, list) and len(ranking) == 4
                             and all(isinstance(r, list) and len(r) == 2 and type(r[1]) is int for r in ranking)
                             and {r[0] for r in ranking} == eligible)
            check(ranking_valid, f"{name}: malformed/ineligible final ranking")
            if ranking_valid:
                check(row.get("engine_final_ranking") == ranking, f"{name}: emitted and recomputed rankings differ")
                check([r[1] for r in ranking] == sorted((r[1] for r in ranking), reverse=True), f"{name}: unsorted margins")
                check(row.get("winner") == ranking[0][0] == row.get("highest_margin_leader"), f"{name}: winner disagreement")
                check(row.get("threshold_qualifiers") == [f for f, margin in ranking if margin > 0], f"{name}: qualifier disagreement")
            check(row.get("winner_differs_from_highest_margin") is False and row.get("engine_ranking_output_missing") is False,
                  f"{name}: invalid ranking audit flags")
            check(bool(re.fullmatch(r"[0-9a-f]{64}", row.get("final_state_sha256", ""))), f"{name}: invalid final-state digest")
            check(row.get("termination") in ("optimates", "threshold", "final-winter-margin"), f"{name}: invalid termination")
            for field in ("diagnostics", "diagnostic_occurrences"):
                check(isinstance(row.get(field), list), f"{name}: {field} missing")
                check(all(d.get("severity") == "legal-decline" for d in row.get(field, [])), f"{name}: nonlegal {field}")
            check(type(row.get("interlude_completed")) is bool, f"{name}: missing Interlude flag")
            if row["scenario"] != "The Gallic War":
                check(ending == row["scenario"] and row["interlude_completed"] is False, f"{name}: unexpected scenario transition")
            elif ending != "The Gallic War":
                check(ending == "Pax Gallica?" and row["interlude_completed"] is True, f"{name}: inconsistent Interlude transition")
        for scenario in BOT_SCENARIOS:
            subset = [r for r in rows if r["scenario"] == scenario]
            total = summary[scenario]
            checks = {"card_edition": edition, "attempted": len(seeds), "completed": len(seeds),
                      "engine_completed": len(seeds), "crashes": 0, "integrity_flagged_games": 0,
                      "winner_margin_disagreements": 0,
                      "wins": dict(Counter(r["winner"] for r in subset)),
                      "highest_margin_leaders": dict(Counter(r["highest_margin_leader"] for r in subset)),
                      "terminations": dict(Counter(r["termination"] for r in subset)),
                      "interlude_games": sum(r["interlude_completed"] for r in subset),
                      "cards_mean": statistics.mean(r["cards"] for r in subset),
                      "cards_median": statistics.median(r["cards"] for r in subset),
                      "cards_range": [min(r["cards"] for r in subset), max(r["cards"] for r in subset)],
                      "winters": dict(Counter(str(r["winters"]) for r in subset)),
                      "decisions": sum(r["decisions"] for r in subset),
                      "simultaneous_threshold_games": sum(len(r["threshold_qualifiers"]) > 1 for r in subset)}
            incidents, diagnosed_games = Counter(), Counter()
            for row in subset:
                for diagnostic in row["diagnostics"]:
                    incidents[diagnostic["severity"]] += diagnostic["count"]
                diagnosed_games.update({d["severity"] for d in row["diagnostics"]})
            checks.update(diagnostic_incidents=dict(incidents), diagnostic_games=dict(diagnosed_games))
            for key, value in checks.items():
                check(total.get(key) == value, f"{context}/{scenario}: summary {key} disagrees with records")
        report["bot_batches"][edition] = {"games": len(rows), "seeds": list(seeds), "scenarios": list(BOT_SCENARIOS),
             "accepted": sum(r["completed"] for r in rows),
             "winner_counts": {s: dict(Counter(r["winner"] for r in rows if r["scenario"] == s)) for s in BOT_SCENARIOS},
             "interlude_completed": sum(r["interlude_completed"] for r in rows)}
        all_rows.extend(rows)

    baseline = json.loads(snapshot)["games"]
    comparisons, changed, maximum = {}, [], Fraction(0)
    for scenario in BOT_SCENARIOS:
        rows = [r for r in all_rows if r["scenario"] == scenario and r["card_edition"] == "legacy"]
        before = Counter(baseline[f"{scenario}|{seed}"]["winner"] for seed in range(1, 21))
        after = Counter(r["winner"] for r in rows)
        deltas = {f: Fraction(after[f] - before[f], 20) for f in FACTIONS}
        maximum = max(maximum, *(abs(d) for d in deltas.values()))
        for faction, delta in deltas.items():
            check(abs(delta) <= Fraction(3, 20), f"balance/{scenario}/{faction}: drift {delta} exceeds unchanged 3/20 band")
        changed_seeds = sorted(r["seed"] for r in rows if baseline[f"{scenario}|{r['seed']}"]["winner"] != r["winner"])
        changed.extend(f"{scenario}|{seed}" for seed in changed_seeds)
        comparisons[scenario] = {"before": dict(before), "after": dict(after),
             "exact_rate_change": {f: str(d) for f, d in deltas.items()},
             "percentage_point_change": {f: float(d * 100) for f, d in deltas.items()}, "changed_winner_seeds": changed_seeds}
    report["balance"] = {"passed": maximum <= Fraction(3, 20), "band_percentage_points": 15,
          "exact_band": "3/20", "baseline_updated": False, "maximum_absolute_drift": str(maximum),
          "changed_winner_count": len(changed), "changed_winners": changed, "scenarios": comparisons}

    fuzz = [read(run / f"fuzz{h}.json") for h in (0, 7)]
    check(fuzz[0] == fuzz[1], "mixed-seat JSON differs across hash seeds 0 and 7")
    for hash_seed, data in zip((0, 7), fuzz):
        context = f"fuzz{hash_seed}"
        metadata(data["metadata"], "player_fuzz", OTHER_SCENARIOS, range(1, 5), "legacy", context)
        for option in ("reactive", "events", "replay"):
            check(data["metadata"].get(option) is True, f"{context}: {option} disabled")
        rows = data["records"]
        actual = [(r["scenario"], r["seed"]) for r in rows]
        expected = {(s, n) for s in OTHER_SCENARIOS for n in range(1, 5)}
        check(len(actual) == len(set(actual)) == data["games"] == 20 and set(actual) == expected,
              f"{context}: incorrect exact scenario/seed coverage")
        check(data["hard_findings"] == 0 and not data["by_kind"], f"{context}: hard findings")
        check(all(r["game_completed"] is True and not r["findings"] and r["card_edition"] == "legacy" for r in rows),
              f"{context}: incomplete game, findings, or incorrect edition")
        for field in ("human_turns", "event_turns", "events_ok", "partial"):
            check(data[field] == sum(r[field] for r in rows), f"{context}: {field} disagrees with records")
        check(data["partial"] == 0, f"{context}: partial random plans present")
        batch = hashlib.sha256()
        for row in rows:
            check(bool(re.fullmatch(r"[0-9a-f]{16}", row["digest"])), f"{context}: malformed replay digest")
            check(type(row["rejected"]) is int and row["rejected"] >= 0, f"{context}: invalid rejected count")
            batch.update(f"{row['scenario']}|{row['seed']}|legacy|{row['digest']}".encode())
        check(batch.hexdigest() == data["batch_digest"], f"{context}: batch digest does not match case digests")
    report["mixed_seats"] = {"unique_cases": 20, "executions_including_replay": 80, "hash_seeds": [0, 7],
          "cross_hash_equal": fuzz[0] == fuzz[1], "hard_findings": fuzz[0]["hard_findings"], "partial": fuzz[0]["partial"],
          "rejected_random_plans_per_hash": sum(r["rejected"] for r in fuzz[0]["records"]),
          "batch_digest": fuzz[0]["batch_digest"],
          "limitation": "Rejected random plans are disclosed separately; completion is not complete human-choice coverage."}

    census = [read(run / f"census{h}.json") for h in (0, 7)]
    check(census[0] == census[1], "strict census JSON differs across hash seeds 0 and 7")
    for hash_seed, data in zip((0, 7), census):
        context = f"census{hash_seed}"
        metadata(data["metadata"], "error_census", OTHER_SCENARIOS, range(1, 6), "legacy", context)
        check(data["metadata"]["strict"] is True, f"{context}: strict mode disabled")
        check(data["games"] == data["completed"] == 25 and data["failed_games"] == 0 and data["failures"] == [],
              f"{context}: failed or missing games")
        check(data["illegal"] == 0 and all(k == "legal-decline" or n == 0 for k, n in data["by_severity"].items()),
              f"{context}: defect-class diagnostics")
        counts = Counter()
        for incident in data["counts"]:
            check(incident["severity"] == "legal-decline", f"{context}: nonlegal incident")
            counts[incident["severity"]] += incident["n"]
        check(dict(counts) == data["by_severity"] and sum(counts.values()) == data["total"],
              f"{context}: diagnostic aggregates disagree")
    report["strict_census"] = {"unique_cases": 25, "executions": 50, "hash_seeds": [0, 7],
          "cross_hash_equal": census[0] == census[1], "defects": sum(n for k, n in census[0]["by_severity"].items() if k != "legal-decline"),
          "by_severity_per_hash": census[0]["by_severity"],
          "coverage_evidence": "Exact tool metadata plus aggregate completion; the census tool does not emit per-game success records."}
    if not args.skip_pytest:
        test_status = read(run / "tests.status.json")
        check(test_status.get("exit_code") == 0, "pytest process exit status is not zero")
        check(test_status.get("source", {}).get("source_sha256") == source["source_sha256"]
              and test_status.get("source_after", {}).get("source_sha256") == source["source_sha256"],
              "pytest source identity differs across execution boundaries")
        check(test_status.get("source", {}).get("commit") == source["commit"]
              and test_status.get("source_after", {}).get("commit") == source["commit"],
              "pytest commit differs from frozen commit")
        check(test_status.get("cwd") == str(REPO) and "pytest" in test_status.get("argv", []),
              "pytest launch metadata is incomplete")
        suites = ET.parse(run / "tests.xml").getroot().findall(".//testsuite")
        check(bool(suites), "JUnit has no test suite")
        totals = {key: sum(int(s.attrib[key]) for s in suites) for key in ("tests", "errors", "failures", "skipped")}
        check(totals["tests"] >= 4715 and all(totals[k] == 0 for k in ("errors", "failures", "skipped")),
              "full suite has failures/skips or fewer tests than the accepted first batch")
        totals["time"] = sum(float(s.attrib["time"]) for s in suites)
        totals["exit_code"] = test_status["exit_code"]
        report["pytest"] = totals
    report["passed"] = not failures
    report["accepted_attempt"] = args.attempt if report["passed"] else None
    output = run / ("matrix-results.json" if args.skip_pytest else "results.json")
    output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k not in ("bot_batches", "balance")}, indent=2))
    print(f"Bot records: {len(all_rows)}; maximum balance drift: {maximum}; changed winners: {len(changed)}")
    print(f"Independent verification {'PASS' if report['passed'] else 'FAIL'}: {output}")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
