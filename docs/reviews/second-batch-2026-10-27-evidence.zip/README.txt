Falling Sky second Event repair batch — scratch validation plan

Do not launch orchestrate.py until root explicitly freezes the integrated
Python source digest. No engine files, tests, baseline, or thresholds are
modified by these scripts. Each attempt gets a new directory; preserve all
failed/interrupted attempts and do not combine outcomes from source revisions.

Exact agreed matrix:
  100 legacy bot games: all five scenarios, seeds 1–20, hash seed 0.
   50 original bot games: all five scenarios, seeds 201–210, hash seed 0.
   50 second-edition bot games: all five scenarios, seeds 201–210, hash seed 0.
   80 mixed-seat executions: all five scenarios, seeds 1–4, internal replay
      enabled, at hash seeds 0 and 7. Twenty unique cases per hash.
   50 strict-census executions: all five scenarios, seeds 1–5, hashes 0 and 7.

Launch from any directory with the supplied Python environment:
  ../fs-test-venv/bin/python orchestrate.py --source-sha256 ROOT_FROZEN_DIGEST --attempt attempt1

The legacy command gates the remaining commands. The remaining six commands
run with two concurrent jobs by default; each bot command uses two workers.
Every command, environment hash seed, UTC boundary, duration, output log, and
actual subprocess exit code is retained. The source and unchanged baseline
are checked before/after each child and every 15 seconds while it runs.
The parent/root owns the full pytest run and should write its JUnit output to
attempt1/tests.xml, preserving the separate test log and command/exit status.

After all seven matrix commands complete:
  ../fs-test-venv/bin/python verify.py --attempt attempt1 --skip-pytest
After the full suite finishes:
  ../fs-test-venv/bin/python verify.py --attempt attempt1
After a subsequent commit, use --allow-committed-tree to recheck byte-identical
Python against the retained precommit evidence without demanding the old HEAD.

The verifier reads evidence only; it never repeats games. It validates runner
exit statuses, frozen metadata, exact bot/mixed coverage, all completion flags,
eligible four-faction emitted/recomputed rankings, winner/margins, final-state
hashes, legal-decline-only diagnostics, summaries, replay digest aggregation,
cross-hash JSON equality, and the exact unchanged inclusive 3/20 balance band.
Balance uses the 100 already-audited legacy records, avoiding duplicate games.
Mixed partial counts and rejected random plans are separately disclosed.
The census tool exposes exact metadata and aggregate completion, but does not
emit individual success records; the report retains this evidence limitation.
No claim of exhaustive printed human-choice coverage follows from this matrix.

CLI help/source was inspected before writing these commands. These scripts
are independent of run_batch's internal acceptance predicate and summary
implementation; they inspect the serialized records directly.
