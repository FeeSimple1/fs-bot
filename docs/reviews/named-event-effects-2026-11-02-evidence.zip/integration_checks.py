"""Bounded bot regression and mixed-seat replay checks for this repair."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib, json, os, subprocess, sys

HERE = Path(__file__).resolve().parent
OUT = HERE / os.environ.get('FS_MATRIX_LABEL', 'matrix-01')
OUT.mkdir(exist_ok=False)
REPO = HERE.parent/'fs-bot'
BASELINE = REPO/'fs_bot/tools/balance_baseline.json'
SCENARIOS = {'Pax Gallica?', 'The Great Revolt', 'Reconquest of Gaul', 'Ariovistus', 'The Gallic War'}

def identity():
    h=hashlib.sha256(); files=sorted(REPO.glob('fs_bot/**/*.py'),key=lambda p:p.relative_to(REPO).as_posix())
    for p in files:
        h.update(p.relative_to(REPO).as_posix().encode());h.update(b'\0');h.update(p.read_bytes())
    return {'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
            'python_sha256':h.hexdigest(),'python_files':len(files),
            'python_worktree_changes':any(name.endswith('.py') for name in subprocess.check_output(['git','diff','--name-only','HEAD','--','fs_bot'],cwd=REPO,text=True).splitlines())}

before=identity(); baseline_hash=hashlib.sha256(BASELINE.read_bytes()).hexdigest()
jobs=[]
for edition,seeds in [('legacy','1-20'),('original','201-205'),('second-edition','201-205')]:
    name='bots-'+edition
    jobs.append((name,'0',['-m','fs_bot.tools.run_batch','--seeds',seeds,'--card-edition',edition,'--workers','2','--out',str(OUT/name)]))
for edition in ['legacy','original','second-edition']:
    for hashseed in ['0','7']:
        name=f'fuzz-{edition}-{hashseed}'
        jobs.append((name,hashseed,['-m','fs_bot.tools.player_fuzz','--seeds','201-202','--card-edition',edition,'--out',str(OUT/(name+'.json'))]))

for hashseed in ['0','7']:
    name=f'census-{hashseed}'
    jobs.append((name,hashseed,['-m','fs_bot.tools.error_census','--seeds','201-202','--strict','--out',str(OUT/(name+'.json'))]))

def run(job):
    name,hashseed,args=job
    env=os.environ.copy();env.update(PYTHONHASHSEED=hashseed,PYTHONPATH=str(REPO))
    command=[sys.executable,*args]
    with (OUT/(name+'.log')).open('w') as log:
        r=subprocess.run(command,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT)
    print(f'{name}: exit {r.returncode}',flush=True)
    return {'name':name,'hashseed':hashseed,'command':command,'exit_code':r.returncode}

with ThreadPoolExecutor(max_workers=3) as pool:
    runs=list(pool.map(run,jobs))
(OUT/'integration-commands.json').write_text(json.dumps(runs,indent=2)+'\n')
assert all(r['exit_code']==0 for r in runs), runs
games={}
for edition,seeds in [('legacy',range(1,21)),('original',range(201,206)),('second-edition',range(201,206))]:
    rows=[json.loads(line) for line in (OUT/('bots-'+edition)/'games.jsonl').read_text().splitlines()]
    assert len(rows)==len(SCENARIOS)*len(seeds)
    assert {(r['scenario'],r['seed']) for r in rows}=={(s,n) for s in SCENARIOS for n in seeds}
    for r in rows:
        assert all(r.get(k) is True for k in ('completed','game_completed','audit_completed')),r
        assert not r['errors'] and not r['integrity_findings'],r
        assert r['card_edition']==edition and r['final_state_sha256']
        assert len(r['final_ranking'])==4 and not r['engine_ranking_output_missing'] and not r['winner_differs_from_highest_margin']
        assert all(d['severity']=='legal-decline' for d in r['diagnostics'])
    games[edition]=rows
baseline=json.loads(BASELINE.read_text())['games']
differences=[{'scenario':r['scenario'],'seed':r['seed'],'before':baseline[f"{r['scenario']}|{r['seed']}"],
              'after':{k:r[k] for k in ('winner','cards')}} for r in games['legacy']
             if any(r[k]!=baseline[f"{r['scenario']}|{r['seed']}"][k] for k in ('winner','cards'))]
(OUT/'baseline-differences.json').write_text(json.dumps(differences,indent=2)+'\n')

parent_rows=[json.loads(line) for line in (HERE/'parent-bots-legacy'/'games.jsonl').read_text().splitlines()]
parent={(row['scenario'],row['seed']):row for row in parent_rows}
assert len(parent)==100
parent_differences=[{'scenario':r['scenario'],'seed':r['seed'],
                    'before':{k:parent[r['scenario'],r['seed']][k] for k in ('winner','cards')},
                    'after':{k:r[k] for k in ('winner','cards')}} for r in games['legacy']
                    if any(r[k]!=parent[r['scenario'],r['seed']][k] for k in ('winner','cards'))]
(OUT/'parent-differences.json').write_text(json.dumps(parent_differences,indent=2)+'\n')

from collections import Counter
rate_changes=[]
for scenario in sorted(SCENARIOS):
    old=Counter(baseline[f'{scenario}|{seed}']['winner'] for seed in range(1,21))
    new=Counter(r['winner'] for r in games['legacy'] if r['scenario']==scenario)
    for faction in sorted(set(old)|set(new)):
        rate_changes.append({'scenario':scenario,'faction':faction,'before_wins':old[faction],
                             'after_wins':new[faction],'percentage_point_change':5*(new[faction]-old[faction])})
balance_passed=all(abs(row['after_wins']-row['before_wins'])<=3 for row in rate_changes)
fuzz={}
for edition in ['legacy','original','second-edition']:
    a=json.loads((OUT/f'fuzz-{edition}-0.json').read_text());b=json.loads((OUT/f'fuzz-{edition}-7.json').read_text())
    for v in (a,b):
        assert v['games']==10 and not v['hard_findings'] and not v['by_kind']
    assert a['batch_digest']==b['batch_digest']
    assert all(a[k]==b[k] for k in ('human_turns','event_turns','events_ok','partial'))
    fuzz[edition]={k:a[k] for k in ('games','human_turns','event_turns','events_ok','partial','hard_findings','batch_digest')}
census_a=json.loads((OUT/'census-0.json').read_text());census_b=json.loads((OUT/'census-7.json').read_text())
for value in (census_a,census_b):
    assert value['games']==value['completed']==10 and not value['failures']
    assert all(key=='legal-decline' or count==0 for key,count in value['by_severity'].items())
assert census_a==census_b
assert identity()==before and hashlib.sha256(BASELINE.read_bytes()).hexdigest()==baseline_hash
result={'source':before,'bot_games':sum(len(v) for v in games.values()),'bot_editions':{e:len(v) for e,v in games.items()},
        'baseline_comparison':{'games':100,'winner_or_card_count_changes':len(differences),'rate_changes':rate_changes,'passed':balance_passed,'baseline_sha256':baseline_hash,'baseline_changed':False,'existing_band':0.15},
        'fuzz':fuzz,'mixed_seat_distinct_cases':30,'mixed_seat_executions_including_replay_and_hash_repeat':120,
        'parent_comparison':{'games':100,'winner_or_card_count_changes':len(parent_differences),'provenance':'task-baseline.json: byte-identical parent source; reused labelled records'},
        'strict_census_executions':20,'census_severities':census_a['by_severity'],
        'scope':'Five scenarios; bot legacy seeds1-20 and other edition seeds201-205; mixed seeds201-202 in all three profiles, hashes0/7 with replay.',
        'passed':balance_passed}
(OUT/'integration-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
assert balance_passed, 'Balance band exceeded: inspect baseline-differences.json; do not refresh automatically'
