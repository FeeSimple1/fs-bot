"""Preserve exact old-save loading and continuation, with read-only observers."""
import argparse
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys

p=argparse.ArgumentParser()
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args()
sys.path.insert(0,str(a.repo.resolve()))
from fs_bot import rules_consts as rc
from fs_bot.engine import interlude
from fs_bot.state.serialize import encode,load_game
from fs_bot.tools.validation_metadata import source_identity
from fs_bot.board.pieces import count_pieces,find_leader
fixture_dir=a.repo/'fs_bot/tests/fixtures/compatibility_8ef88e2'
spec=importlib.util.spec_from_file_location('fixture_driver',fixture_dir/'generate.py')
driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
manifest=json.loads((fixture_dir/'manifest.json').read_text())
fixture=fixture_dir/'pre-interlude.json'
source=source_identity()
state,meta,log=load_game(fixture,validate=True)
initial={'state':encode(state),'meta':encode(meta),'log':encode(log)}
checkpoints=[]

def record(label,when,board,result=None):
    checkpoints.append({'label':label,'when':when,'state':encode(board),'result':encode(result),
                        'state_sha256':driver.digest(board),'rng_sha256':driver.digest(board['rng'])})

def wrap(name,label=None):
    original=getattr(interlude,name,None)
    if original is None:return
    def observer(board,*args,**kwargs):
        record(label or name,'before',board)
        result=original(board,*args,**kwargs)
        record(label or name,'after',board,result)
        return result
    setattr(interlude,name,observer)

for name in ('_step0_circumvallation','_step1_winter_events','_adjust_german_forces',
             '_adjust_belgae_forces','_adjust_aedui_forces','_adjust_arverni_forces',
             '_adjust_roman_forces','_cisalpina_relocation','_step3_britannia',
             '_step4_markers_cleanup','_step5_spring','_step6_eligibility',
             '_step7_edge_track','_step8_victory_swap','_build_pax_gallica_deck_for_interlude'):
    wrap(name)
wrap('_region_with_most_pieces','leader_region_choice')
wrap('_choose_interlude_leader_region','leader_region_choice')
stdout=io.StringIO()
with contextlib.redirect_stdout(stdout):
    result=driver.continue_fixture('pre-interlude',state,meta,log)
report={'source':source,'source_after':source_identity(),
        'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),
        'manifest_original_expected':manifest['fixtures']['pre-interlude.json']['continued_sha256'],
        'generator_sha256':hashlib.sha256((fixture_dir/'generate.py').read_bytes()).hexdigest(),
        'initial':initial,'initial_sha256':driver.digest(initial),
        'checkpoints':checkpoints,'continued':encode(result),'continued_sha256':driver.digest(result),
        'captured_stdout':stdout.getvalue(),'full_games_executed':0,'fixture_continuations':1}
with a.out.open('x') as f:json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('initial','checkpoints','continued','captured_stdout')},indent=2))
