"""Compare the original Card65 handler with its explicit-choice repair.

The old function alone is extracted verbatim from the recorded Git commit
and executed with the same unchanged piece helpers. Each invocation gets
the parameters its public contract supports; the physical position matches.
"""
import ast
from copy import deepcopy
import json
import subprocess

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, place_piece
from fs_bot.cards import card_effects as ce
from fs_bot.state.state_schema import build_initial_state, validate_state

BASE = '8db858b14cd13856059d42db1ad3931e523b5ed4'
source = subprocess.check_output(['git', 'show', BASE + ':fs_bot/cards/card_effects.py'], text=True)
function = next(node for node in ast.parse(source).body
                if isinstance(node, ast.FunctionDef) and node.name == 'execute_card_65')
namespace = dict(vars(ce))
exec(compile(ast.Module(body=[function], type_ignores=[]), '<original-card65>', 'exec'), namespace)
state = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=23)
state['executing_faction'] = rc.BELGAE
place_piece(state, rc.NERVII, rc.BELGAE, rc.WARBAND, 10)
place_piece(state, rc.NERVII, rc.GERMANS, rc.WARBAND, 5)
ce._ally_tribe(state, rc.TRIBE_NERVII, rc.GERMANS)
assert validate_state(state) == []
before = deepcopy(state)
before['event_params'] = {'warband_replacements': [{'region': rc.NERVII} for _ in range(5)],
                          'ally_replacement_tribe': rc.TRIBE_NERVII}
namespace['execute_card_65'](before, True)
state['event_params'] = {'replacements': [
    {'region': rc.NERVII, 'piece_type': rc.WARBAND,
     'piece_state': rc.HIDDEN, 'replace': True} for _ in range(5)] + [
    {'region': rc.NERVII, 'piece_type': rc.ALLY,
     'tribe': rc.TRIBE_NERVII, 'replace': True}]}
ce.execute_card_65(state, True)
print(json.dumps({'base_commit': BASE, 'original': {
    'belgic_warbands': count_pieces(before, rc.NERVII, rc.BELGAE, rc.WARBAND),
    'german_warbands': count_pieces(before, rc.NERVII, rc.GERMANS, rc.WARBAND),
    'tribe_owner': before['tribes'][rc.TRIBE_NERVII]['allied_faction'],
    'integrity': validate_state(before)}, 'repaired': {
    'belgic_warbands': count_pieces(state, rc.NERVII, rc.BELGAE, rc.WARBAND),
    'german_warbands': count_pieces(state, rc.NERVII, rc.GERMANS, rc.WARBAND),
    'tribe_owner': state['tribes'][rc.TRIBE_NERVII]['allied_faction'],
    'integrity': validate_state(state)}}, indent=2))
