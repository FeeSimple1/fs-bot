"""Reproduce seventh-audit observations on the audited source bytes."""
import argparse, hashlib, json, os, pathlib, subprocess, sys
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--out',required=True);a=p.parse_args()
root=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path(a.repo).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
ledger=json.loads((root/'findings.json').read_text());h=hashlib.sha256()
for file in sorted((repo/'fs_bot').rglob('*.py')):h.update(str(file.relative_to(repo)).encode()+b'\0'+file.read_bytes())
assert h.hexdigest()==ledger['source_sha256'],'Check out the audited source revision before running defect witnesses.'
rows=[]
for entry in ledger['portable_witnesses']:
 r=subprocess.run([sys.executable,str(root/entry['script'])],cwd=repo,env=dict(os.environ,PYTHONPATH=str(repo),PYTHONHASHSEED='0'),capture_output=True,text=True)
 (out/(pathlib.Path(entry['script']).stem+'.json')).write_text(r.stdout)
 match=r.returncode==0 and json.loads(r.stdout)==json.loads((root/entry['output']).read_text())
 rows.append(dict(entry,exit_code=r.returncode,exact_json_match=match,stderr=r.stderr))
summary={'all_pass':all(r['exact_json_match'] for r in rows),'source_sha256':h.hexdigest(),'witnesses':rows}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2));sys.exit(0 if summary['all_pass'] else 1)
