"""Independent legal-opportunity control, not a claim that Event52 emits a second request."""
import json,runpy,sys
from pathlib import Path
repo,output=sys.argv[1:3]
root=Path(__file__).parent
sys.argv=['probe_second_sa.py',repo,str(root/'support-first-only')]
g=runpy.run_path(str(root/'probe_second_sa.py'))
r=g['r'];state=g['state'];plan=g['plan'];execute_decision=g['execute_decision']
from fs_bot.engine.free_actions import validate_free_action_response,execute_free_action_plan
rows=[]
for first,second in [(r.SA_SCOUT,r.SA_BUILD),(r.SA_BUILD,r.SA_SCOUT)]:
 s=state()
 s['decision_agent']=lambda st,f,q:plan(first) if q['kind']=='free_action' else None
 result=execute_decision(s,r.ROMANS,{'action':'event','player_action':{'command':'Event','details':{'card_id':52,'text_preference':r.EVENT_SHADED}}})
 assert result['executed'];s.pop('decision_agent')
 p=plan(second);p.pop('command');p.pop('regions');p.pop('sa_timing');p['details'].pop('recruit_plan')
 request={'kind':'free_action','request_type':'event_sa','allowed_sas':[second],'free':True}
 error=validate_free_action_response(s,r.ROMANS,request,p);assert error is None,error
 completed=execute_free_action_plan(s,r.ROMANS,request,p);assert completed['executed']
 assert s['tribes'][r.TRIBE_HELVII]['allied_faction']==r.ROMANS
 assert g['count_pieces'](s,r.SEQUANI,r.ROMANS,r.AUXILIA)==1
 assert g['count_pieces'](s,r.PROVINCIA,r.ROMANS,r.FORT)==1
 assert g['validate_state'](s)==g['check_structural_integrity'](s)==[]
 rows.append({'first':first,'second':second,'hypothetical_second_grant_validation':error,'second_execution':completed,'helvii':s['tribes'][r.TRIBE_HELVII], 'auxilia_sequani':1,'permanent_fort_preserved':True})
Path(output).write_text(json.dumps(rows,indent=2))
