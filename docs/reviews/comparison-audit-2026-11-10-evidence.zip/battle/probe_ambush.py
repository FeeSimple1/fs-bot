"""Reproduce the Ambush/Fort defect on the audited, unmodified engine.

Run from the fs-bot root with PYTHONPATH=. python PATH/TO/probe_ambush.py.
Assertions pin the observed defect, not the desired rule.
"""
import copy
import json

from fs_bot import rules_consts as rc
from fs_bot.battle.resolve import resolve_battle
from fs_bot.board.pieces import count_pieces, place_piece
from fs_bot.engine.execute import execute_decision
from fs_bot.state.state_schema import build_initial_state, validate_state
from fs_bot.tools.seat_session import validate_response


def position(caesar=False):
    state = build_initial_state(rc.SCENARIO_PAX_GALLICA, seed=0)
    state['resources'][rc.AEDUI] = 10
    place_piece(state, rc.MORINI, rc.AEDUI, rc.WARBAND, 8)
    place_piece(state, rc.MORINI, rc.ROMANS, rc.LEGION, 3, from_legions_track=True)
    place_piece(state, rc.MORINI, rc.ROMANS, rc.FORT)
    if caesar:
        place_piece(state, rc.MORINI, rc.ROMANS, rc.LEADER, leader_name=rc.CAESAR)
    assert validate_state(state) == []
    return state


def run(caesar):
    state = position(caesar)
    diagnostic = copy.deepcopy(state)
    decision = {'action': 'command_sa', 'player_action': {
        'command': rc.CMD_BATTLE, 'sa': rc.SA_AMBUSH,
        'sa_regions': [rc.MORINI], 'details': {
            'battle_plan': [{'region': rc.MORINI, 'target': rc.ROMANS}]}}}
    validate_response(state, {'kind': 'turn', 'faction': rc.AEDUI,
                             'options': ['command_sa']}, decision)
    execution = execute_decision(state, rc.AEDUI, decision)
    details = resolve_battle(diagnostic, rc.MORINI, rc.AEDUI, rc.ROMANS,
                             is_ambush=True)
    assert execution['executed'] and not execution['errors']
    assert count_pieces(state, rc.MORINI, rc.ROMANS, rc.LEGION) == 3
    assert count_pieces(state, rc.MORINI, rc.AEDUI, rc.WARBAND) == 8
    assert details['caesar_roll'] is None
    assert details['counterattack'] is None
    assert details['attack']['rolls']
    assert validate_state(state) == []
    return {'case': 'with_caesar' if caesar else 'without_caesar',
            'execution': execution, 'battle': details,
            'legions_remaining': 3, 'aedui_warbands_remaining': 8,
            'expected': ('Caesar makes his 4–6 test and may Counterattack on success.'
                         if caesar else 'Two halved Attack Losses automatically remove two Legions.'),
            'source': 'Chapter 4 §§4.3.3, 4.4.3; Chapter 3 §3.4.4'}


if __name__ == '__main__':
    print(json.dumps([run(False), run(True)], indent=2))
