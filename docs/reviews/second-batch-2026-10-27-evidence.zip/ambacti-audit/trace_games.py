import contextlib, gzip, hashlib, io, json, os, sys
from pathlib import Path
sys.path.insert(0, os.getcwd())
from fs_bot import rules_consts as rc
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.engine.game_engine import start_game, play_card, get_sop_factions
from fs_bot.cli.dispatcher import make_decision_func
from fs_bot.engine import execute as ex
from fs_bot.tools.validation_metadata import source_identity
out=Path(sys.argv[1]); out.mkdir(parents=True,exist_ok=True)
source=source_identity()
for seed in map(int,sys.argv[2:]):
 state=setup_scenario(rc.SCENARIO_GALLIC_WAR,seed=seed,card_edition='legacy')
 state['non_player_factions']=set(get_sop_factions(state))
 bot=make_decision_func({},stdin=io.StringIO(),stdout=io.StringIO(),pause=False)
 decisions=[]; cards=[]; execution=[]
 original=ex.execute_decision
 def snapshot(s):return encode({k:v for k,v in s.items() if k!='decision_agent'})
 def decide(s,faction,options,position):
  before=snapshot(s)
  answer=bot(s,faction,options,position)
  decisions.append(dict(card_index=len(cards)+1,card=s.get('current_card'),faction=faction,position=position,options=options,before=before,after_decide=snapshot(s),answer=encode(answer)))
  return answer
 def execute(s,faction,decision):
  before=snapshot(s)
  result=original(s,faction,decision)
  execution.append(dict(card_index=len(cards)+1,card=s.get('current_card'),faction=faction,before=before,after=snapshot(s),result=encode(result)))
  return result
 ex.execute_decision=execute
 with contextlib.redirect_stdout(io.StringIO()):
  start_game(state)
  while state['current_card'] is not None and len(cards)<200:
   result=play_card(state,decide,execute=True)
   cards.append(dict(result=encode(result),after=snapshot(state)))
   if result.get('game_over'):break
 ex.execute_decision=original
 final=snapshot(state)
 record=dict(source=source,seed=seed,decisions=decisions,execution=execution,cards=cards,winner=cards[-1]['result'].get('winner'),final_state_sha256=hashlib.sha256(json.dumps(final,sort_keys=True).encode()).hexdigest())
 with gzip.open(out/f'seed-{seed}.json.gz','wt') as f:json.dump(record,f,sort_keys=True)
 print(json.dumps(dict(seed=seed,winner=record['winner'],cards=len(cards),final_state_sha256=record['final_state_sha256'],source=source)),flush=True)
