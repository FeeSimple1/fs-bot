"""Read-only physical deltas and PR-12 forecasts on recorded identical inputs."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / 'fs-bot'))
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces
from fs_bot.cards.litaviccus_np import _outcomes, plan
from fs_bot.map.map_data import get_playable_regions_for_state
from fs_bot.state.serialize import decode, encode
from fs_bot.tools.validation_metadata import source_identity

EXPECTED = '90a57ffbce8c94a9a4dc2690b15c5cce3bfa45e6b7f2e0b4af367ca883efeb06'


def differences(a, b, path=''):
    if isinstance(a, dict) and isinstance(b, dict):
        for key in sorted(a.keys() | b.keys()):
            yield from differences(a.get(key, '<missing>'), b.get(key, '<missing>'), path + '/' + key)
    elif a != b:
        yield {'path': path, 'parent': a, 'candidate': b}


def signature(state):
    return hashlib.sha256(json.dumps(encode(state), sort_keys=True).encode()).hexdigest()


def main():
    assert source_identity()['source_sha256'] == EXPECTED
    results = []
    for path in sorted((HERE / 'attempt1').glob('*-first-divergence.json')):
        data = json.loads(path.read_text())
        old, new = data['parent'], data['candidate']
        prior = data['preceding_candidate']
        row = {'file': path.name, 'stage': old['stage'], 'card_index': old['card_index']}
        if old['stage'] == 'decision-after':
            state = decode({**prior['board'], 'rng': prior['rng']})
            start = signature(state)
            regions = []
            for region in sorted(get_playable_regions_for_state(state, rc.BELGAE)):
                if not count_pieces(state, region, rc.ROMANS, rc.LEGION):
                    continue
                joined = count_pieces(state, region, rc.BELGAE) + count_pieces(state, region, rc.AEDUI)
                if not joined:
                    continue
                outcomes = list(_outcomes(state, region))
                regions.append({'region': region, 'physical_pieces': encode(state['spaces'][region]['pieces']),
                                'outcomes': [dict(legion_losses=n, safer_than_counterattack=safe,
                                                  frost_permitted=frost) for n, safe, frost in outcomes],
                                'minimum_legion_losses': min((n for n, _, _ in outcomes), default=0)})
            row.update(faction=prior['faction'], predicted_plan=plan(state), regions=regions,
                       input_and_rng_unchanged=start == signature(state))
            assert row['input_and_rng_unchanged']
            assert row['predicted_plan'] is None
        else:
            old_board = deepcopy(data['preceding_parent']['board'])
            new_board = deepcopy(data['preceding_candidate']['board'])
            old_board.update({key: change['after'] for key, change in old['changes'].items()})
            new_board.update({key: change['after'] for key, change in new['changes'].items()})
            row['physical_delta'] = list(differences(old_board, new_board))
            row['grant_args'] = prior.get('args')
            row['physical_metadata_only'] = False
        results.append(row)
    assert source_identity()['source_sha256'] == EXPECTED
    result = {'candidate_source_sha256': EXPECTED, 'cases': results,
              'limitations': 'Forecasts run on recorded identical inputs. Deltas retain all board fields; no additive metadata is normalized.'}
    path = HERE / 'attempt1' / 'source-explanation-inputs.json'
    with path.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
