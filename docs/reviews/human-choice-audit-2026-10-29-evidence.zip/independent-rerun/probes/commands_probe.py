"""Deterministic human Command/SA audit; no repository edits.
Run from repo with PYTHONPATH=. using the audit venv. Empty initialized
positions preserve inventory, permanent Provincia Fort, and tribe topology.
All piece movement/removal uses piece helpers; every result validates.
"""
import copy, io, json
from fs_bot import rules_consts as rc
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.board.pieces import place_piece, count_pieces, count_pieces_by_state
from fs_bot.board.control import refresh_all_control
from fs_bot.engine.execute import execute_decision, _execute_sa
from fs_bot.tools.seat_session import SeatSession, DecisionPending, validate_response
from fs_bot.cli.display import HumanTurnDisplay
from fs_bot.commands.sa_scout import scout_reveal
from fs_bot.commands.sa_devastate import devastate_region
from fs_bot.commands.sa_rampage import rampage
from fs_bot.commands.seize import seize_in_region


def state(scenario=rc.SCENARIO_GREAT_REVOLT):
    s=build_initial_state(scenario,seed=81)
    s['non_player_factions']=set()
    s['resources']={f:20 for f in rc.FACTIONS}
    place_piece(s,rc.PROVINCIA,rc.ROMANS,rc.FORT,1)
    return s

def valid(s):
    errors=validate_state(s)+check_structural_integrity(s)
    assert not errors, errors

def session(s,seat):
    x=SeatSession(s,{'seat':seat,'scenario':s['scenario'],'seed':81},[],HumanTurnDisplay(io.StringIO()))
    s['decision_agent']=x.reactive
    return x

def rally(region,count=1):
    return {'command':rc.CMD_RALLY,'regions':[region],'sa':'No SA','sa_regions':[],
            'details':{'rally_plan':{'steps':[{'region':region,'action':'place_warbands','count':count}]}}}

def seize(region):
    return {'command':rc.CMD_SEIZE,'regions':[region],'sa':'No SA','sa_regions':[], 'details':{}}

def finish(x,action,actor):
    # Explicitly decline optional voluntary removal at each offered boundary;
    # no substantive loss, target, agreement, or effect choice is delegated.
    from fs_bot.engine.game_engine import _action_transaction
    def driver(*args): pass
    driver.transaction_checkpoint=x.checkpoint
    driver.transaction_restore=x.restore
    for n in range(30):
        try:
            with _action_transaction(x.state,driver):
                result=execute_decision(x.state,actor,{'player_action':action})
            x.finish()
            return result
        except DecisionPending:
            req=x.data['pending']['request']
            kind=req['kind']
            if kind not in ('voluntary_removal','agreement'): raise
            response={'done':True} if kind=='voluntary_removal' else False
            x.import_inbox({'decision_id':x.data['pending']['id'],'response':response})
    raise AssertionError('too many windows')

def devastate():
    s=state(); R=rc.CARNUTES
    place_piece(s,R,rc.ARVERNI,rc.LEADER,leader_name=rc.VERCINGETORIX)
    place_piece(s,R,rc.ARVERNI,rc.WARBAND,12)
    place_piece(s,R,rc.ROMANS,rc.AUXILIA,2)
    place_piece(s,R,rc.ROMANS,rc.LEGION,1,from_legions_track=True)
    valid(s)
    native=copy.deepcopy(s)
    native_result=devastate_region(native,R,{rc.ROMANS:[(rc.LEGION,None,1)]})
    valid(native)
    x=session(s,rc.ROMANS) # victim seat: must be asked about its own loss
    action=rally(rc.ARVERNI_REGION); action.update(sa=rc.SA_DEVASTATE,sa_regions=[R])
    out=execute_decision(s,rc.ARVERNI,{'player_action':action})
    valid(s)
    assert out['sa_execution']['executed'] and x.data['pending'] is None
    assert count_pieces(s,R,rc.ROMANS,rc.LEGION)==1 and count_pieces(s,R,rc.ROMANS,rc.AUXILIA)==1
    return {'native_legion_choice':native_result,'typed_result':out,'victim_pending':x.data['pending'],
            'remaining_legions':1,'remaining_auxilia':1,'valid':True}

def rampage_count():
    s=state(); R=rc.NERVII
    place_piece(s,R,rc.BELGAE,rc.LEADER,leader_name=rc.AMBIORIX)
    place_piece(s,R,rc.BELGAE,rc.WARBAND,4)
    place_piece(s,R,rc.ROMANS,rc.AUXILIA,4)
    valid(s)
    native=copy.deepcopy(s)
    native_result=rampage(native,R,rc.ROMANS,3,[{'action':'remove','piece_type':rc.AUXILIA,'piece_state':rc.HIDDEN}]*3)
    valid(native)
    action=rally(rc.ATREBATES); action.update(sa=rc.SA_RAMPAGE,
        sa_regions=[{'region':R,'target':rc.ROMANS,'warbands_to_flip':3,'count':3}])
    x=session(s,rc.BELGAE)
    out=finish(x,action,rc.BELGAE); valid(s)
    assert out['sa_execution']['rampages'][0]['count']==2
    return {'native_three_supported':native_result,'typed_result':out,'hidden_belgae_remaining':count_pieces_by_state(s,R,rc.BELGAE,rc.WARBAND,rc.HIDDEN),'valid':True}

def scout_split():
    s=state(); R=rc.CARNUTES
    place_piece(s,R,rc.ROMANS,rc.LEADER,leader_name=rc.CAESAR)
    place_piece(s,R,rc.ROMANS,rc.AUXILIA,1)
    for f in (rc.BELGAE,rc.ARVERNI): place_piece(s,R,f,rc.WARBAND,1)
    valid(s)
    native=copy.deepcopy(s)
    native_result=scout_reveal(native,R,1,[{'faction':f,'count':1} for f in (rc.BELGAE,rc.ARVERNI)])
    valid(native)
    action=seize(R); action.update(sa=rc.SA_SCOUT,sa_regions=[R])
    action['details']['scout_plan']={'auxilia_moves':[],'scout_targets':[
        {'region':R,'enemy':f,'hidden':1} for f in (rc.BELGAE,rc.ARVERNI)]}
    x=session(s,rc.ROMANS); out=finish(x,action,rc.ROMANS); valid(s)
    counts={f:count_pieces_by_state(s,R,f,rc.WARBAND,rc.SCOUTED) for f in (rc.BELGAE,rc.ARVERNI)}
    assert counts=={rc.BELGAE:1,rc.ARVERNI:0}
    return {'native_split_supported':native_result,'typed_result':out,'scouted':counts,'valid':True}

def scout_visibility():
    s=state(); R=rc.CARNUTES
    place_piece(s,R,rc.ROMANS,rc.LEADER,leader_name=rc.CAESAR)
    place_piece(s,R,rc.ROMANS,rc.AUXILIA,1)
    place_piece(s,R,rc.BELGAE,rc.WARBAND,1,piece_state=rc.HIDDEN)
    place_piece(s,R,rc.BELGAE,rc.WARBAND,1,piece_state=rc.REVEALED)
    valid(s)
    out=scout_reveal(s,R,1,[{'faction':rc.BELGAE,'count':1,'piece_state':rc.REVEALED}]); valid(s)
    assert count_pieces_by_state(s,R,rc.BELGAE,rc.WARBAND,rc.HIDDEN)==0
    assert count_pieces_by_state(s,R,rc.BELGAE,rc.WARBAND,rc.REVEALED)==1
    return {'native_result':out,'requested_visibility':rc.REVEALED,'observed_hidden_scouted':True,'valid':True}

def seize_subset():
    s=state(); R=rc.CARNUTES
    place_piece(s,R,rc.ROMANS,rc.AUXILIA,2); valid(s)
    native=copy.deepcopy(s)
    native_result=seize_in_region(native,R,[rc.TRIBE_AULERCI]); valid(native)
    # Victims explicitly decline any triggered Rally so this probe isolates Dispersal.
    def decline(board,faction,request):
        if request['kind']=='free_action': return {'decline':True}
        return None
    s['decision_agent']=decline
    action=seize(R); action['details']={'disperse_regions':[R],'tribes_to_disperse':[rc.TRIBE_AULERCI]}
    out=execute_decision(s,rc.ROMANS,{'player_action':action}); valid(s)
    assert len(out['regions'][0]['tribes_dispersed'])==2
    return {'native_subset_supported':native_result['tribes_dispersed'],'typed_dispersed':out['regions'][0]['tribes_dispersed'],'valid':True}

def repeated_regions():
    s=state(); R=rc.CARNUTES
    place_piece(s,R,rc.ROMANS,rc.AUXILIA,1); valid(s)
    action=seize(R); action['regions']=[R,R]
    x=session(s,rc.ROMANS)
    validate_response(s,{'kind':'turn','faction':rc.ROMANS,'options':['command']},{'action':'command','player_action':action})
    out=finish(x,action,rc.ROMANS); valid(s)
    assert out['regions_resolved']==[R,R] and out['forage_resources_total']==8
    e=state(); place_piece(e,R,rc.ARVERNI,rc.LEADER,leader_name=rc.VERCINGETORIX)
    place_piece(e,R,rc.ARVERNI,rc.WARBAND,2); place_piece(e,R,rc.BELGAE,rc.WARBAND,2)
    a=rally(rc.ARVERNI_REGION); a.update(sa=rc.SA_ENTREAT,sa_regions=[
        {'region':R,'action':'replace_piece','target_faction':rc.BELGAE,'piece_type':rc.WARBAND,'target_state':rc.HIDDEN}]*2)
    y=session(e,rc.ARVERNI); second=finish(y,a,rc.ARVERNI); valid(e)
    assert len(second['sa_execution']['actions'])==2
    return {'seize_result':out,'entreat_result':second,'durable_turn_validation':'accepted repeated Seize Region','valid':True}

def intimidate_tribe():
    s=state(rc.SCENARIO_ARIOVISTUS); R=rc.CARNUTES
    place_piece(s,R,rc.GERMANS,rc.LEADER,leader_name=rc.ARIOVISTUS_LEADER)
    place_piece(s,R,rc.GERMANS,rc.WARBAND,4)
    from fs_bot.cards.card_effects import _ally_tribe
    for t in (rc.TRIBE_CARNUTES,rc.TRIBE_AULERCI): _ally_tribe(s,t,rc.ROMANS)
    valid(s)
    action={'command':rc.CMD_RAID,'sa':rc.SA_INTIMIDATE,'sa_regions':[R], 'details':{
        'raid_plan':[{'region':rc.UBII,'target':None}],
        'intimidate_plan':[{'region':R,'target_faction':rc.ROMANS,'target_piece':rc.ALLY,'target_state':None,'tribe':rc.TRIBE_CARNUTES}]}}
    place_piece(s,rc.UBII,rc.GERMANS,rc.WARBAND,1)
    x=session(s,rc.GERMANS); out=finish(x,action,rc.GERMANS); valid(s)
    left={t:s['tribes'][t]['allied_faction'] for t in (rc.TRIBE_CARNUTES,rc.TRIBE_AULERCI)}
    assert left[rc.TRIBE_CARNUTES]==rc.ROMANS and left[rc.TRIBE_AULERCI] is None
    return {'typed_result':out,'requested_tribe':rc.TRIBE_CARNUTES,'remaining_allies':left,'valid':True}

def build_order():
    s=state(); first,second=rc.CARNUTES,rc.SEQUANI
    place_piece(s,rc.MANDUBII,rc.ROMANS,rc.LEADER,leader_name=rc.CAESAR)
    for r in (first,second): place_piece(s,r,rc.ROMANS,rc.AUXILIA,1)
    valid(s)
    action={'command':rc.CMD_RECRUIT,'regions':[rc.PROVINCIA],'sa':rc.SA_BUILD,
            'sa_regions':[first,second], 'details':{
                'recruit_plan':[{'region':rc.PROVINCIA,'action':'place_auxilia','count':1}],
                'build_plan':{'forts':[second], 'subdue':[],
                              'allies':[{'region':first,'tribe':rc.TRIBE_CARNUTES}]}}}
    x=session(s,rc.ROMANS); out=finish(x,action,rc.ROMANS); valid(s)
    actual=out['sa_execution']['actions']
    assert actual==[('fort',second),('ally',first,rc.TRIBE_CARNUTES)]
    return {'selected_region_order':[first,second],'actual_operation_order':actual,
            'typed_result':out,'valid':True}

if __name__=='__main__':
    results={}
    for probe in (devastate,rampage_count,scout_split,scout_visibility,seize_subset,repeated_regions,intimidate_tribe,build_order):
        try: results[probe.__name__]=probe()
        except BaseException as e:
            import traceback
            results[probe.__name__]={'error':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
    print(json.dumps(results,indent=2,sort_keys=True))
    assert not any('error' in x for x in results.values())
