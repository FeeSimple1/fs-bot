"""Verify eighth comparison audit run evidence; this is not exhaustive rule coverage."""
from collections import Counter
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import re
import sys
from xml.etree import ElementTree

from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues, summarize
from fs_bot.tools.validation_metadata import source_identity


def main():
    p = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent
    root = Path(__import__('fs_bot').__file__).resolve().parent.parent
    identity = json.loads((p / 'source.json').read_bytes())
    expected_identity = {
        'commit': 'e62b0360c1b91032741ef8f6afa4d247c8ea2437',
        'dirty': False,
        'source_sha256': '3c047ebcfef915efef8e1da308cd63484b1e6c735b8aba8e5c095de2c5d106b9',
    }
    failures = []

    def check(ok, message):
        if not ok:
            failures.append(message)

    check(identity == expected_identity, 'Initial source identity differs from audited revision')
    current = source_identity()
    check(current['commit'] == identity['commit'], 'Current commit differs from tested commit')
    check(current['source_sha256'] == identity['source_sha256'], 'Python sources changed during validation')
    python_files = len(list((root / 'fs_bot').rglob('*.py')))
    check(python_files == 611, f'Expected 611 Python files, got {python_files}')
    expected = {(s, n, 'second-edition') for s in SCENARIOS for n in range(45, 49)}
    rows = [json.loads(line) for line in (p / 'bots-second/games.jsonl').read_text().splitlines()]
    keys = [(r['scenario'], r['seed'], r['card_edition']) for r in rows]
    check(len(rows) == len(set(keys)) == len(expected) == 20 and set(keys) == expected,
          'Bot scenario/seed/edition coverage differs from the exact 20 requested unique keys')
    botmeta = json.loads((p / 'bots-second/metadata.json').read_bytes())
    check(all(botmeta.get(k) == v for k, v in identity.items()), 'Bot metadata source identity mismatch')
    check(botmeta.get('seeds') == [45, 46, 47, 48], 'Bot metadata seed mismatch')
    check(set(botmeta.get('scenarios', [])) == set(SCENARIOS), 'Bot metadata scenario mismatch')
    check(botmeta.get('card_edition') == 'second-edition', 'Bot metadata edition mismatch')
    check(botmeta.get('hash_seed') == 0 and botmeta.get('workers') == 2,
          'Bot metadata runner settings mismatch')
    diagnostic_groups, diagnostic_incidents = Counter(), Counter()
    for row in rows:
        label = f"{row['scenario']} seed={row['seed']}"
        check(all(row.get(k) is True for k in ('completed', 'game_completed', 'audit_completed')),
              f'{label}: completion/audit flag failure')
        check(not row.get('errors') and not row.get('error') and not row.get('integrity_findings'),
              f'{label}: errors or integrity findings')
        check(not _outcome_issues(row), f'{label}: invalid engine/computed ranking or winner: {_outcome_issues(row)}')
        check(row.get('engine_ranking_output_missing') is False and
              row.get('winner_differs_from_highest_margin') is False,
              f'{label}: missing ranking or winner/margin disagreement')
        check(isinstance(row.get('final_state_sha256'), str) and len(row['final_state_sha256']) == 64,
              f'{label}: missing final state digest')
        check(row.get('commit') == identity['commit'] and row.get('source_sha256') == identity['source_sha256'],
              f'{label}: source identity mismatch')
        check(all(d.get('severity') == 'legal-decline' for d in row['diagnostics']),
              f'{label}: nonlegal diagnostic category')
        check(all(d.get('severity') == 'legal-decline' for d in row['diagnostic_occurrences']),
              f'{label}: nonlegal diagnostic occurrence')
        check(sum(d['count'] for d in row['diagnostics']) == len(row['diagnostic_occurrences']),
              f'{label}: diagnostic occurrence count mismatch')
        for d in row['diagnostics']:
            diagnostic_groups[d['severity']] += 1
            diagnostic_incidents[d['severity']] += d['count']
    stored_summary = json.loads((p / 'bots-second/summary.json').read_bytes())
    check(stored_summary == json.loads(json.dumps(summarize(rows))), 'Bot stored summary differs from records')

    fuzz = {seed: json.loads((p / f'fuzz{seed}.json').read_bytes()) for seed in (0, 987)}
    json_match = (p / 'fuzz0.json').read_bytes() == (p / 'fuzz987.json').read_bytes()
    stdout_match = (p / 'fuzz0.log').read_bytes() == (p / 'fuzz987.log').read_bytes()
    check(json_match, 'Mixed-player JSON differs across hash seeds 0/987')
    check(stdout_match, 'Mixed-player stdout differs across hash seeds 0/987')
    for seed, run in fuzz.items():
        records = run['records']
        fkeys = [(r['scenario'], r['seed'], r['card_edition']) for r in records]
        check(run['games'] == len(records) == len(set(fkeys)) == 20 and set(fkeys) == expected,
              f'Fuzz hash{seed}: incomplete/duplicated scenario/seed/edition coverage')
        check(run['hard_findings'] == 0 and not run['by_kind'], f'Fuzz hash{seed}: hard findings')
        check(all(r['game_completed'] and not r['findings'] and r['digest'] for r in records),
              f'Fuzz hash{seed}: incomplete/failed case or missing replay digest')
        check(all(run['metadata'].get(k) == v for k, v in identity.items()),
              f'Fuzz hash{seed}: source identity mismatch')
        check(all(run['metadata'].get(k) is True for k in ('reactive', 'events', 'replay')),
              f'Fuzz hash{seed}: reactions, Events or replay disabled')
        check(run['metadata'].get('seeds') == [45, 46, 47, 48] and
              set(run['metadata'].get('scenarios', [])) == set(SCENARIOS) and
              run['metadata'].get('card_edition') == 'second-edition',
              f'Fuzz hash{seed}: metadata coverage mismatch')
        for field in ('human_turns', 'event_turns', 'events_ok', 'partial'):
            check(run[field] == sum(r[field] for r in records), f'Fuzz hash{seed}: {field} aggregate mismatch')
        digest = hashlib.sha256()
        for r in records:
            digest.update(f"{r['scenario']}|{r['seed']}|{r['card_edition']}|{r['digest']}".encode())
        check(digest.hexdigest() == run['batch_digest'], f'Fuzz hash{seed}: batch digest mismatch')

    suites = list(ElementTree.parse(p / 'pytest.xml').getroot().iter('testsuite'))
    totals = {k: sum(int(s.attrib.get(k, 0)) for s in suites) for k in ('tests', 'errors', 'failures', 'skipped')}
    check(totals['tests'] == 10116, f"Expected 10116 tests, got {totals['tests']}")
    check(not any(totals[k] for k in ('errors', 'failures', 'skipped')), 'Pytest errors, failures or skips')
    pytest_log = (p / 'pytest.log').read_text()
    warning_match = re.search(r'(\d+) warnings in ([0-9.]+)s', pytest_log)
    executions = {name: json.loads((p / f'{name}-execution.json').read_bytes())
                  for name in ('pytest', 'bots-second', 'fuzz0', 'fuzz987')}
    check(all(e.get('exit_status') == 0 for e in executions.values()), 'At least one validation command failed')
    baseline = json.loads((p / 'baseline-identity.json').read_bytes())
    baseline_after = hashlib.sha256((root / 'fs_bot/tools/balance_baseline.json').read_bytes()).hexdigest()
    check(baseline_after == baseline['sha256'], 'Balance baseline changed during validation')

    summary = {
        'source': identity, 'source_identity_at_verification': current,
        'python': platform.python_version(), 'python_files': python_files,
        'pytest': {'passed': totals['tests'] - totals['errors'] - totals['failures'] - totals['skipped'],
                   **totals, 'seconds': sum(float(s.attrib['time']) for s in suites),
                   'version': importlib.metadata.version('pytest'),
                   'xdist_version': importlib.metadata.version('pytest-xdist'),
                   'warnings': int(warning_match[1]) if warning_match else 0,
                   'warning_note': 'External anyio pytest plugin uses the deprecated CallSpec2 alias; no game-engine warnings.',
                   'console_seconds': float(warning_match[2]) if warning_match else None,
                   'workers': 5, 'hash_seed': 0, 'log': 'pytest.log', 'junit': 'pytest.xml'},
        'bots': {'games': len(rows), 'attempted': len(rows),
                 'complete': sum(r['completed'] for r in rows),
                 'game_completed': sum(r['game_completed'] for r in rows),
                 'audit_completed': sum(r['audit_completed'] for r in rows),
                 'interludes': sum(r['interlude_completed'] for r in rows),
                 'interlude_keys': [[r['scenario'], r['seed']] for r in rows if r['interlude_completed']],
                 'seeds': [45, 46, 47, 48], 'edition': 'second-edition', 'scenarios': list(SCENARIOS),
                 'diagnostics': dict(diagnostic_groups), 'diagnostic_incidents': dict(diagnostic_incidents),
                 'diagnostics_note': 'diagnostics counts grouped per-game rows; diagnostic_incidents sums their count fields',
                 'errors': sum(len(r['errors']) for r in rows),
                 'integrity_findings': sum(len(r['integrity_findings']) for r in rows),
                 'ranking_issues': sum(len(_outcome_issues(r)) for r in rows),
                 'terminations': dict(Counter(r['termination'] for r in rows)),
                 'ended_on_final_winter': sum(r['ended_on_final_winter'] for r in rows),
                 'ended_before_final_winter': sum(not r['ended_on_final_winter'] for r in rows),
                 'winners_by_scenario': {s: dict(Counter(r['winner'] for r in rows if r['scenario'] == s)) for s in SCENARIOS},
                 'winner_attribution': 'Faction at game end; after the Gallic War Interlude Arverni represents the original German seat.',
                 'files': ['bots-second.log', 'bots-second/metadata.json', 'bots-second/games.jsonl', 'bots-second/summary.json']},
        'mixed': {**{k: fuzz[0][k] for k in ('games', 'human_turns', 'event_turns', 'events_ok', 'partial', 'hard_findings', 'batch_digest')},
                  'distinct_cases': 20, 'hash_runs': 2, 'executions_including_internal_replays': 80,
                  'completed_cases_per_hash': {str(seed): sum(r['game_completed'] for r in run['records']) for seed, run in fuzz.items()},
                  'files': ['fuzz0.json', 'fuzz0.log', 'fuzz987.json', 'fuzz987.log']},
        'hash_seeds': [0, 987], 'mixed_exact_bytes_match': json_match and stdout_match,
        'mixed_json_exact_bytes_match': json_match, 'mixed_stdout_exact_bytes_match': stdout_match,
        'baseline_changed': baseline_after != baseline['sha256'], 'balance_matrix_run': False,
        'executions': executions, 'failure_count': len(failures), 'failures': failures,
        'limits': ['Second-edition seeds45-48 supplement the prior seeds41-44 sample; they do not exhaust game or rule coverage.',
                   'No new legacy balance matrix or balance refresh was performed for this unchanged-source audit.',
                   'Cross-hash comparison covers mixed-player JSON/stdout and internal replays; the audited bot batch ran at hash0.'],
    }
    (p / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))
    return min(len(failures), 250)


if __name__ == '__main__':
    raise SystemExit(main())
