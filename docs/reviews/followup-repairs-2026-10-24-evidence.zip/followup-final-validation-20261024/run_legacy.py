from pathlib import Path
import json, os, subprocess, sys
ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'fs-bot'
sys.path.insert(0, str(REPO))
from fs_bot.tools.validation_metadata import source_identity
expected = json.loads((ROOT / 'freeze.json').read_text())['source_sha256']
records=[]
for name,seeds in [('legacy-1000','1-200'), ('legacy-heldout-500','201-300')]:
    before=source_identity()
    assert before['source_sha256']==expected, before
    cmd=[sys.executable,'-m','fs_bot.tools.run_batch','--seeds',seeds,'--card-edition','legacy','--workers','2','--out',str(ROOT/name)]
    with (ROOT/(name+'.log')).open('w') as log:
        proc=subprocess.run(cmd,cwd=REPO,env={**os.environ,'PYTHONHASHSEED':'0'},stdout=log,stderr=subprocess.STDOUT)
    after=source_identity()
    record=dict(name=name,command=cmd,exit_code=proc.returncode,before=before,after=after)
    records.append(record)
    (ROOT/'legacy-launches.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,proc.returncode,flush=True)
    assert proc.returncode==0, record
    assert after['source_sha256']==expected, after
