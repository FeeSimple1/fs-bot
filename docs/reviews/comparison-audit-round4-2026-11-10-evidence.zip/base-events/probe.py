import json
from copy import deepcopy
from fs_bot import rules_consts as rc
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.board.pieces import count_pieces,place_piece
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.moves import validate_player_action
from fs_bot.tools.seat_session import validate_response,board_copy
from fs_bot.state.serialize import encode


def board(card,setup=True):
 s=(setup_scenario if setup else build_initial_state)(rc.SCENARIO_GREAT_REVOLT,seed=4)
 s['current_card']=card;s['card_edition']='original';s['non_player_factions']=set()
 assert validate_state(s)==[] and check_structural_integrity(s)==[]
 return s

def play(s,card,params,actor=rc.BELGAE,shaded=False):
 d={'action':'event','player_action':{'command':rc.FIRST_DID_EVENT,'details':{'card_id':card,'text_preference':rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,'event_params':params}}}
 validate_response(s,{'kind':'turn','faction':actor,'options':['event']},d)
 before=encode(board_copy(s)); ok,info=validate_player_action(s,actor,d['player_action']);assert ok, info; assert encode(board_copy(s))==before
 r=execute_decision(s,actor,d);assert r['executed'],r
 return {'result':r,'census':validate_state(s),'structure':check_structural_integrity(s)}

out={}
for targets in ([rc.ARVERNI],[rc.ARVERNI,rc.ARVERNI],[]):
 s=board(46);s['resources'][rc.ARVERNI]=20
 o=play(s,46,{'target_factions':targets});o['after_resources']=s['resources'][rc.ARVERNI];out['46_'+str(targets)]=o

for params in [
 {'target_tribes':[{'tribe':rc.TRIBE_CATUVELLAUNI,'region':rc.PROVINCIA,'faction':rc.BELGAE,'warband_faction':rc.BELGAE}]},
 {'target_tribes':[{'tribe':rc.TRIBE_HELVII,'region':rc.PROVINCIA,'faction':rc.ROMANS,'warband_faction':rc.BELGAE}]},
 {'target_tribes':[{'tribe':rc.TRIBE_HELVII,'region':rc.PROVINCIA,'faction':rc.BELGAE,'warband_faction':rc.BELGAE}]},
]:
 s=board(22,setup=False);place_piece(s,rc.PROVINCIA,rc.ROMANS,rc.AUXILIA)
 o=play(s,22,params,shaded=True);o['tribes']={t:s['tribes'][t] for t in (rc.TRIBE_CATUVELLAUNI,rc.TRIBE_HELVII)};o['warbands_provincia']=count_pieces(s,rc.PROVINCIA,rc.BELGAE,rc.WARBAND);out['22_'+str(params)]=o

for targets in ([rc.ROMANS],[rc.AEDUI],[rc.AEDUI,rc.AEDUI],[rc.BELGAE,rc.AEDUI,rc.ARVERNI]):
 s=board(48); seen=[]
 # Guaranteed one-warband Rally and Roman Recruit from Provincia.
 def agent(st,faction,request):
  if request['kind']=='free_action':
   seen.append(faction)
   if faction==rc.ROMANS:
    return {'command':rc.CMD_RECRUIT,'sa':'No SA','regions':[rc.PROVINCIA],'details':{'recruit_plan':[{'region':rc.PROVINCIA,'action':'place_auxilia','count':1}]}}
   region={rc.AEDUI:rc.AEDUI_REGION,rc.ARVERNI:rc.ARVERNI_REGION,rc.BELGAE:rc.MORINI}[faction]
   return {'command':rc.CMD_RALLY,'sa':'No SA','regions':[region],'details':{'rally_plan':{'steps':[{'region':region,'action':'place_warbands','count':1}]}}}
 s['decision_agent']=agent
 try:
  o=play(s,48,{'target_factions':targets});o['seen']=seen;o['pieces']={f:sum(count_pieces(s,region,f,rc.WARBAND) for region in s['spaces']) for f in rc.GALLIC_FACTIONS};o['roman_auxilia']=count_pieces(s,rc.PROVINCIA,rc.ROMANS,rc.AUXILIA);out['48_'+str(targets)]=o
 except Exception as e:out['48_'+str(targets)]={'error':str(e),'seen':seen}
print(json.dumps(out,indent=2,default=str))
