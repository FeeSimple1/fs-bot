"""Replay audited bot games that reached the Interlude and record home-City adjustments."""

from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import sys
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, get_leader_in_region
from fs_bot.cli.dispatcher import make_decision_func
from fs_bot.engine import interlude
from fs_bot.engine.game_engine import get_sop_factions, play_card, start_game
from fs_bot.map.map_data import get_tribes_in_region_for_state
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.tools.validation_metadata import source_identity


def digest(value):
    return sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def snapshot(state, region):
    piece_types = (rc.LEGION, rc.AUXILIA, rc.FORT, rc.WARBAND, rc.ALLY, rc.CITADEL, rc.SETTLEMENT)
    forces = {}
    for faction in rc.FACTIONS:
        counts = {kind: count_pieces(state, region, faction, kind) for kind in piece_types}
        leader = get_leader_in_region(state, region, faction)
        if leader:
            counts[rc.LEADER] = leader
        if any(counts.values()):
            forces[faction] = {kind: count for kind, count in counts.items() if count}
    return dict(forces=forces,
                tribes={tribe: dict(state['tribes'][tribe])
                        for tribe in get_tribes_in_region_for_state(state, region)},
                legions_track=dict(state['legions_track']), board=digest(state),
                rng=digest(state['rng'].getstate()))


def replay(row):
    scenario, seed, edition = (row[key] for key in ('scenario', 'seed', 'card_edition'))
    state = setup_scenario(scenario, seed=seed, card_edition=edition)
    state['non_player_factions'] = set(get_sop_factions(state))
    decide = make_decision_func({}, stdin=StringIO(), stdout=StringIO(), pause=False)
    stages = {}

    def record(region, adjust):
        def wrapped(state):
            before = snapshot(state, region)
            result = adjust(state)
            stages[region] = dict(before=before, result=result, after=snapshot(state, region))
            return result
        return wrapped

    transition = None
    with (patch.object(interlude, '_adjust_aedui_forces',
                       record(rc.AEDUI_REGION, interlude._adjust_aedui_forces)),
          patch.object(interlude, '_adjust_arverni_forces',
                       record(rc.ARVERNI_REGION, interlude._adjust_arverni_forces)),
          redirect_stdout(StringIO())):
        start_game(state)
        for draw in range(1, 201):
            if transition is None and state['current_card'] == rc.WINTER_CARD:
                before = digest(state)
            result = play_card(state, decide, execute=True)
            if transition is None and state['interlude_completed']:
                transition = dict(draw=draw, before=before, after=digest(state), stages=stages)
            if result['game_over']:
                break

    final_board = digest({k: v for k, v in state.items() if k != 'decision_agent'})
    assert transition is not None
    assert (result['winner'], draw, final_board) == (
        row['winner'], row['cards'], row['final_state_sha256'])
    return dict(scenario=scenario, seed=seed, card_edition=edition, winner=row['winner'],
                cards=draw, final_board=final_board, interlude=transition)


def main(output, *records):
    rows = [json.loads(line) for path in records for line in Path(path).read_text().splitlines()]
    source = source_identity()
    assert rows and all(row['source_sha256'] == source['source_sha256'] for row in rows)
    games = [replay(row) for row in rows if row['interlude_completed']]
    Path(output).write_text(json.dumps(dict(source=source, games=games), indent=2) + '\n')
    print(f'{len(games)} Interludes match their audited game records')


if __name__ == '__main__':
    main(*sys.argv[1:])
