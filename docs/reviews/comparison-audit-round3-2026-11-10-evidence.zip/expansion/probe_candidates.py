import json,sys
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces,place_piece,remove_piece,get_available
from fs_bot.cards.card_effects import _ally_tribe,execute_event
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT
from fs_bot.engine.moves import validate_player_action
from fs_bot.state.state_schema import build_initial_state,validate_state,check_structural_integrity
from fs_bot.tools.seat_session import validate_response

def board(card,faction=rc.BELGAE):
 s=build_initial_state(rc.SCENARIO_ARIOVISTUS,seed=317)
 s.update(non_player_factions=set(), current_card=card,next_card='A67',executing_faction=faction)
 return s

def run(s,card,params,shaded=False):
 assert not validate_state(s),validate_state(s)
 assert not check_structural_integrity(s),check_structural_integrity(s)
 action={'command':rc.FIRST_DID_EVENT,'regions':[],'sa':'No SA','sa_regions':[], 'details':{'card_id':card,'text_preference':rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,'event_params':params}}
 d={'action':ACTION_EVENT,'player_action':action}
 error=None
 try: validate_response(s,{'kind':'turn','faction':s['executing_faction'],'options':[ACTION_EVENT]},d)
 except Exception as e: error=f'{type(e).__name__}: {e}'
 valid=validate_player_action(s,s['executing_faction'],action)
 result=execute_decision(s,s['executing_faction'],d)
 return {'validation_error':error,'valid':valid,'result':result,'pool_errors':validate_state(s),'structural_errors':check_structural_integrity(s)}

out={}
s=board('A29')
out['A29_empty']=run(s,'A29',{'placements':[]},True)
out['A29_empty']['avail']={p:get_available(s,rc.GERMANS,p) for p in (rc.WARBAND,rc.SETTLEMENT)}
s=board('A19')
s.update(executing_faction=rc.GERMANS,event_params={'region':rc.SEQUANI})
execute_event(s,71)
assert s['tribes']['Colony_Sequani']['allied_faction']==rc.GERMANS
place_piece(s,rc.SEQUANI,rc.ROMANS,rc.LEADER,leader_name=rc.CAESAR)
s['executing_faction']=rc.BELGAE
out['A19_colony']=run(s,'A19',{'replacements':[{'tribe':'Colony_Sequani'}]})
out['A19_colony']['colony_after']=s['tribes']['Colony_Sequani']['allied_faction']
print(json.dumps(out,indent=2,default=str))

for status in (rc.DISPERSED,rc.DISPERSED_GATHERING):
 s=board('A35')
 place_piece(s,rc.TREVERI,rc.ROMANS,rc.AUXILIA)
 from fs_bot.commands.seize import seize_in_region
 seize_in_region(s,rc.TREVERI,[rc.TRIBE_TREVERI],no_rally=True)
 if status==rc.DISPERSED_GATHERING:
  from fs_bot.engine.winter import spring_phase
  # Just flip the physical marker orientation to its equally valid other side.
  s['tribes'][rc.TRIBE_TREVERI]['status']=status
 out['A35_'+status]=run(s,'A35',{'ally_faction':rc.BELGAE,'piece_faction':rc.BELGAE,'piece_type':rc.WARBAND,'count':0})
 out['A35_'+status]['tribe_after']=s['tribes'][rc.TRIBE_TREVERI]

for stalwart in (False,True):
 s=board('A31',rc.BELGAE)
 place_piece(s,rc.ATREBATES,rc.BELGAE,rc.WARBAND,6)
 place_piece(s,rc.ATREBATES,rc.GERMANS,rc.WARBAND,8,piece_state=rc.REVEALED)
 s['resources'][rc.BELGAE]=20
 s['event_params']={}
 execute_event(s,59,shaded=True)
 if stalwart: execute_event(s,'A31',shaded=True)
 action={'command':rc.CMD_BATTLE,'regions':[rc.ATREBATES],'sa':'No SA','sa_regions':[], 'details':{'battle_plan':[{'region':rc.ATREBATES,'target':rc.GERMANS}]}}
 d={'action':'command','player_action':action}
 out['A31_horse_'+str(stalwart)]={'valid':validate_player_action(s,rc.BELGAE,action),'result':execute_decision(s,rc.BELGAE,d),'germans_after':count_pieces(s,rc.ATREBATES,rc.GERMANS,rc.WARBAND),'pool_errors':validate_state(s),'structural_errors':check_structural_integrity(s)}
print(json.dumps(out,indent=2,default=str))
