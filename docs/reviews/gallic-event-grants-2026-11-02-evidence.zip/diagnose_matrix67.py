import sys, json, traceback, inspect
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/534c265c65f4/fs-bot')
from fs_bot import rules_consts as rc
from fs_bot.board import pieces
from fs_bot.engine import voluntary_removal
from fs_bot.tools.run_batch import play_one
from fs_bot.state.serialize import encode
out=Path('/workspace/scratch/534c265c65f4/gallic-event-grants-2026-11-02')
captured=[]
def trap(label, original):
 def wrapped(*args, **kwargs):
  try: return original(*args, **kwargs)
  except Exception as exc:
   if 'Physical-owner selection requires Enlist' not in str(exc) and 'Removal cohorts must be distinct physical subsets.' not in str(exc): raise
   frames=[]; state=None
   for item in inspect.stack()[1:]:
    loc=item.frame.f_locals
    if state is None and isinstance(loc.get('state'),dict): state=loc['state']
    frames.append({'function':item.function,'line':item.lineno,
       'locals':{k:repr(v)[:12000] for k,v in loc.items() if k in ('region','origin','faction','piece_type','owner','kwargs','rows','cohorts','registered','prepared','ctx','original','remaining','pools','key','card_id','request','action')}})
   data={'label':label,'error':str(exc),'traceback':traceback.format_exc(),'frames':frames}
   if state: data['state']=encode({k:v for k,v in state.items() if k!='decision_agent'})
   captured.append(data)
   (out/f'matrix67-diagnostic-{len(captured)}.json').write_text(json.dumps(data,indent=2,default=str))
   raise
 return wrapped
pieces._enlist_operation=trap('enlist_operation',pieces._enlist_operation)
voluntary_removal._checked_cohorts=trap('checked_cohorts',voluntary_removal._checked_cohorts)
for task in [(rc.SCENARIO_GREAT_REVOLT,201,'second-edition'),(rc.SCENARIO_RECONQUEST,12,'legacy')]:
 result=play_one(task)
 print(json.dumps({'task':task,'audit_completed':result['audit_completed'],'nonlegal':[x for x in result['diagnostics'] if x['severity']!='legal-decline']}))
