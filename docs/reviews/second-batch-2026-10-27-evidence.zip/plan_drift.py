"""Prepare a prioritized, review-only causal audit plan; never launch games."""
import argparse
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / "fs-second-batch-baseline04b"
FIRST = ROOT.parent / "first-batch-validation/attempt3"


def rows(path):
    return {(r["scenario"], r["seed"]): r for r in map(json.loads, path.read_text().splitlines())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attempt", required=True)
    args = parser.parse_args()
    run = ROOT / args.attempt
    review = json.loads((run / "results.json").read_text())
    assert review["pytest_checked"] and review["pytest"]["exit_code"] == 0
    assert all(f.startswith("balance/") for f in review["failures"]), "Only a valid engine matrix may enter drift review"
    current = rows(run / "bots-legacy/games.jsonl")
    old = rows(FIRST / "bots-legacy/games.jsonl")
    assert current.keys() == old.keys() and len(current) == 100
    assert all(r["completed"] and r["audit_completed"] and r["game_completed"] for r in current.values())
    old_source = json.loads((FIRST / "source.json").read_text())
    failed_scenarios = {f.split("/")[1] for f in review["failures"]}
    cases = []
    for (scenario, seed), row in current.items():
        prior = old[scenario, seed]
        outcome_changed = row["winner"] != prior["winner"]
        state_changed = row["final_state_sha256"] != prior["final_state_sha256"]
        priority = (0 if outcome_changed and scenario in failed_scenarios else
                    1 if outcome_changed else 2 if state_changed else 3)
        slug = scenario.lower().replace("?", "").replace(" ", "-") + f"-{seed:02}"
        cached_baseline = None
        for path in sorted(ROOT.glob(f"attempt*/drift-review/{slug}/baseline.json.gz"), reverse=True):
            with gzip.open(path, "rt") as stream:
                cached = json.load(stream)
            if (cached.get("passed") is True
                    and cached.get("scenario") == scenario and cached.get("seed") == seed
                    and cached["source"]["source_sha256"] == old_source["source_sha256"]
                    and cached["source_after"]["source_sha256"] == old_source["source_sha256"]
                    and cached["record"]["final_state_sha256"] == prior["final_state_sha256"]):
                cached_baseline = str(path)
                break
        if cached_baseline is None and scenario == "The Gallic War" and seed in (3, 10, 16, 20):
            cached_baseline = str(ROOT / "ambacti-audit/baseline04b" / f"seed-{seed}.json.gz")
        cases.append({"scenario": scenario, "seed": seed, "edition": "legacy", "priority": priority,
                      "winner_changed": outcome_changed, "full_final_state_changed": state_changed,
                      "baseline": {k: prior[k] for k in ("winner", "cards", "final_state_sha256")},
                      "current": {k: row[k] for k in ("winner", "cards", "final_state_sha256")},
                      "action": "trace both once and compare earliest divergence" if state_changed else
                                "no new game needed: identical complete final-state hash and outcome",
                      "baseline_archive": cached_baseline})
    cases.sort(key=lambda c: (c["priority"], c["scenario"], c["seed"]))
    plan = {"status": "prepared only; no games launched; source review required before any refresh",
            "attempt": args.attempt, "current_source": review["source"],
            "baseline_source_sha256": old_source["source_sha256"],
            "baseline_commit": "04b4b70bedae78a07723340aa4ed401b3a77dd29",
            "baseline_worktree": str(BASE), "original_failures": review["failures"],
            "all_cases": len(cases), "changed_winners": sum(c["winner_changed"] for c in cases),
            "changed_full_states": sum(c["full_final_state_changed"] for c in cases),
            "priority_order": "Beyond-band scenario changed winners, other changed winners, changed-state/same-winner cases; skip exact final-state matches.",
            "cases": cases}
    out = run / "drift-plan.json"
    with out.open("x") as stream:
        json.dump(plan, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({k:v for k,v in plan.items() if k != "cases"}, indent=2))


if __name__ == "__main__":
    main()
