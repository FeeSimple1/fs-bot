"""Audit 7 Battle witnesses. Run with PYTHONPATH pointing to audited fs-bot.

Uses only public Event/Command/phase entries, seeded RNG and canonical piece
placement. Assertions pin observed defects and controls, not intended repairs.
"""
from copy import deepcopy
import json

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, place_piece
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT, ACTION_COMMAND
from fs_bot.engine.arverni_phase import run_arverni_phase
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity


def board(scenario=rc.SCENARIO_GREAT_REVOLT):
    state = build_initial_state(scenario, seed=7)
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    state['non_player_factions'] = set()
    state['resources'].update({faction: 20 for faction in state['resources']})
    return state


def oracles(state):
    result = {'census': validate_state(state), 'structure': check_structural_integrity(state)}
    assert result == {'census': [], 'structure': []}, result
    return result


def capabilities(state):
    return [{'card': card, 'side': side,
             'owner': state.get('capability_owners', {}).get(card)}
            for card, side in state.get('capabilities', {}).items()]


def event(state, card, faction=rc.ROMANS, *, shaded=False, params=None):
    state['current_card'] = card
    result = execute_decision(state, faction, {'action': ACTION_EVENT, 'player_action': {
        'command': rc.FIRST_DID_EVENT, 'details': {'card_id': card,
        'event_params': params or {},
        'text_preference': rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED}}})
    assert result['executed'], result
    return result


def ordinary_battle(state, attacker, defender, region):
    result = execute_decision(state, attacker, {'action': ACTION_COMMAND, 'player_action': {
        'command': rc.CMD_BATTLE, 'sa': 'No SA', 'regions': [region],
        'details': {'battle_plan': [{'region': region, 'target': defender}]}}})
    assert result['executed'] and not result.get('errors'), result
    return result


def install_choices(state, region, defender):
    requests = []
    def choose(live, faction, request):
        requests.append({'faction': faction, 'request': deepcopy(request)})
        if request.get('request_type') == 'fixed_event_battle':
            return {'region': region, 'defender': defender}
        if request['kind'] == 'retreat':
            return {'retreat': False}
    state['decision_agent'] = choose
    return requests


def fixed_battle(kind, capability=None):
    state = board()
    region = rc.CARNUTES if kind in ('legiones', 'ordinary_legiones') else rc.PICTONES
    defender = rc.ROMANS if kind in ('legiones', 'ordinary_legiones') else rc.BELGAE
    place_piece(state, region, rc.AEDUI, rc.WARBAND, 4)
    if defender == rc.BELGAE:
        place_piece(state, region, rc.BELGAE, rc.WARBAND, 8)
    place_piece(state, region, rc.ROMANS, rc.AUXILIA, 2)
    if capability is not None:
        event(state, capability, rc.AEDUI if capability == 59 else rc.ROMANS,
              shaded=capability == 59)
    requests = install_choices(state, region, defender)
    before = oracles(state)
    active_before = capabilities(state)
    if kind == 'legiones':
        result = event(state, 2, rc.AEDUI, shaded=True, params={'battle_region': region})
    elif kind == 'aquitani':
        result = event(state, 25, rc.AEDUI, params={'battle_region': region})
    elif kind == 'morasses':
        result = event(state, 36, rc.AEDUI)
    else:
        result = ordinary_battle(state, rc.AEDUI, defender, region)
    counts = {'Aedui Warbands': count_pieces(state, region, rc.AEDUI, rc.WARBAND),
              'defender mobile': count_pieces(state, region, defender,
                  rc.AUXILIA if defender == rc.ROMANS else rc.WARBAND)}
    return {'case': kind, 'capability': capability, 'scenario': state['scenario'],
            'capabilities_before': active_before, 'capabilities_after': capabilities(state),
            'before': before, 'after': oracles(state), 'survivors': counts,
            'request_kinds': [x['request']['kind'] for x in requests], 'result': result}


def arverni_phase(slingers):
    state = board(rc.SCENARIO_ARIOVISTUS)
    region = rc.CARNUTES
    place_piece(state, region, rc.ARVERNI, rc.WARBAND, 4)
    place_piece(state, region, rc.ROMANS, rc.AUXILIA, 2)
    # Frost omits March and zero Roman Resources prevents Raid from hiding
    # the capability omission behind a different number of eligible Ambushers.
    state['resources'][rc.ROMANS] = 0
    if slingers:
        event(state, 13)
    requests = install_choices(state, region, rc.ROMANS)
    before = oracles(state)
    active_before = capabilities(state)
    result = run_arverni_phase(state, is_frost=True)
    assert result['rally']['allies_placed'] == [(rc.CARNUTES, rc.TRIBE_CARNUTES)]
    assert result['march']['skipped_frost'] and not result['raid']['raids']
    assert len(result['battle']['battles']) == 1
    return {'case': 'full_arverni_phase', 'slingers': slingers,
            'scenario': state['scenario'], 'capabilities_before': active_before,
            'capabilities_after': capabilities(state), 'before': before,
            'after': oracles(state), 'survivors': {
                'Arverni Warbands': count_pieces(state, region, rc.ARVERNI, rc.WARBAND),
                'Roman Auxilia': count_pieces(state, region, rc.ROMANS, rc.AUXILIA)},
            'request_kinds': [x['request']['kind'] for x in requests], 'result': result}


def ballistae(ballistae_active=True, stalwart=True, attacker=rc.GERMANS):
    state = board(rc.SCENARIO_ARIOVISTUS)
    region = rc.CARNUTES
    place_piece(state, region, attacker, rc.WARBAND, 4)
    place_piece(state, region, rc.ROMANS, rc.FORT)
    if ballistae_active:
        event(state, 10)
    if stalwart:
        # A31 acquired last, so there is no later-Event precedence ambiguity.
        event(state, 'A31', rc.GERMANS, shaded=True)
    requests = install_choices(state, region, rc.ROMANS)
    before = oracles(state)
    active_before = capabilities(state)
    rng_probe = deepcopy(state['rng'])
    next_roll = rng_probe.randint(rc.DIE_MIN, rc.DIE_MAX)
    assert next_roll == 3
    result = ordinary_battle(state, attacker, rc.ROMANS, region)
    # Exactly the predicted one Fort absorption roll was consumed.
    assert state['rng'].getstate() == rng_probe.getstate()
    return {'case': 'ballistae_stalwart', 'scenario': state['scenario'],
            'attacker': attacker, 'ballistae': ballistae_active, 'stalwart': stalwart,
            'capabilities_before': active_before, 'capabilities_after': capabilities(state),
            'before': before, 'after': oracles(state), 'fort_roll': next_roll,
            'Roman Forts_surviving': count_pieces(state, region, rc.ROMANS, rc.FORT),
            'request_kinds': [x['request']['kind'] for x in requests], 'result': result}


def main():
    fixed = [fixed_battle('legiones', 13), fixed_battle('legiones'),
             fixed_battle('ordinary_legiones', 13),
             fixed_battle('aquitani', 13), fixed_battle('aquitani'),
             fixed_battle('morasses', 13), fixed_battle('morasses', 59),
             fixed_battle('morasses'), fixed_battle('ordinary_morasses', 59)]
    actual = [(row['survivors']['Aedui Warbands'], row['survivors']['defender mobile'])
              for row in fixed]
    assert actual == [(4, 0), (4, 0), (3, 1), (3, 3), (3, 3),
                      (4, 6), (4, 6), (4, 6), (2, 4)], actual
    phases = [arverni_phase(True), arverni_phase(False)]
    assert all(row['survivors'] == {'Arverni Warbands': 4, 'Roman Auxilia': 0} for row in phases)
    saves = [ballistae(), ballistae(stalwart=False), ballistae(ballistae_active=False),
             ballistae(attacker=rc.BELGAE)]
    assert [row['Roman Forts_surviving'] for row in saves] == [1, 1, 0, 1]
    print(json.dumps({'audited_commit': 'c67d501711471bf790d805c017c2125b2c254639',
          'seed': 7, 'production_changes': False,
          'BM7-01': {'fixed_battles': fixed, 'automatic_arverni': phases,
            'expected_correct': {
              'legiones_with_slingers': {'Aedui Warbands': 3, 'Roman Auxilia': 1},
              'aquitani_with_slingers': {'Aedui Warbands': 1, 'Belgae Warbands': 4},
              'morasses_with_slingers': {'Aedui Warbands': 3, 'Belgae Warbands': 7},
              'morasses_with_shaded_horse': {'Aedui Warbands': 4, 'Belgae Warbands': 4},
              'arverni_phase_with_slingers': {'Arverni Warbands': 3, 'Roman Auxilia': 1}}},
          'BM7-02': {'ballistae_saves': saves,
            'expected_correct': {'ballistae_plus_stalwart_German_attacker_Roman_Forts_surviving': 0}}},
          indent=2))


if __name__ == '__main__':
    main()
