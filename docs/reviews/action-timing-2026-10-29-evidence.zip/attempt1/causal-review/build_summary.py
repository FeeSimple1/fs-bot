"""Assemble immutable localized-cause evidence; does not authorize a baseline."""
from pathlib import Path
from collections import Counter
from fractions import Fraction
import gzip,hashlib,json
ROOT=Path(__file__).resolve().parent
ATTEMPT=ROOT.parent
PARENT_RUN=Path('/workspace/scratch/534c265c65f4/rulings-trade-validation-2026-10-29/attempt3/bots-legacy')

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())
def records(path):return {(r['scenario'],r['seed']):r for r in map(json.loads,path.read_text().splitlines())}
def outcome(row):return {'winner':row['winner'],'cards':row['cards']}
old=records(PARENT_RUN/'games.jsonl');new=records(ATTEMPT/'diagnostic-bots/games.jsonl');baseline=read(ATTEMPT/'balance-baseline.json')['games']
assert len(old)==len(new)==100 and set(old)==set(new)
used={};cases=[];classification_counts=Counter();changed_counts=Counter()
rule_basis={
 'roman_selected_plan_tie_correction':{'rules':['Chapter 8 §8.3.4','Chapter 8 §8.8.1'],'explanation':'Equal-priority destination choices now use the seeded random chooser rather than insertion order. Local replay records the ranking calls and exactly reproduces the changed selected plan.'},
 'roman_ranking_rng_sequence_only':{'rules':['Chapter 8 §8.3.4','Chapter 8 §8.8.1'],'explanation':'The complete destination ranking randomizes equal-priority groups, including lower groups not used by the selected move. The selected plan is unchanged but RNG position changes. Equal-choice selection is source-backed; the complete ranking draw sequence is an implementation detail, not individually mandated by the rules.'},
 'seize_triggered_rally':{'rules':['Chapter 3 §3.2.3','Chapter 8 §8.2.3'],'explanation':'Successful rolls after dispersal now resolve the granted Arverni/Belgae free Rallies. Parent recorded/rolled opportunities without applying those placements. First divergence includes actual pool/board/Tribe effects, not only richer reporting.'},
 'surus_replacement_and_command':{'rules':['Card Reference 51 Surus and Tips','Chapter 3 §§3.4.2–3.4.4','Chapter 8 §§8.2.3,8.3.1,8.4.1'],'explanation':'NPC shaded Surus now derives its replacement Region/count, then commands only the newly placed German Warbands under the executor chart and native German mechanics. Parent lacked the NPC placement derivation and permitted the older German sweep behavior.'},
 'own_casualty_visibility':{'rules':['Chapter 8 §8.4.1','Chapter 3 §§3.2.4,3.3.4'],'explanation':'Non-player own losses/removals use the reverse visibility priority: Scouted, then Revealed, then Hidden. Before/after traces expose which otherwise equal Warbands survive, including Retreat and Event-granted Battles.'},
 'no_mechanical_divergence':{'rules':[],'explanation':'Complete paired trace has no board/RNG/decision difference after the narrowly documented Seize-report normalization; winner and card count are unchanged.'},
}
for entry in read(ROOT/'semantic-localizations-100.json'):
 folder=Path(entry['review']).parent;review=read(folder/'semantic-review.json');key=(review['scenario'],review['seed']);first=review['first_mechanical_difference'];category=review['provisional_category'];proof={}
 if first is None:classification='no_mechanical_divergence';assert outcome(old[key])==outcome(new[key])
 elif first['changed_domains']==['rng'] or category.startswith('Roman decision'):
  probes={side:read(folder/(side+'.probe.json')) for side in ('parent','candidate')}
  assert all(p['output_state_matches_trace'] and p['output_payload_matches_trace'] for p in probes.values())
  ranks={side:[c for c in p['calls'] if c['function']=='_rank_march_destinations'] for side,p in probes.items()}
  draws={side:[c for c in p['calls'] if c['module']=='random.py' and any('_rank_march_destinations' in s for s in c['stack'])] for side,p in probes.items()}
  assert ranks['parent'] and ranks['candidate'] and any(any('_ranked' in s for s in c['stack']) for c in draws['candidate'])
  same_plan=first['parent_payload']==first['candidate_payload']
  classification='roman_ranking_rng_sequence_only' if same_plan else 'roman_selected_plan_tie_correction'
  proof={'exact_local_replays_match_trace':True,'selected_plan_unchanged':same_plan,
         'parent_ranking_rng_draws':len(draws['parent']),'candidate_ranking_rng_draws':len(draws['candidate']),
         'parent_rankings':[r['return'] for r in ranks['parent']], 'candidate_rankings':[r['return'] for r in ranks['candidate']]}
 elif category.startswith('Seize-triggered'):classification='seize_triggered_rally'
 elif category.startswith('Surus'):classification='surus_replacement_and_command'
 elif category.startswith('Battle visibility') or (first['changed_domains']==['spaces'] and first['boundary']['card']=='A69'):classification='own_casualty_visibility'
 else:raise AssertionError(('unclassified',key,category))
 if first:assert first['input']['state_equal'] and first['input']['payload_equal']
 artifacts={}
 for name in ('parent.json.gz','candidate.json.gz','comparison.json','semantic-review.json','parent.probe.json','candidate.probe.json'):
  p=folder/name
  if p.exists():artifacts[str(p.relative_to(ROOT))]=sha(p);used[str(p.relative_to(ROOT))]=sha(p)
 initial=baseline[f'{key[0]}|{key[1]}'];before=outcome(old[key]);after=outcome(new[key]);changed=before!=after
 classification_counts[classification]+=1
 if changed:changed_counts[classification]+=1
 cases.append({'scenario':key[0],'seed':key[1],'original_baseline':initial,'accepted_parent':before,'candidate':after,
       'parent_to_candidate_record_changed':changed,'parent_to_candidate_winner_changed':before['winner']!=after['winner'],
       'original_to_candidate_record_changed':initial!=after,'classification':classification,
       'first_mechanical_boundary':first and first['boundary'],'changed_domains':first and first['changed_domains'],
       'equal_action_input_state':first and first['input']['state_equal'],'equal_action_input_payload':first and first['input']['payload_equal'],
       'parent_input_state_sha256':first and first['input']['parent_state_sha256'],'candidate_input_state_sha256':first and first['input']['candidate_state_sha256'],
       'local_probe':proof,'evidence_sha256':artifacts})
# All accepted captures already independently parse and match the exact audited
# records. Bind the raw artifacts, not merely the local classifications.
comparison_review=read(ATTEMPT/'diagnostic-original-comparison.review.json')
failed_artifacts=[];superseded_valid=[];failed_pairs=[]
for folder in sorted(ROOT.glob('*-incomplete-capture')):
 failed_pairs.append(folder.name)
 for p in sorted(folder.glob('*.json.gz')):
  item={'path':str(p.relative_to(ROOT)),'sha256':sha(p)}
  try:
   with gzip.open(p,'rt') as f:json.load(f)
   superseded_valid.append(item)
  except (EOFError,OSError,ValueError) as error:
   item['error_type']=type(error).__name__;failed_artifacts.append(item)
assert len(failed_artifacts)==18 and len(failed_pairs)==14 and len(superseded_valid)==10
external_files=[ATTEMPT/'balance-baseline.json',PARENT_RUN/'games.jsonl',PARENT_RUN/'metadata.json',ATTEMPT/'diagnostic-bots/games.jsonl',ATTEMPT/'diagnostic-bots/metadata.json',ATTEMPT/'diagnostic-bots/summary.json',ATTEMPT/'diagnostic-original-comparison.review.json']
source_files=[Path('/workspace/scratch/534c265c65f4/fs-action-timing-parent/Reference Documents')/n for n in ('Chapter 3','Chapter 8','Card Reference')]
auxiliary={str(p.relative_to(ROOT)):sha(p) for p in ROOT.rglob('*') if p.is_file() and p.suffix in ('.py','.json','.log') and p.name not in ('causal-summary.json',) and '-incomplete-capture' not in str(p) and 'semantic-review.json'!=p.name and 'comparison.json'!=p.name and '.probe.json' not in p.name}
summary={
 'status':'All 100 pairs localized; no unresolved first mechanical divergence. Independent causal/baseline approval remains separate.',
 'baseline_modified':False,'baseline_refresh_authorized':False,
 'sources':{'accepted_parent':{'commit':'5ee485e43132e9080a083efece79c66af80afef8','source_sha256':'e19896b1e07bbf425ca5e1f7d1db5113e4db6843c3302bc0ef1eb1bd32304bd0','checkout':'/workspace/scratch/534c265c65f4/fs-action-timing-parent'},
            'candidate':{'base_commit':'5ee485e43132e9080a083efece79c66af80afef8','dirty':True,'source_sha256':'c24adb23c9018071ed948e295a96fc4b17649e35fecabd985e77dedbfa32fcc5','frozen_python_source':str(ATTEMPT/'python-source')},
            'original_baseline':{'sha256':sha(ATTEMPT/'balance-baseline.json'),'historical_source_identity':'Not encoded in the original baseline file; it is not the immediate parent outcome set.'}},
 'coverage':{'scenarios':sorted({k[0] for k in new}),'seeds':list(range(1,21)),'edition':'legacy','PYTHONHASHSEED':'0','paired_games':100,'accepted_full_traces':200,'exact_local_boundary_replays':70},
 'classification_counts':dict(classification_counts),'changed_parent_record_classification_counts':dict(changed_counts),
 'triangulation':{'original_to_parent':{'changed_records':sum(baseline[f'{k[0]}|{k[1]}']!=outcome(old[k]) for k in old),'changed_winners':sum(baseline[f'{k[0]}|{k[1]}']['winner']!=old[k]['winner'] for k in old)},
                  'parent_to_candidate':{'changed_records':sum(outcome(old[k])!=outcome(new[k]) for k in old),'changed_winners':sum(old[k]['winner']!=new[k]['winner'] for k in old)},
                  'original_to_candidate':{'changed_records':sum(baseline[f'{k[0]}|{k[1]}']!=outcome(new[k]) for k in new),'changed_winners':sum(baseline[f'{k[0]}|{k[1]}']['winner']!=new[k]['winner'] for k in new)},
                  'independent_rate_comparison':comparison_review},
 'observational_normalization':{'operation':'Recursively remove only key regions from dictionaries where command == Seize and regions_resolved is present.',
       'reason':'Candidate adds a per-Region execution report, also stored in _card_turn. The existing aggregate fields are retained and compared.',
       'preserved':'All raw full-state snapshots, raw first-difference comparisons, decision payloads, physical board, RNG, pools, Resources, Tribes, markers and all other state keys remain retained. No whole history or private-state domain is suppressed.',
       'proof':'Each trace observer asserts unchanged full encoded state and RNG around capture; every accepted trace final hash matches the separately recorded exact game.'},
 'rule_basis':rule_basis,'unresolved_findings':[],
 'capture_integrity':{'initial_capture_strategy':'Streaming gzip JSON','diagnostic_artifact_failures':failed_artifacts,'affected_pairs':failed_pairs,'valid_counterparts_superseded_with_pair':superseded_valid,
       'retry_strategy':'Preserve original pair directory and tool versions; recapture affected pair only. Atomic compressed-byte writes are fsynced and decompressed before and after rename. Initial seed1 retry used the prior streaming writer and was independently verified complete.',
       'engine_failure':False,'accepted_artifacts':'All 200 accepted gzip traces parse through their trailers, have matching source before/after and matching exact audited final game hashes; independent reviewer verified the full matrix.',
       'captured_runs_total':228,'accepted_runs':200,'failed_artifact_runs':18,'superseded_valid_runs':10,
       'original_tool_versions':'tool-versions/; reconstructed pre-fix bytes match their pre-existing launch manifest SHA256s exactly.'},
 'diagnostic_audit':comparison_review['audits'],
 'limitations':['First divergence identifies a corrected procedure or implementation RNG sequence on equal inputs; it does not prove that one change exclusively caused the final winner.',
                'Complete-ranking tie RNG consumption may affect later dice even when the chosen move is unchanged. The rules require fair tie choices, not this exact sequence of implementation draws.',
                'This is a legacy/hash0 diagnostic and causal study, not the subsequently required accepted full test/multi-edition/mixed-session/replay matrix.',
                'No baseline, game source, rule source, or game settings were changed for this causal review.'],
 'external_evidence_sha256':{str(p):sha(p) for p in external_files},'rule_source_sha256':{str(p):sha(p) for p in source_files},
 'accepted_artifacts_sha256':used,'auxiliary_evidence_sha256':auxiliary,'cases':cases}
out=ROOT/'causal-summary.json'
with out.open('x') as f:json.dump(summary,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({'summary':str(out),'sha256':sha(out),'classifications':summary['classification_counts'],'parent_changes':summary['triangulation']['parent_to_candidate'],'unresolved':summary['unresolved_findings']},indent=2))
