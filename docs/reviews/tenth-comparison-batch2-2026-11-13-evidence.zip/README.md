# Tenth comparison repair Batch 2 evidence

Batch 2 closes BM10-01. `source.json` identifies the tested patch to parent
`83e28d4e8f296ac0506552c9830dd26e0858f825`. The copied audit witness records
the original mismatch between the formula and the Battle resolver. The new
regressions execute A64, A31 and A34 through the public Event path. They
check the standing and Retreat Loss counts and the Aedui's Battle choice.

The parent bot games and replay come from Batch 1 and match the parent's
Python source digest. The verifier checks the original run metadata, game
coverage, rankings, diagnostic results, final board digests and paired
outcomes. It also checks the test results and the 48 protected source hashes.
`SHA256SUMS` covers every other archive member.

## Reproduce the checks

Use Python 3.12.14 and the development test environment. Run from the
repaired repository root. Set `OUT` to an empty output directory,
`EVIDENCE` to the extracted archive and `PARENT` to a clean checkout of
the parent commit.

```bash
PYTHONHASHSEED=0 python -m pytest -q fs_bot/tests/test_tenth_comparison_battle.py
PYTHONHASHSEED=0 python -m pytest -q -n 4 --junitxml="$OUT/full.xml"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out "$OUT/legacy"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 53-56 --card-edition second-edition --workers 2 --out "$OUT/second-edition"
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 53-56 --card-edition second-edition --out "$OUT/fuzz0.json" > "$OUT/fuzz0.log"
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 53-56 --card-edition second-edition --out "$OUT/fuzz987.json" > "$OUT/fuzz987.log"
cmp "$OUT/fuzz0.json" "$OUT/fuzz987.json"
cmp "$OUT/fuzz0.log" "$OUT/fuzz987.log"
PYTHONPATH=. python "$EVIDENCE/verify_results.py"
```

Run the included test file against the parent to reproduce the two failures
and four passing controls.

```bash
cd "$PARENT"
PYTHONPATH=. PYTHONHASHSEED=0 python -m pytest -q "$EVIDENCE/test_tenth_comparison_battle.py"
```
