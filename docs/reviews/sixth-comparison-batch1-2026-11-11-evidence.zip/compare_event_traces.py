"""Check the first differing action in each paired changed-winner replay."""
from collections import Counter
import json
from pathlib import Path
import sys


def key(game):
    return tuple(game[k] for k in ('scenario', 'seed', 'card_edition'))


def bot_action(decision):
    return decision['choice']['bot_action']['command']


def first_divergence(older, newer):
    for previous, current in zip(older['cards'], newer['cards']):
        if previous['after'] != current['after']:
            assert previous['before'] == current['before']
            assert previous['draw'] == current['draw']
            assert previous['card'] == current['card']
            break
    else:
        raise AssertionError(key(older))
    card = current['card']
    original, = previous['events']
    faction = original['faction']
    assert original['result']['executed'] and original['result']['shaded']
    assert original['material_before'] == original['material_after']
    assert previous['parameters'] == [{'faction': faction, 'shaded': True, 'params': None}]
    event_choices = [d for d in previous['decisions']
                     if d['faction'] == faction and bot_action(d) == 'Event']
    old_decision, = event_choices
    new_decision, = [d for d in current['decisions'] if d['faction'] == faction]
    assert old_decision['before'] == new_decision['before']

    if bot_action(new_decision) != 'Event':
        material = original['material_before']
        if card == 56:
            assert material['belgic_leader'] == 'Ambiorix'
            reason = 'Named Ambiorix already on the map'
        elif card == 57:
            assert faction == 'Belgae'
            owners = [tribe['allied_faction'] for tribe in material['tribes'].values()]
            assert owners == ['Belgae']
            reason = 'No increase in Belgic Allies or Citadels'
        else:
            assert card == 'A60'
            romans = material['pieces'].get('Romans', {})
            assert not romans.get('Ally') and not any(
                romans.get(visibility, {}).get('Auxilia') for visibility in ('Hidden', 'Revealed', 'Scouted'))
            reason = 'No Roman replacements in Atrebates'
    else:
        assert old_decision == new_decision
        assert card in (57, 'A35', 'A60')
        replacement, = current['events']
        assert original['before'] == replacement['before']
        assert replacement['result']['executed'] and replacement['result']['shaded']
        assert replacement['material_before'] == original['material_before']
        assert replacement['material_after'] != original['material_after']
        assert current['parameters'][0]['params']
        reason = {57: 'Britannia Ally and Warband plan',
                  'A35': 'German Settlement and Warband plan',
                  'A60': 'Belgic replacements in Atrebates'}[card]
    return dict(scenario=older['scenario'], seed=older['seed'], card_edition=older['card_edition'],
                previous_winner=older['winner'], current_winner=newer['winner'],
                card=card, draw=current['draw'], actor=faction, reason=reason,
                previous_command=bot_action(old_decision), current_command=bot_action(new_decision),
                identical_board_and_rng_before_action=True,
                previous=previous, current=current)


def main(parent_path, candidate_path, output):
    parent = json.loads(Path(parent_path).read_text())
    candidate = json.loads(Path(candidate_path).read_text())
    changes = []
    for older, newer in zip(parent['games'], candidate['games'], strict=True):
        assert key(older) == key(newer) and older['winner'] != newer['winner']
        changes.append(first_divergence(older, newer))
    result = dict(parent=parent['source'], repaired=candidate['source'], games=len(changes),
                  first_card_counts=dict(Counter(str(r['card']) for r in changes)), changes=changes)
    Path(output).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'changes'}, indent=2))


if __name__ == '__main__':
    main(*sys.argv[1:])
