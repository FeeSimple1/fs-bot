# Sixth Falling Sky comparison audit evidence

Audited commit: `86fb0c2d8ddf86a4548a863dc9c9da27d0c708ad`. Python-source SHA-256: `2423cb1f410650da300914e6569c1637675894cc43a9bd8284dfd92bd3b3ecb7` across 596 files. Comparator `FeeSimple1/lod-bot` at `2991ea279062773548ec390a1da75f3e85381702`. All rules conclusions use supplied Falling Sky sources and adopted rulings.

The 14 findings are open. Scripts intentionally assert current defects and matched controls; they are not post-repair regression expectations. Controlled fixtures are disclosed in each finding. General passing tests and game samples do not negate targeted rule failures.

From a matching source checkout, with Python 3.12 (tested 3.12.14):

```sh
python run_probes.py --repo /path/to/fs-bot --out /path/to/new-rerun
```

The runner verifies all Python source bytes and all seven JSON outputs. Each probe can also run alone with `PYTHONPATH=/path/to/fs-bot python <probe-path>`.

Validation commands, run from the repository root, with output files retained here:

```sh
PYTHONHASHSEED=0 python -m pytest -q -n 5 --dist loadfile --tb=short --show-capture=no --junitxml=pytest.xml
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 41-44 --card-edition second-edition --workers 3 --out bots-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz987.json
```

The validation verifier checks exact coverage, every game record, source identity, rankings, diagnostics, completion, inventories, XML test totals, and byte equality of mixed-player outputs. It is bound to the original audited Git commit; the portable witness runner accepts the same Python bytes after documentation-only commits. No fresh balance matrix or baseline refresh occurred.

Review records include rejected or corrected exploratory fixtures where available. The initial Event review attempt used the wrong scenario for named Ambiorix; the final probe uses Pax Gallica's actual named leader. Only final passing probes count. Raw full-suite XML and per-game records remain tied to their original revision.
