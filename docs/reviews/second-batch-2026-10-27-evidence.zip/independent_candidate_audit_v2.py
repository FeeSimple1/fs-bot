"""Read-only raw/candidate integrity audit; never executes games or accepts a baseline.

Example (first snapshot before candidate creation):
  python independent_candidate_audit_v2.py --attempt attempt4 --source-sha256 HASH --expected-tests 5082 --raw-only
Then omit --raw-only after the separately reviewed candidate exists. The second
run checks every original raw-evidence digest against the first audit snapshot.
Only a new exclusive-created independent review file is written.
"""
import argparse
import ast
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET

SCENARIOS = ("Pax Gallica?", "Reconquest of Gaul", "The Great Revolt", "Ariovistus", "The Gallic War")
FACTIONS = ("Romans", "Arverni", "Aedui", "Belgae", "Germans")
BAND = Fraction(3, 20)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key!r}")
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw, object_pairs_hook=unique_object)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--attempt", required=True)
    p.add_argument("--source-sha256", required=True)
    p.add_argument("--expected-tests", required=True, type=int)
    p.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    p.add_argument("--repo", type=Path)
    p.add_argument("--raw-only", action="store_true")
    p.add_argument("--output", type=Path)
    args = p.parse_args()
    root = args.root.resolve()
    repo = (args.repo or root.parent / "fs-bot").resolve()
    run = root / args.attempt
    expected = {f"{s}|{n}" for s in SCENARIOS for n in range(1, 21)}
    failures = []
    checked = 0
    evidence = {}

    def check(condition, description):
        nonlocal checked
        checked += 1
        if not condition:
            failures.append(description)

    def read_bytes(name):
        raw = (run / name).read_bytes()
        evidence[name] = sha(raw)
        return raw

    def read(name):
        return parse(read_bytes(name))

    source = read("source.json")
    freeze = read("freeze.json")
    results = read("results.json")
    prior_raw = read_bytes("balance-baseline.json")
    prior = parse(prior_raw)
    repo_baseline = repo / "fs_bot/tools/balance_baseline.json"
    working_prior = repo_baseline.read_bytes()
    committed_prior = subprocess.check_output(
        ["git", "show", f"{source['commit']}:fs_bot/tools/balance_baseline.json"], cwd=repo)
    check(prior_raw == working_prior == committed_prior, "Archived/repository/frozen-commit baseline bytes differ")
    check(sha(prior_raw) == freeze["balance_baseline_sha256"], "Frozen baseline digest mismatch")
    check(freeze["balance_band_exact"] == str(BAND) and freeze["balance_baseline_updated"] is False,
          "Frozen exact 15 percentage point policy changed")
    check(set(prior) == {"games"} and set(prior["games"]) == expected, "Original baseline exact key coverage mismatch")
    check(source["source_sha256"] == args.source_sha256 and results["source"] == source,
          "Expected/source/results source identities disagree")
    check(freeze["commit"] == source["commit"] and freeze["source_sha256"] == args.source_sha256,
          "Freeze commit/source identity mismatch")
    check(subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip() == source["commit"],
          "Current repository HEAD differs from frozen commit")
    hasher = hashlib.sha256()
    file_hashes = {}
    for path in sorted((repo / "fs_bot").rglob("*.py")):
        raw = path.read_bytes()
        relative = str(path.relative_to(repo))
        hasher.update(relative.encode() + b"\0" + raw)
        file_hashes[relative] = sha(raw)
    check(hasher.hexdigest() == args.source_sha256, "Current Python source digest differs from frozen source")
    check(file_hashes == freeze["source_files"], "Current Python file inventory differs from frozen inventory")
    tree = ast.parse((repo / "fs_bot/tools/balance_smoke.py").read_text())
    bands = [kw.value.value for node in ast.walk(tree) if isinstance(node, ast.Call)
             and isinstance(node.func, ast.Attribute) and node.func.attr == "add_argument"
             and any(isinstance(a, ast.Constant) and a.value == "--band" for a in node.args)
             for kw in node.keywords if kw.arg == "default" and isinstance(kw.value, ast.Constant)]
    check(bands == [0.15], "Balance CLI default changed from 0.15")

    metadata = read("bots-legacy/metadata.json")
    status = read("bots-legacy.status.json")
    summary = read("bots-legacy/summary.json")
    check(metadata["tool"] == "run_batch" and metadata["card_edition"] == "legacy"
          and metadata["all_factions_bots"] is True and metadata["hash_seed"] == 0,
          "Legacy batch metadata tool/edition/seat/hash mismatch")
    check(metadata["scenarios"] == list(SCENARIOS) and metadata["seeds"] == list(range(1, 21))
          and metadata["games_per_scenario"] == 20, "Legacy batch metadata coverage mismatch")
    check(metadata["source_sha256"] == args.source_sha256 and metadata["commit"] == source["commit"],
          "Legacy batch metadata source mismatch")
    check(status["exit_code"] == 0 and status["source_changed"] is False
          and status["source_sha256_before"] == status["source_sha256_after"] == args.source_sha256
          and status["environment"]["PYTHONHASHSEED"] == "0", "Legacy job status/source/hash mismatch")
    frozen_job = next(j for j in freeze["jobs"] if j["name"] == "bots-legacy")
    check(status["argv"] == frozen_job["argv"] and frozen_job["hash_seed"] == 0,
          "Legacy executed argv differs from frozen job")
    rows = [parse(line) for line in read_bytes("bots-legacy/games.jsonl").splitlines()]
    keys = [f"{r['scenario']}|{r['seed']}" for r in rows]
    check(len(keys) == len(set(keys)) == 100 and set(keys) == expected, "Raw legacy rows do not cover exact100 keys once")
    raw_games = {}
    coverage = Counter()
    diagnostics = Counter()
    interludes = 0
    for key, row in zip(keys, rows):
        check(type(row["seed"]) is int and 1 <= row["seed"] <= 20
              and type(row["cards"]) is int and row["cards"] > 0, f"{key}: invalid seed/card count")
        raw_games[key] = {"winner": row["winner"], "cards": row["cards"]}
        check(all(row.get(k) is True for k in ("completed", "game_completed", "audit_completed")),
              f"{key}: incomplete audit/game")
        check(not row.get("error") and row.get("errors") == [] and row.get("integrity_findings") == [],
              f"{key}: error or integrity finding")
        check(row.get("card_edition") == "legacy" and row.get("source_sha256") == args.source_sha256
              and row.get("commit") == source["commit"], f"{key}: row source/edition mismatch")
        for field in ("diagnostics", "diagnostic_occurrences"):
            check(isinstance(row.get(field), list)
                  and all(d.get("severity") == "legal-decline" for d in row[field]), f"{key}: invalid/nonlegal {field}")
        check(sum(d["count"] for d in row["diagnostics"]) == len(row["diagnostic_occurrences"]),
              f"{key}: diagnostic aggregate/occurrence count mismatch")
        diagnostic_fields = ("severity", "kind", "message", "faction", "command")
        grouped = Counter()
        for d in row["diagnostics"]:
            check(type(d["count"]) is int and d["count"] > 0, f"{key}: invalid diagnostic count")
            grouped[tuple(d.get(k) for k in diagnostic_fields)] += d["count"]
        check(grouped == Counter(tuple(d.get(k) for k in diagnostic_fields) for d in row["diagnostic_occurrences"]),
              f"{key}: diagnostic group/occurrence mismatch")
        diagnostics.update(d["severity"] for d in row["diagnostic_occurrences"])
        coverage[row.get("diagnostic_coverage")] += 1
        ending = row.get("ending_scenario")
        interlude = row.get("interlude_completed")
        allowed_ends = [("The Gallic War", False), ("Pax Gallica?", True)] if row["scenario"] == "The Gallic War" else [(row["scenario"], False)]
        check(type(interlude) is bool and (ending, interlude) in allowed_ends, f"{key}: ending/Interlude inconsistency")
        interludes += interlude is True
        eligible = set(FACTIONS) - ({"Arverni"} if ending in ("Ariovistus", "The Gallic War") else {"Germans"})
        ranking = row.get("final_ranking", [])
        check(len(ranking) == 4 and all(isinstance(r, list) and len(r) == 2 and type(r[1]) is int for r in ranking)
              and {r[0] for r in ranking} == eligible, f"{key}: invalid final faction ranking")
        check(ranking == row.get("engine_final_ranking"), f"{key}: engine/emitted ranking disagreement")
        check([r[1] for r in ranking] == sorted((r[1] for r in ranking), reverse=True), f"{key}: ranking margin order")
        precedence = [f for f in FACTIONS if f in eligible]
        if "Germans" in eligible:
            precedence = ["Romans", "Germans", "Aedui", "Belgae"]
        check(ranking == sorted(ranking, key=lambda item: (-item[1], precedence.index(item[0]))),
              f"{key}: all-NP equal-margin faction precedence mismatch")
        check(row["winner"] == row.get("highest_margin_leader") == ranking[0][0], f"{key}: winner/top margin mismatch")
        check(row.get("winner_differs_from_highest_margin") is False and row.get("engine_ranking_output_missing") is False,
              f"{key}: ranking audit flag")
        qualifiers = [f for f, margin in ranking if margin > 0]
        check(row.get("threshold_qualifiers") == qualifiers, f"{key}: threshold qualifier mismatch")
        term = row.get("termination")
        check(term in ("threshold", "final-winter-margin", "optimates"), f"{key}: unknown termination")
        check(term != "threshold" or bool(qualifiers), f"{key}: threshold without qualifier")
        check(term != "final-winter-margin" or (row.get("ended_on_final_winter") is True and not qualifiers),
              f"{key}: final Winter termination inconsistency")
        check(term != "optimates" or row["winner"] == "Arverni", f"{key}: invalid Optimates winner")
        check(bool(re.fullmatch(r"[0-9a-f]{64}", row.get("final_state_sha256", ""))), f"{key}: final state digest format")
    changes = {name: sum(pred(prior["games"][k], raw_games[k]) for k in expected)
               for name, pred in {"records": lambda a, b: a != b, "winners": lambda a, b: a["winner"] != b["winner"],
                                  "card_counts": lambda a, b: a["cards"] != b["cards"]}.items()}
    drifts = {}
    expected_failures = []
    for scenario in SCENARIOS:
        old = Counter(prior["games"][f"{scenario}|{n}"]["winner"] for n in range(1, 21))
        new = Counter(raw_games[f"{scenario}|{n}"]["winner"] for n in range(1, 21))
        deltas = {f: Fraction(new[f] - old[f], 20) for f in FACTIONS}
        drifts[scenario] = {"before_wins": dict(old), "after_wins": dict(new),
                            "exact_rate_changes": {f: str(d) for f, d in deltas.items()},
                            "percentage_point_changes": {f: float(100 * d) for f, d in deltas.items()}}
        expected_failures.extend(f"balance/{scenario}/{f}: drift {d} exceeds unchanged {BAND} band"
                                 for f, d in deltas.items() if abs(d) > BAND)
        rb = results["balance"]["scenarios"][scenario]
        check(rb["before"] == dict(old) and rb["after"] == dict(new)
              and rb["exact_rate_change"] == {f: str(d) for f, d in deltas.items()}, f"{scenario}: preserved report drift mismatch")
        check(summary[scenario]["attempted"] == summary[scenario]["completed"] == summary[scenario]["engine_completed"] == 20
              and summary[scenario]["wins"] == dict(new) and summary[scenario]["crashes"] == summary[scenario]["integrity_flagged_games"] == 0,
              f"{scenario}: legacy summary mismatch")
    check(results["accepted_attempt"] is None and results["passed"] is False
          and results["balance"]["passed"] is False and results["failures"] == expected_failures and bool(expected_failures),
          "Original failed report lost, altered, or accepted")
    check(results["balance"]["exact_band"] == str(BAND) and results["balance"]["band_percentage_points"] == 15
          and results["balance"]["baseline_updated"] is False, "Reported original balance policy changed")
    check(results["balance"]["changed_winner_count"] == changes["winners"], "Reported changed winner count mismatch")
    tests_status = read("tests.status.json")
    test_xml = read_bytes("tests.xml")
    suites = ET.fromstring(test_xml).findall(".//testsuite")
    test_counts = {k: sum(int(s.attrib[k]) for s in suites) for k in ("tests", "errors", "failures", "skipped")}
    check(test_counts == {"tests": args.expected_tests, "errors": 0, "failures": 0, "skipped": 0}, "Full JUnit counts mismatch")
    check(tests_status["exit_code"] == 0 and tests_status["source"]["source_sha256"] == tests_status["source_after"]["source_sha256"] == args.source_sha256,
          "Full suite status/source mismatch")
    check(all(results["pytest"][k] == v for k, v in test_counts.items()) and results["pytest_checked"] is True,
          "Preserved report pytest counts mismatch")

    candidate_digest = None
    candidate_keys = None
    if not args.raw_only:
        snapshot = parse((run / "independent-raw-review.json").read_bytes())
        check(snapshot["raw_data_audit_passed"] is True and snapshot["source_sha256"] == args.source_sha256,
              "Prior independent raw review did not pass at this source")
        check(snapshot["evidence_sha256"] == evidence, "Original raw evidence changed after independent snapshot")
        candidate_raw = read_bytes("balance-candidate.json")
        candidate = parse(candidate_raw)
        candidate_digest = sha(candidate_raw)
        check(set(candidate) == {"games"} and set(candidate["games"]) == expected, "Candidate exact coverage/schema mismatch")
        candidate_keys = len(candidate["games"])
        for key, record in candidate["games"].items():
            check(set(record) == {"winner", "cards"} and type(record["cards"]) is int and record["cards"] > 0,
                  f"{key}: candidate schema/count mismatch")
            check(record == raw_games.get(key), f"{key}: candidate differs from exact audited row")
        review = read("balance-candidate-review.json")
        check(review["candidate_sha256"] == candidate_digest and review["old_baseline_sha256"] == sha(prior_raw)
              and review["source"] == source and review["candidate_games"] == 100, "Candidate producer metadata mismatch")
        check(review["repository_baseline_replaced"] is False and review["band_changed"] is False
              and review["exact_band"] == str(BAND) and review["original_guardrail_passed"] is False
              and review["original_failures"] == expected_failures, "Candidate producer lost original failed policy/report")
        check(review["changed_records"] == changes["records"] and review["changed_winners"] == changes["winners"]
              and review["changed_card_counts"] == changes["card_counts"] and review["new_game_executions"] == 0,
              "Candidate producer change totals or new-game count mismatch")
        check(review["exact_keys"] == sorted(expected), "Candidate producer exact-key list mismatch")
        expected_comparison = [{"key": k, "before": prior["games"][k], "candidate": raw_games[k],
                                "winner_changed": prior["games"][k]["winner"] != raw_games[k]["winner"],
                                "cards_changed": prior["games"][k]["cards"] != raw_games[k]["cards"],
                                "record_changed": prior["games"][k] != raw_games[k]} for k in sorted(expected)]
        check(review["comparison"] == expected_comparison, "Candidate producer per-record comparison mismatch")
        for scenario, drift in drifts.items():
            produced = review["scenarios"][scenario]
            check(produced["games"] == 20 and produced["before_wins"] == drift["before_wins"]
                  and produced["candidate_wins"] == drift["after_wins"]
                  and produced["exact_rate_changes"] == drift["exact_rate_changes"]
                  and produced["percentage_point_changes"] == drift["percentage_point_changes"]
                  and produced["original_guardrail_passed"] is all(abs(Fraction(d)) <= BAND for d in drift["exact_rate_changes"].values()),
                  f"{scenario}: candidate producer drift metadata mismatch")
    check(repo_baseline.read_bytes() == working_prior, "Repository baseline changed during independent audit")
    check(all(sha((run / name).read_bytes()) == digest for name, digest in evidence.items()), "Evidence changed during independent audit")
    report = {
        "status": "independent read-only integrity review; not accepted; no baseline replacement authorized",
        "attempt": args.attempt, "raw_data_audit_passed": not failures,
        "candidate_data_audit_passed": None if args.raw_only else not failures,
        "failures": failures, "checks_performed": checked,
        "source_sha256": args.source_sha256, "commit": source["commit"], "source_python_files_checked": len(file_hashes),
        "legacy_records_checked": len(rows), "exact_raw_keys": len(set(keys)), "candidate_keys": candidate_keys,
        "candidate_sha256": candidate_digest, "old_baseline_sha256": sha(prior_raw),
        "repository_baseline_unchanged": repo_baseline.read_bytes() == prior_raw,
        "changes": changes, "scenario_drifts": drifts, "exact_band": str(BAND), "band_percentage_points": 15,
        "original_balance_passed": False, "original_failures": expected_failures,
        "original_report_sha256": evidence["results.json"], "evidence_sha256": evidence,
        "diagnostic_occurrences": dict(diagnostics), "diagnostic_coverage": dict(coverage),
        "interlude_completed": interludes, "pytest": dict(test_counts, exit_code=tests_status["exit_code"]),
        "new_games_executed": 0, "baseline_installed": False,
        "limitations": ["Integrity review only; causal rules review and baseline authorization are separate.",
                        "Final-state digest syntax/provenance checked; outcome rows alone cannot independently reconstruct final boards.",
                        "Raw diagnostic coverage is exactly the reported returned-cards-only coverage; hidden callback events are not independently reconstructed.",
                        "Only the100 legacy records and full-suite evidence are independently checked here; other matrix totals require their separate review."]}
    out = args.output or run / ("independent-raw-review.json" if args.raw_only else "independent-candidate-review.json")
    with out.open("x") as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({k: v for k, v in report.items() if k not in ("scenario_drifts", "evidence_sha256", "limitations")}, indent=2))
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
