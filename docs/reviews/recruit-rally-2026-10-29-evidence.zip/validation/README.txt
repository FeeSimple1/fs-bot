Recruit/Rally choice batch, starting clean main15417ff1b3e6f29b6bc3b6738efcbfb964bce10b.
All evidence is new and isolated. No preceding Spring/Event outcomes are relabeled.

Before edits:5,226 tests passed,63.55s, actualpytest and runner exits0.
Starting PythonSHA32fc2e1f0c2eb2e005db4c7638884a6d2022246c5eda9d87b7ade87da4caeb74 (315files).
Starting balanceSHA815b6f363134159b4cf5772abd4dc76a5e8e0be8fd0bb852dc571390504814f5.
Starting fixture manifestSHA0e1609c9158d2a2e635eca578681442764b05637200f7000ae5554ccceb060ef.
The pre-edit runner directly captured exact argv/cwd/environment, source-file inventory, original baseline/fixture bytes, JUnit/log and actual child+runner exits; all identities remained stable. See before-review.json.

No post-change simulations or final suite before an explicit integrated source freeze.
Proposed bounded post-freeze matrix covers all five scenarios:
100legacy bots (seeds1-20),25original bots (201-205),25second-edition bots (201-205), hashseed0.
20 mixed cases (seeds1-4) internally replayed at hashes0/7 =80 executions.
25 strict census cases (seeds1-5) at hashes0/7 =50 executions.
Profiles stay separate. No automatic baseline or fixture refresh. Exact unchanged15-percentage-point legacy guardrail uses the same100 audited records rather than redundant games.

Run using /workspace/scratch/534c265c65f4/fs-test-venv/bin/python and login:false:
  python orchestrate.py --attempt attempt1 --source-sha256 FROZEN_SHA --prepare-only
  python run_tests.py --attempt attempt1 --source-sha256 FROZEN_SHA
  # Only after passing full suite and explicit parent matrix release:
  python orchestrate.py --attempt attempt1 --source-sha256 FROZEN_SHA --resume-prepared
  python verify.py --attempt attempt1
The orchestrator starts legacy first; nonzero audit status gates all six later commands. Default two batch workers/two concurrent remaining jobs. A STOP-AFTER-LEGACY file in the attempt directory blocks not-yet-launched later jobs when the parent requires a manual gate. Existing jobs are not misreported as unlaunched. The final suite uses -q -n6, captures JUnit and source/baseline/fixture inventories, and never overwrites a prior check. Failures require a new attempt or explicitly distinct report/test label.

Frozen metadata includes exact commands, source files, baseline and fixture manifest bytes. Source/baseline/fixture are monitored throughout. verify.py independently checks exact150 profile/scenario/seed keys, completion flags, errors/integrity/nonlegal diagnostics and occurrence groups, eligible four-faction rankings including equal-margin precedence, engine-emitted ranking, winner and final hashes, summary counts, Interlude endings, exact legacy balance, mixed-case coverage and complete cross-hash JSON equality/replay digests, strict census counts/cross-hash equality, and final full-suite JUnit/status. Optional rejected random plans are separately disclosed. Census does not emit successful per-game records; its coverage evidence is exact metadata plus aggregate completion.

Targeted acceptance for the implementation owners includes source-derived zero/under-maximum/exact-maximum quantities; omitted-field backward compatibility; Available/regional cap limits; human menu/API agreement; Vercingetorix combined Ally+Warband choice and physical supply; base/expansion/scoped Event distinctions; NP behavior preservation; selected-region costs; transactional invalid/missing-response handling; preview/RNG purity; save/load and deterministic replay. The frozen full suite must include those targeted regressions. Random mixed games do not prove complete human-choice coverage.

An original balance failure remains a failure. Diagnose exact paired outcomes and source-backed first behavioral divergences before proposing any separate review-only candidate; the parent must approve installation. Never widen the band or tune choices for preferred winners. Fixture expectation changes likewise require cause/provenance review and distinct before/after evidence. Local validation is not a claim about remote CI.

Final execution order changed by parent: full suite first, no matrix until separate release. Prepared-only mode creates evidence without games; resume rejects any existing matrix status, altered inputs, or missing/failed full suite. A source or fixture correction after a failed suite uses a fresh prepared attempt and preserves the failed suite. Clean parent worktree /workspace/scratch/534c265c65f4/fs-recruit-rally-baseline is available for exact same-call probes and paired traces; no baseline games have been launched.

Prospective full-byte evidence: every new prepared attempt now captures all fs_bot/**/*.py bytes into its own python-source directory before any test/game runs, recomputes the aggregate digest, records snapshot metadata, and verifies the snapshot again before matrix release. Attempt1 originally retained only hashes; its separately documented exact-hash recovery remains historically distinguished.
