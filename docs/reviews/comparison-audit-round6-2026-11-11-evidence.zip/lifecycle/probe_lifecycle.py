"""Sixth audit: base-game Germans Phase witnesses; no engine patches.

Run with the audited fs-bot root on PYTHONPATH. Assertions intentionally
confirm defective behavior on 86fb0c2, not the corrected expectations.
"""
from copy import deepcopy
import json
from fs_bot import rules_consts as rc
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.board.pieces import place_piece, count_pieces
from fs_bot.board.control import refresh_all_control
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.commands.march import germans_phase_march
from fs_bot.commands.rally import germans_phase_rally, rally_in_region
from fs_bot.engine.winter import germans_phase


def integrity(state):
    result = {'census': validate_state(state), 'structure': check_structural_integrity(state)}
    assert result == {'census': [], 'structure': []}, result
    assert count_pieces(state, rc.PROVINCIA, rc.ROMANS, rc.FORT) == 1
    for tribe, info in state['tribes'].items():
        restriction = rc.TRIBE_FACTION_RESTRICTION.get(tribe)
        assert not restriction or info['allied_faction'] in (None, restriction)
    return dict(result, permanent_provincia_fort=True, restricted_tribes_valid=True)


def position(seed):
    state = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed)
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    state['non_player_factions'] = {rc.ARVERNI, rc.AEDUI, rc.BELGAE}
    return state


def rally_case(existing_ally=False, full_phase=False):
    state = position(1)
    place_piece(state, rc.SUGAMBRI, rc.GERMANS, rc.WARBAND, 2)
    if existing_ally:
        assert _ally_tribe(state, rc.TRIBE_SUGAMBRI, rc.GERMANS)
    refresh_all_control(state)
    before = integrity(state)
    result = germans_phase(state) if full_phase else germans_phase_rally(state)
    rally = result['rally'] if full_phase else result
    placed = [tribe for region, tribe in rally['allies_placed'] if region == rc.SUGAMBRI]
    assert len(placed) == (1 if existing_ally else 2)
    assert rc.TRIBE_SUEBI_NORTH in placed
    assert rally['warbands_placed'][rc.SUGAMBRI] == 2
    return dict(existing_ally=existing_ally, full_phase=full_phase,
                expected_new_allies=1, actual_new_allies=len(placed),
                expected_sugambri_warbands_added=2 if existing_ally else 1,
                actual_sugambri_warbands_added=rally['warbands_placed'][rc.SUGAMBRI],
                result=result, before_integrity=before, after_integrity=integrity(state))


def ordinary_rally_control():
    state = position(1)
    place_piece(state, rc.SUGAMBRI, rc.GERMANS, rc.WARBAND, 2)
    refresh_all_control(state)
    before = integrity(state)
    ally = rally_in_region(state, rc.SUGAMBRI, rc.GERMANS, 'place_ally',
                           tribe=rc.TRIBE_SUEBI_NORTH)
    warbands = rally_in_region(state, rc.SUGAMBRI, rc.GERMANS, 'place_warbands')
    assert count_pieces(state, rc.SUGAMBRI, rc.GERMANS, rc.ALLY) == 1
    assert count_pieces(state, rc.SUGAMBRI, rc.GERMANS, rc.WARBAND) == 3
    return dict(ally=ally, warbands=warbands, before_integrity=before,
                after_integrity=integrity(state))


def double_move_case(seed=0, full_phase=False):
    state = position(seed)
    for region, count in ((rc.UBII, 5), (rc.SUGAMBRI, 3), (rc.TREVERI, 1), (rc.SEQUANI, 1)):
        place_piece(state, region, rc.GERMANS, rc.WARBAND, count)
    refresh_all_control(state)
    before = integrity(state)
    originals = {r: count_pieces(state, r, rc.GERMANS, rc.WARBAND) for r in state['spaces']}
    result = germans_phase(state) if full_phase else germans_phase_march(state)
    march = result['march'] if full_phase else result
    march_start = {r: count + (result['rally']['warbands_placed'].get(r, 0) if full_phase else 0)
                   for r, count in originals.items()}
    repeated = [{'origin': origin, 'destination': dest, 'sent': n,
                 'all_original_warbands': march_start[origin],
                 'minimum_arrivals_moved_again': n-march_start[origin]}
                for origin, dest, n in march['groups_moved'] if n > march_start[origin]]
    if seed == 0:
        assert repeated and repeated[0]['origin'] == rc.SUGAMBRI
        assert repeated[0]['sent'] == (11 if full_phase else 6)
        assert repeated[0]['minimum_arrivals_moved_again'] == (6 if full_phase else 3)
    if seed == 1:
        assert not repeated
    return dict(seed=seed, full_phase=full_phase,
                original_warbands_at_march_start=march_start,
                result=result, repeated_movement_proof=repeated,
                before_integrity=before, after_integrity=integrity(state))


def priority_case(seed=0, full_phase=False, human_roman=True, conquerable=True):
    state = position(seed)
    if not human_roman:
        state['non_player_factions'].add(rc.ROMANS)
    place_piece(state, rc.UBII, rc.GERMANS, rc.WARBAND, 5)
    place_piece(state, rc.TREVERI, rc.ROMANS, rc.AUXILIA, 1 if conquerable else 12)
    refresh_all_control(state)
    before = integrity(state)
    assert state['spaces'][rc.TREVERI]['control'] == rc.ROMAN_CONTROL
    result = germans_phase(state) if full_phase else germans_phase_march(state)
    march = result['march'] if full_phase else result
    destination = next(dest for origin, dest, n in march['groups_moved'] if origin == rc.UBII)
    if full_phase:
        assert seed == 1 and destination == rc.SEQUANI
    elif seed == 0:
        assert destination == rc.SUGAMBRI
    elif seed == 1 and human_roman and conquerable:
        assert destination == rc.TREVERI
    required = rc.TREVERI if human_roman and conquerable else None
    return dict(seed=seed, full_phase=full_phase, human_roman=human_roman,
                treveri_conquerable=conquerable,
                required_destination=required, actual_destination=destination,
                result=result, before_integrity=before, after_integrity=integrity(state))


def main():
    return {
        'WS6-01': {'defect': rally_case(), 'full_phase': rally_case(full_phase=True),
                   'one_remaining_tribe_control': rally_case(existing_ally=True),
                   'ordinary_rally_control': ordinary_rally_control()},
        'WS6-02': {'defect': double_move_case(), 'full_phase': double_move_case(full_phase=True),
                   'different_seed_control': double_move_case(seed=1)},
        'WS6-03': {'defect': priority_case(), 'full_phase': priority_case(seed=1, full_phase=True),
                   'nonplayer_control': priority_case(human_roman=False),
                   'cannot_conquer_control': priority_case(conquerable=False),
                   'different_seed_control': priority_case(seed=1)},
    }


if __name__ == '__main__':
    print(json.dumps(main(), indent=2, sort_keys=True))
