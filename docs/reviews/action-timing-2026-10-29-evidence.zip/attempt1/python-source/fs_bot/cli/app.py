"""Top-level CLI orchestrator.

Responsibilities:
  - Argument parsing (--scenario, --seed, --bots, --non-interactive,
    --save, --load, --replay)
  - Optional interactive setup wizard (scenario picker, faction-mode picker)
  - Build initial state via setup_scenario (with an explicit seed, so every
    game is replayable)
  - Mark non_player_factions for bot dispatch; install the CLI reactive
    agent (Retreat / Loss order / Agreements) for human seats
  - Run the game card by card with FULL rules execution
    (play_card(execute=True)), displaying each card's outcome
  - Autosave after every card when --save is given; --load resumes a
    snapshot exactly (rng position included); --replay re-runs a game from
    its logged human decisions and goes interactive when the log ends

Scenario isolation per CLAUDE.md:
  - In Ariovistus scenarios, Arverni is game-run (A6.2) and CANNOT be
    human or bot. Germans CAN be either.
  - In base scenarios, Germans are game-run (Sec.6.2) and CANNOT be human
    or bot. Arverni CAN be either.
"""

import argparse
import copy
import random as _random
import sys
from collections import deque

from fs_bot.rules_consts import (
    ROMANS, ARVERNI, AEDUI, BELGAE, GERMANS,
    FACTIONS,
    BASE_SCENARIOS, ARIOVISTUS_SCENARIOS, ALL_SCENARIOS,
)
from fs_bot.state.setup import setup_scenario
from fs_bot.engine.game_engine import (
    get_sop_factions, start_game, play_card, ActionRejected,
)
from fs_bot.state import serialize
from fs_bot.cli.reactive import make_cli_reactive
from fs_bot.cli.dispatcher import make_decision_func, maybe_pause
from fs_bot.cli.display import (
    format_state_summary, format_region_table, format_tribes_table,
    format_victory_state, format_action, format_card,
)
from fs_bot.cli.menus import prompt_choice


# ============================================================================
# FACTION/SCENARIO ELIGIBILITY
# ============================================================================

def get_assignable_factions(scenario):
    """Return the factions that may be assigned human/bot in a scenario.

    Excludes game-run factions:
      - Base scenarios: Germans excluded (Sec.6.2 game-run)
      - Ariovistus scenarios: Arverni excluded (A6.2 game-run)

    Returns:
        Tuple of faction constants in SoP order.
    """
    if scenario in ARIOVISTUS_SCENARIOS:
        # Romans, Germans, Aedui, Belgae -- A2.0
        return (ROMANS, GERMANS, AEDUI, BELGAE)
    # Base: Romans, Arverni, Aedui, Belgae -- Sec.2.3
    return (ROMANS, ARVERNI, AEDUI, BELGAE)


# ============================================================================
# SETUP WIZARD
# ============================================================================

def setup_wizard(stdin, stdout, *, preset_scenario=None,
                 preset_faction_modes=None):
    """Interactive scenario and faction-mode picker.

    If preset_scenario is provided, skip the scenario question. If
    preset_faction_modes is provided, skip the faction-mode questions
    (but still validate them against the chosen scenario).

    Returns:
        (scenario, faction_modes) tuple. faction_modes is a dict
        {faction: "human"|"bot"} containing exactly the assignable
        factions for the chosen scenario.
    """
    # Scenario
    if preset_scenario is not None:
        if preset_scenario not in ALL_SCENARIOS:
            raise ValueError(f"Unknown scenario: {preset_scenario!r}")
        scenario = preset_scenario
    else:
        choices = [(s, s) for s in ALL_SCENARIOS]
        scenario = prompt_choice(
            stdin, stdout, "Select scenario:", choices
        )

    # Faction modes
    assignable = get_assignable_factions(scenario)
    if preset_faction_modes is not None:
        faction_modes = {}
        for f in assignable:
            mode = preset_faction_modes.get(f, "bot")
            if mode not in ("human", "bot"):
                raise ValueError(f"Bad mode for {f}: {mode!r}")
            faction_modes[f] = mode
    else:
        faction_modes = {}
        mode_choices = [("Human", "human"), ("Bot", "bot")]
        for f in assignable:
            mode = prompt_choice(
                stdin, stdout, f"Mode for {f}:", mode_choices
            )
            faction_modes[f] = mode

    return scenario, faction_modes


# ============================================================================
# CARD RESULT DISPLAY
# ============================================================================

def display_card_result(card_result, stdout, scenario=None, card_edition=None):
    """Print what happened on a card.

    Reports: card id, turn type (event/winter), passes, actions taken,
    Frost flag, Arverni Phase (if any), Winter result, game-over.
    """
    stdout.write("\n")
    card = card_result.get("card")
    stdout.write(f"=== Card {card} resolved ===\n")
    if card_result.get("type") == "winter":
        wr = card_result.get("winter_result", {})
        is_final = wr.get("is_final", False)
        stdout.write(
            f"  Winter round ({'FINAL' if is_final else 'normal'})\n"
        )
        phases = wr.get("winter_result", {}).get("phases", {})
        victory = phases.get("victory", {}) if isinstance(phases, dict) else {}
        if victory.get("game_over"):
            stdout.write(f"  Victory phase: GAME OVER -- "
                         f"winner {victory.get('winner')}\n")
    else:
        turn = card_result.get("turn_result", {})
        if turn.get("frost"):
            stdout.write("  Frost applies (Sec.2.3.8)\n")
        if turn.get("arverni_phase"):
            stdout.write("  Arverni Phase ran (A2.3.9)\n")
        actions = turn.get("actions_taken", {})
        passes = turn.get("passes", [])
        for f, info in actions.items():
            action = info.get("action", "?")
            bot_act = info.get("bot_action") or info.get("player_action")
            if bot_act:
                stdout.write(
                    f"  {f}: {action}  | {format_action(bot_act)}\n"
                )
            else:
                stdout.write(f"  {f}: {action}\n")
            ex = info.get("execution")
            if isinstance(ex, dict):
                # An Event play names the side used and shows that text.
                if "shaded" in ex and ex.get("card_id") is not None:
                    side = "shaded" if ex.get("shaded") else "unshaded"
                    stdout.write(f"      played the {side.upper()} text of "
                                 f"card {ex['card_id']}\n")
                    from fs_bot.cards.card_text import format_card_text
                    txt = format_card_text(ex["card_id"], indent="      | ",
                                           scenario=scenario,
                                           card_edition=card_edition)
                    if txt:
                        stdout.write(txt + "\n")
                if not ex.get("executed"):
                    why = ex.get("reason") or "no effect"
                    stdout.write(f"      (did not execute: {why})\n")
                elif ex.get("errors"):
                    stdout.write(f"      ({len(ex['errors'])} sub-action(s) "
                                 f"had no effect)\n")
        if not actions:
            stdout.write(f"  (all factions passed)  passes={passes}\n")
    if card_result.get("game_over"):
        stdout.write("  *** GAME OVER ***\n")
    stdout.flush()


# ============================================================================
# ARG PARSING
# ============================================================================

def _parse_args(argv):
    p = argparse.ArgumentParser(
        prog="fs_bot",
        description=(
            "Falling Sky bot engine -- interactive CLI with full rules "
            "execution, save/resume, and replay."
        ),
    )
    p.add_argument(
        "--scenario",
        choices=list(ALL_SCENARIOS),
        default=None,
        help="Scenario to play. If omitted, the setup wizard asks.",
    )
    p.add_argument(
        "--seed", type=int, default=None,
        help="RNG seed for deterministic replay.",
    )
    from fs_bot.cards.edition import CARD_EDITIONS
    p.add_argument(
        "--card-edition", choices=CARD_EDITIONS, default=None,
        help=("Versions of cards 11/30/39/44/54: original or second-edition. "
              "Default legacy preserves scenario-dependent selection. "
              "Saved games retain their profile."),
    )
    p.add_argument(
        "--bots", default=None,
        help=(
            "Comma-separated faction names to be bot-controlled "
            "(e.g. Romans,Aedui,Belgae). Others become human. "
            "If omitted, the wizard asks per faction."
        ),
    )
    p.add_argument(
        "--diviciacus-option", action=argparse.BooleanOptionalAction,
        default=None,
        help=("Use the optional Diviciacus Leader and replacement card 38 "
              "in an original scenario. Saved games retain this choice."),
    )
    p.add_argument(
        "--save", default=None, metavar="FILE",
        help="Autosave the game to FILE after every card.",
    )
    p.add_argument(
        "--load", default=None, metavar="FILE",
        help="Resume the exact snapshot in FILE (rng position included).",
    )
    p.add_argument(
        "--replay", default=None, metavar="FILE",
        help=(
            "Re-run the game in FILE from its logged human decisions "
            "(rebuilt from scenario+seed); goes interactive when the "
            "log ends."
        ),
    )
    p.add_argument(
        "--non-interactive", action="store_true",
        help=(
            "Bot-only mode for testing: all assignable factions are bots, "
            "no setup wizard prompts, no inter-card pause."
        ),
    )
    return p.parse_args(argv)


def _parse_bots_arg(bots_arg, assignable):
    """Parse the comma-separated --bots argument into a faction_modes dict."""
    modes = {f: "human" for f in assignable}
    if bots_arg is None:
        return None
    bot_names = [s.strip() for s in bots_arg.split(",") if s.strip()]
    valid_names = {f.lower(): f for f in assignable}
    chosen_bots = set()
    for n in bot_names:
        key = n.lower()
        if key not in valid_names:
            raise ValueError(
                f"Unknown or non-assignable faction in --bots: {n!r}. "
                f"Assignable: {list(assignable)}"
            )
        chosen_bots.add(valid_names[key])
    for f in assignable:
        modes[f] = "bot" if f in chosen_bots else "human"
    return modes


# ============================================================================
# MAIN
# ============================================================================

def main(argv=None, stdin=None, stdout=None):
    """Run the CLI.

    Args:
        argv: Optional argv list (None means sys.argv[1:]).
        stdin/stdout: Streams (default sys.stdin/sys.stdout).

    Returns:
        Exit code (int).
    """
    if stdin is None:
        stdin = sys.stdin
    if stdout is None:
        stdout = sys.stdout

    args = _parse_args(argv)
    if args.load and args.replay:
        stdout.write("--load and --replay are mutually exclusive.\n")
        return 2

    log = []
    meta = {}
    if args.load or args.replay:
        # Scenario / seed / seats come from the save file.
        save_path = args.load or args.replay
        try:
            state, meta, log = serialize.load_game(save_path, validate=True)
        except (serialize.SaveFileError, OSError) as exc:
            stdout.write(f"Cannot load game from {save_path}: {exc}\n")
            return 2
        card_edition = state.get("card_edition", "legacy")
        diviciacus_option = state.get("diviciacus_option", False)
        if (args.diviciacus_option is not None
                and args.diviciacus_option != diviciacus_option):
            stdout.write("Cannot change --diviciacus-option when loading or "
                         "replaying a game; start a new game to change it.\n")
            return 2
        if args.card_edition is not None and args.card_edition != card_edition:
            stdout.write("Cannot change --card-edition when loading or replaying "
                         "a game; start a new game to choose a different profile.\n")
            return 2
        scenario = meta.get("scenario") or state.get("scenario")
        seed = meta.get("seed")
        faction_modes = dict(meta.get("faction_modes") or {})
        if not faction_modes:
            assignable = get_assignable_factions(scenario)
            faction_modes = {
                f: ("bot" if f in state.get("non_player_factions", set())
                    else "human") for f in assignable}
        if args.replay:
            if seed is None:
                stdout.write("Save has no seed; cannot --replay.\n")
                return 2
            faction_modes = dict(meta.get("initial_faction_modes")
                                 or faction_modes)
            state = setup_scenario(scenario, seed=seed,
                                   card_edition=card_edition,
                                   diviciacus_option=diviciacus_option)
        elif state.get("interlude_completed") and GERMANS in faction_modes:
            # Older snapshots saved the original seats after the Interlude.
            faction_modes[ARVERNI] = faction_modes.pop(GERMANS)
    else:
        # Determine faction_modes -- preset from --bots if scenario known
        preset_modes = None
        if args.scenario is not None and args.bots is not None:
            assignable = get_assignable_factions(args.scenario)
            preset_modes = _parse_bots_arg(args.bots, assignable)
        elif args.non_interactive:
            # --non-interactive without --bots: scenario must be set too,
            # else we fall through to the wizard which will fail on stdin.
            if args.scenario is not None:
                assignable = get_assignable_factions(args.scenario)
                preset_modes = {f: "bot" for f in assignable}

        # Either run the wizard or use preset
        if args.scenario is not None and preset_modes is not None:
            scenario = args.scenario
            faction_modes = preset_modes
        else:
            scenario, faction_modes = setup_wizard(
                stdin, stdout,
                preset_scenario=args.scenario,
                preset_faction_modes=preset_modes,
            )

        # Explicit seed always, so every game is saveable/replayable.
        seed = (args.seed if args.seed is not None
                else _random.randrange(2 ** 31))
        if args.diviciacus_option and scenario not in BASE_SCENARIOS:
            stdout.write("--diviciacus-option applies only to original scenarios.\n")
            return 2
        state = setup_scenario(scenario, seed=seed,
                               card_edition=args.card_edition or "legacy",
                               diviciacus_option=bool(args.diviciacus_option))

    initial_modes = dict(meta.get("initial_faction_modes") or faction_modes)
    if state.get("interlude_completed") and GERMANS not in initial_modes:
        initial_modes[GERMANS] = initial_modes.pop(ARVERNI, "bot")
    meta.update({"scenario": scenario, "seed": seed,
                 "card_edition": state.get("card_edition", "legacy"),
                 "diviciacus_option": state.get("diviciacus_option", False),
                 "initial_faction_modes": initial_modes,
                 "faction_modes": dict(faction_modes)})
    # Non-player factions = bots (the engine uses this for tiebreak;
    # bot_dispatch requires it).
    state["non_player_factions"] = {
        f for f, m in faction_modes.items() if m == "bot"
    }
    humans = [f for f, m in faction_modes.items() if m == "human"]

    # Replay queues: human SoP decisions and reactive responses recorded
    # in the log. Determinism (same scenario+seed+decisions) makes the
    # request sequences line up; any desync abandons replay and goes
    # interactive.
    replay_decisions = deque(
        e for e in log if "reactive" not in e) if args.replay else deque()
    replay_reactive = deque(
        e for e in log if "reactive" in e) if args.replay else deque()
    live_log = list(log)
    replay_attempt = {"entry": None}
    timing_replay = {"legacy": False}

    # Decision callback (bots via flowcharts, humans via menus), wrapped to
    # feed/record the replay log.
    pause = not args.non_interactive
    base_decision = make_decision_func(
        faction_modes, stdin=stdin, stdout=stdout, pause=pause,
    )

    from fs_bot.cli.display import HumanTurnDisplay, format_board
    saved_snapshots = (serialize.decode(meta.get("human_snapshots", {}))
                       if args.load else {})
    view = HumanTurnDisplay(stdout, snapshots=saved_snapshots)

    def decision(state_, faction, options, position):
        if faction_modes.get(faction) == "human":
            view.before_decision(state_, faction, show_context=False)
        if faction_modes.get(faction) == "human" and replay_decisions:
            e = replay_decisions[0]
            if (e.get("faction") == faction
                    and e.get("card") == state_.get("current_card")):
                replay_decisions.popleft()
                replay_attempt["entry"] = e
                timing_replay["legacy"] = not e.get("action_windows_version")
                stdout.write(f"[replay] {faction}: {e.get('action')}\n")
                d = {"action": e.get("action")}
                if e.get("player_action") is not None:
                    d["player_action"] = e["player_action"]
                return d
            stdout.write("[replay] log desynced from game -- going "
                         "interactive\n")
            replay_decisions.clear()
            replay_reactive.clear()
        d = base_decision(state_, faction, options, position)
        if faction_modes.get(faction) == "human":
            entry = {"card": state_.get("current_card"), "faction": faction,
                     "position": position, "action": d.get("action"),
                     "action_windows_version": 1}
            if d.get("player_action") is not None:
                entry["player_action"] = d["player_action"]
            live_log.append(entry)
        return d

    # Reactive agent (Retreat / Loss order / Agreements) for human seats,
    # wrapped the same way.
    cli_agent = make_cli_reactive(humans, stdin, stdout)
    if humans:

        def agent(state_, faction, request):
            # Bot previews may deepcopy the board and retain this callable.
            # They cannot consume human input or replay entries belonging to
            # the live game, or alter its decision display/history.
            if state_ is not state:
                return None
            if request.get('kind') in ('voluntary_removal', 'spring_leader', 'battle_elite') and 'window' in request:
                next_record = replay_reactive[0] if replay_reactive else None
                old_next = (next_record is not None
                            and next_record.get('card') == state_.get('current_card')
                            and not next_record.get('action_windows_version'))
                if timing_replay['legacy'] or old_next:
                    return None
            if faction in humans:
                view.before_decision(state_, faction)
            if faction in humans and replay_reactive:
                e = replay_reactive[0]
                if (e.get("faction") == faction
                        and e.get("reactive") == request.get("kind")
                        and e.get('window') == request.get('window')):
                    replay_reactive.popleft()
                    timing_replay['legacy'] = not e.get('action_windows_version')
                    return serialize.decode(e.get("response"))
                replay_reactive.clear()
                replay_decisions.clear()
                timing_replay['legacy'] = False
            resp = cli_agent(state_, faction, request)
            if faction in humans:
                # Explicit defaults are decisions too: omitting None desyncs
                # replay at Quarters before the next recorded agreement.
                live_log.append({"reactive": request.get("kind"),
                                 "faction": faction,
                                 "card": state_.get("current_card"),
                                 "action_windows_version": 1,
                                 **({'window': copy.deepcopy(request['window'])}
                                    if 'window' in request else {}),
                                 "response": serialize.encode(resp)})
            return resp

        agent.supports_action_windows = True
        state["decision_agent"] = agent

    def transaction_checkpoint():
        replay_attempt["entry"] = None
        timing_replay['legacy'] = False
        return (len(live_log), list(replay_decisions), list(replay_reactive),
                copy.deepcopy(view.snapshots))

    def transaction_complete():
        recorded = replay_attempt["entry"]
        if recorded and recorded.get("supply_reconsideration"):
            raise RuntimeError("Replay expected a Supply-refused attempt, but it completed.")

    def transaction_restore(checkpoint):
        log_length, decisions, reactions, snapshots = checkpoint
        error = sys.exc_info()[1]
        receipt = (error.result.get("supply_reconsideration")
                   if isinstance(error, ActionRejected) else None)
        recorded = replay_attempt["entry"]
        if isinstance(error, ActionRejected) and recorded and (
                recorded.get("supply_reconsideration") is not None or receipt is not None):
            if recorded.get("supply_reconsideration") != serialize.encode(receipt):
                raise RuntimeError("Replay Supply refusal differs from its recorded result.")
        if isinstance(receipt, dict):
            # The resolved NPC die survives lawful reconsideration. Keep the
            # attempted action and consumed reactions so --replay can produce
            # that same refusal before proceeding to the corrected action.
            if recorded is None:
                attempted = next((entry for entry in live_log[log_length:]
                                  if "reactive" not in entry), None)
                if attempted is None:
                    raise RuntimeError("Supply reconsideration has no turn transcript.")
                attempted["supply_reconsideration"] = serialize.encode(receipt)
            view.snapshots.clear()
            view.snapshots.update(snapshots)
            return
        del live_log[log_length:]
        replay_decisions.clear()
        replay_decisions.extend(decisions)
        replay_reactive.clear()
        replay_reactive.extend(reactions)
        view.snapshots.clear()
        view.snapshots.update(snapshots)

    decision.transaction_checkpoint = transaction_checkpoint
    decision.transaction_restore = transaction_restore
    decision.transaction_complete = transaction_complete

    def decision_rejected(state_, faction, result):
        reason = result.get("reason") or "the Command had no legal effect"
        stdout.write(f"\n{faction}: {reason}. Your turn is still pending; "
                     "choose again.\n")
        for error in result.get("errors") or []:
            stdout.write(f"  {error}\n")
        stdout.flush()

    decision.decision_rejected = decision_rejected

    def save_snapshot():
        meta["faction_modes"] = dict(faction_modes)
        meta["human_snapshots"] = serialize.encode(view.snapshots)
        serialize.save_game(state, args.save, meta=meta, log=live_log)

    # 'b' at any prompt reprints the live board.
    from fs_bot.cli.menus import set_board_hook
    set_board_hook(lambda: stdout.write("\n" + format_board(state) + "\n"))

    # Run the game card by card with full rules execution, displaying and
    # autosaving after every card.
    resumed = bool(args.load) and (state.get("current_card") is not None
                                   or state.get("played_cards"))
    try:
        if not resumed:
            start_game(state)
        view.remember(state, humans)
        stdout.write(format_board(state) + "\n")
        stdout.flush()
        results = []
        while state["current_card"] is not None:
            card_scenario = state["scenario"]
            card_result = play_card(state, decision, execute=True)
            results.append(card_result)
            # Gallic War Interlude seat swap (A2.1): the German player
            # takes on the Arverni role for the second half.
            if (state.get("interlude_completed")
                    and GERMANS in faction_modes):
                faction_modes[ARVERNI] = faction_modes.pop(GERMANS)
                if GERMANS in humans:
                    humans.remove(GERMANS)
                    humans.append(ARVERNI)
                    if GERMANS in view.snapshots:
                        view.snapshots[ARVERNI] = view.snapshots.pop(GERMANS)
                cli_agent = make_cli_reactive(humans, stdin, stdout)
                meta["faction_modes"] = dict(faction_modes)
                stdout.write("\n*** Interlude: the German player now "
                             "plays the Arverni (A2.1). ***\n")
            display_card_result(card_result, stdout, scenario=card_scenario,
                                card_edition=state.get("card_edition"))
            if args.save:
                save_snapshot()
            if card_result["game_over"]:
                break
            maybe_pause(base_decision)
    except (KeyboardInterrupt, EOFError):
        if args.save:
            save_snapshot()
            stdout.write(f"\nInterrupted -- game saved to {args.save} "
                         f"(resume with --load).\n")
        else:
            stdout.write("\nInterrupted.\n")
        return 0
    except Exception as exc:
        if args.save:
            save_snapshot()
        stdout.write(f"\nGame stopped with exception: {type(exc).__name__}: "
                     f"{exc}\n")
        return 1
    finally:
        set_board_hook(None)

    stdout.write("\n" + format_state_summary(state) + "\n")
    stdout.write(format_victory_state(state) + "\n")
    stdout.write(f"\nGame ended. Cards played: "
                 f"{len(state['played_cards'])}.  Winters: "
                 f"{state['winter_count']}.\n")
    stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
