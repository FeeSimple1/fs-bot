"""Replay changed winners and record the first differing Event action."""
from concurrent.futures import ProcessPoolExecutor
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import sys
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, find_leader, get_available, get_leader_in_region
from fs_bot.cli.dispatcher import make_decision_func
from fs_bot.engine import execute as engine
from fs_bot.engine.game_engine import get_sop_factions, play_card, start_game
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.tools.validation_metadata import source_identity

TRACKED_CARDS = (56, 57, 'A35', 'A60')


def digest(value):
    return sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def board_digest(board):
    return digest({key: value for key, value in board.items() if key != 'decision_agent'})


def material(board, card):
    if card == 56:
        location = find_leader(board, rc.BELGAE)
        return {'belgic_leader_region': location, 'belgic_leader': (
            get_leader_in_region(board, location, rc.BELGAE) if location else None)}
    if card == 'A35':
        return {
            'roman_auxilia_at_treveri': count_pieces(board, rc.TREVERI, rc.ROMANS, rc.AUXILIA),
            'aedui_warbands_at_treveri': count_pieces(board, rc.TREVERI, rc.AEDUI, rc.WARBAND),
            'treveri_ally': board['tribes'][rc.TRIBE_TREVERI]['allied_faction'],
            'available_roman_auxilia': get_available(board, rc.ROMANS, rc.AUXILIA),
            'available_german_warbands': get_available(board, rc.GERMANS, rc.WARBAND),
            'available_german_settlements': get_available(board, rc.GERMANS, rc.SETTLEMENT),
        }
    region = rc.BRITANNIA if card == 57 else rc.ATREBATES
    from fs_bot.map.map_data import get_tribes_in_region_for_state
    return {'region': region,
            'pieces': encode(board['spaces'][region]['pieces']),
            'tribes': {tribe: dict(board['tribes'][tribe]) for tribe in
                       get_tribes_in_region_for_state(board, region) if tribe in board['tribes']}}


def trace(row):
    scenario, seed, edition = (row[key] for key in ('scenario', 'seed', 'card_edition'))
    state = setup_scenario(scenario, seed=seed, card_edition=edition)
    state['non_player_factions'] = set(get_sop_factions(state))
    bot = make_decision_func({}, stdin=StringIO(), stdout=StringIO(), pause=False)
    cards, decisions, event_actions, parameters = [], [], [], []
    execute_event, derive_params = engine._execute_event, engine._derive_event_params

    def decide(board, faction, options, position):
        before = board_digest(board)
        choice = bot(board, faction, options, position)
        decisions.append(dict(faction=faction, before=before, choice=encode(choice),
                              rng_after=digest(board['rng'].getstate())))
        return choice

    def derive(board, faction, card_id, shaded):
        params = derive_params(board, faction, card_id, shaded)
        if card_id in TRACKED_CARDS:
            parameters.append(dict(faction=faction, shaded=shaded, params=encode(params)))
        return params

    def event(board, faction, action, *, human=False):
        card = (action.get('details') or {}).get('card_id', board['current_card'])
        if card not in TRACKED_CARDS:
            return execute_event(board, faction, action, human=human)
        before = board_digest(board)
        pieces = material(board, card)
        result = execute_event(board, faction, action, human=human)
        event_actions.append(dict(faction=faction, before=before, after=board_digest(board),
                                  result=encode(result), material_before=pieces,
                                  material_after=material(board, card)))
        return result

    with (patch.object(engine, '_derive_event_params', derive),
          patch.object(engine, '_execute_event', event), redirect_stdout(StringIO())):
        start_game(state)
        for draw in range(1, 201):
            decisions.clear()
            event_actions.clear()
            parameters.clear()
            before = board_digest(state)
            result = play_card(state, decide, execute=True)
            after = board_digest(state)
            cards.append(dict(draw=draw, card=result['card'], before=before, after=after,
                              decisions=list(decisions), events=list(event_actions),
                              parameters=list(parameters)))
            if result['game_over']:
                break
    assert (result['winner'], draw, after) == (row['winner'], row['cards'], row['final_state_sha256'])
    return dict(scenario=scenario, seed=seed, card_edition=edition, winner=result['winner'],
                final_board=after, cards=cards)


def main(source_rows, output):
    source = source_identity()
    rows = json.loads(Path(source_rows).read_text())
    assert rows and all(row['source_sha256'] == source['source_sha256'] for row in rows)
    with ProcessPoolExecutor(max_workers=2) as pool:
        games = list(pool.map(trace, rows))
    Path(output).write_text(json.dumps(dict(source=source, games=games), indent=2) + '\n')
    print(f'{len(games)} traces match the audited winners, card counts and final boards')


if __name__ == '__main__':
    main(*sys.argv[1:])
