"""Read-only source guards for the 29 October action-timing validation batch."""
from __future__ import annotations

from datetime import datetime, timezone
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'fs-bot'
PYTHON = ROOT.parent / 'fs-test-venv/bin/python'
SCENARIOS = ('Pax Gallica?', 'Reconquest of Gaul', 'The Great Revolt',
             'Ariovistus', 'The Gallic War')
ORIGINAL_BASELINE_SHA = '815b6f363134159b4cf5772abd4dc76a5e8e0be8fd0bb852dc571390504814f5'
BASELINE_SHA = ORIGINAL_BASELINE_SHA  # Historical identity, never the active review result.
PARENT = '5ee485e43132e9080a083efece79c66af80afef8'
MATRIX = {'bot_games': 150, 'mixed_unique_cases': 20,
          'mixed_executions_with_replay': 80, 'census_unique_cases': 25,
          'census_executions': 50, 'hash_seeds': [0, 7]}


def execution_environment(hash_seed):
    """Do not inherit hidden pytest selections/plugins or alternate imports."""
    return {'PYTHONHASHSEED': str(hash_seed), 'PYTHONUNBUFFERED': '1',
            'PYTHONNOUSERSITE': '1', 'PYTHONPATH': str(ROOT),
            'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1', 'PYTEST_ADDOPTS': '',
            'PYTEST_PLUGINS': ''}


def pytest_argv(run, *, workers=None, collect=False):
    argv = [str(PYTHON), '-m', 'pytest', '-q', '-o', 'addopts=']
    if collect:
        argv.extend(['--collect-only', '-p', 'pytest_inventory',
                     '--validation-inventory=' + str(run / 'test-collection.json')])
    else:
        if type(workers) is not int or workers < 1:
            raise ValueError('positive explicit pytest worker count required')
        if workers > 1:
            argv.extend(['-p', 'xdist.plugin', '-n', str(workers)])
        argv.append('--junitxml=' + str(run / 'tests.xml'))
    return argv


def verify_test_inventory(run, freeze, *, include_results=True, prefix='tests'):
    """Match every collected node, including parametrized IDs, to JUnit."""
    raw = (run / 'test-collection.json').read_bytes()
    expected = freeze['pytest_collection']
    if sha(raw) != expected['sha256']:
        raise ValueError('frozen test collection bytes changed')
    inventory = json.loads(raw)
    cases = inventory['cases']
    if (len(cases) != expected['count'] or len(cases) < 5777
            or len({case['nodeid'] for case in cases}) != len(cases)
            or inventory['pytest_version'] != expected['pytest_version']):
        raise ValueError('test collection identity/count differs from freeze')
    collection = read(run / 'collection.status.json')
    if not (run / 'collection.log').is_file() or (run / 'collection.log').stat().st_size == 0:
        raise ValueError('collection raw log is missing or empty')
    if (collection.get('argv') != pytest_argv(run, collect=True)
            or collection.get('environment') != execution_environment(0)
            or collection.get('cwd') != str(REPO)
            or collection.get('exit_code') != 0 or collection.get('runner_exit_code') != 0
            or collection.get('source_changed') is not False
            or collection.get('source_sha256_before') != freeze['source_sha256']
            or collection.get('source_sha256_after') != freeze['source_sha256']):
        raise ValueError('collection command/provenance did not pass')
    if not include_results:
        return {'tests': len(cases), 'pytest_version': inventory['pytest_version']}
    status = read(run / (prefix + '.status.json'))
    if not (run / (prefix + '.log')).is_file() or (run / (prefix + '.log')).stat().st_size == 0:
        raise ValueError('test raw log is missing or empty')
    if prefix != 'tests':
        raise ValueError('accepted suite must be the original frozen tests invocation')
    if (status.get('argv') != pytest_argv(run, workers=status.get('pytest_workers'))
            or status.get('environment') != execution_environment(0)
            or status.get('cwd') != str(REPO)):
        raise ValueError('test command/environment differs from exact unfiltered suite')
    tree = ET.parse(run / (prefix + '.xml')).getroot()
    expected_names = Counter((case['classname'], case['name']) for case in cases)
    actual_names = Counter((case.get('classname'), case.get('name'))
                           for case in tree.findall('.//testcase'))
    if actual_names != expected_names:
        raise ValueError('JUnit cases differ from exact frozen collection')
    suites = tree.findall('.//testsuite')
    totals = {key: sum(int(s.attrib[key]) for s in suites)
              for key in ('tests', 'errors', 'failures', 'skipped')}
    if totals['tests'] != len(cases) or any(totals[key] for key in ('errors', 'failures', 'skipped')):
        raise ValueError('full exact suite has failures, errors, skips or count mismatch')
    if any(tree.findall('.//testcase/' + tag) for tag in ('failure', 'error', 'skipped')):
        raise ValueError('JUnit contains an unsuccessful test case')
    return dict(totals, pytest_version=inventory['pytest_version'], exact_collection=True)


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_text())


def write_json(path, data, *, exclusive=False):
    with path.open('x' if exclusive else 'w') as stream:
        json.dump(data, stream, indent=2, sort_keys=True)
        stream.write('\n')


REVIEW_IDENTITIES = ('source_sha256', 'original_baseline_sha256',
                     'active_baseline_sha256', 'diagnostic_games_sha256',
                     'causal_review_sha256')
REVIEW_FILES = {'candidate_baseline': 'candidate-baseline.json',
                'diagnostic_games': 'diagnostic-games.jsonl',
                'causal_review': 'causal-review.json',
                'root_approval': 'root-approval.json',
                'independent_approval': 'independent-approval.json'}


def validate_review_bytes(files, expected_sha):
    """A refresh requires two explicit reviews of exact causal evidence."""
    manifest = json.loads(files['review.json'])
    if (manifest.get('mode') != 'reviewed-correction'
            or manifest.get('source_sha256') != expected_sha
            or manifest.get('original_baseline_sha256') != ORIGINAL_BASELINE_SHA):
        raise ValueError('baseline review has wrong mode, source or original baseline')
    identity = {key: manifest[key] for key in REVIEW_IDENTITIES}
    for key, filename in (('active_baseline_sha256', 'candidate-baseline.json'),
                          ('diagnostic_games_sha256', 'diagnostic-games.jsonl'),
                          ('causal_review_sha256', 'causal-review.json')):
        if sha(files[filename]) != identity[key]:
            raise ValueError('reviewed evidence hash differs: ' + filename)
    for role in ('root', 'independent'):
        approval = json.loads(files[role + '-approval.json'])
        if (approval.get('passed') is not True or approval.get('role') != role
                or any(approval.get(key) != value for key, value in identity.items())):
            raise ValueError(role + ' has not approved this exact source/baseline/causal evidence')
    if manifest['root_approval'] == manifest['independent_approval']:
        raise ValueError('root and independent approvals must be distinct documents')
    rows = [json.loads(line) for line in files['diagnostic-games.jsonl'].splitlines()]
    expected = {(scenario, seed, 'legacy') for scenario in SCENARIOS for seed in range(1, 21)}
    actual = [(r['scenario'], r['seed'], r['card_edition']) for r in rows]
    if len(actual) != 100 or len(set(actual)) != 100 or set(actual) != expected:
        raise ValueError('reviewed diagnostic is not the exact legacy100')
    for row in rows:
        if (row.get('source_sha256') != expected_sha
                or not all(row.get(key) is True for key in ('completed', 'game_completed', 'audit_completed'))
                or row.get('error') or row.get('errors') != [] or row.get('integrity_findings') != []):
            raise ValueError('reviewed diagnostic contains unaccepted source/outcome')
    candidate = json.loads(files['candidate-baseline.json'])
    records = {f"{row['scenario']}|{row['seed']}": {key: row[key] for key in ('winner', 'cards')}
               for row in rows}
    if candidate.get('games') != records:
        raise ValueError('candidate baseline differs from the reviewed diagnostic100')
    return identity


def load_baseline_review(path, expected_sha):
    path = Path(path).resolve()
    manifest = read(path)
    sources = {'review.json': str(path)}
    for key, filename in REVIEW_FILES.items():
        source = Path(manifest[key])
        sources[filename] = str((source if source.is_absolute() else path.parent / source).resolve())
    if sources['root-approval.json'] == sources['independent-approval.json']:
        raise ValueError('root and independent approvals resolve to the same file')
    files = {name: Path(source).read_bytes() for name, source in sources.items()}
    identity = validate_review_bytes(files, expected_sha)
    return dict(identity, files={name: {'path': sources[name], 'sha256': sha(raw)}
                                 for name, raw in files.items()})


def check_baseline_policy(freeze, expected_sha, *, run=None):
    """Validate either unchanged-original policy or a reviewed replacement."""
    original = freeze.get('original_baseline_sha256', ORIGINAL_BASELINE_SHA)
    policy = freeze.get('balance_policy', 'original')
    if original != ORIGINAL_BASELINE_SHA or freeze['balance_band_exact'] != '3/20':
        raise ValueError('original baseline identity or balance tolerance changed')
    if policy == 'original':
        if (freeze['balance_baseline_sha256'] != ORIGINAL_BASELINE_SHA
                or freeze['balance_baseline_updated'] is not False
                or freeze.get('baseline_review') is not None):
            raise ValueError('original policy does not preserve original baseline')
        return None
    if policy != 'reviewed-correction' or freeze['balance_baseline_updated'] is not True:
        raise ValueError('unknown or unmarked baseline correction policy')
    review = freeze['baseline_review']
    files = {}
    for name, record in review['files'].items():
        path = run / 'baseline-review' / name if run is not None else Path(record['path'])
        files[name] = path.read_bytes()
        if sha(files[name]) != record['sha256']:
            raise ValueError('baseline review evidence changed: ' + name)
    identity = validate_review_bytes(files, expected_sha)
    if (any(review.get(key) != value for key, value in identity.items())
            or freeze['balance_baseline_sha256'] != identity['active_baseline_sha256']):
        raise ValueError('frozen baseline policy differs from its explicit approvals')
    return identity


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def source_files():
    return {str(p.relative_to(REPO)): sha(p.read_bytes())
            for p in sorted((REPO / 'fs_bot').rglob('*.py'))}


def digest():
    value = hashlib.sha256()
    for path in sorted((REPO / 'fs_bot').rglob('*.py')):
        value.update(str(path.relative_to(REPO)).encode() + b'\0' + path.read_bytes())
    return value.hexdigest()


def fixture_files():
    return {str(p.relative_to(REPO)): sha(p.read_bytes())
            for p in sorted((REPO / 'fs_bot/tests/fixtures').rglob('*'))
            if p.is_file() and p.suffix not in ('.py', '.pyc', '.pyo')
            and '__pycache__' not in p.parts}


def runtime_files():
    paths = [p for pattern in ('pyproject.toml', 'pytest.ini', 'setup.cfg',
                              'setup.py', 'tox.ini', 'requirements*.txt')
             for p in REPO.glob(pattern) if p.is_file()]
    return {str(p.relative_to(REPO)): sha(p.read_bytes()) for p in sorted(set(paths))}


def protected_files():
    paths = [REPO / 'fs_bot/rules_consts.py']
    paths.extend(p for p in (REPO / 'Reference Documents').rglob('*') if p.is_file())
    return {str(p.relative_to(REPO)): sha(p.read_bytes()) for p in sorted(paths)}


def identity():
    return {'source_sha256': digest(), 'commit': git('rev-parse', 'HEAD').decode().strip(),
            'dirty': bool(git('status', '--porcelain', '--untracked-files=no').strip()
                          or any(p.endswith('.py') for p in git(
                              'ls-files', '--others', '--exclude-standard', '-z',
                              '--', 'fs_bot').decode().split('\0')))}


def validate_current(expected_sha, freeze=None, baseline_review=None):
    """Raise on any source/data/protected drift; no baseline refresh escape."""
    start = read(ROOT / 'starting-source.json')
    current = identity()
    if current['commit'] != PARENT or start['commit'] != PARENT:
        raise ValueError('HEAD/starting-source differ from scoped parent5ee485e')
    if current['source_sha256'] != expected_sha:
        raise ValueError('live Python source differs from explicitly supplied digest')
    baseline = (REPO / 'fs_bot/tools/balance_baseline.json').read_bytes()
    original = git('show', PARENT + ':fs_bot/tools/balance_baseline.json')
    if sha(original) != ORIGINAL_BASELINE_SHA or start['balance_baseline_sha256'] != ORIGINAL_BASELINE_SHA:
        raise ValueError('original815b balance identity changed')
    policy = freeze or {'balance_policy': 'reviewed-correction' if baseline_review else 'original',
        'balance_baseline_sha256': (baseline_review['active_baseline_sha256'] if baseline_review else ORIGINAL_BASELINE_SHA),
        'balance_baseline_updated': bool(baseline_review), 'balance_band_exact': '3/20',
        'baseline_review': baseline_review}
    check_baseline_policy(policy, expected_sha)
    if sha(baseline) != policy['balance_baseline_sha256']:
        raise ValueError('live baseline differs from explicitly approved active policy')
    if policy.get('balance_policy', 'original') == 'original' and baseline != original:
        raise ValueError('original baseline bytes changed')
    if protected_files() != start['protected_files']:
        raise ValueError('protected reference/constant bytes or inventory changed')
    if freeze:
        for label, actual in (('source_files', source_files()),
                              ('fixture_files', fixture_files()),
                              ('runtime_files', runtime_files())):
            if actual != freeze[label]:
                raise ValueError(label + ' changed from frozen inventory')
        if freeze['protected_files'] != start['protected_files']:
            raise ValueError('protected manifest changed')
        if freeze['source_sha256'] != expected_sha or freeze['commit'] != PARENT:
            raise ValueError('attempt identity differs from requested source/parent')
        for name, expected in freeze['tooling_files'].items():
            if sha((ROOT / name).read_bytes()) != expected:
                raise ValueError('validation tooling changed during prepared attempt: ' + name)
    return current


def snapshot_inventory(run, dirname, inventory):
    for name, expected in inventory.items():
        raw = (REPO / name).read_bytes()
        if sha(raw) != expected:
            raise ValueError('source changed while freezing: ' + name)
        destination = run / dirname / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)


def verify_snapshots(run, freeze):
    for label, dirname in (('source_files', 'python-source'),
                           ('fixture_files', 'fixture-source'),
                           ('protected_files', 'protected-source'),
                           ('runtime_files', 'runtime-source')):
        actual = {str(p.relative_to(run / dirname)): sha(p.read_bytes())
                  for p in sorted((run / dirname).rglob('*')) if p.is_file()}
        if actual != freeze[label]:
            raise ValueError('frozen bytes missing/changed: ' + label)
    check_baseline_policy(freeze, freeze['source_sha256'], run=run)
    if sha((run / 'balance-baseline.json').read_bytes()) != freeze['balance_baseline_sha256']:
        raise ValueError('active baseline snapshot differs from approved policy')
    original = run / 'original-balance-baseline.json'
    if not original.exists() and freeze.get('balance_policy', 'original') == 'original':
        original = run / 'balance-baseline.json'  # Earlier immutable original attempt.
    if sha(original.read_bytes()) != ORIGINAL_BASELINE_SHA:
        raise ValueError('original815b baseline snapshot missing or changed')


def prepare(run, expected_sha, jobs, baseline_review_path=None):
    review = (load_baseline_review(baseline_review_path, expected_sha)
              if baseline_review_path is not None else None)
    source = validate_current(expected_sha, baseline_review=review)
    run.mkdir()  # Exclusive: every failed attempt remains untouched.
    start = read(ROOT / 'starting-source.json')
    freeze = {'recorded_utc': utc(), 'python': platform.python_version(),
              'python_executable': str(PYTHON), **source,
              'original_baseline_sha256': ORIGINAL_BASELINE_SHA,
              'balance_baseline_sha256': review['active_baseline_sha256'] if review else ORIGINAL_BASELINE_SHA,
              'balance_policy': 'reviewed-correction' if review else 'original',
              'balance_band_exact': '3/20', 'balance_baseline_updated': bool(review),
              'baseline_review': review,
              'source_files': source_files(), 'fixture_files': fixture_files(),
              'protected_files': start['protected_files'], 'runtime_files': runtime_files(),
              'matrix': MATRIX, 'jobs': jobs}
    for label, folder in (('source_files', 'python-source'),
                          ('fixture_files', 'fixture-source'),
                          ('protected_files', 'protected-source'),
                          ('runtime_files', 'runtime-source')):
        snapshot_inventory(run, folder, freeze[label])
    baseline = (REPO / 'fs_bot/tools/balance_baseline.json').read_bytes()
    (run / 'balance-baseline.json').write_bytes(baseline)
    (run / 'original-balance-baseline.json').write_bytes(
        git('show', PARENT + ':fs_bot/tools/balance_baseline.json'))
    if review:
        (run / 'baseline-review').mkdir()
        for name, record in review['files'].items():
            raw = Path(record['path']).read_bytes()
            if sha(raw) != record['sha256']:
                raise ValueError('baseline review changed during freeze')
            (run / 'baseline-review' / name).write_bytes(raw)
    manifest = (REPO / 'fs_bot/tests/fixtures/compatibility_8ef88e2/manifest.json').read_bytes()
    (run / 'fixture-manifest.json').write_bytes(manifest)
    freeze['fixture_manifest_sha256'] = sha(manifest)
    freeze['source_snapshot'] = {'directory': 'python-source', 'complete': True,
                                 'files': len(freeze['source_files']), 'source_sha256': expected_sha}
    (run / 'git-status.txt').write_bytes(git('status', '--short'))
    (run / 'git-diff.patch').write_bytes(git('diff', '--binary', 'HEAD'))
    tooling = {p.name: sha(p.read_bytes()) for p in sorted(ROOT.glob('*.py'))}
    for name in tooling:
        destination = run / 'tooling' / name
        destination.parent.mkdir(exist_ok=True)
        destination.write_bytes((ROOT / name).read_bytes())
    freeze['tooling_files'] = tooling
    validate_current(expected_sha, freeze)
    verify_snapshots(run, freeze)
    collection = execute(run, 'collection', pytest_argv(run, collect=True), 0, freeze)
    if collection['runner_exit_code'] != 0:
        raise ValueError('frozen test collection failed; preserve this attempt')
    raw = (run / 'test-collection.json').read_bytes()
    collected = json.loads(raw)
    freeze['pytest_collection'] = {'sha256': sha(raw), 'count': len(collected['cases']),
                                  'pytest_version': collected['pytest_version']}
    verify_test_inventory(run, freeze, include_results=False)
    validate_current(expected_sha, freeze)
    write_json(run / 'source.json', source, exclusive=True)
    write_json(run / 'freeze.json', freeze, exclusive=True)
    write_json(run / 'prepared-only.json', {'recorded_utc': utc(),
               'status': 'Test collection frozen; no tests or games executed; awaiting explicit full-suite invocation.'}, exclusive=True)
    return freeze


def execute(run, name, argv, hash_seed, freeze):
    """Exclusive raw log/status capture with periodic source/data guards."""
    status_path = run / (name + '.status.json')
    log_path = run / (name + '.log')
    if status_path.exists() or log_path.exists():
        raise ValueError('refusing to overwrite existing result: ' + name)
    status = {'name': name, 'argv': argv, 'cwd': str(REPO),
              'environment': execution_environment(hash_seed),
              'started_utc': utc(), 'source_sha256_before': digest(),
              'exit_code': None, 'source_changed': False, 'launched': False}
    write_json(status_path, status, exclusive=True)
    started = time.monotonic()
    process = None
    try:
        validate_current(freeze['source_sha256'], freeze)
        with log_path.open('x') as output:
            process = subprocess.Popen(argv, cwd=REPO, env=dict(
                os.environ, **execution_environment(hash_seed)),
                stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
            status.update(pid=process.pid, launched=True)
            write_json(status_path, status)
            while True:
                try:
                    status['exit_code'] = process.wait(timeout=15)
                    break
                except subprocess.TimeoutExpired:
                    validate_current(freeze['source_sha256'], freeze)
        validate_current(freeze['source_sha256'], freeze)
    except BaseException as exc:
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        status['exit_code'] = process.returncode if process is not None else 125
        status['error'] = repr(exc)
        status['source_changed'] = isinstance(exc, ValueError)
        status['interrupted'] = isinstance(exc, KeyboardInterrupt)
    status.update(ended_utc=utc(), duration_seconds=time.monotonic() - started,
                  source_sha256_after=digest())
    status['runner_exit_code'] = (125 if status.get('error') or status['source_changed']
                                  else status['exit_code'])
    write_json(status_path, status)
    print(f"{name}: exit={status['exit_code']} runner={status['runner_exit_code']} "
          f"freeze_ok={not status['source_changed']}", flush=True)
    return status
