# Enlist Raid and Morbihan display verification

This evidence covers findings UI9-01 and UI9-02. The directed witnesses
use controlled legal positions and the public action, terminal, and
durable-session entry points.

- `parent/` contains reproductions on Batch 2, the directed failures,
  and its archived bot and mixed-player records under their original run
  identities.
- `repair/` contains the corrected witness, transcripts, pending saves,
  directed tests, full test results, and paired game runs.
- `verification.json` records the checks performed by
  `verify_evidence.py`. `SHA256SUMS` covers the other archive members.

With the archive extracted, run the verifier from the Batch 3 repository
root.

```sh
PYTHONPATH=. python /path/to/evidence/verify_evidence.py
```

Run the directed regressions and the repaired witness from the same
checkout.

```sh
python -m pytest -q fs_bot/tests/test_ninth_comparison_frontend.py
PYTHONHASHSEED=0 python /path/to/evidence/repair/probe_repaired.py --repo .
```
