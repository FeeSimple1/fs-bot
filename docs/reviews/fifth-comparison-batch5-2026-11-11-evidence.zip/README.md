# Fifth comparison repair Batch 5 evidence

The parent is Falling Sky commit `61c7587caa586bc430723f0b5fde5b5f80a5ef2f`.
`summary.json` identifies the tested Python sources and records the results.
`SHA256SUMS.json` contains the archive checksums. `parent-witnesses.json`
reproduces the fifth-audit bot observations on the Batch 4 sources.

Run these checks from the relevant checkout with Python 3.12, pytest and
pytest-xdist. Use fresh output directories.

```sh
PYTHONHASHSEED=0 python -m pytest -q -n 5 --dist loadfile --tb=short --show-capture=no
PYTHONHASHSEED=0 python -m pytest -q --tb=short --show-capture=no fs_bot/tests/test_fifth_comparison_bot_battles.py fs_bot/tests/test_fourth_comparison_battles.py fs_bot/tests/test_aedui_bot.py fs_bot/tests/test_german_bot.py fs_bot/tests/test_battle.py fs_bot/tests/test_morasses*.py fs_bot/tests/test_divination*.py fs_bot/tests/test_decisive_battle_choices.py fs_bot/tests/test_assistant_session.py fs_bot/tests/test_diviciacus_consent.py
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out /path/to/results/bots-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 29-32 --card-edition second-edition --workers 2 --out /path/to/results/bots-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 29-32 --card-edition second-edition --out /path/to/results/fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 29-32 --card-edition second-edition --out /path/to/results/fuzz987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
```

Run the new cases from the parent checkout with the test file outside the
checkout. Fourteen cases reproduce the defects and seven controls pass.

```sh
PYTHONPATH=. PYTHONHASHSEED=0 python -m pytest -q --tb=short --show-capture=no /path/to/evidence/test_fifth_comparison_bot_battles.py
```

The paired outcomes use the Batch 4 evidence and the new game records.
The trace script replays each changed winner against the recorded final
board, card count and winner. The first-divergence file compares the two
versions at the first board change, with the decision and forecasts from
that card. Each trace requires the checkout whose source hash matches its
input rows.

```sh
PYTHONPATH=. PYTHONHASHSEED=0 python /path/to/evidence/trace_bot_battles.py /path/to/evidence/trace-parent-input.json /path/to/results/trace-parent.json
PYTHONPATH=. PYTHONHASHSEED=0 python /path/to/evidence/trace_bot_battles.py /path/to/evidence/trace-repaired-input.json /path/to/results/trace-repaired.json
python /path/to/evidence/compare_bot_battle_traces.py /path/to/results/trace-parent.json /path/to/results/trace-repaired.json /path/to/results/first-divergences.json
```

The failed prior-baseline run used the same gameplay source before a
test-only fixture correction. Its 100 winners and lengths match both
final legacy runs. The original baseline, its replacement, and their
record-level differences are included. The same 100 game keys and
15-point threshold govern the passing final check.
