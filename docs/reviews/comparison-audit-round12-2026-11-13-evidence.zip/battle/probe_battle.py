"""Round 12 public bot Battle witnesses for omitted Slingers forecasts."""

import json
from pathlib import Path
import sys

REPO = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / "falling-sky"
sys.path.insert(0, str(REPO))

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, get_leader_in_region, place_piece
from fs_bot.bots.bot_common import predict_battle
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND, ACTION_COMMAND_SA, ACTION_EVENT
from fs_bot.state.serialize import encode
from fs_bot.state.state_schema import build_initial_state, check_structural_integrity, validate_state
from fs_bot.tools.seat_session import validate_response

REGION = rc.CARNUTES
FACTIONS = (
    (rc.BELGAE, rc.AMBIORIX, rc.SCENARIO_GREAT_REVOLT),
    (rc.ARVERNI, rc.VERCINGETORIX, rc.SCENARIO_GREAT_REVOLT),
    (rc.GERMANS, rc.ARIOVISTUS_LEADER, rc.SCENARIO_ARIOVISTUS),
)


def integrity(state):
    result = {"census": validate_state(state), "structure": check_structural_integrity(state)}
    assert result == {"census": [], "structure": []}, result
    return result


def event(state, card, actor, *, shaded=False):
    state["current_card"] = state["current_card_id"] = card
    action = {"action": ACTION_EVENT, "player_action": {
        "command": rc.FIRST_DID_EVENT,
        "details": {"card_id": card, "text_preference": rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,
                    "event_params": {}},
    }}
    validate_response(state, {"kind": "turn", "faction": actor, "options": [ACTION_EVENT]}, action)
    result = execute_decision(state, actor, action)
    assert result["executed"] and not result.get("errors"), result
    integrity(state)
    return result


def summary(state, faction):
    return {
        "leader": get_leader_in_region(state, REGION, faction),
        "warbands": count_pieces(state, REGION, faction, rc.WARBAND),
        "roman_auxilia": count_pieces(state, REGION, rc.ROMANS, rc.AUXILIA),
        "resources": state["resources"][faction],
    }


def case(faction, leader, scenario, seed, *, slingers, stalwart=False, warbands=1):
    state = build_initial_state(scenario, seed=seed)
    state["non_player_factions"] = {faction}
    state["resources"][faction] = 10
    state["can_play_event"] = False
    state["_command_with_sa"] = warbands == 1
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    place_piece(state, REGION, faction, rc.LEADER, leader_name=leader)
    place_piece(state, REGION, faction, rc.WARBAND, warbands)
    place_piece(state, REGION, rc.ROMANS, rc.AUXILIA, 4, piece_state=rc.REVEALED)
    acquisitions = []
    if slingers:
        acquisitions.append(event(state, 13, rc.ROMANS))
    if stalwart:
        acquisitions.append(event(state, "A31", rc.GERMANS, shaded=True))
    before_integrity = integrity(state)
    before = summary(state, faction)
    pristine = encode(state)
    requests = []

    def choose_slingers(_board, actor, request):
        requests.append({"faction": actor, "kind": request["kind"],
                         "num_losses": request.get("num_losses"), "pieces": request.get("pieces")})
        if request["kind"] == "slingers_region":
            return {"region": REGION}
        if request["kind"] == "retreat":
            return {"retreat": False}
        return None

    action = dispatch_bot_turn(state, faction)
    assert encode(state) == pristine, "The single-target dispatcher unexpectedly mutated state/RNG."
    assert action["command"] == rc.CMD_BATTLE, action
    assert action["details"]["battle_plan"][0]["target"] == rc.ROMANS
    ambush = action["sa"] == rc.SA_AMBUSH
    naive = predict_battle(state, REGION, faction, rc.ROMANS, is_ambush=ambush)
    opening = predict_battle(state, REGION, faction, rc.ROMANS, is_ambush=ambush, earlier_battles=[])
    assert encode(state) == pristine, "Detached predictions mutated state/RNG."
    state["decision_agent"] = choose_slingers
    sequence_action = ACTION_COMMAND_SA if state["_command_with_sa"] else ACTION_COMMAND
    result = execute_decision(state, faction, {"action": sequence_action, "bot_action": action})
    assert result["executed"] and not result.get("errors"), result
    after = summary(state, faction)
    if slingers and not stalwart and warbands == 1:
        assert naive["inflicted"] > naive["taken"] and not naive["attacker_leader_lost"]
        assert opening["inflicted"] == 0 and opening["taken"] >= 2 and opening["attacker_leader_lost"]
        assert after["leader"] is None and after["warbands"] == 0 and after["roman_auxilia"] == 4
        assert any(r["faction"] == faction and r["kind"] == "loss_order"
                   and any(piece[0] == rc.LEADER for piece in r["pieces"]) for r in requests)
    else:
        assert after["leader"] == leader and not opening["attacker_leader_lost"]
        if warbands == 8:
            assert after["warbands"] == 6 and after["roman_auxilia"] == 0
    return {
        "name": f"{faction}-seed{seed}-slingers{int(slingers)}-stalwart{int(stalwart)}-wb{warbands}",
        "faction": faction, "scenario": scenario, "seed": seed,
        "slingers": slingers, "stalwart": stalwart, "warbands": warbands,
        "with_sa": state["_command_with_sa"],
        "acquisitions": acquisitions, "before": before, "action": action,
        "unscoped_forecast": naive, "command_aware_forecast": opening,
        "execution": result, "requests": requests, "after": after,
        "integrity_before": before_integrity, "integrity_after": integrity(state),
        "dispatch_and_forecast_pure": True,
    }


def json_default(value):
    if isinstance(value, set):
        return sorted(value)
    raise TypeError(type(value).__name__)


def main():
    cases = []
    for faction, leader, scenario in FACTIONS:
        for seed in (1, 7):
            for active in (False, True):
                cases.append(case(faction, leader, scenario, seed, slingers=active))
        cases.append(case(faction, leader, scenario, 1, slingers=True, warbands=8))
    for seed in (1, 7):
        cases.append(case(rc.GERMANS, rc.ARIOVISTUS_LEADER, rc.SCENARIO_ARIOVISTUS,
                          seed, slingers=True, stalwart=True))
    print(json.dumps({"case_count": len(cases), "cases": cases}, default=json_default,
                     sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
