"""Record matching prefixes and actual Event choices in the paired game runs."""

import argparse
import hashlib
import json
from pathlib import Path
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, get_available
from fs_bot.engine import execute, game_engine
from fs_bot.map.map_data import get_adjacent, get_region_for_tribe_for_state
from fs_bot.state.serialize import encode
from fs_bot.tools import player_fuzz, run_batch
from fs_bot.tools.validation_metadata import source_identity


def digest(value):
    body = json.dumps(encode(value), sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(body.encode()).hexdigest()


def board_hash(state):
    return digest({key: value for key, value in state.items() if key != 'decision_agent'})


def event_board(state, card, faction):
    if card == 33:
        return {
            'fallen_legions': state.get('fallen_legions', 0),
            'legions_track': state['legions_track'].copy(),
            'legion_regions': {
                region: {'legions': count,
                         'warbands': {f: count_pieces(state, region, f, rc.WARBAND)
                                      for f in (rc.ARVERNI, rc.AEDUI, rc.BELGAE, rc.GERMANS)}}
                for region in rc.ALL_REGIONS
                if (count := count_pieces(state, region, rc.ROMANS, rc.LEGION))
            },
        }
    nearby = (rc.CISALPINA, *get_adjacent(rc.CISALPINA))
    return {
        'gallia_togata': rc.MARKER_GALLIA_TOGATA in state['markers'].get(rc.CISALPINA, {}),
        'stock': {kind: get_available(state, faction, kind)
                  for kind in (rc.ALLY, rc.AUXILIA, rc.WARBAND)},
        'tribes': {tribe: dict(info) for tribe, info in state['tribes'].items()
                   if get_region_for_tribe_for_state(state, tribe) in nearby},
    }


def trace(task, mixed):
    cards, events = [], []
    play = game_engine.play_card
    resolve = execute._execute_event
    derive = execute._derive_event_params

    def record_event(state, faction, action, *, human=False):
        card = action.get('details', {}).get('card_id', state.get('current_card'))
        if card not in (33, 'A40'):
            return resolve(state, faction, action, human=human)
        row = {'card': card, 'faction': faction, 'human': human,
               'side': action['details'].get('text_preference'),
               'before': event_board(state, card, faction),
               'before_rng_sha256': digest(state['rng'].getstate())}
        if human:
            row['params'] = action['details'].get('event_params')
        events.append(row)
        result = resolve(state, faction, action, human=human)
        row.update(result=result, after=event_board(state, card, faction),
                   after_rng_sha256=digest(state['rng'].getstate()))
        return result

    def record_params(state, faction, card, shaded):
        params = derive(state, faction, card, shaded)
        if events and card in (33, 'A40'):
            row = events[-1]
            if ((row['card'], row['faction']) == (card, faction)
                    and not row['human'] and 'result' not in row):
                row['params'] = params
        return params

    def record_card(state, decide, **kwargs):
        events.clear()
        row = {'ordinal': len(cards) + 1, 'scenario': state['scenario'],
               'card': state['current_card'], 'before_sha256': board_hash(state),
               'before_rng_sha256': digest(state['rng'].getstate())}
        result = play(state, decide, **kwargs)
        actions = result.get('turn_result', {}).get('actions_taken', {})
        row.update(after_sha256=board_hash(state), actions_sha256=digest(actions),
                   after_rng_sha256=digest(state['rng'].getstate()),
                   actions={faction: action['action'] for faction, action in actions.items()},
                   events=list(events), winner=result.get('winner'))
        cards.append(row)
        return result

    with (patch.object(game_engine, 'play_card', record_card),
          patch.object(run_batch, 'play_card', record_card),
          patch.object(execute, '_execute_event', record_event),
          patch.object(execute, '_derive_event_params', record_params)):
        if mixed:
            scenario, seed, edition = task
            result = player_fuzz.play_game(scenario, seed, card_edition=edition)
            assert result['game_completed'] and not result['findings'], result
            outcome = {'digest': result['digest']}
        else:
            result = run_batch.play_one(task)
            assert result['completed'], result['errors']
            outcome = {key: result[key] for key in ('winner', 'cards', 'final_state_sha256')}
    return {'task': task, 'cards': cards, 'outcome': outcome}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pairs', type=Path)
    parser.add_argument('--mixed', action='store_true')
    args = parser.parse_args()
    tasks = json.loads(args.pairs.read_text())
    games = [trace(task, args.mixed) for task in tasks]
    print(json.dumps(encode({'source': source_identity(), 'games': games}),
                     indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
