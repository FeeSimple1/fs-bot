"""Round 9 bot audit: lawful public-dispatch witnesses, no production changes.

Run: python probe_bots.py --repo /path/to/fs-bot
Assertions preserve the observed defect and should change when repaired.
The explicit SA-label controls are documented as source-required inputs,
not as labels chosen by the unmodified dispatcher.
"""
import argparse
import json
import sys
from copy import deepcopy
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument('--repo', type=Path, default=Path(__file__).resolve().parents[2] / 'fs-bot')
args = ap.parse_args()
sys.path.insert(0, str(args.repo.resolve()))
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces, count_pieces_by_state
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.bots.arverni_bot import _check_devastate, _determine_march_sa
from fs_bot.bots.belgae_bot import _check_rampage, _check_enlist_after_command
from fs_bot.commands.sa_devastate import devastate_region, validate_devastate_region
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND, ACTION_COMMAND_SA

integrity_checks = 0

def integrity(state):
    global integrity_checks
    schema, structure = validate_state(state), check_structural_integrity(state)
    assert schema == structure == [], (schema, structure)
    integrity_checks += 1
    return {'schema': schema, 'structure': structure}


def board(*, seed=6, sa=True):
    state = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=seed)
    state['non_player_factions'] = {rc.ROMANS, rc.AEDUI, rc.BELGAE, rc.ARVERNI}
    state['can_play_event'] = False
    state['_command_with_sa'] = sa
    state['resources'].update({f: 10 for f in state['non_player_factions']})
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    return state


def run(state, faction, *, sa_label=None):
    before = integrity(state)
    action = dispatch_bot_turn(state, faction)
    original_action = deepcopy(action)
    if sa_label:
        action['sa'] = sa_label
    result = execute_decision(state, faction, {
        'action': ACTION_COMMAND_SA if state['_command_with_sa'] else ACTION_COMMAND,
        'bot_action': action})
    assert result['executed'] and not result.get('errors'), result
    after = integrity(state)
    record = {'action': original_action, 'execution': result,
              'integrity_before': before, 'integrity_after': after,
              'resources_after': state['resources'][faction],
              'command_with_sa': state['_command_with_sa']}
    if sa_label:
        record['source_required_execution_control'] = {
            'supplied_sa_label': sa_label,
            'note': 'Only the dispatched SA label changes; existing live executor derives actual targets from the post-Command board.'}
    return record


def devastating_board(*, legions=0, auxilia=0, aedui=0, own=4, sa=True):
    state = board(sa=sa)
    place_piece(state, rc.ARVERNI_REGION, rc.ARVERNI, rc.LEADER,
                leader_name=rc.VERCINGETORIX)
    place_piece(state, rc.BITURIGES, rc.ARVERNI, rc.WARBAND, own,
                piece_state=rc.REVEALED)
    if legions:
        place_piece(state, rc.BITURIGES, rc.ROMANS, rc.LEGION, legions,
                    from_legions_track=True)
    if auxilia:
        place_piece(state, rc.BITURIGES, rc.ROMANS, rc.AUXILIA, auxilia)
    if aedui:
        place_piece(state, rc.BITURIGES, rc.AEDUI, rc.WARBAND, aedui)
    return state


def devastating_counts(state):
    return {'arverni_warbands': count_pieces(state, rc.BITURIGES, rc.ARVERNI, rc.WARBAND),
            'roman_legions': count_pieces(state, rc.BITURIGES, rc.ROMANS, rc.LEGION),
            'roman_auxilia': count_pieces(state, rc.BITURIGES, rc.ROMANS, rc.AUXILIA),
            'aedui_warbands': count_pieces(state, rc.BITURIGES, rc.AEDUI, rc.WARBAND),
            'devastated': bool(state.get('markers', {}).get(rc.BITURIGES, {}).get(rc.MARKER_DEVASTATED))}


def entreat_board(*, initial_hidden=0, sa=True, enemy_auxilia=1):
    state = board(sa=sa)
    place_piece(state, rc.MANDUBII, rc.ARVERNI, rc.LEADER, leader_name=rc.VERCINGETORIX)
    assert _ally_tribe(state, rc.TRIBE_AULERCI, rc.ARVERNI)
    if enemy_auxilia:
        place_piece(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA, enemy_auxilia)
    if initial_hidden:
        place_piece(state, rc.CARNUTES, rc.ARVERNI, rc.WARBAND, initial_hidden)
    return state


def entreat_counts(state):
    return {'arverni_hidden': count_pieces_by_state(state, rc.CARNUTES, rc.ARVERNI, rc.WARBAND, rc.HIDDEN),
            'roman_auxilia': count_pieces(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA)}


def enlist_board(*, hidden=2, german_revealed=2, sa=True):
    state = board(seed=1, sa=sa)
    state['resources'][rc.BELGAE] = 0
    place_piece(state, rc.CARNUTES, rc.BELGAE, rc.LEADER, leader_name=rc.AMBIORIX)
    place_piece(state, rc.CARNUTES, rc.BELGAE, rc.WARBAND, hidden)
    place_piece(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA, 3)
    if german_revealed:
        place_piece(state, rc.BITURIGES, rc.GERMANS, rc.WARBAND, german_revealed,
                    piece_state=rc.REVEALED)
    return state


def enlist_counts(state):
    return {'belgic_hidden': count_pieces_by_state(state, rc.CARNUTES, rc.BELGAE, rc.WARBAND, rc.HIDDEN),
            'belgic_revealed': count_pieces_by_state(state, rc.CARNUTES, rc.BELGAE, rc.WARBAND, rc.REVEALED),
            'roman_auxilia': count_pieces(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA),
            'german_hidden': count_pieces_by_state(state, rc.BITURIGES, rc.GERMANS, rc.WARBAND, rc.HIDDEN),
            'german_revealed': count_pieces_by_state(state, rc.BITURIGES, rc.GERMANS, rc.WARBAND, rc.REVEALED)}


out = {'audited_commit': 'f4c8372c396981c0a31dc6f4545e67f8c6f2e981',
       'production_edits': False, 'repository_tests_run': False,
       'NP9-01': [], 'NP9-02': {'arverni_post_rally': [], 'belgae_post_raid': []}}

for name, kwargs, expected_sa, expected_own, expected_enemy_loss in (
    ('one_legion_no_casualty', {'legions': 1}, 'No SA', 4, 0),
    ('two_auxilia_no_casualty', {'auxilia': 2}, 'No SA', 4, 0),
    ('positive_control_three_legions', {'legions': 3}, rc.SA_DEVASTATE, 3, 1),
    ('negative_control_one_auxilium', {'auxilia': 1}, 'No SA', 4, 0),
    ('one_for_one_casualties', {'aedui': 3}, rc.SA_DEVASTATE, 3, 1),
    ('command_only_control', {'legions': 1, 'sa': False}, 'No SA', 4, 0)):
    state = devastating_board(**kwargs)
    initial = devastating_counts(state)
    initial_choice = _check_devastate(state, state['scenario'])
    rec = run(state, rc.ARVERNI)
    final = devastating_counts(state)
    assert rec['action']['command'] == rc.CMD_RALLY
    assert (rec['execution'].get('sa_execution') or {}).get('executed', False) == (expected_sa == rc.SA_DEVASTATE)
    assert final['arverni_warbands'] == expected_own
    enemy_fields = ('roman_legions', 'roman_auxilia', 'aedui_warbands')
    assert sum(initial[k] - final[k] for k in enemy_fields) == expected_enemy_loss
    assert final['devastated'] == (expected_sa == rc.SA_DEVASTATE)
    rec.update(case=name, initial_counts=initial, final_counts=final,
               initial_devastate_candidates=initial_choice,
               post_command_devastate_candidates=_check_devastate(state,state['scenario']))
    out['NP9-01'].append(rec)

for name, kwargs, label in (
    ('defect_new_entreat', {}, None),
    ('existing_hidden_control', {'initial_hidden': 1}, None),
    ('command_only_control', {'sa': False}, None),
    ('no_enemy_control', {'enemy_auxilia': 0}, None),
    ('source_required_entreat_execution_control', {}, rc.SA_ENTREAT)):
    state = entreat_board(**kwargs)
    initial_choice = _determine_march_sa(state,state['scenario'])
    rec = run(state, rc.ARVERNI, sa_label=label)
    final_choice = _determine_march_sa(state,state['scenario'])
    final = entreat_counts(state)
    assert rec['action']['command'] == rc.CMD_RALLY
    if name == 'defect_new_entreat':
        assert rec['action']['sa'] == rc.SA_ENTREAT
        assert rec['execution']['sa_execution']['executed']
        assert final == {'arverni_hidden': 3, 'roman_auxilia': 0}, final
        assert rec['resources_after'] == 6
    elif name in ('existing_hidden_control', 'source_required_entreat_execution_control'):
        assert rec['execution']['sa_execution']['executed']
        assert rec['execution']['sa_execution']['rederived_at_sa_time']
        assert final['roman_auxilia'] == 0 and final['arverni_hidden'] >= 2
    else:
        assert rec['action']['sa'] == 'No SA' and final_choice == ('No SA', [])
    if label:
        assert final == {'arverni_hidden': 3, 'roman_auxilia': 0}
        assert rec['resources_after'] == 6
    rec.update(case=name, initial_sa=initial_choice, final_sa=final_choice, final_counts=final)
    out['NP9-02']['arverni_post_rally'].append(rec)

for name, kwargs, label in (
    ('defect_missing_enlist_fallback', {}, None),
    ('remaining_hidden_rampage_control', {'hidden': 3}, None),
    ('no_enlist_candidate_control', {'german_revealed': 0}, None),
    ('command_only_control', {'sa': False}, None),
    ('source_required_enlist_execution_control', {}, rc.SA_ENLIST)):
    state = enlist_board(**kwargs)
    initial = enlist_counts(state)
    initial_rampage = _check_rampage(state,state['scenario'])
    # Read-only candidate query on a detached copy so tie-breaking cannot
    # change the live dispatch seed, even if future candidate sets grow.
    initial_enlist = _check_enlist_after_command(deepcopy(state),state['scenario'])
    rec = run(state, rc.BELGAE, sa_label=label)
    final = enlist_counts(state)
    final_rampage = _check_rampage(state,state['scenario'])
    final_enlist = _check_enlist_after_command(deepcopy(state),state['scenario'])
    assert rec['action']['command'] == rc.CMD_RAID
    assert rec['resources_after'] == 2
    if name == 'defect_missing_enlist_fallback':
        assert rec['action']['sa'] == rc.SA_ENLIST
        assert rec['execution']['sa_execution']['sa'] == rc.SA_ENLIST
        assert rec['execution']['sa_execution']['executed']
        assert final['german_revealed'] == 0 and final['german_hidden'] == 2
    elif name == 'remaining_hidden_rampage_control':
        assert rec['execution']['sa_execution']['executed']
        assert final['roman_auxilia'] == 2 and final['german_revealed'] == 2
    elif name == 'no_enlist_candidate_control':
        assert final_enlist is None
        assert rec['execution']['sa_execution']['declined_no_effect']
    elif name == 'command_only_control':
        assert rec['action']['sa'] == 'No SA'
        assert 'sa_execution' not in rec['execution']
        assert final['german_revealed'] == 2
    else:
        assert rec['execution']['sa_execution']['executed']
        assert rec['execution']['sa_execution']['rederived_at_sa_time']
        assert final['german_revealed'] == 0 and final['german_hidden'] == 2
        assert final['roman_auxilia'] == 3
    rec.update(case=name, initial_counts=initial, final_counts=final,
               initial_rampage=initial_rampage, initial_enlist=initial_enlist,
               final_rampage=final_rampage, final_enlist=final_enlist)
    out['NP9-02']['belgae_post_raid'].append(rec)

out['integrity_checks_passed'] = integrity_checks
out['all_observation_assertions_passed'] = True
print(json.dumps(out, indent=2, sort_keys=True))
