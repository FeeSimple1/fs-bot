"""Compare ordered compact traces, optionally reusing the four old full traces.

Unknown sequence shapes and unreviewed rule explanations remain blockers.
This localizes the first observable difference; it never approves a refresh.
"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path


def sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def read(path):
    with gzip.open(path, "rt") as stream:
        return json.load(stream)


def legacy_rows(data):
    """Recover complete card/decision/action boundaries without rerunning a game.

The old logger lacks setup/start boundaries, before-execute payloads, and
nesting depths. Reuse is permitted only when each execution maps uniquely to
one ordinary card/faction decision. Unsupported nesting requires a new trace.
"""
    result, used = [], set()
    executions = data["execution"]
    for index, card in enumerate(data["cards"], 1):
        card_id = card["result"]["card"]
        def add(stage, state, faction=None, position=None, payload=None, depth=0):
            row = {"stage": stage, "card_index": index, "card": card_id, "faction": faction,
                   "position": position, "depth": depth, "state_sha256": sha(state),
                   "domain_sha256": {str(k):sha(v) for k,v in state.items()},
                   "rng_sha256": sha(state.get("rng")), "legacy_state": state}
            if payload is not None:
                row["payload"] = payload
            result.append(row)
        if index > 1:
            add("before_card", data["cards"][index-2]["after"])
        for decision in (d for d in data["decisions"] if d["card_index"] == index):
            faction, position = decision["faction"], decision["position"]
            add("before_decision", decision["before"], faction, position, {"options": decision["options"]})
            add("after_decision", decision["after_decide"], faction, position, decision["answer"])
            matched = [(n,e) for n,e in enumerate(executions) if e["card_index"] == index and e["faction"] == faction]
            if len(matched) > 1:
                raise ValueError(f"Legacy trace has ambiguous nested/repeated executions at card {index}/{faction}; obtain compact baseline trace")
            if matched:
                n, execution = matched[0]
                if n in used:
                    raise ValueError("Legacy execution matched twice; obtain compact baseline trace")
                used.add(n)
                add("before_execute", execution["before"], faction, depth=1)
                add("after_execute", execution["after"], faction, payload=execution["result"], depth=1)
        add("after_card", card["after"], payload=card["result"])
    if len(used) != len(executions):
        raise ValueError("Legacy trace contains unmatched executions; obtain compact baseline trace")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--current", type=Path, required=True)
    parser.add_argument("--baseline-source-sha256", required=True)
    parser.add_argument("--baseline-final-sha256", required=True)
    parser.add_argument("--current-source-sha256", required=True)
    parser.add_argument("--current-final-sha256", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    old, new = read(args.baseline), read(args.current)
    legacy = "trace_version" not in old
    old_scenario = (old["decisions"][0]["before"]["scenario"]
                    if legacy else old["scenario"])
    assert old_scenario == new["scenario"] == new["record"]["scenario"], "trace scenarios differ"
    assert old["seed"] == new["seed"] == new["record"]["seed"], "trace seeds differ"
    assert new["record"]["card_edition"] == "legacy", "drift audit requires legacy profile"
    old_hash = old.get("record", old).get("final_state_sha256")
    new_hash = new["record"]["final_state_sha256"]
    assert old["source"]["source_sha256"] == args.baseline_source_sha256
    assert new["source"]["source_sha256"] == args.current_source_sha256
    assert old_hash == args.baseline_final_sha256 and new_hash == args.current_final_sha256
    assert new["passed"] and (legacy or old["passed"])
    before = legacy_rows(old) if legacy else old["checkpoints"]
    after = new["checkpoints"]
    if legacy:
        after = [r for r in after if r["stage"] not in ("after_setup", "after_start")
                 and not (r["stage"] == "before_card" and r["card_index"] == 1)]
    descriptor = ("stage", "card_index", "card", "faction", "position", "depth")
    first = None
    first_state_or_decision = None
    common = 0
    prior_current = []
    for index, (left, right) in enumerate(zip(before, after)):
        same_boundary = all(left.get(k) == right.get(k) for k in descriptor)
        compare_payload = "payload" in left and "payload" in right
        same_payload = not compare_payload or left["payload"] == right["payload"]
        if not same_boundary or left["state_sha256"] != right["state_sha256"] or not same_payload:
            domains = sorted(k for k in left["domain_sha256"].keys() | right["domain_sha256"].keys()
                             if left["domain_sha256"].get(k) != right["domain_sha256"].get(k))
            difference = {"comparison_index": index, "same_boundary": same_boundary,
                     "baseline_boundary": {k:left.get(k) for k in descriptor},
                     "current_boundary": {k:right.get(k) for k in descriptor},
                     "baseline_state_sha256": left["state_sha256"], "current_state_sha256": right["state_sha256"],
                     "changed_state_domains": domains, "rng_changed": left["rng_sha256"] != right["rng_sha256"],
                     "payload_differs": not same_payload,
                     "baseline_payload": left.get("payload"), "current_payload": right.get("payload"),
                     "current_facts": right.get("facts"),
                     "last_current_precondition_boundaries": [r for r in prior_current[-3:] if "facts" in r]}
            if legacy:
                # Only the first divergent old snapshot is retained in the
                # compact review, rather than duplicating all archived boards.
                difference["baseline_snapshot_at_first_difference"] = left["legacy_state"]
            if first is None:
                first = difference
            # Richer handler result reporting can differ without changing the
            # game. Keep it above, then separately locate a full-state/RNG or
            # actual decision/option/plan difference. Never discard state keys.
            decision_payload = right["stage"] in ("before_decision", "after_decision", "before_execute")
            if (not same_boundary or left["state_sha256"] != right["state_sha256"]
                    or (not same_payload and decision_payload)):
                first_state_or_decision = difference
                break
        if first is None:
            common += 1
        if "facts" in right:
            prior_current.append({k:v for k,v in right.items() if k in (*descriptor, "facts", "state_sha256")})
    if first is None and len(before) != len(after):
        first = {"comparison_index": common, "same_boundary": False,
                 "reason": "checkpoint count differs after the common prefix"}
        first_state_or_decision = first
    hypotheses = ["Inspect corrected Roman ranking ties/die band, own-casualty visibility, actual Seize Rally, Surus cohort, and Event timing/piece scope. Localization alone supplies no causal conclusion."]
    report = {"status": "localization only; independent source review required; no baseline approval",
              "baseline_trace": str(args.baseline), "current_trace": str(args.current),
              "baseline_source": old["source"], "current_source": new["source"],
              "baseline_final_hash_verified": True, "current_final_hash_verified": True,
              "baseline_final_state_sha256": old_hash, "current_final_state_sha256": new_hash,
              "baseline_archive_reused": legacy, "common_checkpoint_prefix": common,
              "baseline_checkpoints": len(before), "current_checkpoints": len(after),
              "first_difference": first, "first_state_or_decision_difference": first_state_or_decision,
              "unverified_review_hypotheses": hypotheses,
              "limitations": ["A first corrected-rule divergence does not prove that this change alone caused the final winner.",
                              "Unknown causes and sequence mismatches block causal acceptance."] +
                             (["Reused legacy trace lacks setup/start boundaries and before-execute payloads; these were not compared."] if legacy else [])}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("x") as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({k:v for k,v in report.items() if k not in ("first_difference", "first_state_or_decision_difference")}, indent=2))


if __name__ == "__main__":
    main()
