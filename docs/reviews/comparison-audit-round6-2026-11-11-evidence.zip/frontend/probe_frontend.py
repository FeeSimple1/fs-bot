"""Sixth audit: executable observed-defect witnesses; no production mutations.
Run with PYTHONPATH=<audited fs-bot root> python probe_frontend.py.
Controlled legal positions, not a claim of natural game frequency.
"""
from copy import deepcopy
from io import StringIO
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, place_piece
from fs_bot.board.control import refresh_all_control
from fs_bot.cli.display import HumanTurnDisplay
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.free_actions import validate_free_action_response
from fs_bot.engine.game_engine import ACTION_EVENT, ACTION_COMMAND_SA, _action_transaction
from fs_bot.state.serialize import decode, encode, load_game, save_game
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.tools.seat_session import DecisionPending, SeatSession, board_copy


def clean(state):
    assert validate_state(state) == [], validate_state(state)
    assert check_structural_integrity(state) == [], check_structural_integrity(state)


def board():
    s=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=4)
    s.update(current_card=52,current_card_id=52,next_card=49,
             card_edition='second-edition',non_player_factions=set())
    place_piece(s,rc.PROVINCIA,rc.ROMANS,rc.FORT)
    for region in (rc.CARNUTES,rc.MANDUBII):
        place_piece(s,region,rc.AEDUI,rc.WARBAND,6)
        place_piece(s,region,rc.BELGAE,rc.WARBAND,5,piece_state=rc.REVEALED)
    s['resources'][rc.AEDUI]=10
    refresh_all_control(s)
    assert s['spaces'][rc.CARNUTES]['control']==rc.AEDUI_CONTROL
    clean(s)
    return s


def plan(regions=(rc.CARNUTES,rc.MANDUBII)):
    return {'command':rc.CMD_BATTLE,'sa':rc.SA_AMBUSH,'sa_regions':list(regions),
            'details':{'battle_plan':[{'region':r,'target':rc.BELGAE}
                                     for r in (rc.CARNUTES,rc.MANDUBII)]}}


def play(s):
    return execute_decision(s,rc.AEDUI,{'action':ACTION_EVENT,'player_action':{
        'command':rc.FIRST_DID_EVENT,'sa':'No SA','details':{
        'card_id':52,'text_preference':rc.EVENT_SHADED,'event_params':{}}}})


def reaction(s,f,r):
    if r['kind']=='retreat': return {'retreat':False}


def counts(s):
    return {region:{f:count_pieces(s,region,f,rc.WARBAND) for f in (rc.AEDUI,rc.BELGAE)}
            for region in (rc.CARNUTES,rc.MANDUBII)}


def event_case(regions):
    s=board(); requests=[]
    def agent(st,f,req):
        requests.append(deepcopy(req))
        return plan(regions) if req['kind']=='free_action' else reaction(st,f,req)
    s['decision_agent']=agent
    before=counts(s)
    result=play(s)
    clean(s)
    assert result['executed']
    assert result['free_actions'][0]['result']['errors']==[]
    after=counts(s)
    assert after[rc.CARNUTES]=={rc.AEDUI:6,rc.BELGAE:2}
    assert after[rc.MANDUBII]=={rc.AEDUI:6 if len(regions)==2 else 5,rc.BELGAE:2}
    return {'result':result,'before':before,'after':after,
            'retreat_requests':sum(r['kind']=='retreat' for r in requests),
            'census':[],'structure':[]}


def ordinary_control():
    s=board(); before=encode(s)
    result=execute_decision(s,rc.AEDUI,{'action':ACTION_COMMAND_SA,'player_action':plan()})
    assert result['rejected'] and 'one Region' in result['reason']
    assert encode(s)==before
    return {'result':result,'board_rng_unchanged':True}


def multi_control():
    s=board(); a=plan();a['sa']='No SA';a['sa_regions']=[]
    a['special_abilities']=[{'sa':rc.SA_AMBUSH,'sa_regions':[rc.CARNUTES,rc.MANDUBII],
                            'sa_timing':'during'},
                           {'sa':rc.SA_TRADE,'sa_regions':[],'sa_timing':'after'}]
    req={'request_type':'event_command','with_sa':True,'max_special_abilities':2}
    before=encode(s)
    error=validate_free_action_response(s,rc.AEDUI,req,a)
    assert error and 'one Region' in error
    assert encode(s)==before
    return {'error':error,'board_rng_unchanged':True}


def make_session(s,meta=None,log=None):
    seat=SeatSession(s,{'seat':rc.AEDUI} if meta is None else meta,
                     [] if log is None else log,HumanTurnDisplay(StringIO()))
    def agent(st,f,r):
        if r['kind']=='free_action': return seat.reactive(st,f,r)
        return reaction(st,f,r)
    s['decision_agent']=agent
    return seat


def step(seat):
    def driver(*args): pass
    driver.transaction_checkpoint=seat.checkpoint
    driver.transaction_restore=seat.restore
    with _action_transaction(seat.state,driver): return play(seat.state)


def durable():
    s=board(); initial=deepcopy(s); seat=make_session(s)
    try:
        step(seat)
        raise AssertionError('Missing pending grant')
    except DecisionPending: pass
    pending=deepcopy(seat.data['pending'])
    assert decode(pending['request'])['request_type']=='event_command'
    assert encode(board_copy(s))==encode(initial)
    request=decode(pending['request']); before=encode(board_copy(s))
    error=validate_free_action_response(s,rc.AEDUI,request,plan())
    assert error is None and encode(board_copy(s))==before
    with TemporaryDirectory() as tmp:
        path=Path(tmp)/'save.json'
        save_game(s,path,meta=seat.meta,log=seat.log)
        restored,meta,log=load_game(path,validate=True); resumed=make_session(restored,meta,log)
        assert resumed.data['pending']==pending
        resumed.import_inbox({'decision_id':pending['id'],'response':plan()})
        result=step(resumed);resumed.finish();clean(restored)
        assert result['executed'] and resumed.data['pending'] is None
        assert decode(log[-1]['assistant_response'])==plan()
        records=iter(log)
        def replay(st,f,req):
            if req['kind']=='free_action':
                row=next(records);assert decode(row['assistant_request'])==dict(req,faction=f)
                return decode(row['assistant_response'])
            return reaction(st,f,req)
        initial['decision_agent']=replay
        assert play(initial)==result and next(records,None) is None
        assert encode(board_copy(initial))==encode(board_copy(restored))
        return {'pending_id':pending['id'],'preview_error':error,
                'preview_board_rng_unchanged':True,'saved_pending_preserved':True,
                'illegal_two_region_ambush_accepted':True,'replay_identical':True,
                'after':counts(restored),'census':[],'structure':[]}


def main():
    out={'FE6-01':{'illegal_two_region_event':event_case((rc.CARNUTES,rc.MANDUBII)),
                   'legal_one_region_event':event_case((rc.CARNUTES,)),
                   'ordinary_rejection_control':ordinary_control(),
                   'two_ability_rejection_control':multi_control(),
                   'save_resume_replay':durable()}}
    print(json.dumps(out,indent=2,sort_keys=True))

if __name__=='__main__': main()
