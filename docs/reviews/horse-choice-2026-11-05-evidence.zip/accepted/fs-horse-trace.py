"""Trace one paired native game; optionally restore only the old Horse policy."""
from pathlib import Path
import json, sys
from fs_bot import rules_consts as rc
from fs_bot.engine import execute as ex
from fs_bot.tools import run_batch
from fs_bot.tools.seat_session import board_copy, fingerprint
from fs_bot.cards.capabilities import is_capability_active, get_capability_owner
from fs_bot.board.pieces import count_pieces
from fs_bot.tools.validation_metadata import source_identity

label = sys.argv[1]
if label == 'counterfactual':
    from fs_bot.engine import horse_choice
    def old_policy(state, faction, plan):
        regions=[e.get('region') for e in plan if e.get('region') is not None]
        if is_capability_active(state,59,rc.EVENT_UNSHADED) and regions:
            cands=[(count_pieces(state,r,rc.ROMANS,rc.AUXILIA),r) for r in sorted(set(regions))]
            cands=[c for c in cands if c[0]>0]
            if cands:state.setdefault('event_modifiers',{})['card59_unshaded_region']=max(cands)[1]
        if is_capability_active(state,59,rc.EVENT_SHADED) and regions:
            owner=get_capability_owner(state,59)
            if owner==faction:
                state.setdefault('event_modifiers',{})['card59_shaded_region']=sorted(set(regions))[0]
            elif owner is not None:
                defenders=sorted({e.get('region') for e in plan if e.get('region') is not None
                    and (e.get('target')==owner or owner in (e.get('targets') or []))})
                if defenders:
                    best=max(defenders,key=lambda r:(count_pieces(state,r,owner),r))
                    state.setdefault('event_modifiers',{})['card59_shaded_region']=best
    horse_choice.select_for_command=old_policy

trace=[]
original=ex.resolve_battle

def battle(state,region,attacker,defender,**kwargs):
    row=dict(card=state.get('current_card'),region=region,attacker=attacker,defender=defender,
             before_hash=fingerprint(board_copy(state)),
             horse={k:v for k,v in state.get('event_modifiers',{}).items() if k.startswith('card59_')})
    physical = board_copy(state)
    for key in ('card59_unshaded_region', 'card59_shaded_region'):
        physical.get('event_modifiers', {}).pop(key, None)
    row['before_position_without_horse_flags'] = fingerprint(physical)
    trace.append(row)
    result=original(state,region,attacker,defender,**kwargs)
    row.update(result=result,after_hash=fingerprint(board_copy(state)))
    return result
ex.resolve_battle=battle
result=run_batch.play_one((rc.SCENARIO_GREAT_REVOLT,2))
Path('/tmp/fs-horse-trace-'+label+'.json').write_text(json.dumps(dict(label=label, intervention='old Horse selection policy' if label=='counterfactual' else None, source=source_identity(),result=result,trace=trace),indent=2)+'\n')
assert result['completed']
print(json.dumps(dict(label=label,battles=len(trace),winner=result['winner'],hash=result['final_state_sha256'])))
