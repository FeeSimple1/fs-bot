"""Check a valid one-recipient and one-ability grant against the parent signatures."""
from copy import deepcopy
import json
from pathlib import Path
import sys

from test_comparison_event_commands import (
    DecisionPending, _action_transaction, add_ability, board, board_copy, encode,
    play, rally, rc, recruit, scout, session, submit,
)
from fs_bot.state import player_ownership


def run(card, old=None):
    state = board(card)
    player_ownership.install(state, {rc.ROMANS: 'Player 1', rc.AEDUI: 'Player 1'})
    seat = session(state)
    params = {'target_factions': [rc.AEDUI]} if card == 48 else None

    def driver(*args):
        pass

    driver.transaction_checkpoint = seat.checkpoint
    driver.transaction_restore = seat.restore

    def step():
        with _action_transaction(state, driver):
            return play(state, params=params)

    if old is not None:
        seat.data['expected'] = [old['request']]
    try:
        step()
    except DecisionPending:
        assert seat.data['pending'] is not None and seat.error is None, seat.error
    answer = rally(rc.AEDUI_REGION) if card == 48 else add_ability(recruit(rc.PROVINCIA), scout())
    submit(seat, answer)
    result = step()
    seat.finish()
    assert result['executed'], result
    entry = seat.log[0]
    record = {'id': entry['assistant_id'], 'signature': entry['assistant_signature'],
              'request': entry['assistant_request'],
              'action_windows_version': entry.get('assistant_action_windows_version', 0)}
    final = encode(board_copy(state))
    if old is not None:
        assert final == old['final_board'], card
        assert record['signature'] == old['request']['signature'], card
    return {'card': card, 'request': record, 'final_board': final,
            'faction': entry['faction'], 'response': entry['assistant_response']}


path = Path(sys.argv[1])
if sys.argv[2] == 'parent':
    path.write_text(json.dumps([run(card) for card in (48, 52)], indent=2) + '\n')
else:
    previous = json.loads(path.read_text())
    print(json.dumps([{'card': row['card'], 'matched': run(row['card'], row)['card'] == row['card']}
                      for row in previous], indent=2))
