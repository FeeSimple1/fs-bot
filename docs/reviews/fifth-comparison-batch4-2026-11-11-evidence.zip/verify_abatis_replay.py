"""Generate or replay a legal Abatis Battle through the durable seat CLI."""

from contextlib import redirect_stdout
from io import StringIO
import json
from pathlib import Path
import sys
from types import SimpleNamespace

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.engine.agent import LOSS_ORDER, RETREAT
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND, ACTION_EVENT
from fs_bot.state import player_ownership
from fs_bot.state.serialize import decode, encode, load_game, save_game
from fs_bot.state.state_schema import build_initial_state, check_structural_integrity, validate_state
from fs_bot.tests.test_action_window_frontends import leave_timing_unchanged
from fs_bot.tools import llm_seat
from fs_bot.tools.validation_metadata import source_identity


def initial_board():
    state = build_initial_state(rc.SCENARIO_ARIOVISTUS, seed=1)
    owners = player_ownership.assignments(state['scenario'], {rc.ROMANS, rc.AEDUI},
                                          [(rc.ROMANS, rc.AEDUI)])
    player_ownership.install(state, owners)
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    place_piece(state, rc.CARNUTES, rc.ROMANS, rc.LEGION, 4, from_legions_track=True)
    place_piece(state, rc.CARNUTES, rc.AEDUI, rc.WARBAND)
    assert _ally_tribe(state, rc.TRIBE_AULERCI, rc.AEDUI)
    state['current_card'] = 'A64'
    result = execute_decision(state, rc.AEDUI, {'action': ACTION_EVENT, 'player_action': {
        'command': rc.FIRST_DID_EVENT, 'sa': 'No SA', 'details': {
            'card_id': 'A64', 'text_preference': rc.EVENT_UNSHADED,
            'event_params': {'region': rc.CARNUTES}}}})
    assert result['executed'], result
    state.update(current_card=15, current_card_id=15, played_cards=[15], deck=[], next_card=None)
    state['resources'][rc.ROMANS] = 20
    for faction in state['eligibility']:
        state['eligibility'][faction] = rc.ELIGIBLE if faction == rc.ROMANS else rc.INELIGIBLE
    assert validate_state(state) == check_structural_integrity(state) == []
    return state, {'seat': rc.ROMANS, 'player_id': owners[rc.ROMANS],
                   'scenario': state['scenario'], 'seed': 1}


def play(directory, choose_ally):
    state, meta = initial_board()
    directory.mkdir(parents=True, exist_ok=False)
    path = directory / 'save.json'
    save_game(state, path, meta=meta, log=[])
    args = SimpleNamespace(dir=str(directory))
    assert llm_seat.cmd_play(args) == 0
    for _ in range(40):
        leave_timing_unchanged(args)
        state, meta, log = load_game(path, validate=True)
        pending = meta['assistant_session']['pending']
        if pending is None:
            break
        request = decode(pending['request'])
        if request['kind'] == 'turn':
            response = {'action': ACTION_COMMAND, 'player_action': {
                'command': rc.CMD_BATTLE, 'sa': 'No SA', 'regions': [rc.CARNUTES],
                'details': {'battle_plan': [{'region': rc.CARNUTES, 'target': rc.AEDUI}]}}}
        elif request['kind'] == RETREAT:
            response = {'retreat': False}
        else:
            assert request['kind'] == LOSS_ORDER, request
            selected = next((p for p in request['pieces'] if choose_ally and p[0] == rc.ALLY),
                            request['pieces'][0])
            response = [list(selected)]
        assert llm_seat.cmd_submit(SimpleNamespace(dir=args.dir, decision_id=pending['id'],
                                                   response=json.dumps(response))) == 0
    else:
        raise AssertionError('The authored Battle did not complete')

    assert validate_state(state) == check_structural_integrity(state) == []
    assert state['tribes'][rc.TRIBE_AULERCI]['allied_faction'] == (None if choose_ally else rc.AEDUI)
    assert state['markers'][rc.CARNUTES].get(rc.MARKER_ABATIS) == (rc.AEDUI if choose_ally else None)
    return {'source': source_identity(),
            'loss_orders': [decode(row['assistant_request']) for row in log if row.get('reactive') == LOSS_ORDER],
            'recorded_decisions': len(log), 'chose_ally': choose_ally}


def replay(directory, target):
    assert llm_seat.cmd_replay(SimpleNamespace(dir=str(directory), output_dir=str(target))) == 0
    before, _, old_log = load_game(directory / 'save.json', validate=True)
    after, _, new_log = load_game(target / 'save.json', validate=True)
    assert encode(before) == encode(after) and old_log == new_log
    return {'source': source_identity(), 'exact_board_rng_and_log': True,
            'recorded_decisions': len(new_log)}


if __name__ == '__main__':
    mode, path, option = sys.argv[1:]
    output = StringIO()
    try:
        with redirect_stdout(output):
            result = (play(Path(path), option == 'ally') if mode == 'play'
                      else replay(Path(path), Path(option)))
    except BaseException:
        print(output.getvalue()[-4500:], file=sys.stderr)
        raise
    print(json.dumps(result, indent=2))
