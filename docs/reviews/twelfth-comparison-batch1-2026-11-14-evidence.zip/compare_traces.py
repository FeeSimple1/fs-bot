"""Verify paired audited game results and identify their first differing Event."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re
from zipfile import ZipFile


def read_games(contents, edition_key='card_edition'):
    return {(row[edition_key], row['scenario'], row['seed']): row
            for line in contents.splitlines() if (row := json.loads(line))}


def check_trace(trace, game):
    assert len(trace['cards']) == game['cards']
    assert trace['winner'] == game['winner']
    assert trace['final_state_sha256'] == game['final_state_sha256']


def compare(parent, repair, before, after):
    assert parent.keys() == repair.keys()
    expected = {key for key, game in after.items()
                if before[key]['final_state_sha256'] != game['final_state_sha256']}
    assert expected == parent.keys()
    changes = []
    for key in sorted(parent):
        check_trace(parent[key], before[key])
        check_trace(repair[key], after[key])
        for index, (old, new) in enumerate(zip(parent[key]['cards'], repair[key]['cards']), 1):
            assert old['before'] == new['before']
            assert old['card'] == new['card']
            if old['after'] == new['after']:
                continue
            assert old['card'] in (24, 49), (key, index, old['card'])
            for old_decision, new_decision in zip(old['decisions'], new['decisions']):
                assert old_decision['before'] == new_decision['before']
                actor = old_decision['faction']
                assert actor == new_decision['faction']
                old_action = old['actions'][actor]
                new_action = new['actions'][actor]
                if old_action == new_action and old_decision == new_decision:
                    continue
                assert old_decision['decision']['action'] == 'event', (key, old_decision)
                assert actor in ('Romans', 'Aedui'), (key, actor)
                if new_decision['decision']['action'] == 'event':
                    assert old_decision['before_execution'] == new_decision['before_execution']
                    assert old_decision['before_effects'] == new_decision['before_effects']
                    assert old_decision['after_effects'] != new_decision['after_effects']
                break
            else:
                raise AssertionError(f'No differing decision within card {index} for {key}')
            changes.append({
                'edition': key[0], 'scenario': key[1], 'seed': key[2],
                'card_index': index, 'card': old['card'], 'entry_board_sha256': old['before'],
                'old_winner': before[key]['winner'], 'new_winner': after[key]['winner'],
                'old_cards': before[key]['cards'], 'new_cards': after[key]['cards'],
                'first_changed_faction': actor,
                'parent': old, 'repair': new,
            })
            break
        else:
            raise AssertionError(f'No differing card for {key}')
    return {
        'games_changed': len(changes),
        'first_cards': dict(Counter(str(row['card']) for row in changes)),
        'winner_changes': dict(Counter(str(row['card']) for row in changes
                                       if row['old_winner'] != row['new_winner'])),
        'changes': changes,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--audit', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    root = args.evidence
    before = read_games((root/'parent-legacy/games.jsonl').read_text())
    with ZipFile(args.audit) as audit:
        before.update(read_games(audit.read('validation/bots/games.jsonl').decode()))
    after = read_games((root/'legacy/games.jsonl').read_text())
    after.update(read_games((root/'second-edition/games.jsonl').read_text()))
    assert before.keys() == after.keys()
    pairs = {
        label: read_games((root/f'{label}-traces-final.jsonl').read_text(), 'edition')
        for label in ('parent', 'repair')
    }
    legacy = dict(json.loads((root/'balance-baseline-parent.json').read_text())['games'])
    expected = {f'{scenario}|{seed}': {field: game[field] for field in ('winner', 'cards')}
                for (edition, scenario, seed), game in before.items() if edition == 'legacy'}
    assert legacy == expected, 'The original benchmark must exactly match the audited parent.'
    driver = re.findall(r'^\[(.+) seed= *(\d+)\] winner=(.+) \((\d+) cards\)$',
                        (root/'balance-original.log').read_text(), re.M)
    candidate = {f'{scenario}|{seed}': {'winner': winner, 'cards': int(cards)}
                 for scenario, seed, winner, cards in driver}
    assert len(driver) == len(candidate) == 100
    assert candidate == {f'{scenario}|{seed}': {field: game[field] for field in ('winner', 'cards')}
                         for (edition, scenario, seed), game in after.items() if edition == 'legacy'}
    differences = compare(pairs['parent'], pairs['repair'], before, after)
    differences['updated_balance_records'] = sum(legacy[key] != candidate[key] for key in legacy)
    print(json.dumps(differences, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
