"""Bounded diagnostic only: exact scenario setup, pure PR-11 plan preview.

The alarm interrupts this diagnostic without returning a partial game decision.
No production planner cutoff, beam, candidate cap, or heuristic is installed.
"""
import argparse
import cProfile
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import pstats
import signal
import sys
import time

root = Path('/workspace/scratch/534c265c65f4/fs-bot')
sys.path.insert(0, str(root))
from fs_bot import rules_consts as rc
from fs_bot.cards.base_arduenna_np import plan
from fs_bot.engine.game_engine import get_sop_factions
from fs_bot.state.setup import setup_scenario
from fs_bot.state.serialize import encode
from fs_bot.state.state_schema import validate_state
from fs_bot.tools.seat_session import board_copy

ap = argparse.ArgumentParser()
ap.add_argument('--scenario', required=True)
ap.add_argument('--seconds', type=int, default=20)
args = ap.parse_args()
assert os.environ.get('PYTHONHASHSEED') == '0'
out = Path(__file__).resolve().parent
slug = args.scenario.lower().replace(' ', '-').replace('?', '')
optimizer = root / 'fs_bot/cards/base_arduenna_np.py'
before_source = hashlib.sha256(optimizer.read_bytes()).hexdigest()
state = setup_scenario(args.scenario, seed=260)
state['current_card'] = 67
state['non_player_factions'] = set(get_sop_factions(state))
calls = []


def reject_live_input(*a):
    calls.append(True)
    raise AssertionError('Preview attempted live human input')


state['decision_agent'] = reject_live_input
before = encode(board_copy(state))
assert validate_state(state) == []


class DiagnosticTimeout(Exception):
    pass


def expired(*a):
    raise DiagnosticTimeout('Diagnostic interrupted; no plan accepted or executed')


signal.signal(signal.SIGALRM, expired)
profiler = cProfile.Profile()
started = time.monotonic()
result = None
status = 'completed'
error = None
signal.alarm(args.seconds)
profiler.enable()
try:
    result = plan(state)
except DiagnosticTimeout as exc:
    status, error = 'diagnostic-timeout', str(exc)
finally:
    profiler.disable()
    signal.alarm(0)
elapsed = time.monotonic() - started
profiler.dump_stats(str(out / (slug + '.pstats')))
text = io.StringIO()
stats = pstats.Stats(profiler, stream=text)
stats.strip_dirs().sort_stats('cumulative').print_stats(25)
stats.sort_stats('tottime').print_stats(15)
(out / (slug + '-profile.txt')).write_text(text.getvalue())
after_source = hashlib.sha256(optimizer.read_bytes()).hexdigest()
summary = {'diagnostic_only': True, 'acceptance': False, 'scenario': args.scenario,
    'seed': 260, 'current_card': 67, 'python': platform.python_version(),
    'hash_seed': 0, 'timeout_seconds': args.seconds, 'elapsed_seconds': elapsed,
    'status': status, 'error': error,
    'optimizer_sha256_before': before_source, 'optimizer_sha256_after': after_source,
    'source_unchanged_during_diagnostic': before_source == after_source,
    'live_state_and_rng_unchanged': before == encode(board_copy(state)),
    'live_input_calls': len(calls), 'plan': encode(result)}
(out / (slug + '-summary.json')).write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
