"""Reproduce the tenth audit's observed defects on the audited source bytes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    repo = args.repo.resolve()
    env = dict(os.environ, PYTHONPATH=str(repo), PYTHONDONTWRITEBYTECODE='1')
    identity = json.loads(subprocess.check_output([
        sys.executable, '-c',
        'import json; from fs_bot.tools.validation_metadata import source_identity; '
        'print(json.dumps(source_identity()))'], cwd=repo, env=env))
    baseline = json.loads((root / 'validation/source.json').read_text())
    assert identity['source_sha256'] == baseline['source_sha256'], (
        'Use the audited source revision: ' + baseline['commit'], identity)
    protected = json.loads((root / 'validation/protected-sources.json').read_text())
    for path, digest in protected.items():
        assert hashlib.sha256((repo / path).read_bytes()).hexdigest() == digest, path

    rows = []
    specs = [(lane, root / lane / ('probe_' + lane + '.py'), root / lane / 'results.json')
             for lane in ('battle', 'bots', 'events', 'frontend', 'lifecycle')]
    specs.append(('quarters_replay', root / 'frontend/probe_quarters_replay.py',
                  root / 'frontend/quarters-replay-results.json'))
    for lane, probe, expected_default in specs:
        assert probe.exists(), probe
        outputs = []
        for seed in ('0', '987'):
            # Preserve the newly exposed Quarters prompt variability rather
            # than erasing request fields. Its replay consequence is audited.
            expected_path = (root / lane / f'results.hash{seed}.json' if lane == 'lifecycle'
                             else expected_default)
            expected = expected_path.read_bytes()
            with tempfile.TemporaryDirectory(prefix='falling-sky-audit10-') as temp:
                run = subprocess.run([sys.executable, str(probe), '--repo', str(repo)],
                                     cwd=temp, env=dict(env, PYTHONHASHSEED=seed),
                                     capture_output=True, timeout=180)
            assert run.returncode == 0, (lane, seed, run.stderr.decode())
            assert not run.stderr, (lane, seed, run.stderr.decode())
            json.loads(run.stdout)
            assert run.stdout == expected, (lane, seed, 'differs from preserved witness')
            outputs.append(run.stdout)
        identical = outputs[0] == outputs[1]
        if lane != 'lifecycle':
            assert identical, lane
        rows.append({'lane': lane, 'hash_seeds': [0, 987],
                     'byte_identical': identical, 'preserved_output_matches': True,
                     'sha256_by_hash_seed': {seed: hashlib.sha256(output).hexdigest()
                                            for seed, output in zip(('0', '987'), outputs)}})
    assert len(rows) == 6, 'The archive must include five lanes and the separate replay witness'
    print(json.dumps({'source_sha256': identity['source_sha256'],
                      'protected_files_verified': len(protected),
                      'witnesses': rows}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
