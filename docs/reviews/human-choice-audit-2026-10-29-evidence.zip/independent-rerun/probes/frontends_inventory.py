"""Bounded shared-interface audit: routes, pending kinds, and printed cards.

This checks routing/transport, not each rule-specific request payload. The
specialized audit partitions evaluate the substantive legality of choices.
"""
import ast
import copy
import io
import json
from pathlib import Path

import fs_bot
from fs_bot import rules_consts as rc
from fs_bot.cards.card_data import get_base_event_card_ids, get_ariovistus_event_card_ids
from fs_bot.cards.card_text import get_card_text
from fs_bot.cli.display import HumanTurnDisplay, format_decision_context
from fs_bot.engine.agent import AGREEMENT, HARASSMENT_LOSS, LOSS_ORDER, RETREAT
from fs_bot.state.setup import setup_scenario
from fs_bot.state.serialize import encode, decode
from fs_bot.tools.seat_session import SeatSession, DecisionPending, board_copy

ROOT = Path(fs_bot.__file__).resolve().parents[1]
CONSTANTS = dict(AGREEMENT=AGREEMENT, HARASSMENT_LOSS=HARASSMENT_LOSS,
                 LOSS_ORDER=LOSS_ORDER, RETREAT=RETREAT)
KINDS = sorted([
    'agreement', 'ambacti_removal', 'battle_elite', 'council_choice',
    'council_selection', 'diviciacus_pieces', 'force_cohort', 'free_action',
    'frumentum_action', 'frumentum_amount', 'harassment_loss', 'kinship',
    'loss_order', 'march_cohort', 'quarters_payment', 'quarters_plan',
    'quarters_provincia', 'raid_intimidate', 'retreat', 'spring_leader',
    'supply_refusal', 'trade_region', 'voluntary_removal', 'winter_campaign',
    'winter_uprising_placement', 'winter_uprising_timing'])


def routed(path):
    tree = ast.parse((ROOT / path).read_text())
    found = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Compare) or not isinstance(node.left, ast.Name) or node.left.id != 'kind':
            continue
        if not isinstance(node.ops[0], (ast.Eq, ast.In)):
            continue
        rhs = node.comparators[0]
        values = rhs.elts if isinstance(rhs, (ast.Tuple, ast.List)) else [rhs]
        for value in values:
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                found.add(value.value)
            elif isinstance(value, ast.Name) and value.id in CONSTANTS:
                found.add(CONSTANTS[value.id])
    return sorted(found)


cli = routed('fs_bot/cli/reactive.py')
assistant = routed('fs_bot/tools/seat_session.py')
assert set(KINDS) <= set(cli)
assert set(KINDS + ['turn']) <= set(assistant)

pending_results = []
for kind in KINDS + ['turn']:
    state = setup_scenario(rc.SCENARIO_GREAT_REVOLT, seed=7)
    session = SeatSession(state, {'seat': rc.ROMANS}, [], HumanTurnDisplay(io.StringIO()))
    request = {'kind': kind}
    if kind == 'turn':
        request.update(options=['pass'], position='1st_eligible')
    before = encode(board_copy(state))
    for _ in range(2):
        try:
            session.ask(state, rc.ROMANS, request)
        except DecisionPending:
            pass
        else:
            raise AssertionError(f'{kind} did not pause')
        assert session.data['pending']['id'] == 'd000001'
        assert decode(session.data['pending']['request'])['kind'] == kind
        assert encode(board_copy(state)) == before
        assert not session.data['journal'] and not session.log
    pending_results.append(kind)

cards = []
for scenario in rc.ALL_SCENARIOS:
    identities = (get_base_event_card_ids() if scenario in rc.BASE_SCENARIOS
                  else get_ariovistus_event_card_ids())
    for edition in ('legacy', 'original', 'second-edition'):
        state = setup_scenario(scenario, seed=7, card_edition=edition)
        for index, card in enumerate(identities):
            next_card = identities[(index + 1) % len(identities)]
            state['current_card'] = card
            state['next_card'] = next_card
            before = encode(state)
            shown = format_decision_context(state)
            for identity in (card, next_card):
                text = get_card_text(identity, scenario, edition)
                assert text, (scenario, edition, identity)
                assert all(line in shown for line in text.splitlines())
            assert encode(state) == before
        cards.append({'scenario': scenario, 'edition': edition,
                      'current_upcoming_pairs': len(identities)})

result = {'cli_reactive_routes': cli, 'assistant_routes': assistant,
          'missing_reactive_routes': [], 'missing_response_pending_stable': pending_results,
          'full_current_upcoming_card_text': cards,
          'card_pair_count': sum(item['current_upcoming_pairs'] for item in cards),
          'limitations': ['Missing-input tests exercise transport before payload-specific validation.',
                          'Card-text checks verify complete supplied text rendering, not rule implementation.']}
text = json.dumps(result, indent=2)
Path(__file__).with_suffix('.out.json').write_text(text + '\n')
print(text)
