# Seventh Falling Sky comparison evidence

Audited commit `c67d501711471bf790d805c017c2125b2c254639`; source SHA-256 `2ae5b3cedb16cfed6969442ebe9fefba99ed0f03933cd30c78a4deb6c002e801`. Nine open repair groups, two high and seven medium. Gameplay code is unchanged.

Extract this archive and run `python run_probes.py --repo /path/to/fs-bot --out /path/to/new-results` with the audited source and Python 3.12.14. It verifies the source digest and all five JSON observations. Assertions pin defects plus controls; this is not a post-repair acceptance suite. `PYTHONPATH=/path/to/fs-bot python validation/verify_validation.py validation` checks the archived complete-game evidence. `SHA256SUMS.json` covers every other archive member.

The report and ledger document sources, exact scope, controls, prior-finding distinctions and suggested repairs. Per-partition coverage files record rejected leads. Root reran every script under two hash seeds; peer review files preserve independent checks. No incidence or aggregate outcome estimate is claimed.
