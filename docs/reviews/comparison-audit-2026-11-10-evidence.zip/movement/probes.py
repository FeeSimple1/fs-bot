"""Observed defects at b23c8cd, with legal controls and census checks."""
from copy import deepcopy
import json

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces
from fs_bot.engine.execute import execute_decision
from fs_bot.state.state_schema import build_initial_state, validate_state
from fs_bot.tools.seat_session import validate_response


def state():
    board = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=2)
    board['resources'].update({rc.ROMANS: 20, rc.AEDUI: 20, rc.ARVERNI: 20})
    return board


def run(board, faction, action, plan):
    assert validate_state(board) == []
    decision = {'action': action, 'player_action': plan}
    request = {'kind': 'turn', 'faction': faction, 'options': [action]}
    assert validate_response(board, request, decision) == decision
    result = execute_decision(board, faction, decision)
    assert result['executed'] and not result.get('errors'), result
    assert validate_state(board) == []
    return result


def rejected(board, faction, action, plan):
    try:
        validate_response(board, {'kind': 'turn', 'faction': faction, 'options': [action]},
                          {'action': action, 'player_action': plan})
    except ValueError as error:
        return str(error)
    raise AssertionError('The control plan should have been rejected')


def duplicate_battle():
    board = state()
    place_piece(board, rc.CARNUTES, rc.ROMANS, rc.LEGION, 2, from_legions_track=True)
    for enemy in (rc.ARVERNI, rc.AEDUI):
        place_piece(board, rc.CARNUTES, enemy, rc.WARBAND)
    plan = {'command': rc.CMD_BATTLE, 'details': {'battle_plan': [
        {'region': rc.CARNUTES, 'target': rc.ARVERNI},
        {'region': rc.CARNUTES, 'target': rc.AEDUI}]}}
    control, legal = deepcopy(board), deepcopy(plan)
    legal['details']['battle_plan'].pop()
    single = run(control, rc.ROMANS, 'limited_command', legal)
    result = run(board, rc.ROMANS, 'limited_command', plan)
    assert single['count'] == 1 and result['count'] == 2
    assert count_pieces(control, rc.CARNUTES, rc.AEDUI) == 1
    assert count_pieces(board, rc.CARNUTES, rc.AEDUI) == 0
    return {'legal_control': single, 'observed': result,
            'resources_spent': 20 - board['resources'][rc.ROMANS]}


def self_battle():
    board = state()
    place_piece(board, rc.CARNUTES, rc.ROMANS, rc.AUXILIA, 4)
    result = run(board, rc.ROMANS, 'command', {'command': rc.CMD_BATTLE,
        'details': {'battle_plan': [{'region': rc.CARNUTES, 'target': rc.ROMANS}]}})
    survivors = count_pieces(board, rc.CARNUTES, rc.ROMANS, rc.AUXILIA)
    assert survivors == 1
    return {'observed': result, 'before_auxilia': 4, 'after_auxilia': survivors}


def extra_march_origins():
    board = state()
    place_piece(board, rc.CARNUTES, rc.AEDUI, rc.WARBAND)
    place_piece(board, rc.MANDUBII, rc.AEDUI, rc.WARBAND)
    canonical = {'command': rc.CMD_MARCH, 'details': {
        'origins': [rc.CARNUTES, rc.MANDUBII], 'destinations': [rc.VENETI, rc.TREVERI],
        'routes': {rc.CARNUTES: [rc.VENETI], rc.MANDUBII: [rc.TREVERI]}}}
    rejection = rejected(board, rc.AEDUI, 'limited_command', canonical)
    explicit = {'command': rc.CMD_MARCH, 'details': {'explicit_moves': [
        {'origin': rc.CARNUTES, 'path': [rc.VENETI]},
        {'origin': rc.MANDUBII, 'path': [rc.TREVERI]}]}}
    extra = deepcopy(canonical)
    extra['details'].update(origins=[rc.CARNUTES], destinations=[rc.VENETI],
        routes={rc.CARNUTES: [rc.VENETI]}, extra_groups=[{
            'origin': rc.MANDUBII, 'route': [rc.TREVERI], 'group': {rc.WARBAND: 1}}])
    results = {}
    for name, plan in [('explicit_moves', explicit), ('extra_groups', extra)]:
        trial = deepcopy(board)
        result = run(trial, rc.AEDUI, 'limited_command', plan)
        assert len(result['origin_costs']) == 2 and len(result['marches']) == 2
        results[name] = result
    return {'canonical_rejected': rejection, 'alternate_shapes_accepted': results}


def britannia_sa():
    board = state()
    place_piece(board, rc.BRITANNIA, rc.AEDUI, rc.WARBAND)
    place_piece(board, rc.PROVINCIA, rc.AEDUI, rc.WARBAND)
    plan = {'command': rc.CMD_MARCH, 'sa': rc.SA_TRADE, 'sa_timing': 'after',
        'details': {'explicit_moves': [{'origin': rc.BRITANNIA, 'path': [rc.MORINI]}]}}
    canonical = deepcopy(plan)
    canonical['details'] = {'origins': [rc.BRITANNIA], 'destinations': [rc.MORINI],
                            'routes': {rc.BRITANNIA: [rc.MORINI]}}
    rejection = rejected(board, rc.AEDUI, 'command_sa', canonical)
    result = run(board, rc.AEDUI, 'command_sa', plan)
    assert result['sa_execution']['executed']
    assert board['resources'][rc.AEDUI] == 25
    return {'canonical_rejected': rejection, 'alternate_shape_accepted': result}


def duplicate_devastate():
    board = state()
    place_piece(board, rc.CARNUTES, rc.ARVERNI, rc.WARBAND, 12)
    place_piece(board, rc.CARNUTES, rc.ARVERNI, rc.LEADER, leader_name=rc.VERCINGETORIX)
    place_piece(board, rc.CARNUTES, rc.ROMANS, rc.AUXILIA, 9)
    place_piece(board, rc.VENETI, rc.ARVERNI, rc.WARBAND)
    plan = {'command': rc.CMD_RAID, 'sa': rc.SA_DEVASTATE, 'sa_timing': 'after',
        'sa_regions': [rc.CARNUTES, rc.CARNUTES],
        'details': {'raid_plan': [{'region': rc.VENETI, 'target': None}]}}
    control, legal = deepcopy(board), deepcopy(plan)
    legal['sa_regions'].pop()
    single = run(control, rc.ARVERNI, 'command_sa', legal)
    result = run(board, rc.ARVERNI, 'command_sa', plan)
    def counts(b):
        return [count_pieces(b, rc.CARNUTES, rc.ARVERNI, rc.WARBAND),
                count_pieces(b, rc.CARNUTES, rc.ROMANS, rc.AUXILIA)]
    assert counts(control) == [9, 6] and counts(board) == [7, 4]
    return {'legal_control': single, 'observed': result,
            'counts_after_one': counts(control), 'counts_after_duplicate': counts(board)}


if __name__ == '__main__':
    print(json.dumps({'duplicate_battle': duplicate_battle(), 'self_battle': self_battle(),
                      'extra_march_origins': extra_march_origins(),
                      'britannia_sa': britannia_sa(),
                      'duplicate_devastate': duplicate_devastate()}, indent=2))
