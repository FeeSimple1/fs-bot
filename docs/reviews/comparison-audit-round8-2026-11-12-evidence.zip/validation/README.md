# Eighth comparison audit baseline validation

These fresh runs test unchanged Falling Sky commit
`e62b0360c1b91032741ef8f6afa4d247c8ea2437`, with Python-source SHA-256
`3c047ebcfef915efef8e1da308cd63484b1e6c735b8aba8e5c095de2c5d106b9`
over 611 Python files. The initial source tree is clean. Python is 3.12.14;
pytest is 9.2.0 and pytest-xdist is 3.8.0.

The recorded commands run from the repository root. All output and audit-only
scripts live outside the repository, at the sibling `audit8-work/validation`.
Use a fresh output directory for a new run. The commands below spell out the
same invocation captured by `run_command.py` in each `*-execution.json` record.

```sh
PYTHONHASHSEED=0 PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m pytest -q -n 5 --junitxml=../audit8-work/validation/pytest.xml > ../audit8-work/validation/pytest.log 2>&1
PYTHONHASHSEED=0 PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m fs_bot.tools.run_batch --seeds 45-48 --card-edition second-edition --workers 2 --out ../audit8-work/validation/bots-second > ../audit8-work/validation/bots-second.log 2>&1
PYTHONHASHSEED=0 PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m fs_bot.tools.player_fuzz --seeds 45-48 --card-edition second-edition --out ../audit8-work/validation/fuzz0.json > ../audit8-work/validation/fuzz0.log 2>&1
PYTHONHASHSEED=987 PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m fs_bot.tools.player_fuzz --seeds 45-48 --card-edition second-edition --out ../audit8-work/validation/fuzz987.json > ../audit8-work/validation/fuzz987.log 2>&1
PYTHONPATH=. .venv/bin/python ../audit8-work/validation/verify_validation.py ../audit8-work/validation
```

`verify_validation.py` checks exact scenario/seed/edition coverage, every bot
completion and audit flag, errors, integrity findings, final-state hashes,
eligible four-entry engine and recomputed rankings, winner agreement, diagnostic
severity and counts, source identities, tool exit statuses, and full-suite JUnit
results. It compares both mixed-player JSON files and stdout byte-for-byte,
checks every mixed case and recomputes the aggregate replay digest. It retains
zero- or nonzero-failure findings in `summary.json` and exits nonzero on a failed
check.

Seeds 45–48 are held out relative to the latest seventh-audit sample 41–44.
Each matrix contains 20 distinct cases, four for each of the five scenarios.
The mixed runner executes each case twice for replay at each hash seed, for 80
executions of 20 distinct cases across the two hash runs. Randomized reactions,
Events, and determinism checks are enabled. Soft partial plans are reported
separately from hard findings.

Bot `diagnostics` counts grouped per-game rows, while `diagnostic_incidents`
sums each row's `count`; these denominators are intentionally separate. Bot
winners are factions at game end. After a Gallic War Interlude, Arverni
represents the original German seat.

No production or reference files were modified. No legacy balance matrix was
run and no baseline was refreshed. `baseline-identity.json` records the
unchanged baseline file digest. This sample establishes these run results;
it does not establish exhaustive rule coverage, policy quality, or human
balance. Prior GitHub workflow results, when recorded by the main audit,
remain separate from these fresh local runs.
