# Engineering comparison record

Falling Sky source: `ae238c6482a792dda98af4f1f9b11abf820a3964`.
Liberty or Death source: `2991ea279062773548ec390a1da75f3e85381702`.
Both checkouts were fetched and matched their remote main branches before review.

This comparison uses the owner's continuing authorization from the preceding
comparison audits. Liberty or Death contributes engineering review patterns;
all Falling Sky rules conclusions cite the supplied Falling Sky/Ariovistus
references and the project's thirteen adopted provisional rulings.

Reviewed comparator implementation and regressions:

- `lod_ai/engine.py:885–898`: faction-specific action allowances and separation
  of ordinary turns from Event grants. This motivates testing the actual
  consuming path and actor, rather than relying on a helper result alone.
- `lod_ai/engine.py:900–945`: action legality consumes actual affected spaces
  and actual Special Activity use; completed result metadata records use.
  Falling Sky's completed CLI summary still consumes the original forecast,
  as UI10-01 demonstrates.
- `lod_ai/engine.py:947–970`: detached action simulation and explicit commit
  of accepted state/context. The audit compares forecasts with public live
  execution and checks physical/structural integrity around both paths.
- `lod_ai/engine.py:1642–1678`: Event resolution attributes the active actor,
  immediately drains granted actions and restores the prior actor. This
  motivates following a free-action grant through its actual beneficiary,
  planner and executor, as in BM10-01 and UI10-02.
- `tests/test_bot_bs_error_rollback.py`: failure injection distinguishes a
  real exception from ordinary legal no-plan results and checks board,
  shared context and RNG preservation. Tenth-audit sampled diagnostics are
  retained as legal declines; they are not relabeled as defects.

`coin-implementation-lessons.md` and `agents.md` were also reviewed for
implementation and audit discipline. No comparator game rule is imported.
The directed findings are source-derived Falling Sky defects, not claims
that these repositories should implement identical rules or data structures.
