# Root review and validation scope

The audited checkout was clean at `bd30d522e8baa2d303b9e372d7d9c550351e91a5`.
Liberty or Death was cloned at `2991ea279062773548ec390a1da75f3e85381702`.
Its `coin-implementation-lessons.md`, `docs/human_mode_audit.md`,
`docs/audit_set_but_never_applied_s76.md`, and eligibility helper supplied
implementation patterns, never Falling Sky rules.

Five partitions examined bot decisions, Battle/Commands, Event effects,
human/free-action dispatch, and seasonal/scenario transitions. A separate
reviewer checked sources, prior-ledger overlap and fixture legality, and
reran the accepted probes. The root reviewer read the final findings and
their relevant supplied rule text, reran the portable evidence, and checked
every integrated validation record.

The original 50 and subsequent 21, 15 and 16 repair-group ledgers are all
closed. New findings must identify a distinct behavior/path. A repair to one
consumer does not establish that every consumer of a rule is correct. Related
symptoms with the same repair mechanism are counted together.

Root eligibility review found no new confirmed defect. Inspected the live
Sequence of Play loop, end-of-card forced-ineligibility/stay-eligible handling,
printed Chapter 2 section 2.3.6 and Chapter 5 section 5.1.2, and existing
production-path tests for card 6/14/40/48, A19/A23/A34/A40/A53 and Council.
The existing tests cover immediate exclusion, next-card exclusion, one-shot
retention and a later Event overriding an earlier eligibility penalty. This
was bounded source review plus the full-suite run, not an exhaustive cross-
product of cards and timing states.

The unchanged production source passed all 9,806 tests. Fresh second-edition
seeds 29–32 cover all five scenarios in both audited all-bot and mixed-seat
play. All 20 bot records have complete valid four-faction rankings, clean
piece/structure checks, no errors and no nonlegal diagnostics. Two bot games
reach the Interlude. All 20 mixed cases complete, have no hard findings, and
match byte-for-byte across hash seeds 0 and 987 including their replay runs.
Each mixed run records 768 human turns, 176 Event attempts, 166 executed
Events and two soft partial plans. These samples do not cover every targeted
boundary. No balance baseline was changed or newly sampled in this audit.

Optimates' ordinal Victory Phase counting is excluded from the confirmed
count because the supplied text does not expressly resolve whether the
skipped Pax Gallica first phase counts. The Interlude deck-size lead was
rejected after reviewing the supplied Setup sequence and conditional wording.
Earlier source questions and separately tracked Circumvallation work are not
recounted as new findings.

No production code, tests, reference documents, canonical constants, or
balance fixtures were changed. The deliverables are a dated report, finding
ledger, reproducible evidence and current documentation links.
