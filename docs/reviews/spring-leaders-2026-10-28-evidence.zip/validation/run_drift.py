"""Run the already-authorized prioritized changed-winner causal localizations."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
PYTHON = ROOT.parent / "fs-test-venv/bin/python"
CURRENT = ROOT.parent / "fs-bot"


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attempt", required=True)
    parser.add_argument("--max-priority", type=int, default=1,
                        help="0=only beyond-band changed winners;1=all changed winners")
    args = parser.parse_args()
    run = ROOT / args.attempt
    plan = json.loads((run / "drift-plan.json").read_text())
    out = run / "drift-review"
    out.mkdir(exist_ok=True)
    environment = dict(os.environ, PYTHONHASHSEED="0", PYTHONUNBUFFERED="1")
    summaries = []

    def command(name, argv, cwd, folder):
        started = time.monotonic()
        status = {"argv": argv, "cwd": str(cwd), "environment": {"PYTHONHASHSEED": "0"},
                  "started_utc": datetime.now(timezone.utc).isoformat(), "exit_code": None}
        write(folder / f"{name}.status.json", status)
        with (folder / f"{name}.log").open("x") as log:
            result = subprocess.run(argv, cwd=cwd, env=environment, stdout=log, stderr=subprocess.STDOUT)
        status.update(exit_code=result.returncode, elapsed_seconds=time.monotonic() - started,
                      ended_utc=datetime.now(timezone.utc).isoformat())
        write(folder / f"{name}.status.json", status)
        return status

    for case in plan["cases"]:
        if case["priority"] > args.max_priority or not case["full_final_state_changed"]:
            continue
        slug = case["scenario"].lower().replace("?", "").replace(" ", "-") + f"-{case['seed']:02}"
        folder = out / slug
        if (folder / "comparison.json").exists():
            prior = json.loads((folder / "comparison.json").read_text())
            assert prior["current_source"]["source_sha256"] == plan["current_source"]["source_sha256"]
            assert prior["baseline_source"]["source_sha256"] == plan["baseline_source_sha256"]
            summaries.append({"case": case, "comparison": str(folder / "comparison.json"), "reused": True})
            continue
        if folder.exists():
            raise RuntimeError(f"Partial trace folder exists; preserve/investigate before continuing: {folder}")
        folder.mkdir()
        old_path = Path(case["baseline_archive"]) if case["baseline_archive"] else folder / "baseline.json.gz"
        new_path = folder / "current.json.gz"
        jobs = []
        for name, cwd, digest, expected, path in (
                ("baseline", Path(plan["baseline_worktree"]), plan["baseline_source_sha256"], case["baseline"]["final_state_sha256"], old_path),
                ("current", CURRENT, plan["current_source"]["source_sha256"], case["current"]["final_state_sha256"], new_path)):
            if name == "baseline" and case["baseline_archive"]:
                continue
            argv = [str(PYTHON), str(ROOT / "compact_trace.py"), "--scenario", case["scenario"], "--seed", str(case["seed"]),
                    "--source-sha256", digest, "--expected-final-sha256", expected, "--out", str(path)]
            jobs.append((name, argv, cwd, folder))
        with ThreadPoolExecutor(max_workers=2) as pool:
            statuses = list(pool.map(lambda j: command(*j), jobs))
        if any(s["exit_code"] != 0 for s in statuses):
            print(f"TRACE FAILURE {case['scenario']} seed {case['seed']}; preserved {folder}", flush=True)
            return 1
        argv = [str(PYTHON), str(ROOT / "compare_traces.py"), "--baseline", str(old_path), "--current", str(new_path),
                "--baseline-source-sha256", plan["baseline_source_sha256"],
                "--baseline-final-sha256", case["baseline"]["final_state_sha256"],
                "--current-source-sha256", plan["current_source"]["source_sha256"],
                "--current-final-sha256", case["current"]["final_state_sha256"],
                "--out", str(folder / "comparison.json")]
        compare_status = command("compare", argv, CURRENT, folder)
        if compare_status["exit_code"] != 0:
            print(f"COMPARE FAILURE {case['scenario']} seed {case['seed']}; preserved {folder}", flush=True)
            return 1
        comparison = json.loads((folder / "comparison.json").read_text())
        first = comparison.get("first_state_or_decision_difference") or comparison["first_difference"] or {}
        brief = {"scenario": case["scenario"], "seed": case["seed"], "priority": case["priority"],
                 "old_winner": case["baseline"]["winner"], "new_winner": case["current"]["winner"],
                 "first_boundary": first.get("current_boundary"), "changed_domains": first.get("changed_state_domains"),
                 "rng_changed": first.get("rng_changed"), "same_boundary": first.get("same_boundary"),
                 "comparison": str(folder / "comparison.json"), "source_reviewed": False}
        summaries.append(brief)
        write(out / "progress.json", {"status": "localization only; source review pending", "cases": summaries})
        print(json.dumps(brief), flush=True)
    write(out / "runner-status.json", {"exit_code": 0, "max_priority": args.max_priority,
          "status": "completed selected localizations; source review and any baseline decision remain separate", "cases": summaries})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
