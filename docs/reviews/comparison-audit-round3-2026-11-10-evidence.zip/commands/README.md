# Command and Battle audit evidence

Audited `3c23a3414c3e870e274ef63c278db8cb3f1ee747`. No gameplay edits.

Run `python probe_commands.py /path/to/fs-bot`.

The script asserts the current defective outcomes for four finding groups,
using the durable turn validator and normal execution. Every starting board
passes inventory census and structural integrity. The Entreat witness then
asserts its exact expected corruption report. Positive controls preserve
legal Entreat targets and ordinary combat/Retreat behavior.

`findings.json` records rules, locations, comparison patterns, scope and
prior-ledger distinctions. `observations.json` is the captured successful run.
