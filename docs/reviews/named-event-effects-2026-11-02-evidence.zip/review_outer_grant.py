"""Independent BE-04 compatibility witness for the existing outer grant window."""
import hashlib
import json
import pathlib
import sys
repo = pathlib.Path(sys.argv[1]).resolve()
sys.path.insert(0, str(repo))
from fs_bot import rules_consts as rc
from fs_bot.engine.execute import _execute_event
from fs_bot.state.state_schema import build_initial_state
state = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=816)
state['executing_faction'] = rc.BELGAE
state['non_player_factions'] = set()
state['event_params'] = {}
action = {'command': rc.FIRST_DID_EVENT, 'details': {'card_id': 26,
    'text_preference': rc.EVENT_SHADED,
    'event_params': {'stage_timing_actions': {'grant.card_26_arverni_rally': []}}}}
helper = repo / 'fs_bot/cards/named_event_effects.py'
print(json.dumps({'repo': str(repo), 'helper_sha256': hashlib.sha256(helper.read_bytes()).hexdigest() if helper.exists() else None,
    'result': _execute_event(state, rc.BELGAE, action, human=True)}, sort_keys=True, indent=2))
