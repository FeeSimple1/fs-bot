"""Reproduce soft partials with full action details, without repository writes."""
from collections import Counter
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path.cwd()))
from fs_bot.tools import player_fuzz as fuzz
from fs_bot.tools.validation_metadata import source_identity
root=Path(__file__).resolve().parent
expected=json.loads((root/'freeze.json').read_text())['source_sha256']
before=source_identity()
assert before['source_sha256']==expected
partial_cases=[r for r in json.loads((root/'fuzz-legacy-hash0.json').read_text())['records'] if r['partial']]
original=fuzz._compare_dry_vs_live
captured=[]
def collect(res,seats,expected_signatures):
    seen=Counter()
    for cr in (res or {}).get('card_results', []):
        for faction,rec in ((cr.get('turn_result') or {}).get('actions_taken') or {}).items():
            if faction not in seats: continue
            k=(cr.get('card'),faction); key=k+(seen[k],); seen[k]+=1
            live=fuzz._sig(rec.get('execution')); want=expected_signatures.get(key)
            if live is not None and live==want and (want[3] or (want[4] and want[4][1])):
                captured.append({'card':cr.get('card'),'faction':faction,'record':rec})
    return original(res,seats,expected_signatures)
fuzz._compare_dry_vs_live=collect
records=[]
for case in partial_cases:
    captured.clear()
    result=fuzz.play_game(case['scenario'],case['seed'],card_edition=case['card_edition'])
    assert result==case,(result,case)
    records.append({'result':result,'partial_records':list(captured)})
after=source_identity()
assert before==after
out={'source_before':before,'source_after':after,'cases':records,'explanation':'The random policy intentionally injects Resource gifts after forming a plan. A gift may leave a later planned Rally unaffordable. A matching dry/live partial with full-game completion and no findings is reported separately, not counted as a successful execution of every proposed plan.'}
(root/'fuzz-soft-partial-diagnosis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'cases':len(records),'partials':sum(r['result']['partial'] for r in records),'source_stable':True}))
