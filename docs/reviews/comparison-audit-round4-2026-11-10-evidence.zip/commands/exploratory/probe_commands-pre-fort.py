import json
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece,count_pieces
from fs_bot.cards.capabilities import activate_capability
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND
from fs_bot.state.state_schema import build_initial_state,validate_state,check_structural_integrity
from fs_bot.tools.seat_session import validate_response

def motivation(n, active=True):
    state=build_initial_state(rc.SCENARIO_ARIOVISTUS,seed=1)
    state['non_player_factions']=set()
    state['resources'][rc.BELGAE]=20
    place_piece(state,rc.CARNUTES,rc.BELGAE,rc.WARBAND,8)
    place_piece(state,rc.CARNUTES,rc.GERMANS,rc.WARBAND,n)
    if active: activate_capability(state,'A33',rc.EVENT_SHADED)
    before={'census':validate_state(state),'structure':check_structural_integrity(state)}
    response={'action':ACTION_COMMAND,'player_action':{'command':rc.CMD_BATTLE,'sa':'No SA','regions':[rc.CARNUTES],'details':{'battle_plan':[{'region':rc.CARNUTES,'target':rc.GERMANS}]}}}
    validate_response(state,{'kind':'turn','faction':rc.BELGAE,'options':[ACTION_COMMAND]},response)
    result=execute_decision(state,rc.BELGAE,response)
    out={'germans_start':n,'capability':active,'before':before,'germans_end':count_pieces(state,rc.CARNUTES,rc.GERMANS),'belgae_end':count_pieces(state,rc.CARNUTES,rc.BELGAE),'after':{'census':validate_state(state),'structure':check_structural_integrity(state)},'result':result}
    assert result['executed'] and not result.get('errors')
    assert not before['census'] and not before['structure']
    assert not out['after']['census'] and not out['after']['structure']
    return out

cases=[motivation(2),motivation(2,False),motivation(3)]
assert [(c['germans_end'],c['belgae_end']) for c in cases]==[(0,7),(0,8),(1,7)]


from fs_bot.engine.execute import _decide_defender_retreat
from fs_bot.board.control import refresh_all_control

def np_retreat(defenders):
    state=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=1)
    state['non_player_factions']={rc.AEDUI}
    state['resources'][rc.BELGAE]=20
    place_piece(state,rc.CARNUTES,rc.BELGAE,rc.WARBAND,8)
    place_piece(state,rc.CARNUTES,rc.AEDUI,rc.WARBAND,defenders)
    place_piece(state,rc.VENETI,rc.AEDUI,rc.WARBAND,1)
    refresh_all_control(state)
    before={'census':validate_state(state),'structure':check_structural_integrity(state)}
    declaration=_decide_defender_retreat(state,rc.CARNUTES,rc.BELGAE,rc.AEDUI,False)
    response={'action':ACTION_COMMAND,'player_action':{'command':rc.CMD_BATTLE,'sa':'No SA','regions':[rc.CARNUTES],'details':{'battle_plan':[{'region':rc.CARNUTES,'target':rc.AEDUI}]}}}
    validate_response(state,{'kind':'turn','faction':rc.BELGAE,'options':[ACTION_COMMAND]},response)
    result=execute_decision(state,rc.BELGAE,response)
    out={'defenders_start':defenders,'before':before,'declaration':declaration,'aedui_battle_end':count_pieces(state,rc.CARNUTES,rc.AEDUI),'aedui_destination_end':count_pieces(state,rc.VENETI,rc.AEDUI),'belgae_end':count_pieces(state,rc.CARNUTES,rc.BELGAE),'after':{'census':validate_state(state),'structure':check_structural_integrity(state)},'result':result}
    assert result['executed'] and not result.get('errors')
    assert not before['census'] and not before['structure']
    assert not out['after']['census'] and not out['after']['structure']
    return out

retreat_cases=[np_retreat(n) for n in (6,4,8)]
assert [(c['aedui_battle_end'],c['aedui_destination_end'],c['belgae_end']) for c in retreat_cases]==[(2,1,7),(0,3,8),(4,1,6)]


def np_hidden_retreat(safe_destination=False):
    state=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=1)
    state['non_player_factions']={rc.AEDUI}
    state['resources'][rc.ROMANS]=20
    place_piece(state,rc.CARNUTES,rc.ROMANS,rc.AUXILIA,4)
    place_piece(state,rc.CARNUTES,rc.AEDUI,rc.WARBAND,2)
    if safe_destination: place_piece(state,rc.VENETI,rc.AEDUI,rc.WARBAND,1)
    refresh_all_control(state)
    before={'census':validate_state(state),'structure':check_structural_integrity(state)}
    declaration=_decide_defender_retreat(state,rc.CARNUTES,rc.ROMANS,rc.AEDUI,False)
    response={'action':ACTION_COMMAND,'player_action':{'command':rc.CMD_BATTLE,'sa':'No SA','regions':[rc.CARNUTES],'details':{'battle_plan':[{'region':rc.CARNUTES,'target':rc.AEDUI}]}}}
    validate_response(state,{'kind':'turn','faction':rc.ROMANS,'options':[ACTION_COMMAND]},response)
    result=execute_decision(state,rc.ROMANS,response)
    out={'safe_destination':safe_destination,'before':before,'declaration':declaration,'aedui_battle_end':count_pieces(state,rc.CARNUTES,rc.AEDUI),'after':{'census':validate_state(state),'structure':check_structural_integrity(state)},'result':result}
    assert result['executed'] and not result.get('errors')
    assert not before['census'] and not before['structure']
    assert not out['after']['census'] and not out['after']['structure']
    return out
hidden_cases=[np_hidden_retreat(False),np_hidden_retreat(True)]
assert [c['aedui_battle_end'] for c in hidden_cases]==[0,1]
print(json.dumps({'motivation':cases,'np_retreat':retreat_cases,'np_hidden_retreat':hidden_cases},indent=2))
