import io,json
from fs_bot import rules_consts as rc
from fs_bot.state.state_schema import build_initial_state,validate_state
from fs_bot.board.pieces import place_piece,count_pieces
from fs_bot.cards.card_effects import execute_event,_ally_tribe
from fs_bot.cards.capabilities import activate_capability,set_capability_owner
from fs_bot.engine.execute import _execute_event,_execute_battle
out={}
def fresh(f=rc.BELGAE):
 s=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=7);s['non_player_factions']=set();s['executing_faction']=f;s['event_params']={}
 for a in s['resources']:s['resources'][a]=20
 return s
def run(s,c,p,sh=False):
 assert not validate_state(s);s['event_params']=p;execute_event(s,c,sh);assert not validate_state(s)
def agent(requests):
 def cb(s,f,r):
  requests.append({'faction':f,'kind':r['kind'],'request_type':r.get('request_type')})
  if r['kind']=='free_action':return {'decline':True}
  if r['kind']=='agreement':return False
  if r['kind']=='retreat':return {'retreat':False}
  if r['kind']=='loss_order':return r['pieces']
 return cb
# Mandatory selection caps/geography are not checked by event handlers.
s=fresh();_ally_tribe(s,rc.TRIBE_BITURIGES,rc.BELGAE)
run(s,41,{'ally_placements':[{'tribe':t} for t in [rc.TRIBE_PICTONES,rc.TRIBE_SANTONES,rc.TRIBE_CARNUTES]]})
out['41_three_allies_instead_of_two']={t:s['tribes'][t]['allied_faction'] for t in [rc.TRIBE_PICTONES,rc.TRIBE_SANTONES,rc.TRIBE_CARNUTES]}
s=fresh();ts=[rc.TRIBE_MORINI,rc.TRIBE_NERVII,rc.TRIBE_BELLOVACI,rc.TRIBE_CARNUTES,rc.TRIBE_MANDUBII]
for t in ts:_ally_tribe(s,t,rc.BELGAE)
run(s,42,{'removals':[{'tribe':t} for t in ts]})
out['42_five_allies_without_roman_control']={t:s['tribes'][t]['allied_faction'] for t in ts}
s=fresh();run(s,40,{'placements':[{'region':rc.SEQUANI,'piece_type':rc.WARBAND,'count':3,'faction':rc.BELGAE},{'region':rc.SEQUANI,'piece_type':rc.AUXILIA,'count':2,'faction':rc.ROMANS}]})
out['40_warbands_and_auxilia_same_region']={'wb':count_pieces(s,rc.SEQUANI,rc.BELGAE,rc.WARBAND),'auxilia':count_pieces(s,rc.SEQUANI,rc.ROMANS,rc.AUXILIA)}
s=fresh();place_piece(s,rc.PROVINCIA,rc.ARVERNI,rc.WARBAND,5)
run(s,51,{'region':rc.PROVINCIA,'replacements':[{'from_faction':rc.ARVERNI}]*5})
out['51_five_replacements_outside_treveri']={'aedui':count_pieces(s,rc.PROVINCIA,rc.AEDUI,rc.WARBAND)}
# Optional Ballistae effect always fires, even though the human gets no activation request.
s=fresh();place_piece(s,rc.MANDUBII,rc.BELGAE,rc.LEADER,leader_name=rc.AMBIORIX);place_piece(s,rc.MANDUBII,rc.BELGAE,rc.WARBAND)
place_piece(s,rc.MANDUBII,rc.ROMANS,rc.AUXILIA,2,piece_state=rc.REVEALED);place_piece(s,rc.MANDUBII,rc.ROMANS,rc.FORT)
activate_capability(s,10,rc.EVENT_SHADED);set_capability_owner(s,10,rc.BELGAE);requests=[];s['decision_agent']=agent(requests)
res=_execute_battle(s,rc.BELGAE,{'command':'Battle','sa':'Ambush','sa_regions':[rc.MANDUBII],'details':{'battle_plan':[{'region':rc.MANDUBII,'target':rc.ROMANS}]}})
out['10_no_activation_choice']={'requests':requests,'fort_after':count_pieces(s,rc.MANDUBII,rc.ROMANS,rc.FORT),'result':res,'valid':not validate_state(s)}
# The German-guiding Events expose neither March groups nor targets.
for card in [17,58,65]:
 s=fresh(rc.ROMANS);place_piece(s,rc.UBII,rc.GERMANS,rc.WARBAND,5);place_piece(s,rc.SEQUANI,rc.ROMANS,rc.AUXILIA,2,piece_state=rc.REVEALED)
 if card==58:place_piece(s,rc.SEQUANI,rc.ROMANS,rc.FORT)
 requests=[];s['decision_agent']=agent(requests)
 res=_execute_event(s,rc.ROMANS,{'command':'Event','details':{'card_id':card,'text_preference':rc.EVENT_SHADED if card==58 else rc.EVENT_UNSHADED,'event_params':{}}},human=True)
 out[str(card)+'_german_guidance_automatic']={'requests':requests,'result':res,'valid':not validate_state(s)}
print(json.dumps(out,indent=2,default=str))
