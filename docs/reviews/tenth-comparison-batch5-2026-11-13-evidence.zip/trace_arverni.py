"""Observe the first affected Arverni turns in the paired validation games."""

import argparse
from concurrent.futures import ProcessPoolExecutor
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces
from fs_bot.commands.common import _is_devastated
from fs_bot.engine import execute, game_engine
from fs_bot.state.serialize import encode
from fs_bot.tools import player_fuzz, run_batch
from fs_bot.tools.validation_metadata import source_identity


def digest(value):
    return hashlib.sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def snapshot(state):
    excluded = {'rng', 'decision_agent', '_card_turn', '_resolved_card'}
    return {'board': digest({k: v for k, v in state.items() if k not in excluded}),
            'rng': digest(state['rng'].getstate())}


def observed_outcome(result):
    ability = result.get('sa_execution') or {}
    return {key: result[key] for key in
            ('executed', 'command', 'marches', 'total_cost', 'sa_timing', 'errors')
            if key in result} | {'ability': ability if ability.get('executed') else None}


def trace(entry):
    task, mixed = entry['task'], entry['mixed']
    cards = []
    live, observations = None, None
    play = game_engine.play_card
    decide = execute._execute_decision
    free = execute._execute_free_bot_command
    ability = execute._execute_arverni_live_sa

    def observe_card(state, *args, **kwargs):
        nonlocal live, observations
        live, observations = state, []
        row = {'ordinal': len(cards) + 1, 'card': state['current_card'],
               'scenario': state['scenario'], 'before': snapshot(state)}
        result = play(state, *args, **kwargs)
        row.update(after=snapshot(state), arverni=observations,
                   actions={f: rec['action'] for f, rec in result.get(
                       'turn_result', {}).get('actions_taken', {}).items()})
        cards.append(row)
        return result

    def observe_command(state, faction, action, run, kind, action_type=None):
        if state is not live or faction != rc.ARVERNI or action is None:
            return run()
        row = {'kind': kind, 'plan': action, 'declared_action': action_type,
               'before': snapshot(state), 'resources_before': state['resources'][rc.ARVERNI]}
        observations.append(row)
        result = run()
        row.update(after=snapshot(state), outcome=observed_outcome(result),
                   resources_after=state['resources'][rc.ARVERNI])
        return result

    def observe_decision(state, faction, decision, **options):
        return observe_command(
            state, faction, decision.get('bot_action'),
            lambda: decide(state, faction, decision, **options), 'command', decision.get('action'))

    def observe_free(state, faction, action, **options):
        return observe_command(
            state, faction, action, lambda: free(state, faction, action, **options), 'free_command')

    def observe_ability(state, faction, action, **options):
        if state is not live or faction != rc.ARVERNI:
            return ability(state, faction, action, **options)
        row = {'kind': 'ability', 'command': action.get('command'), 'before': snapshot(state),
               'resources_before': state['resources'][rc.ARVERNI],
               'marked_before': [region for region in state['spaces'] if _is_devastated(state, region)]}
        observations.append(row)
        troops = {(region, owner, piece): count_pieces(state, region, owner, piece)
                  for region in state['spaces'] for owner in rc.FACTIONS
                  for piece in (rc.WARBAND, rc.LEGION, rc.AUXILIA)}
        result = ability(state, faction, action, **options)
        row.update(after=snapshot(state), outcome=result, resources_after=state['resources'][rc.ARVERNI])
        if result.get('executed') and result.get('sa') == rc.SA_DEVASTATE:
            row['losses'] = [[region, owner, piece, old - count_pieces(state, region, owner, piece)]
                             for (region, owner, piece), old in troops.items()
                             if region in result['regions']
                             and old > count_pieces(state, region, owner, piece)]
        return result

    with ExitStack() as stack:
        stack.enter_context(patch.object(run_batch, 'play_card', observe_card))
        stack.enter_context(patch.object(game_engine, 'play_card', observe_card))
        stack.enter_context(patch.object(execute, '_execute_decision', observe_decision))
        stack.enter_context(patch.object(execute, '_execute_free_bot_command', observe_free))
        stack.enter_context(patch.object(execute, '_execute_arverni_live_sa', observe_ability))
        if mixed:
            scenario, seed, edition = task
            result = player_fuzz.play_game(scenario, seed, card_edition=edition)
            assert result['game_completed'] and not result['findings'], result
            outcome = result
        else:
            result = run_batch.play_one(task)
            assert result['completed'], result
            fields = ('winner', 'cards', 'final_state_sha256', 'interlude_completed')
            outcome = {field: result[field] for field in fields}
    return {'task': task, 'mixed': mixed, 'outcome': outcome, 'cards': cards}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('tasks', type=Path)
    parser.add_argument('--workers', type=int, default=2)
    args = parser.parse_args()
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        games = list(pool.map(trace, json.loads(args.tasks.read_bytes())))
    print(json.dumps(encode({'source': source_identity(), 'games': games}), sort_keys=True))


if __name__ == '__main__':
    main()
