"""Compare recorded turns and retain each changed winner's first divergence."""

import argparse
from collections import Counter
import json
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
EDITIONS = ("legacy", "second-edition")


def records(raw, edition=None):
    rows = [json.loads(line) for line in raw.splitlines()]
    indexed = {(edition or row["edition"], row["scenario"], row["seed"]): row for row in rows}
    assert len(indexed) == len(rows)
    return indexed


def result_signature(row):
    return row["winner"], row["cards"], row["final_state_sha256"]


def actions_at(trace, card, faction):
    return [action for action in trace["cards"][card - 1]["actions"] if action["faction"] == faction]


def comparable_result(row):
    return row["decision"]["action"], row["result"]


def first_difference(parent, repair):
    for old, new in zip(parent["cards"], repair["cards"]):
        if old["after"] != new["after"]:
            break
    else:
        raise AssertionError("Changed winner without a changed card")
    index = old["card_index"]
    assert index == new["card_index"] and old["card"] == new["card"]
    assert old["before"] == new["before"]
    belgic = [row for row in repair["belgic_march"]
              if row["card_index"] == index and row["result"]["executed"]]
    german_before, german_after = (
        [row for row in trace["german_expand"] if row["card_index"] == index]
        for trace in (parent, repair)
    )
    difference = {
        "card_index": index, "card": old["card"], "same_entry_state": old["before"],
        "parent_exit_state": old["after"], "repair_exit_state": new["after"],
    }
    if belgic:
        difference.update(mechanism="Belgic March Enlist", after_enlist=belgic)
    else:
        assert german_before or german_after, (parent["scenario"], parent["seed"], index)
        before = actions_at(parent, index, "Germans")
        after = actions_at(repair, index, "Germans")
        german_execution_changed = [comparable_result(row) for row in before] != [
            comparable_result(row) for row in after
        ]
        german_planning_changed = german_before != german_after
        rng_changed = any(row["rng_before"] != row["rng_after"] for row in german_before + german_after)
        assert german_execution_changed or (german_planning_changed and rng_changed), difference
        difference.update(
            mechanism="German expansion March",
            parent_german_plans=german_before, repair_german_plans=german_after,
            parent_german_results=[row["result"] for row in before],
            repair_german_results=[row["result"] for row in after],
        )
    return difference


def verify_replays(parent_archive, matrix_dir, parent_trace, repair_trace):
    original, repaired = {}, {}
    for edition in EDITIONS:
        path = f"{edition}/games.jsonl"
        original.update(records(parent_archive.read(path), edition))
        repaired.update(records((matrix_dir / path).read_bytes(), edition))
    assert original.keys() == repaired.keys()
    changed = {key for key in original if original[key]["winner"] != repaired[key]["winner"]}
    before, after = (records(path.read_bytes()) for path in (parent_trace, repair_trace))
    assert before.keys() == after.keys() == changed
    output = []
    for key in sorted(changed):
        parent, repair = before[key], after[key]
        for trace, matrix in ((parent, original[key]), (repair, repaired[key])):
            assert (trace["winner"], len(trace["cards"]), trace["final_state_sha256"]) == result_signature(matrix), key
        edition, scenario, seed = key
        output.append(dict(
            edition=edition, scenario=scenario, seed=seed, parent_winner=parent["winner"],
            repair_winner=repair["winner"], parent_card_count=original[key]["cards"],
            repair_card_count=repaired[key]["cards"], parent_final_state=original[key]["final_state_sha256"],
            repair_final_state=repaired[key]["final_state_sha256"],
            **first_difference(parent, repair),
        ))
    return {"mechanisms": dict(Counter(row["mechanism"] for row in output)), "cases": output}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--parent-archive", type=Path, required=True)
    parser.add_argument("--parent-trace", type=Path, required=True)
    parser.add_argument("--repair-trace", type=Path, required=True)
    args = parser.parse_args()
    with ZipFile(args.parent_archive) as parent:
        result = verify_replays(parent, HERE, args.parent_trace, args.repair_trace)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
