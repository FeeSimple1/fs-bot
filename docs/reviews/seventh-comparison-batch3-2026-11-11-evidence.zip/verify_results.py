"""Verify Batch 3 evidence against the repaired repository and Batch 2."""

import json
from pathlib import Path
import re
import sys
from xml.etree import ElementTree
from zipfile import ZipFile

from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


def load(path):
    return json.loads(path.read_bytes())


def key(row):
    return row['scenario'], row['seed'], row['card_edition']


def games(raw):
    rows = [json.loads(line) for line in raw.splitlines()]
    keyed = {key(row): row for row in rows}
    assert len(keyed) == len(rows)
    return keyed


def outcome(row):
    return {k: value for k, value in row.items() if k not in ('commit', 'source_sha256', 'seconds')}


def verify_matrix(root, archive, identity, label, edition, seeds):
    path = f'bots-{label}/games.jsonl'
    previous = games(archive.read(path))
    current = games((root / path).read_bytes())
    assert previous.keys() == current.keys() == {
        (scenario, seed, edition) for scenario in SCENARIOS for seed in seeds}
    parent_digest = json.loads(archive.read('source.json'))['source_sha256']
    metadata = load(root / f'bots-{label}/metadata.json')
    assert all(metadata[field] == value for field, value in identity.items())
    assert metadata['hash_seed'] == 0 and metadata['card_edition'] == edition
    for case, row in current.items():
        assert previous[case]['source_sha256'] == parent_digest
        assert all(row[field] == identity[field] for field in ('commit', 'source_sha256'))
        assert all(row[field] for field in ('completed', 'game_completed',
                                           'audit_completed', 'final_state_sha256'))
        assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row)
        assert len(row['final_ranking']) == len(row['engine_final_ranking']) == 4
        assert all(item['severity'] == 'legal-decline' for item in row['diagnostics'])
        assert outcome(row) == outcome(previous[case]), case
    return current


def main(evidence):
    root = Path(evidence)
    identity = load(root / 'source.json')
    assert source_identity()['source_sha256'] == identity['source_sha256']
    prior_report = Path('docs/reviews/seventh-comparison-batch2-2026-11-11-evidence.zip')
    with ZipFile(prior_report) as archive:
        legacy = verify_matrix(root, archive, identity, 'legacy', 'legacy', range(1, 21))
        second = verify_matrix(root, archive, identity, 'second', 'second-edition', range(41, 45))
        parent_fuzz = json.loads(archive.read('fuzz0.json'))

    fuzz0, fuzz987 = (root / 'fuzz0.json').read_bytes(), (root / 'fuzz987.json').read_bytes()
    assert fuzz0 == fuzz987 and (root / 'fuzz0.log').read_bytes() == (root / 'fuzz987.log').read_bytes()
    fuzz = json.loads(fuzz0)
    assert fuzz['games'] == len(fuzz['records']) == 20 and fuzz['hard_findings'] == 0
    assert {key(r) for r in fuzz['records']} == {
        (scenario, seed, 'second-edition') for scenario in SCENARIOS for seed in range(41, 45)}
    assert all(r['game_completed'] and not r['findings'] for r in fuzz['records'])
    assert all(fuzz['metadata'][field] == value for field, value in identity.items())
    assert {k: v for k, v in fuzz.items() if k != 'metadata'} == {
        k: v for k, v in parent_fuzz.items() if k != 'metadata'}

    balance_log = (root / 'balance.log').read_text()
    assert 'OK: balance within band.' in balance_log
    rows = re.findall(r'^\[(.+) seed=\s*(\d+)\] winner=(.+) \((\d+) cards\)$',
                      balance_log, re.MULTILINE)
    assert len(rows) == 100
    balance = {f'{scenario}|{seed}': dict(winner=winner, cards=int(cards))
               for scenario, seed, winner, cards in rows}
    assert balance == load(Path('fs_bot/tools/balance_baseline.json'))['games']
    assert balance == {f'{s}|{seed}': dict(winner=r['winner'], cards=r['cards'])
                       for (s, seed, _), r in legacy.items()}

    suites = list(ElementTree.parse(root / 'pytest.xml').getroot().iter('testsuite'))
    tests = sum(int(s.attrib['tests']) for s in suites)
    assert tests == 10043 and not any(int(s.attrib.get(k, 0)) for s in suites
                                    for k in ('errors', 'failures', 'skipped'))
    assert '11 passed' in (root / 'directed.log').read_text()
    assert '7 failed, 4 passed' in (root / 'parent-regressions.log').read_text()
    assert '225 passed' in (root / 'focused.log').read_text()
    audit = Path('docs/reviews/comparison-audit-round7-2026-11-11-evidence.zip')
    with ZipFile(audit) as archive:
        assert (root / 'audit-before.json').read_bytes() == archive.read('frontend/probe_surus-output.json')

    summary = dict(source=identity, python=fuzz['metadata']['python'], full_tests=tests,
        directed_tests=11, parent_defect_reproductions=7, focused_tests=225,
        paired_outcomes={label: dict(games=len(matrix), changed=0,
                                    interludes=sum(r['interlude_completed'] for r in matrix.values()))
                         for label, matrix in [('legacy', legacy), ('second', second)]},
        mixed_player={k: fuzz[k] for k in ('games', 'human_turns', 'event_turns',
            'events_ok', 'partial', 'hard_findings', 'batch_digest')},
        balance=dict(games=len(balance), band=0.15, changed=0))
    (root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main(sys.argv[1])
