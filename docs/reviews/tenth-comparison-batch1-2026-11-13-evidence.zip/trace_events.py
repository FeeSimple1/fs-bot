"""Record bot decisions and Atrebates effects on paired Falling Sky games."""

import argparse
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
from pathlib import Path
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, get_available
from fs_bot.engine import execute
from fs_bot.state.serialize import encode
from fs_bot.tools import run_batch
from fs_bot.tools.validation_metadata import source_identity


def digest(value):
    return hashlib.sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def snapshot(state):
    excluded = {'rng', 'decision_agent', '_card_turn', '_resolved_card'}
    return {'board': digest({k: v for k, v in state.items() if k not in excluded}),
            'rng': digest(state['rng'].getstate())}


def atrebates(state):
    troops = ((rc.ROMANS, rc.AUXILIA), (rc.AEDUI, rc.WARBAND),
              (rc.ROMANS, rc.FORT), (rc.BELGAE, rc.WARBAND))
    return {
        'tribes': {tribe: dict(state['tribes'][tribe])
                   for tribe in (rc.TRIBE_REMI, rc.TRIBE_BELLOVACI)},
        'pieces': {f'{owner}/{piece}': count_pieces(state, rc.ATREBATES, owner, piece)
                   for owner, piece in troops},
        'available': {f'{owner}/{piece}': get_available(state, owner, piece)
                      for owner, piece in troops},
    }


def trace(task):
    cards = []
    play_card = run_batch.play_card
    resolve = execute._execute_event

    def observe_card(state, decide, **kwargs):
        card = state['current_card']
        row = {'ordinal': len(cards) + 1, 'card': card, 'scenario': state['scenario'],
               'before': snapshot(state)}
        if card in ('A51', 'A69'):
            row['atrebates_before'] = atrebates(state)
            row['events'] = []

        def observe_event(board, faction, plan, **options):
            before = atrebates(board)
            result = resolve(board, faction, plan, **options)
            if board is state:
                row['events'].append({'faction': faction, 'before': before,
                                      'after': atrebates(board), 'result': result})
            return result

        if card in ('A51', 'A69'):
            with patch.object(execute, '_execute_event', observe_event):
                result = play_card(state, decide, **kwargs)
        else:
            result = play_card(state, decide, **kwargs)
        row['after'] = snapshot(state)
        if card in ('A51', 'A69'):
            row['atrebates_after'] = atrebates(state)
            row['actions'] = result['turn_result']['actions_taken']
        cards.append(row)
        return result

    with patch.object(run_batch, 'play_card', observe_card):
        result = run_batch.play_one(task)
    assert result['completed'], result
    keys = ('winner', 'cards', 'final_state_sha256', 'interlude_completed')
    return {'task': task, 'outcome': {key: result[key] for key in keys}, 'cards': cards}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('tasks', type=Path)
    parser.add_argument('--workers', type=int, default=2)
    args = parser.parse_args()
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        games = list(pool.map(trace, json.loads(args.tasks.read_text())))
    print(json.dumps(encode({'source': source_identity(), 'games': games}), sort_keys=True))


if __name__ == '__main__':
    main()
