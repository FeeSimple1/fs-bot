"""Trace the first differing draw for each changed fixed-seed winner."""
from concurrent.futures import ProcessPoolExecutor
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import sys

from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.cli.dispatcher import _translate_bot_action, make_decision_func
from fs_bot.engine.game_engine import ACTION_EVENT, get_sop_factions, play_card, start_game
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.tools.validation_metadata import source_identity


def digest(state):
    return sha256(json.dumps(encode(state), sort_keys=True).encode()).hexdigest()


def trace(case):
    scenario, seed, edition = case
    state = setup_scenario(scenario, seed=seed, card_edition=edition)
    state['non_player_factions'] = set(get_sop_factions(state))

    def balance_driver(live, faction, options, position):
        live['current_card_id'] = live.get('current_card')
        live['is_second_eligible'] = position == '2nd_eligible'
        live['can_play_event'] = ACTION_EVENT in options
        plan = dispatch_bot_turn(live, faction)
        return {'action': _translate_bot_action(plan, options), 'bot_action': plan}

    decide = balance_driver if edition == 'legacy' else make_decision_func(
        {}, stdin=StringIO(), stdout=StringIO(), pause=False)
    rows = []
    with redirect_stdout(StringIO()):
        start_game(state)
        while state['current_card'] is not None:
            before = digest(state)
            result = play_card(state, decide, execute=True)
            taken = (result.get('turn_result') or {}).get('actions_taken', {})
            actions = {actor: {key: action[key] for key in ('action', 'execution') if key in action}
                       for actor, action in taken.items()}
            rows.append({'card': result['card'], 'before': before, 'after': digest(state),
                         'actions': actions if result['card'] in (48, 52) else {
                             actor: {'action': row['action'],
                                     'command': row.get('execution', {}).get('command')}
                             for actor, row in actions.items()},
                         'winner': result.get('winner')})
            if result['game_over']:
                break
    return {'scenario': scenario, 'seed': seed, 'edition': edition, 'cards': rows}


def cases(parent, repaired):
    def read_balance(path):
        return json.loads((path/'balance.json').read_text())['games']

    def read_bots(path):
        rows = (json.loads(line) for line in (path/'bots/games.jsonl').read_text().splitlines())
        return {(row['scenario'], row['seed']): row for row in rows}

    before, after = read_balance(parent), read_balance(repaired)
    for key in sorted(after):
        if before[key]['winner'] != after[key]['winner']:
            scenario, seed = key.split('|')
            yield scenario, int(seed), 'legacy'
    before, after = read_bots(parent), read_bots(repaired)
    for key in sorted(after):
        if before[key]['winner'] != after[key]['winner']:
            yield *key, 'second-edition'


if __name__ == '__main__':
    previous, current, output = map(Path, sys.argv[1:])
    with ProcessPoolExecutor(max_workers=2) as workers:
        traces = list(workers.map(trace, cases(previous, current)))
    output.write_text(json.dumps({'source': source_identity(), 'traces': traces}, indent=2) + '\n')
