from pathlib import Path
from collections import Counter
from fractions import Fraction
import hashlib,json,re,subprocess
from fs_bot import rules_consts as rc
from fs_bot.tools.validation_metadata import source_identity
parent='4cfeb2c4e58685f96a2287490d405d37df553558';source=source_identity()
assert source['source_sha256']=='dacec83d00c491620202ef3253150227ec68addb7bae6793a6241891a18583f0'
records={}
for label in ('parent','final'):
 rows=[json.loads(x) for x in Path('/tmp/fs-rampage-bots-'+label+'/games.jsonl').read_text().splitlines()]
 records[label]={(r['scenario'],r['seed']):r for r in rows}
 assert set(records[label])=={(s,n) for s in rc.ALL_SCENARIOS for n in (1,2)}
 for row in rows:
  assert all(row[k] for k in ('completed','game_completed','audit_completed','final_state_sha256'))
  assert not row['errors'] and not row['integrity_findings']
  assert len(row['final_ranking'])==4 and not row['winner_differs_from_highest_margin'] and not row['engine_ranking_output_missing']
  assert all(d['severity']=='legal-decline' for d in row['diagnostics'])
ignored={'seconds','commit','source_sha256'}
differences={str(k):sorted(f for f in set(a)|set(records['final'][k]) if f not in ignored and a.get(f)!=records['final'][k].get(f)) for k,a in records['parent'].items()}
assert {k:v for k,v in differences.items() if v}=={str((rc.SCENARIO_RECONQUEST,2)):['final_state_sha256']}
assert all(row['winner']==records['final'][key]['winner'] for key,row in records['parent'].items())
traces={label:json.loads(Path('/tmp/fs-rampage-trace-'+label+'.json').read_text()) for label in ('parent','final')}
for label,t in traces.items():assert t['record']['final_state_sha256']==records[label][rc.SCENARIO_RECONQUEST,2]['final_state_sha256']
p,c=traces['parent'],traces['final']
first=next(i for i,(a,b) in enumerate(zip(p['cards'],c['cards'])) if a['state_sha256']!=b['state_sha256'])
assert first==24 and p['cards'][first]['resolved_card']==c['cards'][first]['resolved_card']==37
call_p=next(x for x in p['rampage_calls'] if x['card_index']==first)
call_c=next(x for x in c['rampage_calls'] if x['card_index']==first)
assert call_p['before']==call_c['before']
assert next(x['count'] for x in call_p['result']['rampages'] if x['region']==rc.ATREBATES)==2
assert next(x['count'] for x in call_c['result']['rampages'] if x['region']==rc.ATREBATES)==3
mixed=json.loads(Path('/tmp/fs-rampage-mixed0.json').read_text())
assert mixed==json.loads(Path('/tmp/fs-rampage-mixed987.json').read_text()) and mixed['hard_findings']==0
assert mixed['metadata']['source_sha256']==source['source_sha256']
partial=json.loads(Path('/tmp/fs-rampage-partial.json').read_text())
assert partial['source']['source_sha256']==source['source_sha256']
assert partial['record']['digest']==next(r['digest'] for r in mixed['records'] if r['scenario']==rc.SCENARIO_PAX_GALLICA and r['seed']==2)
log=Path('/tmp/fs-rampage-balance.log').read_text();matrix={}
for line in log.splitlines():
 match=re.match(r'^\[(.*?) seed=\s*(\d+)\] winner=(\w+) \((\d+) cards\)$',line)
 if match:matrix[match[1]+'|'+match[2]]={'winner':match[3],'cards':int(match[4])}
assert set(matrix)=={s+'|'+str(n) for s in rc.ALL_SCENARIOS for n in range(1,21)}
assert 'OK: balance within band (35 winner changes)' in log
baseline=json.loads(Path('fs_bot/tools/balance_baseline.json').read_text())['games']
changed=[key for key,row in matrix.items() if row['winner']!=baseline[key]['winner']]
assert len(changed)==35
rates={};max_drift=Fraction(0)
for scenario in rc.ALL_SCENARIOS:
 keys=[scenario+'|'+str(n) for n in range(1,21)]
 old=Counter(baseline[k]['winner'] for k in keys);new=Counter(matrix[k]['winner'] for k in keys)
 rates[scenario]={f:{'baseline_wins':old[f],'current_wins':new[f],'change_pp':(new[f]-old[f])*5} for f in rc.FACTIONS}
 max_drift=max(max_drift,*[Fraction(abs(new[f]-old[f]),20) for f in rc.FACTIONS])
assert max_drift==Fraction(3,20)
protected=[p for p in Path('Reference Documents').rglob('*') if p.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
for p in protected:assert p.read_bytes()==subprocess.check_output(['git','show',parent+':'+str(p)])
result={'date':'2026-11-04','timezone':'America/Chicago','source':source,'python_files':len(list(Path('fs_bot').rglob('*.py'))),'protected_files':len(protected),'protected_files_unchanged':True,'targeted_passed':348,'new_tests':48,'parent_proof':{'behavioral_failures':35,'controls_passed':2,'deselected':11},'bots':{'games':10,'all_completed_and_audited':True,'all_winners_equal':True,'comparison_differences':differences,'excluded':sorted(ignored)},'trace':{'scenario':rc.SCENARIO_RECONQUEST,'seed':2,'first_different_card_index':first,'card':37,'region':rc.ATREBATES,'target':rc.AEDUI,'parent_count':2,'corrected_count':3,'preapplication_pieces_equal':True},'mixed':mixed,'mixed_complete_json_equal':True,'hash_seeds':[0,987],'mixed_executions_including_replay':40,'partial_trace':partial,'balance':{'games':100,'seeds':[1,20],'scenarios':list(rc.ALL_SCENARIOS),'band_percentage_points':15,'max_absolute_drift_pp':15,'winner_changes_vs_stored_baseline':35,'baseline_unchanged':True,'passed':True,'rates':rates,'records':matrix,'note':'Changes relative to the stored historical baseline include earlier repairs; these are not claimed as 35 winner changes caused by this patch.'},'original_progress':{'closed':24,'total':50,'percent':48,'open':26},'remaining':'BATTLE-RAMPAGE-VICTIM and CV-PERSISTENCE remain open'}
Path('/tmp/fs-rampage-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':source,'new_tests':48,'targeted':348,'parent_failed':35,'parent_controls':2,'bot_games':10,'changed_final_hashes':1,'mixed_equal':True,'balance':{'games':100,'passed':True,'max_drift_pp':15},'protected':len(protected)}))
