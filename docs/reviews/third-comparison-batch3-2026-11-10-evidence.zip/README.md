# Third comparison repair Batch 3 evidence

Accepted final results are at the archive root: source.json, pytest.xml,
verification.json, bots/, fuzz0.json, fuzz987.json and balance.json. The final
report records their exact Python-source digest and parent revision c6ed9dd.
The root baseline is checked without changing its 100 scenario/seed keys or
15-point drift tolerance.

The new test module contains 60 source-derived cases. parent-regressions-final.xml
runs the same module outside the package against clean c6ed9dd, avoiding repaired
module imports: 37 failures expose the old behavior and 23 positive controls pass.
Earlier parent-regression files retain their smaller, superseded case sets.

The full suite includes original and second-edition source cases. Complete bot
and mixed-player matrices use legacy cards and seeds 21–24 in all five scenarios.
Mixed runs use hash seeds 0 and 987, reactions, Events and internal replay. Exact
JSON equality is required, with hard findings and soft partial plans reported
separately. The 100-game balance check uses seeds 1–20 in all five scenarios.

Parent game records come from Batch 2's accepted evidence. Their Python-source
digest e0c0f1e5dd86bf95978cb6f3226c82d5e46859fb006424b7374f8137aa515f24
matches clean parent c6ed9dd. The current baseline SHA-256 remains
5c14af61d455068527ed2032857192f849eb854b7e0bf4793d475e2974ab262a.

To rerun, use SELFPLAY_PLAYBOOK.md and the listed seeds/profile. run_balance.py
records the official runner's returned outcomes. verify_results.py checks source
identities, XML, exact game coverage, every audit record, cross-hash replay and
baseline identity. accepted-tests/ contains the source-derived case file used.

Candidate directories and earlier focused logs retain superseded engine or
fixture checks. They include old incomplete Harudes placement fixtures, supply
scarcity corrections, the Migration impossible-placement condition, and timing
window investigation. Only the accepted root results supply final measurements.
