# BE-03 independent source review

Reviewer: gallic_event_review. Parent: e37b965e5ce420e29e486c7221661e51b9803282. Sources are the repository's supplied references only. Full CLAUDE.md read; all 47 reference files inventoried. No protected reference or constants edits. PR-01 through PR-09 are unchanged and do not resolve the specific choices below.

## Shared contract

- Chapter 5 §§5.1, 5.1.3: Event executor selects unless text names another decision maker; execute possible text in printed order. A free Command's own decisions belong to its executing faction under Chapter 3 §3.1.
- Chapter 5 §5.4 and Chapter 3 §3.1.2: Resource-free, no additional eligibility effect, normal procedures/location restrictions survive. No Special Ability unless granted.
- Chapter 8 §§8.1.2, 8.2.1–3, 8.3.1, 8.3.4, 8.4.1: Event-granted Limited Command stays Limited; recipient's Event instructions apply; otherwise chart action priorities, own benefit only, net piece category priorities and seeded random equal choices. NPC flowchart refusal is not a restriction on human legal actions.
- Ariovistus A5.1.1: Gallic still means Arverni/Aedui/Belgae, never Germans. A8.2.3: game-run Arverni actions use A6.2 as applicable; no base Arverni chart or human seat. At Peace must not be silently forced At War by cards lacking that override.

## Cards

### 35 shaded, Gallic Shouts

Executor selects a Gallic recipient. Recipient executes one full Command plus one Limited Command, in either order, free, no Battles; neither has an accompanying Special Ability. No explicit “may”: no invented whole-effect decline. Select command order with recipient authority. No special NPC command-order instruction was found; unprioritized equal choices are random under §8.2.3. Aedui's printed side instruction is shaded.

### 46 shaded, Celtic Rites

Executor selects a Gallic recipient; recipient executes one free Command, no Special Ability. No explicit “may.” The original Event executor stays Eligible: the Card Reference tip expressly identifies that cylinder. Recipient retains normal free-action eligibility treatment independently. Aedui's side instruction is shaded.

### Numeric 67, Arduenna, either alias

Executor selects Romans or a Gallic faction. Recipient owns acceptance and subsequent actions. The optional grant is the printed March→non-March Command→Hide sequence: after acceptance execute possible stages in order (§5.1.3), with normal Command choices. No source supports a blanket independent stage-decline.

March may originate anywhere normal movement reaches Nervii/Treveri, with one or both as final destinations. Follow-on non-March Command occurs in one or both target Regions. No Special Ability. Final Hide affects only the recipient's friendly soft pieces. Scouted pieces that marched first lose their marker and finally hide; nonmoving Scouted residents lose the marker and remain Revealed. A67 has the same locations/order but changes beneficiaries to a faction other than Arverni, so German A67 instructions cannot be applied to numeric67.

Base Arverni NPC instruction is substantive: March and Battle to inflict maximum Losses on Legions, or No Arverni. Legacy adjacent gathering and generic command choice is insufficient. Printed receiver instructions apply even if another executor grants the effect (§8.2.1).

### 68 shaded, Remi Influence

The Gallic owner of the Remi Ally owns “may” and chooses Alesia or Cenabum. Remove the selected City's occupant/status (Ally, Citadel, Dispersed/Gathering/Razed), not unrelated troops, Fort or Abatis in its Region. Then place that Gallic faction's Citadel and four Warbands as possible. No invented “up to four” quantity choice. Removal still occurs if replacement stock is unavailable; removing an own Citadel can itself make the replacement available. Preserve the original executor's separate voluntary reclamation authority and placement timing windows.

Belgae NPC requires its Allies-plus-Citadels total to increase, so own Ally→Citadel is not enough even if four Warbands would be added. Aedui/Arverni must own Remi or decline. German NPC cannot benefit. Net Citadel, then Ally, then other piece priorities follow §8.3.1, faction ties §8.4.1, remaining ties seeded random. Human legal targets must not be pruned by these NPC priorities.

## Interpretation boundary

A8.2.3 says to follow A6.2 “as applicable” when Arverni receive actions. A6.2 specifies phase order Rally→March→Raid→Battle and detailed procedures, but does not expressly name which single Command to select for cards35/46. Selecting the first possible permitted Command in phase order is a plausible adaptation, not a printed card-specific ruling. Flag any new policy rather than citing it as explicit text. Card35 forbids Battle; card46 grants no Ambush. This question is outside PR-01–PR-09.

## Review status

Source conclusions delivered to parent and implementation agents. Root chose to record the A8 single-Command question rather than implement a new policy: keep Arverni legally selectable and report an atomic unsupported diagnostic for that narrow case. BE-03 therefore remains partially open.

Independent Remi implementation and all 60 focused cases reviewed with no blocker. Additional `reviewer-remi-witness.py` passed: with both recipient placement pools exhausted, the selected enemy City Ally is removed while unrelated Roman Fort/Auxilia and Abatis survive; invariants pass. This covers a boundary beyond the implementation agent's tests.

Early Gallic review flagged the game-run Arverni order callback and non-player beneficiary fallback outside its own legal-benefit set. Engine addressed these with the source-question diagnostic and NPC guards. Original executor authored timing at outer grant steps remains legal; beneficiary action fields cannot be preauthored by that executor. A further equal-origin default-March tie now uses seeded random selection.

The new zero-own-piece Battle validation is correct: Chapters 3.2.4/3.3.4 require own and enemy Forces, not specifically mobile Forces. Two independent positive validation witnesses passed: a static-only Gallic attack remains legal, as does a co-located Diviciacus cooperation attack. This avoids pruning human legality to the bot's mobile-attacker preference.

The proposed numeric67 Arverni optimizer was reviewed and is not shipping. Chapter8.7.1 expressly describes best-case Defender Loss rolls; it does not expressly settle a human Retreat assumption or successful Leader Harassment save used by the prototype. Those choices can change allocation rankings. The prototype also omitted Frost/player-victory protection and merged states with different departure-origin Control, so its DP did not establish equivalence over all legal NPC plans. No completed maximum-Legion-Loss policy is claimed. The prior resolver remains, with the gap documented as Q-ARDUENNA-NP-PREDICTION. An earlier concern about aggregate physical/visibility handling was not established as a concrete defect and is not a finding.

Final independent code review found no remaining blocker in this bounded human-grant/Remi repair. The retained numeric67 NPC gap and automatic Arverni single-Command ambiguity prevent whole BE-03 closure. Ordinary March-to-Hide-without-movement is a pre-existing separate menu gap; root explicitly kept that outside this bounded batch. Reviewed the new question/report wording and verified no new ruling is claimed. No production edits, full games, or broad matrices were performed by this reviewer; parent owns final complete validation and publication.
