"""Replay changed outcomes and record the first differing card's bot plans."""

from concurrent.futures import ProcessPoolExecutor
from contextlib import ExitStack, redirect_stdout
from functools import wraps
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import sys
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces_by_state
from fs_bot.bots import aedui_bot, arverni_bot, belgae_bot, german_bot
from fs_bot.cli.dispatcher import make_decision_func
from fs_bot.commands.common import battle_cost
from fs_bot.commands.raid import max_raiders_per_region
from fs_bot.engine.game_engine import get_sop_factions, play_card, start_game
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.tools.validation_metadata import source_identity


BOTS = (
    (rc.BELGAE, belgae_bot, 'node_b_battle'),
    (rc.ARVERNI, arverni_bot, 'node_v_battle'),
    (rc.GERMANS, german_bot, 'node_g_battle'),
    (rc.AEDUI, aedui_bot, None),
)


def digest(value):
    return sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def board_digest(state):
    return digest({key: value for key, value in state.items() if key != 'decision_agent'})


def key(row):
    return row['scenario'], row['seed'], row['card_edition']


def watch_battle(module, name, faction, plans):
    planner = getattr(module, name)
    qualifies = module._can_battle_in_region

    @wraps(planner)
    def plan(board, *args, **kwargs):
        checked = []
        before = digest(board['rng'].getstate())
        resources = board['resources'][faction]
        scope = board.get('_command_region_scope')

        @wraps(qualifies)
        def check(state, region, *target, **options):
            favorable = qualifies(state, region, *target, **options)
            checked.append(dict(region=region, target=target[-1],
                                cost=battle_cost(state, region, faction),
                                ambush=options.get('is_ambush', False), favorable=favorable))
            return favorable

        with patch.object(module, '_can_battle_in_region', check):
            action = planner(board, *args, **kwargs)
        plans.append(encode(dict(faction=faction, resources=resources,
                                 free=board.get('_planning_free_command', False),
                                 scope=scope, permits_sa=board.get('_command_with_sa', True),
                                 rng_before=before, rng_after=digest(board['rng'].getstate()),
                                 checks=checked, action=action)))
        return action

    return plan


def watch_raid(module, faction, raids):
    planner = module._would_raid_gain_enough

    @wraps(planner)
    def plan(board, *args, **kwargs):
        enough, entries = planner(board, *args, **kwargs)
        capacity = max_raiders_per_region(board, faction)
        if capacity == 3 or kwargs.get('raiders') is not None:
            regions = sorted({entry['region'] for entry in entries})
            raids.append(encode(dict(faction=faction, enough=enough, entries=entries,
                capacity=capacity, cohort=kwargs.get('raiders'),
                hidden={region: count_pieces_by_state(board, region, faction, rc.WARBAND, rc.HIDDEN)
                        for region in regions})))
        return enough, entries

    return plan


def trace(task):
    row, parent = task
    scenario, seed, edition = key(row)
    state = setup_scenario(scenario, seed=seed, card_edition=edition)
    state['non_player_factions'] = set(get_sop_factions(state))
    bot = make_decision_func({}, stdin=StringIO(), stdout=StringIO(), pause=False)
    decisions, battles, raids, cards = [], [], [], []

    def decide(board, faction, options, position):
        decision = bot(board, faction, options, position)
        decisions.append(encode(dict(faction=faction, position=position, decision=decision)))
        return decision

    with ExitStack() as stack:
        stack.enter_context(redirect_stdout(StringIO()))
        for faction, module, name in BOTS:
            if name:
                stack.enter_context(patch.object(module, name, watch_battle(module, name, faction, battles)))
            stack.enter_context(patch.object(module, '_would_raid_gain_enough',
                                             watch_raid(module, faction, raids)))
        start_game(state)
        for draw in range(1, 201):
            decisions.clear()
            battles.clear()
            raids.clear()
            before = board_digest(state)
            rng_before = digest(state['rng'].getstate())
            result = play_card(state, decide, execute=True)
            card = dict(draw=draw, card=result['card'], before=before, rng_before=rng_before,
                        after=board_digest(state), decisions=list(decisions),
                        battles=list(battles), raids=list(raids))
            if parent is not None:
                prior = parent['cards'][draw - 1]
                assert (prior['card'], prior['before'], prior['rng_before']) == (
                    card['card'], before, rng_before)
                if prior['after'] != card['after']:
                    return dict(scenario=scenario, seed=seed, card_edition=edition,
                                prior_winner=parent['winner'], current_winner=row['winner'],
                                draw=draw, card=card['card'], prior=prior, current=card)
            else:
                cards.append(card)
            if result['game_over']:
                break
    assert parent is None, f'No first changed card for {key(row)}'
    assert (result['winner'], draw, card['after']) == (
        row['winner'], row['cards'], row['final_state_sha256'])
    return dict(scenario=scenario, seed=seed, card_edition=edition, winner=row['winner'], cards=cards)


def main(inputs, output, parent_file=None):
    rows = json.loads(Path(inputs).read_text())
    parents = {} if not parent_file else {key(row): row for row in
        json.loads(Path(parent_file).read_text())['games']}
    assert not parent_file or parents.keys() == {key(row) for row in rows}
    with ProcessPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(trace, ((row, parents.get(key(row))) for row in rows)))
    Path(output).write_text(json.dumps(dict(source=source_identity(), games=results), indent=2) + '\n')
    print(f'{len(results)} games traced')


if __name__ == '__main__':
    main(*sys.argv[1:])

