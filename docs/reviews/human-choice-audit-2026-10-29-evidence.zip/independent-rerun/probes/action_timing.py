"""Audit witness for §4.1: Build at an intermediate point of one March.

Run with PYTHONPATH=<repo>. The low-level hops illustrate legal board
positions; they are not a claim that two standalone Commands equal one March.
The typed validator unconditionally excludes any March/Battle interruption.
"""
import copy
import json
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece
from fs_bot.commands.march import march_group
from fs_bot.commands.sa_build import validate_build_region, build_fort
from fs_bot.engine.action_validation import validate_human_structure
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity


def valid(state):
    errors = validate_state(state) + check_structural_integrity(state)
    assert not errors, errors


def main():
    state = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=84)
    state['non_player_factions'] = set()
    state['resources'][rc.ROMANS] = 20
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.LEADER, leader_name=rc.CAESAR)
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.LEGION, 1, from_legions_track=True)
    valid(state)
    original = copy.deepcopy(state)
    group = {rc.LEADER: rc.CAESAR, rc.LEGION: 1}
    before = validate_build_region(state, rc.SEQUANI)
    first = march_group(state, rc.ROMANS, rc.PROVINCIA, [rc.SEQUANI], group)
    during = validate_build_region(state, rc.SEQUANI)
    during_state = copy.deepcopy(state)
    second = march_group(state, rc.ROMANS, rc.SEQUANI, [rc.MANDUBII], group)
    after = validate_build_region(state, rc.SEQUANI)
    valid(state)
    fort = build_fort(during_state, rc.SEQUANI)
    march_group(during_state, rc.ROMANS, rc.SEQUANI, [rc.MANDUBII], group)
    valid(during_state)
    parts = [{'command': 'March', 'details': {'origins': [rc.PROVINCIA], 'routes': {rc.PROVINCIA: [rc.SEQUANI]}}},
             {'command': 'March', 'details': {'origins': [rc.SEQUANI], 'routes': {rc.SEQUANI: [rc.MANDUBII]}}}]
    action = {'command': 'March', 'sa': 'Build', 'sa_timing': 'during', 'sa_regions': [rc.SEQUANI],
              'details': {'command_parts': parts, 'build_plan': {'forts': [rc.SEQUANI]}}}
    error = validate_human_structure(original, rc.ROMANS, action)
    assert before[0] is False and during[0] is True and after[0] is False
    assert error == 'Use before/after timing for March or Battle; their Command-wide resolution cannot be split'
    assert first['stopped_reason'] is None and second['stopped_reason'] is None
    return {'before': before, 'during': during, 'after': after, 'intermediate_fort': fort,
            'typed_rejection': error, 'valid': True,
            'limit': 'Illustrates one legal interruption; no exhaustive Command interleaving test.'}


if __name__ == '__main__':
    print(json.dumps(main(), indent=2, sort_keys=True))
