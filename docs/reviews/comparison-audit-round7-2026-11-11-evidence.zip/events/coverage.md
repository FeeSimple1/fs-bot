# Seventh comparison audit — Event partition

Audited source `c67d501711471bf790d805c017c2125b2c254639`. Three medium-priority repair groups, six failing public bot witnesses, and seven positive public controls are retained in `findings.json`, `probe_events.py`, and `probe_events-output.json`. Each witness uses `dispatch_bot_turn` and `execute_decision` with canonical `ACTION_EVENT`; all assertions pass while reproducing the defect. The source tree was not edited.

- BE7-01 has one failing Oppida witness and two positive controls (complete explicit plan, existing-Ally actual bot).
- BE7-02 has three failing witnesses (Roman A19, Belgic A26, German A26), each with its complete explicit-plan control.
- BE7-03 has two failing witnesses (Belgae/Germans A18), each with a one-Legion-nearer positive control and a real fallback Command.

Every completed fixture/control calls `validate_state` and `check_structural_integrity` and retains Provincia's permanent Roman Fort. All physical creation/movement uses canonical helpers. A26/A18 witnesses use original Ariovistus setup with only Event/seat metadata selected. A19/Oppida are controlled valid boards. The probes establish correctness failures, not natural frequency. They do not mutate/monkeypatch production code.

Read FS card references, Chapter8 NP selection/maximization/effectiveness rules, Chapter A8, all thirteen provisional rulings, original human inventory and comparison ledgers through round6. Reviewed current Event derivation dispatch, supported helper families, handler parameter consumers, base_event_limits, Oppida legal options, condition/effectiveness filters, and named/expanded card paths. The broad no-op setup scan was investigative only; its other rows are not counted as defects. Oppida human live-choice repair and the Procillus Caesar/Colony repairs remain valid and are not reopened.

Comparator checkout `/workspace/scratch/2a0af949261f/lod-bot-round5`, commit `2991ea279062773548ec390a1da75f3e85381702`: read `coin-implementation-lessons.md`, `docs/audit_set_but_never_applied_s76.md`, and `docs/audit_event_gain_priorities_cards1_16_21.md`. These provided engineering patterns only; all game expectations come from Falling Sky references. No new ambiguous source question was required.

Exploration excluded Roman Wine minimum omission (the handler correctly enforces it), speculative A35 owner/piece concerns (card wording not sufficient for a confirmed defect), and other scan-only no-ops. The first explicit probe used the display string Event instead of canonical ACTION_EVENT and was corrected before the final run; that was a fixture error, not an engine finding.
