"""Command/Event execution layer — bridges bot decisions to mechanics.

Phase-4b proof slice. The Sequence-of-Play decision engine
(`game_engine.resolve_card_turn`) records each faction's decision but did
not previously apply it to the board. This module translates a recorded
decision into calls on the already-implemented, already-tested mechanic
functions in `fs_bot/commands/` and `fs_bot/cards/`.

Scope of THIS slice (deliberately narrow — see WIRING_SCOPE.md):
  - Seize  (Roman Command) — the lightest Command, used to validate the
    whole decision -> execution path end to end.
  - Event  — via the existing `card_effects.execute_event` dispatcher.

Every other Command/SA is recognized but intentionally left as a no-op
here (``executed: False`` with a reason) so that enabling
execution does not crash or silently corrupt a full game while the rest
of the integration is built out incrementally.

Design notes:
  - This is OPT-IN. `resolve_card_turn(..., execute=True)` calls it; the
    default (execute=False) preserves the historical record-only behavior
    so existing tests are unaffected.
  - Execution never raises on an unhandled or failing action; it returns a
    structured result so the engine can keep running and tests can assert.
  - Mechanic-level validation (`validate_*`) is enforced inside the mechanic
    functions; CommandError is caught and reported, not propagated.
"""

from fs_bot.rules_consts import EVENT_SHADED
from fs_bot.engine.diviciacus import command_scope as _diviciacus_command_scope
from fs_bot.commands.common import CommandError, free_action
from fs_bot.board.pieces import PieceError
from fs_bot.commands.seize import seize_in_region, get_dispersible_tribes
from fs_bot.commands.raid import raid_in_region, max_raiders_per_region
from fs_bot.commands.rally import rally_in_region
from fs_bot.battle.resolve import resolve_battle
from fs_bot.commands.sa_besiege import get_besiege_targets
from fs_bot.commands.rally import (
    recruit_in_region, preserve_supply_agreements, supply_query_scope)
from fs_bot.commands.march import march_group, _flip_origin_pieces
from fs_bot.board.pieces import count_pieces, get_leader_in_region
from fs_bot.map.map_data import get_playable_regions, get_playable_regions_for_state
from fs_bot.bots.bot_common import random_select
from fs_bot.commands.sa_trade import trade as _sa_trade
from fs_bot.commands.sa_settle import settle as _sa_settle
from fs_bot.commands.sa_devastate import devastate_region as _sa_devastate
from fs_bot.commands.sa_intimidate import intimidate as _sa_intimidate
from fs_bot.commands.sa_suborn import suborn as _sa_suborn
from fs_bot.commands.sa_build import build_fort as _sa_build_fort
from fs_bot.commands.sa_build import build_subdue as _sa_build_subdue
from fs_bot.commands.sa_build import build_place_ally as _sa_build_ally
from fs_bot.commands.sa_rampage import rampage as _sa_rampage
from fs_bot.commands.sa_entreat import entreat_replace_piece as _sa_entreat_piece
from fs_bot.commands.sa_entreat import entreat_replace_ally as _sa_entreat_ally
from fs_bot.commands.sa_scout import scout_move as _sa_scout_move
from fs_bot.commands.sa_scout import scout_reveal as _sa_scout_reveal
from fs_bot.board.pieces import count_pieces_by_state as _count_state
from fs_bot.bots.bot_common import np_agrees_to_retreat
from fs_bot.commands.seize import execute_harassment_loss as _seize_harass_loss
from fs_bot.rules_consts import HARASSMENT_WARBANDS_PER_LOSS as _HWB_PER_LOSS
from fs_bot.cards.card_effects import execute_event

# Mechanic functions raise CommandError on rule violations and PieceError
# on invalid piece operations (e.g. a plan gone stale against the board).
# Execution captures both so a partly-infeasible plan resolves as far as it
# legally can rather than crashing the turn.
_EXEC_ERRORS = (CommandError, PieceError)
# Event card handlers are complex and may raise a range of errors when the
# board does not match a card's assumptions (missing pieces, absent params,
# etc.). Such an Event is simply Ineffective in this state — report it rather
# than let one card crash the game.
_EVENT_SAFE_ERRORS = (NotImplementedError, KeyError, ValueError,
                      AttributeError, TypeError, IndexError,
                      CommandError, PieceError)


# Bot command labels (mirror the per-bot ACTION_* constants, which all
# share these string values).
_CMD_EVENT = "Event"
_CMD_SEIZE = "Seize"
_CMD_RAID = "Raid"
_CMD_RALLY = "Rally"
_CMD_BATTLE = "Battle"
_CMD_RECRUIT = "Recruit"
_CMD_MARCH = "March"
_SA_AMBUSH = "Ambush"
_SA_BESIEGE = "Besiege"
_SA_TRADE = "Trade"
_SA_SETTLE = "Settle"
_SA_DEVASTATE = "Devastate"
_SA_INTIMIDATE = "Intimidate"
_SA_SUBORN = "Suborn"
_SA_BUILD = "Build"
_SA_RAMPAGE = "Rampage"
_SA_ENTREAT = "Entreat"
_SA_SCOUT = "Scout"
from fs_bot.rules_consts import ARVERNI as _ARVERNI_F
from fs_bot.rules_consts import ROMANS as _ROMANS_F
from fs_bot.rules_consts import AEDUI as _AEDUI_F
from fs_bot.rules_consts import GERMANS as _GERMANS_F
from fs_bot.rules_consts import BELGAE as _BELGAE_F
_SA_ENLIST = "Enlist"
SA_ACTION_NONE_LABEL = "No SA"
# SAs handled inside Battle resolution, not as standalone post-command SAs.
_BATTLE_MODIFYING_SAS = {_SA_AMBUSH, _SA_BESIEGE}
# Standalone SAs that resolve BEFORE the Battle they accompany.
_BEFORE_BATTLE_SAS = {_SA_INTIMIDATE, _SA_DEVASTATE, _SA_ENTREAT, _SA_RAMPAGE}



def _apply_end_of_action_capabilities(state):
    """Ongoing capability effects checked at the end of any Faction's action.

    A70 (Nervii, shaded): "If Nervii Subdued at end of any Faction's action,
    place Belgic Ally there." Subdued = the Nervii Tribe neither Allied nor
    Dispersed (allied_faction None, status None).
    """
    from fs_bot.cards.capabilities import is_capability_active
    from fs_bot.rules_consts import (BELGAE, NERVII, TRIBE_NERVII, ALLY,
                                     EVENT_SHADED)
    from fs_bot.board.pieces import get_available, place_piece
    if not is_capability_active(state, "A70", EVENT_SHADED):
        return
    ti = state.get("tribes", {}).get(TRIBE_NERVII)
    if (ti and ti.get("allied_faction") is None and ti.get("status") is None
            and get_available(state, BELGAE, ALLY) > 0):
        place_piece(state, NERVII, BELGAE, ALLY)
        ti["allied_faction"] = BELGAE


def _command_executed(result) -> bool:
    """True when a Command result represents at least one legal effect.

    §4.1: a Special Ability accompanies a Command executed in at least one
    Region. An after-Command SA must therefore be withheld when the Command
    itself produced no legal effect (external mixed-matrix playtest, defect
    family 3: e.g. a failed zero-Resource Rally must not still award Trade).
    Before-Command SAs are unaffected (they need transactional handling --
    documented as an open item).
    """
    return bool(result) and result.get("executed") is not False


def _sa_runs_before_command(command, sa):
    """Whether a Command's accompanying Special Activity resolves BEFORE the
    Command rather than after.

    - Intimidate / Devastate / Entreat before a Battle remove or replace enemy
      pieces and so change that Battle's outcome (§8.7.1 / A8.7.1).
    - Roman Build resolves before a Recruit (§8.8.4: "Build before Recruit");
      after a March or Seize it resolves after (the default).
    """
    if command == _CMD_BATTLE and sa in _BEFORE_BATTLE_SAS:
        return True
    if command == _CMD_RECRUIT and sa == _SA_BUILD:
        return True
    return False


@preserve_supply_agreements
def execute_decision(state, faction, decision):
    """Execute a decision, rolling back a human turn that executes no Command.

    In particular an SA-before-Command may finance/enable the Command, but
    cannot survive on its own if that Command turns out to be impossible
    (§4.1). Preserve the live agent separately from the board snapshot.
    """
    action = decision.get("player_action") if not decision.get("bot_action") else None
    if action is None:
        from fs_bot.engine.diviciacus_planning import clear_confirmation
        try:
            return _execute_decision(state, faction, decision)
        finally:
            # A skipped or interrupted NP Command must not leave an old
            # agreement available for a later, independently chosen action.
            clear_confirmation(state, faction)
    from fs_bot.engine.action_validation import validate_human_structure
    from fs_bot.engine.game_engine import ACTION_LIMITED_COMMAND
    error = validate_human_structure(state, faction, action,
                                     limited=decision.get('action') == ACTION_LIMITED_COMMAND)
    if error:
        return {"executed": False, "command": action.get("command") if isinstance(action, dict) else None,
                "reason": error, "errors": [{"error": error}]}
    from copy import deepcopy
    agent = state.get("decision_agent")
    card_turn = state.get("_card_turn")
    snapshot = deepcopy({k: v for k, v in state.items() if k != "decision_agent"})
    try:
        result = _execute_decision(state, faction, decision)
    except BaseException:
        state.clear()
        state.update(snapshot)
        if agent is not None:
            state["decision_agent"] = agent
        if card_turn is not None:
            state["_card_turn"] = card_turn
        raise
    if not result.get("executed"):
        state.clear()
        state.update(snapshot)
        if agent is not None:
            state["decision_agent"] = agent
        if card_turn is not None:
            state["_card_turn"] = card_turn
        result["rolled_back"] = True
    return result


def _execute_decision(state, faction, decision):
    """Apply a recorded SoP decision to the board, if supported.

    Args:
        state: Game state dict. Modified in place when an action executes.
        faction: The acting faction constant.
        decision: The dict returned by the engine decision_func. For bot
            turns this contains ``bot_action`` (the full action dict).

    A decision carries its executable plan under ``bot_action`` (produced by a
    bot flowchart) or ``player_action`` (produced by a human player / UI). Both
    use the same action shape ({command, regions, sa, sa_regions, details}) and
    execute through the same machinery, so a mixed human/bot game resolves human
    turns identically to bot turns. The only difference: a human Event uses the
    params the player supplied (``details['event_params']``) rather than the NP
    auto-derivation (§8.2.3), since a human chooses for themselves.

    Returns:
        Result dict: always has ``executed`` (bool) and ``command`` (str);
        plus ``reason`` when not executed, or command-specific details when
        executed.
    """
    bot_action = decision.get("bot_action")
    is_human = False
    if not bot_action:
        bot_action = decision.get("player_action")
        is_human = bot_action is not None
    if not bot_action:
        # No executable plan. A human menu that selected only an action TYPE
        # (Command/Event without regions/SA/params) cannot be auto-executed
        # until the plan is collected; report rather than crash.
        return {"executed": False, "command": None,
                "reason": "decision carries no executable plan "
                          "(no bot_action or player_action)"}

    command = bot_action.get("command")

    # §1.5.2: voluntary Resource transfers ride the acting Faction's
    # Command/Event execution (details["transfers"] = [{"to", "amount"}]).
    # Transfer errors are reported, never block the Command itself.
    transfer_results = []
    for t in (bot_action.get("details") or {}).get("transfers") or []:
        from fs_bot.commands.transfer import transfer_resources
        try:
            transfer_results.append(
                transfer_resources(state, faction, t.get("to"),
                                   t.get("amount")))
        except Exception as exc:
            transfer_results.append({"error": str(exc),
                                     "to": t.get("to"),
                                     "amount": t.get("amount")})

    _COMMAND_HANDLERS = {
        _CMD_EVENT: _execute_event,
        _CMD_SEIZE: _execute_seize,
        _CMD_RAID: _execute_raid,
        _CMD_RALLY: _execute_rally,
        _CMD_BATTLE: _execute_battle,
        _CMD_RECRUIT: _execute_recruit,
        _CMD_MARCH: _execute_march,
    }
    def _attach_transfers(res):
        if transfer_results and isinstance(res, dict):
            res["transfers"] = transfer_results
        return res

    handler = _COMMAND_HANDLERS.get(command)
    if is_human and command == _CMD_RECRUIT:
        handler = lambda board, actor, plan: _execute_recruit(board, actor, plan, _exact=True)
    if handler is not None:
        sa = bot_action.get("sa")
        from fs_bot.commands.sa_enlist import is_borrow_plan
        if is_borrow_plan(bot_action):
            result = _execute_borrowed_command(state, faction, bot_action, handler)
            _apply_end_of_action_capabilities(state)
            return _attach_transfers(result)
        if not is_human and faction == _ARVERNI_F and command == _CMD_BATTLE:
            result = _execute_arverni_paid_battle(state, faction, bot_action)
            _apply_end_of_action_capabilities(state)
            return _attach_transfers(result)
        from fs_bot.bots.arverni_bot import MARCH_THREAT
        plan = (bot_action.get("details") or {}).get("march_plan") or {}
        if (not is_human and faction == _ARVERNI_F and command == _CMD_MARCH
                and plan.get("type") == MARCH_THREAT):
            result = _execute_arverni_threat_march(state, faction, bot_action)
            _apply_end_of_action_capabilities(state)
            return _attach_transfers(result)
        # Some SAs resolve BEFORE the Command they accompany: Intimidate,
        # Devastate, and Entreat before a Battle remove/replace enemy pieces
        # and so change that Battle's outcome (§8.7.1 / A8.7.1 / §4.x). Run
        # those first; all other standalone SAs run after the Command. Battle-
        # modifying SAs (Ambush/Besiege) are applied inside _execute_battle.
        # §4.1: human ordering is explicit; only bots use flowchart timing.
        timing = bot_action.get("sa_timing") or (
            "after" if is_human else
            ("before" if _sa_runs_before_command(command, sa) else "after"))
        before = timing == "before"
        sa_result = None
        if timing == "during" and sa not in _BATTLE_MODIFYING_SAS:
            parts = (bot_action.get("details") or {}).get("command_parts") or []
            if len(parts) != 2:
                return {"executed": False, "command": command,
                        "reason": "Interrupted Command needs two portions"}
            first = handler(state, faction, parts[0])
            sa_result = _execute_sa(state, faction, bot_action)
            second = handler(state, faction, parts[1])
            result = {"executed": _command_executed(first) or _command_executed(second),
                      "command": command, "command_parts": [first, second],
                      "errors": (first.get("errors") or []) + (second.get("errors") or []),
                      "sa_execution": sa_result, "sa_timing": "during"}
            _apply_end_of_action_capabilities(state)
            return _attach_transfers(result)
        if before:
            sa_result = _execute_sa(state, faction, bot_action)
        if command == _CMD_EVENT:
            result = _execute_event(state, faction, bot_action,
                                    human=is_human)
        else:
            result = handler(state, faction, bot_action)
        if not before:
            if (command == _CMD_EVENT or _command_executed(result)
                    or _sa_survives_empty_command(faction, command, sa)):
                sa_result = _execute_sa(state, faction, bot_action)
            else:
                result = dict(result)
                result["sa_skipped"] = "command produced no legal effect"
        if sa_result is not None:
            result = dict(result)
            result["sa_execution"] = sa_result
            result["sa_timing"] = "before" if before else "after"
        _apply_end_of_action_capabilities(state)
        return _attach_transfers(result)
    # Pass / None / unknown
    return {"executed": False, "command": command,
            "reason": "no executable command"}


def _sa_survives_empty_command(faction, command, sa):
    """A8.7.4: the German 'Rally and Settle' is ONE combined node — the
    Germans take it "if doing EITHER would place a Germanic Ally, a
    Settlement, or at least four Germanic Warbands" — so the Settle SA
    executes even when the Rally itself placed nothing. Everywhere else
    the flowcharts' IF-NONE means an SA must not ride a no-effect Command
    (the wasteful-sa rule). Found by play_quality telemetry: the skip was
    wasting the Germans' whole turn ~10 times per 20 games.
    """
    from fs_bot.rules_consts import GERMANS as _G
    return (faction == _G and command == _CMD_RALLY
            and sa == _SA_SETTLE)


def _execute_borrowed_command(state, faction, action, handler):
    """§4.5.1 option 1 applies for the Command and expires immediately."""
    from fs_bot.commands.sa_enlist import begin_borrow, end_borrow, BORROW_KEY
    if faction != _BELGAE_F or action.get("command") not in (
            _CMD_RALLY, _CMD_MARCH, _CMD_RAID, _CMD_BATTLE):
        return {"executed": False, "command": action.get("command"),
                "reason": "Only a Belgic Command may borrow German Warbands"}
    parts = (action.get("details") or {}).get("command_parts") or []
    first = None
    if parts:
        if action.get("sa_timing") != "during" or len(parts) != 2:
            return {"executed": False, "command": action.get("command"),
                    "reason": "Interrupted Enlist needs two Command portions"}
        first = handler(state, faction, parts[0])
    try:
        begin_borrow(state, action)
    except _EXEC_ERRORS as exc:
        return {"executed": False, "command": action.get("command"),
                "reason": str(exc), "errors": [{"error": str(exc)}]}
    try:
        result = handler(state, faction, parts[1] if parts else action)
        affected = state[BORROW_KEY]["affected"]
    finally:
        end_borrow(state)
    if first is not None:
        result = {"executed": _command_executed(first) or _command_executed(result),
                  "command": action["command"], "command_parts": [first, result],
                  "errors": (first.get("errors") or []) + (result.get("errors") or [])}
    result["sa_execution"] = {"executed": bool(affected) and _command_executed(result),
                              "sa": _SA_ENLIST, "type": "borrow",
                              "affected_warbands": affected}
    result["sa_timing"] = "during"
    return result


def _execute_bot_command(state, faction, bot_action, *, with_sa=False):
    """Execute an Event-granted Command; add an SA only when text grants it."""
    from fs_bot.commands.common import free_action_scope
    action = dict(bot_action)
    if not with_sa:
        action["sa"] = SA_ACTION_NONE_LABEL
        action["sa_regions"] = []
    with free_action_scope(state, faction):
        return _execute_free_bot_command(state, faction, action)


def _execute_free_bot_command(state, faction, bot_action):
    """Route a bot_action's Command (never an Event) to the matching command
    executor. Returns the result dict, or None if the command is not one of
    the wired board Commands."""
    cmd = bot_action.get("command")
    handlers = {
        _CMD_SEIZE: _execute_seize, _CMD_RAID: _execute_raid,
        _CMD_RALLY: _execute_rally, _CMD_BATTLE: _execute_battle,
        _CMD_RECRUIT: _execute_recruit, _CMD_MARCH: _execute_march,
    }
    h = handlers.get(cmd)
    if h is None:
        return None
    from fs_bot.commands.sa_enlist import is_borrow_plan
    if is_borrow_plan(bot_action):
        return _execute_borrowed_command(state, faction, bot_action, h)
    sa = bot_action.get("sa")
    timing = bot_action.get("sa_timing")
    before = (timing == "before" if timing else _sa_runs_before_command(cmd, sa))
    sa_result = None
    if timing == "during":
        parts = (bot_action.get("details") or {}).get("command_parts") or []
        first = h(state, faction, parts[0])
        sa_result = _execute_sa(state, faction, bot_action)
        second = h(state, faction, parts[1])
        return {"executed": _command_executed(first) or _command_executed(second),
                "command": cmd, "command_parts": [first, second],
                "errors": (first.get("errors") or []) + (second.get("errors") or []),
                "sa_execution": sa_result, "sa_timing": "during"}
    if before:
        sa_result = _execute_sa(state, faction, bot_action)
    result = (_execute_march(state, faction, bot_action, free=True)
              if cmd == _CMD_MARCH else h(state, faction, bot_action))
    if not before:
        if (_command_executed(result)
                or _sa_survives_empty_command(faction, cmd, sa)):
            sa_result = _execute_sa(state, faction, bot_action)
        else:
            result = dict(result)
            result["sa_skipped"] = "command produced no legal effect"
    if sa_result is not None:
        result = dict(result)
        result["sa_execution"] = sa_result
    return result


def _primary_command_region(bot_action):
    """The first Region a Command's plan acts in/from (for a Limited Command's
    single-Region restriction)."""
    cmd = bot_action.get("command")
    d = bot_action.get("details") or {}
    def reg_of(e):
        return e if isinstance(e, str) else (e.get("region") if isinstance(e, dict) else None)
    if cmd == _CMD_BATTLE:
        plan = d.get("battle_plan") or []
        return reg_of(plan[0]) if plan else None
    if cmd == _CMD_RAID:
        plan = d.get("raid_plan") or []
        return reg_of(plan[0]) if plan else None
    if cmd == _CMD_RECRUIT:
        plan = d.get("recruit_plan") or []
        return reg_of(plan[0]) if plan else None
    if cmd == _CMD_RALLY:
        rp = d.get("rally_plan") or {}
        if 'steps' in rp:
            from fs_bot.commands.rally import rally_plan_steps
            steps = rally_plan_steps(rp)
            return steps[0]['region'] if steps else None
        for k in ("citadels", "allies", "warbands"):
            if rp.get(k):
                return reg_of(rp[k][0])
        return None
    if cmd == _CMD_SEIZE:
        regs = bot_action.get("regions") or []
        return regs[0] if regs else None
    if cmd == _CMD_MARCH:
        plan = d.get("march_plan") or d
        if plan.get("explicit_moves"):
            return plan["explicit_moves"][0].get("origin")
        if plan.get("origin"):
            return plan["origin"]
        origins = plan.get("origins") or []
        if origins:
            o = origins[0]
            return o[0] if isinstance(o, (list, tuple)) else o
        return None
    return None


def _constrain_bot_action(bot_action, allowed, *, state=None, faction=None,
                          constrain_sa=True):
    """Filter a chosen Command's plan to ``allowed`` Regions (for an event's
    "in/from <Region>" restriction). Returns a constrained copy of the action,
    or None if the Command has no action left within the allowed Regions.
    March is constrained to groups marching FROM an allowed Region ("from the
    destination Region")."""
    cmd = bot_action.get("command")
    ba = dict(bot_action)
    d = dict(bot_action.get("details") or {})

    def reg_of(e):
        return e if isinstance(e, str) else e.get("region")

    if cmd == _CMD_BATTLE:
        plan = [e for e in (d.get("battle_plan") or []) if reg_of(e) in allowed]
        if not plan:
            return None
        d["battle_plan"] = plan
    elif cmd == _CMD_RAID:
        plan = [e for e in (d.get("raid_plan") or []) if reg_of(e) in allowed]
        if not plan:
            return None
        d["raid_plan"] = plan
    elif cmd == _CMD_RECRUIT:
        plan = [e for e in (d.get("recruit_plan") or []) if reg_of(e) in allowed]
        if not plan:
            return None
        d["recruit_plan"] = plan
    elif cmd == _CMD_RALLY:
        rp = d.get("rally_plan") or {}
        if 'steps' in rp:
            from fs_bot.commands.rally import rally_plan_steps
            new = {'steps': [entry for entry in rally_plan_steps(rp) if entry['region'] in allowed]}
        else:
            new = {k: [e for e in (rp.get(k) or []) if reg_of(e) in allowed]
                   for k in ("citadels", "allies", "warbands")}
        # A8.7.4 selects German Rally + Settle when EITHER places pieces.
        # A scoped grant must retain an in-scope Settlement-only plan just
        # as the live executor does, without admitting an empty Rally or an
        # SA whose only destinations lie outside this grant.
        if (_sa_survives_empty_command(faction, cmd, bot_action.get("sa"))
                and (state is None or state.get("_command_with_sa", True))):
            for key in ("settlements_before", "settlements_after"):
                new[key] = [entry for entry in (rp.get(key) or [])
                            if reg_of(entry) in allowed
                            and reg_of(entry) in (bot_action.get("sa_regions") or [])]
        if not any(new.values()):
            return None
        d["rally_plan"] = new
    elif cmd == _CMD_SEIZE:
        regs = [r for r in (bot_action.get("regions") or []) if r in allowed]
        if not regs:
            return None
        ba["regions"] = regs
        d["disperse_regions"] = [r for r in (d.get("disperse_regions") or [])
                                 if r in allowed]
    elif cmd == _CMD_MARCH:
        if state is not None and faction is not None:
            # Expand plans have singular origins and implicit Leader moves;
            # normalize every physical group before applying an origin limit.
            # This also clips extra_groups, without narrowing destinations.
            moves, _ = _collect_march_moves(state, faction, ba)
            moves = [m for m in moves if m.get("origin") in allowed]
            if not moves:
                return None
            plan = dict(d.get("march_plan") or d)
            plan["explicit_moves"] = moves
            plan["origins"] = list(dict.fromkeys(m["origin"] for m in moves))
            plan["destinations"] = list(dict.fromkeys(
                region for move in moves for region in move.get("path", ())))
            d["march_plan"] = plan
        else:
            plan = d.get("march_plan") or d
            origins = plan.get("origins") or []
            def onorm(o):
                return o[0] if isinstance(o, (list, tuple)) else o
            keep = [o for o in origins if onorm(o) in allowed]
            singular = plan.get("origin")
            if not keep and singular not in allowed:
                return None
            mp = dict(plan)
            mp["origins"] = keep
            if singular not in allowed:
                mp.pop("origin", None)
            for key in ("routes", "groups"):
                if key in mp:
                    mp[key] = {r: v for r, v in mp[key].items() if r in allowed}
            if "extra_groups" in mp:
                mp["extra_groups"] = [e for e in mp["extra_groups"]
                                      if e.get("origin") in allowed]
            # The executor still needs the scope to filter implicit Leaders.
            mp["allowed_origins"] = sorted(allowed)
            d["march_plan"] = mp
    else:
        return None
    ba["details"] = d
    ba["regions"] = [r for r in (bot_action.get("regions") or []) if r in allowed]
    if constrain_sa:
        ba["sa_regions"] = [r for r in (bot_action.get("sa_regions") or [])
                            if reg_of(r) in allowed]
    return ba


@free_action
def _resolve_free_command(state, faction, allowed_regions=None,
                          exclude_commands=None, limited=False, with_sa=False,
                          _planner=None, _consult=True, allow_decline=True):
    """Execute one *free* Command for ``faction`` using its real flowchart.

    Event cards that grant "a free Command" (e.g. card 9 Mons Cevenna, card 70
    shaded) let the Faction take one Command of its choice. The faithful chooser
    is the Faction's own bot flowchart: we ask it for an action with Event-play
    disabled (so it returns a Command + Special Ability, not another Event or a
    recursive Event play), then execute that Command through the existing
    command executors. Game-run Factions (Germans in base, Arverni in
    Ariovistus) have no bot flowchart and are skipped.

    Apply the flowchart's conditions and priorities to the permitted action
    Regions (§8.2.3), preserving the full board for strategic totals, Control,
    Supply Lines, and March destinations. Event exclusions disable branches;
    Sequence-of-Play Pass and Event opportunities do not apply to this grant.
    """
    from fs_bot.bots.bot_dispatch import dispatch_bot_turn
    from fs_bot.engine.free_actions import (command_options, consult_free_action,
                                             execute_free_action_plan)
    request = {"kind": "free_action", "request_type": "event_command",
               "allowed_commands": [cmd for cmd in command_options(faction)
                                    if cmd not in (exclude_commands or ())],
               "allowed_regions": sorted(allowed_regions) if allowed_regions is not None else None,
               "max_regions": 1 if limited else None, "with_sa": with_sa,
               "free": True}
    if not allow_decline:
        request["allow_decline"] = False
    # A caller may already have accepted an explicit interface default (for
    # example Council). Skip only this initial choice; actual Command reactions
    # still use the live decision agent normally.
    response = consult_free_action(state, faction, request) if _consult else None
    if response is not None:
        if response.get("decline"):
            return {"executed": False, "command": None, "reason": "free Command declined"}
        return execute_free_action_plan(state, faction, request, response)
    from fs_bot.engine.diviciacus import force_scope
    from fs_bot.engine.diviciacus_planning import (
        plan_with_diviciacus, confirm_plan, clear_confirmation)
    denied_regions = set()
    while True:
        planning_state = _free_command_planning_state(
            state, faction, allowed_regions, exclude_commands, with_sa=with_sa)
        planning_state['_diviciacus_refused'] = {faction: sorted(denied_regions)}
        try:
            bot_action = (plan_with_diviciacus(planning_state, faction, _planner) if _planner is not None
                          else dispatch_bot_turn(planning_state, faction))
            if not isinstance(bot_action, dict):
                raise ValueError("flowchart did not return an action")
            cmd = bot_action.get("command")
            if cmd == "Pass":
                _commit_planning_rng(state, planning_state)
                return {"executed": False, "command": None,
                        "declined_no_effect": True,
                        "reason": "no applicable free Command after flowchart priorities"}
            if cmd in (None, _CMD_EVENT) or cmd in set(exclude_commands or ()):
                raise ValueError(f"flowchart selected a disallowed free Command: {cmd!r}")
            with force_scope(planning_state, faction,
                             (bot_action.get("details") or {}).get("diviciacus_regions", [])):
                if allowed_regions is not None:
                    bot_action = _constrain_bot_action(
                        bot_action, set(allowed_regions), state=planning_state, faction=faction)
                    if bot_action is None:
                        raise ValueError("scoped flowchart selected no action in the allowed Regions")
                if limited:
                    # Normalize implicit March origins even without a geographic grant.
                    if bot_action.get("command") == _CMD_MARCH and allowed_regions is None:
                        bot_action = _constrain_bot_action(
                            bot_action, set(get_playable_regions_for_state(planning_state, faction)),
                            state=planning_state, faction=faction, constrain_sa=False)
                    # Choose the first Region AFTER intersecting the Event scope.
                    primary = _primary_command_region(bot_action)
                    if primary is not None:
                        if cmd in (_CMD_RALLY, _CMD_RECRUIT):
                            planning_state, bot_action = _replan_placement_regions(
                                planning_state, faction, cmd, {primary}, bot_action)
                        else:
                            bot_action = _constrain_bot_action(
                                bot_action, {primary}, state=planning_state, faction=faction,
                                constrain_sa=False)
                if bot_action is None:
                    raise ValueError("flowchart selected an empty Limited Command")
        except Exception as exc:
            return {"executed": False, "command": None, "reason": repr(exc)}
        # Live agreement belongs to this concrete, already-scoped grant. A
        # refusal reruns the same grant from its original RNG, before costs or
        # pieces change. Detached previews never consume a human response.
        refused = confirm_plan(state, faction, bot_action)
        new_refusals = set(refused) - denied_regions
        if not new_refusals:
            break
        denied_regions.update(new_refusals)
    _commit_planning_rng(state, planning_state)
    try:
        with _command_execution_scope(state, allowed_regions, with_sa):
            res = _execute_bot_command(state, faction, bot_action, with_sa=with_sa)
    finally:
        clear_confirmation(state, faction, bot_action)
    if res is None:
        return {"executed": False, "command": cmd,
                "reason": "chosen Command not executable"}
    return res


def _free_command_planning_state(state, faction, allowed_regions=None,
                                  exclude_commands=None, forced_command=None,
                                  with_sa=False):
    """Detached planning with the real board and only action-local constraints.

    Never carry a live human decision callback into a hypothetical Supply
    Line/Retreat preview. Only the accepted plan's RNG position is committed.
    """
    from copy import deepcopy
    planning = deepcopy({k: v for k, v in state.items() if k != "decision_agent"})
    planning["non_player_factions"] = set(state.get("non_player_factions", ())) | {faction}
    planning["can_play_event"] = False
    planning["is_second_eligible"] = False
    planning["is_limited"] = False
    planning["_planning_free_command"] = True
    planning["_diviciacus_preview"] = True
    planning["_free_action_factions"] = set(planning.get("_free_action_factions", ())) | {faction}
    planning["_command_region_scope"] = (None if allowed_regions is None
                                         else set(allowed_regions))
    planning["_command_exclusions"] = set(exclude_commands or ())
    planning["_planning_forced_command"] = forced_command
    planning["_command_with_sa"] = bool(with_sa)
    return planning


def _replan_placement_regions(planning, faction, command, regions, original):
    """Allocate Available pieces only among Regions retained by the Event cap."""
    import importlib
    nodes = {
        _ROMANS_F: ("roman", "node_r_recruit"),
        _ARVERNI_F: ("arverni", "node_v_rally"),
        _AEDUI_F: ("aedui", "node_a_rally"),
        _BELGAE_F: ("belgae", "node_b_rally"),
        _GERMANS_F: ("german", "node_g_rally"),
    }
    module, name = nodes[faction]
    narrowed = _free_command_planning_state(
        planning, faction, regions, forced_command=command,
        with_sa=planning.get("_command_with_sa", False))
    action = getattr(importlib.import_module(f"fs_bot.bots.{module}_bot"), name)(narrowed)
    if not isinstance(action, dict) or action.get("command") != command:
        raise ValueError("retained placement Region no longer has its selected Command")
    action = _constrain_bot_action(action, set(regions), state=narrowed,
                                   faction=faction, constrain_sa=False)
    if action is None:
        raise ValueError("retained placement Region has no legal planned placement")
    # A Limited Command's Region limit does not itself limit an explicitly
    # granted accompanying SA (Druids); retain that separate chosen plan.
    for key in ("sa", "sa_regions", "sa_timing"):
        if key in original:
            action[key] = original[key]
    details = dict(original.get("details") or {})
    plan_key = "recruit_plan" if command == _CMD_RECRUIT else "rally_plan"
    details[plan_key] = action["details"][plan_key]
    action["details"] = details
    return narrowed, action


def _command_execution_scope(state, allowed_regions, with_sa):
    """Keep live SA re-planning inside the Event grant, restoring nested scopes."""
    from contextlib import contextmanager
    @contextmanager
    def scoped():
        missing = object()
        values = {"_command_region_scope": (None if allowed_regions is None
                                             else set(allowed_regions)),
                  "_command_with_sa": bool(with_sa)}
        previous = {key: state.get(key, missing) for key in values}
        state.update(values)
        try:
            yield
        finally:
            for key, value in previous.items():
                if value is missing:
                    state.pop(key, None)
                else:
                    state[key] = value
    return scoped()


def _commit_planning_rng(state, planning):
    if "rng" in state and "rng" in planning:
        state["rng"].setstate(planning["rng"].getstate())


def _region_restricted_free_command(state, faction, allowed_regions,
                                    exclude_commands=None):
    """Plan through the complete flowchart with its regional scope (§8.2.3).

    No action means the flowchart exhausted its priorities. Exceptions and
    malformed plans remain errors rather than silently trying unrelated nodes.
    """
    from fs_bot.bots.bot_dispatch import dispatch_bot_turn
    planning = _free_command_planning_state(state, faction, allowed_regions,
                                            exclude_commands)
    action = dispatch_bot_turn(planning, faction)
    if action.get("command") == "Pass":
        _commit_planning_rng(state, planning)
        return None
    if action.get("command") in set(exclude_commands or ()):
        raise ValueError("flowchart returned an excluded free Command")
    constrained = _constrain_bot_action(action, allowed_regions,
                                         state=planning, faction=faction)
    if constrained is None:
        raise ValueError("scoped flowchart returned an out-of-scope action")
    _commit_planning_rng(state, planning)
    return constrained


def _plan_region_order(bot_action):
    """Distinct Regions of a Rally/Recruit plan, in the plan's own priority
    order (Citadels, then Allies, then Warbands for a Rally plan)."""
    d = (bot_action.get("details") or {})

    def reg_of(e):
        return e if isinstance(e, str) else e.get("region")

    rp = d.get("rally_plan")
    if isinstance(rp, dict):
        from fs_bot.commands.rally import rally_plan_steps
        seq = rally_plan_steps(rp)
    else:
        seq = d.get("recruit_plan") or []
    seen, order = set(), []
    for e in seq:
        r = reg_of(e)
        if r and r not in seen:
            seen.add(r)
            order.append(r)
    return order


@free_action
def _resolve_free_rally(state, faction, allowed_regions=None,
                        max_regions=None, *, as_if_control=False,
                        allow_devastated=False):
    from fs_bot.engine.free_actions import (rally_event_scope, consult_free_action,
                                             execute_free_action_plan)
    request = {"kind": "free_action", "request_type": "event_rally",
               "allowed_commands": [_CMD_RECRUIT if faction == _ROMANS_F else _CMD_RALLY],
               "allowed_regions": sorted(allowed_regions) if allowed_regions is not None else None,
               "max_regions": max_regions, "with_sa": False, "free": True,
               "as_if_control": as_if_control, "allow_devastated": allow_devastated}
    with rally_event_scope(state, faction, as_if_control=as_if_control,
                           allow_devastated=allow_devastated, regions=allowed_regions):
        response = consult_free_action(state, faction, request)
        if response is not None:
            if response.get("decline"):
                return {"executed": False, "command": request["allowed_commands"][0],
                        "reason": "free Rally declined"}
            return execute_free_action_plan(state, faction, request, response)
        return _resolve_free_rally_default(state, faction, allowed_regions, max_regions)


def _resolve_free_rally_default(state, faction, allowed_regions=None,
                                max_regions=None):
    """Execute a *free* Rally (Recruit for the Romans) for ``faction`` using
    that Faction's own Rally node — node_a/v/b/g_rally, or node_r_recruit. The
    node returns a Rally/Recruit action with its plan; we execute it through
    the command executors, optionally restricting to ``allowed_regions``.
    Game-run Factions and any non-Rally fallthrough yield no action."""
    nodes = {
        "Aedui": ("fs_bot.bots.aedui_bot", "node_a_rally"),
        "Arverni": ("fs_bot.bots.arverni_bot", "node_v_rally"),
        "Belgae": ("fs_bot.bots.belgae_bot", "node_b_rally"),
        "Germans": ("fs_bot.bots.german_bot", "node_g_rally"),
        "Romans": ("fs_bot.bots.roman_bot", "node_r_recruit"),
    }
    spec = nodes.get(faction)
    if spec is None:
        return {"executed": False, "command": None,
                "reason": "no Rally node for Faction"}
    import importlib
    command = _CMD_RECRUIT if faction == _ROMANS_F else _CMD_RALLY
    from fs_bot.engine.diviciacus import force_scope
    from fs_bot.engine.diviciacus_planning import (
        plan_with_diviciacus, confirm_plan, clear_confirmation)
    denied_regions = set()
    while True:
        planning = _free_command_planning_state(
            state, faction, allowed_regions, forced_command=command)
        planning['_diviciacus_refused'] = {faction: sorted(denied_regions)}
        try:
            node = getattr(importlib.import_module(spec[0]), spec[1])
            bot_action = plan_with_diviciacus(planning, faction, node)
            if not isinstance(bot_action, dict):
                raise ValueError("Rally node did not return an action")
            cmd = bot_action.get("command")
            if cmd != command:
                if cmd not in (_CMD_BATTLE, _CMD_MARCH, _CMD_RAID, _CMD_SEIZE, "Pass"):
                    raise ValueError(f"Rally node returned an invalid action: {cmd!r}")
                # The forced Rally process's IF NONE means its placement
                # priorities were exhausted; do not execute its other Command.
                _commit_planning_rng(state, planning)
                return {"executed": False, "command": command,
                        "declined_no_effect": True,
                        "reason": "no placement available for the granted Rally"}
            with force_scope(planning, faction,
                             (bot_action.get("details") or {}).get("diviciacus_regions", [])):
                if allowed_regions is not None:
                    bot_action = _constrain_bot_action(bot_action, set(allowed_regions),
                                                       state=planning, faction=faction)
                    if bot_action is None:
                        raise ValueError("scoped Rally node selected no allowed Region")
                if max_regions is not None:
                    order = _plan_region_order(bot_action)
                    if len(order) > max_regions:
                        planning, bot_action = _replan_placement_regions(
                            planning, faction, command, set(order[:max_regions]), bot_action)
        except Exception as exc:
            return {"executed": False, "command": command, "reason": repr(exc)}
        refused = set(confirm_plan(state, faction, bot_action)) - denied_regions
        if not refused:
            break
        denied_regions.update(refused)
    _commit_planning_rng(state, planning)
    try:
        res = _execute_bot_command(state, faction, bot_action)
    finally:
        clear_confirmation(state, faction, bot_action)
    return res if res is not None else {"executed": False, "command": cmd,
                                        "reason": "Rally not executable"}


# ===========================================================================
# Free-action execution layer (event-granted free Battles/Commands)
# ---------------------------------------------------------------------------
# Several Ariovistus A-cards grant the acting Faction a *free* Battle (or
# Command) within a constrained Region set, sometimes forbidding the
# defender's Retreat. The card handlers set descriptive flags in
# ``state["event_modifiers"]``; nothing consumed them. This layer reads those
# flags after the Event resolves and runs the granted action through the
# existing command executors, choosing targets per the NP Battle guidance
# (§8.8.1 spirit: hit Leaders, then the most enemy mobile force, where the
# acting Faction has an attacking presence).
# ===========================================================================

_BATTLE_PIECE_TYPES = None  # filled lazily to avoid import-time cycles


def _attacker_has_force(state, region, faction):
    """True if ``faction`` has at least one Battle-capable piece in region."""
    from fs_bot.rules_consts import LEGION, AUXILIA, WARBAND
    from fs_bot.board.pieces import count_pieces, get_leader_in_region
    if get_leader_in_region(state, region, faction) is not None:
        return True
    return any(count_pieces(state, region, faction, pt) > 0
               for pt in (LEGION, AUXILIA, WARBAND))


def _rank_free_battle_defender(state, region, faction):
    """Pick the best enemy to Battle in ``region`` for ``faction``.

    Generic §8.8.1-style priority: Leader present, then most Warbands+Legions,
    then most Allies+Citadels in the Region. Returns a faction or None.
    """
    from fs_bot.rules_consts import (FACTIONS, WARBAND, LEGION, AUXILIA,
                                     ALLY, CITADEL)
    from fs_bot.board.pieces import count_pieces, get_leader_in_region
    best, best_key = None, None
    for enemy in FACTIONS:
        if enemy == faction:
            continue
        if count_pieces(state, region, enemy) <= 0:
            continue
        has_leader = 1 if get_leader_in_region(state, region, enemy) else 0
        # Mobile = all Battle-removable mobile pieces (Warbands, Auxilia,
        # Legions) — Roman mobile force is Auxilia+Legions, not Warbands.
        mobile = (count_pieces(state, region, enemy, WARBAND)
                  + count_pieces(state, region, enemy, AUXILIA)
                  + count_pieces(state, region, enemy, LEGION))
        struct = (count_pieces(state, region, enemy, ALLY)
                  + count_pieces(state, region, enemy, CITADEL))
        key = (has_leader, mobile, struct)
        if best_key is None or key > best_key:
            best, best_key = enemy, key
    return best


def _resolve_card_A34_german_pieces(state, faction, limit=3):
    from fs_bot.cards.divination import resolve_divination
    return resolve_divination(state, faction, limit)


def _predicted_legion_losses(state, region, attacker):
    """Losses that would fall on Roman Legions if ``attacker`` Battles Romans
    in ``region`` (no Retreat). Romans absorb with Auxilia before Legions
    (default loss order), so Legion Losses = min(Legions, total - Auxilia).

    Implements the Belgic NP instruction "Battle where most Losses forced on
    Legions" for the A21/A28/A57/Legiones card group.
    """
    from fs_bot.rules_consts import ROMANS, LEGION, AUXILIA
    from fs_bot.board.pieces import count_pieces
    from fs_bot.battle.losses import calculate_losses
    if count_pieces(state, region, ROMANS) <= 0:
        return 0
    legions = count_pieces(state, region, ROMANS, LEGION)
    auxilia = count_pieces(state, region, ROMANS, AUXILIA)
    try:
        total = calculate_losses(state, region, attacker, ROMANS,
                                 is_retreat=False)
    except Exception:
        return 0
    return max(0, min(legions, total - auxilia))


def _german_warband_floor_ok(state, region, faction, defender):
    """German NP instruction: "Battle only where Counterattack would not leave
    Ariovistus with fewer than 4 Warbands." The floor only binds in the Region
    holding Ariovistus; elsewhere his Warbands are not in the Battle.
    """
    from fs_bot.rules_consts import (GERMANS, WARBAND, ARIOVISTUS_LEADER)
    from fs_bot.board.pieces import count_pieces, get_leader_in_region
    from fs_bot.battle.losses import calculate_losses
    if get_leader_in_region(state, region, GERMANS) != ARIOVISTUS_LEADER:
        return True
    german_wb = count_pieces(state, region, GERMANS, WARBAND)
    try:
        # Conservative: predict counterattack Losses from the current (pre-
        # attack) defender — an upper bound on German Warbands lost.
        ca = calculate_losses(state, region, defender, GERMANS,
                              is_counterattack=True)
    except Exception:
        ca = 0
    return (german_wb - ca) >= 4


def _choose_free_battle(state, faction, allowed_regions):
    """Choose (region, defender) for a free Battle over ``allowed_regions``.

    Among Regions where the acting Faction has an attacking force and an enemy
    is present, pick the Region with the most enemy mobile pieces (most damage
    potential), then the top-ranked defender there.
    """
    from fs_bot.rules_consts import WARBAND, LEGION, AUXILIA, BELGAE, GERMANS
    from fs_bot.board.pieces import count_pieces

    # Belgic NP: "Battle where most Losses forced on Legions; if none, no
    # play." Score each Region by predicted Roman Legion Losses.
    # Iterate candidates in sorted order: ``allowed_regions`` is often a
    # set (e.g. _free_battle_region_set), and the strict > comparisons
    # break score ties by iteration order — set order would leak
    # PYTHONHASHSEED into the choice (found by the player_fuzz cross-
    # hashseed oracle; see QUESTIONS.md).
    if faction == BELGAE:
        best = None  # (region, defender, legion_losses)
        for region in sorted(allowed_regions):
            if not _attacker_has_force(state, region, faction):
                continue
            ll = _predicted_legion_losses(state, region, faction)
            if ll > 0 and (best is None or ll > best[2]):
                from fs_bot.rules_consts import ROMANS
                best = (region, ROMANS, ll)
        return (best[0], best[1]) if best else (None, None)

    best = None  # (region, defender, enemy_mobile)
    for region in sorted(allowed_regions):
        if not _attacker_has_force(state, region, faction):
            continue
        defender = _rank_free_battle_defender(state, region, faction)
        if defender is None:
            continue
        # German NP: skip Regions that would drop Ariovistus below 4 Warbands.
        if faction == GERMANS and not _german_warband_floor_ok(
                state, region, faction, defender):
            continue
        enemy_mobile = (count_pieces(state, region, defender, WARBAND)
                        + count_pieces(state, region, defender, AUXILIA)
                        + count_pieces(state, region, defender, LEGION))
        if best is None or enemy_mobile > best[2]:
            best = (region, defender, enemy_mobile)
    return (best[0], best[1]) if best else (None, None)


def _plan_free_battle_command(state, faction, allowed_regions, *,
                              no_retreat=False, second=False):
    """Finalize one Event Battle with the pieces its owners actually lend."""
    from fs_bot.engine.diviciacus_planning import plan_with_diviciacus
    allowed_regions = set(allowed_regions)
    def planner(sim):
        if second:
            region = next(iter(sorted(allowed_regions)), None)
            defender = _second_battle_worthwhile(sim, faction, region) if region else None
        else:
            region, defender = _choose_free_battle(sim, faction, allowed_regions)
        if region is None or defender is None:
            return {"command": "Pass"}
        details = {"battle_plan": [{"region": region, "target": defender}]}
        if no_retreat:
            details["no_retreat"] = True
        return {"command": _CMD_BATTLE, "sa": SA_ACTION_NONE_LABEL,
                "regions": [region], "sa_regions": [], "details": details}
    with _command_execution_scope(state, allowed_regions, False):
        action = plan_with_diviciacus(state, faction, planner)
    if action.get("command") != _CMD_BATTLE:
        return None
    _request_event_diviciacus(state, faction, action, state.get("current_card"))
    return action


def _within1_of(state, region):
    """Region set = the Region itself plus its adjacencies."""
    from fs_bot.map.map_data import get_adjacent
    return {region, *get_adjacent(region, state["scenario"])}


def _free_battle_region_set(state, flag):
    """Map a free-Battle event flag to its constrained Region set."""
    from fs_bot.rules_consts import SEQUANI, BELGICA_REGIONS
    if flag in ("card_A21_first_no_retreat",):
        return _within1_of(state, SEQUANI)
    if flag in ("card_A57_first_no_retreat",):
        return set(BELGICA_REGIONS)
    if flag in ("card_A28_combined_battle",):
        return _within1_of(state, SEQUANI)  # "in and adjacent to Sequani"
    return set()


# Event-modifier flags that grant a single no-Retreat free Battle.
_FREE_FIRST_BATTLE_FLAGS = (
    "card_A21_first_no_retreat",
    "card_A57_first_no_retreat",
)

# First-Battle flag -> the matching "optional second Battle there" flag
# (Retreat allowed for the second Battle). §A-card text for A21/A57.
_DOUBLE_BATTLE_FLAG = {
    "card_A21_first_no_retreat": "card_A21_double_battle",
    "card_A57_first_no_retreat": "card_A57_double_battle",
}


def _second_battle_worthwhile(state, faction, region):
    """NP willingness for the optional second free Battle in ``region``.

    The acting Faction takes the second Battle only if it still has an
    attacking force there and a defender with mobile pieces remains (so the
    Battle can still inflict a Loss). Returns the defender or None.
    """
    from fs_bot.rules_consts import WARBAND, LEGION, AUXILIA
    from fs_bot.board.pieces import count_pieces
    if not _attacker_has_force(state, region, faction):
        return None
    defender = _rank_free_battle_defender(state, region, faction)
    if defender is None:
        return None
    enemy_mobile = (count_pieces(state, region, defender, WARBAND)
                    + count_pieces(state, region, defender, AUXILIA)
                    + count_pieces(state, region, defender, LEGION))
    return defender if enemy_mobile > 0 else None



# One-shot Event flags consumed by _resolve_free_actions. Immediate
# free actions must not survive into later Events: stale flags made a
# later unrelated Event replay old free Commands/Battles (external
# mixed-matrix playtest, defect family 1). Persistent modifiers read
# by later phases (lost_eagle_no_shift_down, optimates_active,
# card_A63_quarters_devastated_only, card_A66_winter_uprising) are
# deliberately NOT listed.
_ONE_SHOT_FREE_ACTION_FLAGS = (
    "card_11_battle_region",
    "card_11_double_auxilia_losses",
    "card_11a_auxilia_battle",
    "card_11a_battle_region",
    "card_17_german_ambush",
    "card_17_germans_phase",
    "card_17_march_german_groups",
    "card_21_no_fort",
    "card_25_battle_region",
    "card_25_extra_losses",
    "card_26_arverni_rally",
    "card_2_auto_legion_loss",
    "card_2_battle_region",
    "card_34_free_rally",
    "card_34_rally_faction",
    "card_34_rally_regions",
    "card_35_free_limited_command",
    "card_35_gallic_commands",
    "card_36_free_battle",
    "card_36_gallic_ambush_battle",
    "card_44_free_raid",
    "card_44_free_scout",
    "card_44a_free_command",
    "card_44_placed",
    "card_44_scout_moves",
    "card_44_scout_reveals",
    "card_44_raid_actions",
    "card_44a_command_regions",
    "card_45_battle_romans",
    "card_46_free_command",
    "card_47_council",
    "card_48_druids",
    "card_48_target_factions",
    "card_4_free_march_to",
    "card_51_aedui_free_command",
    "card_51_german_action",
    "card_52_free_command_sa",
    "card_54_joined_ranks",
    "card_54_march_limit",
    "card_54a_second_always_retreat",
    "card_57_march_britannia",
    "card_57_faction",
    "card_57_free_sa",
    "card_58_german_march_battle",
    "card_62_war_fleet",
    "card_64_belgae_rally",
    "card_65_german_march_ambush",
    "card_65_march_regions",
    "card_66_german_rally_march",
    "card_67_arduenna",
    "card_6_double_auxilia_losses",
    "card_70_free_command_sa",
    "card_70_legion_limit",
    "card_70_roman_march_battle",
    "card_70_target_regions",
    "card_72_hidden_march_battle",
    "card_72_march_and_enemy_battle",
    "card_9_free_march_and_command",
    "card_9_march_from",
    "card_9_march_to",
    "card_A17_roman_march_battle",
    "card_A17_double_auxilia_losses",
    "card_A19_march_romans",
    "card_A20_arverni_ambush",
    "card_A20_free_seize_veneti",
    "card_A21_double_battle",
    "card_A21_first_no_retreat",
    "card_A24_arverni_phase",
    "card_A27_arverni_phase",
    "card_A28_combined_battle",
    "card_A29_german_raid",
    "card_A32_arverni_phase",
    "card_A34_free_command",
    "card_A34_regions_limit",
    "card_A34_faction",
    "card_A34_use_german_pieces",
    "card_A37_place_allies_move",
    "card_A45_free_intimidate",
    "card_A53_aedui_corn",
    "card_A57_double_battle",
    "card_A57_first_no_retreat",
    "card_A58_free_ambush",
    "card_A58_roman_battle_seize",
    "card_A5_remove_non_romans",
    "card_A65_kinship_battle",
    "card_A67_arduenna",
    "card_A69_ambush",
)

def _resolve_free_actions(state, faction):
    """Every action granted by an Event costs no Resources (§5.4)."""
    from fs_bot.commands.common import free_action_scope
    with free_action_scope(state):
        return _resolve_free_actions_scoped(state, faction)


def _resolve_free_actions_scoped(state, faction):
    """Run any free actions granted by the just-resolved Event.

    Called from ``_execute_event`` for the acting Faction. Returns a list of
    result dicts (possibly empty). Errors in an individual free action are
    captured, not raised, to keep a full game running.
    """
    mods = state.get("event_modifiers") or {}
    results = []
    if mods.get("card_A28_combined_battle"):
        from fs_bot.cards.admagetobriga import resolve_admagetobriga
        results.extend(resolve_admagetobriga(state, faction))
    for flag in _FREE_FIRST_BATTLE_FLAGS:
        if not mods.get(flag):
            continue
        allowed = _free_battle_region_set(state, flag)
        action = _plan_free_battle_command(state, faction, allowed, no_retreat=True)
        if action is None:
            results.append({"free_action": "battle", "flag": flag,
                            "executed": False, "reason": "no valid target",
                            **({"declined_no_effect": True}
                               if flag == "card_A21_first_no_retreat" else {})})
            continue
        chosen = action["details"]["battle_plan"][0]
        region, defender = chosen["region"], chosen["target"]
        try:
            res = _execute_battle(state, faction, action)
        except _EXEC_ERRORS as exc:
            results.append({"free_action": "battle", "flag": flag,
                            "executed": False, "reason": repr(exc)})
            continue
        results.append({"free_action": "battle", "flag": flag,
                        "region": region, "defender": defender,
                        "result": res})
        # Optional second Battle in the same Region (Retreat allowed).
        dbl = _DOUBLE_BATTLE_FLAG.get(flag)
        if dbl and mods.get(dbl):
            second_action = _plan_free_battle_command(
                state, faction, {region}, second=True)
            if second_action is not None:
                second = second_action["details"]["battle_plan"][0]["target"]
                try:
                    res2 = _execute_battle(state, faction, second_action)
                    results.append({"free_action": "battle_second",
                                    "flag": dbl, "region": region,
                                    "defender": second, "result": res2})
                except _EXEC_ERRORS as exc:
                    results.append({"free_action": "battle_second",
                                    "flag": dbl, "region": region,
                                    "executed": False, "reason": repr(exc)})

    # A58 Aduatuci (unshaded): Romans free Battle anywhere in Belgica, then
    # free Seize in Belgica "as if Roman Control, with no Harassment" — the
    # Seize Disperses regardless of actual Control and skips Harassment.
    if mods.get("card_A58_roman_battle_seize"):
        results.extend(_resolve_a58_battle_seize(state, faction))
    if mods.get("card_A67_arduenna"):
        # A67 = base 67 effect, "updated to allow German use" (A Card Ref). A
        # non-German actor (Be/Ae/Ro) uses the faction-agnostic base resolver;
        # the German path has its own (March-to-Control + Battle + flip Hidden).
        from fs_bot.rules_consts import GERMANS as _G67
        if faction == _G67:
            results.extend(_resolve_a67_arduenna(state, faction))
        else:
            results.extend(_resolve_card67_arduenna(state, faction))
    if mods.get("card_A20_free_seize_veneti"):
        results.extend(_resolve_a20_free_seize(state))
    if mods.get("card_A20_arverni_ambush"):
        results.extend(_resolve_a20_arverni_ambush(state))
    if mods.get("card_A17_roman_march_battle"):
        results.extend(_resolve_a17_march_battle(state))
    if mods.get("card_A19_march_romans"):
        results.extend(_resolve_a19_march_romans(state, faction))
    if mods.get("card_6_double_auxilia_losses"):
        results.extend(_resolve_card6_scout_battle(state))
    if mods.get("card_11_double_auxilia_losses"):
        results.extend(_resolve_double_aux_battle_card(
            state, mods.get("card_11_battle_region"), "card_11"))
    if mods.get("card_11a_auxilia_battle"):
        results.extend(_resolve_double_aux_battle_card(
            state, mods.get("card_11a_battle_region"), "card_11a"))
    if mods.get("card_2_auto_legion_loss"):
        results.extend(_resolve_card2_battle(
            state, faction, mods.get("card_2_battle_region")))
    if mods.get("card_70_roman_march_battle"):
        results.extend(_resolve_card70_march_battle(
            state, mods.get("card_70_target_regions"),
            mods.get("card_70_legion_limit", 4)))
    if mods.get("card_72_march_and_enemy_battle"):
        results.extend(_resolve_card72_march_enemy_battle(state, faction))

    if mods.get("card_72_hidden_march_battle"):
        results.extend(_resolve_card72_hidden_march_battle(state, faction))
    if mods.get("card_58_german_march_battle"):
        results.extend(_resolve_card58_german_ambush(state))
    if mods.get("card_65_german_march_ambush"):
        results.extend(_resolve_card65_german_march_ambush(
            state, mods.get("card_65_march_regions", 2)))
    if mods.get("card_17_german_ambush"):
        results.extend(_resolve_card17_march_ambush(
            state, mods.get("card_17_march_german_groups", 3)))
    if mods.get("card_17_germans_phase"):
        results.extend(_resolve_card17_germans_phase(state))
    if mods.get("card_57_march_britannia"):
        results.extend(_resolve_card57_britannia_march(state, faction))
    if mods.get("card_4_free_march_to"):
        results.extend(_resolve_card4_circumvallation(
            state, mods.get("card_4_free_march_to")))
    if mods.get("card_9_free_march_and_command"):
        results.extend(_resolve_card9_march_command(
            state, faction, mods.get("card_9_march_from"),
            mods.get("card_9_march_to")))
    if mods.get("card_70_free_command_sa"):
        results.extend(_resolve_card70_free_command(state, faction))
    if mods.get("card_46_free_command"):
        results.append({"free_action": "free_command", "flag": "card_46",
                        "result": _resolve_free_command(state, faction)})
    if mods.get("card_51_aedui_free_command"):
        from fs_bot.rules_consts import AEDUI as _AEDUI
        results.append({"free_action": "free_command", "flag": "card_51",
                        "result": _resolve_free_command(state, _AEDUI)})
    if mods.get("card_52_free_command_sa"):
        results.extend(_resolve_card52_free_command(state))
    if mods.get("card_35_gallic_commands"):
        results.extend(_resolve_card35_gallic(state, faction))
    if mods.get("card_35_free_limited_command"):
        results.extend(_resolve_card35_roman(state, faction))
    if mods.get("card_34_free_rally"):
        results.append({"free_action": "free_rally", "flag": "card_34",
                        "result": _resolve_free_rally(
                            state, mods.get("card_34_rally_faction", faction),
                            max_regions=mods.get("card_34_rally_regions", 3),
                            as_if_control=True, allow_devastated=True)})
    if mods.get("card_26_arverni_rally"):
        results.extend(_resolve_card26_arverni_rally(state))
    if mods.get("card_64_belgae_rally"):
        results.extend(_resolve_card64_belgae_rally(state))
    if mods.get("card_25_extra_losses"):
        results.extend(_resolve_card25_battle(
            state, faction, mods.get("card_25_battle_region"),
            mods.get("card_25_extra_losses", 3)))
    if mods.get("card_36_free_battle"):
        results.extend(_resolve_card36_battle(state, faction))
    if mods.get("card_36_gallic_ambush_battle"):
        results.extend(_resolve_card36_shaded(state, faction))
    if mods.get("card_66_german_rally_march"):
        results.extend(_resolve_card66_german_rally_march(state, faction))
    if mods.get("card_21_no_fort"):
        results.extend(_resolve_card21_provincia_battle(state))
    if mods.get("card_45_battle_romans"):
        results.extend(_resolve_card45_battle(state, faction))
    if mods.get("card_54_joined_ranks"):
        results.extend(_resolve_card54_joined_ranks(
            state, faction, mods.get("card_54_march_limit", 8),
            bool(mods.get("card_54a_second_always_retreat"))))
    if mods.get("card_44_free_scout"):
        results.extend(_resolve_card44_scout(state))
    if mods.get("card_44_free_raid"):
        results.extend(_resolve_card44_raid(state, faction))
    if mods.get("card_48_druids"):
        results.extend(_resolve_card48_druids(
            state, mods.get("card_48_target_factions")))
    if mods.get("card_47_council"):
        results.extend(_resolve_card47_council(state, faction))
    if mods.get("card_62_war_fleet"):
        results.extend(_resolve_card62_war_fleet(state, faction))
    if (mods.get("card_A24_arverni_phase") or mods.get("card_A27_arverni_phase")
            or mods.get("card_A32_arverni_phase")):
        results.extend(_resolve_event_arverni_phase(state))
    if mods.get("card_51_german_action"):
        # Germans are game-run (no flowchart): act with the placed Warbands via
        # an Ambush sweep (the aggressive "March/Raid/Battle" option).
        from fs_bot.rules_consts import GERMANS as _G
        results.append({"free_action": "german_ambush", "flag": "card_51",
                        "ambushes": _faction_ambush_sweep(state, _G)})
    if mods.get("card_44a_free_command"):
        # Card 44 (Ariovistus) shaded: the free Command is "in Regions
        # placed" — constrain the chooser to the Regions the handler
        # recorded. No placements never authorize a board-wide Command.
        placed = mods.get("card_44a_command_regions") or []
        if placed:
            results.append({"free_action": "free_command", "flag": "card_44a",
                            "result": _resolve_free_command(
                                state, faction, allowed_regions=set(placed))})
    if mods.get("card_A29_german_raid"):
        results.extend(_resolve_card_A29_raid(state))
    if mods.get("card_A34_use_german_pieces"):
        results.extend(_resolve_card_A34_german_pieces(
            state, mods.get("card_A34_faction", faction),
            mods.get("card_A34_regions_limit", 3)))
    if mods.get("card_A34_free_command"):
        results.append({"free_action": "free_command", "flag": "card_A34",
                        "result": _resolve_free_command(
                            state, mods.get("card_A34_faction", faction))})
    if mods.get("card_A65_kinship_battle"):
        results.extend(_resolve_card_A65_battle(state, faction))
    if mods.get("card_A69_ambush"):
        results.extend(_resolve_card_A69_ambush(state))
    if mods.get("card_A58_free_ambush"):
        from fs_bot.rules_consts import ROMANS as _ROM
        results.append({"free_action": "ambush", "flag": "card_A58",
                        "ambushes": _faction_ambush_sweep(state, faction,
                                                          only_faction=_ROM)})
    if mods.get("card_A45_free_intimidate"):
        results.extend(_resolve_card_A45_intimidate(state))
    if mods.get("card_67_arduenna"):
        results.extend(_resolve_card67_arduenna(state, faction))
    if mods.get("card_A5_remove_non_romans"):
        results.extend(_resolve_card_A5_evict(state))
    if mods.get("card_A37_place_allies_move"):
        results.extend(_resolve_card_A37_move(state, faction))
    if mods.get("card_A53_aedui_corn"):
        results.extend(_resolve_card_A53_frumentum(state))
    # Consume the one-shot flags now that their actions resolved.
    em = state.get("event_modifiers")
    if em:
        for _flag in _ONE_SHOT_FREE_ACTION_FLAGS:
            em.pop(_flag, None)
    return results


def _resolve_card_A29_raid(state):
    """A29: only the newly placed German Warbands receive the free Raid."""
    from fs_bot.cards.dumnorix import derive_raids, raid_cohort
    cohort = state.get("event_modifiers", {}).pop("card_A29_raid_cohort", [])
    actions = derive_raids(state, cohort)
    result = raid_cohort(state, cohort, actions)
    if not result["executed"]:
        result["declined_no_effect"] = True
    return [{"free_action": "raid", "flag": "card_A29", "faction": _GERMANS_F,
             "result": result}]


def _resolve_card_A65_battle(state, faction):
    """A65: the executing player chooses a side and all Battle Regions."""
    from fs_bot.cards.kinship import resolve_kinship
    return resolve_kinship(state, faction)


def _resolve_card_A69_ambush(state):
    """A69: legal Ambush at Bellovaci; only the placed Warbands gain full Loss."""
    from fs_bot.rules_consts import (BELGAE, FACTIONS, TRIBE_BELLOVACI,
                                     TRIBE_TO_REGION, FORT, CITADEL)
    from fs_bot.commands.sa_ambush import validate_ambush_region
    from fs_bot.battle.resolve import _calculate_attack_losses
    region = TRIBE_TO_REGION[TRIBE_BELLOVACI]
    placed = state.get("event_modifiers", {}).pop("card_A69_loss_per_warband", 0)
    candidates = []
    if placed:
        for enemy in FACTIONS:
            if enemy == BELGAE or not count_pieces(state, region, enemy):
                continue
            valid, _ = validate_ambush_region(state, region, BELGAE, enemy)
            if not valid:
                continue
            losses = _calculate_attack_losses(
                state, region, BELGAE, enemy, is_retreat=False,
                had_citadel_at_start=count_pieces(state, region, enemy, CITADEL) > 0,
                had_fort_at_start=count_pieces(state, region, enemy, FORT) > 0,
                full_loss_warbands=placed)
            if losses > 0:
                candidates.append(enemy)
    if not candidates:
        return [{"free_action": "ambush", "flag": "card_A69", "executed": False,
                 "declined_no_effect": True, "reason": "no legal Belgic Ambush at Bellovaci"}]
    defender = max(candidates, key=lambda enemy: count_pieces(state, region, enemy))
    result = _execute_battle(state, BELGAE, {
        "command": _CMD_BATTLE, "sa": _SA_AMBUSH, "sa_regions": [region],
        "details": {"battle_plan": [{"region": region, "target": defender}]}},
        _full_loss_warbands=placed)
    return [{"free_action": "ambush", "flag": "card_A69", "region": region,
             "faction": BELGAE, "defender": defender, "result": result}]


def _resolve_card_A45_intimidate(state):
    """A45: a human chooses; Germans follow their Intimidate priorities.

    Only the Leader/Control selection restriction is waived. The usual
    Hidden-Warband, one-Faction, protected-Leader and removal rules remain.
    """
    from fs_bot.rules_consts import GERMANS, WARBAND, HIDDEN
    from fs_bot.board.pieces import count_pieces_by_state
    from fs_bot.map.map_data import get_playable_regions_for_state
    from fs_bot.bots.german_bot import _select_intimidate_targets
    from fs_bot.engine.free_actions import consult_free_action, execute_free_action_plan
    request = {"kind": "free_action", "request_type": "event_sa",
               "card_id": "A45", "allowed_sas": ["Intimidate"],
               "free": True, "intimidate_anywhere": True}
    response = consult_free_action(state, GERMANS, request)
    if response is not None:
        result = ({"executed": False, "declined": True,
                   "reason": "Intimidate declined"} if response.get("decline") else
                  execute_free_action_plan(state, GERMANS, request, response))
    else:
        plan = []
        for region in get_playable_regions_for_state(state, GERMANS):
            hidden = count_pieces_by_state(state, region, GERMANS, WARBAND, HIDDEN)
            if hidden:
                plan.extend({"region": region, **target} for target in
                            _select_intimidate_targets(state, region, min(2, hidden)))
        if plan:
            # A8.7.1: only after removing pieces, place markers wherever
            # else possible. A45 also waives selection in these Regions.
            from fs_bot.rules_consts import MARKER_INTIMIDATED
            removing = {entry["region"] for entry in plan}
            for region in get_playable_regions_for_state(state, GERMANS):
                if (region not in removing and count_pieces_by_state(
                        state, region, GERMANS, WARBAND, HIDDEN) > 0
                        and MARKER_INTIMIDATED not in
                        (state.get("markers", {}).get(region) or {})):
                    plan.append({"region": region, "target_faction": None,
                                 "target_piece": None, "target_state": None})
        result = (_execute_intimidate(state, GERMANS,
                    {"details": {"intimidate_plan": plan}}, ignore_selection=True)
                  if plan else {"executed": False, "declined": True,
                                "reason": "No Intimidate target under A8.7.1"})
    return [{"free_action": "intimidate", "flag": "card_A45", "result": result}]


def _resolve_card_A5_evict(state):
    """Card A5 Gallia Togata (unshaded): only Romans may stack in Cisalpina, so
    non-Roman pieces there move to a Home Region of their Faction (or are
    removed if none is available)."""
    from fs_bot.rules_consts import (CISALPINA, ARVERNI, AEDUI, BELGAE, GERMANS,
        LEADER, LEGION, AUXILIA, WARBAND, HIDDEN, REVEALED, SCOUTED, ARIOVISTUS_SCENARIOS,
        ARVERNI_HOME_REGIONS_BASE, ARVERNI_HOME_REGIONS_ARIOVISTUS,
        AEDUI_HOME_REGIONS, BELGAE_HOME_REGIONS,
        GERMAN_HOME_REGIONS_BASE)
    from fs_bot.board.pieces import (count_pieces, count_pieces_by_state,
        get_leader_in_region, move_piece, remove_piece)
    from fs_bot.board.control import refresh_all_control
    from fs_bot.map.map_data import get_playable_regions
    scen = state["scenario"]
    ario = scen in ARIOVISTUS_SCENARIOS
    homes = {
        ARVERNI: (ARVERNI_HOME_REGIONS_ARIOVISTUS if ario
                  else ARVERNI_HOME_REGIONS_BASE),
        AEDUI: AEDUI_HOME_REGIONS, BELGAE: BELGAE_HOME_REGIONS,
        GERMANS: GERMAN_HOME_REGIONS_BASE,
    }
    playable = set(get_playable_regions(scen, state.get("capabilities")))
    moved, removed = [], []
    for fac in (ARVERNI, AEDUI, BELGAE, GERMANS):
        dest = next((h for h in homes.get(fac, ()) if h in playable
                     and h != CISALPINA), None)
        # Leader
        if get_leader_in_region(state, CISALPINA, fac) is not None:
            if dest:
                move_piece(state, CISALPINA, dest, fac, LEADER)
                moved.append((fac, LEADER, dest))
            else:
                remove_piece(state, CISALPINA, fac, LEADER); removed.append((fac, LEADER))
        leg = count_pieces(state, CISALPINA, fac, LEGION)
        if leg:
            (move_piece(state, CISALPINA, dest, fac, LEGION, count=leg) if dest
             else remove_piece(state, CISALPINA, fac, LEGION, count=leg))
        for pt in (AUXILIA, WARBAND):
            for ps in (HIDDEN, REVEALED, SCOUTED):
                n = count_pieces_by_state(state, CISALPINA, fac, pt, ps)
                if n <= 0:
                    continue
                if dest:
                    move_piece(state, CISALPINA, dest, fac, pt, count=n,
                               piece_state=ps)
                    moved.append((fac, pt, dest))
                else:
                    remove_piece(state, CISALPINA, fac, pt, count=n,
                                 piece_state=ps)
                    removed.append((fac, pt))
    refresh_all_control(state)
    return [{"free_action": "evict_cisalpina", "flag": "card_A5",
             "moved": moved, "removed": removed,
             "executed": bool(moved or removed)}]


def _resolve_card_A37_move(state, faction):
    """Report the optional direct moves selected in A37's Event plan."""
    from fs_bot.rules_consts import AEDUI, ARIOVISTUS_SCENARIOS
    selection = state.get("event_modifiers", {}).get("card_A37_place_allies_move")
    selection = selection if isinstance(selection, dict) else {}
    moves = selection.get("moves", [])
    result = {"free_action": "move", "flag": "card_A37",
              "region": selection.get("region"), "moves": moves,
              "executed": bool(moves)}
    if not moves:
        result["declined_no_effect"] = True
        if (faction == AEDUI and state["scenario"] in ARIOVISTUS_SCENARIOS
                and faction in state.get("non_player_factions", set())):
            result["reason"] = "Aedui Event instruction: move no pieces for All Gaul Gathers"
        else:
            result["reason"] = "No optional A37 movement selected"
    return [result]


def _resolve_card_A53_frumentum(state):
    """A53's paid Aedui allocation and any-order Roman action sequence."""
    from fs_bot.engine.frumentum import resolve_frumentum
    return resolve_frumentum(state)


def _resolve_card67_arduenna(state, faction):
    """Card 67 Arduenna (base): Romans or a Gallic Faction may free March into
    Nervii and/or Treveri, then a free Command except March in those Regions,
    then flip all friendly Warbands/Auxilia there Hidden."""
    from fs_bot.rules_consts import (NERVII, TREVERI, WARBAND, AUXILIA, LEGION,
                                     REVEALED, HIDDEN)
    from fs_bot.board.pieces import (count_pieces, count_pieces_by_state,
                                     flip_piece)
    from fs_bot.board.control import refresh_all_control
    from fs_bot.map.map_data import get_adjacent, get_playable_regions
    scen = state["scenario"]
    playable = set(get_playable_regions(scen, state.get("capabilities")))
    targets = [r for r in (NERVII, TREVERI) if r in playable]
    out = []
    # Free March a mobile group from an adjacent Region into each target.
    for T in targets:
        if _attacker_has_force(state, T, faction):
            continue
        srcs = [a for a in get_adjacent(T, scen) if a in playable
                and _group_has_pieces(_mobile_march_group(state, faction, a))]
        if not srcs:
            continue
        S = max(srcs, key=lambda a: sum(
            count_pieces(state, a, faction, pt)
            for pt in (LEGION, AUXILIA, WARBAND)))
        try:
            _march_with_harassment(state, faction, S, [T])
            out.append({"free_action": "march", "flag": "card_67",
                        "source": S, "dest": T})
        except _EXEC_ERRORS:
            pass
    # Free Command (except March) in/from the target Regions.
    cmd = _resolve_free_command(state, faction, allowed_regions=set(targets),
                               exclude_commands={_CMD_MARCH})
    out.append({"free_action": "free_command", "flag": "card_67", "result": cmd})
    # Flip all friendly Warbands/Auxilia in the targets to Hidden.
    flipped = 0
    for T in targets:
        for pt in (WARBAND, AUXILIA):
            rev = count_pieces_by_state(state, T, faction, pt, REVEALED)
            if rev > 0:
                flip_piece(state, T, faction, pt, rev,
                           from_state=REVEALED, to_state=HIDDEN)
                flipped += rev
    if flipped:
        refresh_all_control(state)
        out.append({"free_action": "flip_hidden", "flag": "card_67",
                    "flipped": flipped})
    return out


def _resolve_event_arverni_phase(state):
    """Cards A24/A27/A32: after placing Arverni Warbands, conduct an immediate
    Arverni Phase as if At War (A6.2) via run_arverni_phase."""
    from fs_bot.engine.arverni_phase import run_arverni_phase
    try:
        res = run_arverni_phase(state, force_at_war=True)
    except Exception as exc:
        return [{"free_action": "arverni_phase", "flag": "arverni_phase",
                 "executed": False, "reason": repr(exc)}]
    return [{"free_action": "arverni_phase", "flag": "arverni_phase",
             "executed": res is not None, "result": res}]


def _resolve_winter_uprising(state, *, forced=False):
    """A66: holder-selected Quarters timing; mandatory at Gallic War Interlude."""
    from fs_bot.cards.winter_uprising_resolution import resolve
    return resolve(state, forced=forced)


def _gallic_np_factions(state):
    from fs_bot.rules_consts import ARVERNI, AEDUI, BELGAE
    nps = state.get("non_player_factions", set())
    return [f for f in (ARVERNI, AEDUI, BELGAE) if f in nps]


def _resolve_card48_druids(state, target_factions):
    """Card 48 Druids: 1-3 Gallic Factions each execute a free Limited Command
    (which may add a free Special Ability), in initiative order. With no chosen
    list, all Gallic Non-player Factions act."""
    targets = [f for f in (target_factions or _gallic_np_factions(state))]
    out = []
    for fac in targets:
        out.append({"free_action": "free_command", "flag": "card_48",
                    "faction": fac,
                    "result": _resolve_free_command(state, fac, limited=True, with_sa=True)})
    return out


def _resolve_card47_council(state, faction=None):
    """Resolve the selected Council's private beneficiary choices in card order."""
    from fs_bot.cards.council import resolve_council
    grant = state.get("event_modifiers", {}).get("card_47_council")
    selection = grant.get("selection") if isinstance(grant, dict) else None
    return resolve_council(state, faction or state.get("executing_faction"), selection)


def _resolve_card62_war_fleet(state, faction):
    from fs_bot.cards.war_fleet import resolve_war_fleet_follow_on
    return resolve_war_fleet_follow_on(state, faction)


def _card25_battle_target(state, region, faction):
    """Aquitani: Roman NP instructions target Arverni, then Belgae only."""
    from fs_bot.rules_consts import ROMANS, ARVERNI, BELGAE
    if faction == ROMANS and faction in state.get("non_player_factions", ()):
        return next((enemy for enemy in (ARVERNI, BELGAE)
                     if count_pieces(state, region, enemy)), None)
    return _rank_free_battle_defender(state, region, faction)


def _plan_fixed_event_battle(state, faction, card_id, allowed_regions, select_target):
    """Plan a specially modified Battle with explicit human cooperation."""
    from fs_bot.engine.diviciacus_planning import plan_with_diviciacus
    from fs_bot.engine.diviciacus import eligible_regions
    def planner(sim):
        region, defender = select_target(sim)
        if region is None or defender is None:
            return {"command": "Pass"}
        return {"command": _CMD_BATTLE, "regions": [region],
                "details": {"battle_plan": [{"region": region, "target": defender}]}}
    with _command_execution_scope(state, set(allowed_regions), False):
        action = plan_with_diviciacus(state, faction, planner)
    if action.get("command") != _CMD_BATTLE:
        return None
    _request_event_diviciacus(state, faction, action, card_id)
    return action


def _request_event_diviciacus(state, faction, action, card_id):
    """A human explicitly opts into a loan for a default Event Command."""
    from fs_bot.engine.diviciacus import eligible_regions, _targets
    from fs_bot.engine.action_validation import command_regions
    if faction in state.get("non_player_factions", set()):
        return
    action.setdefault("details", {})["diviciacus_regions"] = []
    regions = sorted(set(command_regions(action)) & set(eligible_regions(state, faction)))
    if state.get("_diviciacus_preview") or not regions:
        return
    from fs_bot.engine.agent import AGREEMENT, consult_agent
    response = consult_agent(state, faction, {
        "kind": AGREEMENT, "request_type": "diviciacus_command",
        "requesting_faction": faction,
        "context": {"command": action["command"], "card_id": card_id,
                    "regions": regions,
                    "targets": {region: _targets(action, region) for region in regions}}})
    if response is True or (isinstance(response, dict) and response.get("agree") is True):
        action["details"]["diviciacus_regions"] = regions


@_diviciacus_command_scope
def _resolve_fixed_event_battle(state, faction, action, **options):
    """Preserve Event Battle modifiers inside the actual Command scope."""
    from fs_bot.engine.diviciacus import defense_scope
    from fs_bot.battle.resolve import resolve_battle
    entry = action["details"]["battle_plan"][0]
    region, defender = entry["region"], entry["target"]
    with defense_scope(state, region, faction, defender):
        if "retreat_declaration" not in options:
            rd, rr = _decide_defender_retreat(state, region, faction, defender, False)
            options.update(retreat_declaration=rd, retreat_region=rr)
        return resolve_battle(state, region, faction, defender, **options)


def _resolve_card25_battle(state, faction, region, extra):
    """Card 25 Aquitani (unshaded): free Battle in Pictones/Arverni with
    ``extra`` extra Losses and 1 Ally (not Citadel) removed first."""
    from fs_bot.engine.diviciacus_planning import clear_confirmation
    if region is None:
        return [{"free_action": "battle", "flag": "card_25", "executed": False,
                 "declined_no_effect": True,
                 "reason": "no Pictones/Arverni Battle target"}]
    action = _plan_fixed_event_battle(
        state, faction, 25, {region},
        lambda sim: (region, _card25_battle_target(sim, region, faction)))
    if action is None:
        return [{"free_action": "battle", "flag": "card_25", "executed": False,
                 "declined_no_effect": True,
                 "reason": "no enemy in Region"}]
    defender = action["details"]["battle_plan"][0]["target"]
    try:
        res = _resolve_fixed_event_battle(state, faction, action,
                                         extra_losses=extra, ally_first=True)
    except _EXEC_ERRORS as exc:
        return [{"free_action": "battle", "flag": "card_25",
                 "executed": False, "reason": repr(exc)}]
    finally:
        clear_confirmation(state, faction, action)
    return [{"free_action": "battle", "flag": "card_25", "region": region,
             "defender": defender, "result": res}]


def _card36_battle_target(state, faction):
    """Morasses scope, including the base Aedui player-only instruction."""
    from fs_bot.rules_consts import (ARVERNI, AEDUI, BELGAE, WARBAND, LEGION,
                                     AUXILIA)
    from fs_bot.board.pieces import count_pieces
    from fs_bot.map.map_data import get_playable_regions
    from fs_bot.rules_consts import BASE_SCENARIOS
    gallic = (ARVERNI, AEDUI, BELGAE)
    if (faction == AEDUI and state["scenario"] in BASE_SCENARIOS
            and faction in state.get("non_player_factions", ())):
        gallic = tuple(f for f in (ARVERNI, BELGAE)
                       if f not in state.get("non_player_factions", ()))
    best = None  # (region, defender, enemy_mobile)
    for R in get_playable_regions(state["scenario"], state.get("capabilities")):
        if not _attacker_has_force(state, R, faction):
            continue
        for d in gallic:
            if d == faction or count_pieces(state, R, d) <= 0:
                continue
            mob = (count_pieces(state, R, d, WARBAND)
                   + count_pieces(state, R, d, AUXILIA)
                   + count_pieces(state, R, d, LEGION))
            if best is None or mob > best[2]:
                best = (R, d, mob)
    return best


def _resolve_card36_battle(state, faction):
    """Card 36: Battle a Gallic Faction, without Retreat/Counterattack/Citadel."""
    from fs_bot.engine.diviciacus_planning import clear_confirmation
    from fs_bot.map.map_data import get_playable_regions_for_state
    def select(sim):
        best = _card36_battle_target(sim, faction)
        return best[:2] if best else (None, None)
    action = _plan_fixed_event_battle(
        state, faction, 36, get_playable_regions_for_state(state), select)
    if action is None:
        return [{"free_action": "battle", "flag": "card_36", "executed": False,
                 "declined_no_effect": True,
                 "reason": "no Gallic Faction to Battle"}]
    R, d = (action["details"]["battle_plan"][0][key] for key in ("region", "target"))
    try:
        res = _resolve_fixed_event_battle(state, faction, action,
                             retreat_declaration=False,
                             no_counterattack=True, ignore_citadel=True,
                             attacker_stays_hidden=True)
    except _EXEC_ERRORS as exc:
        return [{"free_action": "battle", "flag": "card_36",
                 "executed": False, "reason": repr(exc)}]
    finally:
        clear_confirmation(state, faction, action)
    return [{"free_action": "battle", "flag": "card_36", "region": R,
             "defender": d, "result": res}]


def _resolve_card36_shaded(state, faction):
    """Resolve the chosen Gallic Faction's two printed Morasses Commands."""
    from fs_bot.cards.morasses import resolve_morasses
    return resolve_morasses(state, faction)


def _resolve_card66_german_rally_march(state, faction):
    """Card 66: the executing Faction guides the German Rally then March."""
    from fs_bot.cards.migration import resolve_migration
    return resolve_migration(state, faction)


def _resolve_card21_provincia_battle(state):
    """Card 21 shaded: the Arverni choose free Raid OR Battle in Provincia.

    Both Commands use their normal plan/decision interface. The trusted Event
    modifier supplies the card's Fort exception only for this scoped grant.
    """
    from fs_bot.rules_consts import ARVERNI, PROVINCIA
    if not _attacker_has_force(state, PROVINCIA, ARVERNI):
        return [{"free_action": "free_command", "flag": "card_21",
                 "faction": ARVERNI, "executed": False,
                 "declined_no_effect": True,
                 "reason": "no Arverni force in Provincia"}]
    result = _resolve_free_command(
        state, ARVERNI, allowed_regions={PROVINCIA},
        exclude_commands={_CMD_RALLY, _CMD_MARCH}, with_sa=False)
    return [{"free_action": "free_command", "flag": "card_21",
             "faction": ARVERNI, "region": PROVINCIA, "result": result}]


def _resolve_card45_battle(state, faction):
    """Card 45 Litaviccus (shaded): free Battle against the Romans in 1 Region,
    using Aedui pieces as the attacker's own, Ambushing if able."""
    from fs_bot.rules_consts import ROMANS, AEDUI
    from fs_bot.board.pieces import count_pieces
    from fs_bot.commands.sa_ambush import validate_ambush_region
    from fs_bot.map.map_data import get_playable_regions
    best = None
    for R in get_playable_regions(state["scenario"], state.get("capabilities")):
        if count_pieces(state, R, ROMANS) <= 0:
            continue
        if not (_attacker_has_force(state, R, faction)
                or _attacker_has_force(state, R, AEDUI)):
            continue
        rp = count_pieces(state, R, ROMANS)
        if best is None or rp > best[1]:
            best = (R, rp)
    if best is None:
        return [{"free_action": "battle", "flag": "card_45", "executed": False,
                 "declined_no_effect": True,
                 "reason": "no Roman target with a combined force"}]
    R = best[0]
    is_ambush, _ = validate_ambush_region(
        state, R, faction, ROMANS, allied_factions=(AEDUI,))
    details = {"battle_plan": [{"region": R, "target": ROMANS}],
               "allied_factions": (AEDUI,)}
    bot_action = {"command": _CMD_BATTLE,
                  "sa": (_SA_AMBUSH if is_ambush else SA_ACTION_NONE_LABEL),
                  "sa_regions": ([R] if is_ambush else []), "details": details}
    try:
        res = _execute_battle(state, faction, bot_action)
    except _EXEC_ERRORS as exc:
        return [{"free_action": "battle", "flag": "card_45",
                 "executed": False, "reason": repr(exc)}]
    return [{"free_action": "battle", "flag": "card_45", "region": R,
             "defender": ROMANS, "ambush": is_ambush, "result": res}]


def _resolve_card54_joined_ranks(state, faction, march_limit,
                                 second_always_retreat=False):
    from fs_bot.cards.joined_ranks import resolve_joined_ranks
    return resolve_joined_ranks(state, faction, march_limit, second_always_retreat)


def _resolve_card44_scout(state):
    """Card 44: only the successfully placed Auxilia/Aedui Warbands Scout."""
    from fs_bot.cards.dumnorix import scout_cohort
    mods = state.get("event_modifiers", {})
    result = scout_cohort(state, mods.get("card_44_placed", []),
                          mods.get("card_44_scout_moves", []),
                          mods.get("card_44_scout_reveals", []))
    if not result["executed"] and not result.get("errors"):
        # Replacement remains effective. Scout permits no movement and the
        # new cohort may have no eligible reveal (§5.1.3; Card 44 Tips).
        result.update(declined_no_effect=True,
                      reason="replacement cohort has no Scout movement or eligible reveal")
    return [{"free_action": "scout", "flag": "card_44", "result": result}]


def _resolve_card44_raid(state, faction):
    """Original card 44: only the successfully placed Warbands Raid."""
    from fs_bot.cards.dumnorix import raid_cohort
    mods = state.get("event_modifiers", {})
    result = raid_cohort(state, mods.get("card_44_placed", []),
                         mods.get("card_44_raid_actions", []))
    return [{"free_action": "raid", "flag": "card_44", "result": result}]


def _resolve_card26_arverni_rally(state):
    """Card 26 Gobannitio (shaded): the Arverni free Rally within 1 Region of
    Vercingetorix."""
    from fs_bot.rules_consts import ARVERNI, VERCINGETORIX
    from fs_bot.board.pieces import find_leader, get_leader_in_region
    from fs_bot.map.map_data import get_adjacent, get_playable_regions
    leader = find_leader(state, ARVERNI)
    if leader is None or get_leader_in_region(state, leader, ARVERNI) != VERCINGETORIX:
        return [{"free_action": "free_rally", "flag": "card_26",
                 "executed": False, "declined_no_effect": True,
                 "reason": "no Vercingetorix location for the follow-on Rally"}]
    playable = set(get_playable_regions(state["scenario"], state.get("capabilities")))
    allowed = ({leader} | set(get_adjacent(leader, state["scenario"]))) & playable
    return [{"free_action": "free_rally", "flag": "card_26",
             "result": _resolve_free_rally(state, ARVERNI, allowed_regions=allowed)}]


def _resolve_card64_belgae_rally(state):
    """Card 64 Correus (shaded): the Belgae free Rally in 1 Belgica Region."""
    from fs_bot.rules_consts import BELGAE, BELGICA_REGIONS
    from fs_bot.map.map_data import get_playable_regions
    playable = set(get_playable_regions(state["scenario"], state.get("capabilities")))
    allowed = set(BELGICA_REGIONS) & playable
    return [{"free_action": "free_rally", "flag": "card_64",
             "result": _resolve_free_rally(state, BELGAE, allowed_regions=allowed,
                                             max_regions=1)}]


def _resolve_card35_roman(state, faction):
    """Card 35 Gallic Shouts (unshaded): "Romans may look at the next 2
    facedown cards and either execute a free Limited Command or be Eligible."

    The beneficiary is the ROMANS regardless of who executed the Event (the
    card's Tip contemplates another Faction executing it *for* the Romans).
    The peek lets the Romans pick the better option. We model the choice by
    outcome: take the free Limited Command if it does something; otherwise take
    the alternative and be Eligible (the peek is the information that drives
    this either/or — it has no board effect of its own). "Be Eligible" is
    recorded in state["stay_eligible"] so the Sec.2.3.6 reset cannot clobber
    it when the Romans themselves executed the Event."""
    from fs_bot.rules_consts import ELIGIBLE, ROMANS
    res = _resolve_free_command(state, ROMANS, limited=True)
    if res.get("executed"):
        return [{"free_action": "free_command", "flag": "card_35",
                 "faction": ROMANS, "result": res}]
    state.setdefault("eligibility", {})[ROMANS] = ELIGIBLE
    state.setdefault("stay_eligible", []).append(ROMANS)
    return [{"free_action": "stay_eligible", "flag": "card_35",
             "executed": True, "faction": ROMANS,
             "note": "no effective Limited Command; chose to be Eligible"}]


def _resolve_card35_gallic(state, faction):
    """Card 35 Gallic Shouts (shaded): "A Gallic Faction executes 1 Command and
    1 Limited Command, in either order, free, no Battles." Run a full free
    Command then a Limited free Command for the acting Faction, both excluding
    Battle."""
    out = []
    out.append({"free_action": "free_command", "flag": "card_35",
                "kind": "command",
                "result": _resolve_free_command(
                    state, faction, exclude_commands={_CMD_BATTLE})})
    out.append({"free_action": "free_command", "flag": "card_35",
                "kind": "limited_command",
                "result": _resolve_free_command(
                    state, faction, exclude_commands={_CMD_BATTLE},
                    limited=True)})
    return out


def _resolve_card52_free_command(state):
    """Card 52 Assembly of Gaul (shaded): "Faction Controlling Carnutes Region
    executes a Command that may add 2 Special Abilities, free."

    The controller runs a free Command via the flowchart, which carries the
    one Special Ability the bot selects (executed by _execute_bot_command). The
    card *permits* up to two SAs, but the Non-player flowchart has no rule for
    choosing a second SA — adding one would be invented behaviour — so the
    Faction adds the single SA its flowchart selects (within the allowance).
    The result reports whether a SA accompanied the Command."""
    from fs_bot.rules_consts import CARNUTES, FACTIONS
    from fs_bot.board.control import is_controlled_by
    controller = next((f for f in FACTIONS
                       if is_controlled_by(state, CARNUTES, f)), None)
    if controller is None:
        return [{"free_action": "free_command", "flag": "card_52",
                 "executed": False, "reason": "no Faction controls Carnutes"}]
    res = _resolve_free_command(state, controller, with_sa=True)
    return [{"free_action": "free_command", "flag": "card_52",
             "controller": controller,
             "sa_included": bool((res or {}).get("sa_execution")),
             "result": res}]


def _resolve_card70_free_command(state, faction):
    """Card 70 Camulogenus (shaded): after placing Warbands among Atrebates/
    Carnutes/Mandubii, the Faction executes a free Command + Special Ability in
    the selected Region — the one of the three where it now has the most
    pieces (where the deriver placed). Restricted via the free-Command layer."""
    from fs_bot.rules_consts import ATREBATES, CARNUTES, MANDUBII
    from fs_bot.board.pieces import count_pieces
    from fs_bot.map.map_data import get_playable_regions
    playable = set(get_playable_regions(state["scenario"], state.get("capabilities")))
    regs = [r for r in (ATREBATES, CARNUTES, MANDUBII) if r in playable]
    if not regs:
        return [{"free_action": "free_command", "flag": "card_70_free_command_sa",
                 "executed": False, "reason": "no target Region in play"}]
    R = max(regs, key=lambda r: count_pieces(state, r, faction))
    cmd_res = _resolve_free_command(state, faction, allowed_regions={R}, with_sa=True)
    return [{"free_action": "free_command", "flag": "card_70_free_command_sa",
             "region": R, "result": cmd_res}]


def _resolve_card9_march_command(state, faction, march_from, march_to):
    """Card 9 Mons Cevenna: "Free March from a Region into an adjacent Region,
    both within 1 Region of Provincia. Then execute a free Command and any free
    Special Ability in (or from) the destination Region." (Within 1 of
    Provincia = Provincia, Sequani, or Arverni.)

    Performs the free March (deriving a within-1-of-Provincia source/destination
    if the handler did not supply them), then a free Command via the flowchart-
    faithful chooser.
    """
    from fs_bot.rules_consts import PROVINCIA, SEQUANI, ARVERNI_REGION
    from fs_bot.map.map_data import get_adjacent, get_playable_regions
    out = []
    scen = state["scenario"]
    near = [r for r in (PROVINCIA, SEQUANI, ARVERNI_REGION)
            if r in set(get_playable_regions(scen, state.get("capabilities")))]
    S, B = march_from, march_to
    if not (S and B):
        # Derive: a within-1-of-Provincia source with a mobile group, into an
        # adjacent within-1-of-Provincia destination.
        for cand in near:
            if _group_has_pieces(_mobile_march_group(state, faction, cand)):
                dests = [d for d in get_adjacent(cand, scen) if d in near]
                if dests:
                    S, B = cand, dests[0]
                    break
    dest = None
    if S and B and _group_has_pieces(_mobile_march_group(state, faction, S)):
        try:
            final = _march_with_harassment(state, faction, S, [B])
            dest = final
            out.append({"free_action": "march", "flag": "card_9",
                        "source": S, "final_region": final})
        except _EXEC_ERRORS as exc:
            out.append({"free_action": "march", "flag": "card_9",
                        "executed": False, "reason": repr(exc)})
    # Free Command "in (or from) the destination Region" — restrict to dest.
    allowed = {dest} if dest else (set(near) if near else None)
    cmd_res = _resolve_free_command(state, faction, allowed_regions=allowed, with_sa=True)
    out.append({"free_action": "free_command", "flag": "card_9",
                "result": cmd_res})
    return out


def _resolve_card4_circumvallation(state, region):
    """Card 4 Circumvallation: the Romans free March one mobile group into the
    marked enemy-Citadel Region (the Circumvallation marker was placed there by
    the card handler). Marches from the adjacent Region with the largest Roman
    mobile group."""
    from fs_bot.rules_consts import ROMANS, LEGION, AUXILIA, WARBAND, LEADER
    from fs_bot.map.map_data import get_adjacent, get_playable_regions
    if region is None:
        return []
    playable = set(get_playable_regions(state["scenario"], state.get("capabilities")))
    sources = [a for a in get_adjacent(region, state["scenario"])
               if a in playable
               and _group_has_pieces(_mobile_march_group(state, ROMANS, a))]
    if not sources:
        return [{"free_action": "march", "flag": "card_4_free_march_to",
                 "region": region, "executed": False,
                 "reason": "no adjacent Roman group to March in"}]
    def gsize(r):
        g = _mobile_march_group(state, ROMANS, r)
        return (g.get(LEGION, 0) + g.get(AUXILIA, 0) + g.get(WARBAND, 0)
                + (1 if g.get(LEADER) else 0))
    S = max(sources, key=gsize)
    try:
        final = _march_with_harassment(state, ROMANS, S, [region])
    except _EXEC_ERRORS as exc:
        return [{"free_action": "march", "flag": "card_4_free_march_to",
                 "region": region, "source": S, "executed": False,
                 "reason": repr(exc)}]
    return [{"free_action": "march", "flag": "card_4_free_march_to",
             "region": region, "source": S, "final_region": final}]


def _resolve_card57_britannia_march(state, faction):
    from fs_bot.engine.event_britannia import resolve_britannia
    return resolve_britannia(state, faction)


def _resolve_card17_march_ambush(state, march_limit):
    """Card 17 Germanic Chieftains (unshaded): "Romans March up to 3 German
    groups, then Ambush with Germans in any 1 Region." Setup March of up to
    march_limit German groups (shared helper), then Ambush in the single best
    Region (Hidden-majority, Loss-causing; most enemy pieces — per Roman
    Battle priority 8.8.1's spirit)."""
    from fs_bot.rules_consts import GERMANS, ROMANS
    from fs_bot.board.pieces import count_pieces
    from fs_bot.board.control import refresh_all_control
    from fs_bot.map.map_data import get_playable_regions
    from fs_bot.battle.resolve import resolve_battle
    roman_guided = ROMANS in state.get("non_player_factions", ())
    marched = (_roman_german_setup_marches(state, march_limit) if roman_guided
               else _german_setup_marches(state, march_limit))
    # Single best Ambush Region.
    best, best_tgt, best_score = None, None, None
    for region in get_playable_regions(state["scenario"], state.get("capabilities")):
        tgt = _german_ambush_target(state, region, roman_guided=roman_guided)
        if tgt is None:
            continue
        score = count_pieces(state, region, tgt)
        if best_score is None or score > best_score:
            best, best_tgt, best_score = region, tgt, score
    if best is None:
        return [{"free_action": "german_march_ambush",
                 "flag": "card_17_german_ambush", "marches": marched,
                 "executed": bool(marched), "declined_no_effect": not bool(marched),
                 "reason": "no legal German Ambush"}]
    try:
        res = resolve_battle(state, best, GERMANS, best_tgt, is_ambush=True)
    except _EXEC_ERRORS as exc:
        return [{"free_action": "german_march_ambush",
                 "flag": "card_17_german_ambush", "marches": marched,
                 "region": best, "executed": False, "reason": repr(exc)}]
    refresh_all_control(state)
    return [{"free_action": "german_march_ambush",
             "flag": "card_17_german_ambush", "marches": marched,
             "region": best, "defender": best_tgt, "result": res}]


def _resolve_card17_germans_phase(state):
    """Card 17 Germanic Chieftains (shaded): "Conduct an immediate Germans
    Phase as if Winter." Runs the full §6.2 Germans Phase (Rally, March, Raid,
    Battle-with-Ambush). Base game only; returns no-op in Ariovistus (where
    the Germans are a full Faction with no Germans Phase)."""
    from fs_bot.engine.winter import germans_phase
    try:
        res = germans_phase(state)
    except _EXEC_ERRORS as exc:
        return [{"free_action": "germans_phase", "flag":
                 "card_17_germans_phase", "executed": False,
                 "reason": repr(exc)}]
    return [{"free_action": "germans_phase", "flag": "card_17_germans_phase",
             "executed": res is not None, "result": res}]


def _faction_ambush_target(state, region, attacker, only_faction=None):
    """Best enemy for ``attacker`` to Ambush in ``region`` — the attacker's
    Hidden Warbands must outnumber the defender's Hidden pieces and the Ambush
    must cause a Loss. Picks the legal target with the most pieces. When
    ``only_faction`` is set, the Ambush target is restricted to that Faction
    (e.g. card A58 shaded "free Ambush Romans")."""
    from fs_bot.rules_consts import FACTIONS, WARBAND, AUXILIA, HIDDEN
    from fs_bot.board.pieces import count_pieces, count_pieces_by_state
    from fs_bot.battle.losses import calculate_losses
    a_hidden = count_pieces_by_state(state, region, attacker, WARBAND, HIDDEN)
    if a_hidden <= 0:
        return None
    candidates = [only_faction] if only_faction else FACTIONS
    best, best_score = None, None
    for ef in candidates:
        if ef == attacker or count_pieces(state, region, ef) <= 0:
            continue
        e_hidden = (count_pieces_by_state(state, region, ef, WARBAND, HIDDEN)
                    + count_pieces_by_state(state, region, ef, AUXILIA, HIDDEN))
        if a_hidden <= e_hidden:
            continue
        try:
            if calculate_losses(state, region, attacker, ef,
                                is_retreat=False) <= 0:
                continue
        except Exception:
            continue
        score = count_pieces(state, region, ef)
        if best_score is None or score > best_score:
            best, best_score = ef, score
    return best


def _german_ambush_target(state, region, *, roman_guided=False):
    from fs_bot.rules_consts import GERMANS
    if roman_guided:
        from fs_bot.bots.roman_bot import _rank_battle_targets
        for target in _rank_battle_targets(state, region, state["scenario"]):
            if _faction_ambush_target(state, region, GERMANS, target):
                return target
        return None
    return _faction_ambush_target(state, region, GERMANS)


def _roman_german_setup_marches(state, march_limit):
    """Card 17 Roman instruction: March from Romans to no Romans.

    Normal March hides Revealed Warbands. Groups are previewed together:
    several individually insufficient groups may jointly enable the Ambush.
    """
    from copy import deepcopy
    from itertools import combinations
    from fs_bot.rules_consts import GERMANS, ROMANS, WARBAND, LEADER
    from fs_bot.board.pieces import count_pieces
    from fs_bot.map.map_data import get_playable_regions_for_state, get_adjacent_for_state
    from fs_bot.bots.bot_common import random_select
    marched, used = [], set()
    while len(marched) < march_limit:
        candidates = []
        for destination in sorted(get_playable_regions_for_state(state, GERMANS)):
            if count_pieces(state, destination, ROMANS):
                continue
            sources = [source for source in sorted(get_adjacent_for_state(state, destination, GERMANS))
                       if source not in used and count_pieces(state, source, ROMANS)
                       and count_pieces(state, source, GERMANS, WARBAND)]
            group_count = min(march_limit - len(marched), len(sources))
            if not group_count:
                continue
            for group_sources in combinations(sources, group_count):
                trial = deepcopy({k: v for k, v in state.items() if k != "decision_agent"})
                groups = [(source, count_pieces(state, source, GERMANS, WARBAND))
                          for source in group_sources]
                for source, number in groups:
                    _march_with_harassment(trial, GERMANS, source, [destination],
                                           {WARBAND: number, LEADER: False})
                target = _german_ambush_target(trial, destination, roman_guided=True)
                if target:
                    candidates.append((count_pieces(trial, destination, target),
                                       destination, groups))
        if not candidates:
            break
        score = max(candidate[0] for candidate in candidates)
        _, destination, groups = random_select(
            state, [candidate for candidate in candidates if candidate[0] == score])
        for source, number in groups:
            _march_with_harassment(state, GERMANS, source, [destination],
                                   {WARBAND: number, LEADER: False})
            used.add(source)
            marched.append({"source": source, "dest": destination, "warbands": number})
    return marched


def _faction_ambush_sweep(state, attacker, only_faction=None):
    """Ambush in every Region where ``attacker`` is able (Hidden-majority,
    Loss-causing). Returns the list of ambush results. ``only_faction``
    restricts the defender (e.g. card A58 shaded Ambushes Romans only)."""
    from fs_bot.board.control import refresh_all_control
    from fs_bot.map.map_data import get_playable_regions
    from fs_bot.battle.resolve import resolve_battle
    out = []
    for region in get_playable_regions(state["scenario"], state.get("capabilities")):
        tgt = _faction_ambush_target(state, region, attacker, only_faction)
        if tgt is None:
            continue
        try:
            res = resolve_battle(state, region, attacker, tgt, is_ambush=True)
            out.append({"region": region, "defender": tgt, "result": res})
        except _EXEC_ERRORS as exc:
            out.append({"region": region, "executed": False, "reason": repr(exc)})
    refresh_all_control(state)
    return out


def _german_setup_marches(state, march_limit):
    """Up to ``march_limit`` German setup Marches: gather a Region's German
    Hidden Warbands one step into an adjacent enemy-occupied Region where the
    move newly enables a legal, Loss-causing Ambush. Ranked by enemy force
    exposed; never strips a Region that already has a legal Ambush of its own.
    Returns the list of marches performed. (Shared by cards 65 and 17.)"""
    from fs_bot.rules_consts import GERMANS, WARBAND, HIDDEN
    from fs_bot.board.pieces import count_pieces, count_pieces_by_state, move_piece
    from fs_bot.board.control import refresh_all_control
    from fs_bot.map.map_data import get_adjacent, get_playable_regions
    scen = state["scenario"]
    playable = list(get_playable_regions(scen, state.get("capabilities")))
    candidates = []
    for S in sorted(playable):
        hid = count_pieces_by_state(state, S, GERMANS, WARBAND, HIDDEN)
        if hid <= 0:
            continue
        if _german_ambush_target(state, S) is not None:
            continue
        for B in get_adjacent(S, scen):
            if B not in playable:
                continue
            if _german_ambush_target(state, B) is not None:
                continue
            move_piece(state, S, B, GERMANS, WARBAND, count=hid,
                       piece_state=HIDDEN)
            tgt = _german_ambush_target(state, B)
            exposed = count_pieces(state, B, tgt) if tgt else 0
            move_piece(state, B, S, GERMANS, WARBAND, count=hid,
                       piece_state=HIDDEN)
            if tgt is not None:
                candidates.append((exposed, S, B, hid))
    candidates.sort(key=lambda c: -c[0])
    marched, used = [], set()
    for exposed, S, B, hid in candidates:
        if len(marched) >= march_limit:
            break
        if S in used:
            continue
        cur = count_pieces_by_state(state, S, GERMANS, WARBAND, HIDDEN)
        if cur <= 0:
            continue
        move_piece(state, S, B, GERMANS, WARBAND, count=cur, piece_state=HIDDEN)
        used.add(S)
        marched.append({"source": S, "dest": B, "warbands": cur})
    if marched:
        refresh_all_control(state)
    return marched


def _resolve_card65_german_march_ambush(state, march_limit):
    """Card 65 German Allegiances (unshaded): "March Germans from up to 2
    Regions, then Ambush with all Germans able."

    Setup March (<= march_limit source Regions): gather a Region's German
    Hidden Warbands one step into an adjacent enemy-occupied Region where the
    move newly enables a legal, Loss-causing Ambush. The moves giving the
    largest resulting enemy force under Ambush are taken first. Then Ambush in
    every Region where the Germans are able (Hidden-majority + would cause a
    Loss), best target first.
    """
    from fs_bot.rules_consts import GERMANS
    from fs_bot.board.control import refresh_all_control
    from fs_bot.map.map_data import get_playable_regions
    from fs_bot.battle.resolve import resolve_battle
    scen = state["scenario"]
    playable = list(get_playable_regions(scen, state.get("capabilities")))

    marched = _german_setup_marches(state, march_limit)

    # ---- Ambush with all Germans able (every legal Region).
    ambushes = []
    for region in sorted(playable):
        tgt = _german_ambush_target(state, region)
        if tgt is None:
            continue
        try:
            res = resolve_battle(state, region, GERMANS, tgt, is_ambush=True)
        except _EXEC_ERRORS as exc:
            ambushes.append({"region": region, "executed": False,
                             "reason": repr(exc)})
            continue
        ambushes.append({"region": region, "defender": tgt, "result": res})
    refresh_all_control(state)
    return [{"free_action": "german_march_ambush",
             "flag": "card_65_german_march_ambush",
             "marches": marched, "ambushes": ambushes,
             "executed": bool(ambushes)}]


def _resolve_card58_german_ambush(state):
    """Card 58 Aduatuca (shaded): "March Germans to 1 Region with a Fort. They
    Ambush Romans there, 1 Loss per 2 Warbands." ("Sugambri strike unprepared
    fort" — the Fort gives no protection: ignore_fort.)

    Gather German Warbands from a Roman-Fort Region and its neighbours
    into that Region, then resolve a German Ambush of the Romans there with
    ignore_fort (no halving, full auto-remove). Warband Losses are the normal
    1/2 each = 1 Loss per 2 Warbands. Chooses the Fort Region where the most
    German Warbands can be gathered. The Card Tips expressly waive Hidden
    superiority; Revealed/Scouted Warbands may March and participate too.
    """
    from fs_bot.rules_consts import GERMANS, ROMANS, WARBAND, FORT, LEADER
    from fs_bot.board.pieces import count_pieces
    from fs_bot.board.control import refresh_all_control
    from fs_bot.map.map_data import get_adjacent, get_playable_regions
    from fs_bot.battle.resolve import resolve_battle
    scen = state["scenario"]
    playable = set(get_playable_regions(scen, state.get("capabilities")))

    best = None  # (gatherable, R, sources)
    for R in sorted(playable):
        if count_pieces(state, R, ROMANS, FORT) <= 0:
            continue
        if count_pieces(state, R, ROMANS) <= 0:
            continue
        sources = {r: count_pieces(state, r, GERMANS, WARBAND)
                   for r in [R] + [a for a in get_adjacent(R, scen)
                                   if a in playable]}
        sources = {r: n for r, n in sources.items() if n > 0}
        total = sum(sources.values())
        if total <= 0:
            continue
        if best is None or total > best[0]:
            best = (total, R, sources)

    if best is None:
        return [{"free_action": "ambush", "flag": "card_58_german_march_battle",
                 "executed": False, "declined_no_effect": True,
                 "reason": "no Fort Region where Germans can gather an Ambush"}]

    total, R, sources = best
    marched = 0
    for src, n in sources.items():
        if src == R:
            continue
        _march_with_harassment(state, GERMANS, src, [R],
                               {WARBAND: n, LEADER: False})
        marched += n
    refresh_all_control(state)
    try:
        res = resolve_battle(state, R, GERMANS, ROMANS,
                             is_ambush=True, ignore_fort=True)
    except _EXEC_ERRORS as exc:
        return [{"free_action": "ambush", "flag": "card_58_german_march_battle",
                 "region": R, "executed": False, "reason": repr(exc)}]
    return [{"free_action": "ambush", "flag": "card_58_german_march_battle",
             "region": R, "defender": ROMANS, "warbands_gathered": total,
             "warbands_marched": marched, "result": res}]


def _resolve_card72_march_enemy_battle(state, faction):
    """Card72: bounded adjacent March followed by the chosen enemy's Battle."""
    from fs_bot.cards.impetuosity_unshaded import resolve_impetuosity_unshaded
    return resolve_impetuosity_unshaded(state, faction)


def _resolve_card72_hidden_march_battle(state, faction):
    """Card72's selected Hidden group Marches and may Battle by itself."""
    from fs_bot.cards.impetuosity import resolve_impetuosity
    return resolve_impetuosity(state, faction)


def _card70_route(state, origin, destination, max_steps):
    """Shortest legal route reaches the sole destination without early stops."""
    from collections import deque
    from fs_bot.rules_consts import ROMANS
    from fs_bot.map.map_data import get_adjacent_for_state, get_playable_regions_for_state
    from fs_bot.commands.march import _check_crossing_stop
    playable = set(get_playable_regions_for_state(state, ROMANS))
    queue = deque([(origin, [])])
    seen = {origin}
    while queue:
        current, path = queue.popleft()
        if len(path) >= max_steps:
            continue
        for region in sorted(get_adjacent_for_state(state, current, ROMANS)):
            if region not in playable or region in seen:
                continue
            route = path + [region]
            if region == destination:
                return route
            if not _check_crossing_stop(state, current, region, ROMANS)[0]:
                seen.add(region)
                queue.append((region, route))
    return None


def _resolve_card70_march_battle(state, target_regions, legion_limit):
    """Card 70: a bounded free Roman March, then a separate free Battle."""
    from fs_bot.rules_consts import ROMANS, LEGION, AUXILIA, LEADER, CAESAR
    from fs_bot.map.map_data import get_adjacent, get_playable_regions
    from fs_bot.bots.roman_bot import _rank_battle_targets
    from fs_bot.battle.resolve import resolve_battle
    from fs_bot.engine.diviciacus_planning import plan_with_diviciacus, clear_confirmation
    scen = state["scenario"]
    playable = set(get_playable_regions(scen, state.get("capabilities")))
    targets = [r for r in (target_regions or []) if r in playable]

    def march_planner(sim):
        # Retain the existing target/source priorities, but evaluate and move
        # the actual agreed cohort through the ordinary March machinery.
        best = None
        for target in targets:
            defenders = _rank_battle_targets(sim, target, scen)
            source = None
            for origin in sorted(playable - {target}):
                mobile = count_pieces(sim, origin, ROMANS, LEGION) + count_pieces(sim, origin, ROMANS, AUXILIA)
                leader = get_leader_in_region(sim, origin, ROMANS)
                route = _card70_route(sim, origin, target, 3 if leader == CAESAR else 2)
                if route and mobile > 0 and (source is None or mobile > source[1]):
                    source = (origin, mobile, route, leader if leader == CAESAR else None)
            mobile_enemy = 0
            if defenders:
                mobile_enemy = sum(count_pieces(sim, target, defenders[0], piece)
                                   for piece in ("Warband", AUXILIA, LEGION))
            if source is None and not _attacker_has_force(sim, target, ROMANS):
                continue
            if best is None or mobile_enemy > best[0]:
                best = (mobile_enemy, target, source)
        if best is None:
            return {"command": "Pass"}
        _, target, source_data = best
        if source_data is None:
            return {"command": "Pass", "details": {"card70_target": target}}
        source, _, route, leader = source_data
        group = {LEGION: min(legion_limit, count_pieces(sim, source, ROMANS, LEGION)),
                 AUXILIA: count_pieces(sim, source, ROMANS, AUXILIA), LEADER: leader}
        return {"command": _CMD_MARCH, "sa": SA_ACTION_NONE_LABEL,
                "regions": [source], "details": {
                    "card70_target": target, "origins": [source],
                    "destinations": [target], "routes": {source: route},
                    "groups": {source: group}}}

    action = plan_with_diviciacus(state, ROMANS, march_planner)
    target = (action.get("details") or {}).get("card70_target")
    if target is None:
        return [{"free_action": "march_battle", "flag": "card_70_roman_march_battle",
                 "executed": False, "reason": "no named Region with a Roman group or target"}]
    moved = {"legions": 0, "auxilia": 0}
    if action.get("command") == _CMD_MARCH:
        _request_event_diviciacus(state, ROMANS, action, 70)
        source = action["details"]["origins"][0]
        group = action["details"]["groups"][source]
        if ROMANS not in state.get("non_player_factions", set()):
            from fs_bot.engine.diviciacus import force_scope
            with force_scope(state, ROMANS, action["details"].get("diviciacus_regions", [])):
                group[AUXILIA] = count_pieces(state, source, ROMANS, AUXILIA)
        try:
            march = _execute_march(state, ROMANS, action, free=True, moving_only=True)
        finally:
            clear_confirmation(state, ROMANS, action)
        if not march["executed"]:
            return [{"free_action": "march", "flag": "card_70_roman_march_battle",
                     "region": target, "result": march}]
        moved = {"legions": group[LEGION], "auxilia": group[AUXILIA]}
        if not any(entry.get("final_region") == target for entry in march["marches"]):
            return [{"free_action": "march", "flag": "card_70_roman_march_battle",
                     "region": target, "moved": moved, "result": march,
                     "battle": None, "reason": "moving cohort could not reach the Battle destination"}]

    def select_battle(sim):
        defenders = _rank_battle_targets(sim, target, scen)
        return target, defenders[0] if defenders else None
    action = _plan_fixed_event_battle(state, ROMANS, 70, {target}, select_battle)
    if action is None:
        return [{"free_action": "march", "flag": "card_70_roman_march_battle",
                 "region": target, "moved": moved, "battle": None,
                 "reason": "no Battle target in T after March"}]
    defender = action["details"]["battle_plan"][0]["target"]
    try:
        res = _resolve_fixed_event_battle(state, ROMANS, action)
    except _EXEC_ERRORS as exc:
        return [{"free_action": "march_battle", "flag": "card_70_roman_march_battle",
                 "region": target, "executed": False, "reason": repr(exc)}]
    finally:
        clear_confirmation(state, ROMANS, action)
    return [{"free_action": "march_battle", "flag": "card_70_roman_march_battle",
             "region": target, "defender": defender, "moved": moved, "result": res}]


def _resolve_card2_battle(state, faction, region):
    """Card 2 Legiones (shaded): the acting Faction free Battles the Romans in
    ``region`` with auto_legion_loss (the first Roman Loss removes a Legion)."""
    from fs_bot.rules_consts import ROMANS
    from fs_bot.engine.diviciacus_planning import clear_confirmation
    if region is None or faction == ROMANS:
        return [{"free_action": "battle", "flag": "card_2", "executed": False,
                 "reason": "no battle region or Roman actor"}]
    action = _plan_fixed_event_battle(
        state, faction, 2, {region}, lambda sim: (region, ROMANS))
    try:
        res = _resolve_fixed_event_battle(state, faction, action,
                                         auto_legion_loss=True)
    except _EXEC_ERRORS as exc:
        return [{"free_action": "battle", "flag": "card_2",
                 "executed": False, "reason": repr(exc)}]
    finally:
        clear_confirmation(state, faction, action)
    return [{"free_action": "battle", "flag": "card_2", "region": region,
             "defender": ROMANS, "result": res}]


def _free_double_aux_battle(state, region, auxilia_only=False):
    """Resolve a Roman free Battle in ``region`` with double Auxilia Losses,
    targeting the top Roman Battle-priority defender (8.8.1). Returns the
    battle result dict, or None if there is no valid target. ``auxilia_only``
    restricts the attack to Auxilia (card 11 Ariovistus)."""
    from fs_bot.rules_consts import ROMANS
    from fs_bot.bots.roman_bot import _rank_battle_targets
    from fs_bot.engine.diviciacus_planning import clear_confirmation
    if region is None:
        return None
    def select(sim):
        targets = _rank_battle_targets(sim, region, sim["scenario"])
        return region, targets[0] if targets else None
    action = _plan_fixed_event_battle(
        state, ROMANS, "11a" if auxilia_only else 11, {region}, select)
    if action is None:
        return None
    try:
        return _resolve_fixed_event_battle(state, ROMANS, action,
            double_auxilia=True, auxilia_only_attack=auxilia_only)
    finally:
        clear_confirmation(state, ROMANS, action)


def _resolve_double_aux_battle_card(state, region, flag):
    """Cards 11 / 11a (unshaded): free Battle in the Auxilia-placement Region
    with double Auxilia Losses (the placement itself was done by the card
    handler from the derived Region)."""
    res = _free_double_aux_battle(state, region, auxilia_only=(flag == "card_11a"))
    if res is None:
        return [{"free_action": "battle", "flag": flag, "executed": False,
                 "declined_no_effect": True,
                 "reason": "no Battle target in placement Region"}]
    return [{"free_action": "battle", "flag": flag, "region": region,
             "result": res}]


def _card6_battle_plan(state):
    """Retain Card 6's Region priority and Roman-specific defender ranking."""
    from fs_bot.rules_consts import ROMANS
    from fs_bot.map.map_data import get_playable_regions_for_state
    from fs_bot.bots.roman_bot import _rank_battle_targets
    region, _ = _choose_free_battle(
        state, ROMANS, get_playable_regions_for_state(state, ROMANS))
    if region is None:
        return None
    targets = _rank_battle_targets(state, region, state['scenario'])
    if not targets:
        return None
    return {"command": _CMD_BATTLE, "sa": SA_ACTION_NONE_LABEL,
            "regions": [region], "details": {
                "battle_plan": [{"region": region, "target": targets[0]}]}}


def _resolve_card6_scout_battle(state):
    """Card 6: Romans independently choose free Scout, then one free Battle.

    The Roman beneficiary chooses even if a different Faction played the
    Event. NP/default plans retain Roman Scout and Battle priorities (§8.2.3).
    """
    from fs_bot.rules_consts import ROMANS
    from fs_bot.engine.free_actions import consult_free_action, execute_free_action_plan
    out = []
    scout_request = {"kind": "free_action", "request_type": "event_sa",
                     "allowed_sas": [_SA_SCOUT], "free": True}
    scout_plan = consult_free_action(state, ROMANS, scout_request)
    if scout_plan == {"decline": True}:
        out.append({"free_action": "scout", "flag": "card_6",
                    "executed": False, "declined": True,
                    "reason": "free Scout declined"})
    else:
        if scout_plan is None:
            scout_plan = {"sa": _SA_SCOUT, "sa_regions": [], "details": {}}
        try:
            scout = execute_free_action_plan(state, ROMANS, scout_request, scout_plan)
            out.append({"free_action": "scout", "flag": "card_6", "result": scout})
        except _EXEC_ERRORS as exc:
            out.append({"free_action": "scout", "flag": "card_6",
                        "executed": False, "reason": repr(exc)})

    # Consult after Scout so a human sees its changes before choosing Battle.
    battle_request = {"kind": "free_action", "request_type": "event_command",
                      "allowed_commands": [_CMD_BATTLE], "max_regions": 1,
                      "with_sa": False, "free": True, "double_auxilia": True}
    battle_plan = consult_free_action(state, ROMANS, battle_request)
    if battle_plan == {"decline": True}:
        out.append({"free_action": "battle", "flag": "card_6",
                    "executed": False, "declined": True,
                    "reason": "free Battle declined"})
        return out
    if battle_plan is None:
        from fs_bot.engine.diviciacus_planning import plan_with_diviciacus
        battle_plan = plan_with_diviciacus(state, ROMANS,
            lambda sim: _card6_battle_plan(sim) or {"command": "Pass"})
        if battle_plan.get("command") != _CMD_BATTLE:
            out.append({"free_action": "battle", "flag": "card_6",
                        "executed": False, "declined_no_effect": True,
                        "reason": "no valid Battle Region"})
            return out
    try:
        # This is a Battle Command: apply capabilities/prefire as well as
        # Card 6's trusted Auxilia bonus, without granting an accompanying SA.
        res = execute_free_action_plan(state, ROMANS, battle_request, battle_plan)
        out.append({"free_action": "battle", "flag": "card_6", "result": res})
    except _EXEC_ERRORS as exc:
        out.append({"free_action": "battle", "flag": "card_6",
                    "executed": False, "reason": repr(exc)})
    return out


def _resolve_a20_free_seize(state):
    """A20 Morbihan (unshaded): after the Arverni are removed from Veneti, the
    Romans free Seize there (§3.2.3 — Forage; Disperse Subdued Tribes only
    where Roman-Controlled). The Seize belongs to the Romans by the card text,
    so it is executed for the Romans regardless of which Faction played the
    Event. If the Romans hold no pieces in Veneti, Seize is not possible there
    and this no-ops (validate_seize_region, §3.2.3).

    A20 shaded (Arverni Ambush near Veneti) is handled separately by
    _resolve_a20_arverni_ambush. (The Arverni are NOT a player Faction in
    Ariovistus: per available_forces_ariovistus.txt and A6.2 they are
    game-run via the Arverni Phase, like the base game's Germans, with
    mechanical Battle-with-Ambush per A6.2.4.)
    """
    from fs_bot.rules_consts import ROMANS, VENETI
    from fs_bot.board.pieces import count_pieces
    from fs_bot.board.control import is_controlled_by
    if count_pieces(state, VENETI, ROMANS) <= 0:
        return [{"free_action": "seize", "flag": "card_A20_free_seize_veneti",
                 "executed": False, "declined_no_effect": True,
                 "reason": "Romans have no pieces in Veneti"}]
    # Card A20: "free Seize there as if Roman Control" — Disperse Veneti's
    # Subdued Tribes regardless of actual Control.
    try:
        res = _execute_seize(state, ROMANS, {
            "command": _CMD_SEIZE, "sa": SA_ACTION_NONE_LABEL,
            "regions": [VENETI], "details": {"disperse_regions": [VENETI],
                                             "as_if_control": True}})
    except _EXEC_ERRORS as exc:
        return [{"free_action": "seize", "flag": "card_A20_free_seize_veneti",
                 "executed": False, "reason": repr(exc)}]
    return [{"free_action": "seize", "flag": "card_A20_free_seize_veneti",
             "region": VENETI, "result": res}]


def _resolve_a20_arverni_ambush(state):
    """A20 Morbihan (shaded): "If Veneti Arverni Ally, Arverni Warbands within
    1 Region Ambush Romans in a Region within 1 as if there."

    The Arverni are game-run in Ariovistus (A6.2), so this is a mechanical
    Battle-with-Ambush per A6.2.4. The card's "as if there" lets all
    Arverni Warbands within one Region of Veneti join the Ambush as
    if present: we gather those projecting Warbands into the Battle Region,
    resolve the standard Ambush (no Retreat, auto-remove; Step 5 Reveal flips
    surviving Hidden Warbands), then return the projected Warbands — now
    Revealed — to their home Regions. Surviving projected Warbands return
    after any Caesar Counterattack.

    A6.2.4 requires Hidden Arverni Warbands to outnumber the Defender's Hidden
    pieces and the Ambush to cause an enemy Loss. The Battle Region is chosen
    to remove the most Roman pieces.
    """
    from fs_bot.rules_consts import (VENETI, ARVERNI, ROMANS, WARBAND, AUXILIA,
                                     LEGION, FORT, CITADEL, HIDDEN, REVEALED,
                                     SCOUTED, ALLY, TRIBE_VENETI)
    from fs_bot.board.pieces import (count_pieces, count_pieces_by_state,
                                     move_piece, get_leader_in_region)
    from fs_bot.board.control import refresh_all_control
    from fs_bot.map.map_data import get_adjacent
    from fs_bot.battle.resolve import resolve_battle

    if (state.get("tribes", {}).get(TRIBE_VENETI, {}).get("allied_faction") != ARVERNI
            or count_pieces(state, VENETI, ARVERNI, ALLY) <= 0):
        return [{"free_action": "ambush", "flag": "card_A20_arverni_ambush",
                 "executed": False, "declined_no_effect": True,
                 "reason": "no Arverni Ally in Veneti"}]
    scen = state["scenario"]
    theater = [VENETI] + list(get_adjacent(VENETI, scen))

    def roman_hidden(region):
        return (count_pieces_by_state(state, region, ROMANS, AUXILIA, HIDDEN)
                + count_pieces_by_state(state, region, ROMANS, WARBAND, HIDDEN))

    best = None  # (B, sources, projected, damage)
    for B in theater:
        if count_pieces(state, B, ROMANS) <= 0:
            continue
        # Both "within 1" clauses are centred on Veneti. A source and
        # destination need not be adjacent to each other. All Warbands
        # contribute Losses; only Hidden ones establish Ambush superiority.
        sources = {(r, ps): count_pieces_by_state(state, r, ARVERNI, WARBAND, ps)
                   for r in theater for ps in (HIDDEN, REVEALED, SCOUTED)}
        sources = {key: n for key, n in sources.items() if n > 0}
        projected = sum(sources.values())
        hidden = sum(n for (r, ps), n in sources.items() if ps == HIDDEN)
        if projected <= 0 or hidden <= roman_hidden(B):
            continue
        # Arverni cause floor(Warbands * 1/2); halved again vs Fort/Citadel.
        raw = projected * 0.5
        if (count_pieces(state, B, ROMANS, FORT) > 0
                or count_pieces(state, B, ROMANS, CITADEL) > 0):
            raw *= 0.5
        predicted = int(raw)
        # "Romans" includes Allies and Forts; a mobile escort is not a
        # prerequisite for the granted Battle.
        removable = count_pieces(state, B, ROMANS)
        damage = min(predicted, removable)
        if damage <= 0:
            continue
        if best is None or damage > best[3]:
            best = (B, sources, projected, damage)

    if best is None:
        return [{"free_action": "ambush", "flag": "card_A20_arverni_ambush",
                 "executed": False, "declined_no_effect": True,
                 "reason": "no valid Ambush within 1 of Veneti"}]

    B, sources, projected, _ = best
    from fs_bot.cards.morbihan_display import snapshot_sources, projected_battle
    physical_sources = snapshot_sources(state, theater)
    moved = {}
    for (r, ps), n in sources.items():
        if r == B:
            continue
        move_piece(state, r, B, ARVERNI, WARBAND, count=n, piece_state=ps)
        moved[r, ps] = n
    try:
        with projected_battle(state, B, physical_sources):
            res = resolve_battle(state, B, attacking_faction=ARVERNI,
                                 defending_faction=ROMANS, is_ambush=True)
    except _EXEC_ERRORS as exc:
        # Restore on failure to keep the board consistent.
        for (r, ps), n in moved.items():
            avail = count_pieces_by_state(state, B, ARVERNI, WARBAND, ps)
            take = min(n, avail)
            if take > 0:
                move_piece(state, B, r, ARVERNI, WARBAND, count=take,
                           piece_state=ps)
        refresh_all_control(state)
        return [{"free_action": "ambush", "flag": "card_A20_arverni_ambush",
                 "executed": False, "reason": repr(exc)}]
    # Return projected Warbands (now Revealed by Step 5) to their Regions.
    for (r, ps), n in moved.items():
        avail = count_pieces_by_state(state, B, ARVERNI, WARBAND, REVEALED)
        take = min(n, avail)
        if take > 0:
            move_piece(state, B, r, ARVERNI, WARBAND, count=take,
                       piece_state=REVEALED)
    refresh_all_control(state)
    return [{"free_action": "ambush", "flag": "card_A20_arverni_ambush",
             "region": B, "defender": ROMANS, "projected_warbands": projected,
             "result": res}]


def _move_roman_aux(state, src, dst, n):
    """Move up to n Roman Auxilia src->dst, Hidden first then Revealed."""
    from fs_bot.rules_consts import ROMANS, AUXILIA, HIDDEN, REVEALED
    from fs_bot.board.pieces import count_pieces_by_state, move_piece
    moved = 0
    for ps in (HIDDEN, REVEALED):
        if moved >= n:
            break
        avail = count_pieces_by_state(state, src, ROMANS, AUXILIA, ps)
        take = min(avail, n - moved)
        if take > 0:
            move_piece(state, src, dst, ROMANS, AUXILIA, count=take,
                       piece_state=ps)
            moved += take
    return moved


def _resolve_a17_march_battle(state):
    from fs_bot.cards.publius import resolve_publius
    return resolve_publius(state)


def _resolve_a19_march_romans(state, faction):
    """A19 Gaius Valerius Procillus (shaded): "March all Romans in 1 Region to
    an adjacent one with Germans."

    German NP instruction (Ariovistus): "Play only to move to where no Fort
    and Germans will outnumber Romans." So a Germanic actor relocates all
    Roman mobile pieces (Caesar, Legions, Auxilia) from a source Region into
    an adjacent destination that (a) contains Germans, (b) has no Fort, and
    (c) where, after the move, German pieces outnumber the Roman pieces —
    trapping the Romans for a German attack. Among valid moves, the
    one trapping the most Roman pieces (then the largest German advantage) is
    chosen. Only the Germanic path is specified; other Factions no-op.
    """
    from fs_bot.rules_consts import (GERMANS, ROMANS, CAESAR, LEADER, LEGION,
                                     AUXILIA, WARBAND, FORT, HIDDEN, REVEALED,
                                     SCOUTED)
    from fs_bot.board.pieces import (count_pieces, count_pieces_by_state,
                                     get_leader_in_region, move_piece)
    from fs_bot.board.control import refresh_all_control
    from fs_bot.map.map_data import get_adjacent, get_playable_regions
    if faction != GERMANS:
        return []
    scen = state["scenario"]
    playable = get_playable_regions(scen, state.get("capabilities"))

    def roman_mobile(r):
        m = (count_pieces(state, r, ROMANS, LEGION)
             + count_pieces(state, r, ROMANS, AUXILIA))
        if get_leader_in_region(state, r, ROMANS) is not None:
            m += 1
        return m

    best = None  # (S, D, trapped, advantage)
    for S in sorted(playable):
        rs = roman_mobile(S)
        if rs <= 0:
            continue
        for D in get_adjacent(S, scen):
            if count_pieces(state, D, GERMANS) <= 0:        # "with Germans"
                continue
            if count_pieces(state, D, ROMANS, FORT) > 0:     # "no Fort"
                continue
            romans_after = count_pieces(state, D, ROMANS) + rs
            adv = count_pieces(state, D, GERMANS) - romans_after
            if adv <= 0:                                     # "outnumber"
                continue
            key = (rs, adv)
            if best is None or key > (best[2], best[3]):
                best = (S, D, rs, adv)

    if best is None:
        return [{"free_action": "march_romans", "flag":
                 "card_A19_march_romans", "executed": False,
                 "declined_no_effect": True,
                 "reason": "no move where Germans outnumber Romans (no Fort)"}]

    S, D, trapped, adv = best
    # Move all Roman mobile pieces S -> D (Caesar, then Legions, then Auxilia).
    moved = {"caesar": False, "legions": 0, "auxilia": 0}
    leader = get_leader_in_region(state, S, ROMANS)
    if leader is not None:
        move_piece(state, S, D, ROMANS, LEADER)
        moved["caesar"] = leader == CAESAR
        moved["leader"] = leader
    legs = count_pieces(state, S, ROMANS, LEGION)
    if legs:
        move_piece(state, S, D, ROMANS, LEGION, count=legs)
        moved["legions"] = legs
    for ps in (HIDDEN, REVEALED, SCOUTED):
        a = count_pieces_by_state(state, S, ROMANS, AUXILIA, ps)
        if a:
            move_piece(state, S, D, ROMANS, AUXILIA, count=a, piece_state=ps)
            moved["auxilia"] += a
    refresh_all_control(state)
    return [{"free_action": "march_romans", "flag": "card_A19_march_romans",
             "source": S, "dest": D, "moved": moved,
             "german_advantage": adv}]


def _resolve_a67_arduenna(state, faction):
    """A67 German NP: gather the maximum safe force, take Control, Battle.

    The specific Arduenna instruction requires retaining Germanic Control at
    origins, including when the Leader departs. Its "as many ... as possible"
    replaces the normal March flowchart's additional one-Warband leave-behind.
    Only targets that the gathered force can Control qualify for the stated
    Roman, then Aedui, then Belgic target priority.
    """
    from fs_bot.rules_consts import (GERMANS, ROMANS, AEDUI, BELGAE, WARBAND,
                                     NERVII, TREVERI, REVEALED, HIDDEN, AUXILIA,
                                     FACTIONS, LEADER)
    from fs_bot.board.pieces import (count_pieces, count_pieces_by_state,
                                     flip_piece)
    from fs_bot.board.control import is_controlled_by
    from fs_bot.map.map_data import get_adjacent
    out = []
    if faction != GERMANS:
        return out
    priority = (ROMANS, AEDUI, BELGAE)

    def other_forces(region):
        return sum(count_pieces(state, region, other)
                   for other in FACTIONS if other != GERMANS)

    def safe_group(origin):
        warbands = count_pieces(state, origin, GERMANS, WARBAND)
        leader = get_leader_in_region(state, origin, GERMANS)
        movable = warbands + int(leader is not None)
        if is_controlled_by(state, origin, GERMANS):
            # Control requires strictly more than ALL other Forces combined.
            # Structures can retain Control without leaving a Warband behind.
            movable = min(movable, max(0,
                count_pieces(state, origin, GERMANS) - other_forces(origin) - 1))
        moving_leader = leader if movable > 0 else None
        return {LEADER: moving_leader,
                WARBAND: min(warbands, movable - int(moving_leader is not None))}

    candidates = []
    for region in (NERVII, TREVERI):
        defender = next((pf for pf in priority
                         if count_pieces(state, region, pf) > 0), None)
        if defender is None:
            continue
        moves = []
        gathered = count_pieces(state, region, GERMANS)
        for origin in get_adjacent(region, state['scenario']):
            group = safe_group(origin)
            if not _group_has_pieces(group):
                continue
            moves.append((origin, group))
            gathered += group[WARBAND] + int(group[LEADER] is not None)
        if gathered > other_forces(region):
            candidates.append((region, defender, moves))
    if not candidates:
        return out
    first_priority = min(priority.index(candidate[1]) for candidate in candidates)
    target, defender, moves = random_select(state, [
        candidate for candidate in candidates
        if priority.index(candidate[1]) == first_priority])

    marched = []
    for origin, group in moves:
        try:
            final = _march_with_harassment(state, faction, origin, [target],
                                           group_cap=group)
            marched.append({"origin": origin, "final_region": final})
        except _EXEC_ERRORS as exc:
            marched.append({"origin": origin, "executed": False,
                            "reason": repr(exc)})
    out.append({"free_action": "march", "flag": "card_A67_arduenna",
                "target": target, "marches": marched})

    # Free Battle the priority player there (Retreat allowed).
    if count_pieces(state, target, faction, WARBAND) > 0 and \
            count_pieces(state, target, defender) > 0:
        try:
            res = _execute_battle(state, faction, {
                "command": _CMD_BATTLE, "sa": SA_ACTION_NONE_LABEL,
                "sa_regions": [],
                "details": {"battle_plan": [{"region": target,
                                             "target": defender}]}})
            out.append({"free_action": "battle", "flag": "card_A67_arduenna",
                        "region": target, "defender": defender, "result": res})
        except _EXEC_ERRORS as exc:
            out.append({"free_action": "battle", "flag": "card_A67_arduenna",
                        "executed": False, "reason": repr(exc)})

    # Flip the German pieces in the target Hidden (the card's final step).
    flipped = 0
    for pt in (WARBAND, AUXILIA):
        rev = count_pieces_by_state(state, target, faction, pt, REVEALED)
        if rev > 0:
            flip_piece(state, target, faction, pt, rev,
                       from_state=REVEALED, to_state=HIDDEN)
            flipped += rev
    if flipped:
        out.append({"free_action": "flip_hidden", "flag": "card_A67_arduenna",
                    "region": target, "flipped": flipped})
    return out


def _resolve_a58_battle_seize(state, faction):
    from fs_bot.rules_consts import ROMANS, BELGICA_REGIONS
    from fs_bot.board.pieces import count_pieces
    from fs_bot.board.control import is_controlled_by
    out = []
    if faction != ROMANS:
        return out
    belgica = set(BELGICA_REGIONS)
    # Free Battle in Belgica (Retreat allowed — the card sets no no-Retreat).
    action = _plan_free_battle_command(state, faction, belgica)
    if action is not None:
        chosen = action["details"]["battle_plan"][0]
        region, defender = chosen["region"], chosen["target"]
        try:
            res = _execute_battle(state, faction, action)
            out.append({"free_action": "battle", "flag":
                        "card_A58_roman_battle_seize", "region": region,
                        "defender": defender, "result": res})
        except _EXEC_ERRORS as exc:
            out.append({"free_action": "battle",
                        "flag": "card_A58_roman_battle_seize",
                        "executed": False, "reason": repr(exc)})
    # Free Seize in Belgica Regions where Romans have pieces; Disperse where
    # Roman-Controlled (get_dispersible_tribes enforces the cap/Control).
    seize_regions = [r for r in BELGICA_REGIONS
                     if count_pieces(state, r, ROMANS) > 0]
    if seize_regions:
        # "as if Roman Control, with no Harassment": Disperse every Seize
        # Region's Subdued Tribes regardless of actual Control, no Harassment.
        try:
            sres = _execute_seize(state, faction, {
                "command": _CMD_SEIZE, "sa": SA_ACTION_NONE_LABEL,
                "regions": seize_regions,
                "details": {"disperse_regions": seize_regions,
                            "as_if_control": True, "no_harassment": True}})
            out.append({"free_action": "seize",
                        "flag": "card_A58_roman_battle_seize",
                        "regions": seize_regions, "result": sres})
        except _EXEC_ERRORS as exc:
            out.append({"free_action": "seize",
                        "flag": "card_A58_roman_battle_seize",
                        "executed": False, "reason": repr(exc)})
    return out


def _execute_event(state, faction, bot_action, *, human=False):
    """Execute an Event via the card_effects dispatcher.

    The decision carries the card id and the Dual-Use text preference
    (§8.2.2 / A8.2.2). We map that preference to the dispatcher's ``shaded``
    flag. Unimplemented card stubs or unknown ids are reported, not raised, so
    a full game keeps running.

    NP (bot) Events auto-derive their parameter choices per §8.2.3/§8.3.1. A
    human Event (``human=True``) instead uses the params the player supplied in
    ``details['event_params']`` — a human chooses for themselves, so the NP
    auto-derivation is skipped.
    """
    details = bot_action.get("details") or {}
    card_id = details.get("card_id", state.get("current_card"))
    shaded = details.get("text_preference") == EVENT_SHADED

    if (card_id in (47, "A66") and human and "event_params" in details
            and not isinstance(details["event_params"], dict)):
        return {"executed": False, "command": _CMD_EVENT,
                "card_id": card_id, "shaded": shaded,
                "reason": f"Card {card_id} event_params must be an object."}

    # Populate event_params before resolving; restore afterwards. For a bot,
    # derive the NP choice (§8.2.3/§8.3.1). For a human, take the player's own
    # params from the plan (no NP derivation). Cards whose choices aren't
    # available still raise ValueError and are reported, not crashed.
    prev_params = state.get("event_params")
    if human:
        derived = details.get("event_params")
    else:
        derived = _derive_event_params(state, faction, card_id, shaded)
    # Always expose a dict (never None) so card handlers that read
    # state.get("event_params").get(...) don't crash on missing params.
    state["event_params"] = {**(prev_params or {}), **(derived or {})}
    # Many card handlers read state["executing_faction"] to know who is
    # playing the Event; it was never set, so those cards no-op. Set it for
    # the acting faction (restored afterwards).
    prev_faction = state.get("executing_faction")
    state["executing_faction"] = faction
    # TRANSACTIONAL: "report, do not crash" means a failed Event did not
    # happen. (§5.1.3 Partial Execution is honoured INSIDE handlers — they
    # carry out whatever parts apply and skip the rest; a raise is reserved
    # for invalid parameters or a wholly inapplicable Event, and the CLI
    # validation loop means the plan that finally executes satisfies
    # §5.1.3.) — but a handler that mutates mid-loop and then raises (e.g. a
    # per-move/per-placement list where a later entry is illegal) would
    # otherwise leave a half-applied Event behind executed=False. Snapshot
    # the state and roll back on the safe-error path. (Found by the
    # player_fuzz dirty-event oracle on card 62; the class is generic.)
    import copy as _copy
    _agent = state.pop("decision_agent", None)   # shared, never copied
    _card_turn = state.get("_card_turn")
    snapshot = _copy.deepcopy(state)
    if _agent is not None:
        state["decision_agent"] = _agent
    try:
        event_result = execute_event(state, card_id, shaded=shaded)
        # Follow-up choices are part of the same Event transaction (§5.4).
        free_actions = _resolve_free_actions(state, faction)
    except _EVENT_SAFE_ERRORS as exc:
        # Ineffective/non-applicable Event in this state (missing pieces, a
        # stub, or a choice not derivable here). Report, do not crash —
        # and restore the pre-Event state (which also restores
        # event_params/executing_faction to their pre-call values).
        state.clear()
        state.update(snapshot)
        if _card_turn is not None:
            state["_card_turn"] = _card_turn
        state["event_params"] = prev_params
        state["executing_faction"] = prev_faction
        if _agent is not None:
            state["decision_agent"] = _agent
        return {"executed": False, "command": _CMD_EVENT,
                "card_id": card_id, "shaded": shaded,
                "reason": f"event not applicable: {exc!r}"}
    state["event_params"] = prev_params
    state["executing_faction"] = prev_faction
    result = {"executed": True, "command": _CMD_EVENT,
              "card_id": card_id, "shaded": shaded,
              "event_result": event_result}
    if free_actions:
        result["free_actions"] = free_actions
    return result


@_diviciacus_command_scope
def _execute_seize(state, faction, bot_action):
    """Execute a Seize Command — §3.2.3, target priorities §8.8.5.

    The Roman bot supplies ``regions`` (all Seize regions, dispersal-capable
    first) and ``details['disperse_regions']`` (the subset where Dispersal
    should occur). In each dispersal region we Disperse the Subdued tribes
    the rules allow (`get_dispersible_tribes`, which already enforces Roman
    Control and the 4-marker cap); remaining regions still Forage.

    The accompanying Build Special Activity is executed by the orchestration
    layer (_execute_sa, reported under ``sa_execution``), not here.
    """
    details = bot_action.get("details") or {}
    regions = [r for r in (bot_action.get("regions") or []) if isinstance(r, str)]
    disperse_regions = {r for r in (details.get("disperse_regions") or [])
                        if isinstance(r, str)}

    per_region = []
    dispersed_total = 0
    forage_total = 0
    errors = []

    as_if_control = bool(details.get("as_if_control"))
    no_harassment = bool(details.get("no_harassment"))
    for region in regions:
        if region in disperse_regions:
            tribes = get_dispersible_tribes(state, region,
                                            as_if_control=as_if_control)
        else:
            tribes = []
        try:
            res = seize_in_region(state, region, tribes_to_disperse=tribes,
                                  as_if_control=as_if_control)
        except _EXEC_ERRORS as exc:
            errors.append({"region": region, "error": str(exc)})
            continue
        dispersed_total += len(res.get("tribes_dispersed", []))
        forage_total += res.get("forage_resources", 0)
        # Harassment against the seizing Romans — §3.2.3 / §8.4.2 (suppressed
        # when the card grants Seize "with no Harassment", e.g. A58).
        harass = None if no_harassment else _resolve_seize_harassment(state, region)
        if harass:
            res = dict(res)
            res["harassment"] = harass
        per_region.append(res)

    return {
        "executed": len(per_region) > 0,
        "command": _CMD_SEIZE,
        "regions_resolved": [r["region"] for r in per_region],
        "tribes_dispersed_total": dispersed_total,
        "forage_resources_total": forage_total,
        "errors": errors,
    }


@_diviciacus_command_scope
def _execute_raid(state, faction, bot_action):
    """Execute a Raid Command — §3.3.3.

    Bots emit ``details['raid_plan']`` as a flat list of per-flip entries
    ``{"region": R, "target": faction_or_None}`` (steal from ``target`` or,
    when None, gain 1 Resource). All four raiding bots (Arverni, Aedui,
    Belgae, German) share this shape. We group flips by region in order,
    cap at the rules' 2 flips per region (3 for Card 8's owner), translate each flip to a
    raid action, and call ``raid_in_region`` once per region.

    Any accompanying Special Activity (Devastate/Entreat/Intimidate) is
    executed by the orchestration layer (_execute_sa). A3.4.3's intrinsic
    free Intimidate resolves here using the Warbands that actually Raided.
    """
    details = bot_action.get("details") or {}
    raid_plan = details.get("raid_plan", []) or []

    # Preserve region order of first appearance.
    by_region = {}
    order = []
    for entry in raid_plan:
        region = entry.get("region")
        if region is None:
            continue
        if region not in by_region:
            by_region[region] = []
            order.append(region)
        if entry.get("target") is None:
            by_region[region].append({"type": "gain"})
        else:
            by_region[region].append(
                {"type": "steal", "target": entry["target"]})
        if "physical_owner" in entry:
            by_region[region][-1]["physical_owner"] = entry["physical_owner"]

    per_region = []
    gained_total = 0
    errors = []
    for region in order:
        actions = by_region[region][:max_raiders_per_region(state, faction)]
        if not actions:
            continue
        try:
            res = raid_in_region(state, region, faction, actions)
        except _EXEC_ERRORS as exc:
            errors.append({"region": region, "error": str(exc)})
            continue
        gained_total += res.get("resources_gained", 0)
        per_region.append(res)

    return {
        "executed": len(per_region) > 0,
        "command": _CMD_RAID,
        "regions_resolved": [r["region"] for r in per_region],
        "resources_gained_total": gained_total,
        "raids": per_region,
        "errors": errors,
    }


def _placement_error(command, error):
    return {'executed': False, 'command': command, 'placements': [],
            'errors': [{'error': str(error)}]}


def _atomic_placement_plan(state, execute):
    """Exact player counts/order cannot survive as a partially applied plan."""
    from copy import deepcopy
    saved = deepcopy({key: value for key, value in state.items() if key != 'decision_agent'})
    agent, had_agent = state.get('decision_agent'), 'decision_agent' in state
    card_turn = state.get('_card_turn')
    def restore():
        state.clear()
        state.update(saved)
        if had_agent:
            state['decision_agent'] = agent
        if card_turn is not None:
            state['_card_turn'] = card_turn
    try:
        result = execute()
    except BaseException:
        restore()
        raise
    if result.get('errors'):
        restore()
        result.update(executed=False, placements=[], rolled_back=True)
    return result


@_diviciacus_command_scope
def _execute_rally(state, faction, bot_action):
    """Resolve ordered human options or the unchanged legacy NP priority lists."""
    from fs_bot.commands.rally import rally_plan_steps
    plan = (bot_action.get('details') or {}).get('rally_plan') or {}
    try:
        steps = rally_plan_steps(plan)
    except _EXEC_ERRORS as exc:
        return _placement_error(_CMD_RALLY, exc)
    execute = lambda: _execute_rally_steps(state, faction, steps)
    if 'steps' in plan or any('count' in entry or 'placement_owners' in entry for entry in steps):
        return _atomic_placement_plan(state, execute)
    return execute()


def _execute_rally_steps(state, faction, steps):
    from fs_bot.commands.rally import validate_rally_option
    planned = {}
    for entry in steps:
        region, action = entry['region'], entry['action']
        try:
            validate_rally_option(state, region, faction, action, planned.get(region, set()))
        except _EXEC_ERRORS as exc:
            return _placement_error(_CMD_RALLY, exc)
        planned.setdefault(region, set()).add(action)
    placed, errors, selected = [], [], {}
    for entry in steps:
        region, action = entry['region'], entry['action']
        prior = selected.get(region, set())
        try:
            validate_rally_option(state, region, faction, action, prior)
            from fs_bot.engine.diviciacus import placement_owner_scope
            with placement_owner_scope(state, faction, region, entry.get('placement_owners')):
                rally_in_region(state, region, faction, action, tribe=entry.get('tribe'),
                    count=entry.get('count'), warband_mix=entry.get('warband_mix'),
                    include_home_bonus=True, include_bonuses=not prior, free=bool(prior))
            selected.setdefault(region, set()).add(action)
            record = {'region': region, 'action': action, 'tribe': entry.get('tribe')}
            if 'count' in entry:
                record['count'] = entry['count']
            placed.append(record)
        except _EXEC_ERRORS as exc:
            errors.append({'region': region, 'action': action, 'error': str(exc)})
    return {'executed': bool(placed), 'command': _CMD_RALLY,
            'placements': placed, 'errors': errors}


@_diviciacus_command_scope
def _execute_battle(state, faction, bot_action, *, _paid_regions=(),
                    _full_loss_warbands=0, _double_auxilia=False, _ambush_anywhere=False,
                    _battle_observer=None):
    """Execute a Battle Command — §3.2.4 / §3.3.4 / §3.4.4.

    The bot supplies ``details['battle_plan']`` as a list of per-region
    entries. Two shapes exist: most bots emit ``{"region", "target"}`` (a
    single defending faction), while the Roman bot emits
    ``{"region", "targets": [...]}`` (defenders ranked by priority); we
    Battle the top-ranked defender per region.

    Battle-modifying Special Activities are applied as parameters to
    ``resolve_battle``:
      - Ambush (§4.3.3/§4.5.3/A4.6.3): ``is_ambush=True`` where the bot's
        ``sa`` is Ambush and the region is in ``sa_regions`` (eligibility was
        already gated by the bot's _check_ambush).
      - Besiege (§4.2.3/A4.2.3, Roman): remove a Citadel (else Ally, else
        Settlement) before Losses, chosen via get_besiege_targets.

    Defender Retreat is left to auto-determination (no retreat); routing the
    defender bot's Retreat decision (§8.4.3) is a separate workstream. Other
    standalone SAs accompanying a Battle (Scout, Intimidate) are not executed
    here.
    """
    details = bot_action.get("details") or {}
    battle_plan = details.get("battle_plan", []) or []
    # Free-Battle events may forbid the defender's Retreat (§ card text).
    no_retreat = bool(details.get("no_retreat"))
    force_retreat = bool(details.get("force_retreat"))
    allied_factions = tuple(details.get("allied_factions") or ())
    warband_full_loss = bool(details.get("warband_full_loss"))

    # A31 German Phalanx vs one-shot Event battle benefits (BGG thread
    # 2079436: one-shot effects like a Germans-executed Sabis no-retreat
    # count as "Event effects"). Unshaded cancels benefits TO German
    # attackers (their event-granted no_retreat / warband_full_loss);
    # shaded cancels effects HARMING German defenders (a no_retreat
    # pinned on them) — handled per battle below.
    from fs_bot.rules_consts import GERMANS as _GE_A31
    if (faction == _GE_A31
            and state.get("event_modifiers", {}).get(
                "card_A31_cancel_german_benefits")):
        no_retreat = False
        warband_full_loss = False
    sa = bot_action.get("sa")
    # sa_regions are string Region names for Ambush/Besiege; other SAs
    # (e.g. Intimidate) carry dict plans we ignore here, so filter to strings.
    sa_regions = {r for r in (bot_action.get("sa_regions") or [])
                  if isinstance(r, str)}

    from fs_bot.cards.capabilities import (
        is_capability_active as _ica_b, get_capability_owner as _gco_b)
    from fs_bot.rules_consts import (EVENT_UNSHADED as _EU_B,
                                     EVENT_SHADED as _ES_B,
                                     ROMANS as _RO_B, AUXILIA as _AUX_B)
    _plan_regions = [e.get("region") for e in battle_plan
                     if e.get("region") is not None]

    # Card 13 unshaded (Balearic Slingers): on an ENEMY Battle Command the
    # Romans choose 1 Region — Auxilia there first inflict 1/2 Loss each on
    # the attacker, then the Battle resolves. NP choice: most Roman Auxilia.
    _c13_region = None
    if (faction != _RO_B and _ica_b(state, 13, _EU_B) and _plan_regions):
        _cands = [(count_pieces(state, r, _RO_B, _AUX_B), r)
                  for r in sorted(set(_plan_regions))]
        _cands = [c for c in _cands if c[0] > 0]
        if _cands:
            _c13_region = max(_cands)[1]

    # Card 59 unshaded (Germanic Horse): Romans may inflict 1 Loss per
    # Auxilia (not 1/2) in 1 Region per Battle Command — attack AND
    # counterattack (Tip). NP choice: the Region with most Roman Auxilia.
    if _ica_b(state, 59, _EU_B) and _plan_regions:
        _cands = [(count_pieces(state, r, _RO_B, _AUX_B), r)
                  for r in sorted(set(_plan_regions))]
        _cands = [c for c in _cands if c[0] > 0]
        if _cands:
            state.setdefault("event_modifiers", {})[
                "card59_unshaded_region"] = max(_cands)[1]

    # Card 59 shaded: the owning Gallic Faction doubles the enemy's Losses
    # in 1 Region per Battle Command — when attacking AND when defending
    # (card Tips) — unless blocked by Fort/Citadel per the Tips.
    if _ica_b(state, 59, _ES_B) and _plan_regions:
        _owner59 = _gco_b(state, 59)
        if _owner59 == faction:
            state.setdefault("event_modifiers", {})[
                "card59_shaded_region"] = sorted(set(_plan_regions))[0]
        elif _owner59 is not None:
            # The owner is DEFENDING in this command: their counterattack
            # doubles in 1 Region (NP choice: most owner pieces).
            _def_regions = sorted({
                e.get("region") for e in battle_plan
                if e.get("region") is not None
                and (e.get("target") == _owner59
                     or _owner59 in (e.get("targets") or []))})
            if _def_regions:
                _best = max(_def_regions,
                            key=lambda r: (count_pieces(state, r, _owner59),
                                           r))
                state.setdefault("event_modifiers", {})[
                    "card59_shaded_region"] = _best

    battles = []
    errors = []
    diviciacus_blocks = []
    for entry in battle_plan:
        region = entry.get("region")
        if region is None:
            continue
        # Single target, or Roman ranked targets list -> take the top.
        if "target" in entry and entry["target"] is not None:
            defender = entry["target"]
        else:
            targets = entry.get("targets") or []
            defender = targets[0] if targets else None
        if defender is None:
            continue
        from fs_bot.engine.diviciacus import defense_scope
        with defense_scope(state, region, faction, defender):
            # A Battle requires the defender to actually be present in the Region
            # (§3.x) — skip a no-target entry rather than resolving a no-op.
            if count_pieces(state, region, defender) <= 0:
                errors.append({"region": region, "defender": defender,
                               "error": "defender not present"})
                continue

            # §3.2.4 / §3.3.4 / A3.4.4: pay once for the selected Battle
            # Region, before any Battle effects or defender decisions. Event
            # actions waive the cost through their scoped §5.4 grant.
            from fs_bot.commands.common import battle_cost
            cost = 0 if region in _paid_regions else battle_cost(state, region, faction)
            if state["resources"].get(faction, 0) < cost:
                errors.append({"region": region, "defender": defender,
                               "error": f"Not enough Resources for Battle (need {cost})"})
                continue
            state["resources"][faction] = state["resources"].get(faction, 0) - cost

            is_ambush = sa == _SA_AMBUSH and region in sa_regions
            if is_ambush and not _ambush_anywhere:
                from fs_bot.commands.sa_ambush import validate_ambush_region
                from fs_bot.engine.diviciacus import ambush_scope
                with ambush_scope(state, faction, bot_action, region):
                    valid, reason = validate_ambush_region(
                        state, region, faction, defender,
                        allied_factions=allied_factions)
                if not valid:
                    # A1.4 explicitly lets a defender's new agreement block
                    # an otherwise planned Ambush. This is a legal reaction.
                    context = state.get("_diviciacus_force", {})
                    if (context.get("phase") == "defense" and
                            context.get("faction") == defender and
                            "Hidden pieces" in reason):
                        diviciacus_blocks.append(region)
                    else:
                        errors.append({"region": region, "sa": sa, "error": reason})
                    is_ambush = False

            besiege_target = None
            if sa == _SA_BESIEGE and region in sa_regions:
                from fs_bot.commands.sa_besiege import validate_besiege_region
                valid, reason = validate_besiege_region(state, region, defender)
                if valid:
                    options = get_besiege_targets(state, region, defender)
                    if options:
                        besiege_target = options[0]  # Citadel > Ally > Settlement
                else:
                    errors.append({"region": region, "sa": sa, "error": reason})

            # Card 13 unshaded pre-fire: Roman Auxilia inflict 1/2 each on the
            # attacker BEFORE the Battle resolves in the chosen Region.
            if _c13_region == region:
                from fs_bot.battle.losses import resolve_losses as _rl13
                _aux = count_pieces(state, region, _RO_B, _AUX_B)
                _pre = int(_aux * 0.5)
                if _pre > 0:
                    _rl13(state, region, faction, _pre)
                _c13_region = None  # once per Command

            # Card 27 shaded (Massed Gallic Archers): at the start of Battles
            # with 6+ Arverni Warbands, the other side first absorbs 1 extra
            # Loss (attacking or defending — card Tip).
            from fs_bot.rules_consts import (ARVERNI as _ARV_B, PROVINCIA,
                                             WARBAND as _WB_B)
            if _ica_b(state, 27, _ES_B):
                from fs_bot.battle.losses import resolve_losses as _rl27
                if (faction == _ARV_B
                        and count_pieces(state, region, _ARV_B, _WB_B) >= 6
                        and count_pieces(state, region, defender) > 0):
                    _rl27(state, region, defender, 1)
                elif (defender == _ARV_B
                        and count_pieces(state, region, _ARV_B, _WB_B) >= 6
                        and count_pieces(state, region, faction) > 0):
                    _rl27(state, region, faction, 1)
                # If the absorption emptied the defender, skip the battle.
                if count_pieces(state, region, defender) <= 0:
                    if _battle_observer is not None:
                        _battle_observer('before', state, region, defender, None)
                    battles.append({"region": region, "defender": defender,
                                    "is_ambush": is_ambush,
                                    "besiege": besiege_target,
                                    "result": {"card27_wiped": True}})
                    continue

            # A31 shaded: "Event effects harming Germans in Battle are
            # cancelled" — an event's no-retreat does not bind a German
            # defender (BGG thread 2079436 reading).
            _no_retreat_here = no_retreat
            if (no_retreat and defender == _GE_A31):
                from fs_bot.cards.capabilities import (
                    is_capability_active as _ica31s)
                from fs_bot.rules_consts import EVENT_SHADED as _ES31s
                if _ica31s(state, "A31", _ES31s):
                    _no_retreat_here = False

            if _battle_observer is not None:
                _battle_observer('before', state, region, defender, None)
            try:
                if _no_retreat_here:
                    retreat_decl, retreat_region = (False, None)
                elif force_retreat:
                    _d, _dest = _decide_defender_retreat(
                        state, region, faction, defender, is_ambush)
                    retreat_decl, retreat_region = (True, _dest)
                else:
                    retreat_decl, retreat_region = _decide_defender_retreat(
                        state, region, faction, defender, is_ambush)
                res = resolve_battle(
                    state, region, faction, defender,
                    is_ambush=is_ambush, besiege_target=besiege_target,
                    retreat_declaration=retreat_decl,
                    retreat_region=retreat_region,
                    allied_factions=allied_factions,
                    warband_full_loss=warband_full_loss,
                    full_loss_warbands=_full_loss_warbands,
                    double_auxilia=_double_auxilia,
                    ignore_fort=(state.get("event_modifiers", {}).get("card_21_no_fort", False)
                                 and faction == _ARV_B and region == PROVINCIA),
                )
            except _EXEC_ERRORS as exc:
                errors.append({"region": region, "defender": defender,
                               "error": str(exc)})
                continue
            if _battle_observer is not None:
                _battle_observer('after', state, region, defender, res)
            # Card 10 shaded (Ballistae): the owning Gallic Faction "after
            # Ambush may remove defending Fort or Citadel" — NP: always,
            # Citadel first (higher value; Q13 tribe sync applied).
            if (is_ambush and _ica_b(state, 10, _ES_B)
                    and _gco_b(state, 10) == faction):
                from fs_bot.rules_consts import (CITADEL as _CIT10,
                                                 FORT as _F10)
                from fs_bot.board.pieces import (
                    clear_allied_tribe as _cat10, remove_piece as _rp10)
                if count_pieces(state, region, defender, _CIT10) > 0:
                    _rp10(state, region, defender, _CIT10)
                    _cat10(state, region, defender, _CIT10)
                elif count_pieces(state, region, defender, _F10) > 0:
                    _rp10(state, region, defender, _F10)

            battles.append({"region": region, "defender": defender,
                            "is_ambush": is_ambush,
                            "besiege": besiege_target,
                            "result": res})

    # Clear the per-Command card 59 region flags.
    for _k59 in ("card59_unshaded_region", "card59_shaded_region"):
        state.get("event_modifiers", {}).pop(_k59, None)

    return {
        "executed": len(battles) > 0,
        "command": _CMD_BATTLE,
        "battles_resolved": [(b["region"], b["defender"]) for b in battles],
        "battle_sa_executed": any(b.get("is_ambush") or b.get("besiege") is not None
                                  for b in battles if not b.get("result", {}).get("card27_wiped")),
        "count": len(battles),
        "errors": errors,
        "ambush_blocked_by_diviciacus": diviciacus_blocks,
    }


@_diviciacus_command_scope
@preserve_supply_agreements
def _execute_recruit(state, faction, bot_action, *, _exact=False):
    from fs_bot.commands.rally import recruit_plan_entries
    try:
        plan = recruit_plan_entries((bot_action.get('details') or {}).get('recruit_plan') or [])
    except _EXEC_ERRORS as exc:
        return _placement_error(_CMD_RECRUIT, exc)
    exact = _exact or any('count' in entry or 'placement_owners' in entry for entry in plan)
    execute = lambda: _execute_recruit_entries(state, faction, bot_action, exact=exact)
    return _atomic_placement_plan(state, execute) if exact else execute()


def _execute_recruit_entries(state, faction, bot_action, *, exact=False):
    """Execute a Roman Recruit — §3.2.1 / §8.8.4.

    The Roman bot now emits ``details['recruit_plan']`` as an ordered list of
    ``{"region", "action", ["tribe"]}`` entries (all Allies able, then all
    Auxilia able, Supply-Line Regions first). Each entry calls
    ``recruit_in_region`` (which enforces eligibility, caps, and cost).
    Per-region errors are captured so the plan resolves as far as Resources
    allow. The accompanying Build SA is executed by the orchestration layer
    (_execute_sa) before this Recruit (§8.8.4).
    """
    details = bot_action.get("details") or {}
    plan = details.get("recruit_plan", []) or []

    placed = []
    errors = []
    superseded = []
    for entry in plan:
        with supply_query_scope(state):
            region = entry.get("region")
            action = entry.get("action")
            if region is None or action is None:
                continue
            tribe = entry.get("tribe")
            if not exact and action == "place_ally" and tribe is not None:
                # The Build SA resolves BEFORE this Recruit (§8.8.4 'Build
                # before Recruit') and may itself have allied the planned
                # tribe. Re-derive against the current board: keep the planned
                # tribe if still eligible, substitute another eligible Subdued
                # Tribe there, or drop the entry as superseded (not an error —
                # the piece the entry wanted is already on the map).
                from fs_bot.commands.rally import _find_subdued_tribe_for_ally
                eligible_now = _find_subdued_tribe_for_ally(state, region,
                                                            _ROMANS_F) or []
                if tribe not in eligible_now:
                    replacement = next(
                        (t for t in eligible_now
                         if not any(p.get("tribe") == t for p in placed)), None)
                    if replacement is None:
                        superseded.append({"region": region, "tribe": tribe})
                        continue
                    tribe = replacement
                # The Build SA (§8.8.4 'Build before Recruit') may have placed the
                # Allies this Recruit planned, emptying the shared Ally pool. "Place
                # all Allies ABLE" — once none are Available, skip the entry as
                # superseded rather than letting the executor refuse it.
                from fs_bot.board.pieces import get_available as _get_avail
                from fs_bot.rules_consts import ALLY as _ALLY_C
                if _get_avail(state, _ROMANS_F, _ALLY_C) < 1:
                    superseded.append({"region": region, "tribe": tribe})
                    continue
            # Budget pre-check — "Place all Allies/Auxilia ABLE": entries the
            # Romans can no longer afford (e.g. card 13 shaded removed the
            # Supply-Line discount mid-plan) are skipped as unaffordable, not
            # errors — the rule's own 'able' qualifier, not a refused proposal.
            from fs_bot.commands.rally import recruit_cost as _rcost
            if not exact and state["resources"].get(_ROMANS_F, 0) < _rcost(state, region):
                superseded.append({"region": region, "action": action,
                                   "reason": "unaffordable"})
                continue
            # Presence pre-check for Auxilia — §3.2.1 requires a Roman
            # Leader, Ally, or Fort there (or card 55's Belgica carve-out);
            # the Build SA resolves first and the plan may be stale.
            if not exact and action == "place_auxilia":
                from fs_bot.commands.rally import can_recruit_auxilia
                if not can_recruit_auxilia(state, region):
                    superseded.append({"region": region, "action": action,
                                       "reason": "no Leader/Ally/Fort"})
                    continue
            try:
                from fs_bot.engine.diviciacus import placement_owner_scope
                with placement_owner_scope(state, faction, region, entry.get('placement_owners')):
                    res = recruit_in_region(state, region, action, tribe=tribe,
                                            count=entry.get('count'))
                placed.append({"region": region, "action": action,
                               "tribe": tribe})
            except _EXEC_ERRORS as exc:
                errors.append({"region": region, "action": action,
                               "error": str(exc)})

    result = {
        "executed": len(placed) > 0,
        "command": _CMD_RECRUIT,
        "placements": placed,
        "errors": errors,
    }
    if superseded:
        result["superseded_by_build"] = superseded
    return result


def _mobile_march_group(state, faction, region):
    """Build a march group dict of ALL mobile pieces a faction has in region.

    Mobile = Leader + Legions + Auxilia + Warbands (totals across Hidden /
    Revealed / Scouted). This matches the threat-March instruction to "March
    all mobile Forces out of" a Region.
    """
    from fs_bot.rules_consts import LEADER, LEGION, AUXILIA, WARBAND
    group = {
        LEADER: get_leader_in_region(state, region, faction),
        LEGION: count_pieces(state, region, faction, LEGION),
        AUXILIA: count_pieces(state, region, faction, AUXILIA),
        WARBAND: count_pieces(state, region, faction, WARBAND),
    }
    return group


def _group_has_pieces(group):
    from fs_bot.rules_consts import LEADER, LEGION, AUXILIA, WARBAND
    return (group.get(LEADER) is not None
            or any(group.get(piece, 0) > 0 for piece in (LEGION, AUXILIA, WARBAND)))


def _collect_march_moves(state, faction, bot_action):
    """Normalize threat and expansion plans to groups and adjacent routes."""
    details = bot_action.get("details") or {}
    plan = details.get("march_plan") or details
    if "explicit_moves" in plan:
        return list(plan["explicit_moves"]), []
    origins, destinations = plan.get("origins"), plan.get("destinations")
    if not (isinstance(origins, list) and isinstance(destinations, list)
            and origins and destinations):
        moves = plan_expand_march_moves(state, faction, plan)
        if plan.get("allowed_origins") is not None:
            moves = [m for m in moves if m["origin"] in plan["allowed_origins"]]
        return moves, []

    destinations = [d[0] if isinstance(d, (list, tuple)) else d
                    for d in destinations]
    origins = [o[0] if isinstance(o, (list, tuple)) else o for o in origins]
    dest_pool = [d for d in destinations if d not in set(origins)]
    playable = set(get_playable_regions_for_state(state, faction))
    routes, groups = plan.get("routes") or {}, plan.get("groups") or {}
    max_steps = plan.get("max_steps")
    from fs_bot.commands.march import _max_steps_for_group
    from fs_bot.rules_consts import LEADER
    moves, deferred = [], []
    for origin in dict.fromkeys(origins):
        if not _group_has_pieces(_mobile_march_group(state, faction, origin)):
            continue
        available = _mobile_march_group(state, faction, origin)
        cap = groups.get(origin)
        if cap is not None:
            available = {pt: (value if cap.get(pt) else None) if pt == LEADER
                         else min(value or 0, int(cap.get(pt, 0) or 0))
                         for pt, value in available.items()}
        allowance = _max_steps_for_group(state, origin, faction, available)
        if max_steps is not None:
            allowance = min(allowance, max_steps)
        path = routes.get(origin)
        if not path:
            best = None
            for dest in dest_pool:
                route = _bfs_march_path(origin, dest, playable)
                if not route or len(route) > allowance:
                    continue
                if (best is None or len(route) < len(best[1]) or
                        (len(route) == len(best[1]) and
                         random_select(state, [best[0], dest]) == dest)):
                    best = (dest, route)
            path = best[1] if best else None
        if not path:
            deferred.append(origin)
            continue
        moves.append({"origin": origin, "path": path,
                      "group": groups.get(origin)})
    for extra in plan.get("extra_groups") or []:
        moves.append({"origin": extra.get("origin"),
                      "path": extra.get("route") or [],
                      "group": extra.get("group"), "extra_group": True})
    return moves, deferred


def _select_affordable_march_moves(state, faction, moves, *, free=False):
    """Select origins in plan priority order without moving or spending."""
    from fs_bot.commands.march import march_cost
    from fs_bot.commands.march import _max_steps_for_group, _validate_group_in_region
    from fs_bot.map.map_data import get_adjacency_type
    from fs_bot.rules_consts import LEADER
    playable = set(get_playable_regions_for_state(state, faction))
    selected, costs, deferred, errors = [], {}, [], []
    budget = state["resources"].get(faction, 0)
    for move in moves:
        origin, path = move.get("origin"), move.get("path") or []
        if (origin not in playable or not path or
                any(dest not in playable or get_adjacency_type(src, dest) is None
                    for src, dest in zip([origin] + path, path))):
            errors.append({"origin": origin, "error": "invalid March route"})
            continue
        available = _mobile_march_group(state, faction, origin)
        cap = move.get("group")
        if cap is not None:
            available = {pt: (value if cap.get(pt) else None) if pt == LEADER
                         else min(value or 0, int(cap.get(pt, 0) or 0))
                         for pt, value in available.items()}
            if "german_warbands" in cap:
                available["german_warbands"] = cap["german_warbands"]
        if len(path) > _max_steps_for_group(state, origin, faction, available):
            errors.append({"origin": origin, "error": "March route exceeds this group's movement allowance"})
            continue
        try:
            _validate_group_in_region(state, origin, faction, available)
        except _EXEC_ERRORS as exc:
            errors.append({"origin": origin, "error": str(exc)})
            continue
        if not _group_has_pieces(available):
            continue
        if origin not in costs:
            cost = 0 if free else march_cost(state, origin, faction)
            if cost > budget:
                deferred.append(origin)
                continue
            costs[origin] = cost
            budget -= cost
        selected.append(move)
    return selected, costs, deferred, errors


def march_plan_has_effect(state, faction, plan):
    """Check the flowchart's IF NONE without moving pieces or advancing RNG.

    Origin billing is shared with execution; resource-short bots must take
    their specified fallback rather than spend a turn on an empty March.
    Event-granted free Commands ignore the Resource budget (§3.1.2).
    """
    from copy import deepcopy
    from fs_bot.bots.bot_common import is_frost_active
    from fs_bot.commands.common import is_free_action
    free = state.get("_planning_free_command", False) or is_free_action(state, faction)
    if not free and not state.get("_planning_event_command") and is_frost_active(state):
        return False
    sim = deepcopy({k: v for k, v in state.items() if k != "decision_agent"})
    moves, _ = _collect_march_moves(sim, faction, {"details": plan})
    scope = state.get("_command_region_scope")
    if scope is not None:
        moves = [m for m in moves if m.get("origin") in scope]
    selected, _, _, _ = _select_affordable_march_moves(sim, faction, moves, free=free)
    return bool(selected)


@_diviciacus_command_scope
def _execute_march(state, faction, bot_action, *, free=False, before_move=None,
                   moving_only=False):
    """Pay once per selected origin; movement-only helpers remain free."""
    moves, deferred = _collect_march_moves(state, faction, bot_action)
    result = _execute_march_moves(state, faction, moves, free=free,
                                  before_move=before_move, moving_only=moving_only)
    result["deferred_origins"] = deferred + result["deferred_origins"]
    return result


def _execute_march_moves(state, faction, moves, *, free=False, before_move=None,
                         moving_only=False):
    """Bill origins once, before moving; a threat-March SA runs after payment.

    Only affordable origins with an actual mobile group and adjacent route
    are selected. Multiple groups/steps never incur additional origin fees.
    Free Event Commands and base-game German movement remain free.
    """
    selected, costs, deferred, errors = _select_affordable_march_moves(
        state, faction, moves, free=free)
    total_cost = sum(costs.values())
    if total_cost:
        state["resources"][faction] -= total_cost
    sa_result = before_move() if selected and before_move is not None else None
    marched = []
    flipped_origins = set()
    for move in selected:
        origin = move["origin"]
        try:
            final = _march_with_harassment(state, faction, origin, move["path"],
                                           group_cap=move.get("group"),
                                           flipped_origins=flipped_origins,
                                           moving_only=moving_only)
            if final != origin:
                entry = {k: v for k, v in move.items() if k not in ("path", "group")}
                entry["final_region"] = final
                marched.append(entry)
        except _EXEC_ERRORS as exc:
            errors.append({"origin": origin, "error": str(exc)})
    result = {"executed": bool(marched), "command": _CMD_MARCH,
              "marches": marched, "deferred_origins": list(dict.fromkeys(deferred)),
              "errors": errors, "total_cost": total_cost, "origin_costs": costs}
    if not marched:
        result["reason"] = "nothing marchable within available Resources or legal routes"
    if sa_result is not None:
        result["sa_execution"] = sa_result
        result["sa_timing"] = "during-before-movement"
    return result


def _execute_arverni_threat_march(state, faction, bot_action):
    """§8.7.1: pay March, try Devastate/Entreat, move; otherwise try SA after."""
    from fs_bot.rules_consts import BRITANNIA
    details = bot_action.get("details") or {}
    plan = details.get("march_plan") or details
    crosses_britannia = (BRITANNIA in (plan.get("origins") or []) or
                         BRITANNIA in (plan.get("destinations") or []))
    callback = (None if crosses_britannia else
                lambda: _execute_arverni_live_sa(state, faction, bot_action))
    result = _execute_march(state, faction, bot_action, before_move=callback)
    if (callback is not None and result["executed"] and
            not (result.get("sa_execution") or {}).get("executed")):
        result["sa_execution"] = callback()
        result["sa_timing"] = "after"
    return result


def _bfs_march_path(origin, dest, playable):
    """Shortest adjacency path origin -> dest over playable Regions.

    Returns the list of Regions to move into (excluding origin), or None if
    unreachable. Used to route a March to a planned but non-adjacent
    destination (the destination is the bot's choice; only the path is
    derived).
    """
    from collections import deque
    from fs_bot.map.map_data import get_adjacent
    if origin == dest:
        return []
    seen = {origin}
    q = deque([(origin, [])])
    while q:
        cur, path = q.popleft()
        for nb in sorted(get_adjacent(cur)):
            if nb in seen or nb not in playable:
                continue
            npath = path + [nb]
            if nb == dest:
                return npath
            seen.add(nb)
            q.append((nb, npath))
    return None


def _flip_selected_march_group(state, faction, origin, group):
    """Card70 hides only its moving cohort, retaining physical loan owners."""
    from fs_bot import rules_consts as rc
    from fs_bot.board.pieces import count_pieces_by_state, flip_piece
    from fs_bot.engine.march_choices import choose_visibility, select_origin_visibility
    select_origin_visibility(state, faction, origin, group)
    owners = group.get("_diviciacus_owners")
    physical_owners = owners is not None
    piece = rc.AUXILIA if faction == rc.ROMANS else rc.WARBAND
    if owners is None:
        selected = group.get("_march_visibility", {}).get(piece)
        if selected is None:
            available = {ps: count_pieces_by_state(state, origin, faction, piece, ps)
                         for ps in (rc.HIDDEN, rc.REVEALED, rc.SCOUTED)}
            selected = choose_visibility(state, faction, origin, piece, group.get(piece, 0),
                                         available, phase="formation")
        owners = {faction: selected}
    combined = {}
    for owner, selected in owners.items():
        updated = {}
        for visibility, count in list(selected.items()):
            target = {rc.REVEALED: rc.HIDDEN, rc.SCOUTED: rc.REVEALED}.get(visibility, visibility)
            if count and target != visibility:
                flip_piece(state, origin, faction, piece, count,
                           from_state=visibility, to_state=target,
                           **({"physical_owner": owner} if physical_owners else {}))
            updated[target] = updated.get(target, 0) + count
            combined[target] = combined.get(target, 0) + count
        selected.clear()
        selected.update(updated)
    group.setdefault("_march_visibility", {})[piece] = combined


def _march_with_harassment(state, faction, origin, path, group_cap=None, *,
                           harassers_by_region=None, dropoffs_by_region=None,
                           flipped_origins=None, moving_only=False):
    """March a faction's mobile group origin -> ... -> path[-1], one step
    at a time, resolving Harassment (§3.2.2 / §8.4.2) in each Region the group
    enters and then leaves. Returns the final Region reached.

    ``group_cap`` (optional, {piece_type: count} with LEADER truthy/falsy)
    marches a SUBSET group selected at the origin — §3.2.2 lets a player
    March "a group" of their choosing; bots march full groups by their
    instructions. Found needed in live human-seat play: without it a
    human could never split a stack.
    """
    # §3.2.2: the marching group is SELECTED AT THE ORIGIN and carried through
    # the whole path. It must NOT be recomputed from each intermediate Region:
    # doing so absorbed that Region's RESIDENT forces into the march (and tried
    # to move resident Revealed Warbands as Hidden, e.g. "Only 1 Hidden Warband
    # in <R>, need 15"), and applied Harassment to residents too. Pieces do not
    # join a March mid-route; Harassment only hits the marching group.
    group = _mobile_march_group(state, faction, origin)
    if group_cap is not None:
        from fs_bot.rules_consts import LEADER as _LDR
        capped = {}
        for pt, v in group.items():
            if pt == _LDR:
                capped[pt] = v if group_cap.get(_LDR) else None
            else:
                capped[pt] = min(int(group_cap.get(pt, 0) or 0), v or 0)
        group = capped
        if "german_warbands" in group_cap:
            group["german_warbands"] = group_cap["german_warbands"]
    from fs_bot.commands.march import _max_steps_for_group, _validate_group_in_region
    if len(path) > _max_steps_for_group(state, origin, faction, group):
        raise CommandError("March route exceeds this group's movement allowance")
    _validate_group_in_region(state, origin, faction, group)
    # Validate the whole group's route before changing any visibility state.
    # §3.2.2/3.3.2 flip once per selected origin, even when it forms multiple
    # groups. Re-flipping would Hide the remaining de-Scouted Warbands.
    if moving_only:
        _flip_selected_march_group(state, faction, origin, group)
    else:
        if flipped_origins is None or origin not in flipped_origins:
            _flip_origin_pieces(state, origin, faction)
            if flipped_origins is not None:
                flipped_origins.add(origin)
        if path:
            from fs_bot.engine.march_choices import select_origin_visibility
            select_origin_visibility(state, faction, origin, group)
    current = origin
    for i, nxt in enumerate(path):
        if not _group_has_pieces(group):
            break
        # The extra hop belongs only to pieces still moving with Caesar or
        # Vercingetorix (§3.2.2/§3.3.2). A Harassment casualty can remove that
        # Leader after the route was initially validated.
        if i >= _max_steps_for_group(state, current, faction, group):
            break
        res = march_group(state, faction, current, [nxt], group)
        current = res.get("final_region", nxt)
        if current != nxt or res.get("stopped_reason"):
            break  # stop in the crossing destination; do not continue/harass
        # Intermediate Region (entered then about to be left) -> Harassment
        # against the carried group only; survivors continue.
        if (i < len(path) - 1
                and i + 1 < _max_steps_for_group(state, current, faction, group)):
            # Event-owned plans may leave part of this group in a transit
            # Region (3.2.2). Only the continuing pieces suffer Harassment.
            for piece, count in (dropoffs_by_region or {}).get(current, {}).items():
                from fs_bot.engine.march_choices import drop_visibility
                drop_visibility(state, faction, current, group, piece, count)
            harassers = (harassers_by_region[current]
                         if harassers_by_region is not None and current in harassers_by_region
                         else _iter_harassers(state, current, faction, group,
                                              stop_when_empty=True))
            if harassers:
                from fs_bot.commands.march import resolve_harassment
                # This mechanic mutates the carried group as it removes
                # casualties. Reapplying its report would subtract twice
                # and would drop a Leader even after a successful save.
                resolve_harassment(state, current, faction, group,
                                   harassing_factions=harassers)
    return current



def _sa_detail(bot_action, key):
    """Fetch an SA plan by key from an action's details, tolerating both
    layouts bots use: merged at the top level (Belgae) OR nested under
    details["sa_details"] (Aedui, German battle).
    """
    d = bot_action.get("details") or {}
    if d.get(key) is not None:
        return d.get(key)
    return (d.get("sa_details") or {}).get(key)


@_diviciacus_command_scope(phase="special_ability")
def _execute_sa(state, faction, bot_action):
    """Execute a standalone Special Activity accompanying a Command.

    Returns a result dict, or None when there is no standalone SA to run
    (No SA, or a battle-modifying SA already handled in _execute_battle).

    All standalone SAs are wired: Trade, Settle, Devastate, Intimidate,
    Suborn, Build, Scout, Entreat, Rampage, and Enlist execute from the
    bot/human plan (battle-modifying SAs — Ambush, Besiege — are applied
    inside _execute_battle). An unrecognized SA label is reported, not
    guessed.
    """
    sa = bot_action.get("sa")
    if not sa or sa == SA_ACTION_NONE_LABEL or sa in _BATTLE_MODIFYING_SAS:
        return None

    if (faction == _AEDUI_F and sa in (_SA_TRADE, _SA_SUBORN)
            and faction in state.get("non_player_factions", set())):
        # §8.6.3 evaluates Trade "at that moment" — i.e. when the Special
        # Ability resolves, AFTER the Command has spent/earned Resources —
        # and falls through Trade -> Suborn -> no SA. Re-derive the whole
        # choice now against the current board (the decision-time pick used
        # pre-Command Resources; e.g. a Rally can spend the Aedui below the
        # Suborn price between planning and resolution). Humans keep their
        # declared SA.
        from fs_bot.bots.aedui_bot import (_determine_trade_sa,
                                           SA_ACTION_NONE as _A_NONE,
                                           SA_ACTION_TRADE as _A_TRADE)
        battled = bot_action.get("command") == _CMD_BATTLE
        new_sa, new_regions, new_details = _determine_trade_sa(
            state, state["scenario"], battled=battled)
        if new_sa == _A_NONE:
            return {"executed": False, "sa": sa,
                    "declined_no_effect": True,
                    "reason": "no Trade or Suborn at SA time (§8.6.3 "
                              "'at that moment'; if none, no SA)"}
        if new_sa == _A_TRADE:
            result = _execute_trade(state, faction)
            result.setdefault("rederived_at_sa_time", True)
            return result
        rederived = dict(bot_action)
        rederived["sa"] = new_sa
        rederived["sa_regions"] = new_regions
        d = dict(bot_action.get("details") or {})
        d.update(new_details or {})
        rederived["details"] = d
        result = _execute_suborn(state, faction, rederived)
        result.setdefault("rederived_at_sa_time", True)
        return result

    if sa == _SA_TRADE:
        return _execute_trade(state, faction)
    if (sa in (_SA_DEVASTATE, _SA_ENTREAT)
            and faction == _ARVERNI_F
            and faction in state.get("non_player_factions", set())):
        # Re-evaluate the flowchart at its prescribed SA timing, not against
        # a board/resources snapshot predating the accompanying Command.
        return _execute_arverni_live_sa(state, faction, bot_action)
    if sa == _SA_DEVASTATE:
        return _execute_devastate(state, faction, bot_action)
    if (sa in (_SA_INTIMIDATE, _SA_SETTLE)
            and faction == _GERMANS_F
            and bot_action.get("command") in (_CMD_MARCH, _CMD_RAID)
            and faction in state.get("non_player_factions", set())):
        # A8.7.1: the Germans Intimidate "after Raid or March" — i.e. when the
        # SA resolves, AFTER the Command has moved/revealed pieces. The plan
        # picked at decision time reads the pre-Command board, so a March that
        # empties its origin of Hidden Warbands leaves a stale Intimidate the
        # executor refuses ("Only 0 Hidden Germanic Warbands in <R>"). Re-derive
        # the Intimidate-or-Settle choice against the current board, exactly as
        # the Aedui Trade/Suborn path re-derives "at that moment". Humans keep
        # their declared SA.
        from fs_bot.bots.german_bot import (
            _determine_intimidate_or_settle_after_march as _g_march_sa,
            _determine_intimidate_after_raid as _g_raid_sa,
            SA_ACTION_INTIMIDATE as _G_INTIM,
            SA_ACTION_SETTLE as _G_SETTLE)
        details = bot_action.get("details") or {}
        if bot_action.get("command") == _CMD_MARCH:
            new_sa, new_regions, new_details = _g_march_sa(
                state, details.get("march_plan") or {})
        else:
            new_sa, new_regions, new_details = _g_raid_sa(
                state, details.get("raid_plan") or [], after_raid=True)
        rederived = dict(bot_action)
        d = dict(details)
        d.update(new_details or {})
        rederived["details"] = d
        rederived["sa_regions"] = new_regions  # _execute_settle reads this
        if new_sa == _G_INTIM:
            result = _execute_intimidate(state, faction, rederived)
            result.setdefault("rederived_at_sa_time", True)
            return result
        if new_sa == _G_SETTLE:
            result = _execute_settle(state, faction, rederived)
            result.setdefault("rederived_at_sa_time", True)
            return result
        return {"executed": False, "sa": _SA_INTIMIDATE,
                "declined_no_effect": True, "rederived_at_sa_time": True,
                "reason": "no Intimidate or Settle at SA time (A8.7.1 "
                          "evaluated after the Command; if none, no SA)"}
    if sa == _SA_SETTLE:
        return _execute_settle(state, faction, bot_action)
    if sa == _SA_INTIMIDATE:
        return _execute_intimidate(state, faction, bot_action)
    if sa == _SA_SUBORN:
        return _execute_suborn(state, faction, bot_action)
    if sa == _SA_BUILD:
        result = _execute_build(state, faction, bot_action)
        if (faction == _ROMANS_F and not result.get("actions")
                and faction in state.get("non_player_factions", set())
                and _sa_detail(bot_action, "build_plan") is None):
            # R_BUILD "If no Build: R_SCOUT" — Scout after Command instead
            # (roman_bot_flowchart §8.8.1). Recompute against the current
            # (post-Command) board, exactly like the Build it replaces.
            scout = _execute_scout(state, faction, bot_action)
            if scout.get("executed"):
                scout = dict(scout)
                scout["fell_through_from"] = _SA_BUILD
                return scout
        return result
    if (sa == _SA_RAMPAGE
            and faction == _BELGAE_F
            and bot_action.get("command") in (_CMD_RALLY, _CMD_RAID)
            and faction in state.get("non_player_factions", set())):
        # §8.5.1: Rampage "after Rally or Raid" resolves AFTER the Command has
        # moved/revealed pieces (a Raid Reveals the very Belgic Warbands a
        # Rampage would flip). Re-derive against the current board, exactly as
        # the German Intimidate / Aedui Trade-Suborn paths do; if none, no SA.
        from fs_bot.bots.belgae_bot import _check_rampage
        new_plan = _check_rampage(state, state["scenario"],
                                  before_battle=False)
        if not new_plan:
            return {"executed": False, "sa": _SA_RAMPAGE,
                    "declined_no_effect": True, "rederived_at_sa_time": True,
                    "reason": "no legal Rampage at SA time (§8.5.1 'if "
                              "none')"}
        rederived = dict(bot_action)
        rederived["sa_regions"] = new_plan
        result = _execute_rampage(state, faction, rederived)
        result.setdefault("rederived_at_sa_time", True)
        if not result.get("executed") and not result.get("errors"):
            # Re-derived plan still removed/Retreated nothing -> "if none".
            result.setdefault("declined_no_effect", True)
        return result
    if sa == _SA_RAMPAGE:
        result = _execute_rampage(state, faction, bot_action)
        if not result.get("executed") and not result.get("errors"):
            result.setdefault("declined_no_effect", True)
        return result
    if sa == _SA_ENTREAT:
        return _execute_entreat(state, faction, bot_action)
    if sa == _SA_SCOUT:
        return _execute_scout(state, faction, bot_action)
    if sa == _SA_ENLIST:
        if faction in state.get("non_player_factions", set()):
            # The entire free sub-Command is chosen AFTER the main Command
            # (§8.5.1); validating an old selection after moving the Leader
            # wastes the turn and can miss a different legal free Command.
            from fs_bot.bots.belgae_bot import _check_enlist_after_command
            fresh = _check_enlist_after_command(state, state["scenario"])
            if fresh is None:
                return {"executed": False, "sa": sa, "declined_no_effect": True,
                        "rederived_at_sa_time": True, "reason": "no legal Enlist (if none)"}
            rederived = dict(bot_action)
            rederived["details"] = dict(bot_action.get("details") or {})
            rederived["details"]["enlist"] = fresh
            rederived["sa_regions"] = fresh.get("regions", [])
            result = _execute_enlist(state, faction, rederived)
            result["rederived_at_sa_time"] = True
            return result
        return _execute_enlist(state, faction, bot_action)

    return {"executed": False, "sa": sa,
            "reason": f"unrecognized Special Activity label: {sa!r}"}


def _execute_arverni_paid_battle(state, faction, bot_action):
    """§8.7.1: pay selected Battles before Devastate/Entreat, then resolve.

    Devastation placed by this SA cannot retrospectively double the selected
    Battle price, and Entreat can spend only the Resources remaining after
    all Battle Regions have been paid. The private prepaid set never grants
    an SA a cost waiver and cannot be supplied in a player action.
    """
    from fs_bot.commands.common import battle_cost
    from fs_bot.bots.bot_common import affordable_battle_plan
    details = dict(bot_action.get("details") or {})
    plan = affordable_battle_plan(state, faction, details.get("battle_plan") or [])
    costs = {entry["region"]: battle_cost(state, entry["region"], faction)
             for entry in plan}
    state["resources"][faction] -= sum(costs.values())
    details["battle_plan"] = plan
    action = dict(bot_action, details=details)
    sa = action.get("sa")
    before = _sa_runs_before_command(_CMD_BATTLE, sa)
    sa_result = _execute_sa(state, faction, action) if before and plan else None
    result = _execute_battle(state, faction, action, _paid_regions=costs)
    if not before and _command_executed(result):
        sa_result = _execute_sa(state, faction, action)
    if sa_result is not None:
        result["sa_execution"] = sa_result
        result["sa_timing"] = "before" if before else "after"
    result["total_cost"] = sum(costs.values())
    result["region_costs"] = costs
    return result


def _execute_arverni_live_sa(state, faction, bot_action):
    """§8.7.1 Devastate -> Entreat -> no SA, evaluated on the live board."""
    from fs_bot.bots.arverni_bot import _check_devastate, _check_entreat
    fresh = dict(bot_action)
    regions = _check_devastate(state, state["scenario"])
    if regions:
        fresh["sa_regions"] = regions
        result = _execute_devastate(state, faction, fresh)
    else:
        plan = _check_entreat(state, state["scenario"])
        if not plan:
            return {"executed": False, "sa": bot_action.get("sa"),
                    "declined_no_effect": True, "rederived_at_sa_time": True,
                    "reason": "no legal Devastate or Entreat at SA time (if none)"}
        fresh["sa_regions"] = plan
        # Remove stale nested plans that would override the new candidates.
        fresh["details"] = dict(bot_action.get("details") or {})
        fresh["details"].pop("entreat_plan", None)
        result = _execute_entreat(state, faction, fresh)
    result["rederived_at_sa_time"] = True
    return result


def _trade_roman_agreement(state):
    """Resolve the Roman Trade-agreement declaration (§4.4.1) at SA time.

    §4.4.1: the Romans declare agreement when the Trade resolves (they
    declare "regardless" of Control). NP Romans always agree (§8.6.3). A
    player Rome decides live: consult the decision-agent AGREEMENT hook
    (same channel _region_allows_supply_line uses for Supply Lines); if
    there is no agent or it defers, apply the alliance default — agree.
    See QUESTIONS.md (Aedui Trade — Roman agreement).
    """
    if _ROMANS_F in state.get("non_player_factions", set()):
        return True
    from fs_bot.engine.agent import consult_agent, AGREEMENT
    from fs_bot.rules_consts import AEDUI as _AED
    resp = consult_agent(state, _ROMANS_F, {
        "kind": AGREEMENT, "request_type": "trade_roman_agreement",
        "requesting_faction": _AED, "context": {}})
    if resp is not None:
        return bool(resp)
    return True


def maybe_np_aedui_subsidy(state):
    """§8.6.6: Non-player Aedui transfer 10 Resources to the Romans at
    each instant Roman Resources drop below 2 while the Aedui hold more
    than 20 (player-Roman victory-score gates per the §8.6.6 NOTE, applied
    in node_a_agreements). Called after every executed SoP action and
    after the Winter Quarters/Harvest phases — the documented
    approximation of "at each instant".

    Returns the transfer result dict, or None when no transfer fires.
    """
    from fs_bot.rules_consts import AEDUI as _AED
    if _AED not in state.get("non_player_factions", set()):
        return None
    if state["resources"].get(_ROMANS_F, 0) >= 2:
        return None
    if state["resources"].get(_AED, 0) <= 20:
        return None
    from fs_bot.bots.aedui_bot import node_a_agreements
    if not node_a_agreements(state, _ROMANS_F, "resources"):
        return None
    from fs_bot.commands.transfer import transfer_resources
    try:
        return transfer_resources(state, _AED, _ROMANS_F, 10)
    except Exception:
        return None    # e.g. card 38 shaded bans the transfer


def _execute_trade(state, faction, *, allowed_regions=None):
    """Aedui Trade (§4.4.2) — yields Resources; no targets."""
    scope = state.get("_command_region_scope")
    if scope is not None:
        allowed_regions = set(scope) if allowed_regions is None else set(scope) & set(allowed_regions)
    try:
        res = _sa_trade(state,
                        roman_agreed=_trade_roman_agreement(state),
                        allowed_regions=allowed_regions)
    except _EXEC_ERRORS as exc:
        return {"executed": False, "sa": _SA_TRADE, "error": str(exc)}
    return {"executed": True, "sa": _SA_TRADE, "result": res}


def _execute_settle(state, faction, bot_action):
    """German Settle (A4.6.1) — place a Settlement in each sa_region."""
    regions = [r for r in (bot_action.get("sa_regions") or [])
               if isinstance(r, str)]
    placed, errors = [], []
    for region in regions:
        try:
            from fs_bot.commands.sa_settle import validate_settle_region
            valid, reason = validate_settle_region(state, region)
            if not valid:
                raise CommandError(reason)
            _sa_settle(state, region)
            placed.append(region)
        except _EXEC_ERRORS as exc:
            errors.append({"region": region, "error": str(exc)})
    return {"executed": len(placed) > 0, "sa": _SA_SETTLE,
            "regions": placed, "errors": errors}


def _execute_devastate(state, faction, bot_action):
    """Arverni/Aedui Devastate (§4.3.1) — Devastate each sa_region."""
    regions = [r for r in (bot_action.get("sa_regions") or [])
               if isinstance(r, str)]
    done, errors = [], []
    for region in regions:
        try:
            from fs_bot.commands.sa_devastate import validate_devastate_region
            valid, reason = validate_devastate_region(state, region)
            if not valid:
                raise CommandError(reason)
            _sa_devastate(state, region)
            done.append(region)
        except _EXEC_ERRORS as exc:
            errors.append({"region": region, "error": str(exc)})
    return {"executed": len(done) > 0, "sa": _SA_DEVASTATE,
            "regions": done, "errors": errors}


def _execute_intimidate(state, faction, bot_action, *, ignore_selection=False,
                        raid_credits=None):
    """One faction and 1–2 Warbands per Region/application (A4.6.2).

    A45's trusted grant waives selection. Successful Raid execution may
    supply already-Revealed Warband credits for its separate free Intimidate.
    Neither exception is accepted from the action's own fields.
    """
    from fs_bot.rules_consts import GERMANS
    from fs_bot.commands.sa_intimidate import validate_intimidate_region
    if faction != GERMANS:
        return {"executed": False, "sa": _SA_INTIMIDATE,
                "errors": ["Only Germans may Intimidate"]}
    plan = _sa_detail(bot_action, "intimidate_plan") or []
    credits = dict(raid_credits or {})
    groups = {}
    for entry in plan:
        region = entry.get("region")
        if region is not None:
            # A free Raid use and a regular SA are distinct applications;
            # absent trusted Raid credit, free=True is just a normal attempt.
            free = bool(entry.get("free") and region in credits)
            groups.setdefault((region, free), []).append(entry)
    done, errors = [], []
    for (region, free), entries in groups.items():
        try:
            targets = {e.get("target_faction") for e in entries}
            if len(targets) != 1:
                raise CommandError("Intimidate targets only one Faction per Region")
            target = next(iter(targets))
            removals = [(e.get("target_piece"), e.get("target_state"))
                        for e in entries if e.get("target_piece") is not None]
            count = len(removals) or 1
            if count > 2 or len(entries) > 2:
                raise CommandError("Intimidate uses at most two Warbands per Region")
            if not ignore_selection:
                valid, reason = validate_intimidate_region(state, region)
                if not valid:
                    raise CommandError(reason)
            credit = min(count, credits.get(region, 0)) if free else 0
            if free and credit < count:
                raise CommandError("Intimidate exceeds the Warbands that actually Raided")
            res = _sa_intimidate(state, region, count, target, removals,
                                 revealed_by_raid=credit)
            if free:
                credits.pop(region, None)
            done.append({"region": region, "target": target,
                         "count": len(removals), **res})
        except _EXEC_ERRORS as exc:
            errors.append({"region": region,
                           "error": str(exc)})
    return {"executed": bool(done), "sa": _SA_INTIMIDATE,
            "intimidations": done, "errors": errors}


def _execute_suborn(state, faction, bot_action):
    """Validate and execute a complete ordered Suborn plan (§4.4.2/A38).

    Canonical operations specify native physical owners; older bot plans retain
    their effective-type operation labels, including agreed Diviciacus pieces.
    """
    from copy import deepcopy
    from fs_bot.rules_consts import AEDUI, ALLY, WARBAND, AUXILIA
    from fs_bot.commands.sa_suborn import (
        suborn_region_limit, suborn_preview, validate_suborn_region)
    plan = _sa_detail(bot_action, "suborn_plan") or []
    result = {"executed": False, "sa": _SA_SUBORN, "regions": [], "errors": []}
    region = None
    try:
        if faction != AEDUI:
            raise CommandError("Only Aedui may Suborn")
        if not isinstance(plan, list):
            raise CommandError("Suborn plan must be a list of Regions")
        if len(plan) > suborn_region_limit(state):
            raise CommandError(f"Suborn is maximum {suborn_region_limit(state)} Region(s) (§4.4.2 / card 43)")
        steps, used = [], set()
        for entry in plan:
            if not isinstance(entry, dict):
                raise CommandError("Suborn Region entry must be an object")
            region = entry.get("region")
            if not isinstance(region, str):
                raise CommandError("Suborn Region must be named")
            if region in used:
                raise CommandError("Suborn may select each Region only once")
            used.add(region)
            valid, reason = validate_suborn_region(state, region)
            if not valid:
                raise CommandError(reason)
            operations = []
            actions = entry.get("actions", [])
            if not isinstance(actions, list):
                raise CommandError("Suborn actions must be a list")
            for action in actions:
                if not isinstance(action, dict):
                    raise CommandError("Suborn action must be an object")
                name = action.get("action")
                if name in ("place", "remove"):
                    operations.append(dict(action))
                    continue
                types = {"place_ally": ALLY, "place_warband": WARBAND,
                         "place_auxilia": AUXILIA, "remove_ally": ALLY,
                         "remove_warband": WARBAND, "remove_auxilia": AUXILIA}
                if name not in types:
                    raise CommandError(f"Unknown Suborn action: {name}")
                placing = name.startswith("place_")
                operation = {"action": "place" if placing else "remove",
                             "faction": action.get("faction", AEDUI) if placing else
                                         action.get("target_faction", action.get("faction")),
                             "piece_type": types[name]}
                for key in ("tribe", "piece_state", "physical_owner"):
                    if key in action:
                        operation[key] = action[key]
                operations.append(operation)
            if operations:
                steps.append((region, operations))
        sim = state
        for region, operations in steps:
            sim, _ = suborn_preview(sim, region, operations)
    except _EXEC_ERRORS as exc:
        result["errors"].append({"region": region, "error": str(exc)})
        return result

    # Full validation precedes any live mutation. Preserve that atomicity if
    # a later human allocation makes a formerly affordable conversion fail.
    keys = ("spaces", "tribes", "available", "resources", "_diviciacus_force")
    before = {key: deepcopy(state[key]) for key in keys if key in state}
    try:
        for region, operations in steps:
            _sa_suborn(state, region, operations)
            result["regions"].append(region)
    except BaseException as exc:
        for key in keys:
            if key in before:
                if isinstance(state.get(key), dict):
                    state[key].clear()
                    state[key].update(before[key])
                else:
                    state[key] = before[key]
            else:
                state.pop(key, None)
        if not isinstance(exc, _EXEC_ERRORS):
            raise
        result["regions"] = []
        result["errors"].append({"region": region, "error": str(exc)})
    result["executed"] = bool(result["regions"])
    return result


def _execute_build(state, faction, bot_action):
    """Roman Build (§4.2.1).

    The Roman bot's node_r_build computes a complete build_plan
    ({forts:[region], subdue:[{region,tribe}], allies:[{region,tribe}]}) but
    the accompanying Build SA is emitted without it. We recompute the plan
    against the current (post-Command) board via node_r_build and execute it:
    Forts, then Subdue (target_faction derived from the tribe's current
    Allied faction — a lookup, not a choice), then place Allies.
    """
    # A player-supplied plan (CLI collector) takes precedence — the SA is
    # the PLAYER'S choice (§4.2.1); bots recompute via their flowchart.
    plan = _sa_detail(bot_action, "build_plan")
    if plan is None:
        from fs_bot.bots.roman_bot import node_r_build
        try:
            from fs_bot.engine.action_validation import command_parts, command_regions
            seized = {r for part in command_parts(bot_action)
                      if part.get("command") == _CMD_SEIZE
                      for r in command_regions(part)}
            plan = node_r_build(state, exclude_regions=seized)
        except Exception as exc:  # bot helper failure must not crash the turn
            return {"executed": False, "sa": _SA_BUILD,
                    "reason": f"build plan unavailable: {exc!r}"}

    # Card 12 shaded: "Build and Scout Reveal are maximum 1 Region."
    # §8.3.3: non-players apply limited-Region Capabilities in the FIRST
    # Regions that apply — trim the plan to its first Region overall.
    from fs_bot.cards.capabilities import is_capability_active as _ica12
    from fs_bot.rules_consts import EVENT_SHADED as _ES12
    if _ica12(state, 12, _ES12):
        _first = None
        for _k in ("forts", "subdue", "allies"):
            for _e in plan.get(_k, []) or []:
                _r = _e if isinstance(_e, str) else _e.get("region")
                if _r is not None:
                    _first = _r
                    break
            if _first is not None:
                break
        if _first is not None:
            plan = {
                "forts": [r for r in (plan.get("forts") or [])
                          if r == _first],
                "subdue": [e for e in (plan.get("subdue") or [])
                           if e.get("region") == _first],
                "allies": [e for e in (plan.get("allies") or [])
                           if e.get("region") == _first],
            }

    done, errors = [], []
    from fs_bot.commands.sa_build import validate_build_region
    from fs_bot.engine.action_validation import command_parts, command_regions
    seized = {r for part in command_parts(bot_action)
              if part.get("command") == _CMD_SEIZE
              for r in command_regions(part)}

    tribe_action_regions = set()

    def validate_region(region, *, ally_action=False):
        valid, reason = validate_build_region(state, region)
        if not valid:
            raise CommandError(reason)
        if ally_action and region in seized:
            raise CommandError("Build cannot place/subdue Allies in a Seize Region (§4.2.1)")
        if ally_action and region in tribe_action_regions:
            raise CommandError("Build may place or subdue only one Ally per Region (§4.2.1)")

    for region in plan.get("forts", []) or []:
        try:
            validate_region(region)
            _sa_build_fort(state, region)
            done.append(("fort", region))
        except _EXEC_ERRORS as exc:
            errors.append({"action": "fort", "region": region,
                           "error": str(exc)})
    for entry in plan.get("subdue", []) or []:
        region, tribe = entry.get("region"), entry.get("tribe")
        target = state.get("tribes", {}).get(tribe, {}).get("allied_faction")
        if target is None:
            continue
        try:
            validate_region(region, ally_action=True)
            _sa_build_subdue(state, region, tribe, target)
            tribe_action_regions.add(region)
            done.append(("subdue", region, tribe))
        except _EXEC_ERRORS as exc:
            errors.append({"action": "subdue", "region": region,
                           "tribe": tribe, "error": str(exc)})
    for entry in plan.get("allies", []) or []:
        region, tribe = entry.get("region"), entry.get("tribe")
        try:
            validate_region(region, ally_action=True)
            _sa_build_ally(state, region, tribe)
            tribe_action_regions.add(region)
            done.append(("ally", region, tribe))
        except _EXEC_ERRORS as exc:
            errors.append({"action": "ally", "region": region,
                           "tribe": tribe, "error": str(exc)})
    result = {"executed": len(done) > 0, "sa": _SA_BUILD,
              "actions": done, "errors": errors}
    if not done and not errors:
        # R_BUILD found nothing to do — the flowchart's "If no Build" case,
        # a legal outcome (-> Scout / no SA), not a refused proposal.
        result["declined_no_effect"] = True
    return result


def _decide_defender_retreat(state, region, attacker, defender, is_ambush):
    """Route the defending faction's Retreat decision per §8.4.3.

    Non-player Retreat rules (non_player_guidelines_summary.txt, §8.4.3):
      Retreat to save the last piece, or — if Romans — to reduce Losses on
      Legions, or if (1) no Citadel or Fort, (2) they would inflict < 1/2 the
      Losses they would suffer, and (3) the Retreat itself removes no pieces.

    Returns (retreat_declaration, retreat_region):
      - (False, None) if the defender will not or cannot Retreat.
      - (True, dest)  if it Retreats into an adjacent Region it Controls,
        joining the most friendly pieces ("Leaders join most friendly
        pieces", §8.4.3).

    Scope note: destinations are limited to the defender's OWN Control — the
    always-available Retreat. Retreat into another Faction's Control requires
    that Faction's agreement (§1.5.2; only Aedui/Romans might, §8.6.6/§8.8.6);
    that agreement routing is a separate, documented extension.
    """
    from fs_bot.rules_consts import (
        ROMANS, GERMANS, ARVERNI, BELGAE, LEGION, AUXILIA, WARBAND, CITADEL,
        FORT, BASE_SCENARIOS, ARIOVISTUS_SCENARIOS, EVENT_UNSHADED, EVENT_SHADED,
    )
    from fs_bot.battle.losses import calculate_losses

    if is_ambush:
        return (False, None)  # §4.3.3: Defender may not Retreat from Ambush
    scenario = state["scenario"]
    if defender == GERMANS and scenario in BASE_SCENARIOS:
        return (False, None)  # §3.2.4: Germans never Retreat (base)
    if defender == ARVERNI and scenario in ARIOVISTUS_SCENARIOS:
        return (False, None)  # A3.2.4: Arverni never Retreat
    from fs_bot.cards.capabilities import is_capability_active
    if defender == BELGAE and is_capability_active(state, "A70", EVENT_UNSHADED):
        # A70 unshaded: "Belgae never Retreat" — no choice exists, so the
        # agent is not consulted (the battle mechanic refuses regardless).
        return (False, None)
    if (defender == GERMANS and is_capability_active(state, "A33", EVENT_UNSHADED)
            and not is_capability_active(state, "A31", EVENT_SHADED)):
        return (False, None)  # A33 Wailing Women: Germans never Retreat

    # Legal Retreat destinations (adjacent Regions the defender Controls, or
    # ones whose controller agrees — §1.5.2).
    legal = _retreat_destinations(state, region, defender)

    # Agent hook: a human/LLM controlling the defender decides the Retreat.
    from fs_bot.engine.agent import consult_agent, RETREAT
    resp = consult_agent(state, defender, {
        "kind": RETREAT, "region": region, "attacker": attacker,
        "defender": defender, "is_ambush": is_ambush,
        "legal_regions": sorted(legal)})
    if resp is not None:
        if resp.get("retreat") and resp.get("region") in legal:
            return (True, resp["region"])
        return (False, None)

    # Default NP logic. Condition (3): a Retreat removes no pieces only if a
    # legal destination exists.
    if not legal:
        return (False, None)
    dest = max(sorted(legal), key=lambda r: count_pieces(state, r, defender))

    suffer = calculate_losses(state, region, attacker, defender)
    suffer_if_retreat = calculate_losses(
        state, region, attacker, defender, is_retreat=True)
    inflict = calculate_losses(
        state, region, defender, attacker, is_counterattack=True)

    mobile = (count_pieces(state, region, defender, LEGION)
              + count_pieces(state, region, defender, AUXILIA)
              + count_pieces(state, region, defender, WARBAND)
              + (1 if get_leader_in_region(state, region, defender)
                 is not None else 0))
    has_hard = (count_pieces(state, region, defender, CITADEL) > 0
                or count_pieces(state, region, defender, FORT) > 0)

    # (a) Retreat to save the last piece: full Losses would wipe the mobile
    #     group, but halved (Retreat) Losses leave a survivor.
    if mobile > 0 and suffer >= mobile and suffer_if_retreat < mobile:
        return (True, dest)
    # (b) Romans Retreat to reduce Losses on Legions.
    if (defender == ROMANS
            and count_pieces(state, region, defender, LEGION) > 0
            and suffer > 0):
        return (True, dest)
    # (c) No Citadel/Fort, would inflict < 1/2 the Losses suffered, and a
    #     valid (piece-preserving) destination exists.
    if (not has_hard) and (inflict * 2 < suffer):
        return (True, dest)

    return (False, None)


def _retreat_destinations(state, region, faction):
    """Adjacent Regions a faction may Retreat into (§8.4.3 + §1.5.2).

    Includes Regions the faction Controls, plus Regions Controlled by another
    Faction that agrees to the Retreat (np_agrees_to_retreat — Aedui/Romans
    per §8.6.6/§8.8.6). Returns a list (possibly empty).
    """
    from fs_bot.rules_consts import FACTIONS
    from fs_bot.map.map_data import get_adjacent
    from fs_bot.board.control import is_controlled_by

    dests = []
    for r in get_adjacent(region):
        if is_controlled_by(state, r, faction):
            dests.append(r)
            continue
        for c in FACTIONS:
            if c == faction:
                continue
            if is_controlled_by(state, r, c):
                # The controlling Faction agrees? Agent hook (§1.5.2) for a
                # human/LLM-controlled Faction; else the NP rule.
                from fs_bot.engine.agent import consult_agent, AGREEMENT
                _a = consult_agent(state, c, {
                    "kind": AGREEMENT, "request_type": "retreat_into_control",
                    "requesting_faction": faction,
                    "context": {"region": r, "from_region": region}})
                agrees = (bool(_a) if _a is not None
                          else np_agrees_to_retreat(c, faction, state))
                if agrees:
                    dests.append(r)
                break
    return dests


def _best_retreat_destination(state, region, faction):
    """Pick the Retreat destination joining the most friendly pieces
    (§8.4.3), with a deterministic tie-break. None if no legal destination.
    """
    dests = _retreat_destinations(state, region, faction)
    if not dests:
        return None
    return max(sorted(dests), key=lambda r: count_pieces(state, r, faction))


def _execute_rampage(state, faction, bot_action):
    """Belgic Rampage (§4.5.2) — routes the TARGET's remove-vs-Retreat choice.

    For each flipped Hidden Belgic Warband the target must remove or Retreat
    one piece. The bot's rampage plan gives ``{region, target}``; we flip up
    to 2 Warbands (capped by Hidden Belgic Warbands present and by how many
    target pieces are available). The target loses its lowest-value mobile
    pieces first (Warbands, then Auxilia, then Legions — §8.4.1), and
    Retreats them to save them when a legal destination exists (§8.4.3),
    otherwise removes them. In Ariovistus a Rampaged Arverni target is removed
    rather than Retreating (A4.5).
    """
    from fs_bot.rules_consts import (
        BELGAE, ARVERNI, WARBAND, AUXILIA, LEGION, HIDDEN, REVEALED,
        ARIOVISTUS_SCENARIOS,
    )
    # The Belgae bot puts the Rampage plan in sa_regions as a list of dicts
    # {region, target, forces_removal, adds_control}.
    plan = [e for e in (bot_action.get("sa_regions") or [])
            if isinstance(e, dict)]
    if not plan:
        return {"executed": False, "sa": _SA_RAMPAGE,
                "reason": "no rampage plan with targets"}

    scenario = state["scenario"]
    done, errors = [], []
    for entry in plan:
        region = entry.get("region")
        target = entry.get("target")
        if region is None or target is None:
            continue
        from fs_bot.commands.sa_rampage import (validate_rampage_region,
                                                validate_rampage_target)
        valid, reason = validate_rampage_region(state, region)
        if valid:
            valid, reason = validate_rampage_target(state, region, target)
        if not valid:
            errors.append({"region": region, "target": target, "error": reason})
            continue
        hidden_belgic = _count_state(state, region, BELGAE, WARBAND, HIDDEN)
        if hidden_belgic <= 0:
            continue

        # Build the ordered pool of target pieces to lose (lowest value 1st).
        pool = []
        for pt in (WARBAND, AUXILIA):
            for ps in (REVEALED, HIDDEN):
                pool += [(pt, ps)] * _count_state(state, region, target, pt, ps)
        pool += [(LEGION, None)] * count_pieces(state, region, target, LEGION)
        if not pool:
            continue

        n = min(2, hidden_belgic, len(pool))
        if (bot_action.get("command") == _CMD_BATTLE and
                faction in state.get("non_player_factions", set())):
            n = min(n, max(0, count_pieces(state, region, target) - 1))
        if n == 0:
            continue
        dest = _best_retreat_destination(state, region, target)
        force_remove = (scenario in ARIOVISTUS_SCENARIOS and target == ARVERNI)
        # §4.5.2: the TARGET chooses remove or Retreat (A4.5 forces
        # removal for a Rampaged Arverni in Ariovistus — no choice). A
        # player target is consulted via the RETREAT hook with a rampage
        # context; deferring keeps the NP default (§8.4.1/§8.4.3:
        # Retreat to save pieces when a destination exists).
        if (not force_remove
                and target not in state.get("non_player_factions", set())):
            from fs_bot.engine.agent import consult_agent, RETREAT
            legal = sorted(_retreat_destinations(state, region, target))
            resp = consult_agent(state, target, {
                "kind": RETREAT, "region": region, "attacker": faction,
                "defender": target, "is_ambush": False,
                "legal_regions": legal,
                "context": {"rampage": True, "num_pieces": n}})
            if isinstance(resp, dict):
                if resp.get("retreat") and resp.get("region") in legal:
                    dest = resp["region"]
                else:
                    dest = None    # the player chose removal

        actions = []
        for i in range(n):
            pt, ps = pool[i]
            if dest is not None and not force_remove:
                actions.append({"action": "retreat", "piece_type": pt,
                                "piece_state": ps, "retreat_region": dest})
            else:
                actions.append({"action": "remove", "piece_type": pt,
                                "piece_state": ps})
        try:
            _sa_rampage(state, region, target, n, actions)
            done.append({"region": region, "target": target, "count": n})
        except _EXEC_ERRORS as exc:
            errors.append({"region": region, "target": target,
                           "error": str(exc)})
    return {"executed": len(done) > 0, "sa": _SA_RAMPAGE,
            "rampages": done, "errors": errors}


def _np_harassers(state, region, target_faction, group):
    """Collect advance agreements/NP estimates; live losses use the iterator."""
    return list(_iter_harassers(state, region, target_faction, group))


def _iter_harassers(state, region, target_faction, group, *, stop_when_empty=False):
    """Factions that opt to Harass per §8.4.2 (+ §3.4.5 / A3.2.2).

    §8.4.2: Belgae and Arverni Harass only Roman March and Seize; Aedui and
    Romans Harass only Vercingetorix March. §3.4.5: Germans always Harass
    (base). A3.2.2: Arverni always Harass (Ariovistus). A Faction can only
    Harass where it has at least 3 Hidden Warbands (§3.2.2), or Roman
    Hidden Auxilia against Vercingetorix (§3.3.2).

    Args:
        target_faction: The faction being Harassed (the marcher/seizer).
        group: For a March, the moving group dict (to detect Vercingetorix);
            None for Seize.

    Yield each announcement immediately before that Faction's losses so
    later human harassers see earlier casualties (§3.2.2 / §3.2.3).
    """
    from fs_bot.rules_consts import (
        ROMANS, ARVERNI, AEDUI, BELGAE, GERMANS, VERCINGETORIX,
        LEADER, WARBAND, AUXILIA, LEGION, ALLY, FORT, HIDDEN,
        BASE_SCENARIOS, ARIOVISTUS_SCENARIOS,
    )
    from fs_bot.engine.game_engine import get_sop_factions, get_harassment_order
    scenario = state["scenario"]
    has_verc = (scenario in BASE_SCENARIOS and target_faction == ARVERNI
                and bool(group) and group.get(LEADER) == VERCINGETORIX)
    # Includes provisional PR-05/PR-06; see docs/provisional-rulings.md.
    order = get_harassment_order(state)
    for f in order:
        if stop_when_empty:
            if group is not None and not _group_has_pieces(group):
                break
            if group is None and not any(count_pieces(state, region, target_faction, p)
                                         for p in (AUXILIA, ALLY, LEGION, LEADER, FORT)):
                break
        if f == target_faction:
            continue
        harassing_piece = AUXILIA if f == ROMANS and has_verc else WARBAND
        hwb = _count_state(state, region, f, harassing_piece, HIDDEN)
        if hwb < _HWB_PER_LOSS:
            continue
        # §3.2.2: ANY Faction with 3+ Hidden Warbands MAY opt to Harass —
        # the §8.4.2 table below is the NON-PLAYER instruction. A player
        # Faction decides for itself via the decision-agent hook
        # (AGREEMENT / "harassment"); if it defers (or no agent), fall
        # back to the NP table so the all-bot harness is unchanged.
        if (f in get_sop_factions(state)
                and f not in state.get("non_player_factions", set())):
            from fs_bot.engine.agent import consult_agent, AGREEMENT
            resp = consult_agent(state, f, {
                "kind": AGREEMENT, "request_type": "harassment",
                "requesting_faction": target_faction,
                "context": {"region": region, "hidden_warbands": hwb,
                            "harassing_piece": harassing_piece,
                            "vercingetorix": has_verc}})
            if resp is not None:
                if resp:
                    yield f, hwb
                continue
        opt = False
        if f == GERMANS and scenario in BASE_SCENARIOS:
            opt = True  # §3.4.5
        elif f == ARVERNI and scenario in ARIOVISTUS_SCENARIOS:
            opt = True  # A3.2.2
        elif f in (BELGAE, ARVERNI, GERMANS) and target_faction == ROMANS:
            opt = True  # §8.4.2 / A8.4: harass Roman March/Seize
        elif f in (AEDUI, ROMANS) and has_verc:
            opt = True  # §8.4.2: harass Vercingetorix March
        if opt:
            yield f, hwb


def _resolve_seize_harassment(state, region):
    """Roman choices or the printed NP loss priority (§3.2.3 / §8.4.1)."""
    from fs_bot.commands.march import choose_harassment_loss
    from fs_bot.rules_consts import ROMANS, AUXILIA, ALLY, LEGION, FORT, LEADER, CMD_SEIZE
    losses_applied = []
    for faction, hwb in _iter_harassers(state, region, ROMANS, None,
                                      stop_when_empty=True):
        num_losses = hwb // _HWB_PER_LOSS
        for loss_index in range(1, num_losses + 1):
            pieces = {p: count_pieces(state, region, ROMANS, p)
                      for p in (AUXILIA, ALLY, FORT, LEGION, LEADER)}
            options = [p for p in (AUXILIA, ALLY) if pieces[p]]
            if any(pieces[p] for p in (FORT, LEGION, LEADER)):
                options.append("roll")
            if not options:
                break
            context = {"region": region, "command": CMD_SEIZE,
                       "harasser": faction, "loss_index": loss_index,
                       "num_losses": num_losses, "pieces": pieces}
            chosen = choose_harassment_loss(state, ROMANS, dict(
                context, phase="absorb", options=options))
            choice = {AUXILIA: "auxilia", ALLY: "ally"}.get(chosen, chosen)
            res = _seize_harass_loss(state, region, choice, request_context=context)
            losses_applied.append({"by": faction, "choice": choice,
                                   "removed": res.get("removed")})
    return losses_applied


def _execute_entreat(state, faction, bot_action):
    """Arverni Entreat (§4.3.1). The bot's entreat action plan is carried in
    sa_regions as dicts. Each is one of replace_ally / remove_ally (an Allied
    Tribe) or replace_piece / remove_piece (a Warband/Auxilia). The mechanic
    replaces with an Arverni counterpart, or removes the target when the
    Arverni piece is unavailable.
    """
    plan = [e for e in (bot_action.get("sa_regions") or [])
            if isinstance(e, dict)]
    if not plan:
        # The Arverni Rally/March SA path passes only Region names and drops
        # the Entreat action plan; recompute it against the current board
        # (the Battle path passes the full plan and is used directly above).
        from fs_bot.bots.arverni_bot import _check_entreat
        plan = _check_entreat(state, state["scenario"]) or []
    if not plan:
        # Re-derived against the post-Command board, there is no legal Entreat
        # — the flowchart's "If none ... no Special Ability" (§8.7.1). A clean
        # decline, not a wasted attempt.
        return {"executed": False, "sa": _SA_ENTREAT,
                "declined_no_effect": True, "rederived_at_sa_time": True,
                "reason": "no legal Entreat at SA time (§8.7.1 'if none, "
                          "no Special Ability')"}
    done, errors = [], []
    for a in plan:
        act = a.get("action")
        region = a.get("region")
        tgt = a.get("target_faction")
        try:
            from fs_bot.commands.sa_entreat import validate_entreat_region
            valid, reason = validate_entreat_region(state, region)
            if not valid:
                raise CommandError(reason)
            if act in ("replace_ally", "remove_ally"):
                _sa_entreat_ally(state, region, tgt, a.get("tribe"))
            elif act in ("replace_piece", "remove_piece"):
                _sa_entreat_piece(state, region, tgt, a.get("target_type", a.get("piece_type")),
                                  a.get("target_state"))
            else:
                continue
            done.append({"region": region, "action": act})
        except _EXEC_ERRORS as exc:
            errors.append({"region": region, "action": act,
                           "error": str(exc)})
    return {"executed": len(done) > 0, "sa": _SA_ENTREAT,
            "actions": done, "errors": errors}


def _execute_scout(state, faction, bot_action):
    """Roman Scout (§4.2.2). The bot's node_r_scout computes a complete plan
    (auxilia_moves + scout_targets) but the SA is emitted without it; we
    recompute it against the current board and execute: move Auxilia, then
    Reveal — each flipped Hidden Auxilia Reveals up to 2 enemy Warbands.
    """
    from fs_bot.rules_consts import ROMANS, AUXILIA, HIDDEN
    # A player-supplied plan takes precedence (§4.2.2 is the player's
    # choice of moves and Reveal targets); bots recompute via flowchart.
    plan = _sa_detail(bot_action, "scout_plan")
    if plan is None:
        from fs_bot.bots.roman_bot import node_r_scout
        try:
            plan = node_r_scout(state)
        except Exception as exc:
            return {"executed": False, "sa": _SA_SCOUT,
                    "reason": f"scout plan unavailable: {exc!r}"}

    done, errors = [], []
    # Only execute Auxilia moves that carry a concrete from/to (scout_move
    # schema); the bot's escort "intentions" ({to,needed,reason}) are skipped.
    moves = [m for m in (plan.get("auxilia_moves") or [])
             if isinstance(m, dict) and m.get("from_region") and m.get("to_region")]
    if moves:
        try:
            _sa_scout_move(state, moves)
            done.append({"moves": len(moves)})
        except _EXEC_ERRORS as exc:
            errors.append({"action": "move", "error": str(exc)})

    # Card 12 shaded: "Build and Scout Reveal are maximum 1 Region" —
    # Reveal in the first target Region only (§8.3.3 for non-players).
    from fs_bot.cards.capabilities import is_capability_active as _ica12s
    from fs_bot.rules_consts import EVENT_SHADED as _ES12s
    _targets = plan.get("scout_targets", []) or []
    if _ica12s(state, 12, _ES12s) and _targets:
        _first_r = _targets[0].get("region")
        _targets = [t for t in _targets if t.get("region") == _first_r]

    for tgt in _targets:
        region = tgt.get("region")
        enemy = tgt.get("enemy")
        want = tgt.get("hidden", 0)  # Hidden enemy Warbands to Reveal
        if want <= 0:
            continue
        hidden_aux = _count_state(state, region, ROMANS, AUXILIA, HIDDEN)
        if hidden_aux <= 0:
            continue
        # Each flipped Hidden Auxilia Reveals up to 2 Warbands (§4.2.2).
        aux_count = min(hidden_aux, (want + 1) // 2)
        reveal = min(want, 2 * aux_count)
        targets = [{"faction": enemy, "count": reveal}]
        try:
            _sa_scout_reveal(state, region, aux_count, targets)
            done.append({"region": region, "revealed": reveal})
        except _EXEC_ERRORS as exc:
            errors.append({"region": region, "error": str(exc)})

    result = {"executed": len(done) > 0, "sa": _SA_SCOUT,
              "actions": done, "errors": errors}
    if not done and not errors:
        # R_SCOUT "If none ... no Special Ability" — legal outcome.
        result["declined_no_effect"] = True
    return result


def _execute_enlist(state, faction, bot_action):
    """Belgic Enlist (§4.5.1) — execute a free Germanic sub-Command.

    The bot's enlist_details (details['enlist']) names one of five sub-actions
    in a Region within reach of the Belgic Leader. We orchestrate each via the
    German faction's own mechanics (free where the mechanic supports it):
      - german_battle: a free German Battle (with Ambush in base game; A4.5.1
        adds no Ambush in Ariovistus), routing the defender's Retreat.
      - german_march: flip and March the German mobile group origin -> dest.
      - german_march_hide: flip the Region's Revealed German Warbands to Hidden.
      - german_rally: place a German Ally or Warbands.
      - german_raid: a free German Raid (steal from the named player, else gain).
    """
    from fs_bot.rules_consts import BELGAE
    from fs_bot.commands.enlist_free import execute_free_enlist
    ed = _sa_detail(bot_action, "enlist")
    if not isinstance(ed, dict):
        return {"executed": False, "sa": _SA_ENLIST,
                "reason": "no enlist sub-command details"}
    t = ed.get("type")
    try:
        if faction != BELGAE:
            raise CommandError("Only the Belgae may Enlist (§4.5.1)")
        details = execute_free_enlist(state, ed)
    except _EXEC_ERRORS as exc:
        return {"executed": False, "sa": _SA_ENLIST, "type": t,
                "error": str(exc)}
    return {"executed": True, "sa": _SA_ENLIST, "type": t,
            "region": ed.get("region") or ed.get("origin"),
            "details": details}


def _derive_event_params(state, faction, card_id, shaded):
    """Derive event_params for the acting NP faction where the choice is
    unambiguous under the NP rules (§8.2.3: choose benefits for self;
    §8.3.1: place/remove where most Legions, then Citadels, Allies).

    Returns a params dict (merged over any existing event_params), or None.

    SCOPE: This is the parameter-plumbing hook plus the clearly-derivable
    cases. Most parameterized cards encode a card-specific choice (which
    Region, which pieces, which Faction) whose faithful NP derivation is a
    per-card workstream; those remain reported as 'needs parameters' rather
    than guessed.
    """
    if card_id == 47:
        # Every NP sheet declines Council. Do not preselect its human executor's
        # Region or guests; missing selections are requested during resolution.
        return None
    if card_id == "A23":
        from fs_bot.cards.parley import derive_params
        return derive_params(state, faction, shaded)
    fn = _EVENT_PARAM_DERIVERS.get(card_id)
    if fn is None:
        return None
    return fn(state, faction, shaded)


def _derive_senate_direction(state, faction, shaded):
    """Cicero / Senate-shift cards: each Faction shifts the Senate toward its
    own benefit (§8.2.3). Romans favour Adulation (more Legions) -> DOWN;
    Gallic/Germanic Factions favour Uproar (fewer Roman Legions) -> UP.
    """
    from fs_bot.rules_consts import ROMANS, SENATE_UP, SENATE_DOWN
    return {"senate_direction": SENATE_DOWN if faction == ROMANS
            else SENATE_UP}


def _derive_card_28(state, faction, shaded):
    """Card 28 (Oppida): place the acting Gallic Faction's Available Allies at
    Subdued City Tribes not under Roman Control, and upgrade its City Allies to
    Citadels (§8.2.3 — the NP benefits itself; §8.3.1 — at Cities). Only a
    Gallic Faction benefits."""
    from fs_bot.rules_consts import (GALLIC_FACTIONS, CITY_TO_TRIBE,
                                     TRIBE_TO_REGION, ROMANS, ALLY, CITADEL)
    from fs_bot.board.control import is_controlled_by
    from fs_bot.board.pieces import get_available, count_pieces
    if faction not in GALLIC_FACTIONS:
        return None
    placements, upgrades = [], []
    avail_ally = get_available(state, faction, ALLY)
    for city, tribe in CITY_TO_TRIBE.items():
        region = TRIBE_TO_REGION.get(tribe)
        ti = state.get("tribes", {}).get(tribe)
        if not (region and ti):
            continue
        if (ti.get("allied_faction") is None
                and not is_controlled_by(state, region, ROMANS)
                and len(placements) < avail_ally):
            placements.append({"tribe": tribe, "faction": faction})
    avail_cit = get_available(state, faction, CITADEL)
    for city, tribe in CITY_TO_TRIBE.items():
        region = TRIBE_TO_REGION.get(tribe)
        ti = state.get("tribes", {}).get(tribe)
        if (region and ti and ti.get("allied_faction") == faction
                and count_pieces(state, region, faction, ALLY) > 0
                and len(upgrades) < avail_cit):
            upgrades.append(city)
    if not placements and not upgrades:
        return None
    return {"ally_placements": placements, "citadel_upgrades": upgrades}


def _derive_card_71(state, faction, shaded):
    """Card 71 (Colony): place the Colony + the acting Faction's Ally in a
    Region it Controls (or No Control), with no Colony yet. §8.3.1 — choose a
    Region the Faction Controls (keeps the +1 Control Value)."""
    from fs_bot.rules_consts import MARKER_COLONY, ALLY, NO_CONTROL
    from fs_bot.board.control import is_controlled_by, calculate_control
    from fs_bot.board.pieces import get_available
    if get_available(state, faction, ALLY) <= 0:
        return None
    playable = get_playable_regions(state["scenario"], state.get("capabilities"))
    controlled, nocontrol = [], []
    for r in sorted(playable):
        m = state.get("markers", {}).get(r) or {}
        if MARKER_COLONY in m:
            continue
        if is_controlled_by(state, r, faction):
            controlled.append(r)
        elif calculate_control(state, r) == NO_CONTROL:
            nocontrol.append(r)
    cands = sorted(controlled) or sorted(nocontrol)
    if not cands:
        return None
    region = cands[0]
    return {"region": region, "colony_tribe_name": f"Colony_{region}"}


def _derive_card_41(state, faction, shaded):
    """Card 41 (Avaricum): if the Faction holds Avaricum, place up to 2 Allies
    at Subdued Tribes within 1 of Bituriges and upgrade one City Ally to a
    Citadel (§8.2.3/§8.3.1 — benefit self near Avaricum)."""
    from fs_bot.rules_consts import (CITY_AVARICUM, CITY_TO_TRIBE,
                                     BITURIGES, ALLY, CITADEL)
    from fs_bot.map.map_data import (get_adjacent, get_tribes_in_region,
                                     is_city_tribe)
    from fs_bot.board.pieces import get_available, count_pieces
    av_tribe = CITY_TO_TRIBE.get(CITY_AVARICUM)
    ti = state.get("tribes", {}).get(av_tribe)
    if not ti or ti.get("allied_faction") != faction:
        return None
    scenario = state["scenario"]
    target_regions = [BITURIGES] + list(get_adjacent(BITURIGES, scenario))
    placements = []
    avail = get_available(state, faction, ALLY)
    for r in target_regions:
        for tribe in get_tribes_in_region(r, scenario):
            t_info = state.get("tribes", {}).get(tribe)
            if (t_info and t_info.get("allied_faction") is None
                    and len(placements) < min(2, avail)):
                placements.append({"tribe": tribe})
    citadel_tribe = None
    if get_available(state, faction, CITADEL) > 0:
        for r in target_regions:
            for tribe in get_tribes_in_region(r, scenario):
                t_info = state.get("tribes", {}).get(tribe)
                if (t_info and t_info.get("allied_faction") == faction
                        and is_city_tribe(tribe)
                        and count_pieces(state, r, faction, ALLY) > 0):
                    citadel_tribe = tribe
                    break
            if citadel_tribe:
                break
    if not placements and not citadel_tribe:
        return None
    out = {"ally_placements": [{"tribe": t["tribe"]} for t in placements]}
    if citadel_tribe:
        out["citadel_upgrade_tribe"] = citadel_tribe
    return out


def _derive_card_42(state, faction, shaded):
    """Card 42 (Roman Wine), unshaded: remove up to 4 non-own Allied Tribes
    (not Citadels) in Roman-Controlled Regions (§8.2.3 — remove enemies', not
    own).

    Shaded (Romanizing tribes): remove 1-3 Roman or Aedui Allies (not Citadels)
    in Roman-Aedui Supply-Line Regions (Card Reference 42 — Supply Lines per
    §3.2.1 computed "as if Romans and Aedui both agreed", i.e. chain Regions are
    No Control / Roman / Aedui). The NP removes enemies' Allies (§8.2.3) — never
    its own."""
    from fs_bot.rules_consts import TRIBE_TO_REGION, ROMANS, ALLY
    from fs_bot.board.control import is_controlled_by
    from fs_bot.board.pieces import count_pieces
    if shaded:
        from fs_bot.rules_consts import AEDUI
        from fs_bot.commands.rally import has_supply_line
        agreements = {ROMANS: True, AEDUI: True}
        removals = []
        for tribe in sorted(state.get("tribes", {})):
            if len(removals) >= 3:
                break
            ti = state["tribes"][tribe]
            af = ti.get("allied_faction")
            if af not in (ROMANS, AEDUI) or af == faction:
                continue  # only enemies' Roman/Aedui Allies
            region = TRIBE_TO_REGION.get(tribe)
            if not region or count_pieces(state, region, af, ALLY) <= 0:
                continue  # an Ally piece (not a Citadel city)
            if not has_supply_line(state, region, faction=ROMANS,
                                   agreements=agreements):
                continue
            removals.append({"tribe": tribe, "faction": af})
        return {"removals": removals} if removals else None
    removals = []
    for tribe, ti in state.get("tribes", {}).items():
        af = ti.get("allied_faction")
        region = TRIBE_TO_REGION.get(tribe)
        if (af and af != faction and region
                and is_controlled_by(state, region, ROMANS)
                and count_pieces(state, region, af, ALLY) > 0):
            removals.append({"tribe": tribe})
            if len(removals) >= 4:
                break
    return {"removals": removals} if removals else None


def _derive_card_23(state, faction, shaded):
    """Card 23 (Sacking), unshaded: Romans Raze a City under Roman Control
    (+8 Resources, permanent Disperse). Choose a Roman-Controlled City.

    Shaded (Costly siege): if a Legion is where the acting Faction has a
    Citadel, remove that Legion (Romans Ineligible through next card). Choose
    the Region with the acting Faction's Citadel holding the most Roman Legions
    (§8.3.1 — where most Legions). Non-Roman only ("your Citadel")."""
    from fs_bot.rules_consts import (CITY_TO_TRIBE, TRIBE_TO_REGION,
                                     MARKER_RAZED, ROMANS)
    from fs_bot.board.control import is_controlled_by
    if shaded:
        from fs_bot.rules_consts import LEGION, CITADEL
        from fs_bot.board.pieces import count_pieces
        if faction == ROMANS:
            return None
        best = None
        for region in get_playable_regions(state["scenario"],
                                            state.get("capabilities")):
            if count_pieces(state, region, faction, CITADEL) <= 0:
                continue
            legs = count_pieces(state, region, ROMANS, LEGION)
            if legs > 0 and (best is None or legs > best[1]):
                best = (region, legs)
        return {"target_region": best[0]} if best else None
    if faction != ROMANS:
        return None
    for city, tribe in CITY_TO_TRIBE.items():
        region = TRIBE_TO_REGION.get(tribe)
        if region and is_controlled_by(state, region, ROMANS):
            m = state.get("markers", {}).get(region) or {}
            if MARKER_RAZED in m:
                continue
            return {"target_city": city}
    return None


def _derive_card_68(state, faction, shaded):
    """Card 68 (Remi Influence), unshaded: if Remi are a Roman Ally or Subdued,
    Romans replace up to 2 non-Roman Allies within 1 Region of Remi (Atrebates)
    with Roman Allies (§8.2.3 — convert enemies' to own).

    Shaded (Mediation): a Gallic Faction with Remi as its Ally may remove
    anything at Alesia or Cenabum and place a Citadel + 4 Warbands there
    (Card Reference 68). Acting Faction must be the Gallic Faction allied with
    Remi; choose the City whose removal hurts an enemy most (else Alesia)."""
    from fs_bot.rules_consts import (TRIBE_REMI, TRIBE_TO_REGION, ATREBATES,
                                     ROMANS)
    from fs_bot.map.map_data import get_adjacent, get_tribes_in_region
    if shaded:
        from fs_bot.rules_consts import (GALLIC_FACTIONS, FACTIONS, CITADEL,
                                         CITY_ALESIA, CITY_CENABUM, CITY_TO_TRIBE)
        from fs_bot.board.pieces import count_pieces
        if faction not in GALLIC_FACTIONS:
            return None
        remi = state.get("tribes", {}).get(TRIBE_REMI)
        if not remi or remi.get("allied_faction") != faction:
            return None
        best = None  # (city, enemy_value)
        for city in (CITY_ALESIA, CITY_CENABUM):
            tribe = CITY_TO_TRIBE.get(city)
            region = TRIBE_TO_REGION.get(tribe)
            if not region:
                continue
            ti = state.get("tribes", {}).get(tribe) or {}
            enemy = 0
            af = ti.get("allied_faction")
            if af and af != faction:
                enemy += 1
            for f2 in FACTIONS:
                if f2 != faction:
                    enemy += count_pieces(state, region, f2, CITADEL)
            if best is None or enemy > best[1]:
                best = (city, enemy)
        return {"target_city": best[0]} if best else None
    if faction != ROMANS:
        return None
    _R = ROMANS
    ti = state.get("tribes", {}).get(TRIBE_REMI)
    if not ti:
        return None
    # "Dispersed Remi would not qualify for unshaded" (Card 68 Tips). Disperse
    # is stored in tribe["status"] (= Dispersed / Dispersed-Gathering).
    is_roman = ti.get("allied_faction") == _R
    is_subdued = (ti.get("allied_faction") is None
                  and ti.get("status") is None)
    if not (is_roman or is_subdued):
        return None
    scenario = state["scenario"]
    valid = [ATREBATES] + list(get_adjacent(ATREBATES, scenario))
    repl = []
    for region in valid:
        for tribe in get_tribes_in_region(region, scenario):
            t = state.get("tribes", {}).get(tribe)
            if (t and t.get("allied_faction")
                    and t.get("allied_faction") != _R
                    and len(repl) < 2):
                repl.append({"tribe": tribe})
    return {"replacements": repl} if repl else None


def _derive_card_58(state, faction, shaded):
    """Card 58 (Aduatuca), unshaded: remove up to 9 Belgic/Germanic Warbands
    from a Region with a (Roman) Fort. Choose the Fort Region with the most
    such Warbands. Only a Faction opposed to Belgae/Germans benefits. Shaded
    (free German March/Battle) deferred."""
    from fs_bot.rules_consts import (BELGAE, GERMANS, ROMANS, WARBAND, FORT)
    from fs_bot.board.pieces import count_pieces
    if shaded or faction in (BELGAE, GERMANS):
        return None
    playable = get_playable_regions(state["scenario"], state.get("capabilities"))
    best = None
    for region in sorted(playable):
        if count_pieces(state, region, ROMANS, FORT) <= 0:
            continue
        bg = (count_pieces(state, region, BELGAE, WARBAND)
              + count_pieces(state, region, GERMANS, WARBAND))
        if bg > 0 and (best is None or bg > best[1]):
            best = (region, bg)
    if best is None:
        return None
    region = best[0]
    removals = []
    for f in (BELGAE, GERMANS):
        n = count_pieces(state, region, f, WARBAND)
        if n > 0:
            removals.append({"faction": f, "count": min(n, 9)})
    return {"region": region, "removals": removals}


def _derive_card_22(state, faction, shaded):
    """Card 22 (Hostages), unshaded: among Regions the acting Faction Controls,
    replace up to 4 enemy Warbands/Auxilia with its own (§8.2.3 — convert
    enemies' to own).

    Shaded (Casus belli): place a Gallic Ally and any 1 Warband at each of 1 or
    2 Subdued Tribes where Roman pieces (Card Reference 22). The NP benefits
    itself (§8.2.3) — place its own Ally + own Warband. A Gallic Faction only;
    a Roman/German acting Faction gains nothing from placing a Gallic Ally, so
    no derivation (graceful no-op)."""
    from fs_bot.rules_consts import FACTIONS, WARBAND, AUXILIA
    from fs_bot.board.control import is_controlled_by
    from fs_bot.board.pieces import count_pieces
    if shaded:
        from fs_bot.rules_consts import (GALLIC_FACTIONS, ALLY, ROMANS,
                                         TRIBE_TO_REGION)
        from fs_bot.board.pieces import get_available
        if (faction not in GALLIC_FACTIONS
                or get_available(state, faction, ALLY) <= 0):
            return None
        target_tribes = []
        for tribe in sorted(state.get("tribes", {})):
            if len(target_tribes) >= 2:
                break
            ti = state["tribes"][tribe]
            # Subdued Tribe = neither Allied nor Dispersed (Key Terms Index).
            # Dispersed / Dispersed-Gathering / Razed live in tribe["status"].
            if ti.get("allied_faction") is not None or ti.get("status") is not None:
                continue
            region = TRIBE_TO_REGION.get(tribe)
            if not region or count_pieces(state, region, ROMANS) <= 0:
                continue  # "where Roman pieces"
            target_tribes.append({"tribe": tribe, "region": region,
                                  "faction": faction,
                                  "warband_faction": faction})
        return {"target_tribes": target_tribes} if target_tribes else None
    replacements = []
    playable = get_playable_regions(state["scenario"], state.get("capabilities"))
    for region in sorted(playable):
        if not is_controlled_by(state, region, faction):
            continue
        for tf in FACTIONS:
            if tf == faction:
                continue
            for pt in (WARBAND, AUXILIA):
                for _ in range(count_pieces(state, region, tf, pt)):
                    if len(replacements) >= 4:
                        break
                    replacements.append({"region": region,
                                         "target_faction": tf,
                                         "piece_type": pt})
    return {"replacements": replacements} if replacements else None


def _derive_card_A18(state, faction, shaded):
    """Card A18 (Rhenus Bridge), unshaded: remove all Germans from a Germania
    Region without Ariovistus. Choose the such Region with the most German
    pieces. Any non-German Faction benefits. Shaded deferred."""
    from fs_bot.rules_consts import (GERMANIA_REGIONS, GERMANS, ARIOVISTUS_LEADER,
                                     WARBAND, ALLY, SETTLEMENT, ROMANS)
    from fs_bot.board.pieces import count_pieces, get_leader_in_region
    from fs_bot.board.control import is_controlled_by
    from fs_bot.map.map_data import get_adjacent
    if shaded or faction == GERMANS:
        return None
    scen = state["scenario"]
    best = None
    for region in GERMANIA_REGIONS:
        if get_leader_in_region(state, region, GERMANS) == ARIOVISTUS_LEADER:
            continue
        # "...under or adjacent to Roman Control" (A18) — only such Regions.
        if not (is_controlled_by(state, region, ROMANS)
                or any(is_controlled_by(state, a, ROMANS)
                       for a in get_adjacent(region, scen))):
            continue
        g = (count_pieces(state, region, GERMANS, WARBAND)
             + count_pieces(state, region, GERMANS, ALLY)
             + count_pieces(state, region, GERMANS, SETTLEMENT))
        if g > 0 and (best is None or g > best[1]):
            best = (region, g)
    return {"region": best[0]} if best else None


def _derive_card_A45(state, faction, shaded):
    """Card A45 (Savage Dictates), unshaded: place up to 3 of the acting
    non-German Faction's Allies at Subdued Celtica Tribes. Shaded deferred."""
    from fs_bot.rules_consts import (GERMANS, CELTICA_REGIONS, ALLY,
                                     MARKER_INTIMIDATED)
    from fs_bot.map.map_data import get_tribes_in_region, get_adjacent
    from fs_bot.board.pieces import get_available
    if shaded or faction == GERMANS:
        return None
    avail = get_available(state, faction, ALLY)
    if avail <= 0:
        return None
    scen = state["scenario"]
    markers = state.get("markers", {})
    intimidated = {r for r, m in markers.items()
                   if isinstance(m, dict) and MARKER_INTIMIDATED in m}
    if not intimidated:
        return None  # "within 1 Region of Intimidated markers" — none exist

    def _within1(region):
        return region in intimidated or any(
            a in intimidated for a in get_adjacent(region, scen))

    placements = []
    for region in CELTICA_REGIONS:
        if not _within1(region):
            continue
        for tribe in get_tribes_in_region(region, scen):
            ti = state.get("tribes", {}).get(tribe)
            if (ti and ti.get("allied_faction") is None
                    and ti.get("status") is None
                    and len(placements) < min(3, avail)):
                placements.append({"tribe": tribe, "faction": faction})
    return {"placements": placements} if placements else None


def _derive_card_A37(state, faction, shaded):
    """A37 choices obey the one-Region scope and Aedui no-movement instruction."""
    from fs_bot.cards.all_gaul_gathers import derive_params
    return derive_params(state, faction, shaded)


def _derive_card_A64(state, faction, shaded):
    """Card A64 (Abatis): place the Faction's Abatis marker in a Region where
    it has a Warband — prefer a Region also holding an enemy (frontier
    defense). No existing Abatis there."""
    from fs_bot.rules_consts import WARBAND, FACTIONS, MARKER_ABATIS
    from fs_bot.board.pieces import count_pieces
    playable = get_playable_regions(state["scenario"], state.get("capabilities"))
    frontier, plain = None, None
    for region in sorted(playable):
        if count_pieces(state, region, faction, WARBAND) <= 0:
            continue
        m = state.get("markers", {}).get(region) or {}
        if MARKER_ABATIS in m:
            continue
        enemy = any(count_pieces(state, region, of) > 0
                    for of in FACTIONS if of != faction)
        if enemy and frontier is None:
            frontier = region
        elif plain is None:
            plain = region
    region = frontier or plain
    return {"region": region} if region else None


def _derive_card_A66(state, faction, shaded):
    """A66 NP sheets: Belgica for Belgae, Germania for Germans; then §8.3.4."""
    from fs_bot.cards.winter_uprising import derive_params
    return derive_params(state, faction)


def _derive_card_A17(state, faction, shaded):
    """A17 (shaded): "Remove 4 Auxilia from any 1 Region." Choose the Region
    per the acting Faction's Ariovistus instruction:
      German: most Roman Auxilia removable from Germania or where a German
              Settlement, then adjacent to Germania/Settlement; else none.
      Belgic: Belgica Regions first.
      Other:  most Roman Auxilia.
    The unshaded side is the Roman free March+Battle (executed, not derived).
    """
    if not shaded:
        return None
    from fs_bot.rules_consts import (ROMANS, GERMANS, BELGAE, AUXILIA,
                                     SETTLEMENT, GERMANIA_REGIONS,
                                     BELGICA_REGIONS)
    from fs_bot.board.pieces import count_pieces
    from fs_bot.map.map_data import get_adjacent, get_playable_regions
    scen = state["scenario"]
    playable = get_playable_regions(scen, state.get("capabilities"))
    cands = [(r, count_pieces(state, r, ROMANS, AUXILIA)) for r in sorted(playable)]
    cands = [(r, n) for r, n in cands if n > 0]
    if not cands:
        return None
    if faction == GERMANS:
        settlement_regions = {r for r in sorted(playable)
                              if count_pieces(state, r, GERMANS, SETTLEMENT) > 0}
        core = set(GERMANIA_REGIONS) | settlement_regions
        adj = set()
        for r in core:
            adj.update(get_adjacent(r, scen))
        def gkey(item):
            r, n = item
            tier = 0 if r in core else (1 if r in adj else 2)
            return (tier, -n)
        cands.sort(key=gkey)
        # German instruction targets Roman pieces near Germania; if the best
        # is neither in/adjacent to Germania nor a Settlement, still allowed
        # ("any 1 Region") — pick most Auxilia.
        return {"region": cands[0][0]}
    if faction == BELGAE:
        belgica = set(BELGICA_REGIONS)
        cands.sort(key=lambda it: (0 if it[0] in belgica else 1, -it[1]))
        return {"region": cands[0][0]}
    cands.sort(key=lambda it: -it[1])
    return {"region": cands[0][0]}


def _derive_card_11(state, faction, shaded):
    """Cards 11 (Numidians) / 11a (Ariovistus text): unshaded "Romans place 3
    Auxilia in a Region within 1 of their Leader and free Battle there."

    Roman NP instruction (Numidians): "Place the full number of Auxilia; if not
    able, treat as 'No Romans'." So choose a Region within 1 of the Roman
    Leader where the Romans can place all 3 Auxilia (>=3 Available) and an
    enemy is present to Battle, ranked by Roman Battle priority (8.8.1).
    If no enemy is present, the placement still occurs (§5.1.3).

    Returns both the base ("target_region") and Ariovistus ("region") param
    keys so whichever card text is in play reads its own key.
    """
    if shaded:
        return None
    from fs_bot.rules_consts import ROMANS, AUXILIA
    from fs_bot.board.pieces import (find_leader, count_pieces, get_available)
    from fs_bot.map.map_data import get_adjacent, get_playable_regions
    from fs_bot.bots.roman_bot import _rank_battle_targets
    if get_available(state, ROMANS, AUXILIA) < 3:
        return None  # "Place the full number ... if not able, 'No Romans'."
    leader = find_leader(state, ROMANS)
    if leader is None:
        return None
    scen = state["scenario"]
    playable = set(get_playable_regions(scen, state.get("capabilities")))
    within1 = ({leader} | set(get_adjacent(leader, scen))) & playable
    best = None  # (region, enemy_mobile)
    for r in sorted(within1):
        targets = _rank_battle_targets(state, r, scen)
        if not targets:
            continue
        enemy = targets[0]
        from fs_bot.rules_consts import WARBAND, LEGION, AUXILIA as AUX
        em = (count_pieces(state, r, enemy, WARBAND)
              + count_pieces(state, r, enemy, AUX)
              + count_pieces(state, r, enemy, LEGION))
        if best is None or em > best[1]:
            best = (r, em)
    if best is None:
        # The placement is not conditional on a follow-up Battle. All legal
        # Regions place the same three pieces; resolve that tie per §8.3.4.
        if not within1:
            return None
        from fs_bot.bots.bot_common import random_select
        target = random_select(state, sorted(within1))
        return {"target_region": target, "region": target}
    return {"target_region": best[0], "region": best[0]}


def _derive_card_2(state, faction, shaded):
    """Card 2 Legiones (shaded): "Free Battle against Romans in a Region. The
    first Loss removes a Legion automatically, if any there."

    The acting (non-Roman) Faction chooses a Region where it can Battle the
    Romans — preferring a Region holding a Roman Legion (so the auto-Legion
    Loss bites) and where it has an attacking force, by Roman pieces present.
    Returns {"battle_region": R}, or None if no such Region (the unshaded side
    is the Senate/Legions placement, handled in the card).
    """
    from fs_bot.rules_consts import ROMANS, LEGION
    if not shaded or faction == ROMANS:
        return None
    ROM = ROMANS
    from fs_bot.board.pieces import count_pieces
    from fs_bot.map.map_data import get_playable_regions
    playable = get_playable_regions(state["scenario"], state.get("capabilities"))
    best = None  # (region, has_legion, roman_pieces)
    for r in sorted(playable):
        if not _attacker_has_force(state, r, faction):
            continue
        if count_pieces(state, r, ROM) <= 0:
            continue
        has_leg = 1 if count_pieces(state, r, ROM, LEGION) > 0 else 0
        roman = count_pieces(state, r, ROM)
        key = (has_leg, roman)
        if best is None or key > best[1]:
            best = (r, key)
    return {"battle_region": best[0]} if best else None


def _derive_card_4(state, faction, shaded):
    """Card 4 Circumvallation: "Romans may free March to an adjacent Citadel
    and put Circumvallation marker on Citadel Faction's pieces there."

    Choose the Region holding a non-Roman Citadel that is adjacent to a Roman
    mobile group (so the Romans can March in), preferring the Citadel Region
    with the most enemy pieces to trap. Returns {"target_region": R} or None.
    Roman-only.
    """
    from fs_bot.rules_consts import ROMANS, CITADEL, FACTIONS
    from fs_bot.board.pieces import count_pieces
    from fs_bot.map.map_data import get_adjacent, get_playable_regions
    if faction != ROMANS:
        return None
    playable = set(get_playable_regions(state["scenario"], state.get("capabilities")))
    best = None  # (region, enemy_pieces)
    for R in sorted(playable):
        has_enemy_citadel = any(
            f != ROMANS and count_pieces(state, R, f, CITADEL) > 0
            for f in FACTIONS)
        if not has_enemy_citadel:
            continue
        adj_roman = any(
            _group_has_pieces(_mobile_march_group(state, ROMANS, a))
            for a in get_adjacent(R, state["scenario"]) if a in playable)
        if not adj_roman:
            continue
        enemy = sum(count_pieces(state, R, f) for f in FACTIONS if f != ROMANS)
        if best is None or enemy > best[1]:
            best = (R, enemy)
    return {"target_region": best[0]} if best else None


def _derive_card_70(state, faction, shaded):
    """Card 70 Camulogenus (shaded): "Place 0-6 Warbands among Atrebates,
    Carnutes, and Mandubii; select 1 for a free Command + Special Ability."

    Place all available Warbands (up to 6) of the acting Faction in the one of
    those Regions where it will best act: the Region with the most enemy
    pieces to Battle, else where the Faction already has the most presence,
    else the first. The executor then runs the free Command restricted to that
    Region. Unshaded (Roman March+Battle) needs no params.
    """
    if not shaded:
        return None
    from fs_bot.rules_consts import (ATREBATES, CARNUTES, MANDUBII, WARBAND,
                                     FACTIONS)
    from fs_bot.board.pieces import count_pieces, get_available
    from fs_bot.map.map_data import get_playable_regions
    if faction is None:
        return None
    avail = get_available(state, faction, WARBAND)
    if avail <= 0:
        return None
    playable = set(get_playable_regions(state["scenario"], state.get("capabilities")))
    regs = [r for r in (ATREBATES, CARNUTES, MANDUBII) if r in playable]
    if not regs:
        return None
    def score(r):
        enemy = sum(count_pieces(state, r, f) for f in FACTIONS if f != faction)
        own = count_pieces(state, r, faction)
        return (enemy, own)
    R = max(regs, key=score)
    return {"placements": [{"region": R, "count": min(6, avail)}]}


def _derive_card_25(state, faction, shaded):
    """Card 25 Aquitani (unshaded): free Battle in Pictones or the Arverni
    Region. The Card Tips explicitly allow no attacking force: the three
    extra Losses add to zero. Shaded is a Capability."""
    if shaded:
        return None
    from fs_bot.rules_consts import PICTONES, ARVERNI_REGION, ROMANS, ARVERNI
    from fs_bot.board.pieces import count_pieces
    from fs_bot.map.map_data import get_playable_regions
    playable = set(get_playable_regions(state["scenario"], state.get("capabilities")))
    best = None
    for R in (PICTONES, ARVERNI_REGION):
        if R not in playable:
            continue
        target = _card25_battle_target(state, R, faction)
        if target is None:
            continue
        priority = int(faction == ROMANS
                       and faction in state.get("non_player_factions", ())
                       and target == ARVERNI)
        score = priority, count_pieces(state, R, target)
        if best is None or score > best[1]:
            best = (R, score)
    return {"battle_region": best[0]} if best else None


def _derive_card_16(state, faction, shaded):
    """Card 16: place the most Auxilia; shaded choices follow the live roll."""
    if shaded:
        return None
    from fs_bot.cards.ambacti_np import derive_unshaded
    return derive_unshaded(state, faction)


def _derive_card_44(state, faction, shaded):
    """Card 44's NP replacement/Scout/Raid choices use only placed pieces."""
    from fs_bot.cards.dumnorix import derive_params
    return derive_params(state, faction, shaded)


def _derive_card_A58(state, faction, shaded):
    """Card A58 Aduatuca (shaded): in 1 Belgica Region, replace 1 Roman Ally
    and 3 Auxilia with the acting Faction's, then free Ambush Romans. Choose a
    Belgica Region with a Roman-allied Tribe and Roman Auxilia. (Unshaded is
    the Roman Battle+Seize, executed not derived.)"""
    if not shaded:
        return None
    from fs_bot.rules_consts import ROMANS, AUXILIA, BELGICA_REGIONS
    from fs_bot.board.pieces import count_pieces
    from fs_bot.map.map_data import get_tribes_in_region
    for R in BELGICA_REGIONS:
        if count_pieces(state, R, ROMANS, AUXILIA) <= 0:
            continue
        for t in get_tribes_in_region(R, state["scenario"]):
            ti = state.get("tribes", {}).get(t)
            if ti and ti.get("allied_faction") == ROMANS:
                return {"region": R, "ally_tribe": t}
    return None


# Registry of per-card event_param derivers (extend as cards gain faithful
# NP derivations). Card 1 (Cicero) is the unambiguous senate-direction case.
def _derive_card_A29(state, faction, shaded):
    """A29 unshaded: a Gaul or Roman places up to 2 own Allies at Subdued Tribes
    in Regions with (German) Settlements, plus 5 own Warbands (Gallic) / 3
    Auxilia (Roman) among those Regions (§8.2.3 — benefit self)."""
    if shaded:
        return None
    from fs_bot.rules_consts import (GERMANS, ROMANS, GALLIC_FACTIONS,
                                     SETTLEMENT, WARBAND, AUXILIA, ALLY)
    from fs_bot.board.pieces import count_pieces, get_available
    from fs_bot.map.map_data import get_playable_regions, get_tribes_in_region
    if faction == GERMANS:
        return None
    scen = state["scenario"]
    settlement_regions = [
        r for r in get_playable_regions(scen, state.get("capabilities"))
        if count_pieces(state, r, GERMANS, SETTLEMENT) > 0]
    if not settlement_regions:
        return None
    placements = []
    avail_ally = get_available(state, faction, ALLY)
    n_ally = 0
    for region in settlement_regions:
        if n_ally >= min(2, avail_ally):
            break
        for tribe in get_tribes_in_region(region, scen):
            ti = state.get("tribes", {}).get(tribe)
            if (ti and ti.get("allied_faction") is None
                    and ti.get("status") is None):
                placements.append({"region": region, "piece_type": ALLY,
                                   "faction": faction, "tribe": tribe})
                n_ally += 1
                break
    if faction in GALLIC_FACTIONS:
        n = min(5, get_available(state, faction, WARBAND))
        if n > 0:
            placements.append({"region": settlement_regions[0],
                               "piece_type": WARBAND, "faction": faction,
                               "count": n})
    elif faction == ROMANS:
        n = min(3, get_available(state, faction, AUXILIA))
        if n > 0:
            placements.append({"region": settlement_regions[0],
                               "piece_type": AUXILIA, "faction": faction,
                               "count": n})
    return {"placements": placements} if placements else None


def _derive_card_A40(state, faction, shaded):
    """A40 unshaded: place up to (3 Warbands / 2 Auxilia) of the acting Faction
    in each of up to 3 Regions within 1 of Cisalpina (§8.2.3 — own pieces;
    Romans place Auxilia, others place Warbands)."""
    if shaded:
        return None
    from fs_bot.rules_consts import ROMANS, WARBAND, AUXILIA, CISALPINA
    from fs_bot.board.pieces import get_available
    from fs_bot.map.map_data import get_adjacent, get_playable_regions
    scen = state["scenario"]
    playable = set(get_playable_regions(scen, state.get("capabilities")))
    near = [r for r in ([CISALPINA] + list(get_adjacent(CISALPINA, scen)))
            if r in playable]
    if not near:
        return None
    pt, cap = (AUXILIA, 2) if faction == ROMANS else (WARBAND, 3)
    avail = get_available(state, faction, pt)
    placements = []
    used = 0
    for region in near:
        if used >= 3 or avail <= 0:
            break
        n = min(cap, avail)
        if n > 0:
            placements.append({"region": region, "piece_type": pt,
                               "faction": faction, "count": n})
            avail -= n
            used += 1
    return {"placements": placements} if placements else None


def _derive_o38_region(state, faction, shaded):
    """O38 unshaded: NP places Diviciacus with the most Aedui pieces
    (mirrors the §8.3.2 Leader-placement instruction)."""
    if shaded:
        return None
    from fs_bot.rules_consts import AEDUI
    from fs_bot.bots.bot_common import get_leader_placement_region
    region = get_leader_placement_region(state, AEDUI)
    return {"region": region} if region else None


def _derive_card_32(state, faction=None, shaded=False):
    """Card 32 Forced Marches, NP relocation (found live as a bot no-op:
    the event executed with no moves derived, wasting the bot's turn).

    Arverni instruction: "move only per 8.7.6" — reuse the V_MARCH_SPREAD
    planner's moves as the free relocation. Other NP factions' cards say
    "No <Faction>" (event_eval routes them to the flowchart), so an empty
    derivation there is correct.
    """
    import copy as _copy
    from fs_bot.rules_consts import (ARVERNI as _AR32, WARBAND as _WB32,
                                     LEADER as _LD32)
    faction = faction or state.get("executing_faction")
    if faction != _AR32:
        return {}
    try:
        from fs_bot.bots.arverni_bot import node_v_march_spread
        sim = _copy.deepcopy(state)
        sim.pop("decision_agent", None)
        plan = (node_v_march_spread(sim).get("details") or {}).get(
            "march_plan") or {}
        moves = plan_expand_march_moves(_copy.deepcopy(state), _AR32, plan)
    except Exception:
        return {}
    out = []
    for mv in moves:
        dest = (mv.get("path") or [None])[-1]
        if dest is None:
            continue
        grp = mv.get("group") or {}
        wb = int(grp.get(_WB32) or mv.get("warbands") or 0)
        if wb > 0:
            # Split by piece state — the handler moves one state at a
            # time (census caught a Hidden-only over-count when the
            # stack was mixed Hidden/Revealed).
            from fs_bot.rules_consts import (HIDDEN as _H32,
                                             REVEALED as _R32,
                                             SCOUTED as _S32)
            from fs_bot.board.pieces import (
                count_pieces_by_state as _cps32)
            remaining = wb
            for ps in (_H32, _R32, _S32):
                if remaining <= 0:
                    break
                have = _cps32(state, mv["origin"], _AR32, _WB32, ps)
                take = min(remaining, have)
                if take > 0:
                    out.append({"piece_type": _WB32,
                                "from_region": mv["origin"],
                                "to_region": dest, "count": take,
                                "piece_state": ps})
                    remaining -= take
        if mv.get("leader"):
            out.append({"piece_type": _LD32,
                        "from_region": mv["origin"], "to_region": dest,
                        "leader_name": grp.get(_LD32)})
    return {"moves": out} if out else {}


def _derive_card_62(state, faction, shaded):
    from fs_bot.cards.war_fleet import derive_war_fleet
    return derive_war_fleet(state, faction, shaded)


from fs_bot.cards.ally_events import derive_gobannitio, derive_correus
from fs_bot.cards.boii_np import derive_boii


_EVENT_PARAM_DERIVERS = {
    37: derive_boii,
    26: derive_gobannitio,
    64: derive_correus,
    "O38": _derive_o38_region,
    1: _derive_senate_direction,
    2: _derive_card_2,
    "A58": _derive_card_A58,
    44: _derive_card_44,
    16: _derive_card_16,
    25: _derive_card_25,
    4: _derive_card_4,
    70: _derive_card_70,
    11: _derive_card_11,
    "A17": _derive_card_A17,
    "A18": _derive_card_A18,
    "A37": _derive_card_A37,
    "A29": _derive_card_A29,
    "A40": _derive_card_A40,
    "A45": _derive_card_A45,
    "A64": _derive_card_A64,
    "A66": _derive_card_A66,
    22: _derive_card_22,
    28: _derive_card_28,
    41: _derive_card_41,
    23: _derive_card_23,
    32: _derive_card_32,
    62: _derive_card_62,
    42: _derive_card_42,
    58: _derive_card_58,
    68: _derive_card_68,
    71: _derive_card_71,
}


def _control_keep_warbands(state, faction, region, *, leader_leaving):
    """Warbands to LEAVE in a Region so the Faction keeps Control after a
    March out (flowcharts: 'leave one Warband and enough not to remove
    Control'). The Leader, if leaving, no longer counts toward strength.
    """
    from fs_bot.rules_consts import WARBAND, FACTIONS
    from fs_bot.board.control import is_controlled_by
    total_wb = count_pieces(state, region, faction, WARBAND)
    if total_wb <= 0:
        return 0
    others = sum(count_pieces(state, region, of)
                 for of in FACTIONS if of != faction)
    own_nonwb = count_pieces(state, region, faction) - total_wb
    if leader_leaving:
        own_nonwb -= 1
    if is_controlled_by(state, region, faction):
        keep = max(1, others - own_nonwb + 1)
    else:
        keep = 1  # still leave at least one behind
    return min(total_wb, keep)


def plan_expand_march_moves(state, faction, plan):
    """Dry-run of an "expand/mass/spread/control" March (§8.6.5/§8.7.4-6/
    A8.7.5): compute the moves the executor would make, WITHOUT mutating
    state.

    Shared by _execute_expand_march (which applies the moves) and the bot
    March nodes (which consult it for their flowchart "IF NONE" edges — e.g.
    V_MARCH_MASS/V_MARCH_SPREAD redirect to Raid when nothing is marchable,
    §8.7.4/§8.7.6). One rule, one implementation.

    Returns:
        List of move dicts {"origin", "path", "group", "leader": bool}.
        Empty list when nothing can March (pinned by Control-keeping
        leave-behinds, no reachable destination, or no plan).
    """
    from fs_bot.rules_consts import LEADER, WARBAND, LEGION, AUXILIA
    from fs_bot.board.pieces import find_leader

    if not isinstance(plan, dict):
        return []

    # "destination" (singular) is the V_MARCH_MASS shape (§8.7.6): a Leader
    # march. It was previously unread, so every mass March was refused.
    leader_dests = [plan.get(k) for k in
                    ("leader_destination", "leader_or_group_destination",
                     "diviciacus_destination", "destination")
                    if isinstance(plan.get(k), str)]
    cs_dests = []
    cd = plan.get("control_destination")
    if isinstance(cd, str):
        cs_dests.append(cd)
    for key in ("control_destinations", "spread_destinations", "destinations"):
        for v in (plan.get(key) or []):
            if isinstance(v, str):
                cs_dests.append(v)
            elif isinstance(v, (list, tuple)) and v and isinstance(v[0], str):
                cs_dests.append(v[0])
    if not cs_dests and isinstance(plan.get("destination"), str):
        cs_dests.append(plan["destination"])

    origins = list(plan.get("origins") or [])
    o1 = plan.get("origin")
    if isinstance(o1, str) and o1 not in origins:
        origins.append(o1)

    scenario = state["scenario"]
    playable = set(get_playable_regions_for_state(state, faction))

    from fs_bot.commands.march import _max_steps_for_group

    def _nearest(origin, candidates, group):
        if origin not in playable:
            return None
        allowance = _max_steps_for_group(state, origin, faction, group)
        best = None
        for d in candidates:
            if d == origin:
                continue
            path = _bfs_march_path(origin, d, playable)
            if path is None or len(path) > allowance:
                continue
            if best is None or len(path) < best[0]:
                best = (len(path), d, path)
        return best

    moves, processed = [], set()

    # --- 1. Leader group march ---
    leader_region = find_leader(state, faction)
    if leader_region is not None:
        dests = leader_dests if leader_dests else cs_dests
        keep = _control_keep_warbands(state, faction, leader_region,
                                      leader_leaving=True)
        march_wb = max(0, count_pieces(state, leader_region, faction,
                                       WARBAND) - keep)
        group = {LEADER: get_leader_in_region(state, leader_region, faction),
                 WARBAND: march_wb, LEGION: 0, AUXILIA: 0}
        best = _nearest(leader_region, dests, group)
        if best is not None:
            moves.append({"origin": leader_region, "path": best[2],
                          "group": group, "leader": True,
                          "warbands": march_wb})
            processed.add(leader_region)

    # --- 2. Warband-only control-spreading from other origins ---
    for origin in origins:
        if origin in processed or not isinstance(origin, str):
            continue
        keep = _control_keep_warbands(state, faction, origin,
                                      leader_leaving=False)
        march_wb = max(0, count_pieces(state, origin, faction, WARBAND) - keep)
        if march_wb <= 0:
            continue
        group = {LEADER: None, WARBAND: march_wb, LEGION: 0, AUXILIA: 0}
        best = _nearest(origin, cs_dests, group)
        if best is None:
            continue
        moves.append({"origin": origin, "path": best[2], "group": group,
                      "leader": False, "warbands": march_wb})
        processed.add(origin)

    return moves


def _execute_expand_march(state, faction, plan, *, free=False):
    """Expand/mass/spread March uses the same origin billing as threat March."""
    return _execute_march_moves(state, faction,
                                plan_expand_march_moves(state, faction, plan),
                                free=free)


def _march_group_fixed(state, faction, origin, path, group):
    """March a specific group along a path (step by step), returning the final
    Region. Unlike _march_with_harassment this marches a CAPPED group (used for
    the Leader's expand/mass move with a Control-preserving Warband count)."""
    from fs_bot.commands.march import _max_steps_for_group
    if len(path) > _max_steps_for_group(state, origin, faction, group):
        raise CommandError("March route exceeds this group's movement allowance")
    current = origin
    for nxt in path:
        march_group(state, faction, current, [nxt], group, free=False)
        current = nxt
    return current
