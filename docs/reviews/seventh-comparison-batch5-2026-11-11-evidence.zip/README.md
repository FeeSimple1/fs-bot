# Seventh comparison Batch 5 validation

The repair was tested on parent `a0f58ad97b6b9fd38a64472f6e8747609f78be2e`
with Python 3.12.14. `source.json` identifies the tested Python bytes.
The seventh Batch 4 archive supplies the paired parent game records.
The seventh audit archive supplies the original Battle and Raid witnesses.
`SHA256SUMS` covers the archived files.

Run the verifier from the repaired repository root with its Python
environment active.

```sh
PYTHONPATH=. python /path/to/evidence/verify_results.py /path/to/evidence
```

The validation runs used these commands with fresh output paths.

```sh
PYTHONHASHSEED=0 python -m pytest -q -n 8 --junitxml=pytest.xml
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out bots-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 41-44 --card-edition second-edition --workers 2 --out bots-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
```

`balance-before.log` and `pytest-before.log` used `baseline-prior.json`
in the repository's baseline path. The final balance and pytest runs used
the reviewed Batch 5 baseline. The initial full pytest run used five
workers. The copied directed test file reproduces 17 failures and passes
30 controls when run on the parent. `directed.log` also includes the two
Retreat-refuge cases from `test_belgae_bot.py`. `audit-before.json`
matches the original witness script on the parent. Run `probe_after.py`
with `PYTHONPATH=.` from the repaired repository to reproduce the
after-repair witness output.

`first-changes.json` records both versions of each first changed card,
including the common pre-card board and RNG digests, Battle forecasts
and selected plans, and Raid entries. To reproduce the comparisons, run
`trace_bot_planning.py` with `trace-parent-input.json` and a fresh output
path on the parent checkout. Run the same script with
`trace-candidate-input.json`, a fresh output path, and the parent output
path on the repaired checkout. Use `PYTHONHASHSEED=0 PYTHONPATH=.` for
both invocations.
