"""Trace the paired outcomes that changed in the two verification matrices."""
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import sys

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, get_available
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.engine.execute import _derive_event_params
from fs_bot.cli.dispatcher import _translate_bot_action, make_decision_func
from fs_bot.engine.game_engine import ACTION_EVENT, get_sop_factions, play_card, start_game
from fs_bot.map.map_data import get_region_for_tribe_for_state
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.tools.validation_metadata import source_identity


def digest(value):
    return sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def trace(scenario, seed, edition):
    state = setup_scenario(scenario, seed=seed, card_edition=edition)
    state['non_player_factions'] = set(get_sop_factions(state))

    def balance_driver(live, faction, options, position):
        live['current_card_id'] = live.get('current_card')
        live['is_second_eligible'] = position == '2nd_eligible'
        live['can_play_event'] = ACTION_EVENT in options
        plan = dispatch_bot_turn(live, faction)
        return {'action': _translate_bot_action(plan, options), 'bot_action': plan}

    decide = (balance_driver if edition == 'legacy' else
              make_decision_func({}, stdin=StringIO(), stdout=StringIO(), pause=False))
    rows = []
    hostages = []

    def observed_driver(live, faction, options, position):
        if live['current_card'] == 22 and ACTION_EVENT in options:
            # The shaded deriver is deterministic and read-only.
            hostages.append({'faction': faction,
                             'available_allies': get_available(live, faction, rc.ALLY),
                             'targets': _derive_event_params(live, faction, 22, True)})
        return decide(live, faction, options, position)

    with redirect_stdout(StringIO()):
        start_game(state)
        while state['current_card'] is not None:
            hostages.clear()
            before = {'digest': digest(state), 'resources': dict(state['resources']),
                      'eligibility': dict(state['eligibility'])}
            old_allies = {tribe: info['allied_faction'] for tribe, info in state['tribes'].items()}
            result = play_card(state, observed_driver, execute=True)
            turn = result.get('turn_result') or {}
            rows.append({'card': result['card'], 'before': before,
                         'actions': {faction: {'action': action['action'],
                             'command': (action.get('bot_action') or {}).get('command'),
                             'side': (action.get('bot_action') or {}).get('details', {}).get('text_preference')}
                             for faction, action in turn.get('actions_taken', {}).items()},
                         'after': {'digest': digest(state), 'resources': dict(state['resources']),
                                   'eligibility': dict(state['eligibility'])},
                         'winner': result.get('winner')})
            if result['card'] == 22:
                rows[-1]['hostages_options'] = list(hostages)
                rows[-1]['changed_allies'] = [dict(tribe=tribe,
                    region=get_region_for_tribe_for_state(state, tribe), before=old_allies.get(tribe),
                    after=info['allied_faction']) for tribe, info in state['tribes'].items()
                    if info['allied_faction'] != old_allies.get(tribe)]
            if result['game_over']:
                break
    return rows


if __name__ == '__main__':
    tasks = [(rc.SCENARIO_RECONQUEST, 1, 'legacy'),
             (rc.SCENARIO_ARIOVISTUS, 17, 'legacy'),
             (rc.SCENARIO_GALLIC_WAR, 25, 'second-edition')]
    output = {'source': source_identity(), 'traces': [dict(scenario=s, seed=n, edition=e,
              cards=trace(s, n, e)) for s, n, e in tasks]}
    Path(sys.argv[1]).write_text(json.dumps(output, indent=2) + '\n')
