"""Unchanged behavior probes using only pre-repair APIs."""
import pytest
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece
from fs_bot.cards.capabilities import activate_capability, set_capability_owner
from fs_bot.engine.execute import _execute_battle
from fs_bot.state.state_schema import build_initial_state

REGIONS=(rc.TREVERI,rc.MANDUBII)
FLAGS=('card59_unshaded_region','card59_shaded_region')


def position(side=rc.EVENT_UNSHADED,role='attack'):
    st=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=23)
    owner=rc.ROMANS if side==rc.EVENT_UNSHADED else rc.BELGAE
    enemy=rc.BELGAE if owner==rc.ROMANS else rc.ROMANS
    attacker,defender=(owner,enemy) if role=='attack' else (enemy,owner)
    st['resources'][attacker]=10
    for i,r in enumerate(REGIONS):
        place_piece(st,r,rc.ROMANS,rc.AUXILIA,6 if i==0 else 4)
        place_piece(st,r,rc.BELGAE,rc.WARBAND,8 if i==0 else 6)
    activate_capability(st,59,side)
    if side==rc.EVENT_SHADED:set_capability_owner(st,59,owner)
    action={'sa':None,'sa_regions':[], 'details':{'battle_plan':[{'region':r,'target':defender} for r in REGIONS]}}
    return st,owner,attacker,action


def record(monkeypatch):
    rows=[]
    def battle(st,region,*args,**kwargs):
        rows.append((region,st.get('event_modifiers',{}).get(FLAGS[0]),st.get('event_modifiers',{}).get(FLAGS[1])))
        return {}
    monkeypatch.setattr('fs_bot.engine.execute.resolve_battle',battle)
    return rows


@pytest.mark.parametrize('side,role,selected',[
 (rc.EVENT_UNSHADED,'attack',REGIONS[1]),
 (rc.EVENT_SHADED,'attack',REGIONS[0]),
 (rc.EVENT_SHADED,'defense',REGIONS[1])])
def test_owner_selects_its_region(side,role,selected,monkeypatch):
    st,owner,attacker,action=position(side,role)
    seen=[]
    def agent(board,faction,request):
        if request['kind']=='horse_region':
            seen.append(faction)
            return {'region':selected}
    st['decision_agent']=agent
    rows=record(monkeypatch)
    _execute_battle(st,attacker,action)
    assert seen==[owner]
    index=1 if side==rc.EVENT_UNSHADED else 2
    assert all(row[index]==selected for row in rows)


def test_romans_decline_bonus(monkeypatch):
    st,owner,attacker,action=position()
    st['decision_agent']=lambda board,faction,request: {'decline':True} if request['kind']=='horse_region' else None
    rows=record(monkeypatch)
    _execute_battle(st,attacker,action)
    assert all(row[1] is None for row in rows)


def test_abatis_blocks_shaded_horse():
    from fs_bot.battle.resolve import _calculate_attack_losses
    from fs_bot.battle.losses import calculate_losses
    st=build_initial_state(rc.SCENARIO_ARIOVISTUS,seed=23)
    r=REGIONS[0]
    place_piece(st,r,rc.BELGAE,rc.WARBAND,8)
    place_piece(st,r,rc.AEDUI,rc.WARBAND,6)
    activate_capability(st,59,rc.EVENT_SHADED)
    set_capability_owner(st,59,rc.BELGAE)
    st.setdefault('event_modifiers',{})[FLAGS[1]]=r
    st.setdefault('markers',{}).setdefault(r,{})[rc.MARKER_ABATIS]=rc.AEDUI
    actual=_calculate_attack_losses(st,r,rc.BELGAE,rc.AEDUI,is_retreat=False,
        had_citadel_at_start=False,had_fort_at_start=False)
    estimate=calculate_losses(st,r,rc.BELGAE,rc.AEDUI)
    assert (actual,estimate)==(2,2)


def test_raw_interruption_clears_horse_flag(monkeypatch):
    st,owner,attacker,action=position()
    def pause(*args,**kwargs):raise EOFError
    monkeypatch.setattr('fs_bot.engine.execute.resolve_battle',pause)
    with pytest.raises(EOFError):_execute_battle(st,attacker,action)
    assert all(key not in st.get('event_modifiers',{}) for key in FLAGS)


def test_npc_uses_first_applicable_not_most_auxilia(monkeypatch):
    st,owner,attacker,action=position()
    action['details']['battle_plan'].reverse()
    rows=record(monkeypatch)
    _execute_battle(st,attacker,action)
    assert all(row[1]==REGIONS[1] for row in rows)


def test_single_region_default_control(monkeypatch):
    st,owner,attacker,action=position()
    action['details']['battle_plan']=action['details']['battle_plan'][:1]
    rows=record(monkeypatch)
    _execute_battle(st,attacker,action)
    assert rows==[(REGIONS[0],REGIONS[0],None)]


def test_uninvolved_owner_control(monkeypatch):
    st,owner,attacker,action=position(rc.EVENT_SHADED,'defense')
    set_capability_owner(st,59,rc.AEDUI)
    rows=record(monkeypatch)
    _execute_battle(st,attacker,action)
    assert all(row[2] is None for row in rows)
