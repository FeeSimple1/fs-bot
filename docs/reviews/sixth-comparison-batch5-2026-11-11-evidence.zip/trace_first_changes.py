"""Trace the first changed card and the bot checks that preceded it."""

from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from contextlib import ExitStack, redirect_stdout
from functools import wraps
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import sys
from unittest.mock import patch

from fs_bot.bots import aedui_bot, arverni_bot, belgae_bot, roman_bot
from fs_bot.cli.dispatcher import make_decision_func
from fs_bot.engine.game_engine import get_sop_factions, play_card, start_game
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.tools.validation_metadata import source_identity


def digest(value):
    return sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def board_digest(state):
    return digest({key: value for key, value in state.items() if key != 'decision_agent'})


def game_key(row):
    return tuple(row[field] for field in ('scenario', 'seed', 'card_edition'))


def trace(task):
    row, parent = task
    scenario, seed, edition = game_key(row)
    state = setup_scenario(scenario, seed=seed, card_edition=edition)
    state['non_player_factions'] = set(get_sop_factions(state))
    bot = make_decision_func({}, stdin=StringIO(), stdout=StringIO(), pause=False)
    decisions, checks, cards = [], [], []

    def decide(board, faction, options, position):
        decision = bot(board, faction, options, position)
        decisions.append(dict(faction=faction, position=position, decision=encode(decision)))
        return decision

    def wrap(name, original, context):
        @wraps(original)
        def tracked(board, *args, **kwargs):
            value = original(board, *args, **kwargs)
            region, target = context(*args)
            if region is not None:
                checks.append(encode(dict(check=name, region=region, target=target,
                    result=value, scenario=board['scenario'], ambush=kwargs.get('ambush_possible'),
                    morasses=bool(board.get('_morasses_ambush')),
                    pieces=board['spaces'][region].get('pieces', {}),
                    capabilities=board.get('capabilities', {}),
                    modifiers=board.get('event_modifiers', {}))))
            return value
        return tracked

    def battle_target(region, scenario, enemy):
        return region, enemy

    def high_value_target(region, attacker, defender, scenario):
        return region, defender

    def rampage_target(region, scenario):
        return region, None

    def ambush_target(plan, scenario):
        return (plan[0]['region'], plan[0]['target']) if plan else (None, None)

    hooks = (
        (belgae_bot, '_can_battle_in_region', 'Belgic Battle comparison', battle_target),
        (belgae_bot, '_check_ambush', 'Belgic Ambush forecast', ambush_target),
        (arverni_bot, '_can_battle_in_region', 'Arverni Battle comparison', battle_target),
        (aedui_bot, '_would_force_loss_on_high_value', 'Aedui high-value target', high_value_target),
        (roman_bot, '_has_roman_threat', 'Roman threat', rampage_target),
    )
    with ExitStack() as stack:
        stack.enter_context(redirect_stdout(StringIO()))
        for module, symbol, name, context in hooks:
            stack.enter_context(patch.object(module, symbol, wrap(name, getattr(module, symbol), context)))
        start_game(state)
        for draw in range(1, 201):
            checks.clear()
            decisions.clear()
            before = board_digest(state)
            rng = digest(state['rng'].getstate())
            result = play_card(state, decide, execute=True)
            card = dict(draw=draw, card=result['card'], before=before, rng_before=rng,
                        after=board_digest(state), decisions=list(decisions), checks=list(checks))
            if parent is not None:
                prior = parent['cards'][draw - 1]
                assert (prior['card'], prior['before'], prior['rng_before']) == (card['card'], before, rng)
                if prior['after'] != card['after']:
                    return difference(row, parent, prior, card)
            else:
                cards.append(card)
            if result['game_over']:
                break
    if parent is not None:
        raise AssertionError(f'No first change for {game_key(row)}')
    assert (result['winner'], draw, card['after']) == (row['winner'], row['cards'], row['final_state_sha256'])
    return dict(scenario=scenario, seed=seed, card_edition=edition, winner=row['winner'], cards=cards)


def check_key(check):
    return digest({key: value for key, value in check.items() if key != 'result'})


def difference(row, parent, prior, card):
    old_checks = {check_key(check): check for check in prior['checks']}
    changes = {}
    for current in card['checks']:
        key = check_key(current)
        old = old_checks.get(key)
        if old is not None and old['result'] != current['result']:
            changes[key] = {**current, 'prior_result': old['result']}
    return dict(scenario=row['scenario'], seed=row['seed'], card_edition=row['card_edition'],
                prior_winner=parent['winner'], current_winner=row['winner'],
                draw=card['draw'], card=card['card'], same_start=card['before'],
                same_rng=card['rng_before'], checks=list(changes.values()),
                prior_decisions=prior['decisions'], current_decisions=card['decisions'])


def main(inputs, output, parent_file=None):
    rows = json.loads(Path(inputs).read_text())
    parents = {}
    if parent_file:
        parents = {game_key(row): row for row in json.loads(Path(parent_file).read_text())['games']}
    with ProcessPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(trace, ((row, parents.get(game_key(row))) for row in rows)))
    Path(output).write_text(json.dumps(dict(source=source_identity(), games=results), indent=2) + '\n')
    if parent_file:
        reasons = Counter(check['check'] for row in results for check in row['checks'])
        unmatched = [game_key(row) for row in results if not row['checks']]
        print(f'{len(results)} first changed cards with matching starting boards and RNG')
        print('Changed checks:', dict(reasons))
        print('Cases without a matching changed check:', unmatched)
    else:
        print(f'{len(results)} parent replays match the audited winners, lengths and final boards')


if __name__ == '__main__':
    main(*sys.argv[1:])
