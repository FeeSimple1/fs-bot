"""Read retained trajectories to report actual optional-rule exercise."""
from collections import Counter
import json
import sys
from pathlib import Path

root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent/'optional-diviciacus'
metadata=json.loads((root/'metadata.json').read_text())
counts=Counter()
games=[]
records=[json.loads(line) for line in (root/'games.jsonl').read_text().splitlines()]
for record in sorted(records,key=lambda r:(r['scenario'],r['card_edition'],r['seed'])):
    data=json.loads((root/record['artifact']).read_text())
    local=Counter(o38_cards_resolved=0)
    for card in data['card_results']:
        local['o38_cards_resolved'] += card.get('card') == 'O38'
        for turn in ((card.get('turn_result') or {}).get('actions_taken') or {}).values():
            action=turn.get('bot_action') or {}
            execution=turn.get('execution') or {}
            if (execution.get('card_id')=='O38' and execution.get('executed') is True
                    and execution.get('shaded') is False):
                local['o38_unshaded_executions'] += 1
            if (action.get('details') or {}).get('diviciacus_regions'):
                local['commands_planned_with_cooperation'] += 1
    counts.update(local)
    counts['games_with_cooperation_plans'] += bool(local['commands_planned_with_cooperation'])
    counts['games_with_o38_unshaded_execution'] += bool(local['o38_unshaded_executions'])
    counts['games_with_leader_at_end'] += any(
        (space.get('pieces') or {}).get('Aedui',{}).get('Leader')=='Diviciacus'
        for space in (data['final_state'] or {}).get('spaces',{}).values())
    games.append({key:record[key] for key in ('scenario','card_edition','seed')} | {'counts':dict(local)})
report={'source_sha256':metadata['source']['source_sha256'],'counts':dict(counts),'games':games}
(root/'feature_coverage.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'games':len(games),'counts':dict(counts)}))
