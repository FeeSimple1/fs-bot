"""Compare every recorded bot field except timing and injected provenance."""
import argparse
import json
from pathlib import Path
import sys

REPO = Path('/workspace/scratch/534c265c65f4/fs-bot')
sys.path.insert(0, str(REPO))
from fs_bot.tools.run_batch import SCENARIOS
from fs_bot.tools.validation_metadata import source_identity


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-source', required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    ignored = {'seconds', 'commit', 'source_sha256'}
    replay = [json.loads(line) for line in (root / 'bot-hash7-repeats.jsonl').read_text().splitlines()]
    editions = ('legacy', 'original', 'second-edition')
    expected = {(edition, scenario, seed) for edition in editions for scenario in SCENARIOS
                for seed in range(201, 206)}
    key = lambda record: (record['card_edition'], record['scenario'], record['seed'])
    replay_keys = [key(record) for record in replay]
    findings, differences, matched = [], [], []
    if len(replay) != 75 or set(replay_keys) != expected or len(set(replay_keys)) != len(replay):
        findings.append('Replay does not contain exactly the requested 75 unique games')
    for edition in editions:
        path = root / (edition + '-heldout-500') / 'games.jsonl'
        candidates = [json.loads(line) for line in path.read_text().splitlines()]
        selected = [record for record in candidates if key(record) in expected]
        bykey = {key(record): record for record in selected}
        if len(selected) != 25 or len(bykey) != 25:
            findings.append(f'{edition}: reference coverage is not exactly 25 unique requested games')
        for right in replay:
            if right['card_edition'] != edition:
                continue
            identity = key(right)
            left = bykey.get(identity)
            if left is None:
                findings.append(f'Missing reference {identity}')
                continue
            for label, record in [('hash0', left), ('hash7', right)]:
                if record.get('source_sha256') != args.expected_source:
                    findings.append(f'{label} {identity} unexpected source digest')
                if record.get('completed') is not True:
                    findings.append(f'{label} {identity} not accepted')
            normalized_left = {k: v for k, v in left.items() if k not in ignored}
            normalized_right = {k: v for k, v in right.items() if k not in ignored}
            if normalized_left != normalized_right:
                fields = []
                for field in sorted(set(normalized_left) | set(normalized_right)):
                    if (field not in normalized_left or field not in normalized_right
                            or normalized_left[field] != normalized_right[field]):
                        fields.append(dict(field=field,
                            hash0_present=field in normalized_left, hash7_present=field in normalized_right,
                            hash0=normalized_left.get(field), hash7=normalized_right.get(field)))
                differences.append(dict(card_edition=edition, scenario=identity[1], seed=identity[2],
                                        fields=fields))
            else:
                matched.append(identity)
    current_source = source_identity()
    if current_source['source_sha256'] != args.expected_source:
        findings.append('Source changed before comparison completed')
    result = dict(source=current_source, expected_games=75, matched_games=len(matched),
                  ignored_fields=sorted(ignored), findings=findings, differences=differences)
    (root / 'bot-hash-comparison.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    return 0 if len(matched) == 75 and not findings and not differences else 1


if __name__ == '__main__':
    raise SystemExit(main())
