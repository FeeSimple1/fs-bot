"""Read-only Litaviccus checkpoints around the audited run_batch.play_one path.

Only a live game's Litaviccus decisions/Battle retain board inputs/deltas. Other card
boundaries retain hashes. No RNG is consumed and previews are excluded by
identity with the setup object. Output is exclusive-create and source-bound.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import platform
import sys


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True,
                                    separators=(',', ':')).encode()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', required=True)
    parser.add_argument('--scenario', required=True)
    parser.add_argument('--seed', type=int, required=True)
    parser.add_argument('--edition', required=True, choices=('legacy', 'original', 'second-edition'))
    parser.add_argument('--expected-source', required=True)
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    assert os.environ.get('PYTHONHASHSEED') == '0'
    sys.path.insert(0, args.repo)
    from fs_bot.engine import execute as phase
    from fs_bot.state.serialize import encode
    from fs_bot.tools import run_batch as batch
    from fs_bot.tools.validation_metadata import source_identity

    identity = source_identity()
    assert identity['source_sha256'] == args.expected_source, identity
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    live = None
    card_index = 0
    checkpoints = 0
    stage_counts = {}
    trace = gzip.open(out / 'trace.jsonl.gz', 'xt', encoding='utf-8')

    def snapshot(state):
        encoded = encode({key: value for key, value in state.items()
                          if key != 'decision_agent'})
        rng = encoded.pop('rng')
        return encoded, rng

    def record(stage, state, *, full=False, **extras):
        nonlocal checkpoints
        board, rng = snapshot(state)
        row = dict(index=checkpoints, card_index=card_index,
                   current_card=state.get('current_card'), stage=stage,
                   board_sha256=digest(board), rng_sha256=digest(rng),
                   **encode(extras))
        if full:
            row.update(board=board, rng=rng)
        trace.write(json.dumps(row, sort_keys=True) + '\n')
        checkpoints += 1
        stage_counts[stage] = stage_counts.get(stage, 0) + 1
        return board, rng

    original_setup = batch.setup_scenario

    def setup(*a, **kw):
        nonlocal live
        live = original_setup(*a, **kw)
        return live

    batch.setup_scenario = setup
    original_card = batch.play_card

    def card(state, *a, **kw):
        nonlocal card_index
        card_index += 1
        record('card-before', state, full=state.get('current_card') == 45)
        result = original_card(state, *a, **kw)
        record('card-after', state)
        return result

    batch.play_card = card

    def install(name):
        original = getattr(phase, name)

        def wrapped(state, *a, **kw):
            if state is not live:
                return original(state, *a, **kw)
            before, _ = record(name + '-before', state, full=True,
                               args=a, kwargs=kw)
            result = original(state, *a, **kw)
            after, _ = snapshot(state)
            changes = {key: {'before': before.get(key), 'after': after.get(key)}
                       for key in sorted(set(before) | set(after))
                       if before.get(key) != after.get(key)}
            record(name + '-after', state, result=result, changes=changes)
            return result

        setattr(phase, name, wrapped)

    install('_resolve_card45_battle')

    original_make_decision = batch.make_decision_func

    def make_decision(*args, **kwargs):
        original = original_make_decision(*args, **kwargs)
        def decision(state, faction, options, position):
            if state is not live or state.get('current_card') != 45:
                return original(state, faction, options, position)
            record('decision-before', state, full=True, faction=faction,
                   options=options, position=position)
            result = original(state, faction, options, position)
            record('decision-after', state, result=result, faction=faction)
            return result
        return decision

    batch.make_decision_func = make_decision
    try:
        result = batch.play_one((args.scenario, args.seed, args.edition))
    finally:
        trace.close()
    after_identity = source_identity()
    assert after_identity['source_sha256'] == args.expected_source, after_identity
    summary = dict(source=identity, source_after=after_identity,
                   python=platform.python_version(), hash_seed='0',
                   checkpoints=checkpoints, stage_counts=stage_counts,
                   command=sys.argv, result=result,
                   trace_sha256=hashlib.sha256((out / 'trace.jsonl.gz').read_bytes()).hexdigest())
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({'scenario': args.scenario, 'seed': args.seed, 'edition': args.edition,
                      'winner': result.get('winner'), 'cards': result.get('cards'),
                      'completed': result.get('completed'), 'checkpoints': checkpoints}))
    assert result['completed'], result


if __name__ == '__main__':
    main()
