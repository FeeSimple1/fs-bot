"""One bounded partial diagnostic; never an extra acceptance sample."""
from collections import Counter
from pathlib import Path
import argparse
import json
import os
import platform
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'fs-bot'))
from integration_matrix import identity, protected_files
from fs_bot.tools import player_fuzz as fuzz

parser = argparse.ArgumentParser()
parser.add_argument('--attempt', required=True)
parser.add_argument('--scenario', required=True)
parser.add_argument('--seed', type=int, required=True)
parser.add_argument('--edition', default='legacy')
parser.add_argument('--expected-source-sha', required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
assert platform.python_version() == '3.10.22' and os.environ.get('PYTHONHASHSEED') == '0'
assert not args.out.exists(), 'Use a new evidence label; never overwrite diagnostics'
before = identity()
protected = protected_files()
assert before['python_sha256'] == args.expected_source_sha
matrix = json.loads((HERE / args.attempt / f'fuzz-{args.edition}-0.json').read_text())
expected_record = next(r for r in matrix['records'] if r['scenario'] == args.scenario and r['seed'] == args.seed)
assert expected_record['partial'] > 0 and not expected_record['findings']
partials = []
original = fuzz._compare_dry_vs_live


def compare(res, seats, expected):
    occurrences = Counter()
    for card in (res or {}).get('card_results', ()):
        for faction, record in ((card.get('turn_result') or {}).get('actions_taken') or {}).items():
            if faction not in seats:
                continue
            key = (card.get('card'), faction)
            occurrence = occurrences[key]
            occurrences[key] += 1
            wanted = expected.get(key + (occurrence,))
            actual = fuzz._sig(record.get('execution'))
            if actual is not None and actual == wanted and (wanted[3] or (wanted[4] and wanted[4][1])):
                partials.append({'card': card.get('card'), 'faction': faction, 'occurrence': occurrence,
                                 'expected_signature': wanted, 'actual_signature': actual, 'record': record})
    return original(res, seats, expected)


fuzz._compare_dry_vs_live = compare
result = fuzz.play_game(args.scenario, args.seed, card_edition=args.edition)
after = identity()
assert before == after and protected_files() == protected
assert result == expected_record, 'Instrumented diagnostic must reproduce the complete accepted record exactly'
assert len(partials) == result['partial']
data = {'scope': 'One bounded diagnostic replay, not independent acceptance evidence.',
        'python': platform.python_version(), 'hash_seed': 0, 'diagnostic_games': 1,
        'source': {key: value for key, value in before.items() if key != 'files'},
        'source_manifest_before': before, 'source_manifest_after': after,
        'source_unchanged': True, 'protected_inputs_unchanged': 49,
        'matched_matrix_record_exactly': True, 'matrix_attempt': args.attempt,
        'game': result, 'partials': fuzz._sanitize(partials)}
args.out.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps({key: data[key] for key in ('scope', 'python', 'diagnostic_games', 'matched_matrix_record_exactly', 'game', 'partials')}, indent=2))
