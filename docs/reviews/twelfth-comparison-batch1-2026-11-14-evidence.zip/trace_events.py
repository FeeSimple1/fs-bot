"""Replay a game through public entry points and record relevant Event effects."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from contextlib import redirect_stdout
import hashlib
from io import StringIO
import json
from pathlib import Path
import sys


def trace(case):
    from fs_bot import rules_consts as rc
    from fs_bot.board.pieces import count_pieces
    from fs_bot.cli.dispatcher import make_decision_func
    from fs_bot.engine import execute
    from fs_bot.engine.game_engine import get_sop_factions, play_card, start_game
    from fs_bot.state.serialize import encode
    from fs_bot.state.setup import setup_scenario
    from fs_bot.tools.seat_session import fingerprint

    edition, scenario, seed = case
    state = setup_scenario(scenario, seed=seed, card_edition=edition)
    state['non_player_factions'] = set(get_sop_factions(state))
    bot = make_decision_func({}, stdin=StringIO(), stdout=StringIO(), pause=False)
    cards = []
    decisions = []

    def encode_board(board):
        return encode({key: value for key, value in board.items() if key != 'decision_agent'})

    def decide(board, faction, options, position):
        before = fingerprint(encode_board(board))
        decision = bot(board, faction, options, position)
        decisions.append({
            'faction': faction, 'options': options, 'before': before,
            'decision': decision, 'after_planning_rng': fingerprint(board['rng']),
        })
        return decision

    def event_snapshot():
        return {
            'scenario': state['scenario'],
            'non_player_factions': sorted(state['non_player_factions']),
            'resources': state['resources'].copy(),
            'devastated': sorted(region for region, markers in state['markers'].items()
                                 if rc.MARKER_DEVASTATED in markers),
            'pieces': {
                region: {faction: count_pieces(state, region, faction)
                         for faction in rc.FACTIONS}
                for region in state['spaces']
            },
            'citadels': {
                faction: sum(count_pieces(state, region, faction, rc.CITADEL)
                             for region in state['spaces'])
                for faction in rc.GALLIC_FACTIONS
            },
        }

    original_execute = execute.execute_decision

    def record_execution(board, faction, decision):
        watched = board['current_card'] in (24, 49)
        if watched:
            row = decisions[-1]
            assert row['faction'] == faction
            row['before_execution'] = fingerprint(encode_board(board))
            row['before_effects'] = event_snapshot()
        result = original_execute(board, faction, decision)
        if watched:
            row['after_execution'] = fingerprint(encode_board(board))
            row['after_effects'] = event_snapshot()
        return result

    execute.execute_decision = record_execution
    try:
        with redirect_stdout(StringIO()):
            start_game(state)
            while state['current_card'] is not None:
                card = state['current_card']
                row = {'card': card, 'before': fingerprint(encode_board(state))}
                result = play_card(state, decide, execute=True)
                row['after'] = fingerprint(encode_board(state))
                row['decisions'] = decisions[:]
                decisions.clear()
                if card in (24, 49):
                    row['actions'] = encode(result['turn_result']['actions_taken'])
                cards.append(row)
                if result['game_over']:
                    break
    finally:
        execute.execute_decision = original_execute
    final = hashlib.sha256(json.dumps(encode_board(state), sort_keys=True).encode()).hexdigest()
    return {'edition': edition, 'scenario': scenario, 'seed': seed, 'cards': cards,
            'winner': result['winner'], 'final_state_sha256': final}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--cases', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo.resolve()))
    cases = json.loads(args.cases.read_text())
    with ProcessPoolExecutor(max_workers=2) as pool, args.out.open('w') as output:
        for row in pool.map(trace, cases):
            output.write(json.dumps(row, sort_keys=True) + '\n')


if __name__ == '__main__':
    main()
