# Independent review of Battle and lifecycle partitions

Reviewed unchanged commit `c67d501711471bf790d805c017c2125b2c254639` and source SHA-256 `2ae5b3cedb16cfed6969442ebe9fefba99ed0f03933cd30c78a4deb6c002e801`.

Accepted BM7-01 (high), BM7-02 (medium), and WS7-01 (high) after reading the final ledgers, supplied rules, implementation consumers, prior audit records, and reproducing the final probes. All fifteen Battle cases and seventeen lifecycle cases passed their observed-defect/control assertions. Independent stdout files `battle-final-rerun.json` and `lifecycle-rerun.json` match their respective recorded outputs byte-for-byte.

BM7-01 has a particularly clean Event2 control with no Legion, making the card-specific first-Legion exception inert. Missing Slingers changes casualties in both Event and full automatic Arverni paths; the separate shaded Horse case confirms the shared orchestration omission. BM7-02 activates A31 after Ballistae and independently predicts the single die roll of3 on copied RNG, proving the Fort-save difference without altering live randomness. The non-German control retains the legitimate protection.

WS7-01 crosses all four non-Roman seated NPCs and demonstrates both mandatory escape and Leader consolidation. Exact legal relocation controls and a no-escape control distinguish missing bot planning from a relocation validator error. The full Winter witness starts with actual Pax Gallica setup, whose first Germans Phase is lawfully skipped. All relevant before/after census and structure assertions pass; permanent Provincia Fort and Tribe ownership restrictions remain valid.

No prior comparison ledger counts these consumers. BM6-02 expressly left the Arverni/fixed-Event paths as uncounted static risks. Other Phalanx repairs covered different capabilities or loss calculations. Earlier human Quarters choice work does not wire the four orphaned bot planners. The lifecycle comparator section label was corrected from D to C for the standard-pipeline pattern.

The controlled fixtures establish reproducible defects, not natural-game frequency or aggregate balance effects. No production or protected-reference edits were made. Baseline validation independently passed the full 9,991-test suite, twenty audited second-edition bot games, and exact replay of twenty mixed-player cases across two hash seeds; its evidence is under `validation/`.
