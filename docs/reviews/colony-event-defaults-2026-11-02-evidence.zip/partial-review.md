# Independent review of the two soft partials

Both cases are the fuzzer's documented policy-error category, not new engine
divergences. A random outgoing Resource gift is injected after the policy has
built its Rally plan. That gift leaves enough Resources for the first Region
but not the remaining Regions. The engine charges and resolves the first
Region, refuses the unaffordable Regions, and reports identical dry/live
results. Both games finish with zero hard findings and valid state integrity.

| Scenario and seed | Card and owner | Executed portion | Refused portion |
|---|---|---|---|
| Ariovistus, 39 | A43, Aedui | Transfer four Resources to Germans; Rally Warbands in Mandubii | Rally Warbands in Treveri and Aedui: zero Resources, one needed |
| The Gallic War, 1 | A37, Aedui | Transfer one Resource to Belgae; Rally Warbands in Mandubii | Rally Warbands in Aedui: zero Resources, one needed |

These are ordinary Commands selected on those Event cards, not executions of
the Events themselves. They use the older Region-only Rally plan with no exact
counts or ordered-step commitment. `execute_decision` explicitly distinguishes
that contract from exact human Recruit/Rally plans, which are atomic on an
error. No region is resolved without paying its cost; no additional piece is
placed for the refused portions.

The source basis is Chapter 1 §1.5.2 (Resource transfers during a Command),
Chapter 3 §3.1 (the acting faction must pay, selecting/resolving/paying Regions
in its chosen order), and §3.3.1 (Rally's per-Region cost). The fuzzer documents
matching dry/live sub-action errors as soft partials, and `_inject_transfer`
deliberately alters already-built plans. This review does not use Event partial
execution §5.1.3 to justify partial Command behavior.

`inspect_partials.py` wraps only the diagnostic comparison, without editing
production. Each of the two cases was run once under Python 3.12/hash seed 0;
`partial-Ariovistus-39.json` and `partial-Gallic-War-1.json` retain the exact
selected plans, dry/live signatures, results, and unchanged per-file source
manifest at commit `3873ff97505194557e1ed63b833d7bf2e5317fdc`. Their game
digests match the corresponding accepted local before-hash records. These two
bounded diagnostic runs are not independent acceptance samples or a Python
3.10 reproduction of the separate CI hash-seed failure.
