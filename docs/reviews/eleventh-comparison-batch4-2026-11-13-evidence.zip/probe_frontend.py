"""UI11-01: compare Winter Campaign borrowing and the established controls."""
import argparse
import copy
import io
import json
import pathlib
import sys
import tempfile

p = argparse.ArgumentParser()
p.add_argument('--repo', required=True)
p.add_argument('--repaired', action='store_true')
args = p.parse_args()
sys.path.insert(0, str(pathlib.Path(args.repo).resolve()))

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces_by_state
from fs_bot.cli.display import HumanTurnDisplay
from fs_bot.cli.human_plan import collect_player_action
from fs_bot.cli.reactive import make_cli_reactive
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT, ACTION_COMMAND_SA, _action_transaction
from fs_bot.engine.winter_campaign import winter_campaign_after_harvest, validate_human_plan
from fs_bot.commands.sa_enlist import BORROW_KEY
from fs_bot.state.serialize import encode, decode, save_game, load_game
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.tools.seat_session import SeatSession, DecisionPending, board_copy


def check(state):
    result = {'census': validate_state(state), 'structure': check_structural_integrity(state)}
    assert result == {'census': [], 'structure': []}, result
    return result


def fixture(scenario):
    state = build_initial_state(scenario, seed=1)
    ario = scenario in rc.ARIOVISTUS_SCENARIOS
    card = 'A63' if ario else 63
    state['current_card'] = card
    state['non_player_factions'] = ({rc.ROMANS, rc.AEDUI, rc.GERMANS} if ario
                                    else {rc.ROMANS, rc.ARVERNI, rc.AEDUI})
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    place_piece(state, rc.CARNUTES, rc.BELGAE, rc.LEADER,
                leader_name=rc.BODUOGNATUS if ario else rc.AMBIORIX)
    place_piece(state, rc.CARNUTES, rc.GERMANS, rc.WARBAND, 2)
    event = execute_decision(state, rc.BELGAE, {
        'action': ACTION_EVENT, 'player_action': {'command': rc.FIRST_DID_EVENT, 'details': {
            'card_id': card, 'text_preference': rc.EVENT_SHADED,
            'event_params': {'faction': rc.BELGAE}}}})
    assert event['executed'] and event['shaded']
    check(state)
    return state


def physical(state):
    return {'belgic_resources': state['resources'][rc.BELGAE],
            'germans': {region: {ps: count_pieces_by_state(state, region, rc.GERMANS,
                                                        rc.WARBAND, ps)
                                 for ps in (rc.HIDDEN, rc.REVEALED, rc.SCOUTED)}
                        for region in (rc.CARNUTES, rc.MANDUBII)}}


def borrow_plan(scenario):
    enlist = {'type': 'borrow', 'regions': [rc.CARNUTES]}
    if scenario in rc.ARIOVISTUS_SCENARIOS:
        enlist['warbands'] = {rc.CARNUTES: {rc.HIDDEN: 2, rc.REVEALED: 0, rc.SCOUTED: 0}}
    return {'command': rc.CMD_RAID, 'sa': rc.SA_ENLIST,
            'sa_regions': [rc.CARNUTES], 'sa_timing': 'before',
            'details': {'enlist': enlist, 'raid_plan': [
                {'region': rc.CARNUTES, 'target': None, 'physical_owner': rc.GERMANS},
                {'region': rc.CARNUTES, 'target': None, 'physical_owner': rc.GERMANS}]}}


def blocked_terminal(scenario):
    state = fixture(scenario)
    before = encode(board_copy(state))
    out = io.StringIO()
    lines = ['Special Ability: Enlist', 'lend Warbands to the Belgic Command', rc.CARNUTES]
    if scenario in rc.ARIOVISTUS_SCENARIOS:
        lines.append('1')  # First displayed choice is all two Hidden Germans.
    lines.append('Finish Winter Campaign')
    source = io.StringIO('\n'.join(lines) + '\n')
    state['decision_agent'] = make_cli_reactive([rc.BELGAE], source, out)
    result = winter_campaign_after_harvest(state)
    transcript = out.getvalue()
    assert 'Invalid Winter Campaign plan: Unknown free Enlist sub-Command' in transcript
    assert result['actions'] == [] and result['remaining_actions'] == 2
    assert not source.read()
    assert encode(board_copy(state)) == before
    return {'scenario': scenario, 'transcript': transcript, 'result': result,
            'physical': physical(state), 'board_and_rng_unchanged': True,
            'integrity': check(state)}


def repaired_terminal(scenario):
    state = fixture(scenario)
    before = encode(board_copy(state))
    out = io.StringIO()
    lines = ['Command + Enlist (both actions)', rc.CMD_RAID, rc.CARNUTES]
    if scenario in rc.ARIOVISTUS_SCENARIOS:
        lines.append('1')
    lines += [rc.CARNUTES, 'Gain 1 Resource', 'Gain 1 Resource']
    source = Terminal(out, lines)
    terminal = make_cli_reactive([rc.BELGAE], source, out)
    collected = []

    def agent(board, owner, request):
        response = terminal(board, owner, request)
        if request['kind'] == 'winter_campaign':
            collected.append((request['remaining_actions'], encode(board_copy(board))))
        return response

    agent.supports_action_windows = True
    state['decision_agent'] = agent
    result = winter_campaign_after_harvest(state)
    assert collected == [(2, before)]
    assert result['remaining_actions'] == 0 and len(result['actions']) == 1
    action = result['actions'][0]
    assert action['actions'] == 2 and action['result']['executed']
    assert action['result']['sa_execution']['type'] == 'borrow'
    assert action['result']['sa_execution']['executed']
    expected = borrow_plan(scenario)
    for key, value in expected['details'].items():
        assert action['plan']['details'][key] == value, (key, action['plan'])
    assert state['resources'][rc.BELGAE] == 2
    assert count_pieces_by_state(state, rc.CARNUTES, rc.GERMANS, rc.WARBAND, rc.REVEALED) == 2
    assert BORROW_KEY not in state and next(source.lines, None) is None
    return {'scenario': scenario, 'transcript': out.getvalue(), 'result': result,
            'physical': physical(state), 'planning_board_unchanged': True,
            'integrity': check(state)}


def durable_control(scenario):
    state = fixture(scenario)
    plan = borrow_plan(scenario)
    assert validate_human_plan(state, rc.BELGAE, plan) == 2
    before = encode(board_copy(state))
    session = SeatSession(state, {'seat': rc.BELGAE}, [], HumanTurnDisplay(io.StringIO()))
    state['decision_agent'] = session.reactive

    def attempt(current_session):
        def driver(*unused): pass
        driver.transaction_checkpoint = current_session.checkpoint
        driver.transaction_restore = current_session.restore
        driver.transaction_complete = current_session.transaction_complete
        with _action_transaction(current_session.state, driver):
            return winter_campaign_after_harvest(current_session.state)

    try:
        attempt(session)
        raise AssertionError('Missing human response must pause')
    except DecisionPending:
        pass
    pending = copy.deepcopy(session.data['pending'])
    assert decode(pending['request'])['kind'] == 'winter_campaign'
    assert encode(board_copy(state)) == before
    with tempfile.TemporaryDirectory() as folder:
        path = pathlib.Path(folder) / 'save.json'
        save_game(state, path, meta=session.meta, log=session.log)
        state, meta, log = load_game(path, validate=True)
    session = SeatSession(state, meta, log, HumanTurnDisplay(io.StringIO()))
    state['decision_agent'] = session.reactive
    assert session.data['pending'] == pending
    session.import_inbox({'decision_id': pending['id'], 'response': plan})
    result = attempt(session)
    session.finish()
    assert len(result['actions']) == 1 and result['actions'][0]['actions'] == 2
    assert result['remaining_actions'] == 0
    assert result['actions'][0]['result']['sa_execution']['type'] == 'borrow'
    assert state['resources'][rc.BELGAE] == 2
    assert count_pieces_by_state(state, rc.CARNUTES, rc.GERMANS, rc.WARBAND, rc.REVEALED) == 2
    assert any(decode(entry['assistant_response']) == plan for entry in log)
    return {'scenario': scenario, 'accepted_plan': plan, 'result': result,
            'physical': physical(state), 'pending_id_preserved_after_reload': True,
            'accepted_plan_retained_in_history': True, 'integrity': check(state)}


def free_german_control(scenario):
    state = fixture(scenario)
    out = io.StringIO()
    source = io.StringIO('Special Ability: Enlist\nMarch\nCarnutes\nMandubii\n1\nFinish Winter Campaign\n')
    state['decision_agent'] = make_cli_reactive([rc.BELGAE], source, out)
    result = winter_campaign_after_harvest(state)
    assert result['remaining_actions'] == 1 and len(result['actions']) == 1
    assert result['actions'][0]['result']['type'] == 'german_march'
    assert count_pieces_by_state(state, rc.MANDUBII, rc.GERMANS, rc.WARBAND, rc.HIDDEN) == 2
    assert not source.read()
    if args.repaired:
        transcript = out.getvalue()
        assert 'lend Warbands to the Belgic Command' not in transcript
        assert transcript.count('Command + Enlist (both actions)') == 1
    return {'scenario': scenario, 'result': result, 'physical': physical(state),
            'integrity': check(state)}


class Terminal:
    """Script player menu answers; explicitly decline optional own removals."""
    def __init__(self, out, lines):
        self.out, self.lines, self.offset = out, iter(lines), 0
        self.answers = []

    def readline(self):
        new = self.out.getvalue()[self.offset:]
        self.offset = len(self.out.getvalue())
        if 'Voluntary removal?' in new:
            answer = 'Use default (remove no pieces)'
        else:
            answer = next(self.lines, None)
            if answer is None:
                return ''
        self.answers.append(answer)
        return answer + '\n'


def ordinary_terminal_control(scenario):
    state = fixture(scenario)
    initial = encode(board_copy(state))
    out = io.StringIO()
    lines = ['Command first, with borrowed German Warbands', 'Raid', rc.CARNUTES]
    if scenario in rc.ARIOVISTUS_SCENARIOS:
        lines.append('1')
    lines += [rc.CARNUTES, 'Gain 1 Resource', 'Gain 1 Resource']
    source = Terminal(out, lines)
    state['decision_agent'] = make_cli_reactive([rc.BELGAE], source, out)
    plan = collect_player_action(state, rc.BELGAE, ACTION_COMMAND_SA, source, out)
    assert encode(board_copy(state)) == initial
    result = execute_decision(state, rc.BELGAE,
                              {'action': ACTION_COMMAND_SA, 'player_action': plan})
    assert result['executed'] and result['sa_execution']['executed'] and not result['errors']
    assert state['resources'][rc.BELGAE] == 2
    return {'scenario': scenario, 'plan': plan, 'result': result,
            'scripted_terminal_answers': source.answers, 'planning_board_unchanged': True,
            'physical': physical(state), 'integrity': check(state)}


scenarios = (*rc.BASE_SCENARIOS, *rc.ARIOVISTUS_SCENARIOS)
representatives = (rc.SCENARIO_GREAT_REVOLT, rc.SCENARIO_ARIOVISTUS)
print(json.dumps({'UI11-01': {
    ('repaired_terminal' if args.repaired else 'blocked_terminal'):
        [(repaired_terminal if args.repaired else blocked_terminal)(s) for s in scenarios],
    'durable_combined_plan_controls': [durable_control(s) for s in scenarios],
    'terminal_free_german_command_controls': [free_german_control(s) for s in representatives],
    'ordinary_terminal_borrowing_controls': [ordinary_terminal_control(s) for s in representatives],
}}, indent=2, sort_keys=True))
