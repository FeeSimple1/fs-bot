# Eighth comparison repair evidence, Batch 1

The parent is `33c722e941292f8cb0a66e3cedc0d5efa995b0e2`. The patched Python
source digest is `a9af09027132d567150a5d6c7d8a32abbfbfc5e73e0b14d3a77700d00cb034c2`.
The archived runs used Python 3.12.14 and 612 Python source files.

`verification.json` records the result of `verify_results.py`. To repeat
the evidence checks, run this command from the repaired repository with
the archive extracted to the given path.

```sh
PYTHONPATH=. python /path/to/evidence/verify_results.py
```

`directed-parent.xml` and `directed-parent.log` preserve the ten new cases
against the parent engine, with five failures and five passing controls.
`directed-fixed.xml` and `directed-fixed.log` cover the repaired cases and
four neighboring test modules. `pytest.xml` and `pytest.log` cover the full
10,126-test run at hash seed 0 using five pytest-xdist workers.

To repeat the ten directed cases on either engine revision, run the copied
test file with that checkout on `PYTHONPATH`.

```sh
PYTHONHASHSEED=0 PYTHONPATH=. python -m pytest -q /path/to/evidence/test_eighth_comparison_winter.py
```

`bots-legacy` contains the audited seeds 1–20 at hash seed 0 with two
workers. `bots-second` contains second-edition seeds 45–48 at hash seed 0
with one worker. Each covers all five scenarios. `fuzz0` and `fuzz987` retain
the JSON and stdout of the 20 second-edition cases with reactions, Events
and replay enabled. `balance.log` records the legacy balance check against
the 100-game baseline.

Parent matrices in `parent` come from the seventh comparison Batch 5
archive for legacy seeds 1–20 and the eighth comparison audit archive for
second-edition seeds 45–48. Their recorded commit and dirty flags describe
their original runs. Their Python source digest matches the repair parent.

`trace_winter.py` uses the normal audited runner for the six changed legacy
games. Run it from each checkout with its own source on `PYTHONPATH` to
recreate the paired traces.

```sh
PYTHONHASHSEED=0 PYTHONPATH=. python /path/to/evidence/trace_winter.py 1 3 6 7 12 20
```

The verifier compares the first differing card, the entering board and RNG,
the remaining Winters, the finality flag and the resulting outcome. The
controlled tests separately cover the solitaire rule and save/load behavior.
`SHA256SUMS` lists the digest of each other archive file.
