import sys,json
sys.path.insert(0,'/workspace/scratch/534c265c65f4/fs-bot')
from fs_bot import rules_consts as rc
from fs_bot.state.state_schema import build_initial_state, validate_state
from fs_bot.board.pieces import place_piece, count_pieces_by_state
from fs_bot.cards.capabilities import activate_capability
from fs_bot.cards.arduenna import march_request
from fs_bot.engine.free_actions import execute_free_action_plan

def plan(origin):
 return {'command':rc.CMD_MARCH,'regions':[origin],'sa':'No SA','sa_regions':[],
         'details':{'march_plan':{'origins':[origin],'destinations':[rc.TREVERI],
                                 'routes':{origin:[rc.TREVERI]}}}}
for case in ('unrelated_diviciacus','mixed_visibility'):
 s=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=201)
 actor=rc.AEDUI if case=='unrelated_diviciacus' else rc.BELGAE
 s['non_player_factions']={rc.ROMANS,actor}
 if case=='unrelated_diviciacus':
  activate_capability(s,38,rc.EVENT_UNSHADED)
  place_piece(s,rc.AEDUI_REGION,rc.AEDUI,rc.WARBAND)
  place_piece(s,rc.AEDUI_REGION,rc.ROMANS,rc.AUXILIA)
  place_piece(s,rc.SEQUANI,rc.AEDUI,rc.WARBAND,2,piece_state=rc.REVEALED)
  origin=rc.SEQUANI
 else:
  place_piece(s,rc.ATREBATES,actor,rc.WARBAND,piece_state=rc.HIDDEN)
  place_piece(s,rc.ATREBATES,actor,rc.WARBAND,piece_state=rc.REVEALED)
  origin=rc.ATREBATES
 try:
  result=execute_free_action_plan(s,actor,march_request(67),plan(origin))
  print(json.dumps({'case':case,'result':result,'state_errors':validate_state(s),
                   'hidden_at_target':count_pieces_by_state(s,rc.TREVERI,actor,rc.WARBAND,rc.HIDDEN)}))
 except Exception as exc:
  print(json.dumps({'case':case,'exception':repr(exc)}))
