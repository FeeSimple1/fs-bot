"""Limited positive witnesses for previously unverified expansion rows."""
import json
from probe import board, run, _ally_tribe, place_piece, count_pieces, rc
from fs_bot.cards.card_effects import execute_event
from fs_bot.state.state_schema import check_structural_integrity

out={}
s=board('A18',rc.ROMANS)
place_piece(s,rc.SUGAMBRI,rc.ROMANS,rc.AUXILIA,8)
place_piece(s,rc.SUGAMBRI,rc.GERMANS,rc.WARBAND,2)
out['A18']=run(s,'A18',{'target_region':rc.SUGAMBRI})
assert count_pieces(s,rc.SUGAMBRI,rc.GERMANS)==0
for n in (0,12):
 s=board('A26');out[f'A26_{n}']=run(s,'A26',{'placements':[{'region':rc.SEQUANI,'count':n}] if n else []},True)
 assert count_pieces(s,rc.SEQUANI,rc.ARVERNI,rc.WARBAND)==n
for n in (0,4):
 s=board('A35',rc.ROMANS);out[f'A35U_{n}']=run(s,'A35',{'ally_faction':rc.ROMANS,'piece_type':rc.AUXILIA,'piece_faction':rc.ROMANS,'count':n})
 assert s['tribes'][rc.TRIBE_TREVERI]['allied_faction']==rc.ROMANS
 assert count_pieces(s,rc.TREVERI,rc.ROMANS,rc.AUXILIA)==n
for full in (False,True):
 s=board('A35');p={'placements':[{'region':rc.MORINI,'piece_type':rc.WARBAND,'count':8},{'region':rc.TREVERI,'piece_type':rc.SETTLEMENT}]} if full else {'placements':[]}
 out[f'A35S_{full}']=run(s,'A35',p,True)
 assert count_pieces(s,rc.MORINI,rc.GERMANS,rc.WARBAND)==(8 if full else 0)
 assert count_pieces(s,rc.TREVERI,rc.GERMANS,rc.SETTLEMENT)==(1 if full else 0)
for full in (False,True):
 s=board('A40');p={'placements':[{'region':rc.SEQUANI,'piece_type':rc.WARBAND,'faction':rc.BELGAE,'count':3},{'region':rc.CISALPINA,'piece_type':rc.AUXILIA,'faction':rc.ROMANS,'count':2},{'region':rc.PROVINCIA,'piece_type':rc.ALLY,'faction':rc.ROMANS,'tribe':rc.TRIBE_HELVII}]} if full else {'placements':[]}
 out[f'A40U_{full}']=run(s,'A40',p)
 assert count_pieces(s,rc.SEQUANI,rc.BELGAE,rc.WARBAND)==(3 if full else 0)
for n in (0,5):
 s=board('A60');place_piece(s,rc.ATREBATES,rc.ROMANS,rc.AUXILIA,5,piece_state=rc.SCOUTED)
 out[f'A60S_{n}']=run(s,'A60',{'replacements':[{'from_type':rc.AUXILIA,'piece_state':rc.SCOUTED}]*n},True)
 assert count_pieces(s,rc.ATREBATES,rc.ROMANS,rc.AUXILIA)==5-n
 assert count_pieces(s,rc.ATREBATES,rc.BELGAE,rc.WARBAND)==n
for card,regions,counts in [('A27',(rc.PICTONES,rc.ARVERNI_REGION),(3,3)),('A32',(rc.VENETI,rc.MORINI),(4,2))]:
 for side in (False,True):
  s=board(card);s['event_params']={}
  execute_event(s,card,shaded=side)
  assert check_structural_integrity(s)==[]
  assert [count_pieces(s,r,rc.ARVERNI,rc.WARBAND) for r in regions]==list(counts)
  assert s['event_modifiers'][f'card_{card}_arverni_phase']
  out[f'{card}_{side}_before_phase']={'fixed_placements_match':True,'scarcity_not_checked':True}
print(json.dumps(out,indent=2))
