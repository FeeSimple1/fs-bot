# Eleventh engineering comparison

Falling Sky was reviewed at `702d60a3754ce94a73ead0d0148d647232ecd816`.
Liberty or Death was reviewed at `2991ea279062773548ec390a1da75f3e85381702`.
Both clean checkouts matched their fetched remote main branches on 13 November
2026. The user requested continuation of the established comparison audit.

The following Liberty or Death implementation was reread during this pass.

- `lod_ai/engine.py` lines 885–898 assigns action allowances to the acting
  faction and distinguishes Event grants from Sequence of Play slots.
- Lines 900–945 derives legality and completed output from actual affected
  spaces and Special Activity use.
- Lines 947–970 simulates an action on detached state and context, then
  commits accepted state. Forecast checks should therefore follow through to
  actual public execution and verify state, physical inventory and RNG effects.
- Lines 1642–1678 attributes Event actions to the active faction, drains
  granted actions during Event resolution and restores the previous actor.
- `tests/test_bot_bs_error_rollback.py` uses controlled fault injection to
  check preservation of state, shared context and random state. It separately
  checks ordinary false/empty planner results and real exceptions.

These implementation patterns informed the review of Falling Sky forecasts,
action consumers, grants, completed results and replay. Each finding derives
its expected game behavior from the supplied Falling Sky and Ariovistus
references and the thirteen adopted project rulings. The lane reports record
additional comparator code reviewed and the particular comparison applied.

The audited Falling Sky commit has fourteen completed successful GitHub
checks, preserved in `parent-github-checks.json`. Local tests and newly selected
game seeds are recorded separately in the validation evidence.
