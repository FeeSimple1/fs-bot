"""Collection-only pytest plugin: record exact node IDs and their JUnit names."""
import json
from pathlib import Path

import pytest
from _pytest.junitxml import bin_xml_escape, mangle_test_address


def pytest_addoption(parser):
    parser.addoption('--validation-inventory', required=True)


def pytest_collection_finish(session):
    records = []
    for item in session.items:
        names = mangle_test_address(item.nodeid)
        records.append({'nodeid': item.nodeid, 'classname': '.'.join(names[:-1]),
                        'name': str(bin_xml_escape(names[-1]))})
    path = Path(session.config.getoption('--validation-inventory'))
    with path.open('x') as stream:
        json.dump({'pytest_version': pytest.__version__, 'cases': records},
                  stream, indent=2, sort_keys=True)
        stream.write('\n')
