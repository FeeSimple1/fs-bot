"""Prepare or explicitly release the immutable action-timing validation matrix.

No simulation runs without --resume-prepared (after full-suite PASS), or an
explicit --resume-after-review following a preserved original-balance hold.
"""
from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from fractions import Fraction
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from common import (ROOT, REPO, PYTHON, SCENARIOS, BASELINE_SHA, prepare,
                    validate_current, verify_snapshots, execute, read,
                    write_json, utc, verify_test_inventory)


def build_jobs(run, workers):
    jobs = []
    for edition, seeds in (('legacy', '1-20'), ('original', '201-205'),
                           ('second-edition', '201-205')):
        name = 'bots-' + edition
        jobs.append({'name': name, 'hash_seed': 0, 'argv': [
            str(PYTHON), '-m', 'fs_bot.tools.run_batch', '--seeds', seeds,
            '--card-edition', edition, '--workers', str(workers), '--out', str(run / name)]})
    for h in (0, 7):
        jobs.extend([
            {'name': f'fuzz{h}', 'hash_seed': h, 'argv': [str(PYTHON), '-m',
             'fs_bot.tools.player_fuzz', '--seeds', '1-4', '--card-edition', 'legacy',
             '--out', str(run / f'fuzz{h}.json')]},
            {'name': f'census{h}', 'hash_seed': h, 'argv': [str(PYTHON), '-m',
             'fs_bot.tools.error_census', '--seeds', '1-5', '--card-edition', 'legacy',
             '--strict', '--out', str(run / f'census{h}.json')]},
        ])
    return jobs


def legacy_gate(run, source_sha):
    """Audit the exact legacy100 before comparing the untouched original guard."""
    rows = [json.loads(line) for line in (run / 'bots-legacy/games.jsonl').read_text().splitlines()]
    expected = {(s, n, 'legacy') for s in SCENARIOS for n in range(1, 21)}
    actual = [(r.get('scenario'), r.get('seed'), r.get('card_edition')) for r in rows]
    if len(actual) != 100 or len(set(actual)) != 100 or set(actual) != expected:
        raise ValueError('legacy100 exact coverage differs')
    for row in rows:
        if (not all(row.get(f) is True for f in ('completed', 'game_completed', 'audit_completed'))
                or row.get('source_sha256') != source_sha or row.get('error')
                or row.get('errors') != [] or row.get('integrity_findings') != []
                or row.get('engine_ranking_output_missing') is not False
                or row.get('winner_differs_from_highest_margin') is not False
                or len(row.get('final_ranking', [])) != 4
                or row.get('engine_final_ranking') != row.get('final_ranking')
                or any(d.get('severity') != 'legal-decline' for d in row.get('diagnostics', []))
                or any(d.get('severity') != 'legal-decline' for d in row.get('diagnostic_occurrences', []))):
            raise ValueError(f"legacy audit failure: {row.get('scenario')}/{row.get('seed')}")
    prior = read(run / 'balance-baseline.json')['games']
    comparisons, breaches = {}, []
    for scenario in SCENARIOS:
        before = Counter(prior[f'{scenario}|{n}']['winner'] for n in range(1, 21))
        after = Counter(r['winner'] for r in rows if r['scenario'] == scenario)
        delta = {f: Fraction(after[f] - before[f], 20)
                 for f in ('Romans', 'Arverni', 'Aedui', 'Belgae', 'Germans')}
        comparisons[scenario] = {'before': dict(before), 'after': dict(after),
                                'exact_rate_changes': {f: str(d) for f, d in delta.items()}}
        breaches.extend({'scenario': scenario, 'faction': f, 'exact_change': str(d)}
                        for f, d in delta.items() if abs(d) > Fraction(3, 20))
    changed = [{'key': f"{r['scenario']}|{r['seed']}",
                'before': prior[f"{r['scenario']}|{r['seed']}"],
                'after': {k: r[k] for k in ('winner', 'cards')}} for r in rows
               if prior[f"{r['scenario']}|{r['seed']}"] != {k: r[k] for k in ('winner', 'cards')}]
    return {'source_sha256': source_sha, 'baseline_sha256': BASELINE_SHA,
            'games': 100, 'exact_band': '3/20', 'passed': not breaches,
            'breaches': breaches, 'scenarios': comparisons, 'baseline_updated': False,
            'changed_records': len(changed),
            'changed_winners': sum(r['before']['winner'] != r['after']['winner'] for r in changed),
            'changed_card_counts': sum(r['before']['cards'] != r['after']['cards'] for r in changed),
            'changed': sorted(changed, key=lambda r: r['key']),
            'comparison_reuses_audited_legacy100': True, 'extra_balance_games': 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--source-sha256', required=True)
    parser.add_argument('--workers', type=int, default=2)
    parser.add_argument('--parallel', type=int, default=2)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--plan-only', action='store_true')
    mode.add_argument('--prepare-only', action='store_true')
    mode.add_argument('--resume-prepared', action='store_true')
    mode.add_argument('--resume-after-review', action='store_true')
    args = parser.parse_args()
    if Path(args.attempt).name != args.attempt or args.workers < 1 or args.parallel < 1:
        parser.error('simple attempt name and positive worker counts required')
    run = ROOT / args.attempt
    jobs = build_jobs(run, args.workers)
    if args.plan_only:
        print(json.dumps(jobs, indent=2))
        return 0
    if args.prepare_only:
        prepare(run, args.source_sha256, jobs)
        print(f'Prepared {run}; no tests or games launched.')
        return 0
    freeze = read(run / 'freeze.json')
    validate_current(args.source_sha256, freeze)
    verify_snapshots(run, freeze)
    if freeze['jobs'] != jobs:
        parser.error('job settings differ from frozen plan')
    existing = {j['name'] for j in jobs if (run / (j['name'] + '.status.json')).exists()}
    if existing != ({'bots-legacy'} if args.resume_after_review else set()):
        parser.error('job inventory already exists or is incomplete; never overwrite/repeat jobs')
    suite = read(run / 'tests.status.json')
    if (suite.get('exit_code') != 0 or suite.get('runner_exit_code') != 0
            or suite.get('source_changed') is not False
            or suite.get('source_after', {}).get('source_sha256') != args.source_sha256):
        parser.error('full frozen suite did not pass')
    try:
        verify_test_inventory(run, freeze)
    except (ValueError, KeyError, OSError) as exc:
        parser.error('full frozen suite is not complete: ' + str(exc))
    if args.resume_after_review:
        if not (run / 'runner-status-balance-hold.json').is_file():
            parser.error('no preserved balance hold to release')
        legacy = read(run / 'bots-legacy.status.json')
        if legacy['runner_exit_code'] != 0 or legacy['source_changed']:
            parser.error('cannot release an execution/source failure as a balance-only hold')
        write_json(run / 'matrix-review-release.json', {
            'recorded_utc': utc(), 'source_sha256': args.source_sha256,
            'authorization': 'Explicit --resume-after-review following root review.',
            'baseline_unchanged': True, 'legacy_reused_without_new_games': True}, exclusive=True)
    else:
        legacy = execute(run, jobs[0]['name'], jobs[0]['argv'], 0, freeze)
    statuses = [legacy]
    if legacy['runner_exit_code'] != 0:
        write_json(run / 'runner-status.json', {'passed': False, 'ended_utc': utc(),
                   'reason': 'Legacy execution/audit failed; remaining jobs not launched.',
                   'jobs': statuses}, exclusive=True)
        return 1
    gate = legacy_gate(run, args.source_sha256)
    if args.resume_after_review:
        if gate != read(run / 'legacy-balance-gate.json'):
            parser.error('preserved original balance comparison changed')
    else:
        write_json(run / 'legacy-balance-gate.json', gate, exclusive=True)
    if not gate['passed'] and not args.resume_after_review:
        write_json(run / 'runner-status-balance-hold.json', {
            'passed': False, 'ended_utc': utc(), 'jobs': statuses,
            'reason': 'Original15pp band exceeded. Remaining coverage held for root review.',
            'baseline_unchanged': True}, exclusive=True)
        print('Original balance hold; remaining games not launched.', flush=True)
        return 1
    with ThreadPoolExecutor(max_workers=args.parallel) as pool:
        futures = [pool.submit(execute, run, j['name'], j['argv'], j['hash_seed'], freeze)
                   for j in jobs[1:]]
        statuses.extend(f.result() for f in as_completed(futures))
    passed = all(s['runner_exit_code'] == 0 and not s['source_changed'] for s in statuses)
    validate_current(args.source_sha256, freeze)
    write_json(run / 'runner-status.json', {'passed': passed, 'ended_utc': utc(),
               'jobs': sorted(statuses, key=lambda s: s['name'])}, exclusive=True)
    print(f"Runner {'PASS' if passed else 'FAIL'}; verify.py still required.", flush=True)
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
