# Fourth audit — seasonal and persistent-effect partition

Audited Falling Sky `b951908af2b21cc87a7e27d9a5314b3f257d0147`.

Read `CLAUDE.md`, current-status, provisional rulings, all three earlier finding inventories and relevant previous seasonal/Interlude reports. Inspected the full Reference Documents filename inventory and read Chapters6/7, A6/A7, base/expansion lasting card texts, Gallic War and Pax setup, Setup, resource limits and selected Chapter1/A1 rules.

Comparator pattern used was `lod-bot-comparison/docs/audit_set_but_never_applied_s76.md`: follow stored effects and metadata to their final observation point, including scope and lifetime. Compared this with Falling Sky's Winter/Spring/Interlude consumers, capability replacement/removal registry, scoring and resource accounting. Game conclusions derive only from Falling Sky's supplied references and adopted project rulings.

Three confirmed groups have runnable probes and captured JSON, with positive controls and census/structure checks. Probes freeze current defects, not repaired expectations. Run each from the repo root with `PYTHONPATH=. python <probe path>`.

Coverage included Winter phase order and special first-Winter flags, Harvest physical counting and limits, Senate timing and Legion caps, Spring Scouted/Dispersed/Razed cleanup, Gallic War piece/seat transition, Tribe replacement, deck rebuild, Capability companion flags, A63 ownership and dormancy, and persistent A31/A33/A70 consumers. This is a targeted source review, not exhaustive combinations or a new full-game matrix.

Rejected, deferred or assigned elsewhere:

- Recently repaired Harvest Citadel double-counting, Lost Eagle scope/expiry, Colony consumers, permanent Razed markers and Stalwart/Horse interaction were not counted again.
- A33 Wailing Women's “outnumbered” population is a source question. See its separate note. No defect counted.
- Optimates uses Winter ordinal for its second-Victory-Phase gate. The text's handling of the skipped Pax first Victory Phase was not settled here, so no defect counted.
- Numeric63 and A63 physical replacement identity after Interlude was not asserted. The confirmed replacement-card deck failure is A38 itself.
- Known Circumvallation cohort persistence is expressly excluded.
- A33 Motivation's zero-survivor Counterattack and card59 ownership acquisition belong to the Commands and base Events partitions, respectively.

No production, reference, test, or repository documentation files were modified by this partition.

Independent review rejected the initial negative-Harvest fixture because its sequential Tribe assignment crossed Aedui/Arverni Home restrictions. The superseded script/output are retained, and the accepted probe now explicitly validates each restricted Tribe owner. All Harvest and full-Winter observations reproduced unchanged on the corrected legal assignment.
