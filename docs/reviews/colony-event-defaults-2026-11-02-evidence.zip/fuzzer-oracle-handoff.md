# Mixed-seat NPC Event rejection oracle

The mixed-seat fuzzer previously checked player dry/live outcomes, crashes,
integrity, completion and replay but did not reject an explicitly failed NPC
Event. The saved Ariovistus seed 17 trajectory demonstrates that blind spot:
an Aedui NPC A45 execution returns `executed: false`, `rejected: true` and a
TypeError reason while the old acceptance record reports no hard findings.

`fs_bot/tools/player_fuzz.py` now adds `bot-event-rejected` when an action
record has an NPC Event `bot_action` and those two explicit Boolean flags.
It classifies ownership from the recorded action rather than ending human
seats, which can change at the Gallic War Interlude. It retains the original
reason text. It does not normalize errors, ignore them for digesting, or
classify legal optional declines as rejection. Deliberately malformed human
plans remain subject to their existing dry/live and rollback checks.

The supplied Chapter 8 §§8.1.1 and 8.2.1 direct NPCs to avoid ineffective or
forbidden Events and follow their Event instructions. The new oracle is a
bounded detector for explicit executor rejection; it is not a complete rule
check for every ineffective Event or nested action.

Nine new regressions in `test_player_fuzz_bot_event_rejections.py` cover
actual `main`/`play_game` failure propagation even when replay matches, mixed
record authorship for the same faction, human malformed input, non-Event
commands, legal declined follow-ups, explicit flag requirements, and exact
actor/card/raw-error attribution. The combined new and existing fuzzer tests
pass: **22 passed**, recorded in `fuzzer-focused-01.log`.

`check_captured_bot_rejection.py` reassesses the untouched recorded pre-fix
terminal state and trajectory through `play_game`. The new oracle detects
exactly one A45 failure while retaining digest `fc17f6c251fd8d82`; the old
record has zero findings. This is recorded-trajectory reassessment, not a
game simulation or a changed-rules replay. Its proof JSON preserves the
source identity and capture hash. No additional full game was run for this
oracle task, and production gameplay behavior is unchanged by the oracle.

The separate partial-count review ran two bounded games before source edits;
those are documented independently in `partial-review.md` and must not be
counted as new oracle acceptance games. Full-suite and broad acceptance runs
remain the root agent's publication checks.
