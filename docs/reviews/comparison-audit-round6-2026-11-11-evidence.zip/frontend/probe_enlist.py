"""Ariovistus Enlist March lacks multi-group destination choice (A3.4.2).
Controlled lawful position; source/schema and actual terminal menu witness.
"""
from io import StringIO
from copy import deepcopy
import json
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece,count_pieces
from fs_bot.board.control import refresh_all_control
from fs_bot.cli.human_plan import _collect_enlist_details
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND_SA,ACTION_LIMITED_COMMAND
from fs_bot.state.state_schema import build_initial_state,validate_state,check_structural_integrity

def clean(s):
 assert validate_state(s)==[],validate_state(s)
 assert check_structural_integrity(s)==[],check_structural_integrity(s)

def board(ario=True):
 s=build_initial_state(rc.SCENARIO_ARIOVISTUS if ario else rc.SCENARIO_GREAT_REVOLT,seed=7)
 s.update(non_player_factions=set(),current_card=52,next_card=49)
 place_piece(s,rc.PROVINCIA,rc.ROMANS,rc.FORT)
 place_piece(s,rc.SUGAMBRI,rc.BELGAE,rc.LEADER,leader_name=rc.BODUOGNATUS if ario else rc.AMBIORIX)
 place_piece(s,rc.SUGAMBRI,rc.BELGAE,rc.WARBAND,1)
 place_piece(s,rc.SUGAMBRI,rc.GERMANS,rc.WARBAND,4)
 s['resources'][rc.BELGAE]=10
 if ario:s['resources'][rc.GERMANS]=10
 refresh_all_control(s);clean(s);return s

def positions(s):
 return {r:count_pieces(s,r,rc.GERMANS,rc.WARBAND) for r in (rc.SUGAMBRI,rc.NERVII,rc.TREVERI)}

def split_control():
 s=board()
 a={'command':rc.CMD_MARCH,'sa':'No SA','sa_regions':[],'details':{
  'origins':[rc.SUGAMBRI],'destinations':[rc.NERVII,rc.TREVERI],
  'routes':{rc.SUGAMBRI:[rc.NERVII]},'groups':{rc.SUGAMBRI:{rc.WARBAND:2}},
  'extra_groups':[{'origin':rc.SUGAMBRI,'route':[rc.TREVERI],'group':{rc.WARBAND:2}}]}}
 result=execute_decision(s,rc.GERMANS,{'action':ACTION_LIMITED_COMMAND,'player_action':a})
 clean(s)
 assert result['executed'] and positions(s)=={rc.SUGAMBRI:0,rc.NERVII:2,rc.TREVERI:2},result
 return {'plan':a,'result':result,'after':positions(s),'census':[],'structure':[]}

def terminal_case(ario):
 s=board(ario);out=StringIO(); inp=StringIO('Sugambri\nNervii\n1\n')
 # Public terminal's actual production collector; _sub only bypasses the
 # earlier subcommand menu. Choice 1 selects all four Hidden Warbands.
 regions,details=_collect_enlist_details(s,rc.BELGAE,inp,out,_sub='german_march')
 assert regions==[rc.SUGAMBRI]
 assert details['enlist']['destination']==rc.NERVII
 a={'command':rc.CMD_RAID,'sa':rc.SA_ENLIST,'sa_regions':regions,'sa_timing':'after',
    'details':{'raid_plan':[{'region':rc.SUGAMBRI,'target':None}],**details}}
 result=execute_decision(s,rc.BELGAE,{'action':ACTION_COMMAND_SA,'player_action':a})
 clean(s)
 assert result['executed'] and result['sa_execution']['executed'],result
 assert positions(s)=={rc.SUGAMBRI:0,rc.NERVII:4,rc.TREVERI:0},positions(s)
 assert out.getvalue().count('March Germans TO:')==1
 return {'scenario':s['scenario'],'menu':out.getvalue(),'plan':a,'result':result,
         'after':positions(s),'remaining_input':inp.read(),'census':[],'structure':[]}

if __name__=='__main__':
 print(json.dumps({'FE6-02':{'ario_terminal':terminal_case(True),
                           'base_single_group_control':terminal_case(False),
                           'ario_ordinary_split_control':split_control()}},indent=2,sort_keys=True))
