O38 unshaded compatibility evidence, 27 October 2026

This directory preserves the script and exact stdout from the independent
review's existing 72-case comparison. No games or comparison cases were rerun
while archiving this evidence.

The two original Python processes ran the script through stdin, one from the
clean fs-second-batch-baseline04b checkout and one from the repaired fs-bot
working tree, using:
  /workspace/scratch/534c265c65f4/fs-test-venv/bin/python

Both exited 0 and produced the same SHA-256 over json.dumps(rows,
sort_keys=True). Each row includes the scenario/flag/deck/Leader/faction
inputs, shared Event gate, actual R4/A3 node, and full Roman/Aedui turn result.
The result digest is a digest of these comparison rows, not of repository
source code. comparison.json records the distinct clean-baseline source hash.

The script is the same body that was executed originally. To reproduce from
either repository root, set PYTHONPATH to that root and run this archived
script. The script only constructs and queries synthetic review positions;
it writes no repository files and runs no full games.

The original comparison did not retain its full per-case rows or capture a
full repaired-tree source digest. Those limits are recorded explicitly in
comparison.json; no later frozen-source digest is represented as the identity
of that earlier comparison. The baseline is clean commit
04b4b70bedae78a07723340aa4ed401b3a77dd29.

The source question itself remains open as Q-O38 in QUESTIONS.md. Preserving
existing unshaded behavior is not an owner-adopted interpretation of the
printed Capability label.
