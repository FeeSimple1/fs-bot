# Named Event frontend handoff

Shared checkout parent: `2edf53e6a0dae774b391e64ce883fdcc5f622ba9`.
No commits made. Root owns the combined source identity, full suite, documentation,
progress disposition, outcome validation and push.

## Owned files

- `fs_bot/cli/named_event_effects.py` — new scoped live-owner collector.
- `fs_bot/cli/free_actions.py` — named_event_effect route.
- `fs_bot/cli/human_plan.py` — supported Event turn plans leave choices for the live owner.
- `fs_bot/tests/test_cli_named_event_effects.py` — 42 new cases.
- `fs_bot/tests/test_named_event_sessions.py` — 25 new cases, authored by delegated durable-session agent.

No protected inputs, engine/card handlers or project documentation were modified
by this frontend work. Engine changes were coordinated with named_event_engine.

## Resulting choices

The initial terminal Event plan returns an empty parameter object for all five
supported sides: 2U,18U,A18U,23U,26S. The named owner then receives its live
`named_event_effect` request, including when the executor is the same faction.
The typed API also supports the engine's explicit same-owner parameters.

Menus distinguish explicit bot default, explicit whole-effect decline and manual
choices. Romans choose Card2's exact Legions Track/Fallen split,18/A18's legal
Germania Region, and23's actual City identity. A18 omits Ariovistus's Region.
Card26 offers any faction's actual Allies in Arverni Region for removal, then
legal own Arverni Ally placements. Citadels and Dispersed destinations are not
silently substituted. Current-board previews rebuild choices after each entry;
`board`/`b` displays that preview, and EOF propagates without live mutation.

For Card26, `decline:true` declines the whole optional sentence. An accepted
empty pair of Ally lists proceeds to the separately offered Rally where legal.
The top menu explicitly offers “Skip Ally changes; decide Rally”, as well as the
manual choose-then-finish-both route. The earlier proposed decline-then-Rally
interpretation was superseded by source review before release.

## Timing defects caught by frontend witnesses

A named owner does not inherit the Event executor's voluntary removal authority.
The collector binds a trusted scope to the original executor while keeping the
named owner as the answering seat. Foreign beneficiaries are offered neither
their own nor the executor's voluntary removals. Same-owner reclamation remains
available. Arverni's independent Spring entry can still be selected.

The initial helper replayed a foreign Arverni owner's authored Spring entry as
the Event executor, rejecting a legitimate entry. The frontend witness exposed
this; the engine agent repaired response authorship within the original trusted
executor scope without weakening generic authority checks. The test collects,
previews and executes the foreign-owner Spring choice with identical live state
until acceptance.

A late Card2 reclamation initially produced an incomplete source selection:
track0/Fallen1, followed by reclamation at `2.fallen_legions`, still submitted
only the one Fallen Legion. The collector now recomputes possible totals and
explicitly reselects increased track counts. The engine fulfills a track balance
only after that preserved later window and still rejects unavailable sources.
The regression verifies both timing entries retain their original positions,
preview purity, two-Legion fulfillment and final source accounting. No timing
choice is silently moved earlier.

## Validation

`frontend-focused-04.log`: **94 passed**, covering the67 new frontend/session
cases plus existing `test_cli_free_actions.py` and `test_human_plan.py`.
`python -m pytest --collect-only -q` confirms42 CLI+25 session cases.
`git diff --check` for owned tracked hooks passed. Root's final combined suite
must supersede this scoped result; test counts overlap and are not additive.

Durable tests use real SeatSession transactions and validate source-derived
positions. They cover foreign-owner pending prompts, malformed/source/target and
forged-owner responses, stable decision IDs and pending board, exact board/RNG
and empty journal preservation, current/upcoming card names and Resource deltas,
explicit default receipts, acceptance and decline, save/load and exact replay.
A18 includes Hidden/Revealed/Scouted Warbands, a Settlement, an Allied Tribe and
a German Successor. Card26's empty, explicit-default and selected-Allies paths
all preserve the earlier accepted choice while a later invalid Rally remains
pending, then save/load and replay the two accepted requests exactly.

Earlier attempts are preserved:
- `cli-focused-01/02`: fixture mistakes (Ariovistus constant name and Tribe-table
  column selection); corrected without changing mechanics expectations.
- `cli-focused-03`:37 passed before the extra Spring/late-source/direct-skip cases.
- `cli-spring-before-01`: real foreign-owner Spring authorship rejection.
- `cli-late-reclamation-before-01`: real stale Legion allocation witness.
- `frontend-focused-01`: wrong existing test filename; no tests ran.
- `frontend-focused-02`:90 passed before the final two additional CLI cases.
- Session logs and `sessions-handoff.md` retain their independent chronology,
  including the superseded Card26 decline interpretation.

No external rules sources or new provisional rulings were introduced.

## Final source-choice follow-up

Root identified a further legal Card2 source-mix choice after late reclamation.
With one track Legion and one Fallen Legion initially, choosing one from each
already satisfies the quota; reclaiming a Legion at the later source window
also permits two track Legions and zero Fallen. The collector now exposes newly
legal complete allocations even when the original allocation was complete,
while retaining prior placements and the original timing window. It adds no
redundant menu when no source allocation becomes newly legal. Two narrow cases
cover both paths. `cli-late-source-choice-before-01.log` preserves the failing
witness; `frontend-focused-04.log` is the final accepted frontend run.
