"""BM11-01: A34's Aedui target guarantee omits an active Abatis absorber.

No production edits or mocks. Public Events acquire the marker/capability and
dispatch the German Command chosen by the non-player Aedui beneficiary.
"""
import argparse
import copy
import json
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--repo', default='/workspace/scratch/521fc7ecea8c/falling-sky')
args = parser.parse_args()
sys.path.insert(0, args.repo)

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces, get_available
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.cards.divination_np import choose_divination_action, _high_value_forced
from fs_bot.battle.losses import calculate_losses, defender_abatis_active
from fs_bot.bots.bot_common import predict_battle
from fs_bot.bots.aedui_bot import _would_force_loss_on_high_value
from fs_bot.engine.agent import RETREAT, LOSS_ORDER
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.tools.seat_session import validate_response

REGION = rc.CARNUTES

def check(state):
    result = {'census_errors': validate_state(state),
              'structure_errors': check_structural_integrity(state)}
    assert result == {'census_errors': [], 'structure_errors': []}, result
    return result

def pieces(state):
    return {
        'belgic_warbands_carnutes': count_pieces(state, REGION, rc.BELGAE, rc.WARBAND),
        'belgic_ally_aulerci': state['tribes'][rc.TRIBE_AULERCI]['allied_faction'],
        'belgic_warbands_available': get_available(state, rc.BELGAE, rc.WARBAND),
        'german_warbands_carnutes': count_pieces(state, REGION, rc.GERMANS, rc.WARBAND),
        'german_warbands_elsewhere': sum(count_pieces(state, r, rc.GERMANS, rc.WARBAND)
                                       for r in state['spaces'] if r != REGION),
        'german_warbands_available': get_available(state, rc.GERMANS, rc.WARBAND),
        'abatis_owner': state['markers'].get(REGION, {}).get(rc.MARKER_ABATIS),
    }

def event(state, card, actor, *, shaded=False, **params):
    state['current_card'] = state['current_card_id'] = card
    response = {'action': ACTION_EVENT, 'player_action': {
        'command': rc.FIRST_DID_EVENT, 'sa': 'No SA', 'details': {
            'card_id': card,
            'text_preference': rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,
            'event_params': params}}}
    validate_response(state, {'kind': 'turn', 'faction': actor, 'options': [ACTION_EVENT]}, response)
    result = execute_decision(state, actor, response)
    assert result['executed'] and not result.get('errors'), result
    check(state)
    return result

def run_case(name, *, warbands, leader=True, abatis=True, ally=True, stalwart=False,
             expected_command, observed_command, expected_losses):
    state = build_initial_state(rc.SCENARIO_ARIOVISTUS, seed=1)
    state['non_player_factions'] = set()
    for faction in (rc.GERMANS, rc.BELGAE, rc.AEDUI, rc.ROMANS):
        state['resources'][faction] = 20
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    if leader:
        place_piece(state, REGION, rc.GERMANS, rc.LEADER, leader_name=rc.ARIOVISTUS_LEADER)
    place_piece(state, REGION, rc.GERMANS, rc.WARBAND, warbands)
    place_piece(state, REGION, rc.BELGAE, rc.WARBAND, 2)
    if ally:
        assert _ally_tribe(state, rc.TRIBE_AULERCI, rc.BELGAE)
    check(state)
    acquisitions = []
    if abatis:
        acquisitions.append(event(state, 'A64', rc.BELGAE, region=REGION))
    if stalwart:
        acquisitions.append(event(state, 'A31', rc.GERMANS, shaded=True))
    state['non_player_factions'] = {rc.AEDUI}
    before, valid_before = pieces(state), check(state)
    forecast = predict_battle(state, REGION, rc.GERMANS, rc.BELGAE)
    diagnostics = {
        'raw_losses': calculate_losses(state, REGION, rc.GERMANS, rc.BELGAE),
        'resolver_losses': forecast['inflicted'],
        'resolver_loss_types': sorted(forecast['defender_loss_types']),
        'active_abatis': defender_abatis_active(state, REGION, rc.GERMANS, rc.BELGAE),
        'divination_high_value_gate': _high_value_forced(state, REGION, rc.BELGAE),
        'ordinary_aedui_target_predicate': _would_force_loss_on_high_value(
            state, REGION, rc.GERMANS, rc.BELGAE, state['scenario']),
        'planning_command': choose_divination_action(copy.deepcopy(state), rc.AEDUI)['command'],
    }
    assert diagnostics['raw_losses'] == diagnostics['resolver_losses'] == expected_losses
    requests, responses = [], []
    def agent(board, faction, request):
        requests.append({'faction': faction, 'request': copy.deepcopy(request)})
        response = None
        if request['kind'] == RETREAT:
            response = {'retreat': False}
        elif request['kind'] == LOSS_ORDER:
            response = [piece for piece in request['pieces'] if piece[0] == rc.MARKER_ABATIS]
        responses.append(copy.deepcopy(response))
        return response
    state['decision_agent'] = agent
    result = event(state, 'A34', rc.ROMANS, faction=rc.AEDUI)
    command = result['free_actions'][0]['result']['command']
    assert command == observed_command
    loss_requests = [r['request'] for r in requests if r['request']['kind'] == LOSS_ORDER]
    if command == rc.CMD_BATTLE:
        assert loss_requests[0]['num_losses'] == expected_losses
    after = pieces(state)
    if expected_command != observed_command:
        assert ally and abatis and after['belgic_ally_aulerci'] == rc.BELGAE
        assert after['belgic_warbands_carnutes'] == 0
        assert any(any(p[0] == rc.MARKER_ABATIS for p in r['pieces']) for r in loss_requests)
        assert diagnostics['ordinary_aedui_target_predicate'] is False
    elif command == rc.CMD_BATTLE:
        assert after['belgic_ally_aulerci'] is None
    return {
        'name': name,
        'fixture': {'german_warbands': warbands, 'ariovistus': leader,
                    'abatis': abatis, 'aulerci_ally': ally, 'stalwart': stalwart},
        'acquisition_events': acquisitions, 'before': before,
        'before_validation': valid_before, 'diagnostics': diagnostics,
        'expected_command': expected_command, 'actual_command': command,
        'event_result': result, 'reactive_requests': requests,
        'reactive_responses': responses, 'after': after, 'after_validation': check(state),
        'german_resources_after': state['resources'][rc.GERMANS],
    }

cases = [
    run_case('active_abatis_ariovistus', warbands=10, expected_command=rc.CMD_MARCH,
             observed_command=rc.CMD_BATTLE, expected_losses=3),
    run_case('active_abatis_no_ariovistus', warbands=12, leader=False,
             expected_command=rc.CMD_MARCH, observed_command=rc.CMD_BATTLE, expected_losses=3),
    run_case('same_three_losses_no_abatis', warbands=1, abatis=False,
             expected_command=rc.CMD_BATTLE, observed_command=rc.CMD_BATTLE, expected_losses=3),
    run_case('active_abatis_lower_losses', warbands=6, expected_command=rc.CMD_MARCH,
             observed_command=rc.CMD_MARCH, expected_losses=2),
    run_case('active_abatis_no_high_value_target', warbands=10, ally=False,
             expected_command=rc.CMD_MARCH, observed_command=rc.CMD_MARCH, expected_losses=3),
    run_case('round10_stalwart_repair_remains_correct', warbands=2, stalwart=True,
             expected_command=rc.CMD_BATTLE, observed_command=rc.CMD_BATTLE, expected_losses=4),
]
print(json.dumps({'finding': 'BM11-01', 'scenario': rc.SCENARIO_ARIOVISTUS,
                  'rng_seed': 1, 'cases': cases}, indent=2, sort_keys=True))
