# BE-04 independent source review

Scope: Cards2U,18U,23U,26S and the directly related A18U counterpart.
All references below are supplied repository files. No external rules source
or new project ruling was used. All47 Reference Documents were inventoried.
This note is a source-review checkpoint; final implementation acceptance follows.

## Owners and optional components

Chapter5§5.1 assigns unspecified choices to the executor but explicitly allows
other-faction actions/decisions. The named Romans own2U,18U/A18U,23U; named
Arverni own26S. A foreign executor cannot silently supply those responses.
A human may decline the optional sentence; Arverni may instead choose empty
removal/placement lists and still proceed to the separately chosen free Rally.
No existing source needs the executor to approve the named owner's decision.
The raw-callback default contract remains distinct from missing durable input.

## Card2

Card Reference2 requires an actual one-box-up Senate shift or flip, then two
Legions total from Track/Fallen, as far as possible (§5.1.3). Off-track Senate
cannot shift; FirmUproar cannot shift. Chapter6§6.5.1 governs the other Firm
flips and Uproar-to-Firm movement. A human selects the Track/Fallen allocation;
accepted fixed placement cannot arbitrarily omit available Legions.
The Roman per-card instruction in both editions requires all2 or NoRomans.
No supplied source prioritizes Track over Fallen or Fallen over Track.
Chapter7§7.2 and A7.2 do not count Fallen in the Roman victory formula, and both
pools count equally as off-map Legions for Arverni. An invented source preference
based on anticipated Winter advantage is not the printed bot. Equal complete
legal allocations should use seeded random selection under8.2.3/8.3.4.

## Card18/A18

The Roman owner selects one Germania Region under or adjacent to RomanControl.
Every German piece there is removed. Original18 has the printed base-game
Warband/Ally population; A18 adds the explicit prohibition on a Region containing
namedAriovistus. ChapterA1§A1.4 distinguishes Ariovistus from his Successor.
An unprotected Successor is included by 'all Germans', as are Settlements and
all Hidden/Revealed/Scouted Warbands. An empty eligible human-selected Region is
not excluded by the text; NPC ineffectiveness is a separate policy.
ChapterA8§A8.2.3/A8.3.1 gives Settlements the same Event-location priority as
Citadels, before Allies. After the Region is selected the whole group goes.
The independent clean-parent probe review-a18-parent-01.json confirms that the
old A18 handler left exactly the Successor and Scouted Warband behind.

## Card23

One City at RomanControl is selected; the Event replaces its contents with
Razed and gives Romans8Resources (normal45cap). The text says 'replace anything':
own or enemy Ally/Citadel, empty/Subdued, Dispersed/Gathering, or alreadyRazed
are not blanket-prohibited human targets. No supplied Razed-supply cap was found;
the explicit four-marker cap in3.2.3 is for ordinary Dispersed markers. Replacing
an existingRazed status with Resources already45 has no effect, so NPCavailability
and its default selection must not pick that when an effective alternative exists.
Chapter8§8.3.1 prioritizes enemyCitadel/Ally effects; general own-piece preservation
must remain distinct from human legality. §8.4.1's voluntary-removal prohibition
cross-references reclamation in1.4.1; it is not an express prohibition on the
printed replace-anything effect. The candidate default prefers non-ownCities
but permits an ownAllyCity when that is the only possible benefit.
Razed remains a permanentDispersed status under the printedTips and6.6.

## Card26

Arverni may remove any faction's ALLY in ArverniRegion, then place Arverni's own
Allies there. Chapter5§5.1's placing-faction rule supplies the incoming owner.
The printed shadedTips explicitly preserve normalstacking: no Citadel removals,
no removal of Dispersed/Razed markers, no placing on occupied or Dispersed spaces,
and no override of restrictedCities. Exact Tribe identities are required.
The later freeRally is confined toRegions with or adjacent to actualVercingetorix;
a Successor does not supply the named-Leader location. The existing follow-on
resolver already checks that distinction. Numeric26 is separate from expansion
A26 Divico, which must retain its different behavior. No2ndEdition text-change
handler applies to the four numeric card identities in this task.

## Timing review findings sent to implementers

The outer Sequence-of-Play executor keeps1.4.1 voluntary-removal authority. An
Arverni named owner still controls its own unlockedSpring entry, independently
of that executor. The implementation must separate scope actor from the author
of an owner response. Raw/direct collectors need the same authority frame even
when called without an already-active outer scope. A Card26 decline must not be
labeled as skipping only Allies if it declines the whole sentence.
