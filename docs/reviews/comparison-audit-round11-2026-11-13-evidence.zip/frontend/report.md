# Eleventh comparison audit — human frontend/session lane

Audited Falling Sky `702d60a3754ce94a73ead0d0148d647232ecd816`; Liberty or Death comparator `2991ea279062773548ec390a1da75f3e85381702`. No production/reference edits. One fresh medium finding is demonstrated. Rules conclusions use only the supplied Falling Sky references; LoD is an engineering comparison.

## UI11-01 — Winter Campaign's terminal cannot combine Enlist borrowing with its Belgic Command

**Expected:** A Belgic Winter Campaign with both actions remaining must allow one Command combined with Enlist's borrowed German Warbands. The two actions resolve as one combined plan so the borrowed force exists during the Command. In the demonstrated position, Raid with two borrowed Germans gives Belgae two Resources and Reveals those Germans, spending both Winter Campaign actions.

**Observed:** The real terminal lists separate Commands and Special Abilities, and the only combined choice is Battle + Ambush. Selecting the offered `Special Ability: Enlist` → `lend Warbands to the Belgic Command` → Carnutes instead yields:

> Cannot use this plan: Invalid Winter Campaign plan: Unknown free Enlist sub-Command

It returns to the Winter Campaign menu with both actions still available. No corresponding combined Enlist+Command entry exists. Choosing a Command first also collects only a Command plan, without any borrowing option. After the player chooses Finish, the result records no actions, no resources gained, and unchanged Germans. The player cannot express the legal borrowed Raid using this terminal menu. This is not a claim that the engine should accept a standalone loan without an accompanying Command.

**Public route and fixtures:** The probe assembles a sparse valid board in each of all five scenarios using `build_initial_state` and `place_piece`: the permanent Roman Fort in Provincia, the proper Belgic named Leader in Carnutes, and two Hidden German Warbands in Carnutes; no Belgic Warbands and zero Belgic Resources. It activates shaded 63/A63 through ordinary public `execute_decision` with the proper Belgic beneficiary, installs the actual `make_cli_reactive` agent, and invokes the production `winter_campaign_after_harvest` activation hook. Actual terminal input selects the offered loan; the captured transcript and result prove its rejection. In Ariovistus, the loan explicitly selects only the two Hidden Warbands, within the four-piece limit and away from Ariovistus.

**Rules/API:** Supplied `Reference Documents/Card Reference:645–655` grants any two Commands and/or applicable Special Abilities. `Reference Documents/Ariovistus/A Card Reference:279–286` extends this to A63. `Reference Documents/Chapter 4:195–214` permits Enlist to accompany any Command and treat German Warbands as Belgic for that Command, ending the loan when the Command finishes. `Reference Documents/Ariovistus/Chapter A4:44–53` preserves that option with its four-piece/location restrictions. `AGENT_INTERFACE.md:2263–2280` explicitly documents combined Command+SA Winter Campaign plans as two actions. No new provisional ruling is required.

**Cause:** `fs_bot/cli/winter_campaign.py:13–20` creates combined entries only for Ambush/Besiege. Its standalone SA branch at `27–31` builds `command=None` and invokes `_collect_sa_plan` without disabling borrowing; `fs_bot/cli/human_plan.py:749–760` therefore offers the loan. The Command branch at `32–39` uses `_collect_command_plan` rather than the normal combination collector, so it cannot attach Enlist. The standalone plan reaches `fs_bot/engine/winter_campaign.py:67–77` and then the free-German-subcommand executor at `fs_bot/engine/execute.py:5952–5978`, which correctly rejects type `borrow` there. A valid combined plan takes the existing `_execute_borrowed_command` route at `fs_bot/engine/execute.py:602–644` instead.

**Controls:**

- In all five scenarios, the exact combined borrowed Raid validates as two actions, is accepted by an actual `SeatSession` after pending/save/load, and runs through the same activation hook. The pending ID survives reload and the committed journal retains the exact accepted plan. It gains two Belgic Resources, Reveals both German Warbands, records successful Enlist borrowing, and leaves zero actions.
- In Great Revolt and Ariovistus, the ordinary terminal's existing borrowed-Command option authors and executes the same borrowed Raid successfully. Its detached planning leaves the real board/RNG unchanged.
- In those same two scenarios, standalone Winter Enlist with its **free German March** option works: both Germans move Carnutes→Mandubii, one Winter action is spent, and the next decision allows Finish. Thus standalone Enlist itself is not categorically broken.
- All 14 cases start/end with clean conservation and structural checks. Every blocked terminal attempt leaves its entire board/RNG unchanged. Both hash seeds 0/987 produce byte-identical JSON.

**Prior distinction:** UI8-01 was repeated Regions within one Winter Battle; UI8-02 was missing live March drop-offs in Winter Campaign. UI10-02 concerned selected visibility in Enlist's free German March, a different Enlist option and execution route. FE6-02/FE7-01 concern German March groups. This finding is the Winter terminal's inability to construct an already-supported combined loan+Command. The ordinary collector and durable combined-plan execution are positive controls, not additional defects. The prior delegated-human post-Command ability lead remains excluded.

**Repair scope:** Offer a combined Belgic Command with borrowed Enlist while two Winter actions remain, reusing the existing physical loan selection and detached Command planning. Count the pair as two actions and retain the one-action budget boundary. Do not solve it solely by hiding the rejected standalone choice; that would still omit the legal combined option. Preserve standalone Enlist's free German Command, ordinary borrowing, paid Command costs, source-specific four-piece limits and the prohibition on voluntary removal of borrowed Germans. No backend rule relaxation is needed.

**Actual LoD comparison:** `lod_ai/interactive_cli.py:1107–1122` collects Common Cause as a typed physical borrowing activity within the current planned Command context. Lines `1351–1373` and `1402–1420` execute and clean up the before/during/after activity inside one Command run. Lines `1023–1035` validate it against that accompanying Command's selected spaces. `lod_ai/special_activities/common_cause.py:43–51,106` retains the selected loan in shared Command context. The relevant pattern is that a temporary force modifier and the Command consuming it must be authored together and share a lifetime. These code observations are not imported LoD rules, nor a claim that its Winter procedure is equivalent.

**Reproduction:** From the workspace root:

```sh
PYTHONHASHSEED=0 /workspace/scratch/4aba5bd9b1ab/fs-bot/.venv/bin/python audit11/frontend/probe_frontend.py --repo falling-sky
```

Repeat with `PYTHONHASHSEED=987`; compare with `results.json` and `results.hash987.json`. The probe has no companion fixture or script dependencies. Its ordinary terminal driver explicitly answers optional own-piece-removal menus with the displayed no-removal default; it does not patch menus or production functions.

**Limits:** These are curated sparse positions and direct public post-Harvest capability entry, not full natural Winter histories. The defect affects terminal plan availability; a human using the documented assistant/API combined plan can execute the action. No probability/balance claim, no full-suite claim from this lane, and no production fix. Inspected Scout visibility/physical-owner collection, tenth-round completed-summary changes and Quarters replay compatibility yielded no separately counted new finding in this pass.
