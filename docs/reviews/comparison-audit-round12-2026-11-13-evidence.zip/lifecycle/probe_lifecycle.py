#!/usr/bin/env python3
"""LC12-01, full third-Winter Cisalpina evacuation with canonical pieces."""
import argparse
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo.resolve()))
    from fs_bot import rules_consts as rc
    from fs_bot.board.pieces import move_piece, count_pieces
    from fs_bot.cards.gallia_evacuation import default_response, validate_response
    from fs_bot.engine.game_engine import get_sop_factions
    from fs_bot.engine.interlude_choices import CISALPINA_RELOCATION
    from fs_bot.engine.victory import check_any_victory
    from fs_bot.engine.winter import run_winter_round
    from fs_bot.state.setup import setup_scenario
    from fs_bot.state.state_schema import validate_state, check_structural_integrity

    def integrity(state):
        result = {'census': validate_state(state),
                  'structure': check_structural_integrity(state)}
        assert result == {'census': [], 'structure': []}, result
        return result

    def run(seed, mode):
        state = setup_scenario(rc.SCENARIO_GALLIC_WAR, seed=seed)
        state['non_player_factions'] = set(get_sop_factions(state))
        if mode != 'already_home':
            move_piece(state, rc.PROVINCIA, rc.CISALPINA, rc.ROMANS, rc.LEGION, 3)
        state['winter_count'] = 2
        state['current_card'] = state['current_card_id'] = rc.WINTER_CARD
        assert check_any_victory(state) is None
        before = integrity(state)
        responses = []
        if mode in ('explicit_move', 'delegated'):
            state['non_player_factions'].remove(rc.ROMANS)

            def agent(board, faction, request):
                if request['kind'] == CISALPINA_RELOCATION and faction == rc.ROMANS:
                    if mode == 'explicit_move':
                        response = default_response(board, faction)
                        validate_response(board, faction, response)
                    else:
                        response = {'use_default': True}
                    responses.append({'request': request, 'response': response})
                    return response
                return {'use_default': True}

            state['decision_agent'] = agent
        result = run_winter_round(state)
        assert 'interlude' in result and not result['phases']['victory']['game_over']
        interlude = result['interlude']
        after = integrity(state)
        legions = {region: count_pieces(state, region, rc.ROMANS, rc.LEGION)
                   for region in (rc.CISALPINA, rc.PROVINCIA, rc.BRITANNIA)}
        expected_expedition = mode in ('explicit_move', 'already_home')
        assert interlude['step3_britannia']['conducted'] == expected_expedition
        if mode in ('non_player', 'delegated'):
            assert interlude['step2_cisalpina']['removed'][rc.ROMANS] == 3
            assert legions == {rc.CISALPINA: 0, rc.PROVINCIA: 3, rc.BRITANNIA: 0}
        else:
            assert rc.ROMANS not in interlude['step2_cisalpina']['removed']
            assert legions == {rc.CISALPINA: 0, rc.PROVINCIA: 0, rc.BRITANNIA: 3}
            assert state.get('winter_track_legions') == 3
        return {
            'seed': seed, 'mode': mode,
            'before_integrity': before, 'after_integrity': after,
            'cisalpina': interlude['step2_cisalpina'],
            'expedition': interlude['step3_britannia'],
            'legions': legions, 'legions_track': state['legions_track'],
            'winter_track_legions': state.get('winter_track_legions', 0),
            'senate': state['senate'], 'requests': responses,
            'scenario': state['scenario'], 'interlude_completed': state['interlude_completed'],
        }

    cases = [run(seed, mode) for seed in (1, 7, 19)
             for mode in ('non_player', 'explicit_move', 'delegated', 'already_home')]
    print(json.dumps({'id': 'LC12-01', 'source_revision':
                     '1563e41d84f61dfce43ce4008106eca2a1639aed',
                     'case_count': len(cases), 'assertions_passed': True,
                     'cases': cases}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
