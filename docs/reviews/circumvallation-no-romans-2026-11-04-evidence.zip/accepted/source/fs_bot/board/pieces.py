"""
Piece operations module — The ONLY way pieces change in the game state.

All piece operations go through this module. Functions enforce caps from
rules_consts.py, update Available pools, and maintain state integrity.
Never manipulate piece counts in space dictionaries directly.

Reference: §1.4, §1.4.1, §1.4.2, §1.4.3, A1.4
"""

from fs_bot.rules_consts import (
    # Factions
    ROMANS, ARVERNI, AEDUI, BELGAE, GERMANS, FACTIONS,
    # Piece types
    LEADER, LEGION, AUXILIA, WARBAND, FORT, ALLY, CITADEL, SETTLEMENT,
    PIECE_TYPES, FLIPPABLE_PIECES, MOBILE_PIECES,
    # Piece states
    HIDDEN, REVEALED, SCOUTED,
    # Caps
    CAPS_BASE, CAPS_ARIOVISTUS,
    # Scenarios
    BASE_SCENARIOS, ARIOVISTUS_SCENARIOS,
    # Leaders
    CAESAR, VERCINGETORIX, AMBIORIX, ARIOVISTUS_LEADER,
    DIVICIACUS, BODUOGNATUS, SUCCESSOR,
    BASE_LEADERS, ARIOVISTUS_LEADERS,
    LEADER_FACTION,
    # Stacking
    MAX_FORTS_PER_REGION, MAX_SETTLEMENTS_PER_REGION,
    # Special
    PROVINCIA, PROVINCIA_PERMANENT_FORT,
    LEGIONS_TRACK, FALLEN_LEGIONS,
    LEGIONS_ROW_BOTTOM, LEGIONS_ROW_MIDDLE, LEGIONS_ROW_TOP,
    LEGIONS_ROWS, LEGIONS_PER_ROW,
    # Tribe stacking
    TRIBE_FACTION_RESTRICTION,
)


class PieceError(Exception):
    """Raised when a piece operation violates game rules."""
    pass


def _validate_count(count):
    """Physical counters cannot be negative, fractional, or boolean."""
    if type(count) is not int or count < 0:
        raise PieceError("Piece count must be a nonnegative integer")


def _validate_visibility(piece_state):
    if piece_state is not None and piece_state not in (HIDDEN, REVEALED, SCOUTED):
        raise PieceError(f"Unknown piece state: {piece_state}")


def _validate_region(state, region):
    if region not in state["spaces"]:
        raise PieceError(f"Unknown Region: {region}")


def _second_half_caps(caps, state):
    """Gallic War second half (A2.1): the scenario id switched to
    Pax Gallica?, but two Ariovistus component sets stay in circulation —
    the German inventory (Leader + 30 Warbands, partly in the removed
    pool) and the Aedui Diviciacus Leader (removed at the Interlude; card
    O38 may return him). Use the Ariovistus caps for those."""
    if state.get("scenario_phase") != "second_half":
        return caps
    from fs_bot.rules_consts import GERMANS, AEDUI, LEADER
    merged = dict(caps)
    merged[GERMANS] = CAPS_ARIOVISTUS[GERMANS]
    aedui = dict(merged.get(AEDUI, {}))
    aedui[LEADER] = CAPS_ARIOVISTUS[AEDUI].get(LEADER, 1)
    merged[AEDUI] = aedui
    return merged


def _get_caps(state):
    """Get the piece caps dict for the current scenario."""
    if state["scenario"] in ARIOVISTUS_SCENARIOS:
        return CAPS_ARIOVISTUS
    caps = _second_half_caps(CAPS_BASE, state)
    if state.get("diviciacus_option"):
        # A Setup/A1.4: the optional original-scenario Leader adds only
        # Diviciacus, not the other Ariovistus components or rules.
        caps = dict(caps)
        caps[AEDUI] = dict(caps[AEDUI])
        caps[AEDUI][LEADER] = CAPS_ARIOVISTUS[AEDUI][LEADER]
    return caps


def _get_faction_cap(state, faction, piece_type):
    """Get the cap for a specific faction/piece_type in the current scenario."""
    caps = _get_caps(state)
    faction_caps = caps.get(faction, {})
    return faction_caps.get(piece_type, 0)


def _count_on_map(state, faction, piece_type):
    """Count how many of a piece type a faction has on the map."""
    total = 0
    for region, space in state["spaces"].items():
        pieces = space.get("pieces", {}).get(faction, {})
        if piece_type == LEADER:
            if pieces.get(LEADER) is not None:
                total += 1
        elif piece_type in FLIPPABLE_PIECES:
            total += pieces.get(HIDDEN, {}).get(piece_type, 0)
            total += pieces.get(REVEALED, {}).get(piece_type, 0)
            total += pieces.get(SCOUTED, {}).get(piece_type, 0)
        else:
            total += pieces.get(piece_type, 0)
    return total


def count_on_map(state, faction, piece_type):
    """Count how many of a piece type a faction has on the map (public API).

    Args:
        state: Game state dict.
        faction: Faction constant.
        piece_type: Piece type constant.

    Returns:
        Integer count.
    """
    return _count_on_map(state, faction, piece_type)


def _count_on_legions_track(state):
    """Count total Legions on the Legions track."""
    total = 0
    for row in LEGIONS_ROWS:
        total += state["legions_track"].get(row, 0)
    return total


def _total_legions_accounted(state):
    """Count all Legions everywhere (map + track + fallen + removed)."""
    on_map = _count_on_map(state, ROMANS, LEGION)
    on_track = _count_on_legions_track(state)
    fallen = state.get("fallen_legions", 0)
    removed = state.get("removed_legions", 0)
    return on_map + on_track + fallen + removed


def get_available(state, faction, piece_type):
    """Get the count of available pieces for a faction/type.

    Args:
        state: Game state dict.
        faction: Faction constant.
        piece_type: Piece type constant.

    Returns:
        Integer count of available pieces.
    """
    if piece_type == LEGION:
        # Legions are NOT on Available — they use the Legions track
        # Available Legions = on track, placeable via Senate Phase
        return _count_on_legions_track(state)
    return state["available"].get(faction, {}).get(piece_type, 0)


def _set_available(state, faction, piece_type, count):
    """Set the available count for a faction/piece_type."""
    if piece_type == LEGION:
        raise PieceError("Legions use the Legions track, not Available")
    state["available"].setdefault(faction, {})[piece_type] = count


def _validate_piece_exists_in_scenario(state, faction, piece_type):
    """Validate that a piece type exists for a faction in this scenario."""
    cap = _get_faction_cap(state, faction, piece_type)
    if cap == 0 and piece_type != LEADER:
        raise PieceError(
            f"{faction} cannot have {piece_type} in scenario "
            f"{state['scenario']}"
        )
    # Special leader validation
    if piece_type == LEADER:
        if cap == 0:
            raise PieceError(
                f"{faction} has no Leader in scenario {state['scenario']}"
            )


def _get_piece_count_in_region(state, region, faction, piece_type):
    """Get count of a specific piece type for a faction in a region."""
    space = state["spaces"].get(region, {})
    pieces = space.get("pieces", {}).get(faction, {})

    if piece_type == LEADER:
        return 1 if pieces.get(LEADER) is not None else 0
    elif piece_type in FLIPPABLE_PIECES:
        return (pieces.get(HIDDEN, {}).get(piece_type, 0) +
                pieces.get(REVEALED, {}).get(piece_type, 0) +
                pieces.get(SCOUTED, {}).get(piece_type, 0))
    else:
        return pieces.get(piece_type, 0)


def get_effective_faction_pieces(state, region, faction):
    """Command-facing pieces, retaining physical ownership in the board.

    §4.5.1 treats selected German Warbands as Belgic until their Command
    ends. A4.5.1 free Battle instead ignores unselected German pieces.
    Inventory/cap checks intentionally continue reading physical counters.
    """
    from fs_bot.commands.sa_enlist import BORROW_KEY, FREE_FORCE_KEY
    from fs_bot.rules_consts import BELGAE
    raw = state["spaces"].get(region, {}).get("pieces", {}).get(faction, {})
    from fs_bot.battle.excluded_leader import effective_pieces as leader_view
    raw = leader_view(state, region, faction, raw)
    from fs_bot.battle.combined import effective_pieces
    combined = effective_pieces(state, region, faction, raw)
    from fs_bot.engine.diviciacus import effective_pieces as diviciacus_view
    borrowed = diviciacus_view(state, region, faction, combined if combined is not None else raw)
    if borrowed is not None:
        return borrowed
    if combined is not None:
        return combined
    free = state.get(FREE_FORCE_KEY)
    if free and faction == free.get("faction", GERMANS) and region in free["pieces"]:
        return {ps: {WARBAND: free["pieces"][region].get(ps, 0)}
                for ps in (HIDDEN, REVEALED, SCOUTED)}
    loan = state.get(BORROW_KEY, {}).get("pieces", {}).get(region)
    if not loan or faction not in (BELGAE, GERMANS):
        return raw
    effective = dict(raw)
    for ps in (HIDDEN, REVEALED, SCOUTED):
        effective[ps] = dict(raw.get(ps, {}))
        effective[ps][WARBAND] = (effective[ps].get(WARBAND, 0)
                                  + loan.get(ps, 0) * (1 if faction == BELGAE else -1))
    return effective


def count_pieces(state, region, faction=None, piece_type=None):
    """Count pieces in a region, optionally filtered by faction/type.

    Args:
        state: Game state dict.
        region: Region name constant.
        faction: Optional faction to filter by.
        piece_type: Optional piece type to filter by.

    Returns:
        Integer count.
    """
    space = state["spaces"].get(region, {})
    total = 0

    # A loan can create an effective Belgic force without a physical entry.
    factions_to_check = [faction] if faction else FACTIONS

    for f in factions_to_check:
        f_pieces = get_effective_faction_pieces(state, region, f)
        # Litaviccus can include optional Diviciacus alongside a native
        # Leader. Count both without giving either the other's identity.
        from fs_bot.battle.combined import extra_leaders
        borrowed_leaders = extra_leaders(state, region, f)
        if piece_type:
            if piece_type == LEADER:
                total += borrowed_leaders
                if f_pieces.get(LEADER) is not None:
                    total += 1
            elif piece_type in FLIPPABLE_PIECES:
                total += f_pieces.get(HIDDEN, {}).get(piece_type, 0)
                total += f_pieces.get(REVEALED, {}).get(piece_type, 0)
                total += f_pieces.get(SCOUTED, {}).get(piece_type, 0)
            else:
                total += f_pieces.get(piece_type, 0)
        else:
            # Count all piece types for this faction
            # Leader
            total += borrowed_leaders
            if f_pieces.get(LEADER) is not None:
                total += 1
            # Non-flippable static/other pieces
            for pt in (LEGION, FORT, ALLY, CITADEL, SETTLEMENT):
                total += f_pieces.get(pt, 0)
            # Flippable pieces (Auxilia, Warband) in all states
            for pt in FLIPPABLE_PIECES:
                total += f_pieces.get(HIDDEN, {}).get(pt, 0)
                total += f_pieces.get(REVEALED, {}).get(pt, 0)
                total += f_pieces.get(SCOUTED, {}).get(pt, 0)

    return total


def count_pieces_by_state(state, region, faction, piece_type, piece_state):
    """Count pieces of a specific state (Hidden/Revealed/Scouted).

    Args:
        state: Game state dict.
        region: Region name constant.
        faction: Faction constant.
        piece_type: Piece type constant (must be in FLIPPABLE_PIECES).
        piece_state: HIDDEN, REVEALED, or SCOUTED.

    Returns:
        Integer count.
    """
    if piece_type not in FLIPPABLE_PIECES:
        raise PieceError(f"{piece_type} is not flippable")
    return get_effective_faction_pieces(state, region, faction).get(
        piece_state, {}
    ).get(piece_type, 0)


def _ensure_faction_pieces_structure(state, region, faction):
    """Ensure the pieces structure exists for a faction in a region."""
    state["spaces"].setdefault(region, {})
    state["spaces"][region].setdefault("pieces", {})
    state["spaces"][region]["pieces"].setdefault(faction, {})
    f_pieces = state["spaces"][region]["pieces"][faction]
    # Ensure flippable sub-dicts
    for ps in (HIDDEN, REVEALED, SCOUTED):
        f_pieces.setdefault(ps, {})
    return f_pieces


def place_piece(state, region, faction, piece_type, count=1, *,
                from_legions_track=False, from_fallen=False,
                leader_name=None, piece_state=None):
    """Place piece(s) from Available (or Legions track) onto the map.

    Args:
        state: Game state dict.
        region: Target region name constant.
        faction: Faction constant.
        piece_type: Piece type constant.
        count: Number of pieces to place (default 1).
        from_legions_track: If True, place Legions from track (not Available).
        from_fallen: If True, place Legions from Fallen box.
        leader_name: For Leaders, specify which leader (CAESAR, etc.).
        piece_state: For flippable pieces, HIDDEN or REVEALED.
            Defaults to HIDDEN per §1.4.3.

    Raises:
        PieceError: If placement violates game rules.
    """
    _validate_count(count)
    if count == 0:
        return
    _validate_region(state, region)
    _validate_visibility(piece_state)
    _validate_piece_exists_in_scenario(state, faction, piece_type)
    f_pieces = state["spaces"][region].get("pieces", {}).get(faction, {})

    if piece_type == LEADER:
        if count != 1:
            raise PieceError("Can only place 1 Leader at a time")
        if f_pieces.get(LEADER) is not None:
            raise PieceError(
                f"{faction} already has a Leader in {region}"
            )
        # Check Available
        avail = state["available"].get(faction, {}).get(LEADER, 0)
        if avail < 1:
            raise PieceError(f"No {faction} Leader Available")
        # Place leader — leader_name determines symbol end
        if leader_name is None:
            raise PieceError("leader_name required when placing a Leader")
        if leader_name != SUCCESSOR and LEADER_FACTION.get(leader_name) != faction:
            raise PieceError(f"Invalid Leader for {faction}: {leader_name}")
        f_pieces = _ensure_faction_pieces_structure(state, region, faction)
        state["available"][faction][LEADER] = avail - 1
        f_pieces[LEADER] = leader_name
        return

    if piece_type == LEGION:
        if faction != ROMANS:
            raise PieceError("Only Romans have Legions")
        if from_fallen:
            if state.get("fallen_legions", 0) < count:
                raise PieceError(
                    f"Only {state.get('fallen_legions', 0)} Fallen Legions "
                    f"available, need {count}"
                )
            state["fallen_legions"] -= count
        elif from_legions_track:
            if _count_on_legions_track(state) < count:
                raise PieceError(f"Not enough Legions on track (need {count})")
            # Remove from track, top rows first
            remaining = count
            for row in reversed(LEGIONS_ROWS):
                on_row = state["legions_track"].get(row, 0)
                take = min(on_row, remaining)
                state["legions_track"][row] = on_row - take
                remaining -= take
                if remaining == 0:
                    break
        else:
            raise PieceError(
                "Must specify from_legions_track=True or from_fallen=True "
                "when placing Legions — Legions are not in Available (§1.4.1)"
            )
        f_pieces = _ensure_faction_pieces_structure(state, region, faction)
        f_pieces[LEGION] = f_pieces.get(LEGION, 0) + count
        return

    if piece_type == FORT:
        if faction != ROMANS:
            raise PieceError("Only Romans have Forts")
        current_forts = f_pieces.get(FORT, 0)
        if current_forts + count > MAX_FORTS_PER_REGION:
            raise PieceError(
                f"Max {MAX_FORTS_PER_REGION} Fort per region (§1.4.2)"
            )
        avail = get_available(state, faction, FORT)
        if avail < count:
            raise PieceError(f"Only {avail} Forts Available, need {count}")
        f_pieces = _ensure_faction_pieces_structure(state, region, faction)
        _set_available(state, faction, FORT, avail - count)
        f_pieces[FORT] = current_forts + count
        return

    if piece_type == SETTLEMENT:
        if faction != GERMANS:
            raise PieceError("Only Germans have Settlements")
        current = f_pieces.get(SETTLEMENT, 0)
        # Check across all factions in region for settlement limit
        total_settlements = 0
        for fac, fp in state["spaces"][region].get("pieces", {}).items():
            total_settlements += fp.get(SETTLEMENT, 0)
        if total_settlements + count > MAX_SETTLEMENTS_PER_REGION:
            raise PieceError(
                f"Max {MAX_SETTLEMENTS_PER_REGION} Settlement per region "
                f"(A1.4.2)"
            )
        avail = get_available(state, faction, SETTLEMENT)
        if avail < count:
            raise PieceError(
                f"Only {avail} Settlements Available, need {count}"
            )
        f_pieces = _ensure_faction_pieces_structure(state, region, faction)
        _set_available(state, faction, SETTLEMENT, avail - count)
        f_pieces[SETTLEMENT] = current + count
        return

    if piece_type == ALLY:
        avail = get_available(state, faction, ALLY)
        if avail < count:
            raise PieceError(
                f"Only {avail} {faction} Allies Available, need {count}"
            )
        f_pieces = _ensure_faction_pieces_structure(state, region, faction)
        _set_available(state, faction, ALLY, avail - count)
        f_pieces[ALLY] = f_pieces.get(ALLY, 0) + count
        return

    if piece_type == CITADEL:
        # Invariant (§1.4 / §3.3.1): a Region has one City, a City holds one
        # Citadel — so at most one Citadel per Region, of any Faction. This
        # backstops every placement path (Rally, Events, Arverni Phase) against
        # over-placing a 2nd Citadel after an Ally elsewhere in the Region was
        # consumed by mistake.
        existing = sum(count_pieces(state, region, f, CITADEL)
                       for f in (ROMANS, ARVERNI, AEDUI, BELGAE, GERMANS))
        if existing + count > 1:
            raise PieceError(
                f"Cannot place a Citadel in {region}: it already has a "
                f"Citadel (one City/Citadel per Region)"
            )
        avail = get_available(state, faction, CITADEL)
        if avail < count:
            raise PieceError(
                f"Only {avail} {faction} Citadels Available, need {count}"
            )
        f_pieces = _ensure_faction_pieces_structure(state, region, faction)
        _set_available(state, faction, CITADEL, avail - count)
        f_pieces[CITADEL] = f_pieces.get(CITADEL, 0) + count
        return

    if piece_type in FLIPPABLE_PIECES:
        # Auxilia/Warband — always placed Hidden per §1.4.3
        ps = piece_state if piece_state is not None else HIDDEN
        avail = get_available(state, faction, piece_type)
        if avail < count:
            raise PieceError(
                f"Only {avail} {faction} {piece_type} Available, need {count}"
            )
        f_pieces = _ensure_faction_pieces_structure(state, region, faction)
        _set_available(state, faction, piece_type, avail - count)
        f_pieces[ps][piece_type] = f_pieces[ps].get(piece_type, 0) + count
        return

    raise PieceError(f"Unknown piece type: {piece_type}")


def remove_piece(state, region, faction, piece_type, count=1, *,
                 to_available=True, to_fallen=False, to_track=False,
                 to_removed=False, piece_state=None):
    """Remove piece(s) from the map.

    Args:
        state: Game state dict.
        region: Source region name constant.
        faction: Faction constant.
        piece_type: Piece type constant.
        count: Number of pieces to remove (default 1).
        to_available: If True (default), pieces go to Available.
        to_fallen: If True, Legions go to Fallen box.
        to_track: If True, Legions go to Legions track.
        to_removed: If True, Legions are removed by Event (for Arverni
            victory tracking).
        piece_state: For flippable pieces, specify which state to remove from.
            If None, removes Hidden first, then Revealed, then Scouted.

    Raises:
        PieceError: If removal violates game rules.
    """
    _validate_count(count)
    if count == 0:
        return
    _validate_region(state, region)
    _validate_visibility(piece_state)
    space = state["spaces"].get(region, {})
    f_pieces = space.get("pieces", {}).get(faction, {})

    if piece_type == LEADER:
        if count != 1:
            raise PieceError("Can only remove 1 Leader at a time")
        if f_pieces.get(LEADER) is None:
            raise PieceError(f"No {faction} Leader in {region}")
        leader_name = f_pieces[LEADER]
        # Diviciacus: removed from play, not to Available — A1.4. Track
        # him in the removed pool so conservation stays exact and card
        # O38 can return him ("It may return by Event").
        if leader_name == DIVICIACUS:
            f_pieces[LEADER] = None
            rp = state.setdefault("removed_pieces", {}).setdefault(
                faction, {})
            rp[LEADER] = rp.get(LEADER, 0) + 1
            state["diviciacus_in_play"] = False
            return
        f_pieces[LEADER] = None
        if to_available:
            state["available"][faction][LEADER] = (
                state["available"].get(faction, {}).get(LEADER, 0) + 1
            )
        return

    if piece_type == LEGION:
        if faction != ROMANS:
            raise PieceError("Only Romans have Legions")
        current = f_pieces.get(LEGION, 0)
        if current < count:
            raise PieceError(
                f"Only {current} Legions in {region}, need {count}"
            )
        if to_track and not to_fallen:
            capacity = sum(LEGIONS_PER_ROW - state["legions_track"].get(row, 0)
                           for row in LEGIONS_ROWS)
            if capacity < count:
                raise PieceError(f"Not enough room on Legions track (need {count})")
        f_pieces[LEGION] = current - count
        if to_fallen:
            state["fallen_legions"] = state.get("fallen_legions", 0) + count
        elif to_track:
            # Add to lowest available row
            remaining = count
            for row in LEGIONS_ROWS:
                on_row = state["legions_track"].get(row, 0)
                space_on_row = LEGIONS_PER_ROW - on_row
                add = min(space_on_row, remaining)
                state["legions_track"][row] = on_row + add
                remaining -= add
                if remaining == 0:
                    break
        elif to_removed:
            state["removed_legions"] = (
                state.get("removed_legions", 0) + count
            )
        else:
            # Default: Legions removed from Region go to Fallen — §1.4.1
            state["fallen_legions"] = state.get("fallen_legions", 0) + count
        return

    if piece_type == FORT:
        # Check for permanent Fort in Provincia — §1.4.2
        if region == PROVINCIA and f_pieces.get(FORT, 0) <= count:
            raise PieceError(
                "Cannot remove the permanent Fort from Provincia (§1.4.2)"
            )
        current = f_pieces.get(FORT, 0)
        if current < count:
            raise PieceError(
                f"Only {current} Forts in {region}, need {count}"
            )
        f_pieces[FORT] = current - count
        if to_available:
            avail = get_available(state, faction, FORT)
            _set_available(state, faction, FORT, avail + count)
        return

    if piece_type in (ALLY, CITADEL, SETTLEMENT):
        current = f_pieces.get(piece_type, 0)
        if current < count:
            raise PieceError(
                f"Only {current} {faction} {piece_type} in {region}, "
                f"need {count}"
            )
        f_pieces[piece_type] = current - count
        if to_available:
            avail = get_available(state, faction, piece_type)
            _set_available(state, faction, piece_type, avail + count)
        return

    if piece_type in FLIPPABLE_PIECES:
        # Remove from specific state or auto-select
        removed = 0
        if piece_state is not None:
            states_to_check = [piece_state]
        else:
            # Remove Hidden first, then Revealed, then Scouted
            states_to_check = [HIDDEN, REVEALED, SCOUTED]

        available = sum(f_pieces.get(ps, {}).get(piece_type, 0)
                        for ps in states_to_check)
        if available < count:
            raise PieceError(
                f"Only {available} {faction} {piece_type} in {region}, "
                f"need {count}"
            )
        for ps in states_to_check:
            current = f_pieces.get(ps, {}).get(piece_type, 0)
            take = min(current, count - removed)
            if take > 0:
                f_pieces[ps][piece_type] = current - take
                removed += take
            if removed >= count:
                break

        if to_available:
            avail = get_available(state, faction, piece_type)
            _set_available(state, faction, piece_type, avail + count)
        return

    raise PieceError(f"Unknown piece type: {piece_type}")


def move_piece(state, from_region, to_region, faction, piece_type, count=1,
               *, piece_state=None):
    """Move piece(s) between regions. Does not change Available.

    Args:
        state: Game state dict.
        from_region: Source region.
        to_region: Destination region.
        faction: Faction constant.
        piece_type: Piece type constant.
        count: Number of pieces to move.
        piece_state: For flippable pieces, state to move.

    Raises:
        PieceError: If move violates rules.
    """
    _validate_count(count)
    if count == 0:
        return
    _validate_region(state, from_region)
    _validate_region(state, to_region)
    _validate_visibility(piece_state)
    if piece_type == LEADER:
        if count != 1:
            raise PieceError("Can only move 1 Leader at a time")
        # Remove then place leader, preserving identity
        space = state["spaces"].get(from_region, {})
        f_pieces = space.get("pieces", {}).get(faction, {})
        leader_name = f_pieces.get(LEADER)
        if leader_name is None:
            raise PieceError(f"No {faction} Leader in {from_region}")
        if from_region == to_region:
            return
        dest = state["spaces"][to_region].get("pieces", {}).get(faction, {})
        if dest.get(LEADER) is not None:
            raise PieceError(f"{faction} already has a Leader in {to_region}")
        dest = _ensure_faction_pieces_structure(state, to_region, faction)
        f_pieces[LEADER] = None
        dest[LEADER] = leader_name
        return

    if piece_type == LEGION:
        src = state["spaces"].get(from_region, {}).get("pieces", {}).get(
            faction, {}
        )
        current = src.get(LEGION, 0)
        if current < count:
            raise PieceError(
                f"Only {current} Legions in {from_region}, need {count}"
            )
        src[LEGION] = current - count
        _ensure_faction_pieces_structure(state, to_region, faction)
        dest = state["spaces"][to_region]["pieces"][faction]
        dest[LEGION] = dest.get(LEGION, 0) + count
        return

    if piece_type in (FORT, ALLY, CITADEL, SETTLEMENT):
        src = state["spaces"].get(from_region, {}).get("pieces", {}).get(
            faction, {}
        )
        current = src.get(piece_type, 0)
        if current < count:
            raise PieceError(
                f"Only {current} {faction} {piece_type} in {from_region}, "
                f"need {count}"
            )
        if piece_type == FORT and from_region == PROVINCIA:
            # Don't allow moving the permanent Fort
            if current - count < 1:
                raise PieceError(
                    "Cannot remove the permanent Fort from Provincia"
                )
        if from_region != to_region and piece_type in (FORT, CITADEL, SETTLEMENT):
            destination_total = sum(
                fp.get(piece_type, 0)
                for fp in state["spaces"][to_region].get("pieces", {}).values()
            )
            limit = (MAX_FORTS_PER_REGION if piece_type == FORT else
                     MAX_SETTLEMENTS_PER_REGION if piece_type == SETTLEMENT else 1)
            if destination_total + count > limit:
                raise PieceError(f"Too many {piece_type} in {to_region}")
        src[piece_type] = current - count
        _ensure_faction_pieces_structure(state, to_region, faction)
        dest = state["spaces"][to_region]["pieces"][faction]
        dest[piece_type] = dest.get(piece_type, 0) + count
        return

    if piece_type in FLIPPABLE_PIECES:
        ps = piece_state if piece_state else HIDDEN
        src = state["spaces"].get(from_region, {}).get("pieces", {}).get(
            faction, {}
        )
        current = src.get(ps, {}).get(piece_type, 0)
        if current < count:
            raise PieceError(
                f"Only {current} {faction} {ps} {piece_type} in "
                f"{from_region}, need {count}"
            )
        src[ps][piece_type] = current - count
        _ensure_faction_pieces_structure(state, to_region, faction)
        dest = state["spaces"][to_region]["pieces"][faction]
        dest[ps][piece_type] = dest[ps].get(piece_type, 0) + count
        return

    raise PieceError(f"Unknown piece type: {piece_type}")


def flip_piece(state, region, faction, piece_type, count=1, *,
               from_state=None, to_state=None):
    """Flip flippable pieces between Hidden/Revealed/Scouted.

    For flipping to Hidden when Scouted: remove Scouted marker instead
    of flipping per §1.4.3.

    Args:
        state: Game state dict.
        region: Region name constant.
        faction: Faction constant.
        piece_type: Piece type constant (must be in FLIPPABLE_PIECES).
        count: Number of pieces to flip.
        from_state: Current state (HIDDEN, REVEALED, SCOUTED).
        to_state: Target state (HIDDEN, REVEALED, SCOUTED).

    Raises:
        PieceError: If flip violates rules.
    """
    _validate_count(count)
    if count == 0:
        return
    _validate_region(state, region)
    _validate_visibility(from_state)
    _validate_visibility(to_state)
    if piece_type not in FLIPPABLE_PIECES:
        raise PieceError(f"{piece_type} cannot be flipped")
    if from_state is None or to_state is None:
        raise PieceError("Must specify from_state and to_state for flip")
    if from_state == to_state:
        return  # No-op

    space = state["spaces"].get(region, {})
    f_pieces = space.get("pieces", {}).get(faction, {})

    current = f_pieces.get(from_state, {}).get(piece_type, 0)
    if current < count:
        raise PieceError(
            f"Only {current} {faction} {from_state} {piece_type} in "
            f"{region}, need {count}"
        )

    # Per §1.4.3: Scouted pieces flipped to Hidden — remove marker instead
    # This means Scouted -> Hidden becomes Scouted -> Revealed
    actual_to = to_state
    if from_state == SCOUTED and to_state == HIDDEN:
        actual_to = REVEALED

    f_pieces[from_state][piece_type] = current - count
    f_pieces.setdefault(actual_to, {})
    f_pieces[actual_to][piece_type] = (
        f_pieces[actual_to].get(piece_type, 0) + count
    )


def get_leader_in_region(state, region, faction):
    """Get the leader name in a region for a faction, if any.

    Args:
        state: Game state dict.
        region: Region name constant.
        faction: Faction constant.

    Returns:
        Leader name string (e.g. CAESAR), or None.
    """
    return get_effective_faction_pieces(state, region, faction).get(LEADER)


def find_leader(state, faction):
    """Find the region where a faction's leader is, if on map.

    Args:
        state: Game state dict.
        faction: Faction constant.

    Returns:
        Region name constant, or None if leader not on map.
    """
    for region in state["spaces"]:
        if get_leader_in_region(state, region, faction) is not None:
            return region
    return None


def tribe_has_ally_disc(state, region, tribe, faction):
    """Whether this allied Tribe is backed by a disc, not its City's Citadel.

    A Region-level Ally count cannot identify an individual Tribe when a
    City Citadel and another Tribe's Ally coexist (§1.4.2 / §4.2.1).
    """
    from fs_bot.rules_consts import TRIBE_TO_CITY, TRIBE_TO_REGION, FACTIONS
    info = state.get("tribes", {}).get(tribe, {})
    if (info.get("region") or TRIBE_TO_REGION.get(tribe)) != region:
        return False
    if info.get("allied_faction") != faction:
        return False
    if tribe in TRIBE_TO_CITY and any(
            count_pieces(state, region, f, CITADEL) for f in FACTIONS):
        return False
    return count_pieces(state, region, faction, ALLY) > 0


def count_allied_discs(state, faction):
    """Count allied Tribe records backed by discs rather than City Citadels.

    A City remains allied when its disc is replaced by a Citadel (§1.4.2).
    Adding every allied record to every Citadel therefore double-counts it.
    """
    from fs_bot.rules_consts import TRIBE_TO_CITY, TRIBE_TO_REGION
    return sum(1 for tribe, info in state.get("tribes", {}).items()
               if info.get("allied_faction") == faction and not
               (tribe in TRIBE_TO_CITY and count_pieces(
                   state, info.get("region") or TRIBE_TO_REGION[tribe],
                   faction, CITADEL)))


def clear_allied_tribe(state, region, faction, removed_piece_type, *, tribe=None):
    """Clear the tribes-dict entry matching an ALLY/CITADEL piece removal.

    ``state["tribes"][tribe]["allied_faction"]`` is authoritative for victory
    and must stay in sync with on-map ALLY/CITADEL pieces (one allied tribe
    per piece). Call this immediately AFTER removing an ALLY or CITADEL piece
    of ``faction`` from ``region`` through a path that does not already know
    which tribe the piece belonged to (battle losses, Besiege, Seize,
    Intimidate, generic Event removals).

    For a CITADEL removal the city tribe holding it is cleared; for an ALLY
    removal a non-Citadel-holding allied tribe is preferred (a tribe whose
    Citadel is on the map has no Ally disc — §1.4.2). Selection among equal
    candidates is deterministic (sorted) for replay stability. If ``tribe``
    is supplied, clear only that explicitly selected physical Tribe.

    Returns:
        The tribe name cleared, or None if no matching tribe was found.
    """
    from fs_bot.rules_consts import TRIBE_TO_REGION, TRIBE_TO_CITY
    if removed_piece_type not in (ALLY, CITADEL):
        return None
    tribes = state.get("tribes", {})
    candidates = []
    selected_tribe = tribe
    for tribe in sorted(tribes):
        if selected_tribe is not None and tribe != selected_tribe:
            continue
        info = tribes[tribe]
        if info.get("allied_faction") != faction:
            continue
        # Dynamic tribes (Card 71 Colony) carry their region in the entry.
        reg = info.get("region") or TRIBE_TO_REGION.get(tribe)
        if reg != region:
            continue
        candidates.append((tribe, tribe in TRIBE_TO_CITY))
    if not candidates:
        return None
    def _clear(tribe):
        tribes[tribe]["allied_faction"] = None
        # Normalize the legacy setup status so the tribe is truly
        # Subdued again (status holds Dispersed markers only).
        if tribes[tribe].get("status") == "Allied":
            tribes[tribe]["status"] = None
        return tribe

    if removed_piece_type == CITADEL:
        # Citadels sit only at Cities — clear the city tribe if allied.
        for tribe, is_city in candidates:
            if is_city:
                return _clear(tribe)
        return _clear(candidates[0][0])
    # ALLY removal: if the faction still has a CITADEL piece here, the city
    # tribe is represented by that Citadel — keep it allied and clear a
    # non-city tribe instead.
    citadel_remains = count_pieces(state, region, faction, CITADEL) > 0
    for tribe, is_city in candidates:
        if not (is_city and citadel_remains):
            return _clear(tribe)
    return _clear(candidates[0][0])


# ============================================================================
# Control-flag maintenance — §1.6 / CLAUDE.md "Piece Operations"
# ============================================================================
# CLAUDE.md promises that the piece-operation helpers "recalculate control".
# Historically only some *callers* did (execute_march, rally_in_region, ...),
# so any path that placed/removed/moved pieces without its own refresh —
# notably the bot March path and ~dozens of Event handlers — left stale
# ``space["control"]`` flags that planners and Winter logic then read.
# Control is a region-local function of the pieces in that region (§1.6), so
# each mutating helper now refreshes exactly the region(s) it touched.

def _refresh_region_control(state, *regions):
    from fs_bot.board.control import calculate_control
    from fs_bot.cards.circumvallation import clear_without_romans
    spaces = state.get("spaces", {})
    for region in regions:
        if region in spaces:
            clear_without_romans(state, region)
            spaces[region]["control"] = calculate_control(state, region)


_place_piece_inner = place_piece


def place_piece(state, region, faction, piece_type, count=1, **kwargs):
    _validate_count(count)
    if count == 0:
        return
    _validate_region(state, region)
    _validate_visibility(kwargs.get("piece_state"))
    from fs_bot.engine.diviciacus import place_converted
    if place_converted(state, region, faction, piece_type, count, **kwargs):
        _refresh_region_control(state, region)
        return
    result = _place_piece_inner(state, region, faction, piece_type, count,
                                **kwargs)
    _refresh_region_control(state, region)
    return result


place_piece.__doc__ = _place_piece_inner.__doc__

_remove_piece_inner = remove_piece


def _enlist_operation(state, region, faction, piece_type, count, operation,
                      *, owner=None, **kwargs):
    """Route borrowed counters through physical-owner piece helpers.

    Returns True when the operation was handled. The board and Available
    pools always retain each counter's actual colour, even during prompts.
    """
    from fs_bot.engine.diviciacus import operate as diviciacus_operation
    if diviciacus_operation(state, region, faction, piece_type, count, operation,
                             owner=owner, **kwargs):
        return True
    from fs_bot.battle.combined import operate
    if operate(state, region, faction, piece_type, count, operation,
               owner=owner, **kwargs):
        return True
    from fs_bot.commands.sa_enlist import (
        BORROW_KEY, FREE_FORCE_KEY, allocate_borrowed_operation,
        record_borrowed_change)
    from fs_bot.rules_consts import BELGAE
    free = state.get(FREE_FORCE_KEY)
    free = free if free and region in free["pieces"] and faction == free.get("faction", GERMANS) else None
    borrow = state.get(BORROW_KEY)
    if not free and not (borrow and faction in (BELGAE, GERMANS)):
        if owner is not None:
            raise PieceError("Physical-owner selection requires Enlist")
        return False
    if piece_type != WARBAND:
        if free:
            raise PieceError("Free Enlist Battle cannot affect other German pieces")
        return False
    ps = kwargs.get("from_state") if operation == "flip" else kwargs.get("piece_state")
    if free:
        if type(count) is not int or count < 0:
            raise PieceError("Warband count must be a non-negative integer")
        remaining, allocations = count, []
        for visibility in ((ps,) if ps else (HIDDEN, REVEALED, SCOUTED)):
            take = min(remaining, free["pieces"][region].get(visibility, 0))
            if take:
                allocations.append((faction, visibility, take))
                remaining -= take
        if remaining:
            raise PieceError("Not enough selected Enlist Warbands")
    else:
        allocations = allocate_borrowed_operation(state, region, faction,
                                                   count, ps, owner=owner)
    for physical, visibility, n in allocations:
        params = dict(kwargs)
        dest = params.pop("destination", None)
        if operation == "remove":
            params["piece_state"] = visibility
            _remove_piece_inner(state, region, physical, WARBAND, n, **params)
            new_state = None
        elif operation == "move":
            _move_piece_inner(state, region, dest, physical, WARBAND, n,
                               piece_state=visibility)
            new_state = None
        else:
            new_state = params["to_state"]
            if visibility == SCOUTED and new_state == HIDDEN:
                new_state = REVEALED
            _flip_piece_inner(state, region, physical, WARBAND, n,
                              from_state=visibility, to_state=new_state)
        if free:
            counts = free["pieces"][region]
            counts[visibility] -= n
            if operation == "flip":
                counts[new_state] = counts.get(new_state, 0) + n
            elif operation == "move":
                counts = free["pieces"].setdefault(dest, {})
                counts[visibility] = counts.get(visibility, 0) + n
        elif faction == BELGAE and physical == GERMANS:
            record_borrowed_change(state, region, visibility, n,
                                   destination=dest, new_state=new_state)
    return True


def remove_piece(state, region, faction, piece_type, count=1, **kwargs):
    _validate_count(count)
    if count == 0:
        return
    _validate_region(state, region)
    _validate_visibility(kwargs.get("piece_state"))
    owner = kwargs.pop("physical_owner", None)
    if _enlist_operation(state, region, faction, piece_type, count, "remove",
                          owner=owner, **kwargs):
        _refresh_region_control(state, region)
        return
    result = _remove_piece_inner(state, region, faction, piece_type, count,
                                 **kwargs)
    _refresh_region_control(state, region)
    return result


remove_piece.__doc__ = _remove_piece_inner.__doc__

_move_piece_inner = move_piece


def move_piece(state, from_region, to_region, faction, piece_type, count=1,
               **kwargs):
    _validate_count(count)
    if count == 0:
        return
    _validate_region(state, from_region)
    _validate_region(state, to_region)
    _validate_visibility(kwargs.get("piece_state"))
    owner = kwargs.pop("physical_owner", None)
    if _enlist_operation(state, from_region, faction, piece_type, count, "move",
                          owner=owner, destination=to_region, **kwargs):
        _refresh_region_control(state, from_region, to_region)
        return
    result = _move_piece_inner(state, from_region, to_region, faction,
                               piece_type, count, **kwargs)
    _refresh_region_control(state, from_region, to_region)
    return result


move_piece.__doc__ = _move_piece_inner.__doc__


_flip_piece_inner = flip_piece


def flip_piece(state, region, faction, piece_type, count=1, **kwargs):
    _validate_count(count)
    if count == 0:
        return
    _validate_region(state, region)
    _validate_visibility(kwargs.get("from_state"))
    _validate_visibility(kwargs.get("to_state"))
    owner = kwargs.pop("physical_owner", None)
    if _enlist_operation(state, region, faction, piece_type, count, "flip",
                          owner=owner, **kwargs):
        return
    return _flip_piece_inner(state, region, faction, piece_type, count, **kwargs)


flip_piece.__doc__ = _flip_piece_inner.__doc__
