from pathlib import Path
import json
import re
import subprocess
import xml.etree.ElementTree as ET
from fs_bot import rules_consts as rc
from fs_bot.tools.validation_metadata import source_identity

parent='aec38386839b7a6e3653c9b6b12812cf36de6657'
source=source_identity()
assert source['source_sha256']=='0f1171979d2ee624a2697545a6f68054f23e8e05a4e5dce025f843af66fe0f39'
assert len(list(Path('fs_bot').rglob('*.py')))==505
records={}
for label,directory in [('parent','/tmp/fs-interlude-bots-parent'),('accepted','/tmp/fs-interlude-accepted-bots')]:
    rows=[json.loads(line) for line in Path(directory+'/games.jsonl').read_text().splitlines()]
    records[label]={(row['scenario'],row['seed']):row for row in rows}
    assert len(rows)==10 and set(records[label])=={(s,n) for s in rc.ALL_SCENARIOS for n in (1,2)}
    for row in rows:
        assert all(row[key] for key in ('completed','game_completed','audit_completed','final_state_sha256'))
        assert not row['errors'] and not row['integrity_findings']
        assert len(row['final_ranking'])==4 and not row['winner_differs_from_highest_margin']
        assert not row['engine_ranking_output_missing']
        assert all(d['severity']=='legal-decline' for d in row['diagnostics'])
ignored={'seconds','commit','source_sha256'}
for key,old in records['parent'].items():
    new=records['accepted'][key]
    assert {k:v for k,v in old.items() if k not in ignored}=={k:v for k,v in new.items() if k not in ignored},key
assert records['accepted'][rc.SCENARIO_GALLIC_WAR,1]['interlude_completed']
assert json.loads(Path('/tmp/fs-interlude-bots-parent/metadata.json').read_text())['source_sha256']=='51e1c13b45ee217dcbeeaabea806ea094575b8cac1fe54258a1948b5ac5edf2c'
assert json.loads(Path('/tmp/fs-interlude-accepted-bots/metadata.json').read_text())['source_sha256']==source['source_sha256']
mixed=json.loads(Path('/tmp/fs-interlude-accepted-mixed0.json').read_text())
assert mixed==json.loads(Path('/tmp/fs-interlude-accepted-mixed987.json').read_text())
assert not mixed['hard_findings'] and mixed['partial']==0 and all(r['game_completed'] for r in mixed['records'])
assert mixed['metadata']['source_sha256']==source['source_sha256']
protected=[p for p in Path('Reference Documents').rglob('*') if p.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
assert len(protected)==49
for path in protected:
    assert path.read_bytes()==subprocess.check_output(['git','show',parent+':'+str(path)])
proof=ET.parse('/tmp/fs-interlude-proof-parent.xml').getroot().find('testsuite')
assert proof.attrib['tests']=='6' and proof.attrib['failures']=='4' and proof.attrib['errors']=='0'
assert all(('assert' in t.find('failure').attrib['message'].lower() or
            'did not raise' in t.find('failure').attrib['message'].lower())
           for t in proof if t.find('failure') is not None)
accepted_proof=ET.parse('/tmp/fs-interlude-accepted-proof.xml').getroot().find('testsuite')
assert accepted_proof.attrib['tests']=='6' and accepted_proof.attrib['failures']=='0' and accepted_proof.attrib['errors']=='0'
assert re.search(r'\n330 passed in ',Path('/tmp/fs-interlude-accepted-targeted.log').read_text())
log=Path('/tmp/fs-interlude-accepted-balance.log').read_text()
rows=re.findall(r'^\[(.*?) seed=\s*(\d+)\] winner=(.*?) \((\d+) cards\)$',log,re.M)
assert len(rows)==100 and {(s,int(n)) for s,n,_,_ in rows}=={(s,n) for s in rc.ALL_SCENARIOS for n in range(1,21)}
deltas=[abs(int(v)) for v in re.findall(r'\(([+-]\d+)%\)',log)]
assert deltas and max(deltas)<=15 and 'OK: balance within band' in log
changes=int(re.search(r'OK: balance within band \((\d+) winner changes\)',log)[1])
result={'date':'2026-11-04','timezone':'America/Chicago','source':source,'python_files':505,
        'protected_files':49,'protected_files_unchanged':True,'new_tests':53,'targeted_passed':330,
        'parent_proof':{'behavioral_failures':4,'controls_passed':2,'accepted_passed':6},
        'bots':{'games':10,'all_completed_and_audited':True,'gameplay_and_final_hashes_equal':True,
                'interlude_exercised':{'scenario':rc.SCENARIO_GALLIC_WAR,'seed':1},'excluded':sorted(ignored)},
        'mixed':mixed,'mixed_complete_json_equal':True,'hash_seeds':[0,987],'mixed_executions_including_replay':40,
        'balance':{'games':100,'band_percentage_points':15,'maximum_absolute_delta_percentage_points':max(deltas),
                   'historical_baseline_winner_changes':changes,'baseline_unchanged':True,'passed':True},
        'progress':{'closed':36,'total':50,'percent':72,'open':14},
        'remaining':'WS-F01 force reductions and Cisalpina relocations remain open; separate mechanics leads and source questions retain their dispositions.'}
Path('/tmp/fs-interlude-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':source,'bots_equal':10,'mixed_equal':True,'hard_findings':0,'partials':0,
                  'new_cases':53,'targeted':330,'balance_max_delta_pp':max(deltas)}))
