"""Verify final directed outputs and record independent rerun provenance."""
import hashlib
import json
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parent
AUDIT=ROOT.parent.parent
REPO=AUDIT.parent/'falling-sky'
PYTHON='/workspace/scratch/4aba5bd9b1ab/fs-bot/.venv/bin/python'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

records=[]
for lane in ('battle','bots','events','frontend','lifecycle'):
    script=AUDIT/lane/f'probe_{lane}.py'
    outputs=[ROOT/f'{lane}-{seed}.json' for seed in (0,987)]
    assert outputs[0].read_bytes()==outputs[1].read_bytes()==(AUDIT/lane/'results.json').read_bytes(),lane
    payload=json.loads(outputs[0].read_text())
    assert payload
    snapshot=ROOT/f'{lane}-probe.py'
    shutil.copyfile(script,snapshot)
    records.append(dict(lane=lane,script=str(script),script_sha256=sha(script),preserved_script=snapshot.name,
        hash_seeds=[0,987],exit_codes=[0,0],byte_identical_stdout=True,preserved_output_matches=True,
        stdout_sha256=sha(outputs[0]),outputs=[p.name for p in outputs],commands=[
            f'PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED={seed} {PYTHON} {script} --repo {REPO} > {ROOT}/{lane}-{seed}.json'
            for seed in (0,987)]))
source=json.loads((ROOT.parent/'source.json').read_text())
result=dict(audited_commit=source['commit'],source_sha256=source['source_sha256'],
            lanes=records,all_finalized_lane_reruns_byte_identical=True)
(ROOT/'reruns.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
