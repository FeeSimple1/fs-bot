"""Require exact tested source, completed matrix and reviewed outcome changes."""
from pathlib import Path
import json,subprocess,xml.etree.ElementTree as ET
from integration_matrix import identity,protected_files
E=Path(__file__).resolve().parent;R=E.parent/'fs-bot'
read=lambda p:json.loads((E/p).read_text())
source=read('candidate-source-attempt1.json');assert identity()==source
assert protected_files()==read('protected-before.json')
m=read('attempt1/integration-results.json')
assert m['passed'] and not m['failures']
assert m['source']['python_sha256']==source['python_sha256']
assert m['bot_games']==150 and m['bot_hash_seed_repeat_executions']==25
assert m['mixed_seat_distinct_cases']==220
assert m['mixed_seat_executions_including_replay_and_hash_repeat']==880
assert m['strict_census_executions']==20
assert all(x['hard_findings']==x['partial']==0 for x in m['fuzz'].values())
assert m['baseline_comparison']['passed'] and not m['baseline_comparison']['baseline_changed']
assert m['parent_comparison']['all_editions_semantic_changes']==7
c=read('causal-review/attempt1/review-summary.json')
x=read('causal-review/attempt1/source-explanation-inputs.json')
assert c['candidate_sha256']==x['candidate_source_sha256']==source['python_sha256']
assert c['capture_executions']==14 and c['all_traces_match_matrix_records']
assert c['all_first_divergences_at_litaviccus'] and len(c['reviews'])==len(x['cases'])==7
assert all(r['equal_preceding_board_and_rng'] and r['matrix_outcome_reproduced'] for r in c['reviews'])
assert sum(r['stage']=='decision-after' for r in x['cases'])==3
assert all(r['predicted_plan'] is None and r['input_and_rng_unchanged'] and
           all(v['minimum_legion_losses']==0 for v in r['regions'])
           for r in x['cases'] if r['stage']=='decision-after')
independent=read('causal-review/attempt1/causal-source-review.json')
assert independent['all_reviewed'] and not independent['unexplained_cases']
assert independent['candidate_source_sha256']==source['python_sha256']
assert independent['exact_changed_case_set_matches_matrix']
assert independent['independent_engine_review']['confirmed_all_seven_cases']
root_review={'reviewed_by':'root','all_reviewed':True,'changed_records':7,
 'complete_trace_executions':14,'unexplained_first_divergences':[],
 'candidate_source_sha256':source['python_sha256'],
 'mechanisms':{'No Belgae with zero predicted Legion Losses':3,
               'Aedui Counterattack casualties':2,'Aedui survivors Reveal':2},
 'sources':['Card Reference45','Belgic Event instruction45','Chapter8 sections8.2.3/8.5.1','Chapter3 Battle procedure'],
 'evidence':['causal-review/attempt1/review-summary.json','causal-review/attempt1/source-explanation-inputs.json'],
 'limits':'All seven first differences are source-supported; this is not an exhaustive proof of every later decision.'}
(E/'root-causal-review.json').write_text(json.dumps(root_review,indent=2)+'\n')
def junit(name):
 suites=list(ET.parse(E/name).getroot().iter('testsuite'))
 return {k:sum(int(s.get(k,'0')) for s in suites) for k in ('tests','failures','errors','skipped')}
parent=junit('parent-candidate-suite-attempt1.xml');final=junit('candidate-suite-attempt1.xml')
assert parent==dict(tests=7347,failures=0,errors=0,skipped=0)
assert final==dict(tests=7427,failures=0,errors=0,skipped=0)
assert '80 passed' in (E/'focused-python312.log').read_text()
subprocess.run(['git','diff','--check'],cwd=R,check=True)
p=json.loads((R/'docs/human-choice-progress.json').read_text())
assert p['total']==len(p['findings'])==50
assert p['closed']==sum(v['status']=='closed' for v in p['findings'])==20 and p['open']==30
assert p['unresolved_source_questions_separate']==2
assert p['tested_source']['python_sha256']==source['python_sha256']
a={'accepted':True,'date':'2026-11-03','timezone':'America/Chicago',
 'parent_commit':source['commit'],'final_source':{k:v for k,v in source.items() if k!='files'},
 'full_suite':final,'parent_full_suite':parent,'new_regression_cases':80,
 'focused_python312':{'version':'3.12.14','passed':80,'log':'focused-python312.log'},
 'gameplay_matrix':m,'causal_review':root_review,
 'independent_causal_review':'causal-review/attempt1/causal-source-review.json',
 'protected_inputs_unchanged':True,'protected_input_count':49,
 'provisional_ruling':{'adopted':'PR-12','subject_to_authoritative_correction':True},
 'progress':{'total':50,'closed':20,'open':30,'percent':40,'newly_closed':[],
             'unadopted_source_questions_separate':2},
 'limits':['This separately discovered follow-up does not close another original audit finding.',
           'Fixed seed samples do not establish human balance or exhaustive rules correctness.',
           'PR12 forecasts human standing/Retreat using existing default casualty priority, not every human choice.',
           'No save schema change; old response logs are not promised exact cross-version replay.',
           'Remote CI is verified separately after publication.']}
(E/'acceptance-results.json').write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps({'accepted':True,'tests':final['tests'],'matrix_checks':len(m['checks_passed']),'changed_records_reviewed':7,'source':source['python_sha256']}))
