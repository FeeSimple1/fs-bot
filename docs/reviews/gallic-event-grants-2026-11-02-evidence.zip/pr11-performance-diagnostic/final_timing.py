"""Reproducible pure-planning timings; no game matrix or search cutoff."""
import hashlib
import json
import time
from pathlib import Path

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece
from fs_bot.cards import base_arduenna_np as policy
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import build_initial_state, validate_state


def measure(name, state):
    state.update(current_card=67, next_card=3,
                 non_player_factions={rc.ROMANS, rc.ARVERNI, rc.AEDUI, rc.BELGAE})
    assert not validate_state(state)
    before = encode(state)
    start = time.perf_counter()
    result = policy.plan(state)
    elapsed = time.perf_counter() - start
    assert encode(state) == before
    return {'position': name, 'seconds': elapsed, 'plan': result,
            'live_board_and_rng_unchanged': True}


spread = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=260)
for origin in (rc.ATREBATES, rc.SEQUANI, rc.MANDUBII, rc.MORINI,
               rc.SUGAMBRI, rc.UBII, rc.NERVII):
    place_piece(spread, origin, rc.ARVERNI, rc.WARBAND, 5)
for target in policy.TARGETS:
    place_piece(spread, target, rc.ROMANS, rc.LEGION, 3, from_legions_track=True)
results = [measure('35 Warbands, seven occupied origins', spread),
           measure('Great Revolt actual setup seed260',
                   setup_scenario(rc.SCENARIO_GREAT_REVOLT, seed=260))]
print(json.dumps({'optimizer_sha256': hashlib.sha256(
    Path(policy.__file__).read_bytes()).hexdigest(), 'results': results}, indent=2))
