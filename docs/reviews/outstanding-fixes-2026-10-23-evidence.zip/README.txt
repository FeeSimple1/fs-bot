Falling Sky validation evidence, 23 October 2026

Tested engine commit: c7264cb3d2afbf08ccfce140af6e03b0f17138ae
final-validation: first failed 1,000-game attempt, preserved unchanged.
final-validation-2: second failed attempt, preserved unchanged.
final-validation-3: accepted complete matrix on the corrected source.
checks: before/after balance baseline, full-suite JUnit, unchanged-baseline
check. The report links remote CI for the tested source commit.

outcomes-and-evidence.json contains acceptance checks, per-scenario rates,
game termination timing, exact commands, source digest, and artifact hashes.
Each games.jsonl contains every attempted game, including failed games in
the first two attempts. Their partial outcome rates are not final results.
Every entry is independently hashed in CONTENTS.sha256. Original manifests
retain their actual absolute paths as provenance.

To reproduce, check out the tested commit into a directory named fs-bot.
Use Python 3.12 and install requirements-dev.txt. Copy orchestrate.py and
extract_results.py from final-validation-3 into a NEW sibling directory
next to fs-bot. Never run into these preserved evidence directories.
Run python <new-directory>/orchestrate.py commands to inspect commands;
run ... run --stage batch, inspect the batch, then run the remaining stages
individually and ... verify. The orchestrator sets PYTHONHASHSEED before
each child process and rejects changes to the Python source between stages.
Unit gate: python -m pytest -q (xdist -n 4 was used locally).
Balance: python -m fs_bot.tools.balance_smoke --seeds 1-20.

These tests demonstrate the named paths and seeds. They do not prove all
possible positions or settle the six documented source ambiguities.
