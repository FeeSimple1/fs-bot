# Seventh comparison audit, frontend partition

Audited Falling Sky commit `c67d501711471bf790d805c017c2125b2c254639`; comparator Liberty or Death commit `2991ea279062773548ec390a1da75f3e85381702`. No production files modified.

One confirmed repair group is in `findings.json`.

- FE7-01 uses `probe_surus.py`, recorded in `probe_surus-output.json`. All six cases execute the public `execute_decision` Event path. Single all-piece and single subset Marches are legal controls. The forbidden two-group split succeeds in canonical `extra_groups`, alternate `explicit_moves`, and an actual `_collect_march` terminal-generated response. A sixth case saves the durable pending request, reloads it, accepts the same illegal response, and replays the resulting board exactly. Every fixture has clean before/after schema and structural checks. Output matches byte-for-byte with `PYTHONHASHSEED=987` under the audit venv.

## Comparison and coverage

Read comparator `coin-implementation-lessons.md`, especially free/forced-command boundary and per-space restriction patterns, and `docs/human_mode_audit.md`, including its correction distinguishing hook coverage from complete legal-choice coverage. Followed shared free Command and standalone SA validation into their actual executors, compared ordinary and Event structure checks, read Assembly of Gaul's two-ability handling, and checked human March route/group collection and exact physical-cohort selection. Reviewed source-defined base German vs Ariovistus movement differences, Surus scoped replacement forces, German-guidance dedicated schemas, and Enlist's new split-group implementation.

Reviewed all earlier comparison JSON finding titles/related details, original human-choice audit and 29 October action-timing report, 3 November Event-validation report, and sixth repair Batch 4 to screen duplicates. Surus's NPC `_spread` already explicitly obeys the base single-group restriction; the witnessed defect is the human generic grant/terminal path.

No independent new defect was established in ordinary/Assembly Aedui Ambush limits, event-only Battle fields, nested Seize fields, Suborn region/operation quotas, standalone SA geographic scope, Britannia crossing checks, original-cohort exclusion during ordinary March, or exact physical piece ownership under scoped Surus. These were targeted source/code reviews, not exhaustive test coverage claims. Suspected generic malformed-count coercion was not promoted because it lacked a distinct source-backed illegal result. No new unresolved rules question was required.

## Existing regression checks

`focused-tests-venv.log` records **99 passed in 20.99s** for:

```
python -m pytest -q fs_bot/tests/test_surus_choices.py fs_bot/tests/test_surus_replacements.py fs_bot/tests/test_sixth_comparison_free_actions.py fs_bot/tests/test_fifth_comparison_free_march.py fs_bot/tests/test_german_guidance.py --tb=short
```

The actual runner was `/workspace/scratch/5473f6589808/audit-venv/bin/python`. The first invocation used the primary runtime without pytest and did not collect tests (`focused-tests.log`); only the venv run counts. The witness itself uses standard library only. `probe_terminal_explore.py` is exploratory input-menu inspection; the complete terminal and public execution evidence is integrated into `probe_surus.py`.
