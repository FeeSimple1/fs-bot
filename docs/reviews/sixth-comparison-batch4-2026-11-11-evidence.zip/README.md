# Sixth comparison repair Batch 4 evidence

The parent is `8491880e6e2e01454824aba8e6babb08b3932a36`. The tested
Python source and verified results are in `final/source.json` and
`final/summary.json`. `SHA256SUMS.json` covers every other archive member.

Run the following from the repaired checkout with Python 3.12, pytest and
pytest-xdist. Use fresh output paths.

```sh
PYTHONHASHSEED=0 python -m pytest -q fs_bot/tests/test_sixth_comparison_free_actions.py
PYTHONHASHSEED=0 python -m pytest -q -n 5 --dist loadfile --tb=short --show-capture=no --junitxml=pytest.xml
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 3 --out bots-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 41-44 --card-edition second-edition --workers 2 --out bots-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
```

The 100 reviewed records in `final/balance-baseline.json` passed the
15-point band. Batch 3 and the reviewed baseline have separate outcomes.

The copied test file reproduces 16 failures and three passing controls
when run from the parent checkout.

```sh
PYTHONPATH=. PYTHONHASHSEED=0 python -m pytest -q --tb=short /path/to/evidence/test_parent_free_actions.py
```

To verify the archived results, extract this archive and the Batch 3
archive into separate directories. Run the verifier from the repaired
checkout. It checks exact source digests, full matrix coverage, game
audits, gameplay fields across all paired records, and deterministic
mixed-player replays.

```sh
PYTHONPATH=. python /path/to/evidence/verify_results.py /path/to/batch3-evidence/final
```
