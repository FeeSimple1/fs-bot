"""Verify the Aedui repair matrix, replay pairs, and outcome changes."""

import json
import re
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree

from fs_bot.state.serialize import decode
from fs_bot.tools.balance_smoke import BASELINE_PATH
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


ROOT = Path(__file__).resolve().parent
PARENT = '2a91f8104b1454bdbb9770d69ff7499cdaad250a'
PARENT_DIGEST = 'f966e191008ca5591d88f39f92da973d8a3fdc6674d53c18f2c32040fac7c46d'
BASELINE_PATTERN = re.compile(r'^\[(.+) seed= *([0-9]+)\] winner=(.+) \(([0-9]+) cards\)$', re.M)


def load(name):
    return json.loads((ROOT / name).read_text())


def key(row):
    return row['scenario'], row['seed'], row['card_edition']


def tests(name):
    suites = list(ElementTree.parse(ROOT / name).iter('testsuite'))
    return {k: sum(int(s.get(k, 0)) for s in suites)
            for k in ('tests', 'failures', 'errors', 'skipped')}


def batch(path, seeds, edition, digest):
    meta = load(f'{path}/metadata.json')
    assert meta['source_sha256'] == digest and meta['hash_seed'] == 0
    assert set(meta['scenarios']) == set(SCENARIOS)
    assert meta['seeds'] == list(seeds) and meta['card_edition'] == edition
    records = [json.loads(line) for line in (ROOT / path / 'games.jsonl').read_text().splitlines()]
    games = {key(r): r for r in records}
    assert len(games) == len(records) == len(seeds) * len(SCENARIOS)
    assert games.keys() == {(s, n, edition) for s in SCENARIOS for n in seeds}
    for row in records:
        assert row['source_sha256'] == digest
        assert all(row[k] is True for k in ('completed', 'game_completed', 'audit_completed'))
        assert not row.get('error') and not row['errors'] and not row['integrity_findings']
        assert not _outcome_issues(row)
        assert len(row['final_state_sha256']) == 64
        assert all(d['severity'] == 'legal-decline' for d in row['diagnostics'])
        assert all(d['severity'] == 'legal-decline' for d in row['diagnostic_occurrences'])
        assert sum(d['count'] for d in row['diagnostics']) == len(row['diagnostic_occurrences'])
    return games


def compare(old, new):
    fields = ('final_state_sha256', 'cards', 'winters', 'winner', 'termination',
              'ended_on_final_winter', 'diagnostic_occurrences', 'final_ranking')
    assert old.keys() == new.keys()
    differences = {field: [list(k) for k in sorted(new) if new[k][field] != old[k][field]]
                   for field in fields}
    return {'games': len(new), 'interludes': sum(r['interlude_completed'] for r in new.values()),
            'diagnostic_incidents': sum(len(r['diagnostic_occurrences']) for r in new.values()),
            'differences': differences}


def fuzz_pair(first, second, seeds, digest):
    for extension in ('json', 'log'):
        assert (ROOT / f'{first}.{extension}').read_bytes() == (ROOT / f'{second}.{extension}').read_bytes()
    data = load(f'{first}.json')
    assert data['metadata']['source_sha256'] == digest
    assert all(data['metadata'][k] for k in ('reactive', 'events', 'replay'))
    expected = {(s, n, 'second-edition') for s in SCENARIOS for n in seeds}
    assert len(data['records']) == data['games'] == len(expected)
    assert {key(r) for r in data['records']} == expected
    assert all(r['game_completed'] and not r['findings'] for r in data['records'])
    assert not data['hard_findings']
    for field in ('human_turns', 'event_turns', 'events_ok', 'partial'):
        assert data[field] == sum(r[field] for r in data['records'])
    return data


def first_difference(parent, repaired, *, physical=False):
    for before, after in zip(parent, repaired):
        assert before['ordinal'] == after['ordinal'] and before['card'] == after['card']
        same_board = before['after_sha256'] == after['after_sha256']
        same_action = before['actions_sha256'] == after['actions_sha256']
        if not same_board or (not physical and not same_action):
            assert before['before_sha256'] == after['before_sha256']
            assert before['before_rng_sha256'] == after['before_rng_sha256']
            return before, after
    assert len(parent) == len(repaired)
    return None


def effects(card):
    for row in card['aedui']:
        result = row['result']
        yield result
        for grant in result.get('free_actions', ()):
            if isinstance(grant.get('result'), dict):
                yield grant['result']


def summarize_change(before, after):
    old, new = [list(effects(card)) for card in (before, after)]
    old_commands = [e for e in old if e.get('command') in ('Battle', 'Rally')]
    new_commands = [e for e in new if e.get('command') in ('Battle', 'Rally')]
    assert len(old_commands) == len(new_commands) and old_commands
    for a, b in zip(old_commands, new_commands):
        assert a['command'] == b['command']
        if a['command'] == 'Battle' and a['battles_resolved'] != b['battles_resolved']:
            return {'change': 'additional Battle', 'before': a['battles_resolved'],
                    'after': b['battles_resolved']}
        if a['command'] == 'Rally' and a.get('sa_execution') != b.get('sa_execution'):
            assert a['placements'] == b['placements']
            return {'change': 'post-Rally Special Ability',
                    'before': a.get('sa_execution'), 'after': b.get('sa_execution')}
    raise AssertionError((before, after))


def trace_pairs(kind, old, new, keys, digest):
    def traces(side, expected_digest):
        trace = decode(load(f'trace_{kind}_{side}.json'))
        assert trace['source']['source_sha256'] == expected_digest
        rows = {tuple(row['task']): row for row in trace['games']}
        assert set(rows) == set(keys) and len(rows) == len(trace['games'])
        return rows

    first = []
    parent, repaired = traces('parent', PARENT_DIGEST), traces('final', digest)
    for task in sorted(keys):
        for trace, recorded in ((parent, old), (repaired, new)):
            assert all(recorded[task][field] == value
                       for field, value in trace[task]['outcome'].items())
        a, b = first_difference(parent[task]['cards'], repaired[task]['cards'])
        row = {'task': task, 'first_different_record': a['ordinal'], 'card': a['card']}
        board = first_difference(parent[task]['cards'], repaired[task]['cards'], physical=True)
        if board is None:
            assert kind == 'mixed'
            assert any(item['action']['command'] == 'Rally' for item in b['aedui'])
            row.update(change='Rally plan only', first_different_board=None)
        else:
            x, y = board
            row.update(first_different_board=x['ordinal'], board_card=x['card'],
                       **summarize_change(x, y))
        first.append(row)
    return first


def balance_records(name):
    matches = BASELINE_PATTERN.findall((ROOT / name).read_text())
    values = {f'{scenario}|{seed}': {'winner': winner, 'cards': int(cards)}
              for scenario, seed, winner, cards in matches}
    assert len(matches) == len(values)
    return values


def balance(legacy, parent):
    def matrix(rows):
        return {f'{scenario}|{seed}': {k: r[k] for k in ('winner', 'cards')}
                for (scenario, seed, _), r in rows.items()}
    old, current = matrix(parent), matrix(legacy)
    assert balance_records('parent/balance-final.log') == old
    assert balance_records('balance-final.log') == current
    assert json.loads(BASELINE_PATH.read_text())['games'] == old
    assert 'OK: balance within band' in (ROOT / 'balance-final.log').read_text()
    changes = {k: {'from': old[k], 'to': current[k]} for k in current if current[k] != old[k]}
    return {'games': len(current), 'band_percentage_points': 15,
            'canary_band_percentage_points': 40, 'changes': changes}


def main():
    source = load('source-verified.json')
    digest = source['source_sha256']
    assert source['commit'] == PARENT and source['python_files'] == 616
    assert source_identity()['source_sha256'] == digest
    parent_tests, focused, full = (tests(n) for n in
        ('parent-directed-final.xml', 'focused-final.xml', 'pytest-final.xml'))
    assert parent_tests == dict(tests=29, failures=14, errors=0, skipped=0)
    assert focused == dict(tests=326, failures=0, errors=0, skipped=0)
    assert full == dict(tests=10207, failures=0, errors=0, skipped=0)

    comparisons, parent_bots, repaired_bots = {}, {}, {}
    for name, edition, seeds in (('final-legacy', 'legacy', range(1, 21)),
                                 ('final-second', 'second-edition', range(45, 49))):
        old = batch(f'parent/{name}', seeds, edition, PARENT_DIGEST)
        new = batch(name, seeds, edition, digest)
        comparisons[edition] = compare(old, new)
        parent_bots.update(old)
        repaired_bots.update(new)
        if edition == 'legacy':
            verified_balance = balance(new, old)
    bot_keys = {k for k in repaired_bots if repaired_bots[k]['final_state_sha256']
                != parent_bots[k]['final_state_sha256']}
    bot_traces = trace_pairs('bots', parent_bots, repaired_bots, bot_keys, digest)

    fuzz = fuzz_pair('fuzz0-final', 'fuzz987-final', range(45, 49), digest)
    ci_fuzz = fuzz_pair('fuzz-ci0', 'fuzz-ci7', range(201, 204), digest)
    old_mixed, new_mixed = {}, {}
    for prior, current in (('fuzz0-final', fuzz), ('fuzz-ci0', ci_fuzz)):
        old = load(f'parent/{prior}.json')
        assert old['metadata']['source_sha256'] == PARENT_DIGEST
        old_mixed.update({key(row): row for row in old['records']})
        new_mixed.update({key(row): row for row in current['records']})
    assert old_mixed.keys() == new_mixed.keys()
    mixed_keys = {k for k in new_mixed if old_mixed[k]['digest'] != new_mixed[k]['digest']}
    mixed_traces = trace_pairs('mixed', old_mixed, new_mixed, mixed_keys, digest)

    def mixed_summary(data, hashes):
        return {**{k: data[k] for k in ('games', 'human_turns', 'event_turns', 'events_ok',
                                       'partial', 'hard_findings', 'batch_digest')},
                'hash_seeds': hashes, 'json_and_stdout_match': True}
    print(json.dumps({
        'source': source, 'parent_directed': parent_tests, 'focused': focused,
        'full_suite': full, 'bots': comparisons,
        'bot_first_differences': bot_traces, 'mixed_first_differences': mixed_traces,
        'bot_first_change_counts': Counter(r['change'] for r in bot_traces),
        'mixed_first_change_counts': Counter(r['change'] for r in mixed_traces),
        'mixed': mixed_summary(fuzz, [0, 987]), 'ci_mixed': mixed_summary(ci_fuzz, [0, 7]),
        'balance': verified_balance,
    }, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
