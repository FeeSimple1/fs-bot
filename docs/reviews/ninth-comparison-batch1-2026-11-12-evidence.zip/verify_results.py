"""Check the audit witnesses, paired outcomes and reviewed balance inputs."""

from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
import re
from xml.etree import ElementTree

from fs_bot.state.serialize import decode
from fs_bot.tools.balance_smoke import BASELINE_PATH
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


ROOT = Path(__file__).resolve().parent
PARENT_DIGEST = '57a94d20440986063d7f86224a6074fa0ea2ce471e58e24e9c5dd349ec799033'
BALANCE_LINE = re.compile(r'^\[(.+) seed= *([0-9]+)\] winner=(.+) \(([0-9]+) cards\)$', re.M)


def load(path):
    return json.loads((ROOT / path).read_text())


def key(record):
    return record['scenario'], record['seed'], record['card_edition']


def suite(path):
    elements = list(ElementTree.parse(ROOT / path).iter('testsuite'))
    totals = {field: sum(int(s.get(field, 0)) for s in elements)
              for field in ('tests', 'failures', 'errors', 'skipped')}
    totals['seconds'] = sum(float(s.get('time', 0)) for s in elements)
    return totals


def batch(path, edition, seeds, source_digest):
    meta = load(f'{path}/metadata.json')
    assert meta['source_sha256'] == source_digest
    assert meta['hash_seed'] == 0 and meta['card_edition'] == edition
    assert set(meta['scenarios']) == set(SCENARIOS) and meta['seeds'] == list(seeds)
    rows = [json.loads(line) for line in (ROOT / path / 'games.jsonl').read_text().splitlines()]
    records = {key(row): row for row in rows}
    assert len(rows) == len(records) == len(seeds) * len(SCENARIOS)
    assert records.keys() == {(s, n, edition) for s in SCENARIOS for n in seeds}
    for row in rows:
        assert all(row[k] is True for k in ('completed', 'game_completed', 'audit_completed'))
        assert row['source_sha256'] == source_digest
        assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row)
        assert len(row['final_state_sha256']) == 64
        assert all(d['severity'] == 'legal-decline' for d in row['diagnostics'])
        assert all(d['severity'] == 'legal-decline' for d in row['diagnostic_occurrences'])
        assert sum(d['count'] for d in row['diagnostics']) == len(row['diagnostic_occurrences'])
    return records


def compare_games(before, after):
    assert before.keys() == after.keys()
    fields = ('final_state_sha256', 'winner', 'cards', 'interlude_completed')
    return {
        'games': len(after),
        'interludes': sum(row['interlude_completed'] for row in after.values()),
        'legal_declines': sum(len(row['diagnostic_occurrences']) for row in after.values()),
        'changes': {field: [list(k) for k in sorted(after) if before[k][field] != after[k][field]]
                    for field in fields},
    }


def verify_mixed(source_digest):
    for suffix in ('json', 'log'):
        assert (ROOT / f'fuzz0.{suffix}').read_bytes() == (ROOT / f'fuzz987.{suffix}').read_bytes()
    parent, candidate = load('parent/fuzz0.json'), load('fuzz0.json')
    for data, digest in ((parent, PARENT_DIGEST), (candidate, source_digest)):
        assert data['metadata']['source_sha256'] == digest
        assert all(data['metadata'][field] for field in ('reactive', 'events', 'replay'))
        assert data['games'] == len(data['records']) == 20
        assert {key(row) for row in data['records']} == {
            (scenario, seed, 'second-edition') for scenario in SCENARIOS for seed in range(49, 53)
        }
        assert not data['hard_findings']
        assert all(row['game_completed'] and not row['findings'] for row in data['records'])
        for field in ('human_turns', 'event_turns', 'events_ok', 'partial'):
            assert data[field] == sum(row[field] for row in data['records'])
    old = {key(row): row for row in parent['records']}
    new = {key(row): row for row in candidate['records']}
    return ({k: candidate[k] for k in ('games', 'human_turns', 'event_turns', 'events_ok',
                                       'partial', 'hard_findings', 'batch_digest')}, old, new)


def first_difference(before, after):
    for old, new in zip(before['cards'], after['cards']):
        assert (old['ordinal'], old['card']) == (new['ordinal'], new['card'])
        if (old['after_sha256'], old['actions_sha256']) != (new['after_sha256'], new['actions_sha256']):
            assert old['before_sha256'] == new['before_sha256']
            assert old['before_rng_sha256'] == new['before_rng_sha256']
            assert old['card'] in (33, 'A40')
            return old, new
    raise AssertionError(f'No divergent card for {before["task"]}')


def verify_traces(kind, old_records, new_records, keys, source_digest):
    parent = decode(load(f'trace-{kind}-parent.json'))
    candidate = decode(load(f'trace-{kind}-repair.json'))
    assert parent['source']['source_sha256'] == PARENT_DIGEST
    assert candidate['source']['source_sha256'] == source_digest
    assert [game['task'] for game in parent['games']] == keys
    assert [game['task'] for game in candidate['games']] == keys
    results = []
    for old, new in zip(parent['games'], candidate['games']):
        task = tuple(old['task'])
        for game, record in ((old, old_records[task]), (new, new_records[task])):
            assert all(record[field] == value for field, value in game['outcome'].items())
        first, repaired = first_difference(old, new)
        results.append({'task': task, 'ordinal': first['ordinal'], 'card': first['card'],
                        'parent_actions': first['actions'], 'repaired_actions': repaired['actions'],
                        'parent_events': first['events'], 'repaired_events': repaired['events']})
    return results


def balance_records(path):
    rows = BALANCE_LINE.findall((ROOT / path).read_text())
    games = {f'{scenario}|{seed}': {'winner': winner, 'cards': int(cards)}
             for scenario, seed, winner, cards in rows}
    assert len(games) == len(rows)
    return games


def verify_balance(records):
    original = load('balance-baseline-before.json')['games']
    expected = {f'{s}|{seed}': {field: row[field] for field in ('cards', 'winner')}
                for (s, seed, _), row in records.items()}
    assert original.keys() == expected.keys()
    assert balance_records('balance.log') == expected
    assert load('balance-baseline-reviewed.json')['games'] == expected
    assert json.loads(BASELINE_PATH.read_text())['games'] == expected
    assert balance_records('balance-reviewed.log') == expected
    canary = {key: row for key, row in expected.items() if int(key.rsplit('|', 1)[1]) <= 3}
    assert balance_records('canary-reviewed.log') == canary
    assert 'OK: balance within band' in (ROOT / 'balance-reviewed.log').read_text()
    assert 'OK: balance within band' in (ROOT / 'canary-reviewed.log').read_text()
    changes = [key for key in expected if original[key] != expected[key]]
    return {'games': len(expected), 'canary_games': len(canary), 'changed_records': len(changes),
            'changed_winners': sum(original[k]['winner'] != expected[k]['winner'] for k in changes),
            'changed_lengths': sum(original[k]['cards'] != expected[k]['cards'] for k in changes),
            'full_band': str(Fraction(15, 100)), 'canary_band': str(Fraction(40, 100))}


def verify_ci_sample(source_digest):
    for suffix in ('json', 'log'):
        assert (ROOT / f'fuzz-ci0.{suffix}').read_bytes() == (ROOT / f'fuzz-ci7.{suffix}').read_bytes()
    data = load('fuzz-ci0.json')
    assert data['metadata']['source_sha256'] == source_digest
    assert all(data['metadata'][field] for field in ('reactive', 'events', 'replay'))
    assert data['games'] == len(data['records']) == 15
    assert {key(row) for row in data['records']} == {
        (scenario, seed, 'second-edition') for scenario in SCENARIOS for seed in range(201, 204)
    }
    assert not data['hard_findings']
    assert all(row['game_completed'] and not row['findings'] for row in data['records'])
    return {k: data[k] for k in ('games', 'partial', 'hard_findings', 'batch_digest')}


def main():
    source = source_identity()
    source_digest = source['source_sha256']
    tested = load('source.json')
    assert source_digest == tested['source_sha256']
    tests = {name: suite(f'{name}.xml')
             for name in ('parent-reproduced', 'focused', 'full-before-baseline', 'full')}
    assert tests['parent-reproduced']['tests'] == 23 and tests['parent-reproduced']['failures'] == 21
    assert not tests['parent-reproduced']['errors']
    assert tests['full-before-baseline']['tests'] == 10230
    assert tests['full-before-baseline']['failures'] == 1
    failures = list(ElementTree.parse(ROOT / 'full-before-baseline.xml').iter('testcase'))
    assert [node.get('name') for node in failures if node.find('failure') is not None] == [
        'test_bot_balance_canary'
    ]
    for name, count in (('focused', 317), ('full', 10230)):
        assert tests[name]['tests'] == count
        assert not any(tests[name][key] for key in ('failures', 'errors', 'skipped'))
    comparisons, traces = {}, {}
    for name, edition, seeds in (('legacy', 'legacy', range(1, 21)),
                                 ('second', 'second-edition', range(49, 53))):
        old = batch(f'parent/{name}', edition, seeds, PARENT_DIGEST)
        new = batch(name, edition, seeds, source_digest)
        comparisons[name] = compare_games(old, new)
        traces[name] = verify_traces(name, old, new, comparisons[name]['changes']['final_state_sha256'], source_digest)
        if name == 'legacy':
            balance = verify_balance(new)
    mixed, old, new = verify_mixed(source_digest)
    mixed['changed_cases'] = [list(k) for k in sorted(new) if old[k]['digest'] != new[k]['digest']]
    traces['mixed'] = verify_traces('mixed', old, new, mixed['changed_cases'], source_digest)
    summary = {'source': tested, 'tests': tests, 'bot_games': comparisons, 'mixed': mixed,
               'additional_mixed': verify_ci_sample(source_digest),
               'balance': balance, 'first_divergence': dict(Counter(
                   str(row['card']) for rows in traces.values() for row in rows))}
    print(json.dumps({'summary': summary, 'traces': traces}, indent=2))


if __name__ == '__main__':
    main()
