# Tenth Falling Sky comparison audit evidence

Audited Falling Sky commit: `ae238c6482a792dda98af4f1f9b11abf820a3964`.
Engineering comparator: Liberty or Death `2991ea279062773548ec390a1da75f3e85381702`.
Nine open medium-priority groups; no gameplay or supplied-reference changes.

## Reproduce directed findings

Use the audited repository revision and Python 3.12.14:

```bash
python run_witnesses.py --repo /absolute/path/to/fs-bot
```

The runner verifies the 620-file gameplay/test source digest and all 48
protected files, runs each canonical lane probe at hash seeds 0 and 987 in
temporary working directories, and checks stdout against the preserved
result for each hash. Four original lanes produce byte-identical output.
The lifecycle full-Winter control preserves differing Supply Line prompt
Regions with identical final board/RNG digests; it uses separate raw hash
outputs without normalization. A sixth script reproduces the resulting
saved-decision replay failure with explicit record/resume hash pairs.
A passing probe means the documented defect and its
controls reproduced. It does not mean the defect is fixed. These assertions
are expected to change when the defects are repaired.

Each lane contains `findings.json`, `report.md`, `probe_<lane>.py`, and
`results.json`. The frontend and lifecycle also preserve directly cited hash
outputs; the separate replay script is `frontend/probe_quarters_replay.py`.
`root-verification.json` records the lead's final rerun. Independent review,
script snapshots, exact original commands, and rerun hashes are under
`validation/review/`. Source and protected-file inventories are under
`validation/`.

## Broader validation

`validation/report.md` records the full suite and exact commands for the
20 audited bot games and 20 mixed-player cases, including internal replays
and two hash seeds. Raw logs and complete game records are retained. One
soft mixed-player partial plan is retained separately from hard failures.
The baseline verifier targets the audited Git commit; use that checkout
when rerunning it. Absolute paths in historical command records identify
the original environment; the portable witness runner accepts another path.

`comparator-review.md` records the actual engineering comparison. Supplied
Falling Sky/Ariovistus rules and adopted project rulings remain the rules
authority. No comparator-game rule is used as a Falling Sky rule.

`SHA256SUMS` lists SHA-256 for every other archive member. The archive
contains evidence, reports and probes, without a copy of the game source.
