"""Same public/existing engine calls on parent and repaired source trees."""
import json
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, get_leader_in_region, find_leader
from fs_bot.engine.winter import spring_phase
from fs_bot.engine.interlude import _adjust_belgae_forces
from fs_bot.state.state_schema import build_initial_state


def state(scenario=rc.SCENARIO_GREAT_REVOLT, seed=1):
    board = build_initial_state(scenario, seed=seed)
    board['non_player_factions'] = set(rc.FACTIONS)
    return board


results = {}
board = state()
place_piece(board, rc.SEQUANI, rc.BELGAE, rc.WARBAND, 4)
place_piece(board, rc.NERVII, rc.BELGAE, rc.WARBAND, 1)
spring_phase(board)
results['belgic_successor_most_own'] = {
    'actual': find_leader(board, rc.BELGAE), 'expected': rc.SEQUANI}

board = state()
board['non_player_factions'].remove(rc.ROMANS)
place_piece(board, rc.BRITANNIA, rc.ROMANS, rc.AUXILIA, 1)
requests = []
def choose(board, faction, request):
    requests.append(request.get('kind'))
    return {'region': rc.BRITANNIA}
board['decision_agent'] = choose
spring_phase(board)
results['human_successor_destination'] = {
    'actual': find_leader(board, rc.ROMANS), 'expected': rc.BRITANNIA,
    'requests': requests}

destinations = []
for seed in range(1, 13):
    board = state(seed=seed)
    place_piece(board, rc.PROVINCIA, rc.ROMANS, rc.AUXILIA, 1)
    place_piece(board, rc.SEQUANI, rc.ROMANS, rc.AUXILIA, 1)
    spring_phase(board)
    destinations.append(find_leader(board, rc.ROMANS))
results['roman_ties'] = {'destinations': destinations,
                        'distinct': sorted(set(destinations))}

board = state(rc.SCENARIO_GALLIC_WAR)
place_piece(board, rc.NERVII, rc.BELGAE, rc.LEADER, leader_name=rc.SUCCESSOR)
place_piece(board, rc.NERVII, rc.BELGAE, rc.WARBAND, 4)
_adjust_belgae_forces(board)
region = find_leader(board, rc.BELGAE)
results['interlude_restores_ambiorix'] = {
    'actual': get_leader_in_region(board, region, rc.BELGAE), 'expected': rc.AMBIORIX}
print(json.dumps(results, sort_keys=True, indent=2))
