# Sixth comparison Batch 5 validation evidence

The tested parent is `e5ad1a6009286e8b1ae2dd749f319d476fb35f58`.
`source.json` identifies the repaired Python bytes. `summary.json` records
the verified counts. The parent runs for the outcome comparison are in
the Batch 4 evidence archive alongside the Batch 5 archive in the repository.

The focused cases exercise the public bot dispatcher and command executor.
`parent-regressions.log` comes from running the new test file against Batch 4.
The full suite includes the four Aduatuci retry cases with a legal Roman
Battle threat in the fixture.

Run from the repaired repository root. Extract the archive to a fresh
directory and pass its path to the verifier.

```sh
PYTHONPATH=. python /path/to/extracted/verify_results.py /path/to/extracted
```

The recorded runs used Python 3.12.14 and these commands.

```sh
PYTHONHASHSEED=0 python -m pytest -q -n 5 --junitxml=pytest.xml
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 4 --out bots-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 41-44 --card-edition second-edition --workers 2 --out bots-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
```

`first-changes-legacy.json` and `first-changes-second.json` contain the
first changed cards. The trace script takes a list of game records and an
output path. Run it from the parent checkout using the selected parent
records. Run it from the repaired checkout using the corresponding repaired
records, passing the parent trace path as the third argument. The input
files use the scenario, edition and seed keys from the game matrices.

The earlier balance file and its comparison log record the drift that
prompted the refresh. The new balance run checks the same seed matrix at
the 15-point threshold. The verifier checks all 100 winners and game
lengths against both the audited matrix and the refreshed baseline.
