"""Bounded human Event audit probes; no production mutation or game/balance runs.
Run from fs-bot with its parent on PYTHONPATH. Empty initialized boards have
correct pools/track; all pieces use helpers; validate_state runs before/after.
Durable runs explicitly decline only voluntary-removal timing windows. A
missing ordinary human choice therefore cannot be explained by bot fallback.
"""
import io, json
from fs_bot import rules_consts as r
from fs_bot.state.state_schema import build_initial_state, validate_state
from fs_bot.board.pieces import place_piece, count_pieces, count_pieces_by_state
from fs_bot.cards.card_effects import _ally_tribe, execute_event
from fs_bot.cards.param_schema import card_param_schema
from fs_bot.engine.execute import execute_decision, _execute_intimidate
from fs_bot.engine.game_engine import ACTION_EVENT
from fs_bot.engine.moves import validate_player_action
from fs_bot.tools.seat_session import SeatSession, DecisionPending, validate_response
from fs_bot.cli.display import HumanTurnDisplay
from fs_bot.state.serialize import decode

out={}
def board():
    s=build_initial_state(r.SCENARIO_ARIOVISTUS, seed=23)
    s['non_player_factions']=set()
    return s

def action(card,shaded=False,params=None):
    return {'command':'Event','sa':'No SA','details':{'card_id':card,'text_preference':r.EVENT_SHADED if shaded else r.EVENT_UNSHADED,'event_params':params or {}}}

def durable(s,seat,card,shaded=False,params=None):
    assert validate_state(s)==[],validate_state(s)
    s['current_card']=card
    session=SeatSession(s,{'seat':seat,'scenario':s['scenario'],'seed':23},[],HumanTurnDisplay(io.StringIO()))
    s['decision_agent']=session.reactive
    # These responses are explicitly only removal-window declines. If any
    # other human decision appears it remains pending and is recorded below.
    session.import_inbox([{'reactive':'voluntary_removal','response':{'done':True}} for _ in range(100)])
    a=action(card,shaded,params)
    validate_response(s,{'kind':'turn','faction':seat,'options':[ACTION_EVENT]}, {'action':ACTION_EVENT,'player_action':a})
    try:
        result=execute_decision(s,seat,{'player_action':a})
    except DecisionPending:
        result={'pending':decode(session.data['pending']['request']), 'error':session.error}
    assert validate_state(s)==[],validate_state(s)
    requests=[decode(e['assistant_request']) for e in session.data['journal']]
    return {'result':result,'requests':[{'kind':q['kind'],'request_type':q.get('request_type')} for q in requests], 'pending':decode(session.data['pending']['request']) if session.data['pending'] else None,'valid_state':True}

s=board(); s['resources'][r.ROMANS]=10
out['A60_up_to']=durable(s,r.BELGAE,'A60',params={'count':0,'auxilia_count':0})
out['A60_up_to'].update(auxilia=count_pieces(s,r.ATREBATES,r.ROMANS,r.AUXILIA),roman_resources=s['resources'][r.ROMANS],schema=list(card_param_schema('A60',s['scenario'])))

s=board(); s['resources'][r.ROMANS]=30
out['A40_up_to']=durable(s,r.AEDUI,'A40',True,{'regions':[],'count':0})
out['A40_up_to'].update(roman_resources=s['resources'][r.ROMANS],schema=list(card_param_schema('A40',s['scenario'])))

s=board(); place_piece(s,r.ATREBATES,r.BELGAE,r.WARBAND,6)
out['A51_up_to']=durable(s,r.AEDUI,'A51',params={'piece_type':r.AUXILIA,'remove_count':0,'removals':[]})
out['A51_up_to']['belgic_warbands']=count_pieces(s,r.ATREBATES,r.BELGAE,r.WARBAND)

s=board(); place_piece(s,r.SEQUANI,r.ROMANS,r.AUXILIA,2); place_piece(s,r.UBII,r.GERMANS,r.WARBAND,1)
out['A19_non_german']=durable(s,r.AEDUI,'A19',True,{'origin_region':r.SEQUANI,'destination':r.UBII})
out['A19_non_german']['romans_at_origin']=count_pieces(s,r.SEQUANI,r.ROMANS,r.AUXILIA)
s=board(); place_piece(s,r.SEQUANI,r.ROMANS,r.AUXILIA,2); place_piece(s,r.UBII,r.GERMANS,r.WARBAND,1)
out['A19_german_human']=durable(s,r.GERMANS,'A19',True,{'origin_region':r.SEQUANI,'destination':r.UBII})
out['A19_german_human']['romans_at_origin']=count_pieces(s,r.SEQUANI,r.ROMANS,r.AUXILIA)

for card,region in [('A21',r.SEQUANI),('A57',r.NERVII)]:
    s=board(); place_piece(s,region,r.BELGAE,r.WARBAND,6); place_piece(s,region,r.GERMANS,r.WARBAND,2)
    out[card+'_human_battle']=durable(s,r.BELGAE,card,params={'battle_plan':[{'region':region,'target_faction':r.GERMANS}]})
    out[card+'_human_battle']['german_warbands']=count_pieces(s,region,r.GERMANS,r.WARBAND)

s=board(); place_piece(s,r.TREVERI,r.GERMANS,r.WARBAND,2)
out['A67_human_command']=durable(s,r.GERMANS,'A67')
out['A67_human_command']['warbands']=count_pieces(s,r.TREVERI,r.GERMANS,r.WARBAND)

s=board(); place_piece(s,r.VENETI,r.ROMANS,r.AUXILIA,1); place_piece(s,r.VENETI,r.ARVERNI,r.WARBAND,2)
out['A20_optional_roman']=durable(s,r.ROMANS,'A20',params={'decline':True})
out['A20_optional_roman'].update(arverni_warbands=count_pieces(s,r.VENETI,r.ARVERNI,r.WARBAND),veneti_status=s['tribes'][r.TRIBE_VENETI]['status'])

s=board(); place_piece(s,r.CISALPINA,r.GERMANS,r.WARBAND,2); place_piece(s,r.CISALPINA,r.GERMANS,r.SETTLEMENT,1); _ally_tribe(s,r.TRIBE_NORI,r.GERMANS)
out['A5_evict']=durable(s,r.GERMANS,'A5',params={'evacuations':[{'faction':r.GERMANS,'destination':r.UBII}]})
out['A5_evict'].update(german_cisalpina=count_pieces(s,r.CISALPINA,r.GERMANS),german_sugambri=count_pieces(s,r.SUGAMBRI,r.GERMANS,r.WARBAND),german_ubii=count_pieces(s,r.UBII,r.GERMANS,r.WARBAND))

s=board(); place_piece(s,r.MORINI,r.GERMANS,r.WARBAND,8); place_piece(s,r.TREVERI,r.GERMANS,r.WARBAND,8)
out['A36_fixed_removals']=durable(s,r.BELGAE,'A36',params={'warband_removals':[{'region':r.TREVERI,'count':8}]})
out['A36_fixed_removals'].update(morini=count_pieces(s,r.MORINI,r.GERMANS,r.WARBAND),treveri=count_pieces(s,r.TREVERI,r.GERMANS,r.WARBAND),schema=list(card_param_schema('A36',s['scenario'])))

for name,card,shade,params,placements in [
 ('A30_outside_range','A30',False,{'region':r.MORINI},[(r.MORINI,r.ARVERNI,r.WARBAND,1)]),
 ('A36_over_quota','A36',True,{'placements':[{'region':r.SUGAMBRI,'piece_type':r.WARBAND,'count':10}],'ally_removals':[]},[]),
 ('A43_outside_range_and_quota','A43',False,{'replacements':[{'region':r.MORINI,'from_type':r.WARBAND,'to_faction':r.AEDUI,'piece_state':r.HIDDEN} for _ in range(3)]},[(r.MORINI,r.ARVERNI,r.WARBAND,3)]),
 ('A45_no_intimidated_marker','A45',False,{'placements':[{'tribe':r.TRIBE_VENETI,'faction':r.AEDUI}]},[]),
 ('A29_german_beneficiary','A29',False,{'placements':[{'region':r.TREVERI,'piece_type':r.WARBAND,'faction':r.GERMANS,'count':5}]},[(r.TREVERI,r.GERMANS,r.SETTLEMENT,1)]),
]:
    s=board()
    for p in placements: place_piece(s,*p)
    a=action(card,shade,params)
    accepted,info=validate_player_action(s,r.AEDUI,a)
    result=durable(s,r.AEDUI,card,shade,params)
    result.update(validation_accepted=accepted,remaining_arverni_morini=count_pieces(s,r.MORINI,r.ARVERNI,r.WARBAND),german_sugambri=count_pieces(s,r.SUGAMBRI,r.GERMANS,r.WARBAND),german_treveri=count_pieces(s,r.TREVERI,r.GERMANS,r.WARBAND),veneti_ally=s['tribes'][r.TRIBE_VENETI]['allied_faction'])
    out[name]=result

s=board(); place_piece(s,r.TREVERI,r.GERMANS,r.LEADER,leader_name=r.ARIOVISTUS_LEADER); place_piece(s,r.TREVERI,r.GERMANS,r.WARBAND,3); place_piece(s,r.TREVERI,r.AEDUI,r.WARBAND,3)
execute_event(s,'A22',True)
plan={'details':{'intimidate_plan':[{'region':r.TREVERI,'target_faction':r.AEDUI,'target_piece':r.WARBAND,'target_state':r.HIDDEN} for _ in range(3)]}}
out['A22_third_warband']={'capability':s['capabilities']['A22'],'result':_execute_intimidate(s,r.GERMANS,plan),'valid_state':validate_state(s)==[]}


s=board(); place_piece(s,r.TREVERI,r.ROMANS,r.AUXILIA,1); place_piece(s,r.TREVERI,r.AEDUI,r.WARBAND,1)
s['resources'][r.ROMANS]=s['resources'][r.AEDUI]=10
out['A29_human_raid']=durable(s,r.GERMANS,'A29',True,{'placements':[{'region':r.TREVERI,'piece_type':r.WARBAND,'count':4},{'region':r.TREVERI,'piece_type':r.SETTLEMENT}]})
out['A29_human_raid']['resources']=s['resources']

s=board(); _ally_tribe(s,r.TRIBE_BELLOVACI,r.BELGAE); place_piece(s,r.ATREBATES,r.BELGAE,r.LEADER,leader_name=r.BODUOGNATUS); place_piece(s,r.ATREBATES,r.AEDUI,r.WARBAND,1); place_piece(s,r.ATREBATES,r.GERMANS,r.WARBAND,2)
out['A69_human_ambush']=durable(s,r.BELGAE,'A69',True,{'target_faction':r.AEDUI})

s=board(); place_piece(s,r.ATREBATES,r.ROMANS,r.AUXILIA,1)
out['A58_other_executor']=durable(s,r.AEDUI,'A58')
out['A58_other_executor']['resources']=s['resources']
s=board(); place_piece(s,r.ATREBATES,r.ROMANS,r.AUXILIA,1)
out['A58_roman_auto_seize']=durable(s,r.ROMANS,'A58',params={'decline':True})

s=board(); place_piece(s,r.SEQUANI,r.ROMANS,r.AUXILIA,4); place_piece(s,r.SEQUANI,r.ROMANS,r.AUXILIA,4,piece_state=r.REVEALED)
out['A17_visibility']=durable(s,r.AEDUI,'A17',True,{'region':r.SEQUANI,'piece_state':r.REVEALED})
out['A17_visibility'].update(hidden=count_pieces_by_state(s,r.SEQUANI,r.ROMANS,r.AUXILIA,r.HIDDEN),revealed=count_pieces_by_state(s,r.SEQUANI,r.ROMANS,r.AUXILIA,r.REVEALED))

for card,region,faction,params in [('A25',r.CISALPINA,r.GERMANS,{}),('A26',r.SEQUANI,r.ARVERNI,{}),('A30',r.SEQUANI,r.ARVERNI,{'region':r.SEQUANI}),('A56',r.ATREBATES,r.BELGAE,{})]:
    s=board(); place_piece(s,region,faction,r.WARBAND,1,piece_state=r.SCOUTED)
    out[card+'_scouted_remains']=durable(s,r.AEDUI,card,params=params)
    out[card+'_scouted_remains']['remaining_scouted']=count_pieces_by_state(s,region,faction,r.WARBAND,r.SCOUTED)

print(json.dumps(out,indent=2,default=str))
