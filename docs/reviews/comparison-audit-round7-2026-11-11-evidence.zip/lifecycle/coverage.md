# Seventh comparison audit — lifecycle partition

Audited `c67d501711471bf790d805c017c2125b2c254639`. Comparator inspected at
`2991ea279062773548ec390a1da75f3e85381702`. No production or reference changes.

The comparison used Liberty or Death's orphaned-helper and lifecycle-consumer
patterns in `coin-implementation-lessons.md` and its `audit_set_but_never_applied_s76.md`.
Falling Sky's supplied references and adopted rulings alone establish expected rules.

One confirmed repair group, **WS7-01**, with seventeen directed public-entrypoint
cases. Four faction evacuation pairs, three Leader-consolidation pairs, one
no-escape control, and a full Winter pair reproduce the missing NPC routing.
All before/after states pass census and structural checks, with permanent Provincia
Fort retained and Tribe ownership restrictions checked. The full Winter pair uses
actual Pax setup and its first-Winter Germans skip, so no preceding German Command
causes or hides the observed omission.

Inspected `winter.py` full phase orchestration, Quarters handoff, German relocation,
Warband desertion, Roman payments, Harvest, Senate and Spring, plus automatic Arverni
Rally/March/Raid/Battle and Interlude reductions, deck rebuilding and lingering effects.
The prior automatic-German Rally/March and Harvest count/negative-score fixes were
not recounted. No new finding arose from these static reads alone.

Candidates excluded or handed off

- Circumvallation Interlude whole-Region cleanup belongs to the already documented
  CV-PERSISTENCE problem and is excluded.
- Automatic Arverni Battle's direct resolver bypass is being verified by the battle
  partition; it is not counted here.
- Aquitani/Vercingetorix's Elite Rally hooks in automatic Arverni procedures are not
  counted because their numeric cards are replaced in Ariovistus; no lawful active
  configuration was established for that candidate.
- Arverni March's Scouted transition was checked against `flip_piece`, which removes
  Scouted without concealing those Warbands. It does not repeat the old German bug.
- Potential legacy Quarters-node destination and payload defects are repair risks
  within the single missing-routing group. They are not independently live while
  those nodes remain uncalled, and no extra finding is claimed.

The probes prove controlled mechanisms, not naturally sampled frequency or exhaustive
phase correctness. Existing source questions and thirteen provisional rulings retain
all their prior dispositions.
