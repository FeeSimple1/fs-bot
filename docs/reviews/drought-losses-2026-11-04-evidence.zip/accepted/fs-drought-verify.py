from pathlib import Path
import json,re,subprocess
from fs_bot import rules_consts as rc
from fs_bot.tools.validation_metadata import source_identity
parent='e42b213dcfd57105f13f9ae44674fdd20b243a6a';source=source_identity()
assert source['source_sha256']=='b33a8d39c1fcb3ba138527c95393986493eccf847b3193356d7c706249306037'
records={}
for label,directory in [('parent','/tmp/fs-drought-bots-parent'),('final','/tmp/fs-drought-bots-final')]:
 rows=[json.loads(x) for x in Path(directory+'/games.jsonl').read_text().splitlines()]
 records[label]={(r['scenario'],r['seed']):r for r in rows}
 assert len(rows)==10 and set(records[label])=={(s,n) for s in rc.ALL_SCENARIOS for n in (1,2)}
 for row in rows:
  assert all(row[k] for k in ('completed','game_completed','audit_completed','final_state_sha256'))
  assert not row['errors'] and not row['integrity_findings']
  assert len(row['final_ranking'])==4 and not row['winner_differs_from_highest_margin'] and not row['engine_ranking_output_missing']
  assert all(d['severity']=='legal-decline' for d in row['diagnostics'])
ignored={'seconds','commit','source_sha256'};changed=[]
for k,p in records['parent'].items():
 c=records['final'][k]
 fields=[f for f in p if f not in ignored and p[f]!=c[f]]
 if fields:changed.append({'scenario':k[0],'seed':k[1],'fields':fields,'parent_winner':p['winner'],'final_winner':c['winner']})
assert [(r['scenario'],r['seed']) for r in changed]==[(rc.SCENARIO_RECONQUEST,2)]
assert json.loads(Path('/tmp/fs-drought-bots-final/metadata.json').read_text())['source_sha256']==source['source_sha256']
p=json.loads(Path('/tmp/fs-drought-trace-parent.json').read_text());c=json.loads(Path('/tmp/fs-drought-trace-final.json').read_text())
assert p['record']['final_state_sha256']==records['parent'][rc.SCENARIO_RECONQUEST,2]['final_state_sha256']
assert c['record']['final_state_sha256']==records['final'][rc.SCENARIO_RECONQUEST,2]['final_state_sha256']
index=next(i for i,(x,y) in enumerate(zip(p['cards'],c['cards'])) if x!=y)
assert index==6 and p['cards'][index]['before']==c['cards'][index]['before'] and p['cards'][index]['result']['card']==49
assert len(p['drought'])==len(c['drought'])==1 and p['drought'][0]['before']==c['drought'][0]['before']
assert p['drought'][0]['after']['markers']==c['drought'][0]['after']['markers']
a=p['drought'][0]['after']['spaces'][rc.MORINI]['pieces'][rc.ROMANS];b=c['drought'][0]['after']['spaces'][rc.MORINI]['pieces'][rc.ROMANS]
assert a[rc.LEGION]==0 and b[rc.LEGION]==1 and a[rc.REVEALED][rc.AUXILIA]==1 and b[rc.REVEALED][rc.AUXILIA]==0
x=json.loads(Path('/tmp/fs-drought-mixed0.json').read_text());y=json.loads(Path('/tmp/fs-drought-mixed987.json').read_text())
assert x==y and not x['hard_findings'] and x['partial']==0 and all(r['game_completed'] for r in x['records'])
assert x['metadata']['source_sha256']==source['source_sha256']
protected=[p for p in Path('Reference Documents').rglob('*') if p.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
assert len(protected)==49
for p in protected:assert p.read_bytes()==subprocess.check_output(['git','show',parent+':'+str(p)])
result={'date':'2026-11-04','timezone':'America/Chicago','source':source,'python_files':501,'protected_files':49,'protected_files_unchanged':True,'targeted_passed':284,'new_tests':69,'parent_proof':{'behavioral_failures':35,'controls_passed':1,'deselected':33},'bots':{'games':10,'all_completed_and_audited':True,'all_gameplay_fields_and_final_hashes_equal':False,'matching_gameplay_records':9,'changed':changed,'excluded':sorted(ignored),'first_divergence_trace':{'scenario':rc.SCENARIO_RECONQUEST,'seed':2,'card_index_zero_based':index,'card':49,'pre_event_boards_equal':True,'marker_maps_equal':True,'region':rc.MORINI,'parent_loss':rc.LEGION,'final_loss':rc.AUXILIA,'final_loss_state':rc.REVEALED}},'mixed':x,'mixed_complete_json_equal':True,'hash_seeds':[0,987],'mixed_executions_including_replay':40,'original_progress':{'closed':34,'total':50,'percent':68,'open':16},'remaining':'BE-08 remains partly open; CV-PERSISTENCE, BATTLE-RAMPAGE-VICTIM, BE-09 and the NPC Intimidate targeting lead remain open'}
balance_log=Path('/tmp/fs-drought-balance.log').read_text()
assert 'OK: balance within band (' in balance_log
rows=re.findall(r'^\[(.*?) seed=\s*(\d+)\] winner=(.*?) \((\d+) cards\)$',balance_log,re.M)
assert len(rows)==100 and {(r[0],int(r[1])) for r in rows}=={(sc,n) for sc in rc.ALL_SCENARIOS for n in range(1,21)}
deltas=[abs(int(v)) for v in re.findall(r'\(([+-]\d+)%\)',balance_log)];assert deltas and max(deltas)<=15
changes=int(re.search(r'OK: balance within band \((\d+) winner changes\)',balance_log)[1])
result['balance_smoke']={'games':100,'seeds':list(range(1,21)),'scenarios':list(rc.ALL_SCENARIOS),'band_percentage_points':15,'maximum_absolute_delta_percentage_points':max(deltas),'historical_baseline_winner_changes':changes,'baseline_unchanged':True,'passed':True,'results':[{'scenario':r[0],'seed':int(r[1]),'winner':r[2],'cards':int(r[3])} for r in rows]}
Path('/tmp/fs-drought-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':source,'new_tests':69,'targeted':284,'matching_bot_records':9,'changed_bot_records':changed,'mixed_equal':True,'hard_findings':x['hard_findings'],'partials':x['partial'],'human_turns':x['human_turns'],'event_turns':x['event_turns'],'events_ok':x['events_ok'],'balance_max_delta_pp':max(deltas),'historical_winner_changes':changes}))
