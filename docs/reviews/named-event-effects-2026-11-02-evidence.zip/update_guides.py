from pathlib import Path
R=Path(__file__).resolve().parent.parent/'fs-bot'
report='docs/reviews/named-event-effects-2026-11-02.md'
p=R/'README.md';s=p.read_text();s=s.replace('**17 of 50 findings are closed (34%); 33 remain open**','The [named-faction Event repair]('+report+') closes BE-04, including\nRoman and Arverni decisions when another faction plays the Event.\n**18 of 50 findings are closed (36%); 32 remain open**');p.write_text(s)
p=R/'BUILD_PLAN.md';s=p.read_text();s=s.replace('now records 17 of 50 closed (34%) and 33 open;', 'now records 18 of 50 closed (36%) and 32 open;');s=s.replace('Continue with the remaining Event ownership, quantity','The [named-faction Event repair]('+report+') closes BE-04\n(Roman and Arverni optional effects, plus related A18 removal corrections).\nContinue with the remaining Event ownership, quantity');p.write_text(s)
p=R/'CHANGELOG.md';s=p.read_text();marker='## Unreleased — Event limits';entry='''## Unreleased — named-faction Event choices, 2 November 2026

- Route optional effects on 2/18/23 unshaded and 26 shaded to their named
  Roman or Arverni owner, including when another faction plays the Event.
  Add explicit decline/default, exact targets, Legion source allocation,
  Gobannitio's separate Ally changes/Rally, and durable saved-session replay.
- Repair Card2's missing non-player Legion placements. Remove Scouted Warbands
  and an unprotected German Successor under expansion A18's all-pieces effect;
  preserve the named Ariovistus exclusion and Roman decision ownership.
- Preserve original-executor removal authority, independent Arverni Spring
  entry and existing follow-on timing. Reject malformed or unconsumed timing
  fields and rebuild Legion source choices after late reclamation.
- Close BE-04. See the [repair report](docs/reviews/named-event-effects-2026-11-02.md)
  for source readings, validation, compatibility and remaining scope.

''';s=s.replace(marker,entry+marker,1);p.write_text(s)
p=R/'docs/README.md';s=p.read_text();marker='| [3 November Event limits';s=s.replace(marker,'| [2 November named-faction Event choices](reviews/named-event-effects-2026-11-02.md) | BE-04 owner-directed optional effects, Legion sources, A18 complete removal and durable/terminal validation |\n'+marker,1);p.write_text(s)
p=R/'docs/current-status.md';s=p.read_text();marker='### 3 November Event limits';entry='''### 2 November named-faction Event choices — BE-04 closed

The [repair report](reviews/named-event-effects-2026-11-02.md) restores Romans'
optional choices on 2/18/23 unshaded and expansion A18, and Arverni's choices
on 26 shaded, even when another faction executes the Event. Explicit decline,
exact targets and source selections belong to the named faction. Gobannitio
can skip Ally changes and proceed to a separately chosen Rally; declining the
whole sequence skips both.

Card2 now actually places the non-player's required Legions. Expansion A18
removes Scouted Warbands and a German Successor along with the other Germans,
while its explicit named-Ariovistus protection remains. Non-player defaults
follow supplied priorities without narrowing human target legality. Terminal
menus and saved sessions retain card/board information, pending retries,
original-executor removal authority, independent Spring entry and replay.

**18 of 50 findings are closed (36%); 32 remain open.** This one-finding task
is complete. Finding counts are not an effort estimate or overall rules
certification. Other Event grants, physical choices, Capability decisions,
private peeks and seasonal decisions remain separately tracked. The report's
date uses America/Chicago; the preceding report used UTC.

''';s=s.replace(marker,entry+marker,1);s=s.replace('**17 of 50 findings are closed (34%); 33 remain open.** This three-finding','At that checkpoint, **17 of 50 findings were closed (34%); 33 remained open.** This three-finding',1);p.write_text(s)
p=R/'docs/reviews/human-choice-audit-2026-10-29.md';s=p.read_text();s=s.replace('BE-11, BE-12 and EXP-09. The [live progress register](../human-choice-progress.json)\ntracks 17 closed (34%) and 33 remaining.', 'BE-11, BE-12 and EXP-09. The subsequent [named-faction Event repair](named-event-effects-2026-11-02.md)\ncloses BE-04. The [live progress register](../human-choice-progress.json)\ntracks 18 closed (36%) and 32 remaining.',1);p.write_text(s)
p=R/'PLAYING.md';s=p.read_text();marker='Shaded German Allegiances (65)';entry='''Some repaired Events assign their choices to Romans or Arverni even when
another faction plays the card. Legiones XIIII et XV, Rhenus Bridge and Sacking
ask Romans whether to use the effect and which legal sources or targets to use.
Gobannitio asks Arverni about Ally changes, then their free Rally. Its menu
separates “Skip Ally changes; decide Rally” from declining both effects.
Missing or invalid answers stay pending. The same board and card information
remains available while answering another faction's Event.

''';s=s.replace(marker,entry+marker,1);p.write_text(s)
p=R/'CHATGPT_README.md';s=p.read_text();marker='The repaired Event';idx=s.find(marker)
# Place near the existing Event validation guidance without altering unrelated text.
anchor='[Event validation report](docs/reviews/event-validation-2026-11-03.md)'
end=s.find('\n\n',s.find(anchor))
assert end>=0
entry='''

Cards 2/18/23 unshaded, 26 shaded and A18 unshaded can issue a
`free_action` request with `request_type: "named_event_effect"`. Answer for the
named `acting_faction`, even when another faction executed the Event. Select
the offered target/source parameters, explicit `{"decline":true}`, or explicit
`{"use_default":true}`. For 26, empty Ally lists proceed to the separate Rally
choice; declining the entire effect does not. A foreign Event executor submits
no owner's targets in its initial Event plan. See the
[named-faction repair](docs/reviews/named-event-effects-2026-11-02.md) and
[agent interface](AGENT_INTERFACE.md) for the exact contracts.
'''
s=s[:end]+entry+s[end:];p.write_text(s)
p=R/'AGENT_INTERFACE.md';s=p.read_text();anchor='Boii (37) unshaded accepts';entry='''Named-owner optional effects on 2/18/23 unshaded, 26 shaded and A18 unshaded
use `kind: "free_action"`, `request_type: "named_event_effect"`, `card_id`,
`acting_faction`, `allow_decline: true` and `validate_default_response: true`.
The initial terminal Event plan leaves these decisions for the live owner
request. A same-owner typed Event may supply its own parameters directly;
a foreign executor cannot supply that owner's targets. Empty initial parameters
request the decision; missing durable input never means an automatic default.

| Card/side | Named owner | Accepted owner response |
|---|---|---|
| 2 unshaded | Romans | `legions_from_track` and `legions_from_fallen`: nonnegative integer counts, totaling two as far as possible. The Senate must be able to shift or flip. Available source choices may change after a legal timing action. |
| 18/A18 unshaded | Romans | `target_region` from `target_regions`. A18 also accepts its previous `region` alias; if both appear they must agree. A18 excludes named Ariovistus, but includes a Successor in its complete German removal. |
| 23 unshaded | Romans | `target_city` from `target_cities`; Roman Control is required, not Roman ownership of the City. Existing Dispersed/Razed status is not a blanket human prohibition. |
| 26 shaded | Arverni | `ally_removals` and `ally_placements`: ordered lists of exact Tribe names in Arverni Region. Remove only actual Allies, of any faction; place only own Allies at legal Subdued Tribes. Empty lists still proceed to the separately chosen free Rally. |

Each request also accepts a sole strict-Boolean `{"decline":true}` or
`{"use_default":true}`. For 26, decline skips both Ally changes and Rally.
Explicit default follows the named faction's non-player policy; Roman Card2
policy declines unless both Legions can enter, even though human partial
execution is broader. A legal ineffective human selection remains permitted.

Owner replies may include `stage_timing_actions` at `2.legions`,
`2.fallen_legions`, or `26.removals:<index>`/`26.placements:<index>`, including
the final list-length index. Unknown steps, malformed timing maps and unused
reply-level `timing_actions` are rejected. Outer Event entry timing belongs in
`details.timing_actions`. Outer `handler_complete` and Card26's
`grant.card_26_arverni_rally` remain executor-authored Event timing points;
they are not owner-response fields. The original executor retains voluntary
piece-removal authority, while Arverni can independently author eligible
Spring entry. Owner responses cannot claim another faction's authority.

Invalid replies retain the pending ID, board, RNG and accepted history.
Saved sessions and exact replay preserve both the owner effect and later
Rally choice. Older affected transcripts can require new owner decisions;
there is no save-format version change. Numeric 26 remains distinct from A26.

''';assert anchor in s;s=s.replace(anchor,entry+anchor,1);p.write_text(s)
