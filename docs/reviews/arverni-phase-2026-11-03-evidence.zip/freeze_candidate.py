"""Capture a reviewed candidate only when explicitly invoked by coordinating root."""
import argparse
import json
import subprocess
from pathlib import Path
from integration_matrix import identity, protected_files

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'fs-bot'
parser = argparse.ArgumentParser()
parser.add_argument('label')
args = parser.parse_args()
assert args.label.startswith('attempt') and args.label[7:].isdigit()
suffix = '-' + args.label
manifest = HERE / ('candidate-source' + suffix + '.json')
patch_path = HERE / ('prepared-source' + suffix + '.patch')
assert not manifest.exists() and not patch_path.exists(), 'Never overwrite a frozen candidate'
before = identity()
assert protected_files() == json.loads((HERE / 'protected-before.json').read_text())
patch = subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--', 'fs_bot'], cwd=REPO)
new_files = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', 'fs_bot'], cwd=REPO, text=True).splitlines()
for name in sorted(new_files):
    if not name.endswith('.py'):
        continue
    result = subprocess.run(['git', 'diff', '--binary', '--no-index', '--', '/dev/null', name], cwd=REPO, stdout=subprocess.PIPE)
    assert result.returncode in (0, 1)
    patch += result.stdout
assert identity() == before, 'Source changed while freezing'
manifest.write_text(json.dumps(before, indent=2) + '\n')
patch_path.write_bytes(patch)
print(json.dumps({'manifest': manifest.name, 'patch': patch_path.name, 'python_sha256': before['python_sha256'], 'python_files': before['python_files']}))
