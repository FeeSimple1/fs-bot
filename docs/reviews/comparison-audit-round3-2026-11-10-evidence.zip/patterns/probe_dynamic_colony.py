"""XC3-01. Assertions deliberately freeze audited wrong behavior at 3c23a34."""
import copy
import json
from fs_bot import rules_consts as rc
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.cards.card_effects import execute_card_71
from fs_bot.board.pieces import place_piece, remove_piece, move_piece, clear_allied_tribe
from fs_bot.commands.seize import calculate_forage, get_dispersible_tribes, seize_plan_error
from fs_bot.commands.sa_build import build_place_ally, build_subdue, validate_build_region
from fs_bot.commands.sa_entreat import entreat_replace_ally, validate_entreat_region
from fs_bot.commands.sa_trade import trade
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.victory import calculate_victory_score


def clean(s):
    assert not validate_state(s), validate_state(s)
    assert not check_structural_integrity(s), check_structural_integrity(s)


def colony(s, faction, region):
    s['executing_faction'] = faction
    s['event_params'] = {'region': region}
    execute_card_71(s)
    s.pop('executing_faction'); s.pop('event_params')
    name = 'Colony_' + region
    assert s['tribes'][name] == {'status': None, 'allied_faction': faction, 'region': region}
    clean(s)
    return name


def remove_colony_ally(s, faction, region, name):
    remove_piece(s, region, faction, rc.ALLY)
    clear_allied_tribe(s, region, faction, rc.ALLY, tribe=name)
    clean(s)


def error(fn):
    try:
        fn()
    except ValueError as exc:
        return str(exc)
    except Exception as exc:
        if type(exc).__name__ != 'CommandError':
            raise
        return str(exc)
    raise AssertionError('Expected audited erroneous rejection')


def main():
    out = {}
    s = setup_scenario(rc.SCENARIO_GREAT_REVOLT, seed=4)
    s['non_player_factions'] = set()
    before = calculate_forage(s, rc.MANDUBII, [])
    name = colony(s, rc.ROMANS, rc.MANDUBII)
    action = {'command': rc.CMD_SEIZE, 'regions': [rc.MANDUBII], 'sa': 'No SA',
              'details': {'disperse_tribes': {rc.MANDUBII: []}}}
    result = execute_decision(s, rc.ROMANS, {'action': 'command', 'player_action': action})
    assert result['executed'] and result['forage_resources_total'] == before
    out['seize_roman_ally'] = {'without_colony': before, 'expected': before + 2,
                             'actual': result['forage_resources_total'], 'accepted': True}
    clean(s)
    remove_colony_ally(s, rc.ROMANS, rc.MANDUBII, name)
    assert name not in get_dispersible_tribes(s, rc.MANDUBII, limit_to_markers=False)
    action['details']['disperse_tribes'][rc.MANDUBII] = [name]
    err = seize_plan_error(action, require_exact=True, state=s)
    assert err == 'Choose Tribes belonging to their selected Seize Region'
    result = execute_decision(s, rc.ROMANS, {'action': 'command', 'player_action': action})
    assert result['rejected'] and not result['executed']
    out['seize_subdued_colony'] = {'expected_dispersible': True, 'offered': False,
                                 'actual_rejection': err}
    move_piece(s, rc.PROVINCIA, rc.MANDUBII, rc.ROMANS, rc.LEADER)
    clean(s)
    assert validate_build_region(s, rc.MANDUBII)[0]
    out['build_place'] = {'expected': 'Place Roman Ally at Subdued Colony for 2 Resources',
                         'actual': error(lambda: build_place_ally(s, rc.MANDUBII, name))}
    place_piece(s, rc.MANDUBII, rc.AEDUI, rc.ALLY)
    s['tribes'][name]['allied_faction'] = rc.AEDUI
    clean(s)
    assert validate_build_region(s, rc.MANDUBII)[0]
    out['build_subdue'] = {'expected': 'Remove Aedui Colony Ally for 2 Resources',
                          'actual': error(lambda: build_subdue(s, rc.MANDUBII, name, rc.AEDUI))}

    # A physically valid controlled position using the real Event-created Tribe.
    s = build_initial_state(rc.SCENARIO_PAX_GALLICA, seed=4)
    name = colony(s, rc.AEDUI, rc.BITURIGES)
    place_piece(s, rc.BITURIGES, rc.ARVERNI, rc.WARBAND, count=2)
    place_piece(s, rc.BITURIGES, rc.ARVERNI, rc.LEADER, leader_name=rc.VERCINGETORIX)
    s['resources'][rc.ARVERNI] = 5
    clean(s)
    assert validate_entreat_region(s, rc.BITURIGES)[0]
    out['entreat'] = {'expected': 'Replace Aedui Colony Ally for 1 Resource',
                      'actual': error(lambda: entreat_replace_ally(s, rc.BITURIGES, rc.AEDUI, name))}

    s = setup_scenario(rc.SCENARIO_GREAT_REVOLT, seed=4)
    agreements = {f: True for f in rc.FACTIONS}
    base = trade(copy.deepcopy(s), agreements, roman_agreed=True)['resources_gained']
    name = colony(s, rc.AEDUI, rc.AEDUI_REGION)
    remove_colony_ally(s, rc.AEDUI, rc.AEDUI_REGION, name)
    after = trade(s, agreements, roman_agreed=True)
    assert after['resources_gained'] == base
    out['trade_subdued_colony'] = {'without_colony': base, 'expected': base + 2,
                                   'actual': after['resources_gained'], 'per_item': after['per_item']}
    clean(s)

    # Seize cannot currently make this legal Dispersed state, so set ONLY the
    # marker on the real Event-created, now Subdued Tribe as a rules-valid fixture.
    s = setup_scenario(rc.SCENARIO_GREAT_REVOLT, seed=4)
    name = colony(s, rc.BELGAE, rc.MORINI)
    remove_colony_ally(s, rc.BELGAE, rc.MORINI, name)
    before = calculate_victory_score(s, rc.BELGAE)
    s['tribes'][name]['status'] = rc.MARKER_DISPERSED
    clean(s)
    after = calculate_victory_score(s, rc.BELGAE)
    assert after == before
    out['dispersed_colony_score'] = {'expected': before - 1, 'actual': after,
                                    'before_dispersal': before, 'fixture': 'legal marker assigned because Seize rejects Colony'}
    print(json.dumps(out, indent=2))

if __name__ == '__main__':
    main()
