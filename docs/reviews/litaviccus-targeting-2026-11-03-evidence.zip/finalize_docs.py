from pathlib import Path
import json
E=Path(__file__).resolve().parent;R=E.parent/'fs-bot'
source=json.loads((E/'candidate-source-attempt1.json').read_text())
def change(name,old,new):
 p=R/name;s=p.read_text();assert old in s,(name,old);p.write_text(s.replace(old,new,1))
change('README.md','**20 of 50 findings are closed (40%); 30 remain open**', '''The [Litaviccus follow-up](docs/reviews/litaviccus-targeting-2026-11-03.md)
implements provisional PR-12 targeting and full Aedui Battle participation.
This separate follow-up is outside the original audit denominator.
**20 of 50 findings are closed (40%); 30 remain open**''')
change('docs/README.md','| [3 November Event Battle choices]', '''| [3 November Litaviccus targeting and forces](reviews/litaviccus-targeting-2026-11-03.md) | Adopted PR-12, shared non-player eligibility/target prediction, full Aedui participation and source-bound outcome validation |
| [3 November Event Battle choices]''')
change('BUILD_PLAN.md', '''Retreat forecasts. Non-player Litaviccus targeting remains a separate repair
with the narrow prediction question recorded in `QUESTIONS.md`.''','''Retreat forecasts. The subsequent
[Litaviccus follow-up](docs/reviews/litaviccus-targeting-2026-11-03.md)
implements adopted PR-12 targeting and repairs full Aedui Battle participation;
these remain separate from the original audit denominator.''')
change('BUILD_PLAN.md', '''items are not an exhaustive defect list. Three unadopted non-player source
questions remain: shaded Trade Region selection, the physical Warbands
designated by Vercingetorix's Elite, and forecasting human Roman Retreat
when selecting a Litaviccus target. See the current question index.''','''items are not an exhaustive defect list. Two unadopted non-player source
questions remain: shaded Trade Region selection and the physical Warbands
designated by Vercingetorix's Elite. Litaviccus's response forecast now follows
PR-12, subject to authoritative correction. See the current question index.''')
change('CHANGELOG.md','## Unreleased — Event Battle choices, 3 November 2026','''## Unreleased — Litaviccus targeting and forces, 3 November 2026

- Adopt provisional PR-12 for Litaviccus: predict the published Roman bot
  response or a human Roman's safer legal standing/Retreat choice. Maximize
  Legion Losses, retain Battle/Frost safeguards and use No Belgae if none
  qualify. Eligibility and execution share the same target planner.
- Include Aedui pieces throughout the actual Battle: Retreat forecasts,
  casualties and Reveal, retaining physical ownership, Tribe affiliation
  and native Leader identity. Protect City/Remi Allies across owners.
- Preserve human target freedom, physical board display and save/replay.
  Battle loss reports now distinguish requested Loss totals from actual
  removals/absorptions; forecasts use the executor's validated Ambush timing.
- This follow-up closes no additional original audit finding: 20/50 remain
  closed (40%), with 30 open. See the
  [Litaviccus report](docs/reviews/litaviccus-targeting-2026-11-03.md).

## Unreleased — Event Battle choices, 3 November 2026''')
change('docs/reviews/event-battle-choices-2026-11-03.md','### Separate follow-ups\n','''### Separate follow-ups

**Subsequent disposition, 3 November 2026:** the owner adopted PR-12 and the
[Litaviccus follow-up](litaviccus-targeting-2026-11-03.md) repairs the target
predictor and its related combined-force defect. The following account
records what remained open at this report's own revision.
''')
p=R/'docs/human-choice-progress.json';d=json.loads(p.read_text())
d['tested_source']={k:source[k] for k in ('commit','python_sha256','python_files')}
d['tested_source'].update(working_tree_changes=True,note='Litaviccus follow-up prepared over this parent; full suite and integrated matrix use this exact Python source. No additional original finding closes.')
d['unresolved_source_questions_separate']=2
d['notes'].append('The subsequent Litaviccus follow-up implements owner-adopted PR-12 and full Aedui Battle participation. It repairs the separate target predictor recorded after BE-02 without changing the 50-finding denominator. See reviews/litaviccus-targeting-2026-11-03.md.')
p.write_text(json.dumps(d,indent=2)+'\n')
