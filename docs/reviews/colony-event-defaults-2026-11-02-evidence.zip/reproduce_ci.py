"""Run the exact CI fuzz loop, retaining each cross-version divergent snapshot."""
import gzip
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'fs-bot'))
from fs_bot.tools import player_fuzz
from fs_bot.tools.validation_metadata import source_identity
from fs_bot.state.serialize import encode

identity = source_identity()
baseline = json.loads((HERE / 'before-hash0.json').read_text())
expected = {(r['scenario'], r['seed']): r for r in baseline['records']}
original_play = player_fuzz.play_game
original_digest = player_fuzz._digest
current = [None]
calls = {}

def digest(state, result):
    value = original_digest(state, result)
    scenario, seed = current[0]
    if value != expected[(scenario, seed)]['digest']:
        name = f"python310-hash7-{scenario.replace(' ', '-').replace('?', '')}-{seed}-{calls[current[0]]}"
        with gzip.open(HERE / (name + '.json.gz'), 'wt', encoding='utf-8') as stream:
            json.dump({'source': identity, 'hash_seed': os.environ.get('PYTHONHASHSEED'),
                       'scenario': scenario, 'seed': seed, 'digest': value,
                       'captured': encode({'state': {k: v for k, v in state.items()
                                                    if k != 'decision_agent'},
                                           'trajectory': result})}, stream)
    return value

def play(scenario, seed, **kwargs):
    current[0] = (scenario, seed)
    calls[current[0]] = calls.get(current[0], 0) + 1
    result = original_play(scenario, seed, **kwargs)
    with (HERE / 'python310-records.jsonl').open('a', encoding='utf-8') as stream:
        stream.write(json.dumps({'repetition': calls[current[0]], **result}) + '\n')
    return result

player_fuzz._digest = digest
player_fuzz.play_game = play
exit_code = player_fuzz.main(['--seeds', '1-40', '--out', str(HERE / 'before-python310-hash7.json')])
assert source_identity() == identity, 'Source changed during reproduction'
raise SystemExit(exit_code)
