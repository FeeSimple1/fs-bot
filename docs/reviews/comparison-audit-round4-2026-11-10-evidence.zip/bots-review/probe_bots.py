"""Round-four audit witnesses; assertions freeze defects, not desired behavior.

Run: python probe_bots.py /path/to/fs-bot
Fixtures are census/structure-valid initialized boards assembled with piece
helpers. They are controlled legal positions, not claims of sampled game reach.
"""
import copy
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(sys.argv[1]).resolve()))
from fs_bot.rules_consts import (
    ROMANS, AEDUI, BELGAE, GERMANS, SCENARIO_ARIOVISTUS,
    CAESAR, DIVICIACUS, LEADER, LEGION, AUXILIA, ALLY, SETTLEMENT, WARBAND, FORT,
    PROVINCIA, CARNUTES, SEQUANI, TREVERI,
    TRIBE_CARNUTES, TRIBE_AULERCI, TRIBE_SEQUANI, TRIBE_HELVETII, TRIBE_TREVERI,
    CMD_BATTLE, CMD_MARCH,
)
from fs_bot.state.state_schema import (
    build_initial_state, validate_state, check_structural_integrity,
)
from fs_bot.board.pieces import place_piece, count_pieces, get_leader_in_region
from fs_bot.board.control import refresh_all_control
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.bots.aedui_bot import node_a4, SA_ACTION_NONE, ACTION_PASS as CMD_PASS
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND, ACTION_COMMAND_SA


def clean(state):
    errors = validate_state(state) + check_structural_integrity(state)
    assert not errors, errors
    return errors


def fresh():
    state = build_initial_state(SCENARIO_ARIOVISTUS, seed=5)
    # Chapter 1: Provincia has a permanent Roman Fort in every scenario.
    place_piece(state, PROVINCIA, ROMANS, FORT)
    state['non_player_factions'] = {ROMANS, AEDUI, BELGAE, GERMANS}
    state['can_play_event'] = False
    state['resources'][ROMANS] = 30
    state['resources'][AEDUI] = 10
    return state


def ally(state, tribe, region, faction):
    state['tribes'][tribe]['allied_faction'] = faction
    place_piece(state, region, faction, ALLY)


def roman_case(kind):
    state = fresh()
    place_piece(state, PROVINCIA, ROMANS, LEADER, leader_name=CAESAR)
    place_piece(state, PROVINCIA, ROMANS, LEGION, count=4, from_legions_track=True)
    # Leaves seven Auxilia Available, reaching March at R5 without a threat.
    place_piece(state, PROVINCIA, ROMANS, AUXILIA, count=17)
    ally(state, TRIBE_CARNUTES, CARNUTES, AEDUI)
    ally(state, TRIBE_AULERCI, CARNUTES, AEDUI)
    ally(state, TRIBE_SEQUANI, SEQUANI, GERMANS)
    if kind == 'settlements':
        for region in (SEQUANI, TREVERI):
            place_piece(state, region, GERMANS, SETTLEMENT)
    elif kind == 'ally_control':
        ally(state, TRIBE_HELVETII, SEQUANI, GERMANS)
        ally(state, TRIBE_TREVERI, TREVERI, GERMANS)
    refresh_all_control(state)
    clean(state)
    action = dispatch_bot_turn(state, ROMANS)
    assert action['command'] == CMD_MARCH, action
    destinations = action['details']['destinations']
    expected_target = GERMANS if kind in ('settlements', 'ally_control') else AEDUI
    observed_target = destinations[0][1]
    assert observed_target == (GERMANS if kind == 'ally_control' else AEDUI)
    result = execute_decision(state, ROMANS, {
        'action': ACTION_COMMAND_SA, 'bot_action': action,
    })
    assert result['executed'] and not result.get('errors'), result
    clean(state)
    return {
        'case': kind, 'expected_target': expected_target,
        'observed_target': observed_target, 'action': action,
        'execution': result,
        'legions_by_region': {r: count_pieces(state, r, ROMANS, LEGION)
                              for r in (PROVINCIA, CARNUTES, SEQUANI, TREVERI)},
        'integrity_errors': clean(state),
    }


def diviciacus_case(add_warband=False):
    state = fresh()
    place_piece(state, CARNUTES, AEDUI, LEADER, leader_name=DIVICIACUS)
    if add_warband:
        place_piece(state, CARNUTES, AEDUI, WARBAND)
    ally(state, TRIBE_CARNUTES, CARNUTES, BELGAE)
    refresh_all_control(state)
    clean(state)
    trigger = node_a4(state)
    assert trigger == 'Yes'
    action = dispatch_bot_turn(state, AEDUI)
    assert action['command'] == (CMD_BATTLE if add_warband else CMD_PASS), action
    # Independently execute the rule-required Battle with no SA to show the
    # enemy has no Counterattack and Diviciacus cannot suffer a Loss here.
    legal = copy.deepcopy(state)
    legal_action = {
        'command': CMD_BATTLE, 'regions': [CARNUTES],
        'sa': SA_ACTION_NONE, 'sa_regions': [],
        'details': {'battle_plan': [{'region': CARNUTES, 'target': BELGAE}]},
    }
    result = execute_decision(legal, AEDUI, {
        'action': ACTION_COMMAND, 'bot_action': legal_action,
    })
    assert result['executed'] and not result.get('errors'), result
    assert legal['tribes'][TRIBE_CARNUTES]['allied_faction'] is None
    assert get_leader_in_region(legal, CARNUTES, AEDUI) == DIVICIACUS
    clean(legal)
    return {
        'case': 'with_one_warband_control' if add_warband else 'lone_diviciacus',
        'high_value_trigger': trigger, 'expected_command': CMD_BATTLE,
        'observed_action': action, 'legal_battle_execution': result,
        'ally_after_legal_battle': legal['tribes'][TRIBE_CARNUTES],
        'leader_after_legal_battle': get_leader_in_region(legal, CARNUTES, AEDUI),
        'integrity_errors': clean(legal),
    }


print(json.dumps({
    'roman_settlement_ranking': [roman_case(k) for k in (
        'settlements', 'ally_control', 'one_ally_control')],
    'diviciacus_zero_counterattack': [diviciacus_case(), diviciacus_case(True)],
}, indent=2))
