import json,os,sys
sys.path.insert(0,os.getcwd())
from fs_bot import rules_consts as rc
from fs_bot.cards import ambacti_np,event_conditions
from fs_bot.tools.run_batch import play_one
mode=sys.argv[1]
original_derive=ambacti_np.derive_unshaded
original_available=event_conditions.np_event_available
if mode=='old_aedui_ambacti':
 def old_derive(state,faction):
  return None if faction==rc.AEDUI else original_derive(state,faction)
 ambacti_np.derive_unshaded=old_derive
elif mode=='old_province_gate':
 def old_available(state,card_id,faction,shaded):
  if card_id==21 and not shaded and faction==rc.ROMANS and state['scenario'] in rc.BASE_SCENARIOS:return None
  return original_available(state,card_id,faction,shaded)
 event_conditions.np_event_available=old_available
else:raise ValueError(mode)
for seed in map(int,sys.argv[2:]):
 r=play_one((rc.SCENARIO_GALLIC_WAR,seed,'legacy'))
 print(json.dumps(dict(mode=mode,seed=seed,winner=r['winner'],cards=r['cards'],completed=r['completed'],final_state_sha256=r['final_state_sha256'])),flush=True)
