"""Read-only production review: isolated source/code witnesses for follow-up."""
import json
from fs_bot import rules_consts as r
from fs_bot.state.state_schema import build_initial_state
from fs_bot.board.pieces import place_piece, count_pieces, count_pieces_by_state
from fs_bot.engine.arverni_phase import (
    _arverni_phase_rally, _arverni_phase_march,
    _arverni_phase_raid, _arverni_phase_battle,
)

def new():
    s = build_initial_state(r.SCENARIO_ARIOVISTUS, seed=12)
    s['non_player_factions'] = {r.ROMANS, r.AEDUI, r.BELGAE, r.GERMANS}
    return s

out = {}
s = new()
place_piece(s, r.CARNUTES, r.ARVERNI, r.WARBAND, 3)
place_piece(s, r.CARNUTES, r.ROMANS, r.AUXILIA)
out['confirmed_rally_ally_then_warbands'] = _arverni_phase_rally(s, [r.CARNUTES])

s = new()
place_piece(s, r.CARNUTES, r.ROMANS, r.AUXILIA)
out['confirmed_rally_ally_without_control'] = _arverni_phase_rally(s, [r.CARNUTES])

s = new()
place_piece(s, r.MANDUBII, r.ARVERNI, r.WARBAND, 2)
place_piece(s, r.AEDUI_REGION, r.AEDUI, r.WARBAND, 10)
out['confirmed_secondary_march_preserves_enemy_control'] = {
    'result': _arverni_phase_march(s, r.VENETI),
    'destination_control': s['spaces'][r.AEDUI_REGION]['control'],
}

s = new()
place_piece(s, r.CARNUTES, r.ARVERNI, r.WARBAND, 6)
place_piece(s, r.CARNUTES, r.ROMANS, r.AUXILIA, piece_state=r.REVEALED)
s['resources'][r.ROMANS] = 10
out['confirmed_raid_exceeds_two_warbands'] = _arverni_phase_raid(s, r.ROMANS)

s = new()
place_piece(s, r.CARNUTES, r.ARVERNI, r.WARBAND, piece_state=r.HIDDEN)
place_piece(s, r.CARNUTES, r.ARVERNI, r.WARBAND, 3, piece_state=r.REVEALED)
place_piece(s, r.CARNUTES, r.ROMANS, r.AUXILIA, 3, piece_state=r.HIDDEN)
s['resources'][r.ROMANS] = 10
out['confirmed_raid_reserves_for_impossible_ambush'] = _arverni_phase_raid(s, r.ROMANS)

s = new()
place_piece(s, r.CARNUTES, r.ARVERNI, r.WARBAND, piece_state=r.SCOUTED)
_arverni_phase_march(s, r.CARNUTES)
out['not_a_bug_scouted_march'] = {
    visibility: count_pieces_by_state(s, r.CARNUTES, r.ARVERNI, r.WARBAND, visibility)
    for visibility in (r.HIDDEN, r.REVEALED, r.SCOUTED)
}

s = new()
place_piece(s, r.CARNUTES, r.ARVERNI, r.WARBAND, 3)
place_piece(s, r.CARNUTES, r.ROMANS, r.AUXILIA, piece_state=r.REVEALED)
place_piece(s, r.CARNUTES, r.AEDUI, r.WARBAND, piece_state=r.REVEALED)
result = _arverni_phase_battle(s, r.CARNUTES, r.ROMANS)
out['not_reproduced_multiple_battles'] = {
    'battles': [(b['region'], b['defender']) for b in result['battles']],
    'arverni_hidden_after': count_pieces_by_state(s, r.CARNUTES, r.ARVERNI, r.WARBAND, r.HIDDEN),
    'aedui_remaining': count_pieces(s, r.CARNUTES, r.AEDUI),
}

print(json.dumps(out, indent=2))
