"""Audit 12 UI controls. Uses live terminal collectors and public execution."""
import argparse
import copy
import io
import json
from pathlib import Path
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--repo', required=True)
args = parser.parse_args()
sys.path.insert(0, str(Path(args.repo).resolve()))
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces, count_pieces_by_state
from fs_bot.board.control import refresh_all_control
from fs_bot.cli.human_plan import collect_player_action
from fs_bot.cli.reactive import make_cli_reactive
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND_SA
from fs_bot.state.serialize import encode, decode
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.tools.seat_session import board_copy, validate_response


class Input:
    def __init__(self, output, lines):
        self.output, self.lines, self.offset = output, list(lines), 0
        self.used = []
    def readline(self):
        text = self.output.getvalue()[self.offset:]
        self.offset = len(self.output.getvalue())
        if 'Voluntary removal?' in text:
            answer = 'Use default (remove no pieces)'
        elif 'Give Resources to another Faction' in text:
            answer = 'n'
        elif self.lines:
            answer = self.lines.pop(0)
        else:
            raise AssertionError('Unexpected prompt: ' + text)
        self.used.append(answer)
        return answer + '\n'


def check(state):
    result = {'census': validate_state(state), 'structure': check_structural_integrity(state)}
    assert result == {'census': [], 'structure': []}, result
    return result


def fixture(scenario):
    state = build_initial_state(scenario, seed=19)
    state['non_player_factions'] = set(rc.FACTIONS) - {rc.ROMANS}
    state['resources'][rc.ROMANS] = 20
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    return state


def build_case(scenario):
    state = fixture(scenario)
    place_piece(state, rc.SEQUANI, rc.ROMANS, rc.LEADER, leader_name=rc.CAESAR)
    place_piece(state, rc.SEQUANI, rc.ROMANS, rc.AUXILIA, 2)
    refresh_all_control(state)
    before_integrity = check(state)
    output = io.StringIO()
    source = Input(output, ['March', rc.SEQUANI, 'Stay here (hide pieces; pay March cost)',
                            'y', 'Build', rc.SEQUANI, '(done)', 'Place a Fort',
                            'Place a Roman Ally at Helvetii'])
    state['decision_agent'] = make_cli_reactive({rc.ROMANS}, source, output)
    before = encode(board_copy(state))
    try:
        plan = collect_player_action(state, rc.ROMANS, ACTION_COMMAND_SA, source, output)
    except BaseException:
        print(output.getvalue(), file=sys.stderr)
        raise
    assert encode(board_copy(state)) == before
    assert not source.lines, source.lines
    assert plan['details']['build_plan']['forts'] == [rc.SEQUANI]
    assert [{k: e[k] for k in ('region', 'tribe')} for e in plan['details']['build_plan']['allies']] == [{'region': rc.SEQUANI, 'tribe': rc.TRIBE_HELVETII}]
    response = {'action': ACTION_COMMAND_SA, 'player_action': plan}
    request = {'kind': 'turn', 'faction': rc.ROMANS, 'options': [ACTION_COMMAND_SA]}
    assert validate_response(state, request, response) == response
    roundtrip = decode(encode(board_copy(state)))
    state.pop('decision_agent')
    result = execute_decision(state, rc.ROMANS, response)
    replay = execute_decision(roundtrip, rc.ROMANS, copy.deepcopy(response))
    assert result == replay and encode(board_copy(state)) == encode(board_copy(roundtrip))
    assert result['executed'] and not result.get('errors')
    assert count_pieces(state, rc.SEQUANI, rc.ROMANS, rc.FORT) == 1
    assert state['tribes'][rc.TRIBE_HELVETII]['allied_faction'] == rc.ROMANS
    assert state['resources'][rc.ROMANS] == 14
    return {'name':'build_fort_and_ally_same_region', 'scenario':scenario,
            'before': before_integrity, 'after':check(state), 'plan':plan,
            'result':result, 'planning_pure': True, 'serialized_replay_equal':True,
            'transcript':output.getvalue()}


def scout_case(scenario):
    state = fixture(scenario)
    place_piece(state, rc.MORINI, rc.ROMANS, rc.LEADER, leader_name=rc.CAESAR)
    place_piece(state, rc.MORINI, rc.ROMANS, rc.AUXILIA, 2)
    place_piece(state, rc.MORINI, rc.BELGAE, rc.WARBAND, piece_state=rc.HIDDEN)
    place_piece(state, rc.MORINI, rc.ARVERNI, rc.WARBAND, piece_state=rc.REVEALED)
    refresh_all_control(state)
    before_integrity = check(state)
    output = io.StringIO()
    source = Input(output, ['March', rc.MORINI, 'Stay here (hide pieces; pay March cost)',
        'y', 'Scout', 'Hidden Auxilia from Morini (2 unmoved)', rc.NERVII, '1',
        'Finish Scout movement', 'Scout in Morini (1 Hidden Auxilia)', '1',
        'Belgae Hidden Warbands (up to 1)', '1', 'Arverni Revealed Warbands (up to 1)', '1',
        'Finish Scout Reveal'])
    state['decision_agent'] = make_cli_reactive({rc.ROMANS}, source, output)
    before = encode(board_copy(state))
    try:
        plan = collect_player_action(state, rc.ROMANS, ACTION_COMMAND_SA, source, output)
    except BaseException:
        print(output.getvalue(), file=sys.stderr)
        raise
    assert encode(board_copy(state)) == before and not source.lines
    assert 'Auxilia from Nervii' not in output.getvalue(), 'The moved Auxilia became selectable again'
    response = {'action': ACTION_COMMAND_SA, 'player_action': plan}
    assert validate_response(state, {'kind': 'turn', 'faction': rc.ROMANS,
                                    'options': [ACTION_COMMAND_SA]}, response) == response
    roundtrip = decode(encode(board_copy(state)))
    state.pop('decision_agent')
    result = execute_decision(state, rc.ROMANS, response)
    replay = execute_decision(roundtrip, rc.ROMANS, copy.deepcopy(response))
    assert result == replay and encode(board_copy(state)) == encode(board_copy(roundtrip))
    assert result['executed'] and not result.get('errors')
    assert count_pieces_by_state(state, rc.NERVII, rc.ROMANS, rc.AUXILIA, rc.HIDDEN) == 1
    assert count_pieces_by_state(state, rc.MORINI, rc.ROMANS, rc.AUXILIA, rc.REVEALED) == 1
    for owner in (rc.BELGAE, rc.ARVERNI):
        assert count_pieces_by_state(state, rc.MORINI, owner, rc.WARBAND, rc.SCOUTED) == 1
    assert state['resources'][rc.ROMANS] == 18
    return {'name':'scout_single_move_and_two_physical_targets', 'scenario':scenario,
            'before':before_integrity, 'after':check(state), 'plan':plan,
            'result':result, 'planning_pure':True, 'serialized_replay_equal':True,
            'moved_piece_not_reoffered':True, 'transcript':output.getvalue()}


if __name__ == '__main__':
    cases = [probe(scenario) for probe in (build_case, scout_case)
             for scenario in (rc.SCENARIO_GREAT_REVOLT, rc.SCENARIO_ARIOVISTUS)]
    print(json.dumps({'cases': cases, 'confirmed_findings': []}, indent=2, sort_keys=True))
