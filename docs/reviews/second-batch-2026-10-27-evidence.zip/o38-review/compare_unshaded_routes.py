import copy,hashlib,json
from fs_bot import rules_consts as rc
from fs_bot.state.state_schema import build_initial_state
from fs_bot.cards.card_effects import execute_card_O38
from fs_bot.bots.bot_common import should_decline_event
from fs_bot.bots.roman_bot import node_r4,execute_roman_turn
from fs_bot.bots.aedui_bot import node_a3,execute_aedui_turn
rows=[]
for scenario in rc.BASE_SCENARIOS:
 for flag in (None,False,True):
  for winters in (1,2):
   for present in (False,True):
    for faction,node,turn in ((rc.ROMANS,node_r4,execute_roman_turn),(rc.AEDUI,node_a3,execute_aedui_turn)):
     s=build_initial_state(scenario,seed=7,diviciacus_option=True)
     s.update(non_player_factions={rc.ROMANS,rc.AEDUI,rc.BELGAE,rc.ARVERNI},current_card=rc.CARD_O38,current_card_id=rc.CARD_O38,can_play_event=True,is_second_eligible=False,next_card=None)
     s['deck']=[rc.WINTER_CARD]*winters
     if flag is not None:s['final_year']=flag
     if present:
      s['event_params']={'region':rc.AEDUI_REGION};execute_card_O38(s);s.pop('event_params')
     rows.append((scenario,flag,winters,present,faction,should_decline_event(s,rc.CARD_O38,faction),node(s),turn(copy.deepcopy(s))))
print(len(rows),hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest())
print('node_counts', {x:sum(r[-2]==x for r in rows) for x in ['Yes','No']})
