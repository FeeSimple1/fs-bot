"""Round 6 Battle consumer witnesses on 86fb0c2 (asserts current defects).
Run with PYTHONPATH=<fs-bot-root> python probe_battle.py.
All placements use helpers; all Events and Battles use execute_decision.
"""
import json
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces, remove_piece
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND, ACTION_EVENT
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.tools.seat_session import validate_response
from fs_bot.cards.card_data import get_ariovistus_event_card_ids
from fs_bot.battle.losses import calculate_losses

R = rc.CARNUTES

def board(seed=1):
    s=build_initial_state(rc.SCENARIO_ARIOVISTUS,seed=seed)
    s['non_player_factions']=set()
    place_piece(s,rc.PROVINCIA,rc.ROMANS,rc.FORT)
    for f in (rc.ROMANS,rc.GERMANS,rc.AEDUI,rc.BELGAE):s['resources'][f]=20
    return s

def integrity(s):
    out={'census':validate_state(s),'structure':check_structural_integrity(s)}
    assert not any(out.values()),out
    return out

def event(s,card,faction,shaded=False,params=None):
    s['current_card']=card
    decision={'action':ACTION_EVENT,'player_action':{'command':rc.FIRST_DID_EVENT,'regions':[],
      'sa':'No SA','sa_regions':[],'details':{'card_id':card,
      'text_preference':rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,'event_params':params or {}}}}
    result=execute_decision(s,faction,decision)
    assert result['executed'] and not result.get('errors'),result
    return result

def battle(s,attacker,defender):
    decision={'action':ACTION_COMMAND,'player_action':{'command':rc.CMD_BATTLE,
       'sa':'No SA','regions':[R],'details':{'battle_plan':[{'region':R,'target':defender}]}}}
    validate_response(s,{'kind':'turn','faction':attacker,'options':[ACTION_COMMAND]},decision)
    result=execute_decision(s,attacker,decision)
    assert result['executed'] and not result.get('errors'),result
    return result

def capture(s):
    calls=[]
    def agent(state,owner,request):
        calls.append({'owner':owner,'kind':request['kind'],'num_losses':request.get('num_losses'),
                      'pieces':request.get('pieces')})
        if request['kind']=='retreat':return {'retreat':False}
        return None
    s['decision_agent']=agent
    return calls

def legio(inflexible=True,legio=True,defender=rc.GERMANS):
    s=board()
    place_piece(s,R,rc.ROMANS,rc.LEADER,leader_name=rc.CAESAR)
    place_piece(s,R,rc.ROMANS,rc.LEGION,2,from_legions_track=True)
    place_piece(s,R,defender,rc.WARBAND,8)
    if legio:event(s,15,defender,True)
    if inflexible:event(s,'A31',rc.ROMANS)
    before=integrity(s)
    predicted=calculate_losses(s,R,rc.ROMANS,defender)
    calls=capture(s)
    result=battle(s,rc.ROMANS,defender)
    return {'inflexible':inflexible,'legio_shaded':legio,'defender':defender,
      'before':before,'after':integrity(s),'predicted_attack_losses':predicted,
      'defender_survivors':count_pieces(s,R,defender,rc.WARBAND),'requests':calls,'result':result}

def slingers(stalwart=True,slingers=True,attacker=rc.GERMANS,horse=False):
    s=board()
    place_piece(s,R,attacker,rc.WARBAND,4)
    place_piece(s,R,rc.ROMANS,rc.AUXILIA,2)
    if slingers:event(s,13,rc.ROMANS)
    if horse:event(s,59,rc.ROMANS)
    if stalwart:event(s,'A31',rc.GERMANS,True)
    before=integrity(s)
    calls=capture(s)
    result=battle(s,attacker,rc.ROMANS)
    return {'stalwart':stalwart,'slingers_unshaded':slingers,'horse_unshaded':horse,'attacker':attacker,
      'before':before,'after':integrity(s),'attacker_survivors':count_pieces(s,R,attacker,rc.WARBAND),
      'roman_auxilia_survivors':count_pieces(s,R,rc.ROMANS,rc.AUXILIA),'requests':calls,'result':result}

def german_position(third_party=False):
    s=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=1)
    s['non_player_factions']=set()
    place_piece(s,rc.PROVINCIA,rc.ROMANS,rc.FORT)
    place_piece(s,R,rc.GERMANS,rc.WARBAND,4)
    place_piece(s,R,rc.ROMANS,rc.AUXILIA,2)
    if third_party:place_piece(s,R,rc.AEDUI,rc.WARBAND,2)
    return s

def alternate_ambush(route,slingers=True):
    from fs_bot.engine.germans_battle import germans_phase_battle
    guided=route=='event17'
    s=german_position(third_party=guided)
    if route=='event53':
        remove_piece(s,R,rc.GERMANS,rc.WARBAND)
        place_piece(s,R,rc.ROMANS,rc.AUXILIA,2)
    if slingers:event(s,13,rc.ROMANS)
    before=integrity(s)
    calls=[]
    def agent(state,owner,req):
        calls.append({'owner':owner,'kind':req['kind'],'request_type':req.get('request_type'),
                      'num_losses':req.get('num_losses')})
        if req.get('request_type')=='german_guided_march':return {'marches':[]}
        if req.get('request_type')=='german_guided_ambush':return {'region':R,'defender':rc.AEDUI}
        return None
    s['decision_agent']=agent
    if route=='phase':result=germans_phase_battle(s)
    elif route=='event17':result=event(s,17,rc.ROMANS)
    elif route=='event53':result=event(s,53,rc.AEDUI)
    else:result=battle(s,rc.GERMANS,rc.ROMANS)
    return {'route':route,'slingers_unshaded':slingers,'before':before,'after':integrity(s),
      'survivors':{f:count_pieces(s,R,f) for f in (rc.GERMANS,rc.ROMANS,rc.AEDUI)},
      'requests':calls,'result':result}

def repeated_defenders(event53=True):
    from fs_bot.engine.germans_battle import germans_phase_battle
    s=german_position(third_party=True)
    before=integrity(s);calls=capture(s)
    result=event(s,53,rc.AEDUI) if event53 else germans_phase_battle(s)
    return {'route':'event53' if event53 else 'ordinary_phase','before':before,'after':integrity(s),
      'survivors':{f:count_pieces(s,R,f) for f in (rc.GERMANS,rc.ROMANS,rc.AEDUI)},
      'loss_owners':list(dict.fromkeys(c['owner'] for c in calls if c['kind']=='loss_order')),
      'requests':calls,'result':result}

def main():
    cards=(15,13,59,'A31')
    assert set(cards).issubset(get_ariovistus_event_card_ids())
    out={'audited_commit':'86fb0c2d8ddf86a4548a863dc9c9da27d0c708ad',
      'deck_coexistence':{str(c):c in get_ariovistus_event_card_ids() for c in cards},
      'inflexible_shaded_legio':[legio(),legio(False),legio(legio=False),legio(defender=rc.BELGAE)],
      'stalwart_slingers':[slingers(),slingers(False),slingers(slingers=False),slingers(attacker=rc.BELGAE),slingers(horse=True)],
      'alternate_ambush_paths':[alternate_ambush('phase'),alternate_ambush('phase',False),
        alternate_ambush('ordinary_engine_control'),alternate_ambush('event17'),alternate_ambush('event17',False),
        alternate_ambush('event53')],
      'consuetudine_repeated_defenders':[repeated_defenders(),repeated_defenders(False)]}
    assert [x['defender_survivors'] for x in out['inflexible_shaded_legio']]==[4,4,3,4]
    assert [x['predicted_attack_losses'] for x in out['inflexible_shaded_legio']]==[4,4,5,4]
    assert [(x['attacker_survivors'],x['roman_auxilia_survivors']) for x in out['stalwart_slingers']]==[(3,1),(3,1),(4,0),(3,1),(2,1)]
    assert [(x['survivors'][rc.GERMANS],x['survivors'][rc.ROMANS],x['survivors'][rc.AEDUI])
            for x in out['alternate_ambush_paths']]==[(4,0,0),(4,0,0),(3,1,0),(4,2,0),(4,2,0),(3,3,0)]
    assert [x['loss_owners'] for x in out['consuetudine_repeated_defenders']]==[[rc.AEDUI,rc.ROMANS],[rc.AEDUI]]
    assert [x['survivors'][rc.GERMANS] for x in out['consuetudine_repeated_defenders']]==[4,4]
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
