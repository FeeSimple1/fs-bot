# Separate Litaviccus non-player target follow-up

Read-only review of parent4e9a82e, 3 November2026. This finding is separate
from BE-02's restored human target choice and is not implemented here.

The supplied Belgic Event instruction groups Legiones XIIII et XV and
Litaviccus: "Battle where most Losses forced on Legions; if none, treat as
'No Belgae'." The present Litaviccus resolver instead selects the Region
with the most Roman pieces, without a Legion-loss metric. Its availability
check only looks for any Roman force with an eligible attacker.

The funded witness has ten Roman Auxilia in Carnutes and one Roman Legion in
Mandubii. Belgic forces can legally Ambush the latter without Caesar, causing
one guaranteed Legion removal. The old resolver selects Carnutes, where
there are no Legions at all. This establishes a mismatch without uncertain
human responses or saving rolls. Both board and piece integrity remain valid.

The initial zero-Resource private-helper witness is retained separately.
It reports an insufficient-Resources error because the private helper lacks
the caller's free scope; this is NOT a separate public Event bug. The public
Event caller supplies that scope, and the funded witness isolates target
selection from it.

## What the sources settle

- 8.2.3 applies the printed Event instruction and ordinary non-player
  conditions/priorities to the relevant Event Regions.
- 8.5.1 explicitly uses the best case of all Defender Loss rolls removing
  pieces when judging Belgic Battle prospects.
- 8.4.3 specifies the actual non-player Roman Retreat response, including
  reducing forced Legion Loss rolls.
- Equal otherwise-unprioritized candidates use seeded random selection
  (8.3.4), not map insertion order.
- Litaviccus itself grants use of Aedui pieces and Ambush only if able.
  Its grant is not discretionary Aedui lending.

## What remains unspecified for a complete selector

No cited passage explicitly chooses a prediction convention for a *human*
Roman defender's optional Retreat/response when comparing potential Legion
Losses before selecting the Battle Region. The printed best-case Defender
Loss-roll assumption does not itself decide whether that human will Retreat.
The existing PR-11 adopts a conservative human-response forecast for numeric
Arduenna67 only; it does not authorize applying that policy to card45.

A complete correction therefore needs a narrow disposition: should the
selector rank standing-Battle Legion Losses, use actual NP responses and
conservative human responses (as separately adopted for67), or interpret
"forced" as a stricter guaranteed result? The supplied references settle
the defect in the witness but do not expressly settle that general forecast.
Do not label the largest-stack fallback rules-correct, and do not silently
extend PR-11. Record the follow-up and obtain an authoritative clarification
or explicit owner ruling before replacing the whole target predictor.
