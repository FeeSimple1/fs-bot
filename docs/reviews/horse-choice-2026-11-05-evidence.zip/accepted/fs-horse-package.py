from pathlib import Path
import hashlib, io, json, platform, subprocess, tarfile, tempfile, zipfile
import xml.etree.ElementTree as ET
from fs_bot.tools.validation_metadata import source_identity

prefix = 'horse-choice-2026-11-05'
result = json.loads(Path('/tmp/fs-horse-results.json').read_text())
assert source_identity() == result['source']
suite = ET.parse('/tmp/fs-horse-full.xml').getroot().find('testsuite')
assert suite.attrib['tests'] == '8688'
assert all(suite.attrib[k] == '0' for k in ('failures', 'errors', 'skipped'))
assert sum(t.attrib['classname'].endswith('test_horse_choice') for t in suite) == 64
patch = subprocess.check_output(['git', 'diff', 'HEAD', '--', 'fs_bot'])
new_files = ('fs_bot/engine/horse_choice.py', 'fs_bot/cli/horse.py',
             'fs_bot/tests/test_horse_choice.py')
with tempfile.TemporaryDirectory(prefix='fs-horse-reconstruct-') as directory:
    root = Path(directory)
    parent = subprocess.check_output(['git', 'archive', result['source']['commit'], 'fs_bot'])
    with tarfile.open(fileobj=io.BytesIO(parent)) as archive:
        archive.extractall(root, filter='data')
    subprocess.run(['git', 'apply', '--unsafe-paths', '-'], cwd=root, input=patch, check=True)
    for name in new_files:
        (root / name).write_bytes(Path(name).read_bytes())
    files = sorted((root / 'fs_bot').rglob('*.py'))
    assert len(files) == 520
    digest = hashlib.sha256()
    for path in files:
        digest.update(str(path.relative_to(root)).encode()+b'\0'+path.read_bytes())
    assert digest.hexdigest() == result['source']['source_sha256']
result.update(full_suite=suite.attrib, python=platform.python_version(),
              source_reconstruction_verified=True,
              compatibility_limit='Older histories can stop at the new owner Region choice or diverge from the corrected NPC priority and Abatis interaction. Prospective-queue Card 13/59 choices remain open.')
commands = [
 'python -m pytest -q --junitxml=/tmp/fs-horse-full.xml',
 'python -m pytest -q fs_bot/tests/test_horse_choice.py fs_bot/tests/test_slingers_choice.py fs_bot/tests/test_capabilities_base.py fs_bot/tests/test_battle.py fs_bot/tests/test_base_arduenna_np.py fs_bot/tests/test_prospective_battle_observer.py fs_bot/tests/test_event_battle_choices.py fs_bot/tests/test_agent_interface.py fs_bot/tests/test_assistant_session.py fs_bot/tests/test_impetuosity_unshaded.py',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --games 2 --workers 2 --out OUT',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
 'PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20',
 'PYTHONPATH=. python -m pytest -q /tmp/test_horse_parent_proof.py --junitxml=OUT.xml',
 'PYTHONHASHSEED=0 PYTHONPATH=. python /tmp/fs-horse-trace.py parent|final|counterfactual',
 'PYTHONPATH=. python /tmp/fs-horse-verify.py',
 'PYTHONPATH=. python /tmp/fs-horse-package.py',
]
result['commands'] = commands
Path('docs/reviews/'+prefix+'-results.json').write_text(json.dumps(result, indent=2)+'\n')
p = Path('docs/reviews/'+prefix+'.md')
s = p.read_text().replace('Final full-suite and evidence inspection pending.',
 f"**8,688 tests pass**, with zero failures, errors or skips ({float(suite.attrib['time']):.2f} seconds).")
x = result['mixed']
s = s.replace('Frozen source, protected inputs, final results and archive checksums are\nverified separately.', f'''All ten native NPC records complete and audit cleanly, with four ranked
Factions, consistent winner/ranking output and only legal-decline diagnostics.
Nine match every parent gameplay field and final board hash, excluding elapsed
seconds, commit and source identity. The Great Revolt seed 2 has the same
winner but different margins, Resources and surviving forces.

A paired trace finds its first differing Battle on card 20: the parent flags
Nervii for shaded Horse while the first selected Battle is Pictones. The repair
flags Pictones, increasing that attack from two Losses to four. Before the
Battle, the complete position excluding only Horse flags is identical.
Restoring only the old Horse selection policy on the accepted code reproduces
every parent gameplay field and final board hash for that game. Supplemental
trace reruns and the labeled counterfactual are separate from native totals.

The complete mixed-seat JSON outputs match across hash seeds 0 and 987. They
cover {x['human_turns']} human turns, {x['event_turns']} Event attempts and {x['events_ok']} successful Events, with zero hard
findings and zero partial games. Their digest is `{x['batch_digest'][:16]}`.
Internal replay gives 40 executions total. The historical 100-game balance
check passes the existing band, with a maximum difference of
{result['balance']['maximum_absolute_delta_percentage_points']} percentage points and {result['balance']['historical_baseline_winner_changes']} winner changes versus the historical baseline. Those
historical comparisons are separate from the paired parent/current NPC
comparisons.

All 49 protected inputs match the parent byte for byte, comprising 47 supplied
references, canonical constants and the historical balance baseline. Archive
checksums and reconstruction of all 520 Python files verify the accepted source
digest. The first directed run exposed a test harness that left later casualties
unanswered after its accepted decline. That fixture now controls Horse alone;
a separate test retains the full later-casualty continuation. Superseded
development logs are retained separately.''')
p.write_text(s)
p = Path('docs/current-status.md')
p.write_text(p.read_text().replace('Validation pending the final full suite and evidence inspection.',
 '''**8,688 tests pass**, including 64 new cases, with 364 focused tests passing.
Nine of ten NPC records/final hashes match the parent; the changed game is
traced to corrected Horse selection and reproduced by restoring the old policy.
Mixed-seat results agree across hash seeds with zero hard findings or partials, and the historical
100-game balance guard passes its unchanged band. The report records the
frozen source, protected inputs, evidence and cross-revision replay limit.''', 1))
entries = {}
for name in ['fs-horse-full.xml', 'fs-horse-full.log', 'fs-horse-targeted.log',
 'fs-horse-mixed0.json', 'fs-horse-mixed0.log', 'fs-horse-mixed987.json',
 'fs-horse-mixed987.log', 'fs-horse-balance.log', 'fs-horse-proof-parent.xml',
 'fs-horse-proof-parent.log', 'fs-horse-proof-final.xml', 'fs-horse-proof-final.log',
 'test_horse_parent_proof.py', 'fs-horse-verify.py', 'fs-horse-package.py',
 'fs-horse-trace.py', 'fs-horse-trace-parent.json', 'fs-horse-trace-parent.log',
 'fs-horse-trace-final.json', 'fs-horse-trace-final.log',
 'fs-horse-trace-counterfactual.json', 'fs-horse-trace-counterfactual.log']:
    entries['accepted/'+name] = Path('/tmp/'+name).read_bytes()
for label, directory in [('parent', '/tmp/fs-horse-bots-parent'),
                         ('accepted', '/tmp/fs-horse-bots-final')]:
    for path in Path(directory).iterdir():
        if path.is_file():
            entries[label+'/bots/'+path.name] = path.read_bytes()
for name in ['fs-horse-initial.log', 'fs-horse-directed.log', 'fs-horse-retry.log']:
    entries['development/'+name] = Path('/tmp/'+name).read_bytes()
entries['development/README.txt'] = b'The initial sanity run exercised 83 existing capability/Slingers cases. The first 62-case directed run left later casualty prompts unanswered after accepting Horse decline. The scoped fixture now delegates those casualties while a dedicated later-casualty test retains complete pending/save/replay checks. Its Abatis fixture now uses a Gallic Warband owner. The accepted directed rerun has 64 cases, including cancelled/defending Abatis. Final focused/full evidence is separate.\n'
entries['accepted/source.patch'] = patch
for name in new_files:
    entries['accepted/'+name] = Path(name).read_bytes()
protected = [p for p in Path('Reference Documents').rglob('*') if p.is_file()]
protected += [Path('fs_bot/rules_consts.py'), Path('fs_bot/tools/balance_baseline.json')]
entries['accepted/protected-inputs.json'] = json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}, indent=2).encode()
entries['accepted/results.json'] = json.dumps(result, indent=2).encode()
entries['commands.txt'] = ('\n'.join(commands)+'\n\nRun paired NPC batches and unchanged proof cases from their respective parent/current directories. Parent proof gives seven behavioral failures and two passing controls; accepted proof gives nine passing cases. All game matrices here are bounded general regression checks; directed tests exercise the new Horse request.\n').encode()
entries['README.txt'] = (f"Parent {result['source']['commit']}. Apply accepted/source.patch and copy the three accepted/fs_bot new files to reconstruct the accepted source. Digest {result['source']['source_sha256']} across 520 files. Full suite 8688 passed, 64 new cases, 364 focused tests. Nine probes give seven parent failures and two passing controls; all nine pass on the repair. Nine of ten NPC records/final hashes match parent. The changed Great Revolt seed 2 is traced to corrected Horse selection; restoring the old policy reproduces the parent exactly. Mixed-seat complete JSON matches across hash seeds 0/987, with zero hard findings or partials. The historical 100-game balance guard passes its unchanged 15-point band. Original bundle remains 39/50 closed (78%), with BE-09 still open for the prospective queue. {result['compatibility_limit']}\n").encode()
entries['SHA256SUMS.txt'] = ''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(entries.items())).encode()
p = Path('docs/reviews/'+prefix+'-evidence.zip')
with zipfile.ZipFile(p, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(p) as archive:
    assert archive.testzip() is None
    for line in archive.read('SHA256SUMS.txt').decode().splitlines():
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest
print(json.dumps(dict(suite=suite.attrib, archive_bytes=p.stat().st_size, source=result['source'])))
