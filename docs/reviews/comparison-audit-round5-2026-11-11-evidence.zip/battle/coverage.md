# Battle/Command partition, fifth audit

Frozen source bd30d522e8baa2d303b9e372d7d9c550351e91a5. Comparator FeeSimple1/lod-bot at 2991ea279062773548ec390a1da75f3e85381702. Read coin-implementation-lessons.md, especially boundary/data-shape, per-space, cross-faction, and integration-testing patterns. Those patterns directed review of live versus forecast calculators and marker-versus-piece casualty handling. The comparator supplies no Falling Sky rules.

Confirmed groups BM5-01 and BM5-02 have seven controlled public-execution cases in probe_battle.py, all passing their assertions of the present defects and controls. Run from checkout with PYTHONPATH=. python /path/to/probe_battle.py. probe_battle.json records full public results, callback lists, and before/after integrity. Expected source-correct outcomes are documented in findings.json, not treated as observed output.

Reviewed Battle live Attack and Counterattack calculators, their capability terms, loss priority/callback pipeline, effective piece interfaces, Retreat flow, and selection/execution portions of Rampage, Intimidate, Settle, Enlist, Trade and Battle orchestration. Prior comparison ledgers, original human-choice finding summary and casualty identity repair, adopted rulings, and current source questions were consulted to avoid recounting known findings. This is bounded inspection, not exhaustive Command coverage.

Rejected or uncounted leads

- Live Ariovistus Attack checks A31 cancellation of Abatis correctly. A parallel calculate_losses helper checks raw Abatis for Ariovistus doubling, but no public wrong consumer was demonstrated here. Sent to bot partition; excluded from this count.
- A31 versus Balearic Slingers prefire needs careful before-Battle timing interpretation; excluded.
- A31 versus numeric27 Archers cannot coexist in ordinary Ariovistus without additional transition setup because A27 replaces27. No witness or count.
- Fort saving threshold from Card10 interacting with Abatis was not inferred from broad wording; excluded.
- A33 outnumbering scope is an existing source question and remains excluded.
- No new claim from repeated Settle or Intimidate selection: existing per-Region validation/grouping appears to constrain those paths; not a dynamic exhaustive pass.

All probes build controlled states from the canonical initial schema and place pieces with helpers. Permanent Provincia Fort is present. They do not claim natural reach from a sampled game. Numeric15 is an unreplaced Ariovistus card under A Setup36–60 (confirmed independently after a reviewer raised an A15C hypothesis based on a documentation example). No production code, tests, protected references or baseline changed.
