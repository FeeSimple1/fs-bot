# Root audit review

The checkout and canonical main agreed at 86fb0c2 before work. All prior 50/21/15/16/11 findings were closed. The LoD comparator was unchanged at 2991ea2; its boundary, duplicated-calculator, scheduled-action and human-choice patterns guided this pass. Supplied Falling Sky rules govern every conclusion.

Five partitions covered Events, Battle, bots, lifecycle and human/free-action interfaces. Independent review checked references, fixture legality, controls and earlier-ledger overlap; root read the final findings, relevant rule text and command paths, independently reran all seven final probes, and verified every integrated validation record.

Root also inspected Enlist borrowing/free Command integration, Settle geography/cost paths, and printed German movement distinctions. The base Enlist split-group lead was rejected: base 3.4.2 explicitly allows only one moving group. The expansion changes that procedure, yielding the narrower FE6-02 finding. No other root-only suspicion was counted.

Grouping follows repair mechanisms, not individual witnesses. Remaining Stalwart consumers share one group; three missing NPC Event plans share one group; Belgic/Arverni forecast formulas share one group; Arverni and Aedui forced-target guarantees share one group. Automatic German March participant tracking and destination priority are distinct mechanisms. Earlier fixes retain their explicitly tested scope.

This is targeted review and controlled integration testing, not exhaustive coverage of all board states, editions or timing combinations. Unresolved Optimates and other existing source questions are excluded. The audit did not edit production code, tests, references, canonical labels or balance data.
