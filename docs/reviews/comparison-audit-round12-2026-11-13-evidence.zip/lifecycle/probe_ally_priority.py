#!/usr/bin/env python3
"""LC12-02, NP Interlude removes a City Ally before a non-City Ally."""
import argparse
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo.resolve()))
    from fs_bot import rules_consts as rc
    from fs_bot.cards.card_effects import _unally_tribe, _ally_tribe
    from fs_bot.board.pieces import count_pieces
    from fs_bot.engine.game_engine import get_sop_factions
    from fs_bot.engine.interlude_reductions import eligible_cohorts, BELGIC_HALF, ROMAN_HALF
    from fs_bot.engine.victory import check_any_victory, check_victory
    from fs_bot.engine.winter import run_winter_round
    from fs_bot.state.setup import setup_scenario
    from fs_bot.state.state_schema import validate_state, check_structural_integrity

    def integrity(state):
        result = {'census': validate_state(state), 'structure': check_structural_integrity(state)}
        assert result == {'census': [], 'structure': []}, result
        return result

    def run(seed, faction, human, region=rc.MANDUBII):
        state = setup_scenario(rc.SCENARIO_GALLIC_WAR, seed=seed)
        for tribe, info in list(state['tribes'].items()):
            if info.get('allied_faction') == faction:
                _unally_tribe(state, tribe)
        tribes = [tribe for tribe, place in rc.TRIBE_TO_REGION.items() if place == region]
        for tribe in tribes:
            _unally_tribe(state, tribe)
            assert _ally_tribe(state, tribe, faction)
        # Keep the sparse target allocation below an early Roman victory.
        # Each supplementary German Ally consumes a real Available disc.
        added_germans = []
        for tribe, info in sorted(state['tribes'].items()):
            if not check_victory(state, rc.ROMANS):
                break
            if (tribe not in tribes and info.get('allied_faction') is None
                    and info.get('status') is None and _ally_tribe(state, tribe, rc.GERMANS)):
                added_germans.append(tribe)
        state['non_player_factions'] = set(get_sop_factions(state))
        state['winter_count'] = 2
        state['current_card'] = state['current_card_id'] = rc.WINTER_CARD
        assert check_any_victory(state) is None, (faction, human, region, check_any_victory(state))
        before = integrity(state)
        plans = []
        if human:
            state['non_player_factions'].remove(faction)
            stage = BELGIC_HALF if faction == rc.BELGAE else ROMAN_HALF
            def agent(board, owner, request):
                if request.get('stage') != stage:
                    return {'use_default': True}
                remaining = [dict(row) for row in request['cohorts']]
                selected = []
                for kind, minimum in request['minimums'].items():
                    need = minimum
                    while need:
                        eligible = [row for row in eligible_cohorts(stage, remaining)
                                    if row['piece_type'] == kind]
                        eligible.sort(key=lambda row: (row['tribe'] in rc.TRIBE_TO_CITY,
                                                       row['region'], str(row['tribe'])))
                        row = eligible[0]
                        n = min(need, row['count'])
                        selected.append(dict(row, count=n))
                        row['count'] -= n
                        need -= n
                plans.extend(selected)
                return {'removals': selected}
            state['decision_agent'] = agent
        result = run_winter_round(state)
        assert 'interlude' in result and not result['phases']['victory']['game_over']
        after = integrity(state)
        allies = {tribe: state['tribes'][tribe]['allied_faction'] for tribe in tribes}
        expected = rc.TRIBE_MANDUBII if human else rc.TRIBE_SENONES
        if region == rc.CARNUTES:
            expected = rc.TRIBE_CARNUTES
        assert allies[expected] == faction and sum(owner == faction for owner in allies.values()) == 1
        return {'seed': seed, 'faction': faction, 'human': human, 'region': region,
                'before_integrity': before, 'after_integrity': after,
                'supplementary_german_allies': added_germans, 'before_allies': {tribe: faction for tribe in tribes}, 'after_allies': allies,
                'chosen_removals': plans,
                'interlude_adjustment': result['interlude']['step2_belgae' if faction == rc.BELGAE else 'step2_romans']}

    cases = [run(seed, faction, human) for seed in (1, 7, 19)
             for faction in (rc.BELGAE, rc.ROMANS) for human in (False, True)]
    cases += [run(1, faction, False, rc.CARNUTES) for faction in (rc.BELGAE, rc.ROMANS)]
    print(json.dumps({'id': 'LC12-02', 'source_revision': '1563e41d84f61dfce43ce4008106eca2a1639aed',
                     'case_count':len(cases), 'assertions_passed': True, 'cases':cases},indent=2,sort_keys=True))

if __name__ == '__main__':
    main()
