"""Read existing attempt4 paired trace archives; never run games or change acceptance."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUN = ROOT / "attempt4"
CURRENT = "6155e2b5be0d2910ad47aacab2ae8489962375ed8091ed54a503cfe6165ae352"
BASE = "7228099f14b047788c81189f97f0eb434a321dc7e47f835ba548695920bc711f"
CARDS = {2: 39, 5: 30, 7: 2, 12: 55, 13: 43, 14: 16, 15: 13, 16: 63, 19: 59}
CAPABILITIES = {13: "Balearic Slingers", 30: "Vercingetorix’s Elite", 39: "River Commerce", 43: "Convictolitavis", 55: "Commius", 59: "Germanic Horse", 63: "Winter Campaign"}
checks = 0
failures = []
evidence = {}

def check(condition, description):
    global checks
    checks += 1
    if not condition:
        failures.append(description)

def read(path):
    raw = path.read_bytes()
    evidence[str(path.relative_to(RUN))] = hashlib.sha256(raw).hexdigest()
    return json.loads(gzip.decompress(raw) if path.suffix == ".gz" else raw)

def identity(c):
    return tuple(c.get(k) for k in ("card", "card_index", "depth", "faction", "position", "stage"))

def signature(c):
    return identity(c), c.get("state_sha256"), c.get("payload")

rows = [json.loads(x) for x in (RUN / "bots-legacy/games.jsonl").read_text().splitlines()]
raw = {r["seed"]: r for r in rows if r["scenario"] == "The Great Revolt"}
paired = {r["seed"]: r for r in read(RUN / "legacy-paired-comparison.json")["records"] if r["scenario"] == "The Great Revolt"}
old = read(RUN / "balance-baseline.json")["games"]
reviews = []
for seed, card in CARDS.items():
    directory = RUN / "drift-review" / f"the-great-revolt-{seed:02}"
    comparison = read(directory / "comparison.json")
    before = read(directory / "baseline.json.gz")
    after = read(directory / "current.json.gz")
    for label, trace, expected_source, record in (("baseline", before, BASE, paired[seed]["first_batch"]), ("current", after, CURRENT, raw[seed])):
        check(trace["source"]["source_sha256"] == trace["source_after"]["source_sha256"] == expected_source, f"{seed}/{label}: source changed/mismatched")
        check(trace["passed"] is True and trace["final_hash_matches_audited_record"] is True, f"{seed}/{label}: failed or unverified trace")
        check(trace["scenario"] == "The Great Revolt" and trace["seed"] == seed, f"{seed}/{label}: wrong traced case")
        for field in ("winner", "cards", "final_state_sha256", "final_ranking", "termination", "interlude_completed"):
            check(trace["record"][field] == record[field], f"{seed}/{label}: recorded {field} differs from audited matrix")
        check(trace["expected_final_state_sha256"] == record["final_state_sha256"], f"{seed}/{label}: expected final hash differs from audited matrix")
        check(comparison[f"{label}_final_state_sha256"] == record["final_state_sha256"] and comparison[f"{label}_final_hash_verified"] is True,
              f"{seed}/{label}: comparison final identity mismatch")
    first = next((i for i, (a, b) in enumerate(zip(before["checkpoints"], after["checkpoints"])) if signature(a) != signature(b)), None)
    check(first == comparison["common_checkpoint_prefix"] == comparison["first_difference"]["comparison_index"], f"{seed}: independently computed first divergence mismatch")
    a = before["checkpoints"][first]
    b = after["checkpoints"][first]
    pre_a = before["checkpoints"][first - 1]
    pre_b = after["checkpoints"][first - 1]
    check(identity(a) == identity(b) and b["card"] == card and b["stage"] == "after_decision", f"{seed}: unexpected first differing boundary")
    check(pre_a["stage"] == pre_b["stage"] == "before_decision" and signature(pre_a) == signature(pre_b)
          and pre_a["board_and_rng_sha256"] == pre_b["board_and_rng_sha256"], f"{seed}: no identical immediately preceding decision state")
    check(a["payload"]["action"] == "event" and b["payload"]["action"] in ("command", "command_sa", "limited_command"), f"{seed}: unexpected Event decline routing")
    facts = pre_b["facts"]
    if seed in (7, 14):
        check(b["faction"] == "Aedui" and facts["conditional_no_event"] is True and facts["roman_score"] == 13
              and facts["queried_next_winter_is_final"] is False, f"{seed}: conditional rule preconditions not demonstrated")
        cause = "Aedui conditional No Event: current Roman score13 exceeds12"
        source = "Reference Documents/aedui_bot_event_instructions.txt:17-24; card2 Legiones XIIII et XV / card16 Ambacti"
    else:
        check(card in CAPABILITIES and facts["deck_winter_cards"] == 1 and facts["played_winter_cards"] == 2
              and facts["winter_count"] == 2 and facts["queried_next_winter_is_final"] is True,
              f"{seed}: final-year Capability preconditions not demonstrated")
        cause = f"Final-year Capability declined: {CAPABILITIES[card]}"
        source = "Reference Documents/Chapter 8:30-40 (§8.1.1); corresponding card in Reference Documents/Card Reference"
    reviews.append({"seed": seed, "card": card, "card_index": b["card_index"], "faction": b["faction"], "common_checkpoints": first,
                    "source_supported_first_divergence": cause, "source_location": source,
                    "stored_baseline_winner": old[f"The Great Revolt|{seed}"]["winner"], "paired_04b_winner": before["record"]["winner"],
                    "current_winner": after["record"]["winner"], "identical_predecision_board_rng": True})
stored_aedui = sum(old[f"The Great Revolt|{seed}"]["winner"] == "Aedui" for seed in range(1,21))
paired_aedui = sum(paired[seed]["first_batch"]["winner"] == "Aedui" for seed in range(1,21))
current_aedui = sum(raw[seed]["winner"] == "Aedui" for seed in range(1,21))
gained = [seed for seed in range(1,21) if raw[seed]["winner"] == "Aedui" and old[f"The Great Revolt|{seed}"]["winner"] != "Aedui"]
check((stored_aedui, paired_aedui, current_aedui) == (1,2,5) and gained == [12,14,15,19], "Aedui winner totals or newly won seeds mismatch")
check(set(gained) <= set(CARDS), "New Aedui wins lack reviewed first divergence")
report = {"status": "independent source-supported first-divergence review; no baseline approval", "passed": not failures,
          "checks_performed": checks, "failures": failures, "source_sha256": CURRENT, "paired_baseline_source_sha256": BASE,
          "traces_reviewed": len(reviews), "paired_trace_archives": 2 * len(reviews), "classifications": {"final_year_capability": 7, "aedui_conditional_no_event": 2},
          "great_revolt_aedui": {"stored_baseline_wins": stored_aedui, "paired_04b_wins": paired_aedui, "current_wins": current_aedui,
                                "games":20, "original_percentage_point_drift":20, "unchanged_band_percentage_points":15,
                                "original_guardrail_passed":False, "new_stored_baseline_winning_seeds":gained},
          "reviews": reviews, "evidence_sha256": evidence, "new_games_executed":0,
          "limitations": ["Identifies source-supported first trajectory differences; does not prove that one change alone caused each final winner.",
                          "Full final-state hashes match existing audited records; this read-only review does not reconstruct boards from game execution.",
                          "Original stored baseline1→5 remains the failed guardrail. Paired clean04b2→5 is causal context only and does not replace that baseline."]}
with (RUN / "independent-great-revolt-causal-review.json").open("x") as f:
    json.dump(report,f,indent=2,sort_keys=True);f.write("\n")
print(json.dumps({k:v for k,v in report.items() if k not in ("reviews","evidence_sha256")},indent=2))
raise SystemExit(1 if failures else 0)
