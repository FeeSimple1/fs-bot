"""Observed-defect witnesses for Falling Sky 3c23a34. No engine edits."""
import json
from copy import deepcopy
from fs_bot import rules_consts as rc
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.state.setup import setup_scenario
from fs_bot.board.pieces import place_piece, count_pieces, count_pieces_by_state, get_available
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.victory import calculate_victory_score
from fs_bot.tools.seat_session import validate_response

def fresh(edition):
    s=build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=4)
    s['card_edition']=edition
    return s

def check(s):
    errors=validate_state(s)+check_structural_integrity(s)
    assert not errors,errors

def play(s,card,params,shaded=False,actor=rc.BELGAE):
    check(s)
    s['current_card']=s['current_card_id']=card
    d={'action':'event','player_action':{'command':'Event','details':{
        'card_id':card,'text_preference':rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,
        'event_params':params}}}
    validate_response(s,{'kind':'turn','faction':actor,'options':['event']},d)
    result=execute_decision(s,actor,d)
    assert result['executed'],result
    check(s)
    return result

records=[]
for edition in ('original','second-edition'):
    s=fresh(edition)
    place_piece(s,rc.PICTONES,rc.GERMANS,rc.WARBAND,4)
    place_piece(s,rc.PICTONES,rc.AEDUI,rc.WARBAND,5)
    play(s,53,{})
    assert count_pieces(s,rc.PICTONES,rc.AEDUI,rc.WARBAND)==5
    records.append({'case':'consuetudine_missing_forced_ambush','edition':edition,
        'region':rc.PICTONES,'german_warbands':4,'aedui_hidden_before':5,
        'aedui_warbands_after':5,'expected_aedui_after':3,
        'german_hidden_after':count_pieces_by_state(s,rc.PICTONES,rc.GERMANS,rc.WARBAND,rc.HIDDEN),
        'german_revealed_after':count_pieces_by_state(s,rc.PICTONES,rc.GERMANS,rc.WARBAND,rc.REVEALED)})
    s=fresh(edition)
    place_piece(s,rc.PICTONES,rc.GERMANS,rc.WARBAND,1,piece_state=rc.SCOUTED)
    place_piece(s,rc.PICTONES,rc.AEDUI,rc.WARBAND,2)
    play(s,53,{})
    assert count_pieces_by_state(s,rc.PICTONES,rc.GERMANS,rc.WARBAND,rc.SCOUTED)==1
    records.append({'case':'consuetudine_scouted_not_cleared','edition':edition,
        'german_scouted_after':1,'expected_scouted_after':0,'expected_revealed_after':1})
    s=fresh(edition)
    play(s,71,{'region':rc.CARNUTES},actor=rc.AEDUI)
    name='Colony_'+rc.CARNUTES
    assert s['tribes'][name]['allied_faction']==rc.AEDUI
    play(s,34,{},True)
    assert s['tribes'][name]['allied_faction']==rc.AEDUI
    records.append({'case':'acco_skips_colony','edition':edition,'region':rc.CARNUTES,
        'tribe':name,'owner_after':rc.AEDUI,'expected_owner':rc.ARVERNI})
    s=setup_scenario(rc.SCENARIO_GREAT_REVOLT,seed=4,card_edition=edition)
    for tribe in list(s['tribes']):
        if get_available(s,rc.ROMANS,rc.ALLY)==0:break
        _ally_tribe(s,tribe,rc.ROMANS)
    assert get_available(s,rc.ROMANS,rc.ALLY)==0
    before_score=calculate_victory_score(s,rc.ROMANS)
    before_n=len(s['tribes'])
    play(s,71,{'region':rc.BRITANNIA},actor=rc.ROMANS)
    assert s['markers'][rc.BRITANNIA][rc.MARKER_COLONY]
    assert len(s['tribes'])==before_n
    assert calculate_victory_score(s,rc.ROMANS)==before_score
    records.append({'case':'colony_no_available_ally_loses_tribe','edition':edition,
        'region':rc.BRITANNIA,'roman_available_allies':0,'tribes_before':before_n,
        'tribes_after':len(s['tribes']),'colony_marker':True,
        'roman_score_before':before_score,'roman_score_after':calculate_victory_score(s,rc.ROMANS),
        'expected_score_after':before_score+1})
    s=setup_scenario(rc.SCENARIO_GREAT_REVOLT,seed=4,card_edition=edition)
    assert s['tribes'][rc.TRIBE_CATUVELLAUNI]['allied_faction'] is None
    assert get_available(s,rc.ARVERNI,rc.ALLY)>0
    before=count_pieces(s,rc.BRITANNIA,rc.ARVERNI,rc.WARBAND)
    play(s,66,{'faction':rc.ARVERNI,'target_region':rc.BRITANNIA,'moves':[
        {'from_region':rc.ARVERNI_REGION,'to_region':rc.BRITANNIA,'piece_type':rc.WARBAND,'count':1}]},True)
    assert count_pieces(s,rc.BRITANNIA,rc.ARVERNI,rc.WARBAND)==before+1
    assert s['tribes'][rc.TRIBE_CATUVELLAUNI]['allied_faction'] is None
    records.append({'case':'migration_omits_mandatory_ally','edition':edition,
        'region':rc.BRITANNIA,'moved_arverni_warbands':1,'tribe_owner_after':None,
        'expected_owner':rc.ARVERNI,'available_ally':get_available(s,rc.ARVERNI,rc.ALLY)})
print(json.dumps(records,indent=2))
