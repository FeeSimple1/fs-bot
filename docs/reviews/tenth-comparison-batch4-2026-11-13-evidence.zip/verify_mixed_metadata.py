"""Compare full mixed-seat trajectories after removing Battle display metadata."""

import json
from unittest.mock import patch

from fs_bot.tools import player_fuzz


def strip_presentation(value):
    if isinstance(value, list):
        return [strip_presentation(item) for item in value]
    if isinstance(value, tuple):
        return tuple(strip_presentation(item) for item in value)
    if isinstance(value, dict):
        return {key: strip_presentation(item) for key, item in value.items()
                if key != 'battle_sa' or not value.get('battle_sa_executed')}
    return value


def main():
    digest = player_fuzz._digest
    records = []

    def capture(state, result):
        records[-1] = {'raw': digest(state, result),
                       'without_battle_display': digest(strip_presentation(state),
                                                        strip_presentation(result))}
        return records[-1]['raw']

    with patch.object(player_fuzz, '_digest', capture):
        for scenario in player_fuzz.ALL_SCENARIOS:
            for seed in range(53, 57):
                records.append(None)
                row = player_fuzz.play_game(scenario, seed, card_edition='second-edition')
                assert row['game_completed'] and not row['findings']
                records[-1].update(scenario=scenario, seed=seed)
    print(json.dumps(records, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
