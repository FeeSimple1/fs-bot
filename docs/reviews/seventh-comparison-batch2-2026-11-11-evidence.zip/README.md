# Seventh comparison Batch 2 validation

The repair was tested on parent `8c76446ea746d68f9494bdb1baf2e0f858ad708e`
with Python 3.12.14. `source.json` identifies the tested Python bytes. The
seventh Batch 1 evidence in the repository supplies the paired parent
game records. The seventh audit archive supplies the original lifecycle
witness. `SHA256SUMS` covers the archived files.

Run the verifier from the repaired repository root with its Python
environment active.

```sh
PYTHONPATH=. python /path/to/evidence/verify_results.py /path/to/evidence
```

The validation runs used these commands with a fresh output directory.

```sh
PYTHONHASHSEED=0 python -m pytest -q -n 5 --junitxml=pytest.xml
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out bots-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 41-44 --card-edition second-edition --workers 2 --out bots-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
```

`balance-before.log` and `pytest-before.log` used `baseline-prior.json` in
the repository's baseline path. The final balance and pytest runs used the
reviewed baseline for Batch 2. Both runs used the same seeds and thresholds.
`directed.log` contains the 21 public-path regressions. The same test file
run on the parent reproduces 16 failures and passes five controls.
`audit-before.json` matches the prior audit's lifecycle witness output.

`first-changes.json` records each first changed card and Quarters phase,
including matching starting board and RNG digests, relocations, random
ties, and desertion. To reproduce it, run `trace_quarters_changes.py`
with `trace-parent-input.json` and a fresh parent trace output path on the
parent checkout. Then run the script with `trace-candidate-input.json`, a
fresh output path, and the parent trace path on the repaired checkout. Use
`PYTHONHASHSEED=0 PYTHONPATH=.` for both invocations.
