"""A3.2.3 integration witness: a successful Seize roll calls A6.2.1 Rally.

Directly enters the response to a supplied successful roll. It does not claim
to test selection of Seize, Dispersal or the random trigger itself.
"""
import argparse
import json
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--repo', required=True)
args = parser.parse_args()
sys.path.insert(0, args.repo)

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, place_piece
from fs_bot.engine.execute import _resolve_seize_rally
from fs_bot.map.map_data import get_adjacent
from fs_bot.state.state_schema import build_initial_state, validate_state
from fs_bot.tools.validation_metadata import source_identity

rows = []
for scenario in (rc.SCENARIO_ARIOVISTUS, rc.SCENARIO_GALLIC_WAR):
    for existing in (0, 3):
        state = build_initial_state(scenario, seed=12)
        state['non_player_factions'] = {rc.ROMANS, rc.AEDUI, rc.BELGAE, rc.GERMANS}
        place_piece(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA)
        if existing:
            place_piece(state, rc.CARNUTES, rc.ARVERNI, rc.WARBAND, existing)
        source = rc.MANDUBII
        assert rc.CARNUTES in get_adjacent(source, scenario)
        result = _resolve_seize_rally(state, source, rc.TRIBE_MANDUBII,
                                      {'faction': rc.ARVERNI, 'roll': 1})
        rows.append({'scenario': scenario, 'initial_arverni_warbands': existing,
                     'caller': '_resolve_seize_rally', 'source_region': source,
                     'result': result,
                     'final_carnutes_warbands': count_pieces(state, rc.CARNUTES, rc.ARVERNI, rc.WARBAND),
                     'final_carnutes_allies': count_pieces(state, rc.CARNUTES, rc.ARVERNI, rc.ALLY),
                     'integrity': validate_state(state)})
print(json.dumps({'source': source_identity(), 'cases': rows}, indent=2))
