"""Reassess the retained pre-fix trajectory; do not rerun a game."""
from copy import deepcopy
from pathlib import Path
import gzip
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'fs-bot'
sys.path.insert(0, str(REPO))
from fs_bot.state.serialize import decode
from fs_bot.tools import player_fuzz as fuzz
from fs_bot.tools.validation_metadata import source_identity

path = HERE / 'before-ariovistus17-hash0.json.gz'
capture = json.loads(gzip.decompress(path.read_bytes()))
stored = decode(capture['captured'])
before = source_identity()

def recorded_result(state, decision_func, *, execute):
    state.clear()
    state.update(deepcopy(stored['state']))
    return deepcopy(stored['trajectory'])

fuzz.run_game = recorded_result
result = fuzz.play_game(capture['record']['scenario'], capture['record']['seed'])
assert source_identity() == before
assert capture['record']['findings'] == []
assert len(result['findings']) == 1
assert result['findings'][0][0:2] == ('bot-event-rejected', 'A45')
assert result['digest'] == capture['record']['digest']
assert result['game_completed']
out = {
    'method': 'New play_game acceptance oracle applied to the unchanged recorded terminal state and trajectory; no new game simulation.',
    'capture': path.name,
    'capture_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    'source': before,
    'before_findings': capture['record']['findings'],
    'after_findings': result['findings'],
    'unchanged_digest': result['digest'],
    'game_completed': result['game_completed'],
    'new_full_games': 0,
}
(HERE / 'captured-bot-rejection-proof.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, indent=2))
