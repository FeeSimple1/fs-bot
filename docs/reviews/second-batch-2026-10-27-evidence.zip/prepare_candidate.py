"""Prepare a review-only balance candidate from audited legacy records.

No games are rerun, no repository file is edited, and this does not approve a
baseline refresh or convert the preserved original failed guardrail to a pass.
"""
import argparse
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "fs-bot"
SCENARIOS = ("Pax Gallica?", "Reconquest of Gaul", "The Great Revolt", "Ariovistus", "The Gallic War")
FACTIONS = ("Romans", "Arverni", "Aedui", "Belgae", "Germans")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attempt", default="attempt1")
    args = parser.parse_args()
    run = ROOT / args.attempt
    source = json.loads((run / "source.json").read_text())
    old_bytes = (run / "balance-baseline.json").read_bytes()
    old = json.loads(old_bytes)
    assert old_bytes == (REPO / "fs_bot/tools/balance_baseline.json").read_bytes()
    assert old_bytes == subprocess.check_output(["git", "show", f"{source['commit']}:fs_bot/tools/balance_baseline.json"], cwd=REPO)
    verification = json.loads((run / "results.json").read_text())
    assert verification["pytest_checked"] and verification["pytest"]["exit_code"] == 0
    assert verification["failures"] and all(f.startswith("balance/") for f in verification["failures"])
    rows = [json.loads(line) for line in (run / "bots-legacy/games.jsonl").read_text().splitlines()]
    expected = {f"{s}|{n}" for s in SCENARIOS for n in range(1, 21)}
    actual = [f"{r['scenario']}|{r['seed']}" for r in rows]
    assert len(actual) == len(set(actual)) == 100 and set(actual) == expected == set(old["games"])
    assert all(r["completed"] and r["audit_completed"] and r["game_completed"]
               and not r["errors"] and not r["integrity_findings"]
               and all(d["severity"] == "legal-decline" for d in r["diagnostics"])
               and r["source_sha256"] == source["source_sha256"]
               and r["commit"] == source["commit"] and r["card_edition"] == "legacy" for r in rows)
    candidate = {"games": {f"{r['scenario']}|{r['seed']}": {"winner": r["winner"], "cards": r["cards"]} for r in rows}}
    candidate_bytes = (json.dumps(candidate, indent=2, sort_keys=True) + "\n").encode()
    comparison = []
    for key in sorted(expected):
        before, after = old["games"][key], candidate["games"][key]
        comparison.append({"key": key, "before": before, "candidate": after,
                           "winner_changed": before["winner"] != after["winner"],
                           "cards_changed": before["cards"] != after["cards"],
                           "record_changed": before != after})
    scenarios = {}
    for scenario in SCENARIOS:
        before = Counter(old["games"][f"{scenario}|{seed}"]["winner"] for seed in range(1, 21))
        after = Counter(candidate["games"][f"{scenario}|{seed}"]["winner"] for seed in range(1, 21))
        deltas = {f: Fraction(after[f] - before[f], 20) for f in FACTIONS}
        scenarios[scenario] = {"games": 20, "before_wins": dict(before), "candidate_wins": dict(after),
                               "exact_rate_changes": {f: str(d) for f, d in deltas.items()},
                               "percentage_point_changes": {f: float(d * 100) for f, d in deltas.items()},
                               "original_guardrail_passed": all(abs(d) <= Fraction(3, 20) for d in deltas.values())}
    report = {
        "status": "review-only candidate; repository baseline unchanged; not accepted",
        "source": source, "candidate_games": 100, "exact_keys": sorted(expected),
        "source_records": "bots-legacy/games.jsonl", "new_game_executions": 0,
        "old_baseline_sha256": hashlib.sha256(old_bytes).hexdigest(),
        "candidate_sha256": hashlib.sha256(candidate_bytes).hexdigest(),
        "band_percentage_points": 15, "exact_band": "3/20", "band_changed": False,
        "original_guardrail_passed": False, "original_failures": verification["failures"],
        "preserved_original_report": "results.json", "repository_baseline_replaced": False,
        "changed_records": sum(r["record_changed"] for r in comparison),
        "changed_winners": sum(r["winner_changed"] for r in comparison),
        "changed_card_counts": sum(r["cards_changed"] for r in comparison),
        "comparison": comparison, "scenarios": scenarios,
        "acceptance_requirement": "Review causal rules evidence before authorizing a baseline refresh. A later candidate comparison must remain separate from the preserved original failure."
    }
    with (run / "balance-candidate.json").open("xb") as stream:
        stream.write(candidate_bytes)
    with (run / "balance-candidate-review.json").open("x") as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({k: v for k, v in report.items() if k not in ("exact_keys", "comparison", "scenarios")}, indent=2))


if __name__ == "__main__":
    main()
