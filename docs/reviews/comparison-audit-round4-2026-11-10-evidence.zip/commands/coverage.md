# Fourth comparison audit — Commands and Battle partition

Audited Falling Sky commit `b951908af2b21cc87a7e27d9a5314b3f257d0147`.
No production code, tests, or supplied references changed by this partition.

## Comparator pattern

Read Liberty or Death's `coin-implementation-lessons.md` (boundary defects,
per-space/per-action scope, frozen versus live forces, bot flowchart fidelity,
and cross-faction interaction gaps) and the ordinary command/payment/live
checkpoint path in `lod_ai/commands/battle.py`. These are engineering prompts,
not Falling Sky rule authorities. The comparison led to tracing actual
post-Attack forces into Counterattack and into the non-player Retreat forecast,
where both confirmed groups occur.

## Inspected coverage

- Prior 50-finding progress register and second/third audit inventories,
  current-status history, adopted provisional rulings and the full listing
  of supplied Reference Documents. Prior human Retreat and Roman Legion
  forecast fixes are distinguished from the new NPC decision defects.
- Shared human whole-action validation, Battle/SA Region selection, arbitrary
  Event modifiers, ordinary and interrupted Command execution.
- Raid per-Region grouping, resource theft eligibility, actual flipped cohorts
  and German free Intimidate credits.
- Build per-Region Fort/Ally operation limits, physical Ally identity, Supply
  and Seize exclusions. Entreat selected physical Ally validation, replacement
  restrictions, and dynamic Colony helpers.
- Scout playable endpoints, moved-cohort tracking, physical owners, Reveal
  allocations and total capacity.
- Rampage unique Region/target/count validation and victim ownership, Retreat
  disposition and declared destinations.
- Enlist temporary physical ownership, four-counter expansion budget,
  borrowing scope, and free-command selection restrictions.
- March origin billing, route length, selected physical cohorts, later-origin
  arrivals, multi-group exclusion, drop-offs and Leader-dependent continuation.
- Battle prerequisites, Ambush/Besiege eligibility, attack/Counterattack phases,
  Capability scope and NPC Retreat declaration/disposition.

## Confirmed executable witnesses

`probe_commands.py` contains eight cases, grouped into two repair findings.
All cases enter through durable turn validation and normal `execute_decision`.
The script also records the production NPC declaration directly for diagnosis.
All fixtures start and finish without census or structural errors. They use
`build_initial_state`, legal piece-helper placements, the mandatory permanent Roman Fort in
Provincia, and ordinary available resources; they do not claim to be naturally reached full-game positions.

Run from any checkout of the audited revision:

```sh
PYTHONPATH=/path/to/fs-bot python probe_commands.py > results.json
```

The script freezes current observed defects. Repairs should reverse the defect
assertions to the source-derived expected behavior and retain the legal controls.
`findings.json` supplies exact sources, code locations, boundaries and expected
changes. `results.json` is the final combined output. `results.txt` preserves an
intermediate exploratory output before consolidation and is not another run count.

## Rejected or unpromoted leads

- Ordinary Battle Event-only flags are now reserved for trusted resolution;
  the earlier arbitrary-modifier finding is not recounted.
- Raid input above its Region limit is truncated. This is potentially useful
  interface feedback, but the witnessed execution remains within the legal
  quota, so it is not counted as a new rules defect here.
- Repeated Build Ally operations are blocked by the actual executor's Region
  ledger; repeated Suborn Regions are rejected. No new over-placement claimed.
- A33 unshaded `outnumbered Warbands` compares against attacker mobile troops
  while excluding Leaders and static pieces. The card text provides no further
  definition in the supplied materials. This is an ambiguous lead, not a finding
  and not a proposed gameplay interpretation.
- March origin flipping processes Regions one by one under the printed text.
  No unsupported claim that all origins must flip simultaneously is made.
- Known Circumvallation persistence and the documented NP Aedui subsidy
  approximation are not new audit findings.
- No claim of exhaustive testing of every Enlist/Diviciacus combination,
  every planned-invalid-input shape, or every Capability combination.

## Permanent Fort fixture correction

Independent review noted that bare `build_initial_state` omits the mandatory
Provincia Fort. Every final fixture now explicitly places it with the standard
piece helper before testing, and asserts it remains. All eight final cases
were rerun after the correction and retain the same Battle outcomes. Original
pre-Fort script/output are preserved under `exploratory/` and are superseded,
not additional accepted evidence. The independent expansion rerun uses full
scenario setup and needed no such correction.
