"""Verify complete records, unchanged inputs and exact cross-hash results."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'fs-bot'
prepared = json.loads((HERE / 'prepared-source.json').read_text())
for name, digest in prepared['files'].items():
    assert hashlib.sha256((REPO / name).read_bytes()).hexdigest() == digest, name
protected = json.loads((HERE / 'protected-before.json').read_text())
for name, digest in protected.items():
    assert hashlib.sha256((REPO / name).read_bytes()).hexdigest() == digest, name
suite = ET.parse(HERE / 'after-full.xml').getroot().find('testsuite')
assert int(suite.attrib['tests']) == 6886
assert all(int(suite.attrib[key]) == 0 for key in ('errors', 'failures', 'skipped'))
a, b = [json.loads((HERE / f'after-hash{s}.json').read_text()) for s in (0, 7)]
assert a == b, 'Cross-hash JSON differs'
assert (HERE / 'after-hash0.log').read_bytes() == (HERE / 'after-hash7.log').read_bytes()
assert a['games'] == 200 and a['hard_findings'] == 0 and not a['by_kind']
assert all(r['game_completed'] and not r['findings'] for r in a['records'])
before = json.loads((HERE / 'before-hash0.json').read_text())
changed = [{'before': left, 'after': right}
           for left, right in zip(before['records'], a['records']) if left != right]
(HERE / 'changed-fuzz-cases.json').write_text(json.dumps(changed, indent=2) + '\n')

rows = [json.loads(line) for line in (HERE / 'bots/games.jsonl').read_text().splitlines()]
scenarios = {r['scenario'] for r in rows}
assert len(scenarios) == 5
assert len(rows) == 100 and {(r['scenario'], r['seed']) for r in rows} == {
    (scenario, seed) for scenario in scenarios for seed in range(1, 21)}
for row in rows:
    assert all(row[k] is True for k in ('completed', 'game_completed', 'audit_completed')), row
    assert not row['errors'] and not row['integrity_findings'], row
    assert row['card_edition'] == 'legacy' and row['final_state_sha256']
    assert len(row['final_ranking']) == 4
    assert not row['engine_ranking_output_missing'] and not row['winner_differs_from_highest_margin']
    assert all(d['severity'] == 'legal-decline' for d in row['diagnostics'])
baseline = json.loads((REPO / 'fs_bot/tools/balance_baseline.json').read_text())['games']
rate_changes = []
for scenario in sorted(scenarios):
    old = Counter(baseline[f'{scenario}|{seed}']['winner'] for seed in range(1, 21))
    new = Counter(r['winner'] for r in rows if r['scenario'] == scenario)
    for faction in sorted(set(old) | set(new)):
        rate_changes.append({'scenario': scenario, 'faction': faction,
                             'percentage_point_change': 5 * (new[faction] - old[faction])})
assert all(abs(r['percentage_point_change']) <= 15 for r in rate_changes)
parent_dir = HERE.parent / 'named-event-effects-2026-11-02/matrix-01/bots-legacy'
parent_meta = json.loads((parent_dir / 'metadata.json').read_text())
assert parent_meta['source_sha256'] == before['metadata']['source_sha256']
parent = {(r['scenario'], r['seed']): r for r in map(json.loads, (parent_dir / 'games.jsonl').read_text().splitlines())}
assert len(parent) == 100
parent_diffs = [{'scenario': r['scenario'], 'seed': r['seed'],
                 'before': {k: parent[r['scenario'], r['seed']][k] for k in ('winner', 'cards', 'final_state_sha256')},
                 'after': {k: r[k] for k in ('winner', 'cards', 'final_state_sha256')}}
                for r in rows if any(r[k] != parent[r['scenario'], r['seed']][k]
                                    for k in ('winner', 'cards', 'final_state_sha256'))]
(HERE / 'parent-bots').mkdir(exist_ok=True)
for name in ('metadata.json', 'games.jsonl', 'summary.json'):
    shutil.copyfile(parent_dir / name, HERE / 'parent-bots' / name)
result = {'prepared_source': prepared['source'], 'protected_inputs_unchanged': len(protected),
          'full_tests': {'passed': int(suite.attrib['tests']), 'new_cases': 14, 'python': a['metadata']['python']},
          'mixed_seat': {key: a[key] for key in ('games', 'human_turns', 'event_turns', 'events_ok', 'hard_findings', 'partial', 'batch_digest')},
          'mixed_seat_distinct_cases': 200, 'mixed_seat_executions_including_replay_and_hash_repeat': 800,
          'exact_cross_hash_json_and_stdout_match': True, 'changed_mixed_seat_cases': len(changed),
          'bot_games': 100, 'bot_parent_comparison': {
              'reused_previous_records': True, 'source_sha256': parent_meta['source_sha256'],
              'provenance': 'Prior prepared source over 2edf53e has the exact Python bytes later committed as task-base 3873ff9; original metadata retained.',
              'differences': parent_diffs},
          'baseline': {'unchanged': True, 'passed': True, 'band_percentage_points': 15,
                       'max_change_percentage_points': max(abs(r['percentage_point_change']) for r in rate_changes),
                       'rates': rate_changes},
          'audit_progress': {'closed': 18, 'total': 50, 'open': 32, 'percent': 36, 'additional_original_findings_closed': 0},
          'passed': True}
(HERE / 'acceptance-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'baseline'}, indent=2))
