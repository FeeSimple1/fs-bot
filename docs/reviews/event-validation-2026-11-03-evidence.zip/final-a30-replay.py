"""Bridge exactly two frozen A30 first rows to the final prepared source.

Uses the same encode/decode and execute_decision path as the sealed trace
replays. Does not run games or modify sealed causal-review evidence.
"""
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import sys

evidence = Path(__file__).resolve().parent
worktree = evidence.parent / 'fs-bot'
assert os.environ.get('PYTHONHASHSEED') == '0'
sys.path.insert(0, str(worktree))
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces
from fs_bot.engine.execute import execute_decision
from fs_bot.state.serialize import decode, encode
from fs_bot.tools.validation_metadata import source_identity

manifest_path = evidence / 'final-source-manifest.json'
manifest = json.loads(manifest_path.read_text())


def sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def verify_source():
    files = {str(path.relative_to(worktree)): hashlib.sha256(path.read_bytes()).hexdigest()
             for path in sorted((worktree / 'fs_bot').rglob('*.py'))}
    assert files == manifest['files'], 'Final Python manifest differs from executed source'
    identity = source_identity()
    assert identity['source_sha256'] == manifest['source']['python_sha256'], identity
    assert len(files) == manifest['source']['python_files'] == 417
    return identity


identity_before = verify_source()
sealed = evidence / 'causal-review'
prior_manifest = json.loads((sealed / 'candidate-manifest.json').read_text())
results = []
for scenario, filename in (
        (rc.SCENARIO_ARIOVISTUS, 'first-Ariovistus-18.json'),
        (rc.SCENARIO_GALLIC_WAR, 'first-The-Gallic-War-18.json')):
    path = sealed / filename
    pair = json.loads(path.read_text())
    row, summary = pair['candidate'], pair['summary']
    assert (summary['scenario'], summary['seed']) == (scenario, 18)
    assert (row['kind'], row['card'], row['faction']) == ('execution', 'A30', rc.AEDUI)
    state = decode(row['before'])
    leaders = sum(count_pieces(state, region, rc.ARVERNI, rc.LEADER)
                  for region in state['spaces'])
    assert leaders == 0, 'Captured A30 position unexpectedly contains an Arverni Leader'
    with contextlib.redirect_stdout(io.StringIO()):
        result = execute_decision(state, row['faction'], decode(row['decision']))
    actual_result, actual_state = encode(result), encode(state)
    results.append({
        'scenario': scenario, 'seed': 18, 'card': 'A30', 'faction': rc.AEDUI,
        'input_file': str(path), 'input_file_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'arverni_leaders_in_prestate': leaders,
        'exact_result': actual_result == row['result'],
        'exact_complete_post_state': actual_state == row['after'],
        'exact_rng': actual_state['rng'] == row['after']['rng'],
        'rng_consumed': actual_state['rng'] != row['before']['rng'],
        'actual_result': actual_result, 'expected_result': row['result'],
        'actual_post_state_sha256': sha(actual_state),
        'expected_post_state_sha256': sha(row['after']),
        'actual_rng_sha256': sha(actual_state['rng']),
        'expected_rng_sha256': sha(row['after']['rng']),
        'changed_post_state_keys': sorted(key for key in set(actual_state) | set(row['after'])
                                         if actual_state.get(key) != row['after'].get(key)),
    })
identity_after = verify_source()
assert identity_before == identity_after, 'Executed source identity changed during replays'
passed = all(row['exact_result'] and row['exact_complete_post_state'] and row['exact_rng']
             for row in results)
report = {
    'scope': 'Exactly two captured A30 executions; no full-game reruns.',
    'final_source': manifest['source'], 'verified_identity': identity_after,
    'final_manifest': str(manifest_path),
    'final_manifest_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
    'prior_trace_source': prior_manifest['source'],
    'python': platform.python_version(), 'hash_seed': '0',
    'source_verified_before_and_after': True,
    'exact_replays': sum(row['exact_result'] and row['exact_complete_post_state'] and row['exact_rng']
                         for row in results),
    'passed': passed, 'replays': results,
}
(evidence / 'final-a30-replay.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'exact_replays': report['exact_replays'], 'passed': passed,
                  'final_python_sha256': manifest['source']['python_sha256'],
                  'arverni_leaders_in_prestates': [row['arverni_leaders_in_prestate'] for row in results]}))
raise SystemExit(0 if passed else 1)
