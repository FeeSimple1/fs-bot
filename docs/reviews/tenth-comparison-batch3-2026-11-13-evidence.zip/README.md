# Tenth comparison repair Batch 3 evidence

Batch 3 closes LC10-01. `source.json` identifies the tested patch to parent
`6faed3125b53959bada75eb368947eda7f04d99a`. The audit witness records the
original defect. `test_parent_untagged.py` exercises the existing API on that
revision. The repaired test module adds the two terminal cases for selecting
a specific movement step. Both modules include the later Supply and
prohibited-host controls. The save/resume fixture uses a single Aedui Region
for the Supply request, while UI10-03 tracks multi-Region replay.

The parent records come from Batch 2 and match the parent's Python source
digest. The paired traces wrap the normal public game runner and record the
first affected Quarters in all three legacy games with changed final states.
The verifier checks ranking and integrity, diagnostics, replay, the two
revisions' source digests, and 48 protected source hashes. `SHA256SUMS`
covers every other archive member.

## Reproduce the checks

Use Python 3.12.14 and the development test environment. Run from the
repaired repository root. Set `OUT` to an empty output directory,
`EVIDENCE` to the extracted archive and `PARENT` to a clean checkout of
the parent commit.

```bash
PYTHONHASHSEED=0 python -m pytest -q fs_bot/tests/test_tenth_comparison_quarters.py
PYTHONHASHSEED=987 python -m pytest -q fs_bot/tests/test_tenth_comparison_quarters.py
PYTHONHASHSEED=0 python -m pytest -q -n 4 --junitxml="$OUT/full.xml"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out "$OUT/legacy"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 53-56 --card-edition second-edition --workers 2 --out "$OUT/second-edition"
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 53-56 --card-edition second-edition --out "$OUT/fuzz0.json"
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 53-56 --card-edition second-edition --out "$OUT/fuzz987.json"
PYTHONPATH=. PYTHONHASHSEED=0 python "$EVIDENCE/trace_quarters.py" > "$OUT/trace-repair.json"
PYTHONPATH=. python "$EVIDENCE/verify_results.py"
```

Run the untagged test file and trace in the parent checkout to reproduce the
12 failures, seven passing controls, and three recorded Winter decisions.

```bash
cd "$PARENT"
PYTHONPATH=. PYTHONHASHSEED=0 python -m pytest -q "$EVIDENCE/test_parent_untagged.py"
PYTHONPATH=. PYTHONHASHSEED=0 python "$EVIDENCE/trace_quarters.py" > "$OUT/trace-parent.json"
```
