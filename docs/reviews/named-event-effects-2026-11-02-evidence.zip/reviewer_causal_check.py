"""Independent BE-04 verification of existing traces, not another game run."""
import collections,gzip,hashlib,io,json,pathlib,subprocess,sys,tarfile
root=pathlib.Path('/workspace/scratch/534c265c65f4/fs-bot')
out=root.parent/'named-event-effects-2026-11-02'
p=out/'causal-review'
sys.path.insert(0,str(root))
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces,get_leader_in_region
from fs_bot.board.control import is_controlled_by
from fs_bot.map.map_data import get_adjacent_for_state,get_playable_regions_for_state
from fs_bot.state.serialize import decode
from fs_bot.cards.card_effects import _tribe_region

def read(name): return json.loads((p/name).read_text())
expected=json.loads((out/'source-manifest.json').read_text())
current={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((root/'fs_bot').rglob('*.py'))}
assert current==expected['files']
commit='9e9191bc1c0eb5de13a5d578475d4f85042d2a6b'
archive=subprocess.check_output(['git','archive',commit,'fs_bot'],cwd=root)
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    committed={f.name:hashlib.sha256(tar.extractfile(f).read()).hexdigest() for f in tar if f.isfile() and f.name.endswith('.py')}
assert committed==expected['files']
start=read('candidate-source-verification.json')['source']
end=read('end-verification/candidate-source-verification.json')['source']
identity_changes={k:{'before':start.get(k),'after':end.get(k)} for k in set(start)|set(end) if start.get(k)!=end.get(k)}
assert set(identity_changes)=={'commit'}
assert end['commit']==commit
assert start['source_sha256']==end['source_sha256']==expected['source']['python_sha256']
raw_pairs=json.loads((out/'matrix-01/parent-differences.json').read_text())
manifest={label:{(r['scenario'],r['seed']):r for r in read(f'{label}-manifest.json')['games']} for label in ('parent','candidate')}
assert all(len(v)==16 for v in manifest.values())
summary={(r['scenario'],r['seed']):r for r in read('first-divergences.json')['pairs']}
results=[]
for pair in raw_pairs:
    key=(pair['scenario'],pair['seed'])
    traces={}
    for label in ('parent','candidate'):
        m=manifest[label][key]; path=p/m['file']
        assert hashlib.sha256(path.read_bytes()).hexdigest()==m['sha256']
        data=json.load(gzip.open(path,'rt'))
        assert data['outcome']==pair['before' if label=='parent' else 'after']
        assert len(data['trace'])==m['rows']
        traces[label]=data['trace']
    old,new=traces['parent'],traces['candidate']
    index=next(i for i,(a,b) in enumerate(zip(old,new)) if a!=b)
    a,b=old[index],new[index]
    assert old[:index]==new[:index]
    assert a['before']==b['before']
    assert (a['kind'],a['card'],a['faction'])==(b['kind'],b['card'],b['faction'])
    assert index==summary[key]['trace_index_zero_based']
    before,old_after,new_after=map(decode,(a['before'],a['after'],b['after']))
    card=b['card']; kind=b['kind']; evidence={}
    if kind=='execution' and card==2:
        assert a['decision']==b['decision']
        assert count_pieces(new_after,rc.PROVINCIA,rc.ROMANS,rc.LEGION)-count_pieces(old_after,rc.PROVINCIA,rc.ROMANS,rc.LEGION)==2
        assert sum(old_after['legions_track'].values())-sum(new_after['legions_track'].values())==2
        assert old_after['senate']==new_after['senate']
        evidence={'cause':'Card2 places the two previously missing Legions','new_provincia_legions':count_pieces(new_after,rc.PROVINCIA,rc.ROMANS,rc.LEGION),'old_provincia_legions':count_pieces(old_after,rc.PROVINCIA,rc.ROMANS,rc.LEGION)}
    elif kind=='execution' and card==18:
        changed=[r for r in before['spaces'] if old_after['spaces'][r]!=new_after['spaces'][r]]
        assert len(changed)==1
        r=changed[0]
        assert r in rc.GERMANIA_REGIONS
        assert any(is_controlled_by(before,z,rc.ROMANS) for z in [r,*get_adjacent_for_state(before,r)])
        assert count_pieces(old_after,r,rc.GERMANS)==count_pieces(before,r,rc.GERMANS)>0
        assert count_pieces(new_after,r,rc.GERMANS)==0
        evidence={'cause':'Card18 on Aedui Event now resolves the Romans-owned removal','region':r,'removed_germans':count_pieces(before,r,rc.GERMANS)}
    else:
        assert kind=='decision' and a['decision']['action']=='event' and b['decision']['action']!='event'
        if card==2:
            can_shift=before['senate']['position'] is not None and not(before['senate']['position']==rc.UPROAR and before['senate']['firm'])
            total=sum(before['legions_track'].values())+before['fallen_legions']
            assert not can_shift or total<2
            evidence={'cause':'Card2 unavailable under printed shift/two-Legion prerequisite','senate':before['senate'],'off_map_legions':total}
        elif card in (18,'A18'):
            eligible=[]
            for r in rc.GERMANIA_REGIONS:
                if r not in get_playable_regions_for_state(before): continue
                if card=='A18' and get_leader_in_region(before,r,rc.GERMANS)==rc.ARIOVISTUS_LEADER: continue
                if any(is_controlled_by(before,z,rc.ROMANS) for z in [r,*get_adjacent_for_state(before,r)]):
                    eligible.append({'region':r,'germans':count_pieces(before,r,rc.GERMANS)})
            assert not any(r['germans'] for r in eligible)
            evidence={'cause':'Rhenus Bridge has no effective eligible German target','eligible_regions':eligible}
        else:
            assert card==23
            eligible=[{'city':city,'status':before['tribes'][tribe]['status']} for city,tribe in rc.CITY_TO_TRIBE.items() if tribe in before['tribes'] and _tribe_region(before,tribe) in get_playable_regions_for_state(before) and is_controlled_by(before,_tribe_region(before,tribe),rc.ROMANS)]
            assert not any(before['resources'][rc.ROMANS]<rc.MAX_RESOURCES or e['status']!=rc.MARKER_RAZED for e in eligible)
            evidence={'cause':'Sacking has no effective eligible City','eligible_cities':eligible,'roman_resources':before['resources'][rc.ROMANS]}
    state_index=next(i for i,(x,y) in enumerate(zip(old,new)) if x['after']!=y['after'])
    prior_differences=[{'index':i,'changed_fields':sorted(k for k in set(x)|set(y) if x.get(k)!=y.get(k))}
        for i,(x,y) in enumerate(zip(old[:state_index],new[:state_index])) if x!=y]
    assert all(row['changed_fields']==['decision'] for row in prior_differences)
    if state_index!=index:
        assert key in [('The Gallic War',1),('The Gallic War',8)]
        assert state_index==index+1
    results.append({'scenario':key[0],'seed':key[1],'first_trace_index':index,'card':card,'kind':kind,'faction':b['faction'],'all_earlier_rows_identical':True,'complete_pre_states_equal':True,
        'first_post_state_divergence_index':state_index,
        'pre_state_equal_at_first_post_state_divergence':old[state_index]['before']==new[state_index]['before'],
        'earlier_non_state_differences':prior_differences,**evidence})
# Recheck the one diagnostic sorted-map reconstruction exception without
# rewriting its original failed artifact or running another complete game.
from copy import deepcopy
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.cli.dispatcher import _translate_bot_action
from fs_bot.engine.game_engine import ACTION_EVENT
from fs_bot.engine.execute import execute_decision
from fs_bot.state.serialize import encode
entry=summary[('Reconquest of Gaul',10)]
trace=json.load(gzip.open(p/entry['trace_files']['candidate'],'rt'))['trace']
row=trace[entry['trace_index_zero_based']]
def replay_choice(restore_order):
    state=decode(row['before'])
    if restore_order:
        assert set(state['spaces'])==set(rc.ALL_REGIONS)
        state['spaces']={r:state['spaces'][r] for r in rc.ALL_REGIONS}
    state['current_card_id']=state.get('current_card')
    state['is_second_eligible']=row['position']=='2nd_eligible'
    state['can_play_event']=ACTION_EVENT in row['options']
    ba=dispatch_bot_turn(state,row['faction'])
    return state,{'action':_translate_bot_action(ba,row['options']),'bot_action':ba}
plain_state,plain_result=replay_choice(False)
assert encode(plain_result)!=row['decision']
restored_state,restored_result=replay_choice(True)
assert encode(restored_result)==row['decision'] and encode(restored_state)==row['after']
nextrow=trace[row['index']+1]
restored_state['_card_turn']['actions_taken'][row['faction']]=deepcopy(restored_result)
assert encode(restored_state)==nextrow['before']
execution=execute_decision(restored_state,row['faction'],restored_result)
assert encode(execution)==nextrow['result'] and encode(restored_state)==nextrow['after']
report={'scope':'Existing sixteen changed legacy pairs only; no full games executed by reviewer. Verifies first divergence, not exclusive downstream winner attribution.','python_manifest_files':len(current),'committed_source_equivalent':commit,'python_source_sha256':expected['source']['python_sha256'],'identity_changes_during_diagnostic_run':identity_changes,'trace_file_hashes_verified':32,'paired_outcomes_match_matrix':True,'pairs':results,'cause_counts':dict(collections.Counter(r['cause'] for r in results)),
    'output_only_return_metadata_before_first_state_change':False,
    'sorted_map_exception_independently_reproduced':True,
    'restored_map_order_exact_decision_state_rng_and_following_execution':True}
(out/'reviewer-causal-verification.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='pairs'},sort_keys=True,indent=2))
