"""Twelfth audit public Event witnesses with exact-target controls."""
import argparse
import copy
import json
import sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.repo))
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces, move_piece
from fs_bot.bots.bot_common import should_decline_event
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.cards.card_effects import _ally_tribe, _unally_tribe, _tribe_piece_type
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT, ACTION_COMMAND_SA
from fs_bot.state.setup import setup_scenario
from fs_bot.state.serialize import encode
from fs_bot.state.state_schema import validate_state, check_structural_integrity

EFFECT_FIELDS = ('spaces','tribes','available','resources','senate','legions_track',
                 'fallen_legions','removed_pieces','markers','capabilities','capability_owners',
                 'eligibility','forced_ineligible','stay_eligible')


def integrity(state):
    result = {'census': validate_state(state), 'structure': check_structural_integrity(state)}
    assert result == {'census': [], 'structure': []}, result
    return result


def ready(scenario, faction, card, seed=1, extra_np=()):
    state = setup_scenario(scenario, seed=seed)
    state.update(current_card=card, current_card_id=card, can_play_event=True,
                 non_player_factions={faction, *extra_np})
    integrity(state)
    return state


def effects(state):
    return {key: copy.deepcopy(state.get(key)) for key in EFFECT_FIELDS}


def natural(state, faction):
    before = effects(state)
    pre = integrity(state)
    snapshot = encode(state)
    decline = should_decline_event(state, state['current_card'], faction)
    assert encode(state) == snapshot
    action = dispatch_bot_turn(state, faction)
    assert action['command'] == rc.FIRST_DID_EVENT, action
    result = execute_decision(state, faction, {'action': ACTION_EVENT, 'bot_action': action})
    assert result['executed'] and not result.get('errors'), result
    return {'before_integrity': pre, 'after_integrity': integrity(state), 'declined': decline,
            'action': action, 'result': result,
            'changed_fields': [key for key in EFFECT_FIELDS if before[key] != state.get(key)]}


def explicit(state, faction, params):
    pre = integrity(state)
    result = execute_decision(state, faction, {'action': ACTION_EVENT, 'player_action': {
        'command': rc.FIRST_DID_EVENT,
        'details': {'card_id': state['current_card'], 'text_preference': rc.EVENT_UNSHADED,
                    'event_params': params}}})
    assert result['executed'] and not result.get('errors'), result
    return {'before_integrity': pre, 'after_integrity': integrity(state), 'params': params,
            'result': result}


def only_citadels(state, owners):
    for tribe in state['tribes']:
        if _tribe_piece_type(state, tribe) == rc.CITADEL:
            _unally_tribe(state, tribe)
    for tribe, faction in owners:
        _unally_tribe(state, tribe)
        assert _ally_tribe(state, tribe, faction, citadel=True)
    integrity(state)


sappers = []
for scenario, faction in ((rc.SCENARIO_PAX_GALLICA, rc.ROMANS),
                          *((s, rc.AEDUI) for s in rc.BASE_SCENARIOS)):
    state = ready(scenario, faction, 24)
    only_citadels(state, ((rc.TRIBE_AEDUI, rc.AEDUI), (rc.TRIBE_MANDUBII, rc.BELGAE)))
    control = copy.deepcopy(state)
    before = dict(state['resources'])
    observed = natural(state, faction)
    expected = {**before, rc.BELGAE: max(0, before[rc.BELGAE] - 10)}
    actual = {**before, rc.AEDUI: max(0, before[rc.AEDUI] - 10)}
    assert state['resources'] == actual
    target_control = explicit(control, faction, {'target_faction': rc.BELGAE})
    assert control['resources'] == expected
    sappers.append({'case': 'selects_aedui_over_player_belgae', 'scenario': scenario,
                    'faction': faction, 'before_resources': before, 'observed': observed,
                    'after_resources': dict(state['resources']),
                    'explicit_control': {**target_control, 'resources': dict(control['resources'])}})

for scenario in rc.BASE_SCENARIOS:
    state = ready(scenario, rc.AEDUI, 24, extra_np=(rc.ARVERNI,))
    only_citadels(state, ((rc.TRIBE_ARVERNI, rc.ARVERNI), (rc.TRIBE_MANDUBII, rc.BELGAE)))
    control = copy.deepcopy(state)
    before = dict(state['resources'])
    observed = natural(state, rc.AEDUI)
    assert state['resources'] == {**before, rc.ARVERNI: max(0, before[rc.ARVERNI] - 10)}
    target_control = explicit(control, rc.AEDUI, {'target_faction': rc.BELGAE})
    assert control['resources'] == {**before, rc.BELGAE: max(0, before[rc.BELGAE] - 10)}
    sappers.append({'case': 'targets_nonplayer_arverni', 'scenario': scenario,
                    'faction': rc.AEDUI, 'before_resources': before, 'observed': observed,
                    'after_resources': dict(state['resources']),
                    'explicit_control': {**target_control, 'resources': dict(control['resources'])}})

# The Roman priority's first tier already succeeds when Arverni have a Citadel.
state = ready(rc.SCENARIO_PAX_GALLICA, rc.ROMANS, 24)
only_citadels(state, ((rc.TRIBE_ARVERNI, rc.ARVERNI), (rc.TRIBE_MANDUBII, rc.BELGAE)))
before = dict(state['resources'])
priority_control = natural(state, rc.ROMANS)
assert state['resources'] == {**before, rc.ARVERNI: max(0, before[rc.ARVERNI] - 10)}
priority_control['resources'] = dict(state['resources'])

no_target = []
for faction in (rc.ROMANS, rc.AEDUI):
    state = ready(rc.SCENARIO_PAX_GALLICA, faction, 24)
    only_citadels(state, ())
    fallback = copy.deepcopy(state)
    fallback['can_play_event'] = False
    action = dispatch_bot_turn(fallback, faction)
    assert action['command'] not in (rc.FIRST_DID_EVENT, 'Pass')
    fallback_result = execute_decision(fallback, faction, {'action': ACTION_COMMAND_SA, 'bot_action': action})
    assert fallback_result['executed']
    observed = natural(state, faction)
    assert observed['changed_fields'] == []
    no_target.append({'faction': faction, 'observed': observed,
                      'event_disabled_control': {'action': action, 'result': fallback_result,
                                                 'integrity': integrity(fallback)}})


drought = []
for scenario in (rc.SCENARIO_PAX_GALLICA, *rc.ARIOVISTUS_SCENARIOS):
    for faction in (rc.ROMANS, rc.AEDUI):
        for seed in (1, 7):
            # Morini holds NP Belgae. Carnutes holds a legal player opponent.
            # Roman cases additionally put one expendable Auxilia at Morini,
            # where the printed instruction expressly forbids Roman losses.
            state = ready(scenario, faction, 49, seed, extra_np=(rc.BELGAE,))
            enemy = rc.GERMANS if scenario in rc.ARIOVISTUS_SCENARIOS else rc.ARVERNI
            if scenario in rc.ARIOVISTUS_SCENARIOS:
                move_piece(state, rc.MORINI, rc.CARNUTES, rc.GERMANS, rc.WARBAND, count=1)
                move_piece(state, rc.CARNUTES, rc.ARVERNI_REGION, rc.ARVERNI, rc.WARBAND, count=1)
            else:
                place_piece(state, rc.CARNUTES, enemy, rc.WARBAND, count=1)
            if faction == rc.ROMANS:
                place_piece(state, rc.MORINI, rc.ROMANS, rc.AUXILIA, count=1)
            assert count_pieces(state, rc.CARNUTES, rc.ROMANS) == 0
            assert count_pieces(state, rc.MORINI, enemy) == 0
            assert count_pieces(state, rc.MORINI, rc.BELGAE) > 0
            control = copy.deepcopy(state)
            before_markers = copy.deepcopy(state['markers'])
            before_resources = dict(state['resources'])
            before = {r: {f: count_pieces(state, r, f) for f in rc.FACTIONS}
                      for r in (rc.MORINI, rc.CARNUTES)}
            observed = natural(state, faction)
            assert state['markers'] == {**before_markers, rc.MORINI: {**before_markers.get(rc.MORINI, {}), rc.MARKER_DEVASTATED: True}}
            assert count_pieces(state, rc.MORINI, rc.BELGAE) == before[rc.MORINI][rc.BELGAE] - 1
            assert count_pieces(state, rc.CARNUTES, enemy) == before[rc.CARNUTES][enemy]
            if faction == rc.ROMANS:
                assert count_pieces(state, rc.MORINI, rc.ROMANS) == before[rc.MORINI][rc.ROMANS] - 1
            target_control = explicit(control, faction, {'devastate_region': rc.CARNUTES})
            assert control['markers'] == {**before_markers, rc.CARNUTES: {**before_markers.get(rc.CARNUTES, {}), rc.MARKER_DEVASTATED: True}}
            assert count_pieces(control, rc.CARNUTES, enemy) == before[rc.CARNUTES][enemy] - 1
            assert count_pieces(control, rc.MORINI, rc.BELGAE) == before[rc.MORINI][rc.BELGAE]
            assert count_pieces(control, rc.MORINI, rc.ROMANS) == before[rc.MORINI][rc.ROMANS]
            expected_resources = {f: n // 2 for f, n in before_resources.items()}
            assert state['resources'] == control['resources'] == expected_resources
            drought.append({'scenario': scenario, 'faction': faction, 'seed': seed,
                            'player_enemy': enemy, 'non_player_factions': sorted(state['non_player_factions']),
                            'before_pieces': before, 'before_resources': before_resources,
                            'observed': observed, 'markers': state['markers'],
                            'after_pieces': {r: {f: count_pieces(state,r,f) for f in rc.FACTIONS} for r in before},
                            'resources': dict(state['resources']),
                            'explicit_control': {**target_control, 'markers': control['markers'],
                                'pieces': {r: {f: count_pieces(control,r,f) for f in rc.FACTIONS} for r in before}}})

print(json.dumps({'audited_commit': '1563e41d84f61dfce43ce4008106eca2a1639aed',
    'EV12-01': {'wrong_targets': sappers, 'no_targets': no_target, 'roman_priority_control': priority_control},
    'EV12-02': drought,
    'summary': {'sappers_wrong_targets': len(sappers), 'sappers_empty_events': len(no_target),
                'drought_wrong_regions': len(drought), 'exact_target_controls': len(sappers)+len(drought),
                'roman_priority_controls': 1, 'event_disabled_controls': len(no_target)}}, indent=2, sort_keys=True))
