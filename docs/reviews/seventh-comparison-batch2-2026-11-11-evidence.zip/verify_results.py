"""Verify Batch 2 evidence from the repaired Falling Sky checkout."""

from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
import platform
import re
import sys
from xml.etree import ElementTree
from zipfile import ZipFile

from fs_bot.state.serialize import decode
from fs_bot.tools.balance_smoke import _rates
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


def load(path):
    return json.loads(path.read_bytes())


def key(row):
    return row['scenario'], row['seed'], row['card_edition']


def games(raw):
    rows = [json.loads(line) for line in raw.splitlines()]
    keyed = {key(row): row for row in rows}
    assert len(keyed) == len(rows)
    return keyed


def balance_games(path):
    rows = re.findall(r'^\[(.+) seed=\s*(\d+)\] winner=(.+) \((\d+) cards\)$',
                      path.read_text(), re.MULTILINE)
    assert len(rows) == 100
    return {f'{scenario}|{seed}': dict(winner=winner, cards=int(cards))
            for scenario, seed, winner, cards in rows}


def explain(row, counts):
    old, new = row['prior'], row['current']
    assert (old['card'], old['before'], old['rng_before']) == (
        new['card'], new['before'], new['rng_before'])
    assert old['after'] != new['after'] and len(old['quarters']) == len(new['quarters']) == 1
    before, after = old['quarters'][0], new['quarters'][0]
    assert (before['before'], before['rng_before']) == (after['before'], after['rng_before'])
    assert before['after'] != after['after']
    prior, current = map(decode, (before['result'], after['result']))
    assert not any(prior['gallic_relocations'].values())
    moved = [faction for faction, moves in current['gallic_relocations'].items() if moves]
    assert moved or (after['ties'] and before['rng_after'] != after['rng_after'])
    counts['relocation' if moved else 'tie_only'] += 1
    counts['tied_choice'] += bool(after['ties'])
    counts['desertion_changed'] += prior['gallic_desertion'] != current['gallic_desertion']
    return moved


def main(evidence):
    root = Path(evidence)
    identity = load(root / 'source.json')
    assert source_identity()['source_sha256'] == identity['source_sha256']
    counts, differences = {}, {}
    earlier = Path('docs/reviews/seventh-comparison-batch1-2026-11-11-evidence.zip')
    with ZipFile(earlier) as archive:
        parent_digest = json.loads(archive.read('source.json'))['source_sha256']
        for label, edition, seeds in (('legacy', 'legacy', range(1, 21)),
                                     ('second', 'second-edition', range(41, 45))):
            filename = f'bots-{label}/games.jsonl'
            old = games(archive.read(filename))
            current = games((root / filename).read_bytes())
            assert old.keys() == current.keys() == {
                (scenario, seed, edition) for scenario in SCENARIOS for seed in seeds}
            metadata = load(root / f'bots-{label}/metadata.json')
            assert all(metadata[field] == value for field, value in identity.items())
            assert metadata['hash_seed'] == 0 and metadata['card_edition'] == edition
            for case, row in current.items():
                assert old[case]['source_sha256'] == parent_digest
                assert all(row[field] == identity[field] for field in ('commit', 'source_sha256'))
                assert all(row[field] for field in ('completed', 'game_completed',
                                                   'audit_completed', 'final_state_sha256'))
                assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row)
                assert len(row['final_ranking']) == len(row['engine_final_ranking']) == 4
                assert all(item['severity'] == 'legal-decline' for item in row['diagnostics'])
                if row['final_state_sha256'] != old[case]['final_state_sha256']:
                    differences[case] = (old[case], row)
                else:
                    assert (row['winner'], row['cards']) == (old[case]['winner'], old[case]['cards'])
            counts[label] = dict(games=len(current),
                final_boards_changed=sum(case in differences for case in current),
                winners_changed=sum(r['winner'] != old[k]['winner'] for k, r in current.items()),
                lengths_changed=sum(r['cards'] != old[k]['cards'] for k, r in current.items()),
                interludes=sum(r['interlude_completed'] for r in current.values()))
            if label == 'legacy':
                legacy = current
                prior_legacy = old

    trace = load(root / 'first-changes.json')
    assert trace['source'] == identity
    assert len(trace['games']) == len(differences)
    assert {key(row) for row in trace['games']} == differences.keys()
    causes, movers = Counter(), Counter()
    for row in trace['games']:
        old, current = differences[key(row)]
        assert (row['prior_winner'], row['current_winner']) == (old['winner'], current['winner'])
        movers.update(explain(row, causes))

    fuzz0, fuzz987 = (root / 'fuzz0.json').read_bytes(), (root / 'fuzz987.json').read_bytes()
    assert fuzz0 == fuzz987 and (root / 'fuzz0.log').read_bytes() == (root / 'fuzz987.log').read_bytes()
    fuzz = json.loads(fuzz0)
    assert fuzz['games'] == len(fuzz['records']) == 20 and fuzz['hard_findings'] == 0
    assert {key(r) for r in fuzz['records']} == {
        (scenario, seed, 'second-edition') for scenario in SCENARIOS for seed in range(41, 45)}
    assert all(r['game_completed'] and not r['findings'] for r in fuzz['records'])
    assert all(fuzz['metadata'][field] == value for field, value in identity.items())

    before = load(root / 'baseline-prior.json')['games']
    refreshed = load(Path('fs_bot/tools/balance_baseline.json'))['games']
    assert 'FAIL: a faction win rate moved beyond the band.' in (root / 'balance-before.log').read_text()
    assert 'OK: balance within band.' in (root / 'balance.log').read_text()
    assert balance_games(root / 'balance-before.log') == balance_games(root / 'balance.log') == refreshed
    assert refreshed == {f'{s}|{seed}': dict(winner=row['winner'], cards=row['cards'])
                         for (s, seed, _), row in legacy.items()}
    assert refreshed.keys() == before.keys()
    assert all(before[f'{s}|{seed}']['winner'] == r['winner']
               for (s, seed, _), r in prior_legacy.items())
    updated = {k for k in refreshed if refreshed[k] != before[k]}
    assert updated <= {f'{s}|{seed}' for s, seed, edition in differences if edition == 'legacy'}
    shifts = {}
    for scenario in SCENARIOS:
        rates_before, rates_after = _rates(before, scenario), _rates(refreshed, scenario)
        for faction, rate in rates_before.items():
            shift = rates_after[faction] - rate
            if abs(shift) > Fraction(15, 100):
                shifts[f'{scenario}|{faction}'] = int(shift * 100)
    assert shifts

    suites = list(ElementTree.parse(root / 'pytest.xml').getroot().iter('testsuite'))
    tests = sum(int(s.attrib['tests']) for s in suites)
    assert tests == 10032 and not any(int(s.attrib.get(k, 0)) for s in suites
                                    for k in ('errors', 'failures', 'skipped'))
    assert '1 failed, 10031 passed' in (root / 'pytest-before.log').read_text()
    assert 'test_bot_balance_canary' in (root / 'pytest-before.log').read_text()
    assert '21 passed' in (root / 'directed.log').read_text()
    assert '16 failed, 5 passed' in (root / 'parent-regressions.log').read_text()
    audit = Path('docs/reviews/comparison-audit-round7-2026-11-11-evidence.zip')
    with ZipFile(audit) as archive:
        assert (root / 'audit-before.json').read_bytes() == archive.read('lifecycle/probe_lifecycle-output.json')

    summary = dict(source=identity, python=platform.python_version(),
        full_tests=tests, directed_tests=21, parent_defect_reproductions=16,
        paired_outcomes=counts, first_divergence_causes=dict(causes), first_movers=dict(movers),
        mixed_player={k: fuzz[k] for k in ('games', 'human_turns', 'event_turns',
            'events_ok', 'partial', 'hard_findings', 'batch_digest')},
        balance=dict(games=100, band=0.15, records_updated=len(updated),
            winners_changed=sum(refreshed[k]['winner'] != before[k]['winner'] for k in updated),
            lengths_changed=sum(refreshed[k]['cards'] != before[k]['cards'] for k in updated),
            prior_baseline_out_of_band_points=shifts))
    (root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main(sys.argv[1])
