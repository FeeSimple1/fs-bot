from pathlib import Path
import hashlib,json,zipfile
out=Path(__file__).resolve().parent
repo=out.parent/'fs-bot'
selected=[]
for p in sorted(out.rglob('*')):
 if not p.is_file() or p.name.endswith('.tmp'):continue
 rel=p.relative_to(out)
 if rel.name=='evidence-index.json':continue
 if len(rel.parts)>1 and rel.parts[0] in {'parent-bots','bots-legacy','bots-original','bots-second-edition','causal-review'}:
  selected.append(p)
 elif len(rel.parts)==1 and (p.suffix in {'.log','.txt','.xml','.json'} or p.name.endswith('handoff.md') or p.name in {'integration_checks.py','package_evidence.py','evidence-readme.md'}):
  selected.append(p)
index={str(p.relative_to(out)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in selected}
manifest=out/'evidence-index.json';manifest.write_text(json.dumps(index,indent=2)+'\n')
archive=repo/'docs/reviews/human-event-grants-2026-11-02-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in [*selected,manifest]:z.write(p,p.relative_to(out))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,info in index.items():assert hashlib.sha256(z.read(name)).hexdigest()==info['sha256']
result={'path':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'entries':len(index)+1,'crc_and_manifest_verified':True}
p=repo/'docs/reviews/human-event-grants-2026-11-02-results.json';data=json.loads(p.read_text());data['evidence_archive']=result;p.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(result,indent=2))
