"""Capture an unchanged fuzz game's final state/trajectory for a bounded diff."""
import argparse
import gzip
import json
import os
from pathlib import Path
import sys

REPO = Path(__file__).resolve().parent.parent / 'fs-bot'
sys.path.insert(0, str(REPO))
from fs_bot.state.serialize import encode
from fs_bot.tools import player_fuzz
from fs_bot.tools.validation_metadata import source_identity

parser = argparse.ArgumentParser()
parser.add_argument('scenario')
parser.add_argument('seed', type=int)
parser.add_argument('output')
args = parser.parse_args()
identity = source_identity()
digest = player_fuzz._digest
captures = []

def capture(state, trajectory):
    result = digest(state, trajectory)
    captures.append(encode({'state': {k: v for k, v in state.items()
                                     if k != 'decision_agent'},
                            'trajectory': trajectory}))
    return result

player_fuzz._digest = capture
record = player_fuzz.play_game(args.scenario, args.seed)
assert len(captures) == 1
assert source_identity() == identity, 'Source changed during diagnostic run'
with gzip.open(args.output, 'wt', encoding='utf-8') as stream:
    json.dump({'source': identity, 'hash_seed': os.environ.get('PYTHONHASHSEED'),
               'record': record, 'captured': captures[0]}, stream)
print(json.dumps(record, sort_keys=True))
