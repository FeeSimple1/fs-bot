from pathlib import Path
import json
E=Path(__file__).resolve().parent;R=E.parent/'fs-bot'
a=json.loads((E/'acceptance-results.json').read_text());z=json.loads((E/'archive-check.json').read_text())
assert a['accepted']
p=R/'docs/current-status.md';s=p.read_text();needle='## Follow-up repairs\n'
text='''
### 3 November Litaviccus follow-up — PR-12 and full participation

The [Litaviccus report](reviews/litaviccus-targeting-2026-11-03.md) implements
owner-adopted PR-12: the Belgic bot chooses the Battle maximizing predicted
Legion Losses, accounting for actual NPC Roman Retreat or a human Roman's
safer legal standing/Retreat response. Zero-Loss or unsafe choices produce
the printed No Belgae fallback. The ruling remains provisional.

The same repair includes all Aedui pieces through the Battle, including
Counterattack and Reveal, while retaining physical ownership and native
Leader identity. It preserves City/Remi Allies across owners and uses the
actual Ambush timing and full requested Loss totals for forecasts. Human
choices, physical board inspection and durable save/replay remain supported.

Validation on the exact source: **7,427 tests passed**, with all 80 added
cases also passing on Python 3.12; 150 audited bot games, 25 cross-hash bot
repeats, 220 mixed-player cases/880 executions, and 20 strict-census
executions. Seven bot records changed, including two winners. All seven
first differences were traced to Litaviccus on identical preceding boards
and RNG; 14 paired trace games reproduce the matrix records. The existing
balance baseline passes unchanged, with maximum drift of 10 percentage
points inside its existing 15-point limit.

This follow-up sits outside the original audit denominator: **20/50 remain
closed (40%); 30 remain open.** There are now two unadopted source questions,
twelve provisional rulings and 34 separately unverified inventory rows.
'''
assert needle in s;s=s.replace(needle,needle+text,1);p.write_text(s)
p=R/'docs/reviews/litaviccus-targeting-2026-11-03.md';s=p.read_text();old='''Final implementation details, source identity and measured verification will
be added after the source freeze and integrated checks. The exact parent
suite and game records are reusable only after byte verification. Changed
outcomes require paired causal review; a completed game alone is not an
acceptance result. Protected references, canonical labels and the existing
balance threshold remain unchanged.
'''
new='''The accepted source is 457 Python files, SHA-256
`90a57ffbce8c94a9a4dc2690b15c5cce3bfa45e6b7f2e0b4af367ca883efeb06`,
prepared over parent `4f33e09347d809846d61e8cc25ebf711100372fc`.
All Python files remained byte-identical through the full suite and game
matrix. All 49 protected inputs (47 references, canonical constants and the
balance baseline) are unchanged.

| Check | Measured result |
|---|---|
| Full suite, Python 3.10.22 | 7,427 passed, zero failures/errors/skips |
| New cases, Python 3.12.14 | All 80 passed |
| Independent rules suite | 18 passed; no remaining blocker |
| Bot matrix | 150 completed/audited games across all five scenarios and three card profiles |
| Bot hash-seed repeat | 25 additional executions; recorded gameplay fields match |
| Mixed human/bot seats | 220 distinct cases, replayed and repeated under two hash seeds: 880 executions, zero hard findings or partial plans |
| Strict census | 20 executions, no errors; 100 legal-decline occurrences per hash seed |
| Cross-hash mixed/census evidence | Complete JSON and stdout match for the paired runs |
| Before/after records | 143 unchanged and seven changed in gameplay fields, including two changed winners |
| Paired diagnostic games | 14 executions reproduce all seven changed pairs |
| Balance guardrail | Unchanged baseline and 15-point limit; maximum observed drift 10 percentage points |

Bot seeds: legacy 1–20 per scenario; original and second-edition 201–205.
Mixed seats: legacy 1–40 and explicit editions 201–202, each at Python hash
seeds 0 and 7 with replay. Census: seeds 201–202 at hashes 0 and 7. Diagnostic
trace games and hash repeats are not additional independent outcome samples.
All 60 expansion-scenario comparison records are unchanged in this sample.

The parent 7,347-test suite, 14 successful CI checks and 150 bot records are
reused after exact-source verification. Their original labels are preserved;
the accepted source bytes match the subsequently committed parent. Earlier
failed development attempts are retained. Parent tests distinguish existing
behavioral failures from tests that fail merely because the new forecast API
is absent. Candidate refinements include a before/after Caesar-prefire
witness and a City/Remi priority regression; these are not inflated into
extra historical product bugs.

### Outcome changes reviewed

Each changed game first diverges at numeric 45 after the preceding physical
board and RNG agree. The root and independent review examine the actual
positions and resulting piece changes, not only matching run totals.

| Profile/scenario/seed | First difference supported by the source |
|---|---|
| Legacy Great Revolt 2 | Counterattack removes the participating Aedui Scouted Warband in Provincia. |
| Legacy Great Revolt 13 | The only candidate cannot inflict a Legion Loss, so the Belgae follow No Belgae and Rally. Final winner changes from Arverni to Belgae. |
| Legacy Great Revolt 16 | Counterattack removes two participating Aedui Revealed Warbands in Arverni. Final winner changes from Romans to Aedui. |
| Original and second-edition Pax Gallica 202 | One Aedui Warband cannot cause a Legion Loss against the fortified Romans; No Belgae replaces the Event. Romans still win, at card 54 rather than 42. |
| Original and second-edition Great Revolt 202 | All nine surviving Aedui Warbands Reveal after their Ambush in Sequani. |

These traces explain the first changed mechanism and reproduce final records;
they do not certify every subsequent decision. Bounded seed samples do not
establish human balance or exhaustive rules correctness. The conservative
stance forecast retains default casualty priorities. Real human responses,
dice and later play can differ from the prediction.

No save schema changes. Continuing an older save uses corrected mechanics;
exact replay of old response logs across versions is not promised. Current
revision save/load/resume and replay include a real human Counterattack
choice removing the selected physical Aedui casualty.

## Progress and evidence

This separately discovered follow-up does not close another original audit
finding: **20/50 are closed (40%), with 30 open**. Two source questions still
lack adopted policies; PR-12 brings the provisional register to twelve.

- [Acceptance results](litaviccus-targeting-2026-11-03-results.json)
- [Evidence archive](litaviccus-targeting-2026-11-03-evidence.zip)

'''
new+=f"Archive: {z['bytes']:,} bytes, {z['indexed_files']} indexed files; SHA-256\n`{z['sha256']}`. Member sizes/hashes and ZIP integrity were verified.\n"
assert old in s;s=s.replace(old,new);p.write_text(s)
(R/'docs/reviews/litaviccus-targeting-2026-11-03-results.json').write_text(json.dumps(a,indent=2)+'\n')
