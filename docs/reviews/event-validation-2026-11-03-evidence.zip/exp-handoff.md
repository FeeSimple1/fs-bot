# EXP-09 integration handoff

Frozen patch: `exp-ready.patch`, against `8db858b14cd13856059d42db1ad3931e523b5ed4`.
SHA256: `dee4b90b92461fc8795e4c63853320163aea63aaa553f719b142f4d3c0de537d`.
Worktree: `../fs-expansion-event-validation`; branch `repair/expansion-event-validation-2026-11-03`.
Fifteen `fs_bot` files staged; no local commit, protected-file edits, or projectwide documentation changes. Root owns integrated validation, documentation, baseline review, and commit.

## Repaired contracts

The namespaced `fs_bot.cards.expansion_validation` module provides `supported`, `region_options`, `next_choice`, detached `preview`, `validate_response`, `default_params`, `derive_params`, `np_available`, and `execute`. Handler, deriver, free-action validation, schema, and CLI dispatch hooks cover only these five sides:

| Side | Typed parameters | Printed effect and authority |
|---|---|---|
| A29U | `faction`; `placements[{region,piece_type,faction,count,tribe}]` | Executor chooses one Roman/Gallic beneficiary; that beneficiary selects up to two own Allies and five own Warbands or three Auxilia, as possible, among Regions with Settlements. Tribe is required only for an Ally. |
| A30U | `region` | One Region within one of Sequani; remove all its Arverni, including exact troop visibility, Allied Tribes/Citadels, and Leader. A legal empty selected Region remains permitted. |
| A36S | `placements[{region,piece_type,count}]`; `ally_removals[{tribe}]` | Germans choose both components: two Settlements and four Warbands, then any two Allies, as possible, within one of Sugambri. One Settlement per Region. |
| A43U | `replacements[{region,from_type,to_faction,tribe or piece_state}]` | Executor selects two Arverni Allies and two Warbands, as possible, within one of Bibracte. Each counterpart may be Roman or Aedui. Exact Tribe/visibility required; unavailable/stacking-illegal counterpart still removes its source. |
| A45U | `placements[{tribe,faction}]` | Up to three non-German Allies in Celtica within one of an Intimidated marker, including that marker's Region. Zero placements is legal. |

Counts are positive integers, structures have count one, duplicate Tribe targets and wrong-side/unknown fields reject. Fixed-number components cannot omit remaining possible pieces. Availability is evaluated after authored timing windows; normal stacking and legal shortage effects remain intact. Existing entry `timing_actions` and tail `stage_timing_actions` are supported. Detached previews retain board/RNG purity and original executor voluntary-removal authority, including without an existing outer action scope.

For a foreign A29 beneficiary the executor supplies only `faction`; a foreign A36 executor supplies `{}`. Live follow-up requests have `request_type="expansion_event_choices"`, the card ID, and `acting_faction` equal to the named owner. Responses supply the owner's parameters or explicit `{"use_default":true}`. Missing durable responses remain pending; raw callback default behavior is preserved. Ariovistus game-run Arverni choices are automatic. Current-board CLI menus expose only legal next choices, preserve timing actions, and support `board`/`b`.

## Source readings

Sources are local `Reference Documents/Ariovistus/A Card Reference` (A29, A30, A36, A43, A45), `Chapter 5` §§5.1, 5.1.1, 5.1.3, `Chapter 8` §§8.2.3, 8.3.1, 8.3.4, 8.4.1, and the expansion faction Event instructions. No new provisional ruling was introduced.

- A29's “up to” modifies its two Allies; the separate five-Warband/three-Auxilia phrase is fixed as possible. A35U, A51U, and base19U parallel wording supports that reading. Roman NPC Harudes separately requires all three Auxilia; human shortage legality is broader.
- A36's named grammatical subject, Germans, governs both placement and removal choices.
- A43's human recipient choice is followed by §5.1.1 removal fallback. NPC self-benefit/maximization policy considers feasible alternative recipients: decline when maximizing replacement requires benefiting the other faction; permit removal where neither can replace. This does not force a human to switch recipient. The Bibracte stacking override belongs to the shaded side only.
- NPC defaults use own-benefit/structure/City-or-Remi/target-faction/visibility priorities and seeded equal ties. They do not restrict human legal menus.

## Validation and fixture provenance

- **53 new cases:** 39 mechanics/validation/durable/timing-authority cases and 14 CLI cases.
- `exp-focused-final.log`: **245 passed** on final staged sources, including card effects, schema, free-action sentinels, CLI free actions, human plan, and A37 regressions.
- `exp-full-01.log`: first full run **6,599 passed, three failed**. Two failures were seed-3 whole-game tests no longer reaching the same A37 decision after earlier corrected Event behavior. The third was the unchanged balance canary: four expansion winners changed, with Ariovistus Belgae -67 percentage points and Gallic War Romans +67 exceeding its ±40-point band. Protected baseline was not changed. Root is reviewing the combined matrix and causal differences.
- A37 tests now replay exact parent pre-`_maybe_execute` states/decisions in `fs_bot/tests/fixtures/a37_before_exp09/{ariovistus-3,the-gallic-war-3}.json.gz`. `exp-capture-a37.py` captured them from untouched `fs-base-event-before` at `8db858b`. Each embeds commit/scenario/seed/card/faction provenance; gzip metadata uses `mtime=0`. Tests execute the real engine action and assert Event success, new Aedui Ally placement, `declined_no_effect` movement, legal-decline census severity, and absence of “no adjacent group to move”. The independent reviewer regenerated both parent runs and verified exact encoded state/decision equality.
- Earlier failed focused attempts remain preserved in the evidence directory. Their outdated old-A29 assertions and test fixture mistakes were corrected; final focused runs pass. `git diff --cached --check` passed.
- Independent reviewer cleared the final scoped implementation, direct-handler authority fix, and A37 fixture provenance. Root subsequently reported all three patches combined and 201 integrated focused tests passing; its integrated matrix/full-suite evidence supersedes this standalone handoff when complete.

## Integration boundaries

Shared generic explicit `event_params` object validation belongs to the base Event repair. Shared durable invalid-human-Event rejection belongs to the German Allegiances repair. The expansion work does not duplicate either. EXP-08/EXP-11 remain outside scope; A29 shaded cohort Raid and A45 shaded Intimidate are unchanged. No further expansion code edits are planned unless root reports an integrated defect.
