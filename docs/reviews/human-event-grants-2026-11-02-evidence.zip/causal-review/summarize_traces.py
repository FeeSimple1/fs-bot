"""Compare the six named trace pairs and write their first-divergence evidence."""
import gzip
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
expected = json.loads((root.parent / 'baseline-differences.json').read_text())
rows = []
manifest = {'parent': [], 'candidate': []}
def sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()
for case in expected:
    scenario, seed = case['scenario'], case['seed']
    filename = scenario.replace(' ', '-')
    pair = {}
    for label in ('parent', 'candidate'):
        path = root / f'{label}-{filename}-{seed}.json.gz'
        with gzip.open(path, 'rt') as handle:
            pair[label] = json.load(handle)
        record = pair[label]
        assert record['outcome'] == case['before' if label == 'parent' else 'after']
        manifest[label].append({'file': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'scenario': scenario, 'seed': seed, 'outcome': record['outcome'], 'rows': len(record['trace'])})
    parent, candidate = pair['parent'], pair['candidate']
    first = next(i for i,(a,b) in enumerate(zip(parent['trace'], candidate['trace'])) if a != b)
    a,b = parent['trace'][first], candidate['trace'][first]
    assert a['kind'] == b['kind'] == 'execution'
    assert a['before'] == b['before'] and a['decision'] == b['decision']
    assert all(x==y for x,y in zip(parent['trace'][:first], candidate['trace'][:first]))
    row = {'scenario': scenario, 'seed': seed, 'before_outcome': parent['outcome'],
        'after_outcome': candidate['outcome'], 'trace_index_zero_based': first,
        'played_card_count_at_execution': a['card_index'], 'card': a['card'], 'actor': a['faction'],
        'all_earlier_trace_rows_identical': True, 'same_pre_execution_state_and_rng': True,
        'same_declared_decision': True,
        'post_execution_changed_state_keys': sorted(k for k in a['after'] if a['after'][k] != b['after'][k]),
        'changed_regions': sorted(r for r in a['after']['spaces'] if a['after']['spaces'][r] != b['after']['spaces'][r]),
        'rng': {'before_equal': a['before']['rng']==b['before']['rng'],
                'after_equal': a['after']['rng']==b['after']['rng'],
                'parent_consumed_rng': a['before']['rng']!=a['after']['rng'],
                'candidate_consumed_rng': b['before']['rng']!=b['after']['rng'],
                'before_sha256': sha(a['before']['rng']),
                'parent_after_sha256': sha(a['after']['rng']),
                'candidate_after_sha256': sha(b['after']['rng'])},
        'parent_result': a['result'], 'candidate_result': b['result']}
    if a['card'] == 'A58':
        row['cause'] = 'Corrected A58 execution: Roman NP flowchart Battle conditions and printed no-enemy-Rally exception.'
        row['detail'] = 'Parent attacks Belgae at Atrebates with one Auxilia, losing it, then rolls 1 for Arverni and 2 for Belgae on Dispersal; enemy free Rallies place three Arverni Allies and Warbands. Candidate Roman flowchart selects no Battle, preserves the Auxilia, and Seizes for the same 8 Resources/one Dispersal without any Rally rolls. Candidate consumes no RNG in this Event; the RNG divergence starts with the corrected omission of forbidden enemy Rallies.'
        row['sources'] = ['Reference Documents/Ariovistus/A Card Reference: A58', 'Reference Documents/Chapter 8: 8.2.3, 8.8.1', 'Reference Documents/Chapter 5: 5.1.1']
    else:
        march = b['result']['free_actions'][0]
        row['cause'] = 'Corrected A19 shaded application for a non-German Event executor.'
        row['detail'] = (f"Parent Belgae Event does not move Romans; candidate carries out the compulsory whole Roman March {march['source']} → {march['dest']} with {march['moved']['legions']} Legions, {march['moved']['auxilia']} Auxilia, and Caesar. German-only no-Fort/outnumber instructions do not apply to Belgae. Neither execution consumes RNG, so this first divergence is a deterministic board correction, not an RNG shift.")
        row['sources'] = ['Reference Documents/Ariovistus/A Card Reference: A19 shaded', 'Reference Documents/Chapter 5: 5.1, 5.1.3', 'Reference Documents/Ariovistus/german_bot_event_instructions_ariovistus.txt: Gaius Valerius Procillus, Parley (German NP only)']
    row['classification'] = 'source_supported_correction_no_unintended_first_divergence_found'
    rows.append(row)
for label in manifest:
    source = pair[label]['source']
    (root / f'{label}-manifest.json').write_text(json.dumps({'source': source, 'games': manifest[label]}, indent=2) + '\n')
report = {'scope': 'Only the six outcome-changing scenario/seed pairs; first actual execution divergence, not exhaustive downstream attribution.',
          'method': 'Actual run_game runner with the unchanged balance_smoke decision callback. Read-only wrappers capture live decisions/executions, not speculative previews. Legacy edition, same seed, PYTHONHASHSEED=0.',
          'source': {'parent': pair['parent']['source'], 'candidate': pair['candidate']['source']},
          'interruption': {'preserved': 'parent-The-Gallic-War-17.interrupted.json.gz',
              'retry_log': 'parent17-retry.log', 'rerun': 'Parent The Gallic War seed 17 only; all six final files parse and reproduce their expected outcomes.'},
          'pairs': rows, 'blocker': None}
(root / 'causal-summary.json').write_text(json.dumps(report, indent=2) + '\n')
lines = ['# Bounded paired outcome review', '',
'Parent `d3241e7` versus candidate `13e9637`, legacy edition, `PYTHONHASHSEED=0`. All twelve traced outcomes match the supplied before/after records. Every pair has identical earlier trace rows, declared decisions, and pre-execution board/RNG. No unexplained first divergence or blocker was found.', '',
'| Scenario | Seed | First differing execution | Concrete change | RNG at that execution |',
'|---|---:|---|---|---|']
for r in rows:
    effect = ('Flowchart omits the unsafe Auxilia attack; forbidden enemy Rally rolls and placements disappear.' if r['card']=='A58' else
        r['candidate_result']['free_actions'][0]['source'] + ' → ' + r['candidate_result']['free_actions'][0]['dest'] + ' compulsory whole Roman March now occurs.')
    rng = 'Same before; parent advances, candidate does not.' if r['card']=='A58' else 'Same before and after; neither advances.'
    lines.append(f"| {r['scenario']} | {r['seed']} | Card count {r['played_card_count_at_execution']}, {r['card']}, {r['actor']} | {effect} | {rng} |")
lines += ['',
'A58 explicitly grants no enemy Rally. The parent rolled Arverni 1 and Belgae 2 after dispersing Atrebates, placing three Arverni Allies plus Warbands and a Belgic Rally. Candidate correctly omits those rolls. Both versions Seize for 8 Resources and one Dispersal. The separate Battle change follows §8.2.3’s requirement to use Roman flowchart conditions (§8.8.1); the old heuristic attacked with one Auxilia and lost it.', '',
'A19 shaded orders a whole Roman March to an adjacent Region containing Germans. The parent skipped this for the Belgic executor. At seed 4 the corrected move is 6 Legions, 8 Auxilia and Caesar from Provincia to Cisalpina; at seed 17 it is 8 Legions, 11 Auxilia and Caesar from Morini to Sugambri. The special no-Fort/outnumber instruction is printed only for NP Germans, not Belgae. These changes are deterministic and consume no RNG.', '',
'No A20 effect is the first divergence in these six pairs. This review establishes the initial causal change, not a decomposition of every later winner/length difference. It does not refresh the baseline, tune policies, or constitute a new balance study.', '',
'## Reproducibility and interruption', '',
'`trace_games.py` runs the real engine with live-only snapshot wrappers; `summarize_traces.py` verifies the outcomes and equal prefixes, then regenerates JSON/Markdown. Twelve gzip traces, complete parent/candidate manifests, source byte digests and RNG hashes are retained. `causal-summary.json` includes exact first differing execution results.', '',
'The original parent Gallic War seed 17 capture was interrupted while writing. Its corrupt output is preserved as `parent-The-Gallic-War-17.interrupted.json.gz`; the single-game rerun is recorded in `parent17-retry.log`. The valid replacement reproduces Belgae winning after 105 cards. The trace script now writes to a temporary file before renaming, preventing partial files from looking complete.', '',
'Commands (use the shared venv Python; substitute absolute checkouts/evidence paths):', '',
'```sh',
'PYTHONHASHSEED=0 python trace_games.py --worktree /path/to/fs-human-grants-parent --label parent --out /path/to/evidence/causal-review',
'PYTHONHASHSEED=0 python trace_games.py --worktree /path/to/fs-bot --label candidate --out /path/to/evidence/causal-review',
'PYTHONHASHSEED=0 python trace_games.py --worktree /path/to/fs-human-grants-parent --label parent --scenario "The Gallic War" --seed 17 --out /path/to/evidence/causal-review',
'python summarize_traces.py', '```', '']
(root / 'causal-summary.md').write_text('\n'.join(lines))
print(json.dumps({'pairs': len(rows), 'source_cards': sorted({r['card'] for r in rows}), 'all_prefixes_equal': True, 'blocker': None}))
