"""Replay captured first decisions/executions only; record live RNG draws."""
import argparse
import contextlib
import hashlib
import io
import json
from pathlib import Path
import random
import sys

ap=argparse.ArgumentParser()
ap.add_argument('--worktree',required=True)
ap.add_argument('--label',choices=('parent','candidate'),required=True)
args=ap.parse_args()
root=Path(__file__).resolve().parent
sys.path.insert(0,args.worktree)
from fs_bot.engine import execute
from fs_bot.engine.game_engine import ACTION_EVENT
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.cli.dispatcher import _translate_bot_action
from fs_bot.state.serialize import decode,encode
from fs_bot.tools.validation_metadata import source_identity
manifest=json.loads((root/f'{args.label}-manifest.json').read_text())
assert source_identity()['source_sha256']==manifest['source']['source_sha256']
report=json.loads((root/'first-divergences.json').read_text())
original_randint=random.Random.randint
original_choice=random.Random.choice
results=[]

def sha(rng):
    return hashlib.sha256(json.dumps(encode(rng),sort_keys=True).encode()).hexdigest()

for summary in report['pairs']:
    pair=json.loads((root/summary['first_rows_file']).read_text())
    row=pair[args.label]
    state=decode(row['before'])
    live_rng=state['rng']
    draws=[]
    def randint(rng,a,b):
        before=sha(rng) if rng is live_rng else None
        value=original_randint(rng,a,b)
        if rng is live_rng:
            draws.append({'method':'randint','range':[a,b],'selected':value,
                          'before_sha256':before,'after_sha256':sha(rng)})
        return value
    def choice(rng,choices):
        before=sha(rng) if rng is live_rng else None
        value=original_choice(rng,choices)
        if rng is live_rng:
            draws.append({'method':'choice','options':encode(list(choices)),'selected':encode(value),
                          'before_sha256':before,'after_sha256':sha(rng)})
        return value
    random.Random.randint=randint
    random.Random.choice=choice
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            if row['kind']=='execution':
                result=execute.execute_decision(state,row['faction'],decode(row['decision']))
                expected_result=row['result']
            else:
                state['current_card_id']=state.get('current_card')
                state['is_second_eligible']=row['position']=='2nd_eligible'
                state['can_play_event']=ACTION_EVENT in row['options']
                ba=dispatch_bot_turn(state,row['faction'])
                result={'action':_translate_bot_action(ba,row['options']),'bot_action':ba}
                expected_result=row['decision']
    finally:
        random.Random.randint=original_randint
        random.Random.choice=original_choice
    exact_result=encode(result)==expected_result
    exact_state=encode(state)==row['after']
    result_record={'scenario':summary['scenario'],'seed':summary['seed'],'kind':row['kind'],
                   'card':row['card'],'faction':row['faction'],'exact_replay':exact_result and exact_state,
                   'exact_result':exact_result,'exact_state':exact_state,'live_rng_draws':draws}
    if not exact_result or not exact_state:
        result_record.update(expected_result=expected_result, actual_result=encode(result),
                             changed_poststate_keys=sorted(k for k in set(state)|set(row['after']) if encode(state.get(k))!=row['after'].get(k)))
    results.append(result_record)
assert source_identity()['source_sha256']==manifest['source']['source_sha256']
(root/f'{args.label}-first-row-replays.json').write_text(json.dumps({'source':manifest['source'],'replays':results},indent=2)+'\n')
failed=[r for r in results if not r['exact_replay']]
print(json.dumps({'label':args.label,'exact_replays':len(results)-len(failed), 'failed_replays':[{k:r[k] for k in ('scenario','seed','card','faction','exact_result','exact_state')} for r in failed]}))
raise SystemExit(bool(failed))
