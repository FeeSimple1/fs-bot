"""Check the immutable tenth-audit baseline evidence against its source revision."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
from xml.etree import ElementTree

from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


ROOT = Path(__file__).resolve().parent
REPO = Path(__import__('fs_bot').__file__).resolve().parent.parent
COMMIT = 'ae238c6482a792dda98af4f1f9b11abf820a3964'
SEEDS = list(range(53, 57))


def load(name):
    return json.loads((ROOT / name).read_text())


def main():
    source = load('source.json')
    current = source_identity()
    assert source['commit'] == current['commit'] == COMMIT
    assert source['source_sha256'] == current['source_sha256']
    assert source['dirty'] is False
    protected = load('protected-sources.json')
    assert len(protected) == 48
    assert set(protected) == {'fs_bot/rules_consts.py'} | {
        str(path.relative_to(REPO)) for path in (REPO / 'Reference Documents').rglob('*') if path.is_file()}
    assert all(hashlib.sha256((REPO / path).read_bytes()).hexdigest() == digest
               for path, digest in protected.items())

    suite, = ElementTree.parse(ROOT / 'pytest.xml').iter('testsuite')
    tests = {key: int(suite.get(key)) for key in ('tests', 'errors', 'failures', 'skipped')}
    assert tests == dict(tests=10279, errors=0, failures=0, skipped=0)
    tests.update(passed=tests['tests'], seconds=float(suite.get('time')), workers=4,
                 hash_seed=0, log='pytest.log', junit='pytest.xml')
    text = (ROOT / 'pytest.log').read_text()
    result = re.search(r'(\d+) passed, (\d+) warnings in ([\d.]+)s', text)
    assert result and int(result[1]) == tests['passed']
    tests.update(warnings=int(result[2]), console_seconds=float(result[3]),
                 warning_note='External anyio pytest plugin uses the deprecated CallSpec2 alias.')

    rows = [json.loads(line) for line in (ROOT / 'bots/games.jsonl').read_text().splitlines()]
    meta = load('bots/metadata.json')
    expected = {(scenario, seed) for scenario in SCENARIOS for seed in SEEDS}
    assert len(rows) == len(expected) == 20
    assert {(r['scenario'], r['seed']) for r in rows} == expected
    assert meta['seeds'] == SEEDS and meta['card_edition'] == 'second-edition'
    assert meta['source_sha256'] == source['source_sha256'] and meta['commit'] == COMMIT
    for row in rows:
        assert row['completed'] and row['game_completed'] and row['audit_completed']
        assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row)
        assert row['source_sha256'] == source['source_sha256']
        assert row['card_edition'] == 'second-edition'
        assert len(row['final_state_sha256']) == 64
        assert all(d['severity'] == 'legal-decline' for d in row['diagnostic_occurrences'])
    diagnostics = Counter(d['severity'] for r in rows for d in r['diagnostic_occurrences'])
    bots = dict(games=len(rows), completed=len(rows), seeds=SEEDS, edition='second-edition',
                scenarios=list(SCENARIOS), errors=0, integrity_findings=0, ranking_issues=0,
                interludes=sum(r['interlude_completed'] for r in rows),
                interlude_keys=[[r['scenario'], r['seed']] for r in rows if r['interlude_completed']],
                diagnostic_groups=sum(len(r['diagnostics']) for r in rows),
                diagnostic_occurrences=dict(diagnostics))

    for extension in ('json', 'log'):
        assert (ROOT / f'fuzz0.{extension}').read_bytes() == (ROOT / f'fuzz987.{extension}').read_bytes()
    fuzz = load('fuzz0.json')
    assert fuzz['metadata']['source_sha256'] == source['source_sha256']
    assert fuzz['metadata']['commit'] == COMMIT
    assert fuzz['metadata']['card_edition'] == 'second-edition' and fuzz['metadata']['seeds'] == SEEDS
    assert all(fuzz['metadata'][key] for key in ('reactive', 'events', 'replay'))
    assert fuzz['games'] == len(fuzz['records']) == 20 and fuzz['hard_findings'] == 0
    assert {(r['scenario'], r['seed']) for r in fuzz['records']} == expected
    assert all(r['game_completed'] and not r['findings'] for r in fuzz['records'])
    mixed = {key: fuzz[key] for key in ('games', 'human_turns', 'event_turns', 'events_ok',
                                      'partial', 'hard_findings', 'by_kind', 'batch_digest')}
    mixed.update(seeds=SEEDS, hash_seeds=[0, 987], edition='second-edition',
                 byte_identical_json=True, byte_identical_stdout=True, replay=True,
                 executions=80,
                 partial_cases=[dict(scenario=r['scenario'], seed=r['seed'], partial=r['partial'])
                                for r in fuzz['records'] if r['partial']])
    summary = dict(source=source, source_identity_at_verification=current,
                   protected_source_hashes_verified=True, pytest=tests, bots=bots, mixed=mixed,
                   balance_note='The full suite includes the existing 15-game balance canary. The audit does not refresh the baseline or claim a fresh 100-game balance study.')
    (ROOT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
