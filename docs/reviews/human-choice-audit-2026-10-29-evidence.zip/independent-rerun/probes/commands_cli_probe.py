"""Real modern collectors with deterministic prompt answers only.
No game functions mocked. Capture every menu and compare live board/RNG.
"""
import io,json
from contextlib import ExitStack
from unittest.mock import patch
import commands_probe as p
from fs_bot import rules_consts as rc
from fs_bot.cli import sa_timing, command_timing
from fs_bot.state.serialize import encode


def run():
    results={}
    for mode in ('rampage','seize','intimidate'):
        s=p.state(rc.SCENARIO_ARIOVISTUS if mode=='intimidate' else rc.SCENARIO_GREAT_REVOLT)
        R=rc.NERVII if mode=='rampage' else rc.CARNUTES
        actor=rc.BELGAE if mode=='rampage' else (rc.GERMANS if mode=='intimidate' else rc.ROMANS)
        if mode=='seize':p.place_piece(s,R,actor,rc.AUXILIA,2)
        else:
            p.place_piece(s,R,actor,rc.LEADER,leader_name=rc.AMBIORIX if mode=='rampage' else rc.ARIOVISTUS_LEADER)
            p.place_piece(s,R,actor,rc.WARBAND,4)
            if mode=='rampage':p.place_piece(s,R,rc.ROMANS,rc.AUXILIA,4)
            else:
                from fs_bot.cards.card_effects import _ally_tribe
                for tribe in (rc.TRIBE_CARNUTES,rc.TRIBE_AULERCI):_ally_tribe(s,tribe,rc.ROMANS)
        s['_cli_action_windows']=True
        p.valid(s)
        before=encode(s); transcript=[]; selected_region=False; selected_removal=False
        def choose(stdin,stdout,prompt,choices):
            nonlocal selected_region,selected_removal
            choices=list(choices); transcript.append({'prompt':prompt,'choices':[label for label,value in choices]})
            if prompt=='Voluntary removal?':return 'done'
            if 'which Region' in prompt:
                if not selected_region:
                    selected_region=True
                    return next(v for label,v in choices if v==R)
                return next(v for label,v in choices if v is None)
            if 'Rampage target' in prompt or 'Intimidate which Faction' in prompt:return rc.ROMANS
            if 'Remove which' in prompt:
                if selected_removal:return None
                selected_removal=True
                return next(v for label,v in choices if v==(rc.ALLY,None))
            raise AssertionError(prompt)
        def yes(stdin,stdout,prompt,default=False):
            transcript.append({'prompt':prompt,'choices':['yes','no']});return True
        with ExitStack() as stack:
            for target in ('fs_bot.cli.sa_timing.prompt_choice','fs_bot.cli.human_plan.prompt_choice','fs_bot.cli.voluntary_removal.prompt_choice'):
                stack.enter_context(patch(target,choose))
            stack.enter_context(patch('fs_bot.cli.command_timing.prompt_yes_no',yes))
            if mode=='rampage':plan=sa_timing.collect_rampage(s,actor,io.StringIO(),io.StringIO())
            elif mode=='seize':plan=command_timing.collect_seize(s,actor,io.StringIO(),io.StringIO(),False)
            else:plan=sa_timing.collect_intimidate(s,actor,io.StringIO(),io.StringIO())
        assert encode(s)==before
        results[mode]={'plan':plan,'menus':transcript,'live_board_rng_unchanged':True}
    return results
if __name__=='__main__':print(json.dumps(run(),indent=2))
