"""Inspect six captured first differences using frozen loss arithmetic only.

This does not rerun a bot decision from sorted diagnostic JSON. Counts and
canonical loss tiers are inspected on detached decoded boards, without an
agent. No engine or baseline files are changed.
"""
from copy import deepcopy
import json
from pathlib import Path
import sys

out = Path(__file__).resolve().parent
sys.path.insert(0, str(out / 'candidate-cdd2971'))
from fs_bot import rules_consts as rc
from fs_bot.state.serialize import decode, encode
from fs_bot.board.pieces import count_pieces, get_leader_in_region
from fs_bot.battle.losses import calculate_losses, _build_loss_priority
from fs_bot.cards.capabilities import is_capability_active
from fs_bot.tools.validation_metadata import source_identity

expected = 'cdd29718dab7ea7443f93dc225f192e3f31751aaa84c4e6e56d617a2b6c7b63c'
assert source_identity()['source_sha256'] == expected
cases = {}
for path in sorted(out.glob('first-semantic-*.json')):
    pair = json.loads(path.read_text())
    row = pair['parent']
    if row['stage'] != 'retreat-after':
        continue
    assert row['faction'] == rc.ROMANS
    def meaningful_board(row):
        result = {k: v for k, v in row['board'].items() if k != '_card_turn'}
        result['event_modifiers'] = {k: v for k, v in result.get('event_modifiers', {}).items()
                                     if k != 'card_67_target_regions'}
        return result
    assert meaningful_board(pair['parent']) == meaningful_board(pair['candidate'])
    assert pair['parent']['rng'] == pair['candidate']['rng']
    state = decode({**row['board'], 'rng': row['rng']})
    before = encode(state)
    region, attacker, defender = row['region'], row['attacker'], row['faction']
    standing = calculate_losses(state, region, attacker, defender)
    retreating = calculate_losses(state, region, attacker, defender, is_retreat=True)
    counter = calculate_losses(state, region, defender, attacker, is_counterattack=True)
    standing_order = _build_loss_priority(deepcopy(state), region, defender)
    retreat_order = _build_loss_priority(deepcopy(state), region, defender, is_retreat=True)
    abatis = (state.get('markers', {}).get(region, {}).get(rc.MARKER_ABATIS) == defender
              and not (attacker == rc.GERMANS and is_capability_active(state, 'A31', rc.EVENT_SHADED)))
    standing_exposure = sum(p[0] == rc.LEGION for p in standing_order[:standing])
    retreat_exposure = sum(p[0] == rc.LEGION for p in retreat_order[:max(0, retreating - int(abatis))])
    mobile = sum(count_pieces(state, region, defender, p)
                 for p in (rc.LEGION, rc.AUXILIA, rc.WARBAND))
    mobile += get_leader_in_region(state, region, defender) is not None
    hard = any(count_pieces(state, region, defender, p) for p in (rc.CITADEL, rc.FORT))
    last_piece = mobile > 0 and standing >= mobile and retreating < mobile
    weak_counter = not hard and counter * 2 < standing
    assert standing_exposure == retreat_exposure, (path.name, standing_exposure, retreat_exposure)
    assert not last_piece and not weak_counter
    assert encode(state) == before
    cases[path.stem.removeprefix('first-semantic-')] = {
        'checkpoint_index': row['index'], 'card_index': row['card_index'],
        'card': row['card'], 'region': region, 'attacker': attacker,
        'auxilia': count_pieces(state, region, defender, rc.AUXILIA),
        'legions': count_pieces(state, region, defender, rc.LEGION),
        'mobile_pieces': mobile, 'has_fort_or_citadel': hard,
        'standing_losses': standing, 'retreat_losses': retreating,
        'counterattack_losses': counter, 'defending_abatis': abatis,
        'standing_loss_priority': encode(standing_order),
        'retreat_loss_priority': encode(retreat_order),
        'standing_legion_exposure': standing_exposure,
        'retreat_legion_exposure': retreat_exposure,
        'last_piece_condition': last_piece,
        'weak_counterattack_condition': weak_counter,
        'inspected_state_and_rng_unchanged': True,
        'parent_decision': row['result'],
        'candidate_decision': pair['candidate']['result']}
assert len(cases) == 6
result = {'source_sha256': expected, 'method': __doc__, 'cases': cases}
(out / 'retreat-exposure.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: {key: row[key] for key in ('auxilia', 'legions',
    'standing_losses', 'retreat_losses', 'standing_legion_exposure',
    'retreat_legion_exposure')} for k, row in cases.items()}, indent=2))
