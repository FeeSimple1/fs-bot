Falling Sky first repair batch, 27 October 2026

Only attempt3 is accepted. Earlier attempts were superseded during independent
review; their partial suite logs and exploratory game records are retained
without counting them as final validation. baseline-tests.log is the unmodified
538c13d suite. Source snapshots and per-tool metadata identify the tested bytes.

Extract this directory beside the matching repository checkout named fs-bot.
Use the commit containing this report (Python digest in attempt3/source.json).
python verify.py rechecks all accepted evidence without simulating new games.
python review_attempt3.py independently verifies the legacy/balance records.

Accepted commands, run from fs-bot (redirect logs into this directory):
python -m pytest -q -n 6 --junitxml=../first-batch-validation/attempt3/tests.xml
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --workers 2 --out ../first-batch-validation/attempt3/bots-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 201-210 --card-edition original --workers 2 --out ../first-batch-validation/attempt3/bots-original
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 201-210 --card-edition second-edition --workers 2 --out ../first-batch-validation/attempt3/bots-second-edition
For each HASH in 0 and 7:
PYTHONHASHSEED=$HASH python -m fs_bot.tools.player_fuzz --seeds 1-4 --out ../first-batch-validation/attempt3/fuzz$HASH.json
PYTHONHASHSEED=$HASH python -m fs_bot.tools.error_census --seeds 1-5 --strict --out ../first-batch-validation/attempt3/census$HASH.json

Use fresh output directories for reruns; do not overwrite preserved evidence.
The optional pytest-xdist package was already installed; project dependencies
were not changed. Full tests ran under Python 3.12.14. Remote CI is separate.
