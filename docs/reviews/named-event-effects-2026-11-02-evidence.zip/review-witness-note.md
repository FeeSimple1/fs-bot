The first review_a18_before.py attempt used the main checkout, which had already
received the candidate A18 repair while this reviewer was reading sources. Its
old-defect assertion failed because the candidate removed all five German
pieces, correctly leaving no Successor or Scouted Warband. The empty
review-a18-before.json is that failed attempt, not accepted parent evidence.
The exploratory review_a18_inspect.py printed the candidate result to the tool
console; its embedded checkpoint description was copied from the parent probe
and must not be treated as provenance. The accepted parent-only witness is
review-a18-parent-01.json, run using the clean fs-named-events-before worktree at
2edf53e. This reproduces the two omitted pieces on the parent. Candidate focused
regressions independently exercise the desired corrected result.
