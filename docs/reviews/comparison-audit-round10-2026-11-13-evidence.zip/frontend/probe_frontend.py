"""Read-only tenth-audit frontend witnesses. Run with --repo <falling-sky>."""
import argparse
import copy
import io
import json
import pathlib
import sys
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--repo', required=True)
args = parser.parse_args()
sys.path.insert(0, str(pathlib.Path(args.repo).resolve()))

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces, count_pieces_by_state
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.cli.app import display_card_result
from fs_bot.cli.dispatcher import make_decision_func
from fs_bot.cli.display import HumanTurnDisplay
from fs_bot.cli.human_plan import _collect_enlist_details
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import play_card, ACTION_COMMAND_SA
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.state.serialize import save_game, load_game, encode, decode
from fs_bot.tools.seat_session import SeatSession, DecisionPending, board_copy, validate_response


def integrity(state):
    result = {'census': validate_state(state), 'structure': check_structural_integrity(state)}
    assert result == {'census': [], 'structure': []}, result
    return result


def position(scenario=rc.SCENARIO_GREAT_REVOLT, seed=6):
    state = build_initial_state(scenario, seed=seed)
    state.update(current_card=20, next_card=21, deck=[21, 22])
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    return state


def display_case(resources, with_target, raid):
    state = position()
    state['non_player_factions'] = {rc.ROMANS, rc.ARVERNI, rc.AEDUI, rc.BELGAE}
    state['resources'].update({f: 10 for f in state['non_player_factions']})
    state['resources'][rc.ARVERNI] = resources
    place_piece(state, rc.MANDUBII, rc.ARVERNI, rc.LEADER, leader_name=rc.VERCINGETORIX)
    assert _ally_tribe(state, rc.TRIBE_AULERCI, rc.ARVERNI)
    if with_target:
        place_piece(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA)
    if raid:
        state['rng'].seed(1)
        place_piece(state, rc.BITURIGES, rc.ARVERNI, rc.WARBAND, 2)
        place_piece(state, rc.CARNUTES, rc.ARVERNI, rc.WARBAND, 3)
    before = integrity(state)
    terminal = io.StringIO()
    callback = make_decision_func({}, io.StringIO(), terminal, pause=False)
    result = play_card(state, callback, execute=True)
    summary = io.StringIO()
    display_card_result(result, summary, scenario=state['scenario'])
    after = integrity(state)
    return {
        'before': before, 'after': after,
        'forecast_output': terminal.getvalue(), 'completed_output': summary.getvalue(),
        'actions_taken': result['turn_result']['actions_taken'],
        'roman_auxilia_carnutes': count_pieces(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA),
    }


def enlist_board(scenario, with_hidden=True):
    state = position(scenario, seed=1)
    state['current_card'] = 55
    state['non_player_factions'] = set()
    leader = rc.BODUOGNATUS if scenario in rc.ARIOVISTUS_SCENARIOS else rc.AMBIORIX
    place_piece(state, rc.CARNUTES, rc.BELGAE, rc.LEADER, leader_name=leader)
    place_piece(state, rc.CARNUTES, rc.BELGAE, rc.WARBAND)
    if with_hidden:
        place_piece(state, rc.CARNUTES, rc.GERMANS, rc.WARBAND, piece_state=rc.HIDDEN)
    place_piece(state, rc.CARNUTES, rc.GERMANS, rc.WARBAND, piece_state=rc.SCOUTED)
    return state


def decision(selected):
    return {'action': ACTION_COMMAND_SA, 'player_action': {
        'command': rc.CMD_RAID, 'regions': [rc.CARNUTES],
        'sa': rc.SA_ENLIST, 'sa_regions': [rc.CARNUTES], 'sa_timing': 'before',
        'details': {'raid_plan': [{'region': rc.CARNUTES, 'target': None}],
                    'enlist': {'type': 'german_march', 'origin': rc.CARNUTES,
                               'destination': rc.MANDUBII, 'warbands': {selected: 1}}}}}


def visibility(state):
    return {region: {ps: count_pieces_by_state(state, region, rc.GERMANS, rc.WARBAND, ps)
                     for ps in (rc.HIDDEN, rc.REVEALED, rc.SCOUTED)}
            for region in (rc.CARNUTES, rc.MANDUBII)}


def enlisted_case(scenario, selected=rc.SCOUTED, with_hidden=True):
    state = enlist_board(scenario, with_hidden)
    before = integrity(state)
    initial = copy.deepcopy(state)
    initial_visibility = visibility(state)
    choice = decision(selected)
    request = {'kind': 'turn', 'faction': rc.BELGAE, 'options': [ACTION_COMMAND_SA],
               'position': '1st_eligible'}
    assert validate_response(state, request, choice) == choice
    session = SeatSession(state, {'seat': rc.BELGAE}, [], HumanTurnDisplay(io.StringIO()))
    session.checkpoint()
    try:
        session.ask(state, rc.BELGAE, request)
        raise AssertionError('Unanswered turn should remain pending')
    except DecisionPending:
        pass
    pending = copy.deepcopy(session.data['pending'])
    with tempfile.TemporaryDirectory() as directory:
        path = pathlib.Path(directory) / 'session.json'
        save_game(state, path, meta=session.meta, log=session.log)
        restored, meta, log = load_game(path, validate=True)
    session = SeatSession(restored, meta, log, HumanTurnDisplay(io.StringIO()))
    assert session.data['pending'] == pending
    session.import_inbox({'decision_id': pending['id'], 'response': choice})
    session.checkpoint()
    accepted = session.ask(restored, rc.BELGAE, request)
    assert accepted == choice
    result = execute_decision(restored, rc.BELGAE, accepted)
    assert result['executed'] and result['sa_execution']['executed'] and not result['errors'], result
    session.finish()
    assert len(log) == 1 and not session.data['pending']
    recorded = decode(log[0]['assistant_response'])
    assert recorded == choice
    replay_result = execute_decision(initial, rc.BELGAE, recorded)
    assert replay_result == result
    assert encode(board_copy(initial)) == encode(board_copy(restored))
    after = integrity(restored)
    final = visibility(restored)
    expected_revealed = int(selected == rc.SCOUTED)
    return {'scenario': scenario, 'selection': selected, 'with_unselected_hidden': with_hidden,
            'before': before, 'after': after, 'initial': initial_visibility, 'final': final,
            'expected_destination_revealed': expected_revealed,
            'actual_destination_revealed': final[rc.MANDUBII][rc.REVEALED],
            'pending_id_retained_after_reload': True, 'accepted_plan_retained': True,
            'saved_choice_execution_repeat_equal': True, 'execution': result}


display_results = {
    'raid_funds_entreat': display_case(0, True, True),
    'rally_forecast_matches_entreat': display_case(10, True, False),
    'raid_no_target_no_entreat': display_case(0, False, True),
}
primary = display_results['raid_funds_entreat']
arverni = primary['actions_taken'][rc.ARVERNI]
assert arverni['bot_action']['sa'] == 'No SA'
assert arverni['execution']['sa_execution']['sa'] == rc.SA_ENTREAT
assert arverni['execution']['sa_execution']['executed']
assert rc.SA_ENTREAT not in primary['completed_output']
assert primary['roman_auxilia_carnutes'] == 0
romans = primary['actions_taken'][rc.ROMANS]
assert romans['bot_action']['sa'] == rc.SA_BUILD
assert not romans['execution']['sa_execution']['executed']
assert '(SA: Build)' in primary['completed_output']
assert '(SA: Entreat' in display_results['rally_forecast_matches_entreat']['completed_output']
assert not (display_results['raid_no_target_no_entreat']['actions_taken'][rc.ARVERNI]
            ['execution'].get('sa_execution') or {}).get('executed')

enlist_results = [enlisted_case(s) for s in (*rc.BASE_SCENARIOS, *rc.ARIOVISTUS_SCENARIOS)]
enlist_results += [enlisted_case(rc.SCENARIO_GREAT_REVOLT, rc.HIDDEN),
                   enlisted_case(rc.SCENARIO_GREAT_REVOLT, with_hidden=False)]
for case in enlist_results:
    mismatch = (case['actual_destination_revealed'] != case['expected_destination_revealed'])
    assert mismatch == (case['scenario'] in rc.BASE_SCENARIOS and case['selection'] == rc.SCOUTED
                        and case['with_unselected_hidden']), case

menu_state = enlist_board(rc.SCENARIO_GREAT_REVOLT)
menu_initial = encode(menu_state)
menu_output = io.StringIO()
regions, details = _collect_enlist_details(menu_state, rc.BELGAE,
    io.StringIO('Carnutes\nMandubii\n2\n'), menu_output, _sub='german_march')
assert details['enlist']['warbands'] == 1
assert encode(menu_state) == menu_initial
assert 'Scouted' not in menu_output.getvalue()

print(json.dumps({'UI10-01': display_results, 'UI10-02': {
    'cases': enlist_results, 'base_terminal_menu': menu_output.getvalue(),
    'base_terminal_plan': details, 'terminal_board_unchanged': True,
}}, indent=2, sort_keys=True))
