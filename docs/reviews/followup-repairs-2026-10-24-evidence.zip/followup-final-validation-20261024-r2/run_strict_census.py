"""Reproducible two-hash strict census; launched only after source freeze."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

REPO = Path('/workspace/scratch/534c265c65f4/fs-bot')
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))
from fs_bot.tools.validation_metadata import source_identity


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--expected-source', required=True)
    args = ap.parse_args()
    before = source_identity()
    if before['source_sha256'] != args.expected_source:
        raise SystemExit('Source digest differs from approved freeze; census not started.')
    report = {'expected_source_sha256': args.expected_source, 'source_before': before,
              'runs': []}
    for hashseed in (0, 7):
        if source_identity()['source_sha256'] != args.expected_source:
            report['source_drift_before_run'] = hashseed
            break
        out = ROOT / f'census-hash{hashseed}.json'
        stdout = ROOT / f'census-hash{hashseed}.stdout.txt'
        stderr = ROOT / f'census-hash{hashseed}.stderr.txt'
        cmd = [sys.executable, '-m', 'fs_bot.tools.error_census', '--seeds', '1-20',
               '--strict', '--out', str(out)]
        env = dict(os.environ, PYTHONHASHSEED=str(hashseed))
        with stdout.open('w') as so, stderr.open('w') as se:
            proc = subprocess.run(cmd, cwd=REPO, env=env, stdout=so, stderr=se)
        report['runs'].append({'hashseed': hashseed, 'command': cmd,
                              'exit_code': proc.returncode,
                              'source_after': source_identity(),
                              'stdout_path': str(stdout), 'stderr_path': str(stderr),
                              'json_path': str(out)})
        print(f'hashseed={hashseed} exit={proc.returncode}', flush=True)
    report['source_after'] = source_identity()
    report['source_unchanged'] = all(
        identity['source_sha256'] == args.expected_source for identity in
        [report['source_before'], report['source_after']] +
        [run['source_after'] for run in report['runs']])
    if len(report['runs']) == 2:
        left, right = report['runs']
        a, b = Path(left['json_path']).read_bytes(), Path(right['json_path']).read_bytes()
        report['json_bytes_identical'] = a == b
        report['json_complete_identical'] = json.loads(a) == json.loads(b)
        report['stdout_identical'] = Path(left['stdout_path']).read_bytes() == Path(right['stdout_path']).read_bytes()
        report['json_sha256'] = [hashlib.sha256(x).hexdigest() for x in (a, b)]
        report['stdout_sha256'] = [hashlib.sha256(Path(run['stdout_path']).read_bytes()).hexdigest()
                                   for run in report['runs']]
    report['accepted'] = (len(report['runs']) == 2 and report['source_unchanged']
                          and all(run['exit_code'] == 0 for run in report['runs'])
                          and report.get('json_complete_identical', False)
                          and report.get('stdout_identical', False))
    path = ROOT / 'census-comparison.json'
    path.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('accepted', 'source_unchanged')}
                     | {'comparison_path': str(path)}), flush=True)
    return 0 if report['accepted'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
