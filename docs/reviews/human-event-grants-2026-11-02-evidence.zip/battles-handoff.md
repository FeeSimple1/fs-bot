# EXP-01 handoff — A21 Vosegus / A57 Sabis

Branch: `repair/event-battles-2026-11-02`, isolated base `d3241e7ad0ed5e11a88d114958e886221dd36db9`.
Commit: `60267c7` (no push; root integrates).
Final candidate source SHA-256: `b3c220d44490735b46ce449e4653f82c48a162b95b003167fc9a7b37fb3b688e`.

## Sources read and applied

Complete `Reference Documents/` inventory inspected (47 source files; both base and Ariovistus directories), plus CLAUDE.md, README/docs orientations, current status, provisional rulings PR-01–PR-09, relevant Agent Interface/Playing frontend guidance and EXP-01 inventory row. No external sources consulted.

- `Reference Documents/Ariovistus/A Card Reference:58–60` (A21): “Free Battle in a Region within 1 of Sequani. No Retreat. Then, if desired, free Battle there again (Retreat allowed).”
- Same source `261–263` (A57): identical except “in a Belgica Region”. Both are single-text Events; either incoming side flag reaches the same contract.
- `Reference Documents/Chapter 5`, §5.1: executing faction makes the selections; §5.1.1 and §5.4 retain ordinary Battle rules except printed modifications; §5.1.3 requires all possible nonoptional text.
- `Reference Documents/Chapter 3`, §§3.2.4/3.3.4: any Region with own and other Forces; attacker chooses one enemy with pieces. `Key Terms Index:122–125` expressly includes static Allies, Citadels and Forts among Forces. Human legal candidates therefore include static-only attackers/defenders and do not require a predicted Loss.
- `Reference Documents/Ariovistus/Chapter A3`, A3.2.4/A3.3.4/A3.4.4: normal expansion Battle/Retreat, including automatic Arverni never Retreat and Germanic Settlements as Allies.
- `Reference Documents/Ariovistus/Chapter A1:103–107`: “Warbands and Auxilia together”; original Card Reference 38 also says “where together”. Existing Diviciacus eligibility needs both physical types, so no legal Roman option exists using only Aedui pieces/Leader. Added a source regression.
- Ariovistus Belgae NP Event instructions: four-card group including Vosegus/Sabis targets most forced Legion Losses, else No Belgae. German NP sheet: preserve Ariovistus's four-Warband Counterattack floor. These remain NP/delegation policies only.
- Battle procedure play aid inspected; no new rule interpretation or provisional ruling was introduced.

## Delivered contract

New `free_action` subtype `request_type: "decisive_battle"` exposes `card_id`, `phase` (`first`/`second`), `allowed_regions`, `defenders_by_region`, `allowed_commands: [Battle]`, `max_regions: 1`, `free: true`, `with_sa: false`, `no_retreat`, `allow_decline`, `default_available`, and `attempt`.

Response is exactly `{region, defender}`. No SA, battle-modifier or extra grant fields can be submitted. First Battle is mandatory when a legal own/enemy Force overlap exists. Second request is rebuilt after first Battle outcomes and reactions, allows another defender, and is limited to the first actual Region. It may be declined with `{decline: true}`. No second request is emitted without a legal surviving option. The first supplies no-Retreat internally; second uses ordinary Retreat restrictions.

`{use_default: true}` intentionally delegates to the existing NP planner. First default is rejected when NP policy supplies no first Battle despite legal human choices (notably human Belgae versus Germans and Germans below Ariovistus's NP floor). Optional second default may decline. Raw callback `None`/ordinary exception retains the documented historical NPC fallback, including historical no-target outcomes; it is distinct from durable human input.

The engine-owned `validate_default_response: true` request flag opts into a narrow shared SeatSession gate: validate exact use_default with the free-action validator before acceptance, and preserve the sentinel in the journal. Existing requests without the flag retain prior behavior. Roman/movement/cohort agents were notified and can use this flag; they copied the gate locally for validation but should omit that shared change from their own commits.

Diviciacus: a concrete human choice or explicit default that receives a refused optional loan returns to the same Battle selection, preserving the mandatory first Battle and optional second choice. Retry request adds `previous_error` and increments `attempt`; prior accepted selection/opt-in/refusal remain replayable. No completed first Battle is repeated. Raw fallback retains its prior single-attempt behavior. Ordinary lending and physical casualty ownership still use existing engine helpers.

Terminal: specialized Region/defender menus, no first decline, explicit default only when usable, optional second decline/default, clear No Retreat/Retreat allowed text, common `b`/`board` inspection, EOF propagation, validation before returning input. Durable: missing/invalid/forged/stale-board choices remain pending with stable IDs and unchanged transaction board/RNG, accepted first choice survives save/load before second, deterministic request/board/RNG replay.

## Changed files

- New `fs_bot/cards/decisive_battle.py`: legality, response validation, human selection/retry and existing NP/default routing.
- New `fs_bot/cli/decisive_battle.py`: specialized menus.
- `fs_bot/engine/execute.py`: replace only A21/A57 resolver loop body with module call; other Event functions untouched.
- `fs_bot/engine/free_actions.py`: one namespaced validator dispatch.
- `fs_bot/cli/free_actions.py`: one namespaced collector dispatch.
- `fs_bot/tools/seat_session.py`: opt-in explicit-default validation/preservation gate.
- New `fs_bot/tests/test_decisive_battle_choices.py`: 59 source-derived regression cases.

No project-wide docs changed (root owns integration docs). No protected file changes: `battles-integrity.json` records 48 checked files, including all 47 reference files and rules_consts.py. Existing unrelated untracked `docs/reviews/.recruit-rally-2026-10-29-evidence.zip.U7lTMt` was left untouched.

## Validation / preserved evidence

Interpreter: `/workspace/scratch/534c265c65f4/fs-test-venv/bin/python`.

- `battles-before.txt`: four source-derived first/second-choice tests all failed on the unmodified base (actual missing human request/outcome failures).
- `battles-loan-before.txt`: later source test demonstrated optional loan refusal swallowing mandatory first Battle before local retry repair.
- `battles-focused-final2.txt`: 188 passed (59 new tests plus conditional NP Event, Diviciacus Event, CLI free actions, assistant sessions and free-action sentinel regressions).
- `battles-pytest-candidate1.txt`: superseded full-suite pass, 6,328 tests, before the final loan retry/regressions. Do not present as final-source validation.
- `battles-pytest-final.txt`: final full `pytest -q -n 2` passed, **6,339 tests in 104.23 seconds** before commit.
- Tests validate physical state conservation, resource-free execution, untouched live RNG/input under preview/invalid responses, no stale Event flags, NP restrictions, and both accepted/declined second-choice replay. Retry save/load/replay is separately covered.

## Scope / limits

EXP-01 complete; no new source ambiguity. Existing Battle capability selection/casualty-choice findings outside this Event grant remain separate. This introduces previously absent mandatory human prompts, so it does not claim old transcripts lacking these choices can replay without supplying them. Raw callback fallback compatibility is explicitly retained. Bot planners, availability heuristics and protected references/constants are unchanged. Root should document the new response shape/shared flag, update EXP-01 progress, run integrated validation and push the combined work.
