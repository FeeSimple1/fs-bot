"""Exercise each nonstandard legal setup with the native audited game runner."""
from itertools import product
from pathlib import Path
import json
from fs_bot import rules_consts as rc
from fs_bot.tools import run_batch
from fs_bot.tools.validation_metadata import source_identity

original = run_batch.setup_scenario
records = []
for scenario in rc.ALL_SCENARIOS:
    for sudden, even, short in product((False, True), repeat=3):
        if not any((sudden, even, short)):
            continue
        if even and scenario == rc.SCENARIO_PAX_GALLICA:
            continue
        if short and scenario != rc.SCENARIO_GREAT_REVOLT:
            continue
        options = dict(sudden_frost=sudden, even_initiative=even,
                       short_great_revolt=short)
        def setup(*args, **kwargs):
            return original(*args, **kwargs, **options)
        run_batch.setup_scenario = setup
        try:
            for seed in (1, 2):
                row = run_batch.play_one((scenario, seed))
                row['setup_options'] = options
                records.append(row)
        finally:
            run_batch.setup_scenario = original
Path('/tmp/fs-setup-options-option-matrix.json').write_text(
    json.dumps(dict(source=source_identity(), records=records), indent=2)+'\n')
print(json.dumps(dict(games=len(records), completed=sum(r['completed'] for r in records),
                     interludes=sum(r['interlude_completed'] for r in records))))
assert all(r['completed'] and not r['errors'] and not r['integrity_findings'] for r in records)
