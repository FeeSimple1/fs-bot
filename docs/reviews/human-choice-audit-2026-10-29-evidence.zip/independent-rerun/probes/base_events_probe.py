"""Bounded human-choice probes; production source is untouched.
Run: PYTHONPATH=fs-bot fs-test-venv/bin/python human-choice-audit-2026-10-29/probes/base_events_probe.py
Empty but inventory-valid scenario states are intentional, using piece helpers.
"""
import io, json
from copy import deepcopy
from fs_bot import rules_consts as rc
from fs_bot.state.state_schema import build_initial_state, validate_state
from fs_bot.board.pieces import place_piece, count_pieces, count_pieces_by_state
from fs_bot.cards.card_effects import execute_event, _ally_tribe
from fs_bot.cards.param_schema import card_param_schema, kind_values
from fs_bot.cards.capabilities import activate_capability, set_capability_owner
from fs_bot.engine.execute import _execute_event, _execute_battle
from fs_bot.tools.seat_session import SeatSession, DecisionPending
from fs_bot.cli.display import HumanTurnDisplay

out = {}
def fresh(actor=rc.BELGAE):
    s=build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=7)
    s['non_player_factions']=set()
    s['executing_faction']=actor
    s['event_params']={}
    for f in s['resources']: s['resources'][f]=20
    return s

def run(s,card,params=None,shaded=False):
    s['event_params']=params or {}
    before=validate_state(s)
    assert not before, before
    execute_event(s,card,shaded)
    after=validate_state(s)
    assert not after, after

def event_action(card,params=None,shaded=False):
    return {'command':'Event','regions':[],'sa':'No SA','sa_regions':[],
        'details':{'card_id':card,'text_preference':rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,'event_params':params or {}}}

# No Roman decision occurs even when Romans own both legally removable types.
s=fresh(); place_piece(s,rc.SEQUANI,rc.ROMANS,rc.LEGION,from_legions_track=True);place_piece(s,rc.SEQUANI,rc.ROMANS,rc.AUXILIA)
session=SeatSession(s,{'seat':rc.ROMANS,'scenario':s['scenario'],'seed':7},[],HumanTurnDisplay(io.StringIO()))
s['decision_agent']=session.reactive
res=_execute_event(s,rc.BELGAE,event_action(49,{'devastate_region':rc.SEQUANI}),human=True)
out['drought_durable_no_roman_request']={'executed':res['executed'],'pending':session.data['pending'],'legions':count_pieces(s,rc.SEQUANI,rc.ROMANS,rc.LEGION),'auxilia':count_pieces(s,rc.SEQUANI,rc.ROMANS,rc.AUXILIA),'fallen':s['fallen_legions'],'valid':not validate_state(s)}
# JSON string-key override is ignored; actual tuple-key override works in Python only.
for keyname, overrides in [('json_string',{str((rc.ROMANS,rc.SEQUANI)):rc.AUXILIA}),('python_tuple',{(rc.ROMANS,rc.SEQUANI):rc.AUXILIA})]:
    s=fresh();place_piece(s,rc.SEQUANI,rc.ROMANS,rc.LEGION,from_legions_track=True);place_piece(s,rc.SEQUANI,rc.ROMANS,rc.AUXILIA)
    run(s,49,{'devastate_region':rc.SEQUANI,'piece_removals':overrides})
    out['drought_'+keyname]={'legions':count_pieces(s,rc.SEQUANI,rc.ROMANS,rc.LEGION),'auxilia':count_pieces(s,rc.SEQUANI,rc.ROMANS,rc.AUXILIA)}

# Smaller placement and remove-only choices have no consumed parameter.
s=fresh();run(s,19,{'choice':'auxilia','count':1});out['lucterius_auxilia_requested_1']={'placed':count_pieces(s,rc.PROVINCIA,rc.ROMANS,rc.AUXILIA)}
s=fresh();place_piece(s,rc.PROVINCIA,rc.ARVERNI,rc.WARBAND,4);run(s,19,{'choice':'warbands','removal_regions':[rc.PROVINCIA],'count':1});out['lucterius_warbands_requested_1']={'remaining':count_pieces(s,rc.PROVINCIA,rc.ARVERNI,rc.WARBAND)}
s=fresh(rc.BELGAE);place_piece(s,rc.MORINI,rc.BELGAE,rc.WARBAND,3);place_piece(s,rc.MORINI,rc.ARVERNI,rc.WARBAND)
run(s,22,{'replacements':[{'region':rc.MORINI,'target_faction':rc.ARVERNI,'piece_type':rc.WARBAND,'replace':False}]});out['hostages_remove_only']={'belgic_warbands':count_pieces(s,rc.MORINI,rc.BELGAE,rc.WARBAND)}
# Pompey cannot select one of two Legions from each Region via its region-only list.
s=fresh()
for r,n in [(rc.MORINI,2),(rc.NERVII,2),(rc.SEQUANI,4)]:place_piece(s,r,rc.ROMANS,rc.LEGION,n,from_legions_track=True)
run(s,3,{'legion_removal_regions':[rc.MORINI,rc.NERVII]},True)
out['pompey_no_split_counts']={r:count_pieces(s,r,rc.ROMANS,rc.LEGION) for r in [rc.MORINI,rc.NERVII]}
# Precise physical states are not read; Scouted-only target disappears from 45's options.
s=fresh();place_piece(s,rc.CARNUTES,rc.ARVERNI,rc.WARBAND,piece_state=rc.HIDDEN);place_piece(s,rc.CARNUTES,rc.ARVERNI,rc.WARBAND,piece_state=rc.REVEALED)
run(s,45,{'regions':[{'region':rc.CARNUTES,'count':1,'piece_state':rc.REVEALED}]})
out['litaviccus_ignores_selected_state']={ps:count_pieces_by_state(s,rc.CARNUTES,rc.ARVERNI,rc.WARBAND,ps) for ps in [rc.HIDDEN,rc.REVEALED]}
s=fresh();place_piece(s,rc.CARNUTES,rc.ARVERNI,rc.WARBAND,piece_state=rc.SCOUTED)
run(s,45,{'regions':[{'region':rc.CARNUTES,'count':1,'piece_state':rc.SCOUTED}]})
out['litaviccus_scouted_unselectable']={'arverni':count_pieces(s,rc.CARNUTES,rc.ARVERNI,rc.WARBAND),'aedui':count_pieces(s,rc.CARNUTES,rc.AEDUI,rc.WARBAND)}
# Exact Allied Tribe lost is fixed alphabetically even if a different Tribe supplied.
s=fresh();_ally_tribe(s,rc.TRIBE_BELLOVACI,rc.ROMANS);_ally_tribe(s,rc.TRIBE_REMI,rc.ROMANS);_ally_tribe(s,rc.TRIBE_MANDUBII,rc.AEDUI);_ally_tribe(s,rc.TRIBE_SENONES,rc.AEDUI)
run(s,31,{'roman_ally_region':rc.ATREBATES,'roman_ally_tribe':rc.TRIBE_REMI,'aedui_ally_region':rc.MANDUBII,'third_ally_faction':rc.AEDUI,'third_ally_region':rc.MANDUBII},True)
out['cotuatus_tribe_unselectable']={t:s['tribes'][t]['allied_faction'] for t in [rc.TRIBE_BELLOVACI,rc.TRIBE_REMI]}
# Claimed optional actions bypass a separate Roman owner's consent.
for card,params in [(2,{'legions_from_track':2}),(18,{'target_region':rc.UBII}),(23,{'target_city':rc.CITY_ALESIA})]:
    s=fresh(rc.BELGAE);s['senate']['position']=rc.INTRIGUE
    place_piece(s,rc.SEQUANI,rc.ROMANS,rc.AUXILIA,5)
    place_piece(s,rc.UBII,rc.GERMANS,rc.WARBAND)
    place_piece(s,rc.MANDUBII,rc.ROMANS,rc.AUXILIA,3)
    session=SeatSession(s,{'seat':rc.ROMANS,'scenario':s['scenario'],'seed':7},[],HumanTurnDisplay(io.StringIO()));s['decision_agent']=session.reactive
    res=_execute_event(s,rc.BELGAE,event_action(card,params),human=True)
    out['optional_roman_'+str(card)]={'executed':res['executed'],'pending':session.data['pending'],'senate':s['senate'],'legions_provincia':count_pieces(s,rc.PROVINCIA,rc.ROMANS,rc.LEGION),'germans_ubii':count_pieces(s,rc.UBII,rc.GERMANS,rc.WARBAND),'alesia_status':s['tribes'][rc.TRIBE_MANDUBII]['status'],'valid':not validate_state(s)}
# Remi's owning Aedui are supposed to receive pieces; Belgae execute it instead.
s=fresh(rc.BELGAE);_ally_tribe(s,rc.TRIBE_REMI,rc.AEDUI)
run(s,68,{'target_city':rc.CITY_ALESIA},True)
out['remi_wrong_beneficiary']={'remi_owner':s['tribes'][rc.TRIBE_REMI]['allied_faction'],'alesia_owner':s['tribes'][rc.TRIBE_MANDUBII]['allied_faction'],'aedui_warbands':count_pieces(s,rc.MANDUBII,rc.AEDUI,rc.WARBAND),'belgae_warbands':count_pieces(s,rc.MANDUBII,rc.BELGAE,rc.WARBAND)}
# 65 shaded attempts Auxilia for a Gallic player instead of its own Warband.
s=fresh(rc.BELGAE);place_piece(s,rc.NERVII,rc.BELGAE,rc.WARBAND,3);place_piece(s,rc.NERVII,rc.GERMANS,rc.WARBAND)
run(s,65,{'warband_replacements':[{'region':rc.NERVII}]},True)
out['german_allegiances_gallic_replacement']={'german_remaining':count_pieces(s,rc.NERVII,rc.GERMANS,rc.WARBAND),'belgae_remaining':count_pieces(s,rc.NERVII,rc.BELGAE,rc.WARBAND)}
# Actual typed CLI candidates cannot express these handler values/shapes.
s=fresh()
out['schema']={}
for card,key,desired in [(6,'auxilia_moves',None),(11,'auxilia_removal_regions',None),(19,'choice','warbands'),(23,'target_city',rc.CITY_ALESIA),(28,'citadel_upgrades',rc.CITY_ALESIA),(49,'piece_removals',None),(57,'removal',None),(68,'target_city',rc.CITY_ALESIA),(9,'march_from',rc.PROVINCIA)]:
    spec=card_param_schema(card,s['scenario'],'original')[key]
    vals=kind_values(s,spec['kind'],spec)
    out['schema'][str(card)+'.'+key]={'spec':spec,'candidate_contains_desired':desired in vals if desired is not None else None,'candidate_example':vals[:3]}

# Requests come after an automatically selected initial March, exposing no human group choice.
for card,params in [(4,{'target_region':rc.MANDUBII}),(9,{'march_from':rc.SEQUANI,'march_to':rc.ARVERNI_REGION}),(67,{}),(70,{})]:
    s=fresh(rc.ROMANS);place_piece(s,rc.SEQUANI,rc.ROMANS,rc.AUXILIA,3);place_piece(s,rc.MANDUBII,rc.BELGAE,rc.WARBAND,2)
    if card==4:
        _ally_tribe(s,rc.TRIBE_MANDUBII,rc.BELGAE)
        from fs_bot.board.pieces import remove_piece
        remove_piece(s,rc.MANDUBII,rc.BELGAE,rc.ALLY);place_piece(s,rc.MANDUBII,rc.BELGAE,rc.CITADEL)
    requests=[]
    def agent(board,who,request):
        requests.append({'who':who,'kind':request['kind'],'request_type':request.get('request_type')})
        if request['kind']=='free_action':return {'decline':True}
        if request['kind']=='agreement':return False
        if request['kind']=='retreat':return {'retreat':False}
        if request['kind']=='loss_order':return request['pieces']
    s['decision_agent']=agent
    result=_execute_event(s,rc.ROMANS,event_action(card,params),human=True)
    out['automatic_action_'+str(card)]={'result':result,'requests':requests,'roman_regions':{r:count_pieces(s,r,rc.ROMANS,rc.AUXILIA) for r in s['spaces'] if count_pieces(s,r,rc.ROMANS,rc.AUXILIA)},'valid':not validate_state(s)}
# Gallic Shouts shaded and Celtic Rites never ask the executor for a beneficiary.
for card in [35,46]:
    s=fresh(rc.ROMANS); requests=[]
    def agent(board,who,request):
        requests.append({'who':who,'kind':request['kind'],'limited':request.get('limited'),'max_regions':request.get('max_regions'),'request_type':request.get('request_type')})
        return {'decline':True}
    s['decision_agent']=agent
    res=_execute_event(s,rc.ROMANS,event_action(card,{'faction':rc.AEDUI},True),human=True)
    out['wrong_free_beneficiary_'+str(card)]={'requests':requests,'result':res}
# Future cards and eligibility option are not in Gallic Shouts' only request.
s=fresh(rc.BELGAE);s['deck']=[1,2,3];s['next_card']=4;requests=[]
def shouts_agent(board,who,request):
    requests.append({'who':who,'request':request});return {'decline':True}
s['decision_agent']=shouts_agent
res=_execute_event(s,rc.BELGAE,event_action(35),human=True)
out['shouts_unshaded_information']={'requests':requests,'result':res}

# Ongoing capability choice: a human Roman with 2 candidate regions gets no choice request.
for card in [13,59]:
    s=fresh(rc.BELGAE);activate_capability(s,card,rc.EVENT_UNSHADED);requests=[];observed=[]
    for region,n in [(rc.MORINI,1),(rc.NERVII,3)]:
        place_piece(s,region,rc.ROMANS,rc.AUXILIA,n);place_piece(s,region,rc.BELGAE,rc.WARBAND,6);place_piece(s,region,rc.AEDUI,rc.WARBAND,2)
    def agent(board,who,request):
        requests.append({'who':who,'kind':request['kind'],'request_type':request.get('request_type')})
        if request['kind']=='retreat':return {'retreat':False}
        if request['kind']=='loss_order':return request['pieces']
        if request['kind']=='agreement':return False
    s['decision_agent']=agent
    action={'command':'Battle','regions':[rc.MORINI,rc.NERVII],'sa':'No SA','details':{'battle_plan':[{'region':r,'target':rc.AEDUI} for r in [rc.MORINI,rc.NERVII]],'capability_region':rc.MORINI}}
    result=_execute_battle(s,rc.BELGAE,action,_battle_observer=lambda phase,board,r,d,res: observed.append({'phase':phase,'region':r,'c59_selected':board.get('event_modifiers',{}).get('card59_unshaded_region')}) if phase=='before' else None)
    out['capability_'+str(card)]={'requests':requests,'observed':observed,'result':result,'valid':not validate_state(s)}
print(json.dumps(out,indent=2,default=str))
