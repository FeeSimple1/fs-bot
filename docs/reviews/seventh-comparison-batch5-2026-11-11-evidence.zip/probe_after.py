"""Seventh comparison Batch 5 witnesses after repair.
Run: PYTHONPATH=<fs-bot-root> python probe_bots.py
Sparse, conserved controlled positions; no claim of naturally sampled frequency.
"""
from copy import deepcopy
import json
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces, count_pieces_by_state
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.bots.bot_common import predict_battle
from fs_bot.cards.capabilities import activate_capability, set_capability_owner
from fs_bot.commands.sa_ambush import validate_ambush_region
from fs_bot.commands.raid import max_raiders_per_region
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND, ACTION_COMMAND_SA
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.tools.seat_session import validate_response


def integrity(state):
    assert validate_state(state) == [], validate_state(state)
    assert check_structural_integrity(state) == [], check_structural_integrity(state)


def board(scenario, *, seed, resources, sa):
    state = build_initial_state(scenario, seed=seed)
    state['non_player_factions'] = {rc.ROMANS, rc.AEDUI, rc.BELGAE,
        rc.GERMANS if scenario in rc.ARIOVISTUS_SCENARIOS else rc.ARVERNI}
    state['can_play_event'] = False
    state['_command_with_sa'] = sa
    for faction in state['non_player_factions']:
        state['resources'][faction] = resources
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    integrity(state)
    return state


def execute_bot(state, faction, *, sa):
    action = dispatch_bot_turn(state, faction)
    result = execute_decision(state, faction, {
        'action': ACTION_COMMAND_SA if sa else ACTION_COMMAND, 'bot_action': action})
    assert result.get('executed') and not result.get('errors'), result
    integrity(state)
    return {'action': action, 'result': result}


def public_alternative(state, faction, command, details, *, sa='No SA'):
    kind = ACTION_COMMAND if sa == 'No SA' else ACTION_COMMAND_SA
    action = {'command': command, 'regions': [rc.CARNUTES], 'sa': sa,
              'sa_regions': [rc.CARNUTES] if sa != 'No SA' else [], 'details': details}
    response = {'action': kind, 'player_action': action}
    validate_response(state, {'kind': 'turn', 'faction': faction,
                              'options': [kind]}, response)
    result = execute_decision(state, faction, response)
    assert result.get('executed') and not result.get('errors'), result
    integrity(state)
    return result


def ambush_cases():
    rows = []
    for faction, warbands, auxilia, leader, scenario, attack in (
        (rc.BELGAE, 4, 12, rc.AMBIORIX, rc.SCENARIO_GREAT_REVOLT, 2),
        (rc.ARVERNI, 10, 20, rc.VERCINGETORIX, rc.SCENARIO_GREAT_REVOLT, 5),
        (rc.GERMANS, 6, 18, rc.ARIOVISTUS_LEADER, rc.SCENARIO_ARIOVISTUS, 3),
    ):
        for hidden, sa in ((True, True), (False, True), (True, False)):
            state = board(scenario, seed=6, resources=10, sa=sa)
            place_piece(state, rc.CARNUTES, faction, rc.WARBAND, warbands,
                        piece_state=rc.HIDDEN if hidden else rc.REVEALED)
            place_piece(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA, auxilia,
                        piece_state=rc.REVEALED)
            place_piece(state, rc.BITURIGES, faction, rc.LEADER, leader_name=leader)
            integrity(state)
            ordinary = predict_battle(state, rc.CARNUTES, faction, rc.ROMANS)
            ambush = predict_battle(state, rc.CARNUTES, faction, rc.ROMANS, is_ambush=True)
            legal = validate_ambush_region(state, rc.CARNUTES, faction, rc.ROMANS)
            assert legal[0] is hidden, (faction, scenario, hidden, sa, legal)
            assert ordinary['inflicted'] == attack and ordinary['taken'] >= attack
            assert ambush['inflicted'] == attack and ambush['taken'] == 0
            alternative = None
            if hidden and sa:
                trial = deepcopy(state)
                alternative = public_alternative(trial, faction, rc.CMD_BATTLE,
                    {'battle_plan': [{'region': rc.CARNUTES, 'target': rc.ROMANS}]},
                    sa=rc.SA_AMBUSH)
                assert count_pieces(trial, rc.CARNUTES, faction, rc.WARBAND) == warbands
                assert count_pieces(trial, rc.CARNUTES, rc.ROMANS, rc.AUXILIA) == auxilia - attack
            bot = execute_bot(state, faction, sa=sa)
            if hidden and sa:
                assert bot['action']['command'] == rc.CMD_BATTLE
                assert bot['action']['sa'] == rc.SA_AMBUSH
                assert bot['action']['sa_regions'] == [rc.CARNUTES]
                assert count_pieces(state, rc.CARNUTES, faction, rc.WARBAND) == warbands
                assert count_pieces(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA) == auxilia - attack
            else:
                assert bot['action']['command'] == rc.CMD_MARCH
            rows.append({'faction': faction, 'scenario': scenario,
                'warbands': warbands, 'roman_auxilia': auxilia,
                'leader_in_adjacent_bituriges': leader, 'hidden': hidden,
                'special_ability_allowed': sa, 'ambush_legal': legal,
                'ordinary_forecast': ordinary, 'ambush_forecast': ambush,
                'expected_command': rc.CMD_BATTLE if hidden and sa else rc.CMD_MARCH,
                'bot': bot, 'public_legal_ambush': alternative})
    return rows


def raid_cases():
    rows = []
    for faction in (rc.BELGAE, rc.ARVERNI, rc.AEDUI, rc.GERMANS):
        scenario = rc.SCENARIO_ARIOVISTUS if faction == rc.GERMANS else rc.SCENARIO_GREAT_REVOLT
        for capability in (False, True):
            state = board(scenario, seed=1, resources=0, sa=False)
            place_piece(state, rc.CARNUTES, faction, rc.WARBAND, 3)
            place_piece(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA, 4,
                        piece_state=rc.REVEALED)
            if capability:
                activate_capability(state, 8, rc.EVENT_SHADED)
                set_capability_owner(state, 8, faction)
            integrity(state)
            capacity = max_raiders_per_region(state, faction)
            assert capacity == (3 if capability else 2)
            trial = deepcopy(state)
            alternative = public_alternative(trial, faction, rc.CMD_RAID,
                {'raid_plan': [{'region': rc.CARNUTES, 'target': None}] * capacity})
            assert trial['resources'][faction] == capacity
            assert count_pieces_by_state(trial, rc.CARNUTES, faction, rc.WARBAND, rc.HIDDEN) == 3 - capacity
            bot = execute_bot(state, faction, sa=False)
            assert bot['action']['command'] == rc.CMD_RAID
            assert state['resources'][faction] == capacity
            assert count_pieces_by_state(state, rc.CARNUTES, faction, rc.WARBAND, rc.HIDDEN) == 3 - capacity
            rows.append({'faction': faction, 'scenario': scenario,
                'owns_shaded_baggage_trains': capability,
                'legal_capacity_and_expected_gain': capacity,
                'observed_gain': state['resources'][faction], 'remaining_hidden': 3 - capacity,
                'bot': bot, 'public_maximum_raid': alternative})
    return rows


if __name__ == '__main__':
    result = {'repair_parent': 'a0f58ad97b6b9fd38a64472f6e8747609f78be2e',
              'cases': 17, 'NP7-01': ambush_cases(), 'NP7-02': raid_cases(),
              'inventory_and_structure': 'Every pre/post witness and control passed',
              'fixture_limits': 'Constructed lawful sparse boards; not sampled-game incidence'}
    print(json.dumps(result, indent=2, sort_keys=True, default=lambda item: sorted(item)))
