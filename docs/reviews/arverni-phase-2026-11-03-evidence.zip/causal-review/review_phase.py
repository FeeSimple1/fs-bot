"""Capture changed-outcome games and compare their first live divergence.

No game runs without --run. Parent output may be reused only after exact
Python byte provenance is established independently by the matrix preflight.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
PARENT_SHA = 'cdd29718dab7ea7443f93dc225f192e3f31751aaa84c4e6e56d617a2b6c7b63c'
IGNORED = {'seconds', 'source_sha256', 'commit'}


def records(path):
    return {(row['scenario'], row['seed']): row for row in
            map(json.loads, path.read_text().splitlines())}


def semantic(record):
    return {key: value for key, value in record.items() if key not in IGNORED}


def trace(path):
    with gzip.open(path / 'trace.jsonl.gz', 'rt') as handle:
        return [json.loads(line) for line in handle]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate-records', type=Path, required=True)
    parser.add_argument('--candidate-sha', required=True)
    parser.add_argument('--parent-records', type=Path, default=ROOT /
        'gallic-event-grants-2026-11-02/attempt3/bots-legacy/games.jsonl')
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    parent = records(args.parent_records)
    candidate = records(args.candidate_records)
    assert len(parent) == len(candidate) == 100 and parent.keys() == candidate.keys()
    assert {row['source_sha256'] for row in parent.values()} == {PARENT_SHA}
    assert {row['source_sha256'] for row in candidate.values()} == {args.candidate_sha}
    changed = sorted(key for key in parent if any(parent[key][field] != candidate[key][field]
                     for field in ('winner', 'cards')))
    base = sorted(key for key in parent if key[0] not in ('Ariovistus', 'The Gallic War'))
    base_differences = [key for key in base if semantic(parent[key]) != semantic(candidate[key])]
    plan = {'candidate_sha256': args.candidate_sha, 'parent_sha256': PARENT_SHA,
            'changed_outcomes': changed, 'base_games': len(base),
            'base_semantic_record_differences': base_differences,
            'parent_records': str(args.parent_records),
            'candidate_records': str(args.candidate_records)}
    print(json.dumps(plan, indent=2), flush=True)
    assert not base_differences, base_differences
    if not args.run:
        return
    out = HERE / args.attempt
    out.mkdir(exist_ok=False)
    (out / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    jobs = []
    for scenario, seed in changed:
        slug = scenario.lower().replace(' ', '-').replace('?', '') + '-' + str(seed)
        for label, repo, sha in [('parent', ROOT / 'fs-arverni-phase-before', PARENT_SHA),
                                 ('candidate', ROOT / 'fs-bot', args.candidate_sha)]:
            path = out / (label + '-' + slug)
            command = [sys.executable, str(HERE / 'capture_phase.py'), '--repo', str(repo),
                       '--scenario', scenario, '--seed', str(seed), '--expected-source', sha,
                       '--out', str(path)]
            jobs.append((scenario, seed, label, path, command))

    def run(job):
        scenario, seed, label, path, command = job
        process = subprocess.run(command, cwd=ROOT / 'fs-bot',
                                 env={**os.environ, 'PYTHONHASHSEED': '0'},
                                 text=True, capture_output=True)
        (out / (path.name + '.log')).write_text(process.stdout + process.stderr)
        return {'scenario': scenario, 'seed': seed, 'label': label,
                'path': str(path), 'command': command, 'exit_code': process.returncode}

    with ThreadPoolExecutor(max_workers=2) as executor:
        launches = list(executor.map(run, jobs))
    (out / 'launches.json').write_text(json.dumps(launches, indent=2) + '\n')
    assert all(job['exit_code'] == 0 for job in launches), launches
    reviews = []
    for scenario, seed in changed:
        paths = {j['label']: Path(j['path']) for j in launches
                 if j['scenario'] == scenario and j['seed'] == seed}
        expected = {'parent': parent[scenario, seed], 'candidate': candidate[scenario, seed]}
        for label, path in paths.items():
            observed = json.loads((path / 'summary.json').read_text())['result']
            assert semantic(observed) == semantic(expected[label]), (scenario, seed, label, 'outcome mismatch')
        a, b = trace(paths['parent']), trace(paths['candidate'])
        first = None
        for old, new in zip(a, b):
            assert (old['stage'], old['card_index'], old['current_card']) == (
                new['stage'], new['card_index'], new['current_card']), (scenario, seed, 'unaligned pre-divergence')
            if any(old[field] != new[field] for field in ('board_sha256', 'rng_sha256')):
                first = {'parent': old, 'candidate': new,
                         'preceding_parent': a[old['index'] - 1] if old['index'] else None,
                         'preceding_candidate': b[new['index'] - 1] if new['index'] else None}
                break
        assert first, (scenario, seed, 'no first divergence')
        old, new = first['parent'], first['candidate']
        before_old, before_new = first['preceding_parent'], first['preceding_candidate']
        explained_boundary = (old['stage'].endswith('-after') and
                              old['stage'].startswith('_arverni_phase_') and
                              before_old['stage'] == old['stage'].replace('-after', '-before') and
                              before_old['board_sha256'] == before_new['board_sha256'] and
                              before_old['rng_sha256'] == before_new['rng_sha256'])
        filename = paths['candidate'].name.removeprefix('candidate-') + '-first-divergence.json'
        (out / filename).write_text(json.dumps(first, indent=2) + '\n')
        reviews.append({'scenario': scenario, 'seed': seed,
                        'first_stage': old['stage'], 'card_index': old['card_index'],
                        'current_card': old['current_card'],
                        'equal_before_board_and_rng': explained_boundary,
                        'semantic_board_changed': old['board_sha256'] != new['board_sha256'],
                        'rng_changed': old['rng_sha256'] != new['rng_sha256'],
                        'parent_result': old.get('result'), 'candidate_result': new.get('result'),
                        'first_divergence_file': filename,
                        'outcome_reproduced': True})
    summary = {**plan, 'captures': len(launches), 'reviews': reviews,
               'all_first_divergences_within_phase': all(r['equal_before_board_and_rng'] for r in reviews),
               'all_traces_match_matrix_records': True,
               'note': 'Boundary attribution requires source review of each recorded result/input; it is not a proof of all later decisions.'}
    (out / 'review-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({'cases': len(reviews), 'all_first_divergences_within_phase':
                      summary['all_first_divergences_within_phase']}), flush=True)
    assert summary['all_first_divergences_within_phase'], reviews


if __name__ == '__main__':
    main()
