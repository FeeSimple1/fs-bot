# Eleventh audit — Event planning and selection

Audited Falling Sky commit `702d60a3754ce94a73ead0d0148d647232ecd816`. Three new medium groups are confirmed. No production source or protected rules changed.

## Method

`probe_events.py` uses production scenario setup, canonical Leader/Tribe piece helpers, public `dispatch_bot_turn`, and public `execute_decision`. Each case checks complete census and structural integrity before/after. Availability checks must leave state and RNG unchanged. Human positive controls demonstrate legal effects without altering production planning; they are controls, not substitute bot witnesses. `results.json` is deterministic JSON.

The final matrix contains six Lucterius natural Events with six explicit-target and six executed non-Event controls; six Assembly natural Events with six explicit-target and six blocked-prerequisite controls; and six Shifting Loyalties Events with six explicit-target controls and twelve public capability acquisitions. Three Loyalties cases intentionally reverse acquisition order as passing controls. All checks pass. This establishes controlled mechanisms, not encounter frequency or exhaustive rules correctness.

## EV11-01 — Shaded Lucterius lacks a complete NP contract

**Expected:** Card Reference lines 181–190 requires restoring the Arverni Successor from the map or Available as named Vercingetorix. Chapter5:52–54 requires carrying out possible text. Chapter8:685–694 checks ineffectiveness before Auto1–4, so the Carnyx does not excuse selecting this Event with named Vercingetorix already present.

**Observed:** On Reconquest and Great Revolt production setups, Available Successors remain off-map and on-map Successors remain Successors after natural NP Event19. Named Vercingetorix also induces a wasted Event. All six executions report success with no material effect. Four explicit destination controls restore the Leader; the two named-Leader controls correctly do nothing. The six matched Event-disabled cases execute ordinary non-Pass Commands.

**Cause and scope:** `execute.py:5984–6029,6585–6625` has no numeric19 target producer. `card_effects.py:905–914` returns on missing `target_region`. `event_eval.py:1176–1177` returns true for the generic placement flag without the prerequisite. Repair both producer and admission for this card, preserving authored human destinations and existing same-Region restoration. This is not a legal optional decline: the printed restoration is mandatory when possible.

**Prior distinction:** BE2-04 repaired explicit shaded Event legality/same-Region restoration, which now passes. Original Lucterius BE-06/07/08 work was unshaded. BE6-03 was numeric56 effectiveness. These absent NP paths are fresh. No unique NP destination is asserted by the human controls. Pax Gallica Spring-box behavior and expansion A19 are excluded.

## EV11-02 — Assembly of Gaul selects nobody to drain

**Expected:** Card Reference518–526 says to drain one or more Gallic Factions when Carnutes qualifies. Roman and Aedui sheets specify enemy choices; Chapter8:69–95 requires implementing those instructions. Expansion ChapterA5:34–36 preserves the meaning of Gallic, so Germans are not legal drain targets.

**Observed:** Six natural Roman/Aedui Event52 choices, with Carnutes Subdued and instructed targets holding Resources, leave all Resources unchanged. Six explicit target lists on identical boards apply the legal drains. Six negative controls canonically ally Carnutes to Arverni and show that the same explicit lists correctly have no effect. Coverage includes Pax Gallica, Great Revolt, Ariovistus and Gallic War.

**Cause and scope:** No numeric52 producer supplies `target_factions`; `card_effects.py:1915–1920` defaults it to an empty list. The bot plan contains the instruction text without the actionable choices. Add a producer and applicability checks for instructed legal targets while preserving the existing Carnutes condition, fixed one-drain-per-Faction behavior and shaded action path. Base targets in the witness are player Arverni/Belgae; expansion targets are player Belgae.

**Prior distinction:** BE2-02 fixed duplicate drain entries. Later Assembly findings concern the shaded free Command and its Special Abilities/March. Human list support does not prove NP list production. No exhaustive zero-Resources or mixed-seat policy claim is made, and base Roman setups that selected Battle first were excluded from Event evidence.

## EV11-03 — Shifting Loyalties uses acquisition order

**Expected:** Roman instructions select a shaded Capability affecting player Arverni/Belgae (base) or Germans/Belgae (expansion), then Romans. Thus active shaded Commius55 affecting player Belgae is selected over beneficial unshaded Titus Labienus12.

**Observed:** In Pax Gallica, Ariovistus and Gallic War, acquiring12 then55 through public Events makes natural Roman Event50 remove12. Acquiring55 then12 makes it remove55. Six explicit `target_capability=55` controls remove55 correctly. This is a wrong-beneficiary choice with a real effect, not a no-op.

**Cause and scope:** No numeric50 NP producer overrides `card_effects.py:1866–1872`, which removes the first active dictionary entry. Add instruction-based selection and appropriate tie handling, preserving human selectors. Other factions and fallback/tie cases need scoped tests; this report establishes only Roman primary priority.

**Prior distinction:** The October capability-selector repair concerned actual-capability CLI menus and legacy A38 display. It did not implement NP printed target priorities. Existing live Trade/Suborn removal timing remains separate and unclaimed.

## Comparator evidence and exclusions

Liberty or Death comparator commit `2991ea279062773548ec390a1da75f3e85381702` was used only for engineering patterns. `lod_ai/bots/base_bot.py:459–505` checks actual handler outcomes on isolated copies, includes queued free operations, and forbids reading future combat RNG. `lod_ai/util/event_audit.py:25–47` records preview and actual outcomes separately and completes evidence after queued operations. These patterns motivated observing the actual public action rather than relying on a flag or instruction string. `docs/audit_event_gain_priorities_cards1_16_21.md` distinguishes working generic selectors from local handlers that bypass printed priorities, motivating the acquisition-order control. No comparator rule supplies Falling Sky authority.

Reviewed source and ledgers include CLAUDE.md, current status, PR-01–13, rounds1–10 and the original human-choice inventory, recent Event repair reports, Event applicability/flags, parameter production and relevant card handlers. Existing repaired numeric56, A51/A69, A40, numeric33, Oppida, Procillus/Divico and Rhenus cases were excluded. Other unproven effect flags, exhausted stocks and full-game statistical impacts remain uncounted. The protected references were read only, and repository status remains clean.

## Reproduction

```sh
PYTHONHASHSEED=0 /workspace/scratch/4aba5bd9b1ab/fs-bot/.venv/bin/python /workspace/scratch/521fc7ecea8c/audit11/events/probe_events.py --repo /workspace/scratch/521fc7ecea8c/falling-sky
```

Use hash seed987 for the determinism comparison. `findings.json` supplies exact rule/code line ranges, controls, distinctions, scopes and evidence paths.
