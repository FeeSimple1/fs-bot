"""Run the fixed Spring placement matrix after an explicitly supplied source freeze.

This scratch runner never edits the repository. A new attempt is mandatory;
subprocess logs and exit statuses are retained even when the attempt fails.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "fs-bot"
PYTHON = ROOT.parent / "fs-test-venv/bin/python"


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest():
    value = hashlib.sha256()
    for path in sorted((REPO / "fs_bot").rglob("*.py")):
        value.update(str(path.relative_to(REPO)).encode() + b"\0" + path.read_bytes())
    return value.hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO)


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def build_jobs(run, workers):
    jobs = []
    for edition, seeds in (("legacy", "1-20"), ("original", "201-205"),
                           ("second-edition", "201-205")):
        name = "bots-" + edition
        jobs.append((name, 0, [str(PYTHON), "-m", "fs_bot.tools.run_batch",
                    "--seeds", seeds, "--card-edition", edition, "--workers",
                    str(workers), "--out", str(run / name)]))
    for hash_seed in (0, 7):
        jobs.append((f"fuzz{hash_seed}", hash_seed, [str(PYTHON), "-m",
                    "fs_bot.tools.player_fuzz", "--seeds", "1-4", "--card-edition",
                    "legacy", "--out", str(run / f"fuzz{hash_seed}.json")]))
        jobs.append((f"census{hash_seed}", hash_seed, [str(PYTHON), "-m",
                    "fs_bot.tools.error_census", "--seeds", "1-5", "--card-edition",
                    "legacy", "--strict", "--out", str(run / f"census{hash_seed}.json")]))
    return jobs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-sha256", required=True,
                        help="exact digest explicitly frozen by the root agent")
    parser.add_argument("--attempt", default="attempt1")
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--parallel", type=int, default=2,
                        help="concurrent remaining jobs after the legacy gate")
    parser.add_argument("--plan-only", action="store_true")
    args = parser.parse_args()
    if args.workers < 1 or args.parallel < 1 or Path(args.attempt).name != args.attempt:
        parser.error("positive workers/parallel and a simple attempt directory are required")
    run = ROOT / args.attempt
    jobs = build_jobs(run, args.workers)
    if args.plan_only:
        print(json.dumps([{"name": n, "PYTHONHASHSEED": str(h), "argv": a,
                           "cwd": str(REPO)} for n, h, a in jobs], indent=2))
        return 0
    if digest() != args.source_sha256:
        parser.error("current Python digest differs from the explicitly frozen digest")
    if run.exists():
        parser.error("attempt directory exists; choose a fresh attempt and preserve prior evidence")
    baseline_bytes = git("show", "HEAD:fs_bot/tools/balance_baseline.json")
    if baseline_bytes != (REPO / "fs_bot/tools/balance_baseline.json").read_bytes():
        parser.error("balance baseline differs from committed baseline")
    commit = git("rev-parse", "HEAD").decode().strip()
    starting = json.loads((ROOT / "starting-source.json").read_text())
    if commit != starting["commit"]:
        parser.error("HEAD differs from this scoped batch starting commit")
    if hashlib.sha256(baseline_bytes).hexdigest() != starting["balance_baseline_sha256"]:
        parser.error("committed balance baseline differs from scoped batch starting baseline")
    dirty = bool(git("status", "--porcelain", "--untracked-files=no").strip()
                 or any(p.endswith(".py") for p in git("ls-files", "--others", "--exclude-standard",
                            "-z", "--", "fs_bot").decode().split("\0")))
    run.mkdir()
    write_json(run / "source.json", {"commit": commit, "dirty": dirty,
                                     "source_sha256": args.source_sha256})
    (run / "balance-baseline.json").write_bytes(baseline_bytes)
    write_json(run / "freeze.json", {
        "recorded_utc": utc(), "python": platform.python_version(), "python_executable": str(PYTHON),
        "source_sha256": args.source_sha256, "commit": commit,
        "balance_baseline_sha256": hashlib.sha256(baseline_bytes).hexdigest(),
        "balance_band_exact": "3/20", "balance_baseline_updated": False,
        "source_files": {str(p.relative_to(REPO)): hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in sorted((REPO / "fs_bot").rglob("*.py"))},
        "matrix": {"bot_games": 150, "mixed_unique_cases": 20,
                   "mixed_executions_with_replay": 80, "census_unique_cases": 25,
                   "census_executions": 50, "hash_seeds": [0, 7]},
        "jobs": [{"name": n, "hash_seed": h, "argv": a} for n, h, a in jobs]})
    statuses = []

    def frozen():
        return (digest() == args.source_sha256
                and git("rev-parse", "HEAD").decode().strip() == commit
                and (REPO / "fs_bot/tools/balance_baseline.json").read_bytes() == baseline_bytes)

    def execute(job):
        name, hash_seed, argv = job
        status = {"name": name, "argv": argv, "cwd": str(REPO),
                  "environment": {"PYTHONHASHSEED": str(hash_seed), "PYTHONUNBUFFERED": "1"},
                  "started_utc": utc(), "source_sha256_before": digest(),
                  "exit_code": None, "source_changed": False}
        started = time.monotonic()
        path = run / f"{name}.status.json"
        write_json(path, status)
        if (run / "STOP-AFTER-LEGACY").exists() and name != "bots-legacy":
            status.update(exit_code=125, launched=False, error="explicit stop-after-legacy sentinel")
        elif not frozen():
            status.update(source_changed=True, exit_code=125, error="freeze changed before launch")
        else:
            environment = dict(os.environ, PYTHONHASHSEED=str(hash_seed), PYTHONUNBUFFERED="1")
            with (run / f"{name}.log").open("x") as log:
                process = subprocess.Popen(argv, cwd=REPO, env=environment, stdout=log,
                                           stderr=subprocess.STDOUT, start_new_session=True)
                status["pid"] = process.pid
                write_json(path, status)
                while True:
                    try:
                        status["exit_code"] = process.wait(timeout=15)
                        break
                    except subprocess.TimeoutExpired:
                        if not frozen():
                            status["source_changed"] = True
                            os.killpg(process.pid, signal.SIGTERM)
                            try:
                                status["exit_code"] = process.wait(timeout=5)
                            except subprocess.TimeoutExpired:
                                os.killpg(process.pid, signal.SIGKILL)
                                status["exit_code"] = process.wait()
                            break
        status.update(ended_utc=utc(), duration_seconds=time.monotonic() - started,
                      source_sha256_after=digest())
        status["source_changed"] = status["source_changed"] or not frozen()
        write_json(path, status)
        print(f"{name}: exit={status['exit_code']} freeze_ok={not status['source_changed']}", flush=True)
        return status

    # The legacy matrix is an early acceptance gate before spending more games.
    legacy = execute(jobs[0])
    statuses.append(legacy)
    if legacy["exit_code"] == 0 and not legacy["source_changed"] and not (run / "STOP-AFTER-LEGACY").exists():
        with ThreadPoolExecutor(max_workers=args.parallel) as pool:
            futures = [pool.submit(execute, job) for job in jobs[1:]]
            statuses.extend(future.result() for future in as_completed(futures))
    passed = (len(statuses) == len(jobs)
              and all(s["exit_code"] == 0 and not s["source_changed"] for s in statuses)
              and frozen())
    write_json(run / "runner-status.json", {"passed": passed, "ended_utc": utc(),
                                             "jobs": sorted(statuses, key=lambda s: s["name"])})
    print(f"Runner {'PASS' if passed else 'FAIL'}; independent record verification is still required.", flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
