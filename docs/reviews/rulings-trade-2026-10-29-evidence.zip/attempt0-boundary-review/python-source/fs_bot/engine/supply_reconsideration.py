"""Human reconsideration after the actual NP Aedui Supply refusal (§8.6.6).

Recruit is reconsidered before its complete declared action starts. Build is
reconsidered at its own boundary, so an earlier March or Seize stays resolved.
PR-07 fixes the automated answer across all of these choices.
"""
from copy import deepcopy

from fs_bot import rules_consts as rc
from fs_bot.commands.common import CommandError

KIND = 'supply_refusal'
ACK = ('np_aedui_supply_refusal_acknowledged',)
SA_DETAILS = {
    'build_plan', 'scout_plan', 'sa_details', 'diviciacus_sa_regions',
}


def _copy(state):
    result = deepcopy({k: v for k, v in state.items() if k != 'decision_agent'})
    result['_diviciacus_preview'] = True
    return result


def _dependencies(state, action, *, sa_only):
    from fs_bot.engine.recruit_planning import forecast_supply, ANSWERS
    from fs_bot.engine.supply_retry import RECEIPT
    from fs_bot.engine.execute import execute_decision, _execute_build
    sim = _copy(state)
    # Look for the original plan's Supply dependencies. Actual refusals are
    # restored for validation of any replacement, never treated as fresh dice.
    sim.pop('_supply_line_agreements', None)
    sim.pop(ANSWERS, None)
    if '_card_turn' in sim:
        sim['_card_turn'].pop(RECEIPT, None)
    with forecast_supply(sim) as requests:
        if sa_only:
            _execute_build(sim, rc.ROMANS, action)
        else:
            execute_decision(sim, rc.ROMANS, {'player_action': action})
    return [r for r in requests if r['faction'] == rc.AEDUI
            and r['requesting_faction'] == rc.ROMANS]


def _command_projection(action):
    """Fields a replacement SA cannot rewrite after the Command resolved."""
    result = deepcopy(action)
    for key in ('sa', 'sa_regions', 'sa_timing'):
        result.pop(key, None)
    details = result.get('details') or {}
    for key in SA_DETAILS:
        details.pop(key, None)
    result['details'] = details
    return result


def validate_response(state, request, response):
    if type(response) is not dict:
        raise ValueError('Supply refusal needs continue or a replacement action')
    if set(response) == {'continue'} and response['continue'] is True:
        return response
    if set(response) != {'replacement'} or type(response['replacement']) is not dict:
        raise ValueError('Return {continue: true} or {replacement: action}')
    replacement = response['replacement']
    from fs_bot.engine.action_validation import validate_human_structure, command_regions
    from fs_bot.engine.moves import validate_player_action
    sa_only = request['action_type'] == 'special_ability'
    if sa_only:
        if _command_projection(replacement) != _command_projection(request['action']):
            raise ValueError('Rechoosing Build cannot change the preceding Command')
    elif replacement.get('command') not in request['allowed_commands']:
        raise ValueError('Replacement Command is not allowed for this action')
    sa = replacement.get('sa') or 'No SA'
    if sa not in request['allowed_special_abilities']:
        raise ValueError('Replacement Special Ability is not allowed')
    error = validate_human_structure(state, rc.ROMANS, replacement,
                                     limited=request.get('limited', False))
    if error:
        raise ValueError(error)
    allowed = request.get('allowed_regions')
    if allowed is not None:
        from fs_bot.engine.free_actions import _sa_regions
        regions = _sa_regions(replacement) if sa_only else command_regions(replacement)
        if not set(regions).issubset(allowed):
            raise ValueError('Replacement selects a Region outside the action grant')
    if request.get('max_regions') is not None and not sa_only:
        if len(set(command_regions(replacement))) > request['max_regions']:
            raise ValueError('Replacement selects too many Regions')
    if sa_only:
        if sa == 'No SA':
            return response
        from fs_bot.engine.execute import _execute_sa
        result = _execute_sa(_copy(state), rc.ROMANS, replacement)
        if (not isinstance(result, dict) or not result.get('executed')
                or result.get('errors')):
            raise ValueError('Replacement Special Ability has no legal complete effect')
    else:
        valid, result = validate_player_action(state, rc.ROMANS, replacement)
        if not valid or not isinstance(result, dict) or result.get('errors'):
            raise ValueError(f'Replacement Command is not executable: {result}')
    return response


def reconsider(state, faction, action, *, sa_only=False, limited=False, with_sa=True):
    """Return the original or explicitly revised plan, without applying it."""
    from fs_bot.commands.rally import np_aedui_supply_key
    key = np_aedui_supply_key(state, faction, rc.AEDUI)
    if (key is None or state.get('_diviciacus_preview')
            or (action.get('sa') != rc.SA_BUILD if sa_only
                else action.get('command') != rc.CMD_RECRUIT)):
        return action
    agreements = state.get('_supply_line_agreements')
    if agreements is None or agreements.get(ACK):
        return action
    dependencies = _dependencies(state, action, sa_only=sa_only)
    if not dependencies:
        return action
    from fs_bot.engine.supply_retry import resolve_np_supply
    before = state['rng'].getstate()
    answer = agreements.get(key)
    if answer is None:
        answer = resolve_np_supply(state, rc.AEDUI, rc.ROMANS)
        if answer or state['rng'].getstate() != before:
            agreements[key] = answer
    # Only the real 5–6 refusal grants this additional reconsideration.
    # The ordinary >12 refusal remains known during normal plan validation.
    if answer or key not in agreements:
        return action
    from fs_bot.engine.action_validation import compatible_sa
    sas = (['No SA'] if limited or not with_sa else
           [rc.SA_BUILD, rc.SA_SCOUT, rc.SA_BESIEGE, 'No SA'])
    if sa_only:
        sas = [sa for sa in sas if compatible_sa(action['command'], sa)]
    request = {
        'kind': KIND, 'action_type': 'special_ability' if sa_only else 'command',
        'action': deepcopy(action), 'allowed_commands': list(rc.ROMAN_COMMANDS),
        'allowed_special_abilities': sas, 'limited': bool(limited),
        'context': {'host': rc.AEDUI, 'answer': False,
                    'reason': 'Non-player Aedui refused Supply; the same answer applies to this action.'},
    }
    if state.get('_command_region_scope') is not None:
        request['allowed_regions'] = sorted(state['_command_region_scope'])
    if state.get('_command_max_regions') is not None:
        request['max_regions'] = state['_command_max_regions']
    from fs_bot.engine.agent import consult_agent
    response = consult_agent(state, faction, request)
    if response is None:
        return action  # Raw callback's documented default: keep its chosen plan.
    validate_response(state, request, response)
    agreements[ACK] = True
    return deepcopy(response.get('replacement', action))
