"""Record each official fixed-seed balance result without changing its policy."""
import json
from pathlib import Path
import sys
from fs_bot.tools import balance_smoke
from fs_bot.tools.validation_metadata import source_identity

out = Path(sys.argv[1])
records = {}
original = balance_smoke.play_bot_game

def observe(scenario, seed):
    record = original(scenario, seed)
    records[f'{scenario}|{seed}'] = record
    return record

balance_smoke.play_bot_game = observe
status = balance_smoke.main(['--seeds', '1-20'])
out.write_text(json.dumps({'source': source_identity(), 'games': records,
                           'guardrail_exit': status}, indent=2) + '\n')
raise SystemExit(status)
