"""Sixth-audit bot defect witnesses at 86fb0c2.

Run with PYTHONPATH=<fs-bot-root> python probe_bots.py. Assertions describe
observed defects, not post-repair expectations. Controlled sparse, conserved
positions are not claimed to be naturally sampled games. No engine patching.
"""
from copy import deepcopy
import json
from fs_bot import rules_consts as rc
from fs_bot.battle.resolve import resolve_battle
from fs_bot.board.pieces import count_pieces, place_piece
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.bots.roman_bot import _has_roman_threat
from fs_bot.commands.sa_rampage import rampage, validate_rampage_region, validate_rampage_target
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND
from fs_bot.state.state_schema import build_initial_state, check_structural_integrity, validate_state
from fs_bot.tools.seat_session import validate_response


def integrity(state):
    assert validate_state(state) == [], validate_state(state)
    assert check_structural_integrity(state) == [], check_structural_integrity(state)


def board(scenario=rc.SCENARIO_GREAT_REVOLT):
    state = build_initial_state(scenario, seed=6)
    state['non_player_factions'] = {rc.ROMANS, rc.AEDUI, rc.BELGAE,
        rc.GERMANS if scenario in rc.ARIOVISTUS_SCENARIOS else rc.ARVERNI}
    state['can_play_event'] = False
    state['_command_with_sa'] = False
    for faction in state['non_player_factions']:
        state['resources'][faction] = 10
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    integrity(state)
    return state


def battle_board(faction, warbands, auxiliaries, legions=0, leader=None,
                 scenario=rc.SCENARIO_GREAT_REVOLT):
    state = board(scenario)
    place_piece(state, rc.CARNUTES, faction, rc.WARBAND, warbands,
                piece_state=rc.REVEALED)
    if auxiliaries:
        place_piece(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA, auxiliaries,
                    piece_state=rc.REVEALED)
    if legions:
        place_piece(state, rc.CARNUTES, rc.ROMANS, rc.LEGION, legions,
                    from_legions_track=True)
    if leader:
        place_piece(state, rc.CARNUTES, faction, rc.LEADER, leader_name=leader)
    integrity(state)
    return state


def execute_bot(state, faction):
    action = dispatch_bot_turn(state, faction)
    result = execute_decision(state, faction,
        {'action': ACTION_COMMAND, 'bot_action': action})
    assert result.get('executed') and not result.get('errors'), result
    integrity(state)
    return {'action': action, 'execution': result}


def legal_battle(state, faction):
    response = {'action': ACTION_COMMAND, 'player_action': {
        'command': rc.CMD_BATTLE, 'regions': [rc.CARNUTES], 'sa': 'No SA',
        'details': {'battle_plan': [{'region': rc.CARNUTES, 'target': rc.ROMANS}]}}}
    validate_response(state, {'kind': 'turn', 'faction': faction,
                             'options': [ACTION_COMMAND]}, response)
    result = execute_decision(state, faction, response)
    assert result.get('executed') and not result.get('errors'), result
    integrity(state)
    return result


def forecast_case(faction, warbands, auxiliaries, expected_losses,
                  observed_command, *, scenario=rc.SCENARIO_GREAT_REVOLT,
                  leader=None, expected_command=None):
    state = battle_board(faction, warbands, auxiliaries, leader=leader, scenario=scenario)
    witness = deepcopy(state)
    projection = resolve_battle(witness, rc.CARNUTES, faction, rc.ROMANS,
                                retreat_declaration=False)
    integrity(witness)
    actual_losses = (projection['attack']['losses_requested'],
                     projection['counterattack']['losses_requested'])
    assert actual_losses == expected_losses, actual_losses
    alternative = deepcopy(state)
    legal_result = legal_battle(alternative, faction)
    bot = execute_bot(state, faction)
    assert bot['action']['command'] == observed_command
    return {'faction': faction, 'scenario': scenario, 'warbands': warbands,
            'roman_auxilia': auxiliaries, 'leader': leader,
            'source_expected_command': expected_command or observed_command,
            'attack_counterattack': actual_losses,
            'direct_battle': projection, 'bot': bot,
            'legal_alternative_battle': legal_result,
            'alternative_roman_auxilia_after': count_pieces(alternative, rc.CARNUTES, rc.ROMANS, rc.AUXILIA),
            'alternative_attacker_warbands_after': count_pieces(alternative, rc.CARNUTES, faction, rc.WARBAND)}


def forecasts():
    rows = []
    for scenario in (rc.SCENARIO_GREAT_REVOLT, rc.SCENARIO_ARIOVISTUS):
        rows.append(forecast_case(rc.BELGAE, 6, 6, (3, 1), rc.CMD_MARCH,
                                 scenario=scenario, expected_command=rc.CMD_BATTLE))
        rows.append(forecast_case(rc.BELGAE, 6, 4, (3, 0), rc.CMD_BATTLE, scenario=scenario))
        rows.append(forecast_case(rc.BELGAE, 6, 12, (3, 4), rc.CMD_MARCH, scenario=scenario))
    rows.append(forecast_case(rc.ARVERNI, 10, 10, (5, 2), rc.CMD_MARCH,
                             expected_command=rc.CMD_BATTLE))
    rows.append(forecast_case(rc.ARVERNI, 10, 6, (5, 0), rc.CMD_BATTLE))
    rows.append(forecast_case(rc.ARVERNI, 10, 20, (5, 7), rc.CMD_MARCH))
    rows.append(forecast_case(rc.BELGAE, 2, 6, (3, 1), rc.CMD_MARCH,
                             leader=rc.AMBIORIX, expected_command=rc.CMD_BATTLE))
    rows.append(forecast_case(rc.BELGAE, 2, 6, (2, 2), rc.CMD_MARCH,
                             leader=rc.SUCCESSOR))
    return rows


def screened_legion():
    rows = []
    for auxiliaries in (20, 0):
        state = battle_board(rc.ARVERNI, 10, auxiliaries, legions=1)
        witness = deepcopy(state)
        projection = resolve_battle(witness, rc.CARNUTES, rc.ARVERNI, rc.ROMANS,
                                    retreat_declaration=False)
        integrity(witness)
        bot = execute_bot(state, rc.ARVERNI)
        assert bot['action']['command'] == rc.CMD_BATTLE
        assert count_pieces(state, rc.CARNUTES, rc.ROMANS, rc.LEGION) == (1 if auxiliaries else 0)
        if auxiliaries:
            assert projection['attack']['losses_requested'] == 5
            assert projection['counterattack']['losses_requested'] == 8
            assert count_pieces(state, rc.CARNUTES, rc.ARVERNI, rc.WARBAND) == 2
        rows.append({'roman_auxilia': auxiliaries, 'roman_legions': 1,
            'source_expected_command': rc.CMD_MARCH if auxiliaries else rc.CMD_BATTLE,
            'bot': bot, 'direct_battle': projection,
            'legions_after': count_pieces(state, rc.CARNUTES, rc.ROMANS, rc.LEGION),
            'arverni_after': count_pieces(state, rc.CARNUTES, rc.ARVERNI, rc.WARBAND)})
    return rows


def rampage_threats():
    rows = []
    for warbands, auxiliaries, nearby_leader, fort, expected, observed in (
        (3, 2, True, False, True, False),
        (2, 2, True, False, False, False),
        (2, 1, False, False, False, True),
        (2, 1, True, False, True, True),
        (2, 1, True, True, False, True),
    ):
        state = board()
        place_piece(state, rc.CARNUTES, rc.ROMANS, rc.LEGION, 3, from_legions_track=True)
        place_piece(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA, auxiliaries,
                    piece_state=rc.REVEALED)
        place_piece(state, rc.CARNUTES, rc.BELGAE, rc.WARBAND, warbands)
        if nearby_leader:
            place_piece(state, rc.BITURIGES, rc.BELGAE, rc.LEADER, leader_name=rc.AMBIORIX)
        if fort:
            place_piece(state, rc.CARNUTES, rc.ROMANS, rc.FORT)
        integrity(state)
        original = deepcopy(state)
        region_valid = validate_rampage_region(state, rc.CARNUTES)
        target_valid = validate_rampage_target(state, rc.CARNUTES, rc.ROMANS)
        assert _has_roman_threat(state, rc.CARNUTES, state['scenario']) is observed
        bot = execute_bot(state, rc.ROMANS)
        assert bot['action']['command'] == (rc.CMD_BATTLE if observed else rc.CMD_RECRUIT)
        row = {'hidden_belgae': warbands, 'roman_auxilia': auxiliaries,
               'roman_legions': 3, 'nearby_ambiorix': nearby_leader, 'roman_fort': fort,
               'rampage_region_valid': region_valid, 'rampage_target_valid': target_valid,
               'source_expected_threat': expected, 'observed_threat': observed,
               'bot': bot}
        if region_valid[0] and target_valid[0]:
            victims = [{'action': 'remove', 'piece_type': rc.AUXILIA,
                        'piece_state': rc.REVEALED} for _ in range(min(warbands, auxiliaries))]
            victims += [{'action': 'remove', 'piece_type': rc.LEGION}
                        for _ in range(max(0, warbands - auxiliaries))]
            result = rampage(original, rc.CARNUTES, rc.ROMANS, warbands, victims)
            integrity(original)
            assert count_pieces(original, rc.CARNUTES, rc.ROMANS, rc.LEGION) == (2 if expected else 3)
            row['legal_rampage_execution'] = result
            row['roman_legions_after_rampage'] = count_pieces(original, rc.CARNUTES, rc.ROMANS, rc.LEGION)
        rows.append(row)
    return rows


if __name__ == '__main__':
    output = {'NP6-01': forecasts(), 'NP6-02': screened_legion(),
              'NP6-03': rampage_threats(), 'cases': 18,
              'inventory_and_structure': 'passed for every pre/post fixture',
              'no_special_activity_forecasts': True,
              'audited_commit': '86fb0c2d8ddf86a4548a863dc9c9da27d0c708ad'}
    print(json.dumps(output, indent=2, sort_keys=True))
