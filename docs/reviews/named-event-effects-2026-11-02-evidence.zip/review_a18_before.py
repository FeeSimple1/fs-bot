"""Independent pre-repair A18 omission witness; source state uses piece helpers."""
import json
from fs_bot import rules_consts as rc
from fs_bot.state.state_schema import build_initial_state
from fs_bot.board.pieces import place_piece, count_pieces, count_pieces_by_state, get_leader_in_region
from fs_bot.board.control import refresh_all_control
from fs_bot.cards.card_effects import execute_card_A18
state = build_initial_state(rc.SCENARIO_ARIOVISTUS, seed=930)
region=rc.SUGAMBRI
place_piece(state, region, rc.ROMANS, rc.AUXILIA, count=8)
for visibility in (rc.HIDDEN,rc.REVEALED,rc.SCOUTED):
    place_piece(state, region, rc.GERMANS, rc.WARBAND, piece_state=visibility)
place_piece(state, region, rc.GERMANS, rc.SETTLEMENT)
place_piece(state, region, rc.GERMANS, rc.LEADER, leader_name=rc.SUCCESSOR)
refresh_all_control(state)
state['executing_faction']=rc.ROMANS
state['event_params']={'region':region}
before={'pieces':count_pieces(state,region,rc.GERMANS), 'leader':get_leader_in_region(state,region,rc.GERMANS),'scouted':count_pieces_by_state(state,region,rc.GERMANS,rc.WARBAND,rc.SCOUTED)}
execute_card_A18(state,False)
after={'pieces':count_pieces(state,region,rc.GERMANS), 'leader':get_leader_in_region(state,region,rc.GERMANS),'scouted':count_pieces_by_state(state,region,rc.GERMANS,rc.WARBAND,rc.SCOUTED)}
assert before=={'pieces':5,'leader':rc.SUCCESSOR,'scouted':1}
assert after=={'pieces':2,'leader':rc.SUCCESSOR,'scouted':1}
print(json.dumps({'checkpoint':'Pre-repair main2edf53e; expected-defect witness, not desired-behavior regression','region':region,'before':before,'after':after,'expected_after_piece_count':0},indent=2))
