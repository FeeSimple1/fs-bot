"""Verify the paired Winter Campaign repair records against the checked-out source."""

import json
from pathlib import Path
from xml.etree import ElementTree

from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


ROOT = Path(__file__).resolve().parent
PARENT = '21c699a63b0cf5e199dd5750c4abdb3c7d82c5ff'
PARENT_DIGEST = 'dc70177dad775609cf18849dfe3c598be3b00cc892c0787ad4f348ad5f32ccd2'


def load(name):
    return json.loads((ROOT / name).read_text())


def key(row):
    return row['scenario'], row['seed'], row['card_edition']


def tests(name):
    suites = list(ElementTree.parse(ROOT / name).iter('testsuite'))
    return {k: sum(int(s.get(k, 0)) for s in suites)
            for k in ('tests', 'failures', 'errors', 'skipped')}


def batch(path, seeds, edition, digest):
    meta = load(f'{path}/metadata.json')
    assert meta['source_sha256'] == digest and meta['hash_seed'] == 0
    assert set(meta['scenarios']) == set(SCENARIOS)
    assert meta['seeds'] == list(seeds) and meta['card_edition'] == edition
    records = [json.loads(line) for line in (ROOT / path / 'games.jsonl').read_text().splitlines()]
    games = {key(r): r for r in records}
    assert len(games) == len(records) == len(seeds) * len(SCENARIOS)
    assert games.keys() == {(s, n, edition) for s in SCENARIOS for n in seeds}
    for row in records:
        assert row['source_sha256'] == digest
        assert all(row[k] is True for k in ('completed', 'game_completed', 'audit_completed'))
        assert not row.get('error') and not row['errors'] and not row['integrity_findings']
        assert not _outcome_issues(row)
        assert len(row['final_state_sha256']) == 64
        assert all(d['severity'] == 'legal-decline' for d in row['diagnostics'])
        assert all(d['severity'] == 'legal-decline' for d in row['diagnostic_occurrences'])
        assert sum(d['count'] for d in row['diagnostics']) == len(row['diagnostic_occurrences'])
    return games, meta


def compare(old, new):
    fields = ('final_state_sha256', 'cards', 'winters', 'winner', 'termination',
              'ended_on_final_winter', 'diagnostic_occurrences', 'final_ranking')
    assert old.keys() == new.keys()
    differences = {field: [list(k) for k in sorted(new) if new[k][field] != old[k][field]]
                   for field in fields}
    return {'games': len(new), 'interludes': sum(r['interlude_completed'] for r in new.values()),
            'diagnostic_incidents': sum(len(r['diagnostic_occurrences']) for r in new.values()),
            'differences': differences}


def main():
    source = load('source-final.json')
    digest = source['source_sha256']
    assert source['commit'] == PARENT and source['python_files'] == 614
    assert source_identity()['source_sha256'] == digest
    parent_tests, focused, full = (tests(n) for n in ('parent-final.xml', 'focused-final.xml', 'pytest-final.xml'))
    assert parent_tests == dict(tests=9, failures=7, errors=0, skipped=0)
    assert focused == dict(tests=184, failures=0, errors=0, skipped=0)
    assert full == dict(tests=10160, failures=0, errors=0, skipped=0)

    comparisons = {}
    for parent_name, current_name, edition, seeds in (
            ('final-legacy', 'final-legacy', 'legacy', range(1, 21)),
            ('final-second', 'final-second', 'second-edition', range(45, 49))):
        old, old_meta = batch(f'parent/{parent_name}', seeds, edition, PARENT_DIGEST)
        new, new_meta = batch(current_name, seeds, edition, digest)
        assert new_meta['commit'] == PARENT
        outcome = compare(old, new)
        assert not any(outcome['differences'].values()), outcome
        comparisons[edition] = {**outcome, 'parent_run': old_meta}

    for extension in ('json', 'log'):
        assert (ROOT / f'fuzz0-final.{extension}').read_bytes() == (ROOT / f'fuzz987-final.{extension}').read_bytes()
    fuzz = load('fuzz0-final.json')
    parent_fuzz = load('parent/fuzz0-final.json')
    assert fuzz['records'] == parent_fuzz['records']
    assert fuzz['metadata']['source_sha256'] == digest
    assert parent_fuzz['metadata']['source_sha256'] == PARENT_DIGEST
    assert all(fuzz['metadata'][k] for k in ('reactive', 'events', 'replay'))
    expected = {(s, n, 'second-edition') for s in SCENARIOS for n in range(45, 49)}
    assert len(fuzz['records']) == fuzz['games'] == len(expected)
    assert {key(r) for r in fuzz['records']} == expected
    assert all(r['game_completed'] and not r['findings'] for r in fuzz['records'])
    assert not fuzz['hard_findings'] and not fuzz['partial']
    for field in ('human_turns', 'event_turns', 'events_ok'):
        assert fuzz[field] == sum(r[field] for r in fuzz['records'])

    balance = (ROOT / 'balance-final.log').read_text()
    assert 'OK: balance within band (2 winner changes)' in balance
    assert '2 game(s) changed winner: The Gallic War|1, The Gallic War|7' in balance
    print(json.dumps({
        'source': source, 'parent_directed': parent_tests, 'focused': focused, 'full_suite': full,
        'bots': comparisons,
        'mixed': {**{k: fuzz[k] for k in ('games', 'human_turns', 'event_turns', 'events_ok',
                                         'partial', 'hard_findings', 'batch_digest')},
                  'hash_seeds': [0, 987], 'json_and_stdout_match': True,
                  'all_cases_match_parent': True},
        'balance': {'games': 100, 'passed': True, 'band_percentage_points': 15,
                    'winner_changes_since_reviewed_baseline': 2,
                    'winner_changes_in_this_batch': 0},
    }, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
