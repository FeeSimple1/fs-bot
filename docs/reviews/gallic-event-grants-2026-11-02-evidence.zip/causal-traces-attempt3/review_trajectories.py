"""Bounded causal review for frozen attempt3; no source/baseline mutation.

Reuses an attempt2 classification only when the complete final-state digest
and outcome match the frozen attempt3 validation record. Fresh cases use
actual live traces; they are not reconstructed bot decisions from sorted JSON.
"""
from collections import Counter
from copy import deepcopy
import gzip
import hashlib
import json
from pathlib import Path

out = Path(__file__).resolve().parent
evidence = out.parent
workspace = evidence.parent
PARENT = 'c3c3cd4fd4370f4367db759106b7418449bcc0c27b34ceae2e93c014c64b3bf4'
OLD = '67ee7ff3b52b0c639cf29e96397bb237814b6bfe16a863d0966c11e27860b52c'
FINAL = 'cdd29718dab7ea7443f93dc225f192e3f31751aaa84c4e6e56d617a2b6c7b63c'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
outcome = lambda r: {k: r[k] for k in ('winner', 'cards')}
key_game = lambda r: r['scenario'] + '|' + str(r['seed'])
records = lambda p: {key_game(r): r for r in map(json.loads, p.read_text().splitlines())}
parent_path = workspace / 'fuzz-determinism-2026-11-02/bots/games.jsonl'
old_path = evidence / 'attempt2/bots-legacy/games.jsonl'
final_path = evidence / 'attempt3/bots-legacy/games.jsonl'
parent, old, final = [records(p) for p in (parent_path, old_path, final_path)]
baseline_path = workspace / 'fs-bot/fs_bot/tools/balance_baseline.json'
baseline_saved = evidence / 'balance-baseline-before.json'
assert baseline_path.read_bytes() == baseline_saved.read_bytes()
baseline = load(baseline_path)['games']
assert len(parent) == len(old) == len(final) == len(baseline) == 100
assert all(r['completed'] for r in final.values())
plan = load(out / 'trace-plan.json')
changed = [k for k in parent if outcome(parent[k]) != outcome(final[k])]
assert changed == plan['parent_changed_outcome_pairs'] and len(changed) == 23
prior_path = evidence / 'causal-traces-final/review-summary.json'
prior = load(prior_path)
prior_rows = {r['game']: r for r in prior['reviews']}
prior_integrity = {r['path']: r['sha256'] for r in prior['trace_integrity']}
retreat = load(out / 'retreat-exposure.json')
assert retreat['source_sha256'] == FINAL


def slug(name):
    scenario, seed = name.rsplit('|', 1)
    return scenario.lower().replace(' ', '-').replace('?', '') + '-' + seed


def checkpoint(row):
    return {k: row[k] for k in ('index', 'card_index', 'card', 'stage',
                                'faction', 'region', 'attacker') if k in row}


def board(row):
    result = {k: v for k, v in row['board'].items() if k != '_card_turn'}
    if 'event_modifiers' in result:
        result['event_modifiers'] = {k: v for k, v in result['event_modifiers'].items()
                                     if k != 'card_67_target_regions'}
    return result


def choice(row):
    if row['stage'] == 'retreat-after':
        return {'retreat_response': row['result']}
    return {k: v for k, v in row.get('decision', {}).items() if k != 'execution'}


files = []


def load_trace(name, label, source, expected_records):
    path = out / f'{label}-{slug(name)}.jsonl.gz'
    meta_path = out / f'{label}-{slug(name)}-summary.json'
    meta = load(meta_path)
    assert meta['source']['source_sha256'] == source
    assert meta['python'] == '3.10.22' and meta['hash_seed'] == '0'
    with gzip.open(path, 'rt') as stream:
        rows = [json.loads(line) for line in stream]
    assert len(rows) == meta['checkpoints']
    assert [r['index'] for r in rows] == list(range(len(rows)))
    assert outcome(meta) == outcome(expected_records[name])
    files.append({'path': str(path.relative_to(evidence)), 'sha256': sha(path),
                  'bytes': path.stat().st_size, 'checkpoints': len(rows),
                  'summary_sha256': sha(meta_path), 'source_sha256': source})
    return rows


def first_difference(name, left, right):
    first_annotation = None
    for index, (a, b) in enumerate(zip(left, right)):
        assert checkpoint(a) == checkpoint(b), (name, index, 'unaligned prefix')
        if first_annotation is None and a != b:
            first_annotation = checkpoint(a)
        if board(a) != board(b) or a['rng'] != b['rng'] or choice(a) != choice(b):
            assert index > 0
            previous_a, previous_b = left[index - 1], right[index - 1]
            assert board(previous_a) == board(previous_b)
            assert previous_a['rng'] == previous_b['rng']
            result = {'checkpoint': checkpoint(a),
                'matching_meaningful_prefix_checkpoints': index,
                'prior_raw_board_equal': previous_a['board'] == previous_b['board'],
                'prior_meaningful_board_equal': True, 'prior_rng_equal': True,
                'post_meaningful_board_equal': board(a) == board(b),
                'post_rng_equal': a['rng'] == b['rng'],
                'parent_choice': choice(a), 'candidate_choice': choice(b)}
            assert result['post_meaningful_board_equal'] and result['post_rng_equal']
            if a['stage'] == 'retreat-after':
                metrics = retreat['cases'][slug(name)]
                assert metrics['checkpoint_index'] == a['index']
                result.update(classification='roman_retreat_legion_exposure', status='intended',
                    explanation='Parent retreated whenever Romans had Legions and positive incoming Losses. Candidate correctly stays when Retreat does not lower forced Legion Loss rolls and neither other Retreat condition applies.',
                    authority=['Chapter 8, 8.4.3 second bullet', 'Chapter 8, 8.4.1 loss priorities'],
                    exact_exposure=metrics)
            else:
                assert a['card'] == 68 and a['faction'] == 'Belgae'
                owner = a['board']['tribes']['Remi']['allied_faction']
                assert owner != 'Belgae'
                assert a['decision']['bot_action']['command'] == 'Event'
                assert b['decision']['bot_action']['command'] == 'Rally'
                result.update(classification='remi_beneficiary_eligibility', status='intended',
                    explanation='Belgae decline shaded Remi Influence because the beneficiary must be the Gallic owner of Remi. Parent selected this ineffective Event; candidate follows Rally with Enlist.',
                    authority=['Card Reference 68', 'Chapter 8, 8.2.3',
                               'Belgae Event Instructions, Remi Influence'], remi_owner=owner)
            snapshot = out / f'first-semantic-{slug(name)}.json'
            expected = {'parent': a, 'candidate': b}
            # Existing capture snapshots must match; do not silently overwrite.
            assert load(snapshot) == expected
            result['first_checkpoint_snapshot'] = str(snapshot.relative_to(evidence))
            result['first_checkpoint_snapshot_sha256'] = sha(snapshot)
            return result, first_annotation
    raise AssertionError((name, 'expected a meaningful first difference'))


reviews = []
for name in changed:
    common = {'game': name, 'older_baseline': baseline[name],
              'parent': outcome(parent[name]), 'candidate': outcome(final[name]),
              'candidate_final_state_sha256': final[name]['final_state_sha256']}
    if name in plan['reused_attempt2_pairs']:
        old_review = prior_rows[name]
        assert old_review['first_meaningful_difference']['status'] == 'intended'
        assert old[name]['final_state_sha256'] == final[name]['final_state_sha256']
        assert outcome(old[name]) == outcome(final[name]) == old_review['candidate']
        assert outcome(parent[name]) == old_review['parent']
        references = []
        for field in ('parent_trace', 'candidate_trace'):
            path = old_review[field]
            assert sha(evidence / path) == prior_integrity[path]
            references.append({'path': path, 'sha256': prior_integrity[path]})
        reviews.append({**common, 'method': 'reuse_exact_final_state_hash',
            'provenance': {'review': str(prior_path.relative_to(evidence)),
                'review_sha256': sha(prior_path), 'reviewed_source_sha256': OLD,
                'attempt3_source_sha256': FINAL,
                'attempt2_final_state_sha256': old[name]['final_state_sha256'],
                'attempt3_final_state_sha256': final[name]['final_state_sha256'],
                'same_outcome': True, 'same_complete_final_state_digest': True,
                'trace_references': references,
                'limitation': 'Historical source67ee7ff traces remain labelled attempt2. Exact final-state equality permits reuse of the cleared classification; it is not a claim that every internal checkpoint is identical under attempt3.'},
            'first_meaningful_difference': deepcopy(old_review['first_meaningful_difference'])})
    else:
        left = load_trace(name, 'parent-e37b965', PARENT, parent)
        right = load_trace(name, 'candidate-cdd2971', FINAL, final)
        first, annotation = first_difference(name, left, right)
        reviews.append({**common, 'method': 'fresh_live_paired_trace',
            'parent_trace': f'causal-traces-attempt3/parent-e37b965-{slug(name)}.jsonl.gz',
            'candidate_trace': f'causal-traces-attempt3/candidate-cdd2971-{slug(name)}.jsonl.gz',
            'first_annotation_difference': annotation, 'first_meaningful_difference': first})

# Previously blocked attempt2 GR6 control. Its corrected initial Nervii pool
# now produces the parent's movement and Battle. Explicit beneficiary plumbing
# appears only during the nested Battle and is restored after the Event.
name = plan['additional_repair_control']
left = load_trace(name, 'parent-e37b965', PARENT, parent)
right = load_trace(name, 'candidate-cdd2971', FINAL, final)
assert len(left) == len(right) == 453
transient = []
for index, (a, b) in enumerate(zip(left, right)):
    assert checkpoint(a) == checkpoint(b)
    assert a['rng'] == b['rng'] and choice(a) == choice(b)
    x, y = board(a), board(b)
    if x != y:
        assert index in (361, 362) and a['card'] == 67
        assert a['stage'] in ('retreat-before', 'retreat-after')
        assert x.pop('event_params') == {} and y.pop('event_params') == {'faction': 'Belgae'}
        assert x == y
        transient.append({'checkpoint': checkpoint(a), 'parent': {}, 'candidate': {'faction': 'Belgae'}})
assert len(transient) == 2
for rows in (left, right):
    before, after = rows[360]['board'], rows[361]['board']
    for region, first, last in [('Nervii', 5, 0), ('Treveri', 0, 5)]:
        assert before['spaces'][region]['pieces']['Belgae']['Hidden']['Warband'] == first
        assert after['spaces'][region]['pieces']['Belgae']['Hidden']['Warband'] == last
    battles = rows[363]['result']['free_actions'][1]['result']['battles_resolved']
    assert battles == [{'__tuple__': ['Treveri', 'Romans']}]
assert outcome(parent[name]) == outcome(final[name]) == {'winner': 'Romans', 'cards': 43}
control = {'game': name, 'status': 'repaired', 'checkpoints': 453,
    'parent': outcome(parent[name]), 'attempt2': outcome(old[name]), 'candidate': outcome(final[name]),
    'former_blocker': 'unsourced_target_origin_exclusion',
    'explanation': 'At card ordinal35, numeric67 moves the five original Nervii Belgic Warbands to Treveri and Battles Romans, matching the parent. Attempt2 incorrectly excluded target Regions as initial origins. All board/RNG/choice checkpoints now match after documented receipt/write-only-marker normalization and two explicit beneficiary parameter entries during Battle.',
    'authority': ['Card Reference 67 Tips', 'Chapter 3, 3.3.2'],
    'transient_parameter_entries': transient, 'all_rng_and_choices_equal': True,
    'all_post_event_board_states_equal_after_normalization': True}

previous_path = workspace / 'named-event-effects-2026-11-02/causal-review/causal-review.json'
previous = {key_game(r): r for r in load(previous_path)['pairs']}
inherited_keys = {k for k in baseline if baseline[k] != outcome(parent[k])}
assert inherited_keys == set(previous) and len(inherited_keys) == 16
for name in inherited_keys:
    assert baseline[name] == previous[name]['before_outcome']
    assert outcome(parent[name]) == previous[name]['after_outcome']

baseline_review = []
for name in sorted(baseline):
    a, p, c = baseline[name], outcome(parent[name]), outcome(final[name])
    if a == p == c:
        continue
    category = ('inherited_only' if p == c else 'new_only' if a == p
                else 'cancelled_prior_drift' if a == c else 'overlap_prior_and_new')
    baseline_review.append({'game': name, 'category': category,
        'older_baseline': a, 'parent': p, 'candidate': c,
        'differs_from_stored_baseline': a != c,
        'winner_changed_vs_baseline': a['winner'] != c['winner'],
        'cards_changed_vs_baseline': a['cards'] != c['cards'],
        'new_review_game': name if p != c else None,
        'prior_review': ({'report': 'docs/reviews/named-event-effects-2026-11-02.md',
                         'machine_report': 'docs/reviews/named-event-effects-2026-11-02-results.json',
                         'evidence': str(previous_path.relative_to(workspace)),
                         'evidence_sha256': sha(previous_path),
                         'cause_code': previous[name]['cause_code'],
                         'before_and_after_outcomes_verified': True} if a != p else None)})
stored_diffs = load(evidence / 'attempt3/stored-baseline-differences.json')
assert {key_game(r) for r in stored_diffs} == {r['game'] for r in baseline_review if r['differs_from_stored_baseline']}
for row in stored_diffs:
    assert row['before'] == baseline[key_game(row)]
    assert row['after'] == outcome(final[key_game(row)])

rejected = load(out / 'capture-integrity-failures.json')
for row in rejected:
    path = out / 'failed-captures' / row['file']
    assert sha(path) == row['sha256']
    row['retained_path'] = str(path.relative_to(evidence))
    row['retained_bytes'] = path.stat().st_size
    row['status'] = 'rejected_truncated_capture; retained; successful top-level recapture verified separately'

counts = {'matrix_records_compared': 100, 'changed_parent_outcome_records': 23,
    'reviewed_and_cleared_parent_outcome_records': len(reviews), 'blocked_parent_outcome_records': 0,
    'fresh_review_pairs': len(plan['fresh_pairs']), 'reused_attempt2_reviews': len(plan['reused_attempt2_pairs']),
    'additional_repair_control_pairs': 1, 'fresh_trace_pairs': len(files) // 2,
    'verified_fresh_trace_files': len(files),
    'first_cause_categories': dict(Counter(r['first_meaningful_difference']['classification'] for r in reviews)),
    'baseline_categories_including_cancellations': dict(Counter(r['category'] for r in baseline_review)),
    'stored_baseline_different_records': sum(r['differs_from_stored_baseline'] for r in baseline_review),
    'stored_baseline_winner_changes': sum(r['winner_changed_vs_baseline'] for r in baseline_review),
    'stored_baseline_card_count_changes': sum(r['cards_changed_vs_baseline'] for r in baseline_review)}
assert counts['stored_baseline_different_records'] == 28
summary = {'status': 'complete; all23 changed-parent outcome records have a cleared first-divergence review; former GR6 blocker repaired',
    'baseline_refresh': False, 'baseline_file_changed': False,
    'source': {'parent_commit': 'e37b965e5ce420e29e486c7221661e51b9803282',
               'parent_sha256': PARENT, 'candidate_sha256': FINAL,
               'historical_reused_attempt2_sha256': OLD},
    'runtime': {'python': '3.10.22', 'PYTHONHASHSEED': 0, 'parallel_games': 1},
    'baseline_sha256': sha(baseline_path), 'counts': counts,
    'input_integrity': [{'path': str(p.relative_to(workspace)), 'sha256': sha(p)}
        for p in (parent_path, old_path, final_path, baseline_path, baseline_saved,
                  prior_path, out / 'retreat-exposure.json')],
    'normalization': ['Ignore _card_turn and decision.execution attached receipts, preserving them in raw traces.',
        'Ignore write-only legacy event_modifiers.card_67_target_regions cleanup; parent source has one assignment and no reader.',
        'Compare retreat-after returned response as a decision even if board and RNG remain equal.',
        'GR6 control only: two nested Battle checkpoints explicitly carry faction=Belgae where parent defaults to that same executor; verify exact entries, restored Event boundary, and all actual boards/choices/RNG.'],
    'method_limits': ['A first intended difference does not prove that correction alone caused every later action or the eventual winner.',
        '15 prior reviews are reused solely after exact final-state hash and outcome equality; their traces remain historical attempt2 evidence.',
        'Prior16 old-baseline drifts reuse the independently reviewed named-event evidence; the complete16 before/after outcome set is verified against this immediate parent.',
        'Sorted diagnostic JSON is used only for inspection and comparisons; the six detached loss-arithmetic checks do not replay bot decisions from reordered maps.',
        'One attempt3 GR6 candidate compressed trace was truncated despite a successful summary. Original failed bytes and summary are retained; the recapture reproduces the matrix outcome and passes gzip/checkpoint checks.',
        'Historical attempt2 GR5 capture limitation remains disclosed in its superseded review; its rejected compressed bytes were not retained.'],
    'reviews': reviews, 'repair_control': control,
    'baseline_record_classification': baseline_review, 'trace_integrity': files,
    'rejected_capture_evidence': rejected}
(out / 'review-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'status': summary['status'], 'counts': counts}, indent=2))
