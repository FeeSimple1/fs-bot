# Bot partition, seventh comparison audit

Audited c67d501711471bf790d805c017c2125b2c254639. Read CLAUDE.md, all thirteen provisional rulings, relevant supplied base and Ariovistus rules, previous comparison ledgers (21/15/16/11/14), original human-choice audit inventory, comparator coin-implementation-lessons.md and docs/audit_set_but_never_applied_s76.md at 2991ea279062773548ec390a1da75f3e85381702. Comparator provided engineering patterns only.

Confirmed two root-cause groups, both medium: NP7-01 Ambush omitted before candidate rejection (three bots); NP7-02 third Baggage Trains Raider omitted in ordinary planning (four bots). `probe_bots.py` runs17 matched bot cases and eleven legal authored alternatives, with explicit board/pool/structure checks. Actual entrypoints are dispatch_bot_turn and execute_decision; alternatives also use durable response shape validation. Assertions describe current observed defects. No engine patches, monkeypatches or direct physical piece-count edits.

The Raid finding rests on 8.1.3 and8.3 maximal execution of each priority as well as card8 capacity. It does not infer a mandatory choice for human players from the card's word 'may'.

Excluded/held exploration:
- German named Leader versus Successor flowchart treatment: not counted without resolving full source context and public witness.
- German Rally add-Control estimate using one prospective Warband: static lead only, not counted.
- A31/Abatis calculator uses a raw marker when testing Ariovistus doubling, while the canonical Attack resolver uses effective Abatis. A straightforward Roman threat witness is invalid because Romans cannot acquire Abatis and Ariovistus independently triggers R1. No proven public consequence here; not counted. Primary German offensive forecast calls corrected resolver.
- An attempted expansion Belgic Ambush fixture used named Ambiorix in Ariovistus; canonical placement correctly produces Successor so adjacent-Leader Ambush is illegal. Discarded from final cases; three proper base/expansion faction cases retained. This was a fixture error, not an engine finding.

Coverage is bounded, not an exhaustive scan or sampled incidence estimate. No production changes.
