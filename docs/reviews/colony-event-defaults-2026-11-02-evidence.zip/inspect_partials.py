"""Diagnose existing soft partial counts without changing the fuzzer or engine."""
from collections import Counter
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'fs-bot'
sys.path.insert(0, str(REPO))
from fs_bot.tools import player_fuzz as fuzz

parser = argparse.ArgumentParser()
parser.add_argument('scenario')
parser.add_argument('seed', type=int)
parser.add_argument('--out', required=True)
args = parser.parse_args()

def manifest():
    return {str(p.relative_to(REPO)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((REPO / 'fs_bot').rglob('*.py'))}

before = manifest()
partials = []
original = fuzz._compare_dry_vs_live

def compare(res, seats, expected):
    counts = Counter()
    for cr in (res or {}).get('card_results', ()):
        for faction, record in ((cr.get('turn_result') or {}).get('actions_taken') or {}).items():
            if faction not in seats:
                continue
            key = (cr.get('card'), faction)
            occurrence = counts[key]
            counts[key] += 1
            wanted = expected.get(key + (occurrence,))
            actual = fuzz._sig(record.get('execution'))
            if actual is not None and actual == wanted and (wanted[3] or (wanted[4] and wanted[4][1])):
                partials.append({'card': cr.get('card'), 'faction': faction,
                                 'occurrence': occurrence, 'expected_signature': wanted,
                                 'actual_signature': actual, 'record': record})
    return original(res, seats, expected)

fuzz._compare_dry_vs_live = compare
result = fuzz.play_game(args.scenario, args.seed)
assert before == manifest(), 'Production source changed during partial diagnostic'
assert len(partials) == result['partial']
out = {'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
       'source_files': before, 'source_unchanged': True, 'game': result,
       'partials': fuzz._sanitize(partials)}
Path(args.out).write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'game': result, 'partials': fuzz._sanitize(partials)}, indent=2))
