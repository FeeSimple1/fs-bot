# Independent review of twelfth-audit witnesses

All seven finding groups are confirmed on the audited revision. Six finalized probe scripts were copied into the reviewer directory and independently executed at hash seeds 0 and 987. Each output is byte-identical to its other hash-seed run and the author’s preserved result. The JSON review records exact script and result hashes.

**EV12-01**. Sappers target and admission errors confirmed by seven natural wrong-target and two empty-Event witnesses; supplied Roman/Aedui per-card priorities and explicit controls agree.

**EV12-02**. Drought wrong-region selection confirmed by twelve natural dispatch witnesses and exact-target controls across base and expansion instructions.

**BM12-01**. Seventeen-case finalized probe confirms omitted Slingers in three ordinary bot forecast gates; public casualty choices prove opening Leader Loss, with six absent-Capability, three surviving-force and two Stalwart controls.

**NP12-01**. Aedui three-destination plan collapses to one three-Warband move, while the explicit three-group control satisfies 8.6.5 at identical Resource cost.

**NP12-02**. Aedui March cost makes Trade required and profitable, but initial No SA suppresses post-Command evaluation; exact movement with opened live SA gate gains 12 Resources.

**LC12-01**. NP Cisalpina fallback chooses removal of three Legions despite an unrestricted legal Home destination. Complete §8.4 maximum-action and move-own guidelines support preserving the force, and the legal human allocation enables the explicitly required expedition.

**LC12-02**. Within the same Mandubii Region, NP Belgae/Romans remove the Alesia City Ally before Senones ordinary Ally. The reverse §8.4.1 priority and physical tribe mapping agree with the human exact-removal control.

The four frontend Build and Scout controls pass in base and expansion scenarios. Their planning state/RNG and serialized replay checks pass. No new frontend finding is claimed.

LC12-01 uses the complete maximum-action and move-own guidelines, alongside the scenario’s legal Home relocation and expedition instruction. The voluntary-removal parenthetical is supporting context with a narrower reclamation meaning. LC12-02 is independently established within one Region, so random Region selection and Home-last ordering cannot explain it.

These probes establish failures in constructed legal positions. Fixture setup, Event identity/phase cursors, explicit control modifications and cross-repo comparisons are disclosed in the lane reports.
