"""Round four: Nori survives Interlude as a phantom Subdued Tribe."""
from copy import deepcopy
import json
from fs_bot import rules_consts as rc
from fs_bot.state.setup import setup_scenario
from fs_bot.engine.interlude import run_interlude
from fs_bot.engine.victory import calculate_victory_score
from fs_bot.engine.winter import harvest_phase
from fs_bot.state.state_schema import validate_state,check_structural_integrity
from fs_bot.board.pieces import count_on_map

s=setup_scenario(rc.SCENARIO_GALLIC_WAR,seed=21)
s['non_player_factions']={rc.ROMANS,rc.AEDUI,rc.GERMANS,rc.BELGAE}
assert validate_state(s)==[] and check_structural_integrity(s)==[]
assert len(s['tribes'])==30 and rc.TRIBE_NORI in s['tribes']
assert rc.TRIBE_CATUVELLAUNI not in s['tribes']
before={'tribe_count':len(s['tribes']),'census':validate_state(s),'structure':check_structural_integrity(s)}
result=run_interlude(s,britannia_decision=False)
assert len(s['tribes'])==31
assert rc.TRIBE_NORI in s['tribes'] and rc.TRIBE_CATUVELLAUNI in s['tribes']
assert not s.get('capabilities') and not any(rc.MARKER_COLONY in m for m in s.get('markers',{}).values())
assert s['tribes'][rc.TRIBE_NORI]=={'status':None,'allied_faction':None}
# Chapter7.2 independently defines the physical-piece shortcut (no Colony here).
enemy_structures=sum(count_on_map(s,f,rc.ALLY)+count_on_map(s,f,rc.CITADEL)
                     for f in (rc.ARVERNI,rc.AEDUI,rc.BELGAE,rc.GERMANS))
expected=30-enemy_structures
observed=calculate_victory_score(s,rc.ROMANS)
assert (observed,expected)==(24,23)
s['resources'][rc.ROMANS]=0
harvest=harvest_phase(s)
assert harvest[rc.ROMANS]==24
# Diagnostic one-record correction only, to isolate the source of the extra1.
control=deepcopy(s);control['tribes'].pop(rc.TRIBE_NORI);control['resources'][rc.ROMANS]=0
assert calculate_victory_score(control,rc.ROMANS)==expected
control_harvest=harvest_phase(control)
assert control_harvest[rc.ROMANS]==23
assert validate_state(s)==[] and check_structural_integrity(s)==[]
assert validate_state(control)==[] and check_structural_integrity(control)==[]
print(json.dumps({'before':before,'after_tribes':len(s['tribes']),
                  'phantom_nori':s['tribes'][rc.TRIBE_NORI], 'no_colony':True,
                  'nonroman_structures':enemy_structures,'roman_score':observed,
                  'expected_roman_score':expected,'harvest':harvest[rc.ROMANS],
                  'control_without_nori_harvest':control_harvest[rc.ROMANS],
                  'census':validate_state(s),'structure':check_structural_integrity(s)},indent=2))
