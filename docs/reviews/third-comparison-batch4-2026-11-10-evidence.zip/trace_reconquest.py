"""Observe the first changed game state in Reconquest of Gaul, seed 1."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys

from fs_bot import rules_consts as rc
from fs_bot.engine import game_engine
from fs_bot.state.serialize import encode
from fs_bot.tools.balance_smoke import play_bot_game
from fs_bot.tools.validation_metadata import source_identity

KEYS = ('spaces', 'resources', 'tribes', 'available', 'markers', 'capabilities',
        'eligibility', 'fallen_legions', 'legions_track', 'event_modifiers')


def snapshot(state):
    return {**{k: deepcopy(state[k]) for k in KEYS if k in state},
            'rng': hashlib.sha256(repr(state['rng'].getstate()).encode()).hexdigest()}


def main():
    trace = []
    play = game_engine.play_card

    def observe(state, *args, **kwargs):
        before = snapshot(state)
        card = state['current_card']
        result = play(state, *args, **kwargs)
        trace.append({'card': card, 'before': before, 'after': snapshot(state),
                      'result': deepcopy(result)})
        return result

    game_engine.play_card = observe
    try:
        outcome = play_bot_game(rc.SCENARIO_RECONQUEST, 1)
    finally:
        game_engine.play_card = play
    Path(sys.argv[1]).write_text(json.dumps(encode({
        'source': source_identity(), 'scenario': rc.SCENARIO_RECONQUEST,
        'seed': 1, 'outcome': outcome, 'trace': trace}), indent=2) + '\n')


if __name__ == '__main__':
    main()
