"""Verify eleventh-audit raw evidence without changing or rerunning gameplay."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
from xml.etree import ElementTree

from fs_bot.tools.error_census import _severity
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity

ROOT = Path(__file__).resolve().parent
REPO = Path(__import__('fs_bot').__file__).resolve().parent.parent
COMMIT = '702d60a3754ce94a73ead0d0148d647232ecd816'
SEEDS = list(range(57, 61))


def load(name):
    return json.loads((ROOT / name).read_text())


def write(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2) + '\n')


def main():
    source = load('source.json')
    current = source_identity()
    assert source['commit'] == COMMIT
    assert source['source_sha256'] == current['source_sha256']
    assert source['dirty'] is False
    protected = load('protected-sources.json')
    references = {str(p.relative_to(REPO)) for p in (REPO / 'Reference Documents').rglob('*') if p.is_file()}
    assert len(references) == 47 and len(protected) == 48
    assert set(protected) == references | {'fs_bot/rules_consts.py'}
    assert set((ROOT / 'reference-inventory.txt').read_text().splitlines()) == references
    assert all(hashlib.sha256((REPO / path).read_bytes()).hexdigest() == digest
               for path, digest in protected.items())

    suite, = ElementTree.parse(ROOT / 'pytest.xml').iter('testsuite')
    tests = {key: int(suite.get(key)) for key in ('tests', 'errors', 'failures', 'skipped')}
    assert tests['tests'] == len(list(suite.iter('testcase')))
    assert tests['errors'] == tests['failures'] == tests['skipped'] == 0
    text = (ROOT / 'pytest.log').read_text()
    result = re.search(r'(\d+) passed(?:, (\d+) warnings)? in ([\d.]+)s', text)
    assert result and int(result[1]) == tests['tests']
    canary = [test for test in suite.iter('testcase') if test.get('name') == 'test_bot_balance_canary']
    assert len(canary) == 1 and len(canary[0]) == 0
    tests.update(passed=tests['tests'], seconds=float(suite.get('time')), workers=4,
                 hash_seed=0, log='pytest.log', junit='pytest.xml',
                 warnings=int(result[2] or 0), console_seconds=float(result[3]),
                 canary_passed=True,
                 initial_launcher_failure={'exit_code': 3, 'tests_executed': 0,
                    'log': 'pytest-initial-cache-path-error.log',
                    'cause': 'pytest rejected relative cache_dir before collection; retried with absolute path.'})

    rows = [json.loads(line) for line in (ROOT / 'bots/games.jsonl').read_text().splitlines()]
    meta = load('bots/metadata.json')
    expected = {(scenario, seed) for scenario in SCENARIOS for seed in SEEDS}
    assert len(rows) == len(expected) == 20
    assert {(r['scenario'], r['seed']) for r in rows} == expected
    assert meta['seeds'] == SEEDS and meta['card_edition'] == 'second-edition'
    assert meta['source_sha256'] == source['source_sha256'] and meta['commit'] == COMMIT
    assert meta['dirty'] is False
    diagnostics, message_counts, record_checks = [], Counter(), []
    for row in rows:
        issues = _outcome_issues(row)
        assert row['completed'] and row['game_completed'] and row['audit_completed']
        assert not row['errors'] and not row['integrity_findings'] and not issues
        assert row['source_sha256'] == source['source_sha256']
        assert row['card_edition'] == 'second-edition'
        assert len(row['final_state_sha256']) == 64
        assert len(row['final_ranking']) == len(row['engine_final_ranking']) == 4
        assert not row['engine_ranking_output_missing'] and not row['winner_differs_from_highest_margin']
        for index, d in enumerate(row['diagnostic_occurrences']):
            calculated = _severity(d['kind'], d['message'])
            assert d['severity'] == calculated == 'legal-decline', d
            diagnostics.append(dict(d, index_in_game=index, independently_reclassified=calculated))
            message_counts[d['kind'], d['message'], calculated] += 1
        assert sum(d['count'] for d in row['diagnostics']) == len(row['diagnostic_occurrences'])
        record_checks.append({key: row[key] for key in ('scenario','seed','card_edition','completed',
            'game_completed','audit_completed','errors','integrity_findings','engine_ranking_output_missing',
            'winner_differs_from_highest_margin','winner','ending_scenario','final_state_sha256','interlude_completed')}
            | dict(ranking_issues=issues, diagnostic_occurrences=len(row['diagnostic_occurrences'])))
    write('bot-record-checks.json', record_checks)
    write('diagnostic-review.json', {'occurrences': diagnostics,
        'message_groups': [dict(kind=k[0],message=k[1],severity=k[2],count=v)
                           for k,v in sorted(message_counts.items())]})
    bots = dict(attempted=len(rows), games=len(rows), completed=len(rows), seeds=SEEDS,
                edition='second-edition', scenarios=list(SCENARIOS), errors=0,
                integrity_findings=0, ranking_issues=0,
                interludes=sum(r['interlude_completed'] for r in rows),
                interlude_keys=[[r['scenario'],r['seed']] for r in rows if r['interlude_completed']],
                diagnostic_groups=sum(len(r['diagnostics']) for r in rows),
                diagnostic_occurrences=dict(Counter(d['severity'] for d in diagnostics)))

    for extension in ('json','log'):
        assert (ROOT / f'fuzz0.{extension}').read_bytes() == (ROOT / f'fuzz987.{extension}').read_bytes()
    fuzz = load('fuzz0.json')
    assert fuzz['metadata']['source_sha256'] == source['source_sha256']
    assert fuzz['metadata']['commit'] == COMMIT and fuzz['metadata']['dirty'] is False
    assert fuzz['metadata']['card_edition'] == 'second-edition' and fuzz['metadata']['seeds'] == SEEDS
    assert all(fuzz['metadata'][key] for key in ('reactive','events','replay'))
    assert fuzz['games'] == len(fuzz['records']) == 20 and fuzz['hard_findings'] == 0
    assert {(r['scenario'],r['seed']) for r in fuzz['records']} == expected
    assert all(r['game_completed'] and not r['findings'] and r['digest'] for r in fuzz['records'])
    assert sum(r['partial'] for r in fuzz['records']) == fuzz['partial']
    mixed = {key: fuzz[key] for key in ('games','human_turns','event_turns','events_ok','partial',
                                      'hard_findings','by_kind','batch_digest')}
    mixed.update(seeds=SEEDS,hash_seeds=[0,987],edition='second-edition',attempted=20,completed=20,
                 byte_identical_json=True,byte_identical_stdout=True,replay=True,executions=80,
                 rejected_plans=sum(r['rejected'] for r in fuzz['records']),
                 partial_cases=[r for r in fuzz['records'] if r['partial']],
                 interlude_keys=[[r['scenario'],r['seed']] for r in fuzz['records']
                                 if r['ending_scenario'] != r['scenario']])
    write('mixed-record-checks.json', fuzz['records'])
    summary = dict(source=source,source_identity_at_verification=current,
                   protected_source_hashes_verified=True,pytest=tests,bots=bots,mixed=mixed,
                   balance_note='Full pytest includes the existing 15-game legacy canary (seeds 1–3 across five scenarios, 40-point band). No fresh 100-game 15-point guardrail or baseline refresh was performed; no engine changes were made during this audit.')
    write('summary.json',summary)
    print(json.dumps(summary,indent=2))


if __name__ == '__main__':
    main()
