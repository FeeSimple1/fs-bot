EXP-12, 2 November 2026. Run from repository root.
Interpreter: /workspace/scratch/534c265c65f4/fs-test-venv/bin/python
Baseline: python -m pytest -q -n 6 --junitxml=baseline.xml
Focused: python -m pytest -q fs_bot/tests/test_remove_all_scouted_events.py --tb=short
Final: python -m pytest -q -n 6 --junitxml=reviewed-final.xml
See source.json for parent revision and exact final Python identity.
The before-fix-reviewed.log runs the final regression file with parent card_effects.py; the fixed file was restored immediately afterward.
Earlier fixture and verification attempts are retained separately.
Independent final focused run: 20 passed in 0.69s.
