"""Freeze the bounded pre-final-source causal checkpoint without rerunning games."""
from collections import Counter
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
report=json.loads((root/'first-divergences.json').read_text())
base=json.loads((root/'base-causal-review.json').read_text())
exp=json.loads((root/'exp-first-cause-facts.json').read_text())
replays={label:json.loads((root/f'{label}-first-row-replays.json').read_text()) for label in ('parent','candidate')}
metadata=json.loads((root/'metadata-equivalence.json').read_text())
assert len(report['pairs'])==50 and len(base['pairs'])==20 and len(exp['pairs'])==17
assert all(r['all_earlier_rows_identical'] and r['same_complete_pre_state'] and r['rng']['before_equal'] for r in report['pairs'])
assert all(r['exact_replay'] for r in replays['parent']['replays'])
assert sum(r['exact_replay'] for r in replays['candidate']['replays'])==47
assert all(r['exact_state'] for r in replays['candidate']['replays'])
assert len(metadata['exceptions'])==3
assert all(r['same_following_execution_result'] and r['same_following_full_state_and_rng'] for r in metadata['exceptions'])
summary={'checkpoint':'Pre-final-source causal review; before the separately authorized A30 priority follow-up.',
 'scope':'Exactly50changed parent winner/card pairs from matrix-01;100diagnostic full games. No other full games were run for this causal review.',
 'source':report['source'],
 'source_identity_note':'Parent is committed8db858b. Candidate is prepared uncommitted417-file Python source29f477d5 over BE12commitb17e2f6; it is not falsely identified as HEAD code or as any later final source.',
 'counts':{'pairs':50,'diagnostic_games':100,'winner_changes':40,'card_count_only_changes':10,
           'identical_full_prefix_and_prestate':50,'parent_exact_first_row_replays':50,
           'candidate_exact_first_row_replays':47,'candidate_metadata_only_exceptions':3,
           'candidate_same_complete_poststate_and_rng':50},
 'first_cause_groups':report['groups'],
 'source_reviews':{'base20':'base-causal-review.json','expansion17':'exp-first-cause-review.md',
                   'german_allegiances13':'Independent event_validation_review raw-position review: seven Arverni and three Aedui positions have zero eligible German Warbands/Allies; three Belgae positions have zero eligible German Allies, so its add-Allies/Citadels instruction requires decline.'},
 'rng_note':'23first rows change subsequent RNG, reflecting live equal-candidate choices or newly reached Command planning. All first pre-state/RNGs and prior rows are identical. RNG details and per-call hashes are retained in first-divergences.json and *-first-row-replays.json.',
 'replay_exception_note':'Only three candidate decisions differ in unused nested Trade-region list order after sorted JSON map reload; same Region sets, estimated Resources, action plans, and complete state/RNG. Both variants produce identical following execution results/state/RNG. No production fix or normalization was used to mask comparison.',
 'metadata_equivalence':'metadata-equivalence.json',
 'assessment':'Every first divergence is source-supported and localizes to reviewed Event fixes. No unexplained first cause or gameplay/RNG replay discrepancy remains. This is bounded causal evidence, not a claim that every subsequent move was source-audited or that game winners are explained by a single local effect.',
 'followup':'Root will apply only the A30 Citadel-before-Leader synthetic-priority correction, then compare fresh final validation matrix outcomes/state hashes/mixed/census digests and exact A30 row execution. These traces remain pre-correction evidence; do not relabel them.',
 'baseline_action':'None. Protected baseline and rules unchanged; root owns any later reviewed baseline decision.'}
(root/'causal-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
lines=['# Bounded paired causal review — pre-final-source checkpoint','',
'All **50 changed parent pairs** were traced once per source: **100 diagnostic games**. Every expected winner and card count reproduced. The pairs comprise **40 winner changes** and **10 card-count-only changes**. All 50 earliest differing rows have identical complete earlier traces and identical complete pre-state, including RNG.','',
'The parent is committed `8db858b14cd13856059d42db1ad3931e523b5ed4` (407 Python files; digest `d78d921cdb2db2c60bd433270bca2a80fb92462888610e8199522de41b749797`). The candidate is the archived **prepared, uncommitted** 417-file source `29f477d5382d87fac2abc4fe9e93ff4b8ca7abcfbad08e5bd0abb9bff2dfb9b5`, over tested BE12 commit `b17e2f6d8297501c16288cfd5de04ae61b19a774`. Its code is not identified merely by HEAD. Both source identities were verified before and after tracing.','',
'## First causes','',
'| Event / actor and boundary | Pairs | Source-supported difference |','|---|---:|---|',
'| 42 / Romans execution | 4 | Uses the printed adjacent-Control alternative, removing two Allies where the old deriver did nothing. |',
'| 42 / Belgae execution | 2 | Selects Remi in Belgica before remaining outside-Belgica targets, then applies seeded ties. |',
'| 42 / Aedui decision | 10 | Declines because the specific instruction permits human opponents only and these are bot-only games. |',
'| 42 / Belgae decision | 2 | Declines because there are no assumed-agreement Supply-Line targets. |',
'| 41 / Aedui execution | 2 | Applies City/Ally priorities and actual seeded equal-candidate selections. |',
'| 65 / Arverni decision | 7 | Declines with no eligible German Warbands or Allies in controlled Regions. |',
'| 65 / Aedui decision | 3 | Declines with no eligible German Warbands or Allies in controlled Regions. |',
'| 65 / Belgae decision | 3 | Declines because no German Ally can yield the required added Belgic Ally/Citadel. |',
'| A45 / Aedui decision | 7 | Declines with no legal own Ally placement. |',
'| A43 / Aedui execution | 4 | Performs mandatory Ally/Warband replacements instead of a silent no-op, including required removal-only fallback. |',
'| A36 / Germans execution | 2 | Performs the two Settlements, four Warbands and two Ally removals instead of a silent no-op. |',
'| A29 / Aedui execution | 2 | Places both legal Allies in one Settlement Region instead of incorrectly stopping after one. |',
'| A30 / Aedui execution | 2 | Removes all Arverni in the selected Region instead of a silent no-op. |','',
'All 20 base positions and 17 expansion positions have per-pair source annotations. The independent reviewer also checked all 13 Card65 eligibility predicates from raw Control, German counters and exact Tribes. No unrelated first divergence or unexplained live RNG draw was found. `base-causal-review.json`, `exp-first-cause-review.md`, `exp-first-cause-facts.json` and the Card65 notes retain those receipts.','',
'## Captured-row verification','',
'All **50 parent** first rows replay exactly. **47 candidate** first rows replay exactly. The other three have only a different ordering of `bot_action.details.sa_details.trade_regions` after sorted JSON map decoding: Great Revolt seed4/Card65 and Ariovistus/Gallic War seed11/A45. The Region sets, Resource estimates and action plans are identical; all **50 candidate complete post-decision states and RNGs are identical**.','',
'The three discrepancies were retained, not normalized away. Existing Aedui Trade metadata follows map insertion order, while the executor ignores that plural metadata field and derives its actual Trade selection. Executing both recorded and decoded decisions from the same captured state produced identical complete execution results, state and RNG in all three cases (`metadata-equivalence.json`). No gameplay or RNG save/load drift was demonstrated.','',
'Live random draws change on 23 first rows, owing to actual equal-candidate choices or a newly reached Command flowchart. Full RNG state hashes and draw logs are retained. In Reconquest8/Card41 the immediate board is unchanged but two legal tie selections advance RNG; that is an intentional rules-driven change, not speculative-preview consumption.','',
'## Scope and next checkpoint','',
'These files are **pre-final-source diagnostic evidence**. Review separately found a generic A30 Leader-before-Citadel Region-priority issue in a synthetic configuration. The traced A30 positions have no Arverni Leader and are unaffected. Root will apply the isolated correction and verify a fresh final matrix against this checkpoint; these traces must not be relabeled as final-source executions.','',
'This review establishes the first causal change in each changed game. It does not attribute every later move or winner solely to that first effect, and it is not a new balance study. No production code, authoritative rules or balance baseline was edited by this tracing task. Root retains responsibility for final full-suite validation and any later baseline decision.','',
'## Evidence and reproduction','',
'`trace_games.py` uses the proven state codec and the unchanged balance runner callback, excluding preview boards; only the 50 pairs in `matrix-01/parent-differences.json` are permitted. `summarize_traces.py` verifies each outcome, gzip digest and exact prefix; `replay_first_rows.py` checks captured actions without new games; `check_metadata_equivalence.py` checks only the three subsequent executions. Both runs used Python3.12.14 and `PYTHONHASHSEED=0`. All gzip file hashes and executed source identities are in the two manifests. Failed exploratory serialization and replay attempts are retained separately.','']
(root/'causal-summary.md').write_text('\n'.join(lines))
print(json.dumps({'causal_pairs':50,'first_causes_cleared':True,'safe_to_thaw_for_authorized_followup':True}))
