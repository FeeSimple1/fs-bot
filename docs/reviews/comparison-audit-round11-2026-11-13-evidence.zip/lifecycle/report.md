# Eleventh audit — lifecycle lane

Reviewed clean Falling Sky revision `702d60a3754ce94a73ead0d0148d647232ecd816`. No production edits. One new medium-severity finding is confirmed through 54 full public Winter/Interlude cases. Their output is byte-identical at `PYTHONHASHSEED=0` and `987`; every case has clean pre/post census and structural checks.

## LC11-01 — Interlude gives three extra Arverni Regions an unprinted removal priority

The Gallic War scenario, Adjust Forces, directs random Region-by-Region NP removals (lines 24–29), expressly flags an Arverni exception, and specifies **the Arverni Region last** for Arverni Allies and Warbands (lines 53–60). Cadurci and Volcae Allies have their separately printed optional early exception. Chapter 8 §8.3.4 requires equal-chance selection among equal candidate Regions (lines 163–166). The piece-type priorities in §8.4.1 apply after spaces are selected (179–186), so an existing Ally is not an extra Region-protection rule.

The NP implementation instead creates three priority tiers: all Regions outside the four expansion Arverni Homes; Veneti/Carnutes/Pictones; Arverni. It shuffles only within each tier. `fs_bot/engine/interlude.py:679–686` therefore gives each of the first three Home Regions zero chance of being selected before an ordinary Region whose Warbands already meet the removal quota. `702–703` applies that ordering to the Warband removals. This is stronger than observing a plausible random result on one seed: the extra tier structurally excludes a printed equal candidate.

Every witness starts from real Gallic War setup. All Arverni Warbands are returned to Available using `remove_piece`, then eight are placed as two equal groups of four Hidden Warbands with `place_piece`. All other setup pieces are retained. The third-Winter cursor is supplied (`winter_count=2`, current Winter); every fixture has no threshold winner. Public `run_winter_round` passes its Victory check, performs the complete production Interlude and switches to Pax Gallica. Human Rome explicitly declines the later Britannia expedition; the German seat is NP except for the explicit-choice controls. No private reducer is invoked by the probe.

| Cases | Expected boundary | Observed |
|---|---|---|
| Veneti4 / Sequani4, seeds 1–12 | Both are ordinary candidates before Arverni Region | Sequani loses all four in 12/12; Veneti always retains four |
| Carnutes4 / Sequani4, seeds 1–12 | Same | Sequani loses all four in 12/12; Carnutes always retains four |
| Pictones4 / Sequani4, seeds 1–12 | Same | Sequani loses all four in 12/12; Pictones always retains four |
| Mandubii4 / Sequani4, seeds 1–12 | Random choice among ordinary Regions | Mandubii removed in 7 cases, Sequani in 5 |
| Arverni4 / Sequani4, seeds 1–3 | Printed Arverni-last priority | Sequani removed; Arverni retains four |
| Human German removes Veneti, Carnutes or Pictones first, seed 1 | Each is a legal non-Arverni-Region selection | All three public Interludes accept it; selected Region loses four, Sequani retains four |

The human control also demonstrates that the shared authored legality understands the scenario's narrower priority: `fs_bot/engine/interlude_reductions.py:23–24` uses the base Arverni Home set, and lines 79–85 permit these cohorts. This corroborates the source but is not itself the source of the expected behavior.

Impact: a non-player German/Arverni seat systematically preserves troops in western expansion Homes at the expense of equally eligible Regions elsewhere, changing the second-half board. Repair the NP reduction tier to match the scenario-specific Arverni-last instruction while preserving the Cadurci/Volcae Ally exception, quotas, piece priorities and seeded selection among ties. Do not change normal Ariovistus Rally/At War Home definitions.

This is distinct from WS5-01's home-City restoration collateral removal, WS7-01's Quarters planner wiring, LC9-01's Roman Quarters payments and LC10-01's adjacent Provincia permission. Earlier Interlude human-choice work introduced the correct narrower authored cohort legality but preserved the old NP ordering. No prior round 1–10 finding records these extra protected NP reduction tiers.

## Engineering comparison

Inspected actual `lod-bot` revision `2991ea279062773548ec390a1da75f3e85381702`, `lod_ai/bots/random_spaces.py:150–192`. Its `pick_by_priority` takes explicit substantive priority keys, groups equal keys and resolves random selection within those groups (170–190). The transferable engineering lesson is to make the stage's priority keys explicit and share them between human legality and NP selection; a generic scenario Home classification should not silently add another key. LOD's rules, random-spaces table and project rulings are not Falling Sky authorities and are not proposed for transplantation.

## Other boundaries inspected

- Checked the repaired adjacent/supply Provincia distinction and stable Supply declarations against tenth-batch notes; no reopened group counted.
- Reviewed first-Pax/first-post-Interlude Winter skips, Harvest-box release, Senate exceptions, Spring unlock/marker cleanup, eligibility reset and finality. Previously repaired seventh–tenth groups and the open Optimates ordinal question were excluded.
- Reviewed Interlude German permanent removals and Settlement conversion, Citadel downgrades, home-City restoration, Cisalpina relocation, Britannia allocation, Resource/seat conversion and deck rebuilding. Settlement-control staleness was rejected because canonical piece helpers refresh Control after removals.
- Reviewed automatic German/Arverni phase entry and Rally/March/Raid/Battle boundaries. No additional new lifecycle witness established.
- Inspected Winter Campaign's paid action budget and Special Ability execution. No new source-backed defect established in this lane.
- No new claims about dormant A63 ownership, Aedui subsidy timing, Circumvallation persistence, negative Roman Harvest interpretation, or source-ambiguous Interlude card-equivalence exclusions.

## Reproduction and limits

```sh
PYTHONHASHSEED=0 /workspace/scratch/4aba5bd9b1ab/fs-bot/.venv/bin/python \
  /workspace/scratch/521fc7ecea8c/audit11/lifecycle/probe_lifecycle.py \
  --repo /workspace/scratch/521fc7ecea8c/falling-sky
```

`PYTHONPATH` can replace `--repo`. Repeat with hash seed 987. The output records all 54 cases, affected cohorts, adjustments, explicit human removals and both validators. It does not claim full-game natural encounter frequency or that every unrelated complete-board random choice is identical across hash seeds. Seed sweeps corroborate the static zero-selection proof; they do not purport to identify the one mandatory random outcome for a particular seed.
