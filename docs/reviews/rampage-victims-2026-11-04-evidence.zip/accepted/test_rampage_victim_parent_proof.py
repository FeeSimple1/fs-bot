import pytest
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, remove_piece, count_pieces, count_pieces_by_state
from fs_bot.commands.sa_rampage import rampage
from fs_bot.commands.common import CommandError
from fs_bot.engine.execute import _execute_rampage
from fs_bot.state.serialize import encode
from fs_bot.state.state_schema import build_initial_state

R,D=rc.NERVII,rc.ATREBATES

def position():
    state=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=43)
    state['non_player_factions']={rc.BELGAE,rc.AEDUI,rc.ARVERNI,rc.GERMANS}
    place_piece(state,R,rc.BELGAE,rc.LEADER,leader_name=rc.AMBIORIX)
    place_piece(state,R,rc.BELGAE,rc.WARBAND,4)
    place_piece(state,R,rc.ROMANS,rc.LEGION,2,from_legions_track=True)
    for ps in (rc.HIDDEN,rc.REVEALED,rc.SCOUTED):
        place_piece(state,R,rc.ROMANS,rc.AUXILIA,2,piece_state=ps)
    place_piece(state,D,rc.ROMANS,rc.AUXILIA)
    return state

def action():
    return {'sa':rc.SA_RAMPAGE,'sa_regions':[{'region':R,'target':rc.ROMANS,'count':2}]}

def test_target_receives_exact_physical_pool():
    state=position()
    seen=[]
    state['decision_agent']=lambda board,faction,request:seen.append(request) or None
    _execute_rampage(state,rc.BELGAE,action())
    assert len(seen)==1 and 'pieces' in seen[0]
    assert (rc.LEGION,None) in seen[0]['pieces']

def test_target_can_remove_legion_and_retreat_selected_revealed_auxilia():
    state=position()
    state['decision_agent']=lambda *args:{'actions':[
        {'action':'remove','piece_type':rc.LEGION,'piece_state':None},
        {'action':'retreat','piece_type':rc.AUXILIA,'piece_state':rc.REVEALED}],
        'retreat_region':D}
    result=_execute_rampage(state,rc.BELGAE,action())
    assert result['executed'] and not result['errors']
    assert state['fallen_legions']==1
    assert count_pieces_by_state(state,D,rc.ROMANS,rc.AUXILIA,rc.REVEALED)==1

def test_low_level_invalid_later_piece_is_atomic():
    state=position()
    before=encode(state)
    with pytest.raises(CommandError):
        rampage(state,R,rc.ROMANS,2,[{'action':'remove','piece_type':rc.AUXILIA,'piece_state':rc.REVEALED},
                                  {'action':'remove','piece_type':rc.ALLY,'piece_state':None}])
    assert encode(state)==before

def test_low_level_no_control_retreat_is_rejected():
    state=position()
    remove_piece(state,D,rc.ROMANS,rc.AUXILIA)
    before=encode(state)
    with pytest.raises(CommandError):
        rampage(state,R,rc.ROMANS,1,[{'action':'retreat','piece_type':rc.AUXILIA,
                                    'piece_state':rc.REVEALED,'retreat_region':D}])
    assert encode(state)==before

def test_host_agreement_is_consulted_once():
    state=position()
    remove_piece(state,D,rc.ROMANS,rc.AUXILIA)
    place_piece(state,D,rc.AEDUI,rc.WARBAND,3)
    seen=[]
    def agent(board,faction,request):
        if request['kind']=='agreement':
            seen.append(faction)
            return True
        return {'retreat':False}
    state['decision_agent']=agent
    _execute_rampage(state,rc.BELGAE,action())
    assert seen==[rc.AEDUI]

def test_npc_default_subset_control():
    state=position()
    state['non_player_factions'].add(rc.ROMANS)
    assert _execute_rampage(state,rc.BELGAE,action())['executed']
    assert count_pieces_by_state(state,D,rc.ROMANS,rc.AUXILIA,rc.SCOUTED)==2
    assert state['fallen_legions']==0

def test_raw_legacy_remove_control():
    state=position()
    state['decision_agent']=lambda *args:{'retreat':False}
    assert _execute_rampage(state,rc.BELGAE,action())['executed']
    assert count_pieces_by_state(state,R,rc.ROMANS,rc.AUXILIA,rc.SCOUTED)==0
    assert state['fallen_legions']==0 and count_pieces(state,D,rc.ROMANS,rc.AUXILIA)==1
