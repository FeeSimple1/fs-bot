# Eleventh audit independent validation

Fresh validation passed on clean commit `702d60a3754ce94a73ead0d0148d647232ecd816`, Python 3.12.14. The 626-file Python source digest is `489efe1d5b60a36f47ac5b7b46fd47595246d770606e32f6fa78d5b5b8d6a9e0`. All 47 supplied references and `fs_bot/rules_consts.py` match their captured SHA-256 inventory. No production files were edited in this lane; no earlier run is relabeled.

| Check | Result |
| --- | --- |
| Full pytest, four workers, hash seed 0 | 10,379 passed; no failures, errors, or skips; 182.89 seconds |
| Audited second-edition bot games | 20 attempted, 20 completed: all five scenarios × seeds 57–60 |
| Bot errors / integrity / ranking issues | 0 / 0 / 0 |
| Bot diagnostics | 154 per-game groups; all 329 occurrences reclassified as legal-decline |
| Bot Interludes | The Gallic War seeds 58 and 60 |
| Mixed second-edition cases | 20 complete per hash seed, 0 and 987; internal replay enabled; 80 executions total |
| Mixed cross-process comparison | Entire JSON and stdout logs byte-identical |
| Mixed activity per batch | 758 human turns; 171 Event turns; 153 executed Events |
| Mixed findings | 0 hard findings; 4 soft partial plans; 40 rejected random plans |
| Mixed Interludes | The Gallic War seeds 59 and 60 |

The four soft partials are Pax Gallica seeds 58 and 60, Reconquest seed 59, and Ariovistus seed 58. Each game completed with no hard finding; these partial plans are not counted as successful full plans. Exact seats, counters, and case digests are retained in `summary.json` and `mixed-record-checks.json`. Batch digest: `a588412824289ad9bde80c33a498bdaca09e90875c6edb2726004decb8ff4317`.

Every bot record was checked for all three completion flags, complete emitted and recomputed rankings, eligible winner, no ranking disagreement, census/structure findings, errors, source/edition, and final-state digest. `diagnostic-review.json` retains every individual raw diagnostic with a fresh severity calculation, plus message grouping. No severity other than legal-decline occurs. This classification does not prove that every legal-looking bot choice follows its printed priorities; directed audit findings remain separate.

The first pytest invocation failed before collection because pytest rejected a relative cache path. Its exit code was 3 and its log is preserved as `pytest-initial-cache-path-error.log`. Retrying with an absolute cache path passed the full suite. Five warnings come from the external anyio plugin's deprecated `CallSpec2` import. No test was skipped.

The suite includes the existing 15-game legacy balance canary: seeds 1–3 across five scenarios, with its existing 40-percentage-point band. This is distinct from the full 100-game, 15-point guardrail. No fresh full guardrail or baseline refresh was performed in this lane; the audit makes no gameplay changes. Passing sampled games and tests is bounded evidence, not complete rules coverage or a human-balance study.

## Reproduction and evidence

Run from the repository root with `/workspace/scratch/4aba5bd9b1ab/fs-bot/.venv/bin/python`. Exact invocations and exit statuses are in `commands.json`. Main commands are:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 python -m pytest -q -n 4 -o cache_dir=/workspace/scratch/521fc7ecea8c/audit11/validation/pytest-cache --junitxml=../audit11/validation/pytest.xml
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 57-60 --card-edition second-edition --workers 2 --out ../audit11/validation/bots
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 57-60 --card-edition second-edition --out ../audit11/validation/fuzz0.json
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 57-60 --card-edition second-edition --out ../audit11/validation/fuzz987.json
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. python ../audit11/validation/verify_validation.py
```

Use new output paths to reproduce; preserve the original raw records. `verify_validation.py` checks the existing artifacts, exact case coverage, diagnostics, JUnit result and canary, full cross-hash equality, source digest, and protected hashes without rerunning gameplay. `source.json`, `protected-sources.json`, and `reference-inventory.txt` identify the frozen inputs. Directed witness reruns and independent source/prior-audit review are stored under `review/`.
