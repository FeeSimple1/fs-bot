"""Trace only the three changed final states between frozen attempts 4 and 5."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
PYTHON = ROOT.parent / "fs-test-venv/bin/python"
OLD = ROOT.parent / "fs-second-batch-frozen6155"
NEW = ROOT.parent / "fs-bot"
OUT = ROOT / "attempt5/a70-causal-review"


def rows(attempt):
    return {(r["scenario"], r["seed"]): r for r in map(json.loads,
            (ROOT / attempt / "bots-legacy/games.jsonl").read_text().splitlines())}


def command(name, argv, cwd, folder):
    start = time.monotonic()
    status = {"argv": argv, "cwd": str(cwd), "hash_seed": 0,
              "started_utc": datetime.now(timezone.utc).isoformat(), "exit_code": None}
    path = folder / f"{name}.status.json"
    path.write_text(json.dumps(status, indent=2) + "\n")
    with (folder / f"{name}.log").open("x") as stream:
        result = subprocess.run(argv, cwd=cwd, env=dict(os.environ, PYTHONHASHSEED="0", PYTHONUNBUFFERED="1"),
                                stdout=stream, stderr=subprocess.STDOUT)
    status.update(exit_code=result.returncode, elapsed_seconds=time.monotonic() - start)
    path.write_text(json.dumps(status, indent=2) + "\n")
    return status


old, new = rows("attempt4"), rows("attempt5")
changed = {key for key in old if old[key]["final_state_sha256"] != new[key]["final_state_sha256"]}
assert changed == {("Ariovistus", 5), ("The Gallic War", 5), ("The Gallic War", 12)}
old_sha = json.loads((ROOT / "attempt4/source.json").read_text())["source_sha256"]
new_sha = json.loads((ROOT / "attempt5/source.json").read_text())["source_sha256"]
summaries = []
for scenario, seed in sorted(changed):
    slug = scenario.lower().replace(" ", "-") + f"-{seed:02}"
    folder = OUT / slug
    folder.mkdir(exist_ok=False)
    old_path = (ROOT / "attempt4/drift-review/the-gallic-war-05/current.json.gz"
                if (scenario, seed) == ("The Gallic War", 5) else folder / "source6155.json.gz")
    new_path = folder / "source0714.json.gz"
    jobs = []
    for name, cwd, digest, expected, target in (
            ("source6155", OLD, old_sha, old[scenario, seed]["final_state_sha256"], old_path),
            ("source0714", NEW, new_sha, new[scenario, seed]["final_state_sha256"], new_path)):
        if name == "source6155" and old_path.exists():
            continue
        argv = [str(PYTHON), str(ROOT / "compact_trace.py"), "--scenario", scenario,
                "--seed", str(seed), "--source-sha256", digest, "--expected-final-sha256", expected,
                "--out", str(target)]
        jobs.append((name, argv, cwd, folder))
    with ThreadPoolExecutor(max_workers=2) as pool:
        statuses = list(pool.map(lambda job: command(*job), jobs))
    if any(s["exit_code"] != 0 for s in statuses):
        raise SystemExit("Trace failed; inspect preserved logs before any retry")
    argv = [str(PYTHON), str(ROOT / "compare_traces.py"), "--baseline", str(old_path), "--current", str(new_path),
            "--baseline-source-sha256", old_sha, "--baseline-final-sha256", old[scenario, seed]["final_state_sha256"],
            "--current-source-sha256", new_sha, "--current-final-sha256", new[scenario, seed]["final_state_sha256"],
            "--out", str(folder / "comparison.json")]
    status = command("comparison", argv, NEW, folder)
    if status["exit_code"] != 0:
        raise SystemExit("Comparison failed; inspect preserved logs")
    comparison = json.loads((folder / "comparison.json").read_text())
    first = comparison["first_state_or_decision_difference"]
    brief = {"scenario": scenario, "seed": seed, "first_boundary": first["current_boundary"],
             "changed_domains": first["changed_state_domains"], "rng_changed": first["rng_changed"],
             "old_winner": old[scenario, seed]["winner"], "new_winner": new[scenario, seed]["winner"],
             "old_trace_reused": (scenario, seed) == ("The Gallic War", 5), "comparison": str(folder / "comparison.json")}
    summaries.append(brief)
    print(json.dumps(brief), flush=True)
(OUT / "runner-status.json").write_text(json.dumps({"exit_code": 0, "new_current_games": 3,
    "new_historical_games": 2, "cached_historical_games": 1, "source_review_pending": True,
    "cases": summaries}, indent=2) + "\n")
