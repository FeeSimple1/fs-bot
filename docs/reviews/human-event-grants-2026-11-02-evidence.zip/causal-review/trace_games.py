"""Read-only tracing of the six paired games through the real balance runner.

Run independently per checkout with PYTHONHASHSEED=0. No production module
is written: wrappers only snapshot actual live-state calls, excluding previews.
"""
import argparse
import contextlib
import gzip
import io
import json
import os
from pathlib import Path
import platform
import sys

ap = argparse.ArgumentParser()
ap.add_argument('--worktree', required=True)
ap.add_argument('--label', required=True)
ap.add_argument('--out', required=True)
ap.add_argument('--scenario')
ap.add_argument('--seed', type=int)
args = ap.parse_args()
assert os.environ.get('PYTHONHASHSEED') == '0'
sys.path.insert(0, args.worktree)
from fs_bot import rules_consts as rc
from fs_bot.engine import execute as ex
from fs_bot.engine.game_engine import run_game, ACTION_EVENT, get_sop_factions
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.cli.dispatcher import _translate_bot_action
from fs_bot.state.setup import setup_scenario
from fs_bot.state.serialize import encode
from fs_bot.tools.validation_metadata import source_identity

out = Path(args.out)
out.mkdir(parents=True, exist_ok=True)
identity = source_identity()
identity.update(python=platform.python_version(), hash_seed='0', worktree=args.worktree)
manifest = []
original = ex.execute_decision
for scenario in (rc.SCENARIO_ARIOVISTUS, rc.SCENARIO_GALLIC_WAR):
    if args.scenario and scenario != args.scenario:
        continue
    for seed in (2, 4, 17):
        if args.seed is not None and seed != args.seed:
            continue
        st = setup_scenario(scenario, seed=seed)
        st['non_player_factions'] = set(get_sop_factions(st))
        trace = []
        def snap(board):
            return encode({k: v for k, v in board.items() if k != 'decision_agent'})
        def choose(board, faction, options, position):
            row = {'index': len(trace), 'kind': 'decision', 'card': board.get('current_card'),
                   'card_index': len(board.get('played_cards', [])),
                   'faction': faction, 'position': position, 'options': options,
                   'before': snap(board)}
            board['current_card_id'] = board.get('current_card')
            board['is_second_eligible'] = position == '2nd_eligible'
            board['can_play_event'] = ACTION_EVENT in options
            ba = dispatch_bot_turn(board, faction)
            result = {'action': _translate_bot_action(ba, options), 'bot_action': ba}
            row.update(decision=encode(result), after=snap(board))
            trace.append(row)
            return result
        def execute(board, faction, decision, *a, **kw):
            if board is not st:
                return original(board, faction, decision, *a, **kw)
            row = {'index': len(trace), 'kind': 'execution', 'card': board.get('current_card'),
                   'card_index': len(board.get('played_cards', [])), 'faction': faction,
                   'decision': encode(decision), 'before': snap(board)}
            result = original(board, faction, decision, *a, **kw)
            row.update(result=encode(result), after=snap(board))
            trace.append(row)
            return result
        ex.execute_decision = execute
        with contextlib.redirect_stdout(io.StringIO()):
            result = run_game(st, decision_func=choose, execute=True)
        ex.execute_decision = original
        winner = next((row['winner'] for row in reversed(result['card_results']) if row.get('winner')), None)
        name = f"{args.label}-{scenario.replace(' ', '-')}-{seed}.json.gz"
        record = {'source': identity, 'scenario': scenario, 'seed': seed,
                  'outcome': {'winner': winner, 'cards': result['total_cards_played']},
                  'trace': trace, 'result': encode(result), 'final': snap(st)}
        with gzip.open(out / (name + '.tmp'), 'wt', encoding='utf-8') as handle:
            json.dump(record, handle, sort_keys=True)
        (out / (name + '.tmp')).replace(out / name)
        manifest.append({'file': name, 'scenario': scenario, 'seed': seed,
                         'outcome': record['outcome'], 'rows': len(trace)})
        print(json.dumps(manifest[-1]), flush=True)
(out / f'{args.label}-manifest.json').write_text(json.dumps({'source': identity, 'games': manifest}, indent=2) + '\n')
