# Bounded paired outcome review

Only **The Gallic War, legacy edition, seed 1** was traced, with `PYTHONHASHSEED=0`.
Parent `95e7a206d5b6ff410d949573724cb2b145ed23d8` reproduces **Aedui / 102 cards**;
candidate `9a2bad256073cbc5c76329af0e02d352d9d0a041` reproduces **Belgae / 103 cards**.

The first divergence is execution trace row **134** (zero-based), played-card count **37**:
Romans execute **A5 Gallia Togata, unshaded**. All 134 preceding trace rows, the complete
pre-execution state including RNG, and the declared Event decision are identical.

| German piece initially in Cisalpina | Parent | Candidate |
|---|---|---|
| Settlement | Incorrectly remains | Moves to Ubii |
| Ally at Nori | Incorrectly remains | Moves to Suebi (North), Sugambri |
| Hidden Warband | Moves to Sugambri | Moves to Ubii, still Hidden |

A5 requires all non-Roman pieces to leave Cisalpina for their Home Regions or be removed.
The candidate therefore corrects the omitted Settlement and Ally evacuation. It also chooses
legal destinations using the NP tie rules. The initial Cisalpina board contains exactly these
three German pieces; it has no Romans. Both executions place the same one available Roman
Auxilia, but the parent leaves illegal German pieces there and Germanic Control; the candidate
fully evacuates them and leaves Roman Control. Tribe records correctly clear Nori and occupy
Suebi (North). Changed board Regions are Cisalpina, Sugambri and Ubii.

The parent's A5 execution consumes no RNG. Candidate RNG advances on two actual choices:
Settlement among Sugambri/Ubii (chooses Ubii), then Warband among Sugambri/Treveri/Ubii
(chooses Ubii). The Ally has only one legal slot, Suebi (North), and consumes no RNG.
A separate replay of this single captured execution, with read-only random-slot tracing,
reproduces the exact recorded result and complete post-state. These RNG changes occur in
live resolution, not preview or validation.

Sources: supplied A Card Reference A5 unshaded; A1.3.1 (German Home Regions include Regions
with Settlements), A1.4.2 (stacking); base §§8.2.3, 8.3.4 and 8.4.1 (NP priorities and equal
candidate selection). This is the intended **EXP-07** correction. Dread/EXP-10 is not the
first divergence in this pair. No unexplained first divergence or blocker was found. The
review establishes the initial causal change; it does not decompose every later winner or
length difference and is not a new balance study. No code, baseline or rule source changed.

## Reproduction and identities

`trace_games.py` is a bounded adaptation of the preceding human-Event-grant trace script.
It records only this one seed per checkout. `summarize_traces.py` verifies both expected
outcomes and equal prefixes, hashes both gzip traces, and regenerates the summary.
`inspect_first_execution.py` replays only the captured first differing candidate execution.
Complete snapshots, both gzip SHA-256 hashes, source digests and RNG hashes are retained.

The parent is an extracted `fs_bot/` plus Reference Documents tree; its native Git identity
is null, so `source-verification.json` verifies every one of its 450 Python/reference files
against the Git blob at 95e7a20. Its source digest matches the prior parent matrix metadata.
The candidate reports dirty because root was updating project documentation concurrently;
all 454 Python/reference files were verified byte-for-byte against 9a2bad2, with no extra
Python files. This accurately distinguishes Git status from executed source identity.

```sh
PYTHONHASHSEED=0 python trace_games.py --worktree /path/to/dread-baseline-source --source-commit 95e7a206d5b6ff410d949573724cb2b145ed23d8 --label parent --scenario "The Gallic War" --seed 1 --out /path/to/causal-review
PYTHONHASHSEED=0 python trace_games.py --worktree /path/to/fs-bot --source-commit 9a2bad256073cbc5c76329af0e02d352d9d0a041 --label candidate --scenario "The Gallic War" --seed 1 --out /path/to/causal-review
PYTHONHASHSEED=0 python inspect_first_execution.py
python summarize_traces.py
```
