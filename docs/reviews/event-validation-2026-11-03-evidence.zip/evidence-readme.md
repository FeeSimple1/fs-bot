# Event validation batch evidence

The report and results JSON in docs/reviews are the accepted summary. The raw
records here retain both successful validation and earlier failed attempts.
Counts overlap; this is not a collection of independent balance samples.

- Task parent: 8db858b. German Allegiances isolated commit: b17e2f6.
- Pre-final prepared source: 417 Python files, SHA29f477d5; source-manifest.json,
  prepared-source.patch, matrix-01 and sealed causal-review retain that identity.
- Final prepared source: 417 Python files, SHAed4c0d64; final-source-manifest.json,
  final-prepared-source.patch and matrix-02. source-commit.json verifies those
  exact bytes were committed. committed-task-source.patch includes all repairs
  and the reviewed baseline change against the original task parent.
- Base and expansion isolated full runs failed the old balance canary; no source
  commits were made with those failing tests. Allegiances' initial ineffective
  human Event failure was repaired while preserving the original test.
- Two earlier expansion A37 full-game fixtures depended on changed trajectories.
  exp-capture-a37.py and the committed fixtures preserve exact parent states and
  decisions instead; independent reconstruction verified both. The report
  explains the other source-inconsistent old assertions that changed.
- matrix-01 and matrix-02 each contain150 audited bot games,120 mixed-seat
  executions including replay/hash repetition, and20 strict census executions.
  Both originally failed only comparison with the unchanged old baseline. Their
  integration-results.json files remain failed, as observed at execution time.
- parent-bots-legacy contains explicitly reused previous accepted records; see
  task-baseline.json for source-byte equivalence, not a claim of100fresh games.
- causal-review contains exactly50changed parent/candidate pairs (40winner and
  10length-only),100diagnostic games, source reviews, first-row replays and a
  sealed canonical-file manifest. The complete common trace prefix and first
  state/RNG match for all50. Three candidate reconstructed decisions differ only
  in unused Trade list ordering; executing both variants yields identical full
  results/state/RNG. Earlier metadata comparison failures are retained.
- Final A30 Region-priority repair followed this causal review. Its synthetic
  failing witness and passing focused run are retained. final-a30-replay and
  final-source-equivalence bridge the old traces to the final source without
  relabeling them: all150 final-state hashes/winners/lengths and mixed/census
  records match, and both captured A30 executions match exactly.
- Independent reviewer cleared the refreshed100-game baseline at the unchanged
  15-point threshold and seeds1–20. baseline-before.json and baseline-after.json
  retain exact files. baseline-refresh-games.log records100fresh update games,
  all exactly matching matrix-02 legacy outcomes. This repeats the same100cases,
  not100additional independent cases. No test threshold was weakened.
- protected-before.json contains49 hashes. The47 Reference Documents and
  rules_consts.py remain unchanged (48immutable inputs); the49th, the baseline,
  changed only after causal review. It must not be described as still unchanged.
- integrated-full-01 and documentation-full-01 log/XML are the final full suites.
  Earlier focused suites, fixture/implementation failures and handoffs retain
  their revision-specific limitations. Source SHA includes all fs_bot Python
  files, including tests; no comment/docstring exception is used.

The archive's evidence-index.json records every included file's SHA256 and size;
packaging verifies all entries plus ZIP CRC. The packaging helper is included.
Historical instruction/handoff statements (such as 'baseline unchanged' before
review) apply to their checkpoint and are not the final disposition.
