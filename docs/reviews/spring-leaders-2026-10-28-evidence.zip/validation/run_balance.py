"""Fresh post-refresh balance validation with exact candidate-record comparison."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time
from run_tests import identity

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'fs-bot'
PYTHON = ROOT.parent / 'fs-test-venv/bin/python'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--source-sha256', required=True)
    parser.add_argument('--baseline-sha256', required=True)
    parser.add_argument('--fixture-sha256', required=True)
    args = parser.parse_args()
    assert Path(args.attempt).name == args.attempt
    run = ROOT / args.attempt
    baseline = REPO / 'fs_bot/tools/balance_baseline.json'
    fixture = REPO / 'fs_bot/tests/fixtures/compatibility_8ef88e2/manifest.json'
    before = identity()
    def frozen():
        current = identity()
        return (current['source_sha256'] == args.source_sha256 and current['commit'] == before['commit']
                and hashlib.sha256(baseline.read_bytes()).hexdigest() == args.baseline_sha256
                and hashlib.sha256(fixture.read_bytes()).hexdigest() == args.fixture_sha256)
    assert frozen()
    candidate = json.loads((run / 'balance-candidate.json').read_text())['games']
    assert hashlib.sha256((run / 'balance-candidate.json').read_bytes()).hexdigest() == args.baseline_sha256
    argv = [str(PYTHON), '-m', 'fs_bot.tools.balance_smoke', '--seeds', '1-20', '--band', '0.15', '--baseline', str(baseline)]
    status_path = run / 'balance-final.status.json'
    assert not status_path.exists()
    status = {'argv': argv, 'cwd': str(REPO), 'source_before': before,
              'baseline_sha256': args.baseline_sha256, 'fixture_manifest_sha256': args.fixture_sha256,
              'environment': {'PYTHONHASHSEED': '0', 'PYTHONUNBUFFERED': '1'},
              'started_utc': datetime.now(timezone.utc).isoformat(), 'exit_code': None,
              'source_changed': False, 'runner_exit_code': None}
    def save():
        status_path.write_text(json.dumps(status, indent=2, sort_keys=True) + '\n')
    save();start = time.monotonic()
    with (run / 'balance-final.log').open('x') as out:
        proc = subprocess.Popen(argv, cwd=REPO, env=dict(os.environ, PYTHONHASHSEED='0', PYTHONUNBUFFERED='1'),
                                stdout=out, stderr=subprocess.STDOUT, start_new_session=True)
        status['pid'] = proc.pid;save()
        while True:
            try:
                status['exit_code'] = proc.wait(timeout=15);break
            except subprocess.TimeoutExpired:
                if not frozen():
                    status['source_changed'] = True
                    os.killpg(proc.pid, signal.SIGTERM)
                    try:status['exit_code'] = proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(proc.pid, signal.SIGKILL);status['exit_code'] = proc.wait()
                    break
    status.update(source_after=identity(), ended_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic()-start)
    status['source_changed'] = status['source_changed'] or not frozen()
    pattern = re.compile(r'^\[(.+) seed=\s*(\d+)\] winner=(\w+) \((\d+) cards\)$')
    records = {}
    duplicate = []
    for line in (run / 'balance-final.log').read_text().splitlines():
        match = pattern.fullmatch(line)
        if match:
            key = match[1] + '|' + match[2]
            if key in records:duplicate.append(key)
            records[key] = {'winner': match[3], 'cards': int(match[4])}
    status['record_count'] = len(records)
    status['duplicate_records'] = duplicate
    status['exact_candidate_records_match'] = records == candidate and len(records) == 100 and not duplicate
    status['runner_exit_code'] = (0 if status['exit_code'] == 0 and not status['source_changed']
                                  and status['exact_candidate_records_match'] else 1)
    save()
    (run / 'balance-final-records.json').write_text(json.dumps({'games': records}, indent=2, sort_keys=True) + '\n')
    print(json.dumps(status, indent=2, sort_keys=True), flush=True)
    return status['runner_exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
