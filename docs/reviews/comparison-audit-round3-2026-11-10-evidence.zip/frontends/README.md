# Frontend comparison audit evidence

Falling Sky revision `3c23a3414c3e870e274ef63c278db8cb3f1ee747`.
Liberty or Death comparison revision `2991ea279062773548ec390a1da75f3e85381702`.

One high-priority repair group, FE3-01, contains two independent executable
witnesses of authored top-level metadata crossing into engine-owned authority.
No game code, tests or reference inputs were changed.

Both scripts start ordinary file sessions from standard setup, submit a legal
one-Auxilia Roman Recruit on card 16, and answer actual reactive requests.
Neither changes the board, saved game, RNG or engine outcomes. The Eligibility
script records the original adjustment's output with an observation-only wrapper.
The journal script also verifies replay of both control and defective outcomes.

Run from the Falling Sky repository root with its package on PYTHONPATH.

```sh
PYTHONPATH=. python ../comparison-audit-round3-2026-11-10/frontends/probe_eligibility_flag.py
PYTHONPATH=. python ../comparison-audit-round3-2026-11-10/frontends/probe_journal_collision.py
```

Assertions freeze the observed defects. Repair regressions should reverse those
expectations and require rejection with unchanged pending state.

Coverage includes durable response validation, accepted-response recording,
normal pause/resume, save/load, whole-card Eligibility, replay, and the earlier
current-card/action-type/command-scope guards. Existing tests exercise additional
rollback, stale-inbox, malformed-response, terminal timing and decision-journey
paths. This partition does not certify every reactive decision schema or every
Event choice; other audit partitions address gameplay-specific effects.
