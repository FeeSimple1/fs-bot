# Third comparison repair Batch 1 evidence

Accepted results are in final3. They use the repair working tree over commit
06487b417f0c32d3e0830ea453a00acb2a81978a with Python-source SHA-256
42da33aca92ecd23c750e2ea17e29f3f71d50c66e2e50db03a0f325966c12069.
The integrated suite passed 9,473 tests, including 62 new cases.

From a checkout of the repair, run the source-derived regression cases with
`python -m pytest -q fs_bot/tests/test_authored_turn_authority.py`.
The same 62 cases, copied into the audit engine checkout, produce 58 failures
and four passing controls. The accepted parent run and exact test source are
preserved here. Parent game matrices used an archive of the recorded parent
commit whose source digest matches the audit engine, with no injected tests
remaining in that archive during the matrices.

final3/verification.json records exact counts and comparisons. The twenty
all-bot records pass completion, ranking, diagnostics and structural gates.
Their game fields match parent-bots after excluding wall time and source
metadata. Seeds 21 through 24 cover all five scenarios.

The two mixed-player JSON files match exactly across hash seeds 0 and 987.
All twenty case records match the prior audit's case records. Four soft partial
plans are reported separately from zero hard findings. Internal replay is
enabled. The 100-game balance matrix matches the parent in every winner and
card count and passes the existing baseline guardrail. run_balance.py wraps
the official runner only to record its returned outcomes.

check_older_conflict.py exercises normal init/play/submit, constructs the
contradictory saved journal produced by the earlier bug, and verifies that
resume and replay stop with board, RNG and committed history preserved.
Use PYTHONPATH pointing to the selected repository when running this script.

Superseded run logs are retained under their original directories. These
include test-double signature failures, an early raw-callback validation
change, a tuple-representation compatibility finding, and its corrected March
test fixture. Only final3 supplies accepted integrated results.
