# Batch 3 verification

The tested Python source is identified in `verification.json`. The parent is
`37a087d5c37671c1f1109ccdbbcb0136c216cb5b`. Run these commands from the repair
checkout with fresh output paths.

```sh
python -m pytest -q -n 6 --junitxml=pytest.xml
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --workers 2 --out legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 25-28 --card-edition second-edition --workers 2 --out second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 25-28 --card-edition second-edition --out fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 25-28 --card-edition second-edition --out fuzz987.json
cmp fuzz0.json fuzz987.json
python -m fs_bot.tools.balance_smoke --seeds 1-20 --baseline previous-baseline.json
python -m fs_bot.tools.balance_smoke --seeds 1-20
```

The run against the previous baseline is expected to exceed its band.
The full suite uses pytest-xdist. To reproduce the parent failures, copy
`test_fourth_comparison_battles.py` and `test_np_retreat_legion_rolls.py`
from the repair into a temporary directory outside either checkout. Run
pytest on those copies with `PYTHONPATH` pointing at the parent.

To trace the winner changes, pass `parent` or `repair`, the archive's
extracted directory as both input paths, and an output JSON path to
`trace_game_changes.py`. Use the corresponding checkout for each replay
with `PYTHONHASHSEED=0` and `PYTHONPATH` set to that checkout. Use its
`compare` mode with the two output paths and the destination for the
comparison. Run `trace_a24_battle.py` from each checkout under the same
settings for the Motivation case. `verify_and_pack.py` records the audit
checks used before packaging the evidence.
