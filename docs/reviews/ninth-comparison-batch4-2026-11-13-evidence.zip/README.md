# Ninth comparison Batch 4 validation

The parent checkout is `6611fabab1fda6a6e4e8b71e537bd544458a8ff5`.
The repaired runs were captured before commit. `repair/source.json` pins
their Python source bytes. The parent game matrices and mixed-player
results are in the neighboring Batch 3 evidence archive under `repair/`.
Those runs have the same Python source digest as the Batch 3 commit.
The audit probe carries the original audit revision as its provenance.

`verification.json` records the verified counts. `first-differences.json`
pairs each changed final state with the first card whose resulting board
or RNG differs. The digest of the board excludes the live callback, RNG,
and saved card-result fields. RNG is compared separately. Targeted
traces also capture the actual Special Abilities and Devastate quotas.

Run the original probe against Batch 3 and the repaired probe against
the repair, each with `PYTHONHASHSEED=0` and again with 987.

```sh
python parent/probe_bots.py --repo /path/to/batch3
python repair/probe_repaired.py --repo /path/to/batch4
```

To reproduce the directed tests on either revision, run the included
test file from a separate directory with that checkout on `PYTHONPATH`.
From the repaired checkout run `PYTHONHASHSEED=0 python -m pytest -q` for
the full suite. The recorded run used five local pytest-xdist workers.

The following commands reproduce the game matrices and balance checks
from the repaired checkout. Use empty output directories for each study.

```sh
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --workers 3 --out legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 49-52 --card-edition second-edition --workers 2 --out second-edition
python -m fs_bot.tools.balance_smoke --seeds 1-20 --baseline /path/to/repair/balance-previous.json
python -m fs_bot.tools.balance_smoke --seeds 1-20
```

Run `python -m fs_bot.tools.player_fuzz --seeds SEEDS --card-edition EDITION
--out FILE` at each hash seed named in the replay filenames. Run the
following from either checkout for the paired trace. Pass
`trace-detail-tasks.json` to restrict it to the games with nested ability
or casualty evidence.

```sh
PYTHONPATH=. PYTHONHASHSEED=0 python /path/to/repair/trace_abilities.py /path/to/repair/trace-tasks.json --workers 2
```

Verify the archived files with `sha256sum -c SHA256SUMS` after extraction.
