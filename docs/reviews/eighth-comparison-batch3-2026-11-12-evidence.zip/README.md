# Eighth comparison repair evidence, Batch 3

Parent commit: `21c699a63b0cf5e199dd5750c4abdb3c7d82c5ff`. The runs used
Python 3.12.14. The repaired digest covers 614 Python files.

Run the evidence verifier from the repaired checkout with the archive
extracted.

```sh
PYTHONPATH=. python /path/to/evidence/verify_results.py
```

`parent-final` records the directed module on the parent. Seven cases
reproduce the two defects. The Britannia pairing and older replay cases
pass. `focused-final` covers the adjacent Winter, March, and assistant
behavior. `pytest-final` covers the full suite with five pytest-xdist
workers and hash seed 0. Repeat the directed cases on either engine by
running from that checkout.

```sh
PYTHONHASHSEED=0 PYTHONPATH=. python -m pytest -q /path/to/evidence/test_eighth_comparison_winter_campaign.py
```

The saved-session tests create controlled nonfinal Winter checkpoints
from normal scenario setups. They use the real terminal and file-based
decision handlers. The durable cases run the Winter and replay through
the public game driver.

`final-legacy` covers seeds 1–20 across all scenarios. `final-second`
covers second-edition seeds 45–48. Both use hash seed 0 and two workers.
`fuzz0-final` and `fuzz987-final` cover the same second-edition seeds
with reactions, Events and internal replay enabled. `balance-final.log`
records the reviewed 100-game legacy guardrail. Parent records come from
the Batch 2 archive and carry the parent engine's Python source digest.
`SHA256SUMS` records the digest of every other file in this archive.
