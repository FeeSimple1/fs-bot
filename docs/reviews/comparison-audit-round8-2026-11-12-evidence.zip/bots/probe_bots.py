"""Read-only eighth comparative audit: public bot dispatch and execution witnesses.

Usage: /path/to/fs-bot/.venv/bin/python probe_bots.py --repo /path/to/fs-bot
No repository tests, patches, mocks, or piece-count mutations are used.
"""
import argparse
import json
import sys
from copy import deepcopy
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument('--repo', type=Path, default=Path(__file__).resolve().parents[2] / 'fs-bot')
args = ap.parse_args()
sys.path.insert(0, str(args.repo.resolve()))

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.bots.aedui_bot import _determine_trade_sa, _estimate_battle_losses
from fs_bot.bots.bot_common import predict_battle
from fs_bot.battle.resolve import resolve_battle
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND, ACTION_COMMAND_SA

integrity_checks = 0

def integrity(state):
    global integrity_checks
    schema, structure = validate_state(state), check_structural_integrity(state)
    assert schema == structure == [], (schema, structure)
    integrity_checks += 1
    return {'schema': schema, 'structure': structure}


def board(*, scenario=rc.SCENARIO_GREAT_REVOLT, sa=True, resources=10):
    state = build_initial_state(scenario, seed=6)
    state['non_player_factions'] = {rc.ROMANS, rc.AEDUI, rc.BELGAE,
        rc.GERMANS if scenario in rc.ARIOVISTUS_SCENARIOS else rc.ARVERNI}
    state['can_play_event'] = False
    state['_command_with_sa'] = sa
    for faction in state['non_player_factions']:
        state['resources'][faction] = resources
    # Provincia's permanent Fort is a physical invariant of the game board.
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    return state


def run(state, *, action=None):
    before = integrity(state)
    if action is None:
        action = dispatch_bot_turn(state, rc.AEDUI)
    result = execute_decision(state, rc.AEDUI, {
        'action': ACTION_COMMAND_SA if state['_command_with_sa'] else ACTION_COMMAND,
        'bot_action': action})
    assert result['executed'] and not result.get('errors'), result
    after = integrity(state)
    return {'action': action, 'execution': result, 'integrity_before': before,
            'integrity_after': after, 'aedui_resources_after': state['resources'][rc.AEDUI]}


def battle_board(enemy_warbands, *, scenario=rc.SCENARIO_GREAT_REVOLT, resources=10):
    state = board(scenario=scenario, sa=False, resources=resources)
    place_piece(state, rc.CARNUTES, rc.AEDUI, rc.WARBAND, 2, piece_state=rc.REVEALED)
    assert _ally_tribe(state, rc.TRIBE_CARNUTES, rc.BELGAE)
    place_piece(state, rc.AEDUI_REGION, rc.AEDUI, rc.WARBAND, 4, piece_state=rc.REVEALED)
    place_piece(state, rc.AEDUI_REGION, rc.BELGAE, rc.WARBAND, enemy_warbands, piece_state=rc.REVEALED)
    integrity(state)
    return state


def counts(state):
    return {'aedui_warbands': count_pieces(state, rc.AEDUI_REGION, rc.AEDUI, rc.WARBAND),
            'belgic_warbands': count_pieces(state, rc.AEDUI_REGION, rc.BELGAE, rc.WARBAND),
            'aedui_allies': count_pieces(state, rc.AEDUI_REGION, rc.AEDUI, rc.ALLY)}

out = {'audited_commit': 'e62b0360c1b91032741ef8f6afa4d247c8ea2437',
       'seed': 6, 'production_edits': False, 'repository_tests_run': False,
       'NP8-01': [], 'NP8-02': []}
for scenario in (rc.SCENARIO_GREAT_REVOLT, rc.SCENARIO_ARIOVISTUS):
    for n, tag, expected_regions in (
            (4, 'favorable_control', [rc.CARNUTES, rc.AEDUI_REGION]),
            (6, 'defect', [rc.CARNUTES]),
            (8, 'unfavorable_control', [rc.CARNUTES])):
        state = battle_board(n, scenario=scenario)
        legacy = _estimate_battle_losses(state, rc.AEDUI_REGION, rc.AEDUI, rc.BELGAE, scenario)
        forecast = predict_battle(state, rc.AEDUI_REGION, rc.AEDUI, rc.BELGAE)
        forecasts = {k: v for k, v in forecast.items() if k != 'defender_loss_types'}
        forecasts['defender_loss_types'] = sorted(forecast['defender_loss_types'])
        trials = {}
        for stance in (False, True):
            trial = deepcopy(state)
            integrity(trial)
            battle = resolve_battle(trial, rc.AEDUI_REGION, rc.AEDUI, rc.BELGAE,
                                    retreat_declaration=stance)
            integrity(trial)
            trials['retreat' if stance else 'stand'] = {
                'attack_losses': battle['attack']['losses_requested'],
                'counterattack_losses': (battle['counterattack'] or {}).get('losses_requested', 0),
                'counts': counts(trial)}
        record = run(state)
        assert [p['region'] for p in record['action']['details']['battle_plan']] == expected_regions
        record.update(scenario=scenario, case=tag, initial_enemy_warbands=n,
                      legacy_estimate=legacy, shared_forecast=forecasts,
                      live_battle_trials=trials, final_counts=counts(state))
        out['NP8-01'].append(record)

# Source-required complete Battle plan through the same public executor.
state = battle_board(6)
action = dispatch_bot_turn(state, rc.AEDUI)
action['details']['battle_plan'].append({'region': rc.AEDUI_REGION,
    'target': rc.BELGAE, 'priority': 'favorable'})
action['regions'].append(rc.AEDUI_REGION)
record = run(state, action=action)
assert counts(state)['aedui_warbands'] == 2 and counts(state)['belgic_warbands'] == 4
record.update(case='source_required_second_battle_execution_control', final_counts=counts(state),
              supplied_plan_note='Dispatcher plan extended by the additional Battle required by 8.6.2; not represented as an unmodified bot selection.')
out['NP8-01'].append(record)

state = battle_board(4, resources=1)
record = run(state)
assert len(record['execution']['battles_resolved']) == 1 and state['resources'][rc.AEDUI] == 0
record.update(case='one_resource_budget_control', final_counts=counts(state))
out['NP8-01'].append(record)

for case, sa, resources, initial_warbands in (
        ('defect', True, 10, 0),
        ('existing_hidden_warband_control', True, 10, 1),
        ('command_only_control', False, 10, 0),
        ('no_resources_after_rally_control', True, 1, 0)):
    state = board(sa=sa, resources=resources)
    if initial_warbands:
        place_piece(state, rc.AEDUI_REGION, rc.AEDUI, rc.WARBAND, initial_warbands)
    before_sa = _determine_trade_sa(state, state['scenario'])
    record = run(state)
    after_sa = _determine_trade_sa(state, state['scenario'])
    if case == 'defect':
        assert record['action']['sa'] == 'No SA' and 'sa_execution' not in record['execution']
        assert after_sa[0] == rc.SA_SUBORN
        assert counts(state) == {'aedui_warbands': 1, 'belgic_warbands': 0, 'aedui_allies': 0}
        assert state['resources'][rc.AEDUI] == 9
    elif case == 'existing_hidden_warband_control':
        assert record['execution']['sa_execution']['executed']
        assert record['execution']['sa_execution']['rederived_at_sa_time']
    else:
        assert record['action']['sa'] == 'No SA' and after_sa[0] == 'No SA'
    record.update(case=case, initial_sa_choice=before_sa, post_command_sa_choice=after_sa,
                  final_counts=counts(state))
    out['NP8-02'].append(record)

# The legal Suborn-through-executor control starts from the identical empty board.
state = board()
action = dispatch_bot_turn(state, rc.AEDUI)
action['sa'] = rc.SA_SUBORN
record = run(state, action=action)
assert record['execution']['sa_execution']['executed']
assert counts(state) == {'aedui_warbands': 3, 'belgic_warbands': 0, 'aedui_allies': 1}
assert state['resources'][rc.AEDUI] == 5
record.update(case='source_required_post_rally_suborn_execution_control', final_counts=counts(state),
              supplied_plan_note='Dispatcher plan supplied a Suborn SA label so its existing post-Command live chooser runs; the executor itself derives the actual legal operations.')
out['NP8-02'].append(record)
out['integrity_checks_passed'] = integrity_checks
out['all_observation_assertions_passed'] = True
print(json.dumps(out, indent=2, sort_keys=True))
