"""Resume the archived pre-Interlude save without modifying its bytes."""

import argparse
from collections import Counter
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    sys.path.insert(0, str(repo))
    from fs_bot import rules_consts as rc
    from fs_bot.board.pieces import count_pieces
    from fs_bot.engine import interlude
    from fs_bot.engine.interlude_reductions import ARVERNI_HALF, reduction_request
    from fs_bot.state.serialize import load_game
    from fs_bot.state.state_schema import check_structural_integrity, validate_state

    fixtures = repo / 'fs_bot/tests/fixtures/compatibility_8ef88e2'
    generator = fixtures / 'generate.py'
    spec = importlib.util.spec_from_file_location('old_save_fixture_driver', generator)
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    path = fixtures / 'pre-interlude.json'
    before, meta, log = load_game(path, validate=True)
    assert before['scenario'] == rc.SCENARIO_GALLIC_WAR and not before['interlude_completed']

    adjusted = []
    adjust = interlude._adjust_arverni_forces

    def log_adjustment(state):
        before_quota = reduction_request(state, ARVERNI_HALF)
        rng_before = driver.digest(state['rng'])
        result = adjust(state)
        adjusted.append(dict(before_quota=before_quota, rng_before=rng_before,
                             after_cohorts=reduction_request(state, ARVERNI_HALF)['cohorts'],
                             rng_after=driver.digest(state['rng']), result=result))
        return result

    loaded = dict(digest=driver.digest(before), scenario=before['scenario'],
                  winter_count=before['winter_count'], card=before['current_card'])
    interlude._adjust_arverni_forces = log_adjustment
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            continued = driver.continue_fixture('pre-interlude', before, meta, log)
    finally:
        interlude._adjust_arverni_forces = adjust

    board = continued['state']
    assert board['interlude_completed'] and board['scenario'] == rc.SCENARIO_PAX_GALLICA
    assert validate_state(board) == check_structural_integrity(board) == []
    adjustment, = adjusted
    output = dict(
        fixture_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        generator_sha256=hashlib.sha256(generator.read_bytes()).hexdigest(),
        loaded=loaded, continuation_sha256=driver.digest(continued), adjustment=adjustment,
        ending_scenario=board['scenario'], next_card=board['next_card'],
        rebuilt_deck_counts=Counter(map(str, board['deck'])),
        final_warbands={region: count_pieces(board, region, rc.ARVERNI, rc.WARBAND)
                        for region in board['spaces']},
    )
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
