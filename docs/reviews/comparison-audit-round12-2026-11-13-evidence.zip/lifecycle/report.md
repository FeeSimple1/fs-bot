# Twelfth comparison lifecycle review

FS revision `1563e41d84f61dfce43ce4008106eca2a1639aed` and LoD revision `2991ea279062773548ec390a1da75f3e85381702` were inspected. This lane changes no production code. The supplied rules and thirteen adopted provisional rulings govern the conclusions.

Two medium-priority findings were reproduced through the full third-Winter entry point. The 26 cases pass physical census and structural checks before and after and have no threshold winner before Winter. Both probe outputs match byte for byte across hash seeds 0 and 987.

## LC12-01

The NP Cisalpina relocation default removes three Roman Legions even though they can return to Provincia. That leaves too few Legions for the Britannia expedition. In the paired explicit relocation, all six Legions survive the evacuation, three go to the Harvest box and three go with Caesar to Britannia. The branch changes both Britannia occupation and the Senate result. Three seeds reproduce the failure, human delegation repeats it, and two controls per seed preserve the expedition.

The scenario allows human removal. The NP conclusion follows the general requirement to maximize applicable moves and the move-own priorities in Chapter 8. The reference to §1.4.1 in the voluntary-removal prohibition concerns reclamation and supplies no independent universal ban on scenario removals. The existing A5 allocation planner implements the relevant preservation behavior but is bypassed in this Interlude consumer.

Earlier WS-C30/WS-F01 explicitly preserved the NP fallback while repairing human allocations. That retained consumer is the subject of this finding.

## LC12-02

NP Belgae and Romans remove the City Ally Mandubii before the ordinary Ally Senones when the half-removal quota requires two of the three Allied Tribes in that Region. The generic bookkeeping helper sorts names, so it clears Lingones and then Mandubii. Own-removal priority instead retains the City. Explicit physical human allocations satisfy that priority on the same board. Carnutes/Aulerci controls show why some City pairs already work by alphabetical coincidence.

The earlier LC11-01 repair concerns Region ordering. This defect remains after the Region has been selected and concerns the physical Tribe chosen for removal.

## Cross-repository comparison

LoD `lod_ai/util/year_end.py` lines846–899 explicitly dispatches NP Leader redeployment to its planner and applies an off-map fallback only after that selection. `lod_ai/bots/indians.py` lines1668–1692 selects among legal destinations. The comparison led to checking whether FS’s human and NP seasonal choices reach equivalent physical planners.

LoD `lod_ai/util/year_end.py` lines1030–1123 selects seasonal deserters through controller-specific priorities, rescoring as individual removals change the board. This led to tracing the exact Allied Tribe selection behind FS’s aggregate Interlude quotas. These are engineering comparisons. The games retain their own distinct rules.

## Coverage and rejected hypotheses

Reviewed Winter phase sequencing, first-Winter exception consumption, post-Interlude final-Winter detection, Spring successor placement and markers, Senate Legion availability, Harvest quantities, paired-player victory, resource conversion, Interlude deck exclusions and preserved Capability identity, and Interlude force and evacuation choices. Compared these to LoD’s phase-completion cursor, year-end dispatch and physical removal selection. Earlier audit ledgers and the current provisional-ruling register were read for overlap.

A suspected forced-ineligibility leak across Spring was rejected because normal Event adjustment consumes the single-card counter before Winter. Active A38 duplication was already repaired and the deck builder excludes the substituted identity. The post-Interlude final Winter is detected from the remaining deck and was already repaired. The prospective Warband visibility-removal issue was not counted because full Spring hides the retained pieces before play resumes. Potential deterministic German Settlement replacement ordering was left unconfirmed because the applicable replacement priority needs a distinct fixture and source analysis.

The witnesses are controlled scenario-derived boards with a supplied third-Winter cursor. They establish the specified public failures and controls. They do not estimate their frequency in ordinary games, add a new rule interpretation beyond the identified priority application, or claim exhaustive lifecycle coverage.
