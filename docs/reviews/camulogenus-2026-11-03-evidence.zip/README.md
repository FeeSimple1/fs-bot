# Camulogenus evidence, 3 November 2026 (America/Chicago)

The accepted source and counts are in acceptance-results.json. The final
accepted integration matrix uses attempt3 and the suite uses candidate-suite-final.xml; compare their source
hash with candidate-source-attempt3.json. Apply prepared-source-attempt3.patch
over parent 4b112b1e5c180b8ff243e9b8e4d8ca76ad22d43e to reproduce the Python
source, including tests. The canonical rules and balance baseline are protected.

Parent-attempt1 contains fresh Python 3.12.14 parent results used in the
comparison. Parent-records and prior-tools are retained historical material,
not an accepted runtime substitute or part of the final denominators.

Attempt1 is superseded by the later related default-planner repair. Attempt2
changed during execution and is not accepted; its full suite was interrupted.
Development fixture/import/wrapper corrections and the independent old-source
failure logs are retained separately. Failed tests are not counted as distinct
production bug groups.

Use integration_matrix.py --help for the matrix runner. Source fingerprints
must match the intended candidate, and output directories must be new. Its
paths are relative to this evidence directory and sibling fs-bot and
fs-camulogenus-before directories. Install the project's test dependencies
in a Python 3.12 environment; full-suite commands use optional pytest-xdist
(-n 2), which does not change project runtime requirements.

The archive includes archive-index.json with byte sizes and SHA-256 hashes
for every other member. GitHub CI is checked after publishing and is reported
separately from this pre-publication evidence.
