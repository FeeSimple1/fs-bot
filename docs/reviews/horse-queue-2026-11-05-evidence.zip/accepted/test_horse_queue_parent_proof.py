"""Behavior probes using only APIs already available in the parent."""
import pytest
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece
from fs_bot.cards.capabilities import activate_capability
from fs_bot.commands.common import free_action_scope
from fs_bot.engine.execute import _execute_battle
from fs_bot.state.state_schema import build_initial_state

REGIONS=(rc.NERVII,rc.TREVERI)


def position():
    st=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=23)
    st['non_player_factions']={rc.ARVERNI}
    for r in REGIONS:
        place_piece(st,r,rc.ARVERNI,rc.WARBAND,6)
        place_piece(st,r,rc.ROMANS,rc.AUXILIA,4)
    activate_capability(st,59,rc.EVENT_UNSHADED)
    return st


def run(st,monkeypatch):
    rows=[]
    def combat(board,region,*args,**kwargs):
        rows.append((region,board.get('event_modifiers',{}).get('card59_unshaded_region')))
        return {}
    monkeypatch.setattr('fs_bot.engine.execute.resolve_battle',combat)
    with free_action_scope(st,rc.ARVERNI):
        result=_execute_battle(st,rc.ARVERNI,{'details':{'battle_plan':[
            {'region':r,'target':rc.ROMANS} for r in REGIONS]}},_skip_absent_targets=True)
    assert result['executed'] and not result['errors']
    return rows


def test_human_reserves_for_later_battle(monkeypatch):
    st=position();seen=[]
    def agent(board,faction,request):
        if request['kind']=='horse_window':
            seen.append((faction,request['region']))
            return {'action':'reserve' if request['region']==REGIONS[0] else 'activate'}
    st['decision_agent']=agent
    assert run(st,monkeypatch)==[(REGIONS[0],None),(REGIONS[1],REGIONS[1])]
    assert seen==[(rc.ROMANS,r) for r in REGIONS]


def test_human_declines_for_whole_command(monkeypatch):
    st=position()
    st['decision_agent']=lambda board,faction,request: {'action':'decline'} if request['kind']=='horse_window' else None
    assert run(st,monkeypatch)==[(r,None) for r in REGIONS]


def test_forecast_includes_optional_human_activation_choices(monkeypatch):
    from fs_bot.cards import base_arduenna_np as policy
    from fs_bot.engine.agent import consult_agent
    st=position()
    def fake_command(board,*args,**kwargs):
        def choice(region,actions):
            result=consult_agent(board,rc.ROMANS,{'kind':'horse_window','card_id':59,
                'side':rc.EVENT_UNSHADED,'owner':rc.ROMANS,'region':region,
                'attacker':rc.ARVERNI,'defender':rc.ROMANS,'auxilia':4,
                'potential_regions':[REGIONS[1]] if region==REGIONS[0] else [],'actions':actions})
            return result['action'] if result else 'activate'
        first=choice(REGIONS[0],['activate','reserve','decline'])
        if first=='reserve':score=0 if choice(REGIONS[1],['activate','decline'])=='activate' else 3
        else:score=1 if first=='activate' else 2
        for _ in range(score):
            consult_agent(board,rc.ROMANS,{'kind':'loss_order','region':REGIONS[0],
                'num_losses':1,'pieces':[(rc.LEGION,None)]})
        return {'executed':True,'errors':[]}
    monkeypatch.setattr('fs_bot.engine.execute._execute_battle',fake_command)
    assert policy.predicted_legion_losses(st,REGIONS)==0


def test_raw_default_control(monkeypatch):
    st=position()
    assert run(st,monkeypatch)==[(r,REGIONS[0]) for r in REGIONS]


def test_inactive_capability_control(monkeypatch):
    st=position()
    activate_capability(st,59,rc.EVENT_SHADED)
    assert run(st,monkeypatch)==[(r,None) for r in REGIONS]
