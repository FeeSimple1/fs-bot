"""Source-derived BE-04 adjacent mechanical witnesses on an explicit checkout."""
from pathlib import Path
import sys,json,subprocess,hashlib
repo=Path(sys.argv[1]);sys.path.insert(0,str(repo))
from fs_bot import rules_consts as rc
from fs_bot.state.state_schema import build_initial_state,validate_state
from fs_bot.board.pieces import place_piece,count_pieces,get_leader_in_region
from fs_bot.cards.card_effects import _ally_tribe,execute_event
from fs_bot.engine.execute import _execute_event
s=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=816)
s['senate']={'position':rc.INTRIGUE,'firm':False};s['non_player_factions']={rc.ROMANS}
r=_execute_event(s,rc.ROMANS,{'command':rc.FIRST_DID_EVENT,'details':{'card_id':2,'text_preference':rc.EVENT_UNSHADED}})
legiones={'executed':r['executed'],'senate':s['senate'],'placed_legions':count_pieces(s,rc.PROVINCIA,rc.ROMANS,rc.LEGION),'integrity':validate_state(s)}
s=build_initial_state(rc.SCENARIO_ARIOVISTUS,seed=816)
s['executing_faction']=rc.ROMANS;s['event_params']={'region':rc.SUGAMBRI}
for visibility in (rc.HIDDEN,rc.REVEALED,rc.SCOUTED):
    place_piece(s,rc.SUGAMBRI,rc.GERMANS,rc.WARBAND,piece_state=visibility)
place_piece(s,rc.SUGAMBRI,rc.GERMANS,rc.LEADER,leader_name=rc.SUCCESSOR)
place_piece(s,rc.SUGAMBRI,rc.GERMANS,rc.SETTLEMENT)
_ally_tribe(s,rc.TRIBE_SUGAMBRI,rc.GERMANS)
place_piece(s,rc.SUGAMBRI,rc.ROMANS,rc.AUXILIA,8)
assert validate_state(s)==[]
execute_event(s,'A18')
rhenus={'remaining_germans':count_pieces(s,rc.SUGAMBRI,rc.GERMANS),
        'remaining_warbands':count_pieces(s,rc.SUGAMBRI,rc.GERMANS,rc.WARBAND),
        'remaining_leader':get_leader_in_region(s,rc.SUGAMBRI,rc.GERMANS),'integrity':validate_state(s)}
h=hashlib.sha256();files=sorted(repo.glob('fs_bot/**/*.py'),key=lambda p:p.relative_to(repo).as_posix())
for p in files:
    h.update(p.relative_to(repo).as_posix().encode());h.update(b'\0');h.update(p.read_bytes())
print(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
    'python_sha256':h.hexdigest(),'python_files':len(files),'legiones':legiones,'a18':rhenus},indent=2))
