"""Repeat exactly five audited legacy games under hash seed 7."""
import argparse
import os
import platform
import sys
from pathlib import Path
from integration_matrix import REPO, SCENARIOS, identity, require, write_json
sys.path.insert(0, str(REPO))
from fs_bot.tools.run_batch import play_one
p = argparse.ArgumentParser()
p.add_argument('--out', required=True)
args = p.parse_args()
out = Path(args.out)
require(not out.exists(), 'Do not overwrite a previous attempt')
before = identity()
records = [play_one((sc, 1, 'legacy')) for sc in SCENARIOS]
require(before == identity(), 'Source changed')
write_json(out, {'metadata': {'source': before, 'python': platform.python_version(), 'hash_seed': int(os.environ['PYTHONHASHSEED']),
                             'edition': 'legacy', 'seeds': [1]}, 'records': records})
print(f'games={len(records)} completed={sum(r["completed"] for r in records)}')
raise SystemExit(0 if all(r['completed'] for r in records) else 1)
