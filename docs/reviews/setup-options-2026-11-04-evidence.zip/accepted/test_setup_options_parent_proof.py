"""Unchanged behavioral probes using only APIs present in the parent."""
import pytest
from fs_bot import rules_consts as rc
from fs_bot.state.setup import setup_scenario, _build_base_deck, _build_ariovistus_deck, _setup_great_revolt
from fs_bot.state.state_schema import build_initial_state
from fs_bot.engine.game_engine import start_game, advance_to_next_card, is_frost


def test_sudden_frost_swaps_visible_cards():
    state = setup_scenario(rc.SCENARIO_GREAT_REVOLT, seed=9)
    state['sudden_frost'] = True
    state['deck'] = [1, rc.WINTER_CARD, 2]
    assert start_game(state) == rc.WINTER_CARD
    assert state['played_cards'] == [rc.WINTER_CARD]
    assert state['next_card'] == 1
    assert advance_to_next_card(state) == 1


@pytest.mark.parametrize('scenario,builder', [(rc.SCENARIO_RECONQUEST, _build_base_deck),
                                             (rc.SCENARIO_ARIOVISTUS, _build_ariovistus_deck)])
def test_even_initiative_shuffles_separate_symbol_piles(scenario, builder):
    state = build_initial_state(scenario, seed=9)
    state['even_initiative'] = True
    class Observer:
        def __init__(self, rng):
            self.rng, self.sizes = rng, []
        def shuffle(self, items):
            self.sizes.append(len(items))
            self.rng.shuffle(items)
    observer = Observer(state['rng'])
    state['rng'] = observer
    builder(state, 45, [3, 6, 9])
    assert observer.sizes[:5] == [18, 18, 18, 18, 48]
    assert len(state['deck']) == 48


def test_short_great_revolt_uses_two_winters():
    state = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=9)
    state['short_great_revolt'] = True
    _setup_great_revolt(state)
    assert len(state['deck']) == 32
    assert state['deck'].count(rc.WINTER_CARD) == 2


def test_standard_frost_control():
    state = setup_scenario(rc.SCENARIO_GREAT_REVOLT, seed=9)
    state['deck'] = [1, rc.WINTER_CARD, 2]
    assert start_game(state) == 1
    assert is_frost(state)
    assert advance_to_next_card(state) == rc.WINTER_CARD


def test_standard_great_revolt_control():
    state = setup_scenario(rc.SCENARIO_GREAT_REVOLT, seed=9)
    assert len(state['deck']) == 48
    assert state['deck'].count(rc.WINTER_CARD) == 3
