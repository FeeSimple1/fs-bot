Falling Sky second repair batch — final evidence

Final accepted-source candidate: attempt5, based on git04b4b70,
Python SHA071485179ff2949ba9e2163ca48f6761c52f617084f90a0a60ee521f35926d8b.
The repository report and final-results.json give the final acceptance status.

attempt1 through attempt4 are superseded. Their outcomes, command logs,
source manifests, failure dispositions and original comparisons are retained.
Never pool them into the final matrix or relabel their source IDs.

attempt5/results.json is the ORIGINAL fixed-baseline verification. Its sole
balance failure remains failed: Great Revolt Aedui1/20 to5/20 (+20points)
against the unchanged15point band. verify.py intentionally requires that
original frozen baseline; after a reviewed refresh, it is not the final
acceptance check. Do not overwrite its original result by rerunning it on
the refreshed repository.

The reviewed final candidate and independent audits are in attempt5.
baseline-acceptance.json records the root's reviewed refresh. Separate
post-baseline/balance.status.json and tests.status.json record fresh checks
against the installed exact candidate, with unchanged Python and threshold.
The final full matrix is200 bot games,80 mixed executions including replay,
and50 strict-census executions. The fresh balance command adds100 bot
executions; diagnostic traces are counted separately.

Causal evidence is a source chain: attempt4's37 paired winner traces remain
at SHA6155e2b5..., while attempt5/a70-causal-review verifies the immediate
three changed states against SHA071485.... The remaining97 final states
match; this is not a claim that all intermediate paths are identical.
The historical reconstruction is isolated; live source was not changed.

Raw game records, JUnit, subprocess exit statuses, command arguments and
hash-seed settings are retained. Local full tests used optional pytest-xdist
with six workers; ordinary python -m pytest -q is still the project entrypoint.
Some scripts are final reproducibility utilities; per-attempt source records
and raw outputs retain their original identities. Absolute workspace paths
in historical metadata describe the environment in which runs occurred.

ARCHIVE_MANIFEST.json contains SHA256 and size for every other archived file.
The ZIP was read back and each member checked. No references, canonical
constants or provisional rulings were changed. Q-O38 remains open.
