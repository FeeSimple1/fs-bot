# Ninth comparative audit: lifecycle lane

Audited `FeeSimple1/fs-bot` at `f4c8372c396981c0a31dc6f4545e67f8c6f2e981`; engineering comparator `FeeSimple1/lod-bot` at `2991ea279062773548ec390a1da75f3e85381702`. No production, reference, test, or documentation files in either repository were changed by this lane.

## LC9-01 — Roman non-player Quarters payment planning forgets troops arriving in a later-visited Region

Priority: **medium**. Status: confirmed, open.

### Expected and observed

Two Roman Auxilia leave Devastated Morini for adjacent non-Devastated Roman-Controlled Nervii, which already has one Auxilia. The area is cut off from all Supply Lines by Belgic Control. With 20 Resources, no local Fort or Ally, and no capability affecting costs, Non-player Romans must pay 6 Resources to retain all three Auxilia. No removal rolls are necessary.

The ordinary public `quarters_phase(state)` independently chooses and completes that exact relocation but pays only 2 Resources for one Auxilia. It rolls `[2, 5]` for the two others and removes one. Rome ends with two Nervii Auxilia and 18 Resources instead of three and 14. The same defect reproduces in **all five scenarios**. The board census and structural integrity checks are clean both before and after: this is a rules/decision error rather than an inventory corruption.

### Mechanism

`build_np_winter_relocations` walks the original `spaces` order. Its Morini evacuation adds two arrivals to `remaining[Nervii]` (lines 1921–1922). When the later Nervii iteration runs, the still-unmoved original board contains only its original Auxilia; line 1925 overwrites the accumulated two arrivals with that single original piece. The payment planner at lines 1939–1945 emits `pay: 1`. `winter._quarters_phase` submits this count unchanged after the actual moves. The payment executor properly rolls for the real unprotected remainder, making the decision-layer underestimate cause live troop losses.

Other overwriting branches are repair considerations; the reported witness specifically exercises line 1925. The same code can be reviewed for multiple arrivals and protected initial garrisons without counting unproved variants as separate bugs.

### Authority and implementation

- `Reference Documents/Chapter 8:974–981` (§8.8.7): Roman NPCs pay for all pieces necessary to avoid removal rolls, with the printed regional priority.
- `Reference Documents/Chapter 6:84–98` (§6.3.3): legal adjacent Quarters relocation, then the actual remaining Legion/Auxilia payment or roll; 2 Resources without a local Roman Ally, absent Devastation.
- `Reference Documents/Ariovistus/Chapter A6:139–142` (A6.3.3): the expansion retains Roman quartering, with the changed Supply endpoint.
- `fs_bot/bots/roman_bot.py:1873–1925`: original-board iteration and overwritten accumulated arrivals.
- `fs_bot/bots/roman_bot.py:1936–1949`: undercounted payment plan.
- `fs_bot/engine/winter.py:404–428`: public phase selects the non-player planner, applies relocations, then submits payment choices.
- `fs_bot/engine/winter.py:578–609` and `fs_bot/engine/quarters.py:510–570`: actual remaining pieces are paid or rolled.

The supplied sources are the game authorities. The comparator's `coin-implementation-lessons.md` boundary/late-consumer lessons and `lod_ai/tests/test_review_winter_quarters.py` actual-state year-end integration checks motivated the method; no Liberty or Death rule was imported.

### Controls and reproduction

Run `fs-bot/.venv/bin/python probe_lifecycle.py --repo /path/to/fs-bot --out-dir /new/output`.

`probe_lifecycle.py` generates one defect witness and four controls in each scenario, plus validated save/load repeats:

1. **Complete-payment public control:** the same planner-produced physical relocation, with only `pay` changed to 3, passes the normal public validator and `quarters_phase(..., relocations=plan)` preserves all three Auxilia at cost 6, without rolls.
2. **Opposite-direction automatic control:** Nervii's two Auxilia evacuate into Morini's one. Morini is visited earlier, so its original cohort is retained and later arrivals are added correctly. The unmodified public phase pays for all three and rolls none.
3. **Stationary-stack automatic control:** all three Auxilia start at Nervii, no evacuation. The public phase pays for three at cost 6, without rolls.
4. **Insufficient-budget automatic control:** the opposite-direction board has only 2 Resources. Its planner correctly requests payment for all three, but actual affordability permits only one. It then legitimately rolls `[2,5]` for two. This shows that the primary loss is not an affordability edge case.
5. Each main witness is saved with production `save_game`, restored with `load_game(validate=True)`, and repeats with exactly the same results.

All physical pieces are placed with `place_piece`; blockers are four single Belgic Warbands in Atrebates, Sugambri, Treveri and Britannia in original scenarios, three in expansion scenarios where Britannia is excluded. The permanent Provincia Fort is present. `has_supply_line` verifies both Roman Regions are disconnected before execution. All other factions have no Leader or Devastated stack and make no Quarters move, so the Roman position stays unchanged until its own turn. No monkeypatch, arbitrary low-level piece count, human callback, or fake control field is used. The only direct non-piece setup assigns legal treasury/seat metadata and a Devastated marker. The fixture begins at a controlled Quarters boundary, not a claimed naturally sampled campaign. Full-game incidence and strategic impact are not estimated.

### Prior-finding distinction and repair scope

Original WS-F05 concerned exact human visibility cohort choices. WS7-01 concerned previously unwired **non-Roman** Quarters procedures. Historical Q12 wired the Roman planner and documents its existing evacuation behavior. None records the subsequent destination-loop overwrite in Roman payment accounting. LC8-01 and LC8-02 concern final Winter detection and solitaire victory, not relocation or payment.

Repair by deriving the NPC payment plan from a validated post-relocation board or by correctly preserving both original staying pieces and incoming cohorts in its forecast. Preserve Fort/Ally free garrisons, Supply agreement handling, actual affordability, printed payment ordering, exact visibility and no-double-adjacent-move rules. Test multiple origins and both Region iteration directions, while leaving human-authored payment choices intact.

## Coverage and excluded known issues

Reviewed the full reference inventory, adopted-ruling index, Winter phases, Senate reinforcement/marker handling, Spring placement/cleanup, victory and Interlude flow, public Quarters validation/execution and non-player Quarters plans. Earlier ledgers through round 8 and the original 50-item ledger were checked for overlap. Round 8 finality and sole-human victory fixes remain present.

Two tempting leads were explicitly excluded rather than counted anew:

- Circumvallation Interlude clears unmarked forces: already recorded as `CV-PERSISTENCE`, including exact Interlude cohort cleanup, in `docs/reviews/circumvallation-persistence-followup-2026-11-04.md` and current status.
- Mandatory Aedui subsidy is checked after actions/Harvest rather than every low-resource instant: expressly documented approximation in `QUESTIONS.md:2139–2169` and `execute.maybe_np_aedui_subsidy`. No claim that this limitation is repaired or newly discovered.

No unresolved source conflict was promoted to a finding. This lane ran the directed probe, not the repository suite or new game matrix; those are owned by the validation lane.
