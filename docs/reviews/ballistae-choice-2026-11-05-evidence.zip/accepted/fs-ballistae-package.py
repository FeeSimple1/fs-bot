from pathlib import Path
import hashlib, io, json, platform, subprocess, tarfile, tempfile, zipfile
import xml.etree.ElementTree as ET
from fs_bot.tools.validation_metadata import source_identity

prefix = 'ballistae-choice-2026-11-05'
result = json.loads(Path('/tmp/fs-ballistae-results.json').read_text())
assert source_identity() == result['source']
suite = ET.parse('/tmp/fs-ballistae-full.xml').getroot().find('testsuite')
assert suite.attrib['tests'] == '8580'
assert all(suite.attrib[k] == '0' for k in ('failures', 'errors', 'skipped'))
assert sum(t.attrib['classname'].endswith('test_ballistae_choice') for t in suite) == 47
patch = subprocess.check_output(['git', 'diff', 'HEAD', '--', 'fs_bot'])
new_files = ('fs_bot/engine/ballistae_choice.py', 'fs_bot/cli/ballistae.py',
             'fs_bot/tests/test_ballistae_choice.py')
with tempfile.TemporaryDirectory(prefix='fs-ballistae-reconstruct-') as directory:
    root = Path(directory)
    parent = subprocess.check_output(['git', 'archive', result['source']['commit'], 'fs_bot'])
    with tarfile.open(fileobj=io.BytesIO(parent)) as archive:
        archive.extractall(root, filter='data')
    subprocess.run(['git', 'apply', '--unsafe-paths', '-'], cwd=root, input=patch, check=True)
    for name in new_files:
        (root / name).write_bytes(Path(name).read_bytes())
    files = sorted((root / 'fs_bot').rglob('*.py'))
    assert len(files) == 514
    digest = hashlib.sha256()
    for path in files:
        digest.update(str(path.relative_to(root)).encode()+b'\0'+path.read_bytes())
    assert digest.hexdigest() == result['source']['source_sha256']
result.update(full_suite=suite.attrib, python=platform.python_version(),
              source_reconstruction_verified=True,
              compatibility_limit='Older cross-revision histories that passed the formerly automatic removal may stop for the new owner choice. Raw None/default retains the old priority, excluding the protected Provincia Fort.')
commands = [
 'python -m pytest -q --junitxml=/tmp/fs-ballistae-full.xml',
 'python -m pytest -q fs_bot/tests/test_ballistae_choice.py fs_bot/tests/test_capabilities_base.py fs_bot/tests/test_besiege_choice.py fs_bot/tests/test_event_battle_choices.py fs_bot/tests/test_agent_interface.py fs_bot/tests/test_assistant_session.py fs_bot/tests/test_execute_integration.py',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --games 2 --workers 2 --out OUT',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
 'PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20',
 'PYTHONPATH=. python -m pytest -q /tmp/test_ballistae_parent_proof.py --junitxml=OUT.xml',
 'PYTHONPATH=. python /tmp/fs-ballistae-verify.py',
 'PYTHONPATH=. python /tmp/fs-ballistae-package.py',
]
result['commands'] = commands
Path('docs/reviews/'+prefix+'-results.json').write_text(json.dumps(result, indent=2)+'\n')
p = Path('docs/reviews/'+prefix+'.md')
s = p.read_text().replace('Final full-suite and evidence inspection pending.',
 f"**8,580 tests pass**, with zero failures, errors or skips ({float(suite.attrib['time']):.2f} seconds).")
x = result['mixed']
s = s.replace('Frozen source, protected inputs, final results and archive checksums are\nverified separately.', f'''All ten standard NPC records complete and audit cleanly with four ranked
Factions, consistent winner/ranking output, no integrity findings and only
legal-decline diagnostics. Every gameplay field and final board hash matches
the parent, excluding elapsed seconds, commit and source identity.

The complete mixed-seat JSON outputs match across hash seeds 0 and 987. They
cover {x['human_turns']} human turns, {x['event_turns']} Event attempts and {x['events_ok']} successful Events, with zero hard
findings and zero partial games. Their digest is `{x['batch_digest'][:16]}`.
Internal replay gives 40 executions total. The historical 100-game balance
check passes the existing band, with a maximum difference of
{result['balance']['maximum_absolute_delta_percentage_points']} percentage points and {result['balance']['historical_baseline_winner_changes']} winner changes versus the historical baseline. Those
historical comparisons are separate from the ten exact parent/current NPC
comparisons.

All 49 protected inputs match the parent byte for byte, comprising 47 supplied
references, canonical constants and the historical balance baseline. Archive
checksums and reconstruction of all 514 Python files verify the accepted source
digest. The first directed run exposed two mistaken test expectations about
ordinary combat casualties and the executor result envelope. Those fixtures
were corrected before acceptance; the superseded log is retained separately.''')
p.write_text(s)
p = Path('docs/current-status.md')
p.write_text(p.read_text().replace('Validation pending the final full suite and evidence inspection.',
 '''**8,580 tests pass**, including 47 new cases, with 349 focused tests passing.
Ten standard NPC records/final hashes match the parent, mixed-seat results
agree across hash seeds with zero hard findings or partials, and the historical
100-game balance guard passes its unchanged band. The report records the
frozen source, protected inputs, evidence and cross-revision replay limit.''', 1))
entries = {}
for name in ['fs-ballistae-full.xml', 'fs-ballistae-full.log', 'fs-ballistae-targeted.log',
 'fs-ballistae-mixed0.json', 'fs-ballistae-mixed0.log', 'fs-ballistae-mixed987.json',
 'fs-ballistae-mixed987.log', 'fs-ballistae-balance.log', 'fs-ballistae-proof-parent.xml',
 'fs-ballistae-proof-parent.log', 'fs-ballistae-proof-final.xml', 'fs-ballistae-proof-final.log',
 'test_ballistae_parent_proof.py', 'fs-ballistae-verify.py', 'fs-ballistae-package.py']:
    entries['accepted/'+name] = Path('/tmp/'+name).read_bytes()
for label, directory in [('parent', '/tmp/fs-ballistae-bots-parent'),
                         ('accepted', '/tmp/fs-ballistae-bots-final')]:
    for path in Path(directory).iterdir():
        if path.is_file():
            entries[label+'/bots/'+path.name] = path.read_bytes()
for name in ['fs-ballistae-initial.log', 'fs-ballistae-retry.log']:
    entries['development/'+name] = Path('/tmp/'+name).read_bytes()
entries['development/README.txt'] = b'The initial 43-case run had test-only failures expecting four Warbands after a Battle that correctly lost one, and reading a nonexistent command_execution result field. Corrected fixtures retain actual post-combat and full executor assertions. The next 84-case run includes the then-45 new cases and 39 existing capability tests. Accepted 349-case focused and 8580-case full runs use the final 47 new cases.\n'
entries['accepted/source.patch'] = patch
for name in new_files:
    entries['accepted/'+name] = Path(name).read_bytes()
protected = [p for p in Path('Reference Documents').rglob('*') if p.is_file()]
protected += [Path('fs_bot/rules_consts.py'), Path('fs_bot/tools/balance_baseline.json')]
entries['accepted/protected-inputs.json'] = json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}, indent=2).encode()
entries['accepted/results.json'] = json.dumps(result, indent=2).encode()
entries['commands.txt'] = ('\n'.join(commands)+'\n\nRun paired NPC batches and unchanged proof cases from their respective parent/current directories. Parent proof gives four behavioral failures and two passing controls; accepted proof gives six passing cases. All game matrices here are bounded general regression checks; directed tests exercise the new Ballistae request.\n').encode()
entries['README.txt'] = (f"Parent {result['source']['commit']}. Apply accepted/source.patch and copy the three accepted/fs_bot new files to reconstruct the accepted source. Digest {result['source']['source_sha256']} across 514 files. Full suite 8580 passed, 47 new cases, 349 focused tests. Six probes give four parent failures and two passing controls; all six pass on the repair. Ten standard NPC records/final hashes match parent. Mixed-seat complete JSON matches across hash seeds 0/987, with zero hard findings or partials. The historical 100-game balance guard passes its unchanged 15-point band. Original bundle remains 39/50 closed (78%), with BE-09 still open for Cards 13 and 59. {result['compatibility_limit']}\n").encode()
entries['SHA256SUMS.txt'] = ''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(entries.items())).encode()
p = Path('docs/reviews/'+prefix+'-evidence.zip')
with zipfile.ZipFile(p, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(p) as archive:
    assert archive.testzip() is None
    for line in archive.read('SHA256SUMS.txt').decode().splitlines():
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest
print(json.dumps(dict(suite=suite.attrib, archive_bytes=p.stat().st_size, source=result['source'])))
