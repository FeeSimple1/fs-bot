"""One exact run_batch.play_one with compact, ordered, read-only checkpoints.

Run from the desired repository checkout. The caller must supply its frozen
source digest and the already-audited expected final hash. No defaults launch
an unplanned matrix. This does not evaluate causal correctness or refresh data.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys


def sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scenario", required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--source-sha256", required=True)
    parser.add_argument("--expected-final-sha256", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if os.environ.get("PYTHONHASHSEED") != "0":
        parser.error("launch with PYTHONHASHSEED=0")
    if args.out.exists():
        parser.error("trace exists; preserve prior evidence and choose a fresh path")
    sys.path.insert(0, os.getcwd())
    from fs_bot import rules_consts as rc
    from fs_bot.tools import run_batch as batch
    from fs_bot.tools.validation_metadata import source_identity
    from fs_bot.state.serialize import encode
    from fs_bot.engine import execute as execution
    from fs_bot.engine import game_engine, winter, interlude
    from fs_bot.bots import bot_common
    from fs_bot.engine.victory import calculate_victory_score
    from fs_bot.board.pieces import count_pieces, get_available, get_leader_in_region
    from fs_bot.bots.bot_common import get_event_instruction

    source = source_identity()
    if source["source_sha256"] != args.source_sha256:
        parser.error("checkout differs from explicitly frozen source")
    checkpoints = []
    card_index = 0
    depth = 0
    active_card = None
    # These hashes are only an auxiliary view. Full state and all domain hashes
    # remain the primary comparison; no context key is silently ignored.
    board_domains = ("spaces", "tribes", "available", "removed_pieces", "removed_legions",
                     "fallen_legions", "legions_track", "resources", "markers", "capabilities",
                     "capability_owners", "event_modifiers", "eligibility", "forced_ineligible",
                     "senate", "spring_box_leaders", "scenario", "scenario_phase", "rng")

    def capsule(state, faction=None, detailed=False):
        value = {k: encode(state.get(k)) for k in
                 ("scenario", "scenario_phase", "interlude_completed", "winter_count", "final_year",
                  "current_card", "current_card_id", "next_card", "event_params", "executing_faction",
                  "can_play_event", "is_second_eligible", "_card_turn", "non_player_factions")}
        value["deck_winter_cards"] = sum(c == rc.WINTER_CARD for c in state.get("deck", []))
        value["played_winter_cards"] = sum(c == rc.WINTER_CARD for c in state.get("played_cards", []))
        value["roman_score"] = calculate_victory_score(state, rc.ROMANS)
        value["available_auxilia"] = get_available(state, rc.ROMANS, rc.AUXILIA)
        value["roman_resources"] = state.get("resources", {}).get(rc.ROMANS)
        if hasattr(game_engine, "next_winter_is_final"):
            value["queried_next_winter_is_final"] = game_engine.next_winter_is_final(state)
        if faction:
            instruction = get_event_instruction(active_card, faction, state["scenario"])
            if instruction:
                value["instruction"] = instruction.instruction
                value["conditional_no_event"] = bool(getattr(instruction, "conditional_no_event", False))
        if detailed:
            value["pieces_by_region_and_faction"] = {
                region: {f: count_pieces(state, region, f) for f in rc.FACTIONS}
                for region in sorted(state["spaces"])}
            value["roman_auxilia_by_region"] = {
                region: count_pieces(state, region, rc.ROMANS, rc.AUXILIA)
                for region in sorted(state["spaces"])}
            value["roman_leader_by_region"] = {
                region: get_leader_in_region(state, region, rc.ROMANS)
                for region in sorted(state["spaces"])}
            value["roman_physical_piece_detail_by_region"] = {
                region: encode(space.get("pieces", {}).get(rc.ROMANS, {}))
                for region, space in sorted(state["spaces"].items())}
            value["leaders_by_region_and_faction"] = {
                region: {f: get_leader_in_region(state, region, f) for f in rc.FACTIONS}
                for region in sorted(state["spaces"])}
            value["spring_box_leaders"] = encode(state.get("spring_box_leaders", []))
            value["vercingetorix_entry_unlocked"] = state.get("vercingetorix_entry_unlocked", "ABSENT")
            value["physical_available"] = encode(state["available"])
            value["markers"] = encode(state.get("markers", {}))
            value["event_modifiers"] = encode(state.get("event_modifiers", {}))
        return value

    def capture(stage, state, faction=None, position=None, payload=None):
        rng_before = state["rng"].getstate()
        snapshot = encode({k:v for k,v in state.items() if k != "decision_agent"})
        row = {"ordinal": len(checkpoints), "stage": stage, "card_index": card_index,
               "card": active_card, "faction": faction, "position": position, "depth": depth,
               "state_sha256": sha(snapshot),
               "domain_sha256": {str(k): sha(v) for k,v in snapshot.items()},
               "board_and_rng_sha256": sha({k:snapshot.get(k) for k in board_domains}),
               "rng_sha256": sha(snapshot.get("rng"))}
        if payload is not None:
            row["payload"] = encode(payload)
        if stage in ("before_decision", "before_execute", "before_card", "after_card") or stage.startswith(("before_phase:", "after_phase:", "before_choice:", "after_choice:")):
            row["facts"] = capsule(state, faction, detailed=True)
        row["state_snapshot"] = snapshot
        if stage.startswith(("before_phase:", "after_phase:", "before_choice:", "after_choice:")):
            row["phase_snapshot"] = snapshot
        assert state["rng"].getstate() == rng_before, "observer consumed gameplay RNG"
        assert encode({k:v for k,v in state.items() if k != "decision_agent"}) == snapshot, "observer mutated gameplay state"
        checkpoints.append(row)

    # Common logical boundaries on both sources; each wrapper calls the same
    # original function exactly once, never requests a second choice or RNG draw.
    def observe(module, name, logical, choice=False):
        original = getattr(module, name)
        def wrapper(state, *a, **kw):
            faction = a[0] if choice and a else None
            label = "choice:" if choice else "phase:"
            capture("before_" + label + logical, state, faction)
            checkpoints[-1]["observed_call"] = {"args": encode(a), "kwargs": encode(kw)}
            result = original(state, *a, **kw)
            capture("after_" + label + logical, state, faction, payload=result)
            return result
        setattr(module, name, wrapper)
        return original, wrapper
    for module, name in ((winter, "spring_phase"), (winter, "_place_successor_leaders"),
                         (interlude, "_adjust_belgae_forces"), (interlude, "_adjust_roman_forces")):
        observe(module, name, name)
    interlude_choice = ("_choose_interlude_leader_region" if hasattr(interlude, "_choose_interlude_leader_region")
                        else "_region_with_most_pieces")
    observe(interlude, interlude_choice, "interlude_leader_region", choice=True)
    original_choice, observed_choice = observe(bot_common, "get_leader_placement_region", "leader_placement_region", choice=True)
    # Existing imports may hold the public helper directly; preserve their
    # semantics while making the same observational boundary visible.
    for module_name, module in list(sys.modules.items()):
        if module_name.startswith("fs_bot.") and getattr(module, "get_leader_placement_region", None) is original_choice:
            setattr(module, "get_leader_placement_region", observed_choice)

    original_setup, original_start = batch.setup_scenario, batch.start_game
    original_card, original_bot = batch.play_card, batch.make_decision_func
    original_execute = execution.execute_decision

    def setup(*a, **kw):
        state = original_setup(*a, **kw)
        capture("after_setup", state)
        return state

    def start(state, *a, **kw):
        nonlocal active_card
        result = original_start(state, *a, **kw)
        active_card = state.get("current_card")
        capture("after_start", state)
        return result

    def bot_factory(*a, **kw):
        bot = original_bot(*a, **kw)
        def decide(state, faction, options, position):
            capture("before_decision", state, faction, position, {"options": options})
            answer = bot(state, faction, options, position)
            capture("after_decision", state, faction, position, answer)
            return answer
        return decide

    def execute(state, faction, decision):
        nonlocal depth
        depth += 1
        capture("before_execute", state, faction, payload=decision)
        try:
            result = original_execute(state, faction, decision)
            capture("after_execute", state, faction, payload=result)
            return result
        finally:
            depth -= 1

    def card(state, *a, **kw):
        nonlocal card_index, active_card
        card_index += 1
        active_card = state.get("current_card")
        capture("before_card", state)
        result = original_card(state, *a, **kw)
        capture("after_card", state, payload=result)
        return result

    batch.setup_scenario, batch.start_game = setup, start
    batch.play_card, batch.make_decision_func = card, bot_factory
    execution.execute_decision = execute
    record = batch.play_one((args.scenario, args.seed, "legacy"))
    after = source_identity()
    matched = record.get("final_state_sha256") == args.expected_final_sha256
    passed = matched and after["source_sha256"] == source["source_sha256"]
    output = {"trace_version": 3, "source": source, "source_after": after, "scenario": args.scenario,
              "seed": args.seed, "expected_final_state_sha256": args.expected_final_sha256,
              "final_hash_matches_audited_record": matched, "passed": passed,
              "observer": "Ordered exact play_one boundaries; RNG and whole-state preservation checked; full encoded snapshots retained at every boundary. Passed verifies source and observer result against the recorded game, not rules correctness or audit acceptance.",
              "record": record, "checkpoints": checkpoints}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(output, sort_keys=True).encode()
    compressed = gzip.compress(encoded, mtime=0)
    temporary = args.out.with_name(args.out.name + '.writing')
    with temporary.open('xb') as stream:
        stream.write(compressed)
        stream.flush()
        os.fsync(stream.fileno())
    assert gzip.decompress(temporary.read_bytes()) == encoded
    temporary.rename(args.out)
    assert gzip.decompress(args.out.read_bytes()) == encoded
    print(json.dumps({k:v for k,v in output.items() if k not in ("record", "checkpoints")} |
                     {"winner": record.get("winner"), "cards": record["cards"],
                      "completed": record["completed"], "checkpoints": len(checkpoints)}, indent=2))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
