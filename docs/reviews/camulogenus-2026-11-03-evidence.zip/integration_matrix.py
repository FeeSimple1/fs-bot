"""Bounded Camulogenus acceptance matrix; candidate requires explicit freeze SHA."""
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
from pathlib import Path
import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'fs-bot'
PARENT = HERE.parent / 'fs-camulogenus-before'
EXPECTED_PARENT = '4b112b1e5c180b8ff243e9b8e4d8ca76ad22d43e'
EXPECTED_PARENT_SHA = '90a57ffbce8c94a9a4dc2690b15c5cce3bfa45e6b7f2e0b4af367ca883efeb06'
sys.path.insert(0, str(REPO))
from fs_bot import rules_consts as rc

SCENARIOS = (rc.SCENARIO_PAX_GALLICA, rc.SCENARIO_RECONQUEST,
             rc.SCENARIO_GREAT_REVOLT, rc.SCENARIO_ARIOVISTUS,
             rc.SCENARIO_GALLIC_WAR)
EDITIONS = ('legacy', 'original', 'second-edition')
SEEDS = {'legacy': list(range(1, 21)), 'original': [201, 202], 'second-edition': [201, 202]}
IGNORED_RECORD_FIELDS = {'seconds', 'commit', 'source_sha256'}


def read_json(path):
    return json.loads(path.read_text())


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def require(value, message='Required acceptance check failed'):
    if not value:
        raise AssertionError(message)


def identity(repo=REPO):
    paths = sorted((repo / 'fs_bot').rglob('*.py'))
    digest, files = hashlib.sha256(), {}
    for path in paths:
        name, data = path.relative_to(repo).as_posix(), path.read_bytes()
        digest.update(name.encode() + b'\0' + data)
        files[name] = hashlib.sha256(data).hexdigest()
    commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
    changed = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD', '--', 'fs_bot'], cwd=repo, text=True).splitlines()
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', 'fs_bot'], cwd=repo, text=True).splitlines()
    return {'commit': commit, 'python_sha256': digest.hexdigest(), 'python_files': len(paths),
            'python_worktree_changes': any(p.endswith('.py') for p in changed + untracked), 'files': files}


def protected_files(repo=REPO):
    paths = sorted(p for p in (repo / 'Reference Documents').rglob('*') if p.is_file())
    paths += [repo / 'fs_bot/rules_consts.py', repo / 'fs_bot/tools/balance_baseline.json']
    return {p.relative_to(repo).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}


def jobs(out, parent=False):
    result = []
    for edition in EDITIONS:
        seeds = SEEDS[edition]
        name = 'bots-' + edition
        result.append({'name': name, 'hash_seed': '0', 'args': ['-m', 'fs_bot.tools.run_batch',
            '--seeds', f'{seeds[0]}-{seeds[-1]}', '--card-edition', edition, '--workers', '2', '--out', str(out / name)]})
    if parent:
        return result
    for edition in EDITIONS:
        for hash_seed in ('0', '7'):
            for kind, module in [('fuzz', 'player_fuzz'), ('census', 'error_census')]:
                name = f'{kind}-{edition}-{hash_seed}'
                args = ['-m', 'fs_bot.tools.' + module, '--seeds', '201-202', '--card-edition', edition,
                        '--out', str(out / (name + '.json'))]
                if kind == 'census':
                    args.append('--strict')
                result.append({'name': name, 'hash_seed': hash_seed, 'args': args})
    result.append({'name': 'bot-repeat-7', 'hash_seed': '7',
                   'args': [str(HERE / 'repeat_bots.py'), '--out', str(out / 'bot-repeat-7.json')]})
    return result


def checked_records(path, edition, seeds):
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    expected = {(sc, seed, edition) for sc in SCENARIOS for seed in seeds}
    require(len(rows) == len(expected) and {(r['scenario'], r['seed'], r['card_edition']) for r in rows} == expected,
            f'{path}: exact record coverage')
    for row in rows:
        require(all(row.get(k) is True for k in ('completed', 'game_completed', 'audit_completed')), 'Incomplete audited game')
        require(not row['errors'] and not row['integrity_findings'], 'Engine error or integrity finding')
        require(bool(row['final_state_sha256']) and len(row['final_ranking']) == 4, 'Hash/ranking missing')
        require(not row['engine_ranking_output_missing'] and not row['winner_differs_from_highest_margin'], 'Engine ranking absent/disagrees')
        require(all(d['severity'] == 'legal-decline' for d in row['diagnostics']), 'Nonlegal diagnostic')
    return rows


def verify(out, before, protected, runs, repo, parent=False):
    checks, failures, bots = [], [], {}
    def check(name, callback):
        try:
            value = callback()
        except Exception as exc:
            failures.append({'check': name, 'error': repr(exc)})
            return None
        checks.append(name)
        return value
    check('source frozen', lambda: require(identity(repo) == before))
    check('protected inputs unchanged', lambda: require(protected_files(repo) == protected == read_json(HERE / 'protected-before.json')))
    check('commands passed with frozen inputs', lambda: require(all(r['exit_code'] == 0 and r['source_unchanged_after'] and r['protected_unchanged_after'] for r in runs)))
    for edition in EDITIONS:
        def validate_bot(edition=edition):
            rows = checked_records(out / ('bots-' + edition) / 'games.jsonl', edition, SEEDS[edition])
            meta = read_json(out / ('bots-' + edition) / 'metadata.json')
            require(meta['source_sha256'] == before['python_sha256'] and meta['commit'] == before['commit'])
            require(meta['python'] == platform.python_version() and meta['hash_seed'] == 0 and meta['all_factions_bots'])
            require(meta['seeds'] == SEEDS[edition] and set(meta['scenarios']) == set(SCENARIOS) and meta['card_edition'] == edition)
            require(all(r['source_sha256'] == before['python_sha256'] and r['commit'] == before['commit'] for r in rows))
            return rows
        rows = check('audited bot records and provenance ' + edition, validate_bot)
        if rows is not None:
            bots[edition] = rows
    result = {'source': {k: v for k, v in before.items() if k != 'files'}, 'python': platform.python_version(),
              'checks_passed': checks, 'failures': failures, 'protected_input_count': len(protected),
              'bot_games': sum(len(v) for v in bots.values()), 'bot_editions': {k: len(v) for k, v in bots.items()}}
    if parent:
        result['passed'] = not failures
        write_json(out / 'integration-results.json', result)
        return result
    def repeat_check():
        data = read_json(out / 'bot-repeat-7.json')
        require(data['metadata']['source'] == before and data['metadata']['hash_seed'] == 7 and data['metadata']['python'] == platform.python_version())
        rows = data['records']
        require(len(rows) == 5 and {(r['scenario'], r['seed']) for r in rows} == {(sc, 1) for sc in SCENARIOS})
        original = {(r['scenario'], r['seed']): r for r in bots['legacy']}
        for row in rows:
            prior = original[row['scenario'], row['seed']]
            require({k: v for k, v in row.items() if k not in IGNORED_RECORD_FIELDS} ==
                    {k: v for k, v in prior.items() if k not in IGNORED_RECORD_FIELDS}, 'Cross-hash bot record mismatch')
        return len(rows)
    result['bot_hash_seed_repeat_executions'] = check('five exact cross-hash bot records', repeat_check)
    fuzz, census = {}, {}
    for edition in EDITIONS:
        def common(kind):
            a, b = [read_json(out / f'{kind}-{edition}-{seed}.json') for seed in ('0', '7')]
            require(a == b, 'Cross-hash JSON mismatch')
            require((out / f'{kind}-{edition}-0.log').read_bytes() == (out / f'{kind}-{edition}-7.log').read_bytes(), 'Cross-hash stdout mismatch')
            m = a['metadata']
            require(m['source_sha256'] == before['python_sha256'] and m['commit'] == before['commit'])
            require(m['python'] == platform.python_version() and m['seeds'] == [201, 202] and m['card_edition'] == edition and set(m['scenarios']) == set(SCENARIOS))
            return a
        def fuzz_check():
            a = common('fuzz')
            require(a['games'] == len(a['records']) == 10)
            require({(r['scenario'], r['seed']) for r in a['records']} == {(sc, seed) for sc in SCENARIOS for seed in (201, 202)})
            require(a['metadata']['replay'] and a['metadata']['reactive'] and a['metadata']['events'])
            require(a['hard_findings'] == a['partial'] == 0 and not a['by_kind'])
            require(all(r['game_completed'] and not r['findings'] and r['partial'] == 0 and r['digest'] and r['card_edition'] == edition for r in a['records']))
            return {k: a[k] for k in ('games', 'human_turns', 'event_turns', 'events_ok', 'partial', 'hard_findings', 'batch_digest')}
        def census_check():
            a = common('census')
            require(a['metadata']['strict'] and a['games'] == a['completed'] == 10 and a['failed_games'] == a['illegal'] == 0 and not a['failures'])
            require(all(k == 'legal-decline' or v == 0 for k, v in a['by_severity'].items()))
            require(all(r['severity'] == 'legal-decline' or r['n'] == 0 for r in a['counts']))
            return a['by_severity']
        fuzz[edition] = check('mixed replay plus exact cross-hash JSON/stdout ' + edition, fuzz_check)
        census[edition] = check('strict census plus exact cross-hash JSON/stdout ' + edition, census_check)
    result.update(fuzz=fuzz, census_severities=census,
                  mixed_seat_distinct_cases=sum(v['games'] for v in fuzz.values() if v),
                  mixed_seat_executions_including_replay_and_hash_repeat=4*sum(v['games'] for v in fuzz.values() if v),
                  strict_census_executions=20*sum(v is not None for v in census.values()))
    def compare_parent():
        prior_root = HERE / 'parent-attempt1'
        prior_result = read_json(prior_root / 'integration-results.json')
        require(prior_result['passed'] and prior_result['python'] == platform.python_version())
        require(prior_result['source']['python_sha256'] == EXPECTED_PARENT_SHA and prior_result['source']['commit'] == EXPECTED_PARENT)
        differences = []
        for edition, rows in bots.items():
            previous = {(r['scenario'], r['seed']): r for r in checked_records(prior_root / ('bots-' + edition) / 'games.jsonl', edition, SEEDS[edition])}
            for row in rows:
                old = previous[row['scenario'], row['seed']]
                fields = sorted(k for k in set(row) | set(old) if k not in IGNORED_RECORD_FIELDS and row.get(k) != old.get(k))
                if fields:
                    differences.append({'scenario': row['scenario'], 'seed': row['seed'], 'card_edition': edition, 'changed_fields': fields})
        require(sum(map(len, bots.values())) == 120)
        write_json(out / 'parent-semantic-differences.json', differences)
        return {'games': 120, 'all_editions_semantic_changes': len(differences), 'causal_review_required': bool(differences),
                'provenance': 'Fresh parent-attempt1 records at the same Python runtime; ignores only seconds, commit and source_sha256.'}
    result['parent_comparison'] = check('120 paired semantic records at same runtime', compare_parent)
    def balance_check():
        baseline = read_json(REPO / 'fs_bot/tools/balance_baseline.json')['games']
        expected = {f'{sc}|{seed}' for sc in SCENARIOS for seed in range(1, 21)}
        require(set(baseline) == expected and len(bots['legacy']) == 100)
        rates = []
        for sc in SCENARIOS:
            old = Counter(baseline[f'{sc}|{seed}']['winner'] for seed in range(1, 21))
            new = Counter(r['winner'] for r in bots['legacy'] if r['scenario'] == sc)
            for faction in sorted(set(old) | set(new)):
                rates.append({'scenario': sc, 'faction': faction, 'before_wins': old[faction], 'after_wins': new[faction],
                              'percentage_point_change': 5*(new[faction]-old[faction])})
        data = {'games': 100, 'existing_band': 0.15, 'baseline_changed': False,
                'baseline_sha256': protected['fs_bot/tools/balance_baseline.json'], 'rate_changes': rates,
                'passed': all(abs(r['percentage_point_change']) <= 15 for r in rates)}
        write_json(out / 'balance-comparison.json', data)
        require(data['passed'], 'Unchanged balance guardrail failed')
        return data
    result['baseline_comparison'] = check('existing 100-game 15-point balance guardrail', balance_check)
    result['planned_counts'] = {'bots': 120, 'mixed_distinct': 30, 'mixed_executions': 120, 'strict_census_executions': 60, 'bot_hash_seed_repeat_executions': 5}
    result['passed'] = not failures
    write_json(out / 'integration-results.json', result)
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--mode', choices=('plan', 'parent', 'candidate'), default='plan')
    p.add_argument('--label', default='attempt1')
    p.add_argument('--expected-source-sha')
    args = p.parse_args()
    require('/' not in args.label and '\\' not in args.label and not args.label.startswith('.'))
    parent = args.mode == 'parent'
    repo = PARENT if parent else REPO
    out = HERE / args.label
    plan = jobs(out, parent)
    if args.mode == 'plan':
        write_json(HERE / 'matrix-plan.json', {'status': 'Prepared only; no candidate started', 'python': platform.python_version(), 'jobs': plan,
                   'counts': {'bots': 120, 'mixed_distinct': 30, 'mixed_executions': 120, 'census': 60, 'bot_hash_repeats': 5}})
        print('Prepared candidate plan; no candidate games started')
        return 0
    before, protected = identity(repo), protected_files(repo)
    require(before['commit'] == EXPECTED_PARENT and protected == read_json(HERE / 'protected-before.json'))
    require(before['python_sha256'] == (EXPECTED_PARENT_SHA if parent else args.expected_source_sha), 'Source not frozen/expected')
    if parent:
        require(not before['python_worktree_changes'])
    out.mkdir(exist_ok=False)
    write_json(out / 'source-manifest-before.json', before)
    write_json(out / 'protected-before.json', protected)
    write_json(out / 'planned-commands.json', plan)
    def run(job):
        started = time.monotonic()
        env = dict(os.environ, PYTHONHASHSEED=job['hash_seed'], PYTHONPATH=str(repo))
        command = [sys.executable, *job['args']]
        require(identity(repo) == before and protected_files(repo) == protected, 'Source changed before job')
        with (out / (job['name'] + '.log')).open('w') as stream:
            r = subprocess.run(command, cwd=repo, env=env, stdout=stream, stderr=subprocess.STDOUT)
        record = {**job, 'command': command, 'cwd': str(repo), 'exit_code': r.returncode,
                  'elapsed_seconds': round(time.monotonic()-started, 3),
                  'source_unchanged_after': identity(repo) == before, 'protected_unchanged_after': protected_files(repo) == protected}
        write_json(out / (job['name'] + '-command.json'), record)
        print(f"{job['name']}: exit {r.returncode}", flush=True)
        return record
    with ThreadPoolExecutor(max_workers=3) as pool:
        runs = list(pool.map(run, plan))
    write_json(out / 'integration-commands.json', runs)
    write_json(out / 'source-manifest-after.json', identity(repo))
    result = verify(out, before, protected, runs, repo, parent)
    print(json.dumps({k: result[k] for k in ('passed', 'failures', 'bot_games')}, indent=2))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
