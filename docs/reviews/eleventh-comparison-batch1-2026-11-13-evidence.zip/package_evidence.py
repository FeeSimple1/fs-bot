"""Pack the reviewed Batch 1 evidence and verify every archived byte."""

import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'falling-sky'
REPORT = 'eleventh-comparison-batch1-2026-11-13'
FILES = '''
README.md source.json protected-sources.json summary.json
verify_results.py package_evidence.py trace_events.py trace-tasks.json trace-parent.json
trace-repair.json first-changes.json probe_parent_events.py parent-witness.json
parent-directed.log parent-directed.xml test_eleventh_comparison_events.py
probe_lucterius_session.py lucterius-session0.json lucterius-session987.json
directed987.log directed987.xml full.log full.xml legacy.log second-edition.log
fuzz0.log fuzz0.json fuzz987.log fuzz987.json parent-fuzz0.json
balance.log balance-reviewed.log previous-balance-baseline.json reviewed-baseline.json
reviewed-guardrail.log reviewed-guardrail.xml
'''.split()
for folder in ('legacy', 'second-edition', 'parent-legacy', 'parent-second-edition'):
    FILES.extend(f'{folder}/{name}' for name in ('metadata.json', 'games.jsonl', 'summary.json'))

members = {name: (ROOT / name).read_bytes() for name in FILES}
assert len(members) == len(FILES)
members[f'{REPORT}.md'] = (REPO / 'docs/reviews' / f'{REPORT}.md').read_bytes()
assert members['test_eleventh_comparison_events.py'] == (
    REPO / 'fs_bot/tests/test_eleventh_comparison_events.py').read_bytes()
members['SHA256SUMS'] = ''.join(f'{hashlib.sha256(data).hexdigest()}  {name}\n'
                                for name, data in sorted(members.items())).encode()
archive = REPO / 'docs/reviews' / f'{REPORT}-evidence.zip'
with zipfile.ZipFile(archive, 'w') as result:
    for name, data in sorted(members.items()):
        entry = zipfile.ZipInfo(name, (2026, 11, 13, 0, 0, 0))
        entry.create_system = 3
        entry.external_attr = 0o100644 << 16
        result.writestr(entry, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as result:
    assert result.testzip() is None and result.namelist() == sorted(members)
    assert all(result.read(name) == data for name, data in members.items())
print(f'{archive}: {len(members)} verified members, {archive.stat().st_size:,} bytes')
