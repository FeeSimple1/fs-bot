# Sixth audit frontend partition

Audited Falling Sky `86fb0c2d8ddf86a4548a863dc9c9da27d0c708ad`; comparator Liberty or Death `2991ea279062773548ec390a1da75f3e85381702`. Production source untouched.

Two confirmed repair groups are in `findings.json`. Executable witnesses freeze the observed defect, not the desired repair. Run from any directory with `PYTHONPATH` set to the audited repository, using Python3.12 (the audit used `/workspace/scratch/5473f6589808/audit-venv/bin/python`). Both scripts exit0 and print their recorded JSON.

- FE6-01: `probe_frontend.py`, output `probe_frontend-output.json`. Complete Card52 shaded public execution; illegal two-Region Aedui Ambush; correct one-Ambush normal-counterattack control; ordinary and multi-ability-schema rejection controls; pending/save/load/resume/journal replay exactness. Preview purity, source-derived casualty difference and clean structural/inventory checks.
- FE6-02: `probe_enlist.py`, output `probe_enlist-output.json`. Actual production Enlist menu and full public Belgic Command+Enlist; base correct single-group control; Ariovistus same-board ordinary German Limited March splitting2+2. Legal-choice omission from the consumed schema and menu; no invented unsupported-input contract or durable-session claim.

## Comparison and review coverage

Read `lod_ai/event_choices.py` collection/handler contract and `docs/human_mode_audit.md` historical audit and later correction. The latter explicitly distinguishes verifying existing hooks from an exhaustive rule-defined choice audit; this guided the Ariovistus-specific Enlist omission. Shared free-action structure validation was compared with ordinary `validate_human_structure` and Assembly of Gaul’s multi-ability validator. Checked current fifth-round March restrictions/drop-offs, plan/SA region scoping, nested SA extraction, interrupted Command entry paths, and durable session input/journal contract. Reviewed rounds2–5 ledgers and original inventory to separate already-fixed findings.

No independent new finding was established for request signature compatibility, action-window retries, partial preview contracts, hidden-information display, or ordinary Command/SA timing. This is scoped coverage, not exhaustive proof of those systems.

The proposed base-game Enlist split was rejected on reading §3.4.2: base Germans explicitly have only one moving group. The confirmed Enlist issue is Ariovistus-only, where A3.4.2 replaces the base rule. The documented rule distinction is retained in the matched control.

## Existing regression checks

Command:

```
PYTHONHASHSEED=0 python -m pytest -q fs_bot/tests/test_fifth_comparison_free_march.py fs_bot/tests/test_comparison_event_commands.py fs_bot/tests/test_enlist_free.py fs_bot/tests/test_command_interruption.py fs_bot/tests/test_human_action_order.py --tb=short
```

`focused-tests.log`: **130 passed in23.51s**. These passing regressions coexist with the source-backed targeted witnesses; they do not cover the new failures. An earlier command named a nonexistent test file and collected no tests (`focused-tests-badpath.log`); only the corrected run counts as validation.

Independent reviewer `/root/audit6_review` reran both witness scripts and matched recorded JSON, verified sources/fixtures and prior-ledger distinctions, and accepted both groups.
