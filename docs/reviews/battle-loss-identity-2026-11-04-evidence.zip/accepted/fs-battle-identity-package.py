from pathlib import Path
import hashlib, json, platform, subprocess, xml.etree.ElementTree as ET, zipfile
from fs_bot.tools.validation_metadata import source_identity

prefix='battle-loss-identity-2026-11-04'
result=json.loads(Path('/tmp/fs-battle-identity-results.json').read_text())
assert source_identity()==result['source']
suite=ET.parse('/tmp/fs-battle-identity-full.xml').getroot().find('testsuite')
assert suite.attrib['tests']=='8423' and all(suite.attrib[k]=='0' for k in ('failures','errors','skipped'))
assert sum(t.attrib['classname'].endswith('test_battle_loss_identity') for t in suite)==50
result['full_suite']=suite.attrib
result['python']=platform.python_version()
commands=[
    'python -m pytest -q --junitxml=/tmp/fs-battle-identity-full.xml',
    'python -m pytest -q fs_bot/tests/test_battle*.py fs_bot/tests/test_diviciacus*.py fs_bot/tests/test_assistant_session.py fs_bot/tests/test_agent_interface.py fs_bot/tests/test_litaviccus*.py',
    'PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --games 2 --workers 2 --out OUT',
    'PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
    'PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
    'PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20',
    "PYTHONPATH=. python -m pytest -q /tmp/test_battle_loss_identity_parent.py -k 'each_human_selects_exact_ordinary_visibility or human_selects_named_ally or city_citadel or litaviccus_casualty or full_battle_attack or legacy_raw_type_priority or npc_and_game_run' --junitxml=/tmp/fs-battle-identity-parent-proof.xml",
    'PYTHONPATH=. python /tmp/fs-battle-identity-verify.py',
    'PYTHONPATH=. python /tmp/fs-battle-identity-package.py',
]
result['commands']=commands
Path('docs/reviews/'+prefix+'-results.json').write_text(json.dumps(result,indent=2)+'\n')
p=Path('docs/reviews/'+prefix+'.md')
s=p.read_text().replace('Final full-suite and matrix inspection pending.',f"**8,423 tests pass**, including all 50 new cases, with zero failures, errors or skips ({float(suite.attrib['time']):.2f} seconds).")
s=s.replace('Final results and\nprotected-input checks will be recorded with the evidence archive.', '''All ten NPC games complete and audit cleanly, with no errors or integrity
findings, four ranked factions and consistent winner/ranking fields. Their
complete gameplay records and final hashes match the parent. Only elapsed
seconds, commit and source digest are excluded from that comparison.

Both complete mixed-seat JSON outputs match across hash seeds, covering 356
human turns, 96 Event attempts and 90 successful Events. There are zero hard
findings and zero partial games, with batch digest `d899b5732da10db5` and 40
executions including internal replay. The historical 100-game balance guard
passes its existing band, with a maximum difference of 15 percentage points
and 35 winner changes versus the historical baseline. These are separate from
the ten directly paired parent/current records.

All 49 protected inputs match the parent byte for byte, including the 47 rule
references, canonical constants and balance baseline. The archive includes
commands, source reconstruction data, raw results and checksums. Earlier
failed development/fixture runs are stored separately from accepted results.''')
p.write_text(s)
p=Path('docs/current-status.md');s=p.read_text().replace('Validation pending the full suite and matrix inspection.', '''**8,423 tests pass**, including 50 new cases, and 519 focused tests pass.
Ten audited NPC records/final hashes match the parent. Mixed-seat replays agree
across hash seeds with zero hard findings or partials. The 100-game historical
balance guard passes its existing band. Source identity, compatibility checks
and raw evidence are recorded in the report.''',1);p.write_text(s)
entries={}
for name in ['fs-battle-identity-full.xml','fs-battle-identity-full.log',
             'fs-battle-identity-targeted-final.log','fs-battle-identity-mixed0.json',
             'fs-battle-identity-mixed0.log','fs-battle-identity-mixed987.json',
             'fs-battle-identity-mixed987.log','fs-battle-identity-balance.log',
             'fs-battle-identity-parent-proof.xml','fs-battle-identity-parent-proof.log',
             'test_battle_loss_identity_parent.py','fs-battle-identity-verify.py',
             'fs-battle-identity-package.py']:
    entries['accepted/'+name]=Path('/tmp/'+name).read_bytes()
for label,directory in [('parent','/tmp/fs-battle-identity-bots-parent'),('accepted','/tmp/fs-battle-identity-bots-final')]:
    for path in Path(directory).iterdir():
        if path.is_file():
            entries[label+'/bots/'+path.name]=path.read_bytes()
for name in ['fs-battle-identity-initial.log','fs-battle-identity-compat.log',
             'fs-battle-identity-compat2.log','fs-battle-identity-compat3.log',
             'fs-battle-identity-targeted.log']:
    entries['development/'+name]=Path('/tmp/'+name).read_bytes()
entries['development/README.txt']=b'Development runs excluded from accepted counts. The initial run exposed a helper-name mismatch, then ordinary Ally owners required a null slot outside a borrowing context. Later runs exposed outdated request-shape expectations and the legacy Elite fixture. The accepted source fixes routing, verifies saved legacy requests on their original boards and updates fixture expectations while preserving their behavior assertions.\n'
entries['accepted/source.patch']=subprocess.check_output(['git','diff','HEAD','--','fs_bot'])
name='fs_bot/tests/test_battle_loss_identity.py'
entries['accepted/'+name]=Path(name).read_bytes()
protected=[path for path in Path('Reference Documents').rglob('*') if path.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
entries['accepted/protected-inputs.json']=json.dumps({str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in protected},indent=2).encode()
entries['accepted/results.json']=json.dumps(result,indent=2).encode()
entries['commands.txt']=('\n'.join(commands)+'\n\nRun paired bot batches in their respective parent/current working directories. The copied new regression file is unchanged. Run its selected subset in the isolated parent with PYTHONPATH=.; expect 28 behavioral failures, eight passing controls and fourteen deselected tests. All fifty cases pass in the accepted full suite.\n').encode()
entries['README.txt']=('Parent '+result['source']['commit']+'. Apply accepted/source.patch and add accepted/fs_bot/tests/test_battle_loss_identity.py to reconstruct the frozen Python sources. Accepted digest '+result['source']['source_sha256']+' across 506 files. Full suite 8423 passed, fifty new cases, 519 focused tests. Parent proof 28 behavioral failures and eight controls, fourteen deselected. Ten audited NPC records/final hashes match the parent. Mixed outputs agree under hash seeds0/987, zero hard findings/partials, forty executions including replay. Historical 100-game balance guard passes the unchanged 15-point band. Development logs are excluded from accepted counts.\n').encode()
entries['SHA256SUMS.txt']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(entries.items())).encode()
p=Path('docs/reviews/'+prefix+'-evidence.zip')
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(entries.items()):
        z.writestr(name,data)
with zipfile.ZipFile(p) as z:
    assert z.testzip() is None
    for line in z.read('SHA256SUMS.txt').decode().splitlines():
        digest,name=line.split('  ',1)
        assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps({'suite':suite.attrib,'archive_bytes':p.stat().st_size,'source':result['source']}))
