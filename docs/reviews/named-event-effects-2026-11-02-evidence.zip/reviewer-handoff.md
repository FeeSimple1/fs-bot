# BE-04 independent review handoff

Review completed against the shared candidate on 2026-11-03. No repository files were edited by this reviewer. The implementation is acceptable for this bounded finding, subject to the root agent's full-suite, integration, invariant, protected-file, and publication checks. No remaining blocking defect was found in the reviewed scope.

## Scope and sources

The review covers base Cards 2 unshaded, 18 unshaded, 23 unshaded, 26 shaded, and the directly related A18 unshaded counterpart. It does not constitute another full-game audit or establish aggregate outcome quality.

All source judgments use the supplied repository references. No external source, new provisional ruling, protected reference edit, or constants change was required. `reviewer-source-notes.md` records the detailed source conclusions and their locations. This review checked the numeric/expansion identities, original/second-edition routing, and automatic Arverni behavior in Ariovistus.

## Accepted behavior

- The named Romans or Arverni choose the optional effect even when another faction executes the Event. Durable missing input remains pending; explicit decline and explicit bot default are distinct responses.
- Card 2 requires a real Senate shift or flip and places two Legions as far as possible. Humans choose the Track/Fallen allocation. Roman bot instructions require both Legions; equally legal complete allocations use seeded random choice because no source-pool preference is printed. Legal late reclamation keeps its original timing and can open a new source allocation.
- Cards 18/A18 remove every German piece in the chosen eligible Region. A18 protects the named Ariovistus, while a Successor and Scouted Warbands remain removable. Settlement-before-Ally Region priority is explicitly supplied by A8.2.3/A8.3.1.
- Card 23 accepts the printed range of human City targets, including an own Ally, Dispersed status, or already-Razed City. NPC selection excludes an already-Razed City at maximum Resources when that would accomplish nothing. Razed status is stored at the exact Tribe.
- Card 26 removes only Allies, permits any faction's existing Ally as a removal target, and places only legal Arverni Allies at exact Tribes. Declining the whole optional effect suppresses the Rally. Skipping rearrangement with empty lists still permits the separately chosen Rally. The existing Rally resolver requires actual Vercingetorix and ordinary applicable Rally legality.
- Named-owner response timing and outer-executor reclamation authority remain separate. Owner responses cannot author outer handler/grant stages. The outer executor retains both the existing handler-complete and Card 26 Rally-grant windows.

## Defects caught or corrected during review

The review confirmed the parent A18 omission of Scouted Warbands and a Successor with an independent clean-parent witness. It also checked the corrected Card 2 source priority, the Card 23 zero-effect NPC target edge, named-owner Spring versus executor reclamation authority, the raw collector's authority frame, and the Card 26 whole-decline wording.

A final strict-validation regression was found independently: the first candidate rejected the existing outer `grant.card_26_arverni_rally` stage. The parent accepted the same plan. The engine agent repaired the narrow allowlist and preserved ownership separation; the final candidate accepts it again. Evidence is retained in:

- `review_outer_grant.py`
- `review-outer-grant-parent.json`
- `review-outer-grant-candidate-01.json` (failed intermediate candidate)
- `review-outer-grant-candidate-02.json` (repaired candidate)

The test change in the existing Gobannitio outcome test strengthens rejection of a Citadel-as-Ally plan rather than weakening the rule assertion. The new tests use actual board state, real Event execution, durable SeatSession transactions, serialization/replay, and meaningful rollback checks.

## Independent verification

`reviewer-focused-01.log` records **320 passing tests** in 1.25 seconds across:

- `test_named_event_effects.py`
- `test_cli_named_event_effects.py`
- `test_named_event_sessions.py`
- `test_event_action_windows.py`
- `test_event_timing_planning.py`
- `test_event_timing_review.py`
- `test_event_grant_outcomes.py`

`reviewer-focused-01.json` records the exact command, working directory, exit code, and every Python source hash before and after the run. Those source mappings are identical. The run includes the final outer-grant repair and late source-allocation menu changes.

The durable tests cover human ownership, card/board-change context, invalid response retries without board/RNG/journal mutation, save/load, exact request/response replay, full decline, explicit default, and the separate Gobannitio Rally decision. CLI tests cover board inspection, EOF, exact piece/source selection, timing, and the owner/executor distinction.

## Evidence limitations

The first A18 witness attempt imported the edited checkout instead of the parent. It is explicitly excluded from parent evidence in `review-witness-note.md`; the empty artifact and exploratory output were retained rather than relabeled. The accepted parent witness is `review-a18-parent-01.json` from the separate clean parent worktree.

This handoff does not claim the root agent's full suite or bot matrix has completed, nor does it assign causation to aggregate winner changes. Those checks remain separately attributable to their own logs and manifests.

## Final documentation and outcome-evidence addendum

The root agent requested a follow-up review after the acceptance runs. I reviewed the current README, BUILD_PLAN, PLAYING, CHATGPT_README, AGENT_INTERFACE, docs/current-status, docs index, historical audit notice, and CHANGELOG diffs. No concrete contract or provenance misstatement was found. The API documents the actual parameter shapes and timing locations, the Card 26 distinction is accurate, historical checkpoint counts remain historical, and 18/50 is expressly a finding count rather than effort or total rules accuracy.

The actual logs now show **6,872 full-suite tests passing**. Integration results identify the frozen 422-file Python source and record 150 bot games, 30 distinct mixed-seat cases with 120 executions including replay/hash repeats, and 20 strict-census executions. The unchanged legacy baseline passes its existing 15-percentage-point band; the largest observed shift is 10 points. These are bounded acceptance samples, not a balance certification.

I independently checked the existing 16 changed legacy pairs, without running any additional full game. `reviewer_causal_check.py` and `reviewer-causal-verification.json` record the checks:

- All 32 compressed trace hashes match their manifests, and every parent/candidate outcome matches the matrix.
- The first differing recorded rows have identical full pre-states and identical earlier rows. Eight restore Card 2's two missing Legion placements; two restore Roman-owned Card 18 removal when Aedui executed the Event; six correctly decline an unavailable or ineffective Event.
- The first difference is not merely newly returned handler metadata. Fourteen pairs already differ in post-state. In Gallic War seeds 1 and 8, the first A18 difference is the chosen action only, followed by a post-state difference on the next execution row. The execution pre-states already contain different Sequence-of-Play metadata, so the identical-prestate claim applies to the earlier decision, not that later execution. The JSON records both boundaries explicitly.
- This establishes the first causal divergence within the repaired scope; it does not claim that one local change alone explains every later decision or final winner.

The diagnostic trace process completed all 32 games but its final whole-identity equality assertion failed because the root committed the frozen source while it ran. I independently compared all 422 current Python files and all 422 files archived from commit `9e9191bc1c0eb5de13a5d578475d4f85042d2a6b` with the prepared manifest: every hash agrees. The separate recorded start/end source identities differ only in the Git commit field; the Python digest remains `9d4cc73f2efaa33b8e6ad871fb432ae43c7471d5222b1c13d9c9b571c0c3c4a8`. The original failed log remains retained and must not be presented as a wholly green trace process.

The initial boundary-replay check also retains one failure: sorted diagnostic JSON changed the insertion order of the spaces dictionary, changing an unused Trade-region detail list and its Diviciacus confirmation signature in Reconquest seed 10. I independently reproduced that mismatch, restored the original `ALL_REGIONS` insertion order, and verified the exact decision, complete post-state/RNG, and following execution. This is an explicitly resolved diagnostic serialization limitation, with no extra full game and no production code edit.

The bounded source, implementation, user/API documentation, and causal-evidence reviews are now clear. Publication and any final report/evidence packaging checks remain with the root agent.
