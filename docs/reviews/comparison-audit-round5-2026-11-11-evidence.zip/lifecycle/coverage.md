# Fifth audit lifecycle partition

Frozen FS revision bd30d522e8baa2d303b9e372d7d9c550351e91a5. Comparator FeeSimple1/lod-bot revision 2991ea279062773548ec390a1da75f3e85381702. Read its coin-implementation-lessons.md, particularly boundary/state-shape, scheduled actions, scope, and scenario handling. Falling Sky's supplied references and adopted rulings governed findings.

One confirmed high-priority repair group, WS5-01, covers mirrored Bibracte/Gergovia Region wipes during home-City restoration. The four source-valid phase-level cases enter the third Victory Phase with no qualified winner. Both defects and both occupied-home controls pass census/structure, source-restricted Tribe ownership and the permanent Provincia Fort check. Each resolves the complete Interlude through public run_winter_round. No game code, canonical labels, or Reference Documents changed.

Read-only coverage included Chapter6 and A6 in full, Gallic War Interlude and Pax setup in full, Chapter7/A7, Winter victory/Harvest/Senate/Spring orchestration, Quarters relocation/payment and conservation paths, and Interlude reductions, Cisalpina evacuation, marker cleanup, resource transfer, seat/scenario swap and deck rebuild. Prior comparison reports/ledgers and provisional-ruling register were checked for overlap. This was a targeted code/source review with two executable investigations, not exhaustive testing of all lifecycle combinations.

The second executable investigation is an uncounted source question about Optimates. It demonstrates actual current behavior through first and second Pax Winter resolution, with an inactive-Event diagnostic control, but does not prove that the behavior is wrong. See questions.md. Its observation must not be counted as a confirmed defect or inverted into a regression until the source question is settled.

Rejected/held leads:

- Interlude's 72-card candidate pool and 70-card cap. Original Setup says to shuffle Events, deal required piles and set extra cards aside. The Interlude says to hold out in-effect cards then create piles. Current implementation follows that sequencing and only loses pile14 when the remaining pool has65 or fewer Events, i.e. at least7 of72 candidate identities held out. Tests explicitly record6 versus7. A possible alternative first limits the pool to70 then excludes active Events, but that ordering is not expressly mandated. The wording 'If there is no14th pile ... because five or more ... left out' does not state the converse that exactly5 holdouts must eliminate the pile. No confirmed finding and no proposed code change.
- Spring's deferred Vercingetorix entry correctly remains gated during Interlude Spring and unlocks at the first post-Interlude Spring.
- Interlude Resource transfer appears to add Arverni's old amount, but ordinary expansion Arverni Resources are zero. No reachable nonzero exception proven, so no finding.
- Quarters visibility/default-loss identity could matter before Winter Campaign, but no source-determined alternative roll ordering demonstrated. No finding.
- Senate's Ariovistus lower-row maximum2 keeps eligible Uproar-row Legions outside that budget, consistent with A6.5.2. No new discrepancy identified.
- Existing WS4-01 Resource floor, WS4-02 active/inactive card identity and WS4-03 Nori retirement are closed findings and not recounted.
- Cisalpina evacuation's default removal is within the printed relocation-or-removal choice; no source mandate for a stronger NP placement preference found.

Commands:

```sh
PYTHONPATH=<fs-bot-root> python lifecycle/probe_lifecycle.py
```

The script emits its complete observations as JSON and asserts them. The saved probe_lifecycle.json is the output on the frozen revision. WS5-01 assertions deliberately freeze the current defect. Its eventual repair tests must reverse the failing outcomes and preserve both controls. Optimates assertions only reproduce the current observation while its interpretation remains unresolved.
