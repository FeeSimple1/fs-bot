from pathlib import Path
import hashlib, io, json, platform, subprocess, tarfile, tempfile, zipfile
import xml.etree.ElementTree as ET
from fs_bot.tools.validation_metadata import source_identity

prefix = 'slingers-choice-2026-11-05'
result = json.loads(Path('/tmp/fs-slingers-results.json').read_text())
assert source_identity() == result['source']
suite = ET.parse('/tmp/fs-slingers-full.xml').getroot().find('testsuite')
assert suite.attrib['tests'] == '8624'
assert all(suite.attrib[k] == '0' for k in ('failures', 'errors', 'skipped'))
assert sum(t.attrib['classname'].endswith('test_slingers_choice') for t in suite) == 44
patch = subprocess.check_output(['git', 'diff', 'HEAD', '--', 'fs_bot'])
new_files = ('fs_bot/engine/slingers_choice.py', 'fs_bot/cli/slingers.py',
             'fs_bot/tests/test_slingers_choice.py')
with tempfile.TemporaryDirectory(prefix='fs-slingers-reconstruct-') as directory:
    root = Path(directory)
    parent = subprocess.check_output(['git', 'archive', result['source']['commit'], 'fs_bot'])
    with tarfile.open(fileobj=io.BytesIO(parent)) as archive:
        archive.extractall(root, filter='data')
    subprocess.run(['git', 'apply', '--unsafe-paths', '-'], cwd=root, input=patch, check=True)
    for name in new_files:
        (root / name).write_bytes(Path(name).read_bytes())
    files = sorted((root / 'fs_bot').rglob('*.py'))
    assert len(files) == 517
    digest = hashlib.sha256()
    for path in files:
        digest.update(str(path.relative_to(root)).encode()+b'\0'+path.read_bytes())
    assert digest.hexdigest() == result['source']['source_sha256']
result.update(full_suite=suite.attrib, python=platform.python_version(),
              source_reconstruction_verified=True,
              compatibility_limit='Older histories can stop at the new Roman Region choice or diverge from the corrected first-applicable priority and combined pre-fire rate. Prospective-queue Slingers and Card 59 Region choices remain open.')
commands = [
 'python -m pytest -q --junitxml=/tmp/fs-slingers-full.xml',
 'python -m pytest -q fs_bot/tests/test_slingers_choice.py fs_bot/tests/test_capabilities_base.py fs_bot/tests/test_base_arduenna_np.py fs_bot/tests/test_prospective_battle_observer.py fs_bot/tests/test_marcus_antonius.py fs_bot/tests/test_event_battle_choices.py fs_bot/tests/test_agent_interface.py fs_bot/tests/test_assistant_session.py fs_bot/tests/test_war_fleet.py fs_bot/tests/test_litaviccus_np_independent.py',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --games 2 --workers 2 --out OUT',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
 'PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20',
 'PYTHONPATH=. python -m pytest -q /tmp/test_slingers_parent_proof.py --junitxml=OUT.xml',
 'PYTHONPATH=. python /tmp/fs-slingers-verify.py',
 'PYTHONPATH=. python /tmp/fs-slingers-package.py',
]
result['commands'] = commands
Path('docs/reviews/'+prefix+'-results.json').write_text(json.dumps(result, indent=2)+'\n')
p = Path('docs/reviews/'+prefix+'.md')
s = p.read_text().replace('Final full-suite and evidence inspection pending.',
 f"**8,624 tests pass**, with zero failures, errors or skips ({float(suite.attrib['time']):.2f} seconds).")
x = result['mixed']
s = s.replace('Frozen source, protected inputs, final results and archive checksums are\nverified separately.', f'''All ten standard NPC records complete and audit cleanly with four ranked
Factions, consistent winner/ranking output, no integrity findings and only
legal-decline diagnostics. Every gameplay field and final board hash matches
the parent, excluding elapsed seconds, commit and source identity.

The complete mixed-seat JSON outputs match across hash seeds 0 and 987. They
cover {x['human_turns']} human turns, {x['event_turns']} Event attempts and {x['events_ok']} successful Events, with zero hard
findings and zero partial games. Their digest is `{x['batch_digest'][:16]}`.
Internal replay gives 40 executions total. The historical 100-game balance
check passes the existing band, with a maximum difference of
{result['balance']['maximum_absolute_delta_percentage_points']} percentage points and {result['balance']['historical_baseline_winner_changes']} winner changes versus the historical baseline. Those
historical comparisons are separate from the ten exact parent/current NPC
comparisons.

All 49 protected inputs match the parent byte for byte, comprising 47 supplied
references, canonical constants and the historical balance baseline. Archive
checksums and reconstruction of all 517 Python files verify the accepted source
digest. The first directed run paused the later-casualty fixture at its earlier
Retreat request. The fixture now delegates Retreat and retains its casualty
continuation assertions. The superseded development log is retained separately.''')
p.write_text(s)
p = Path('docs/current-status.md')
p.write_text(p.read_text().replace('Validation pending the final full suite and evidence inspection.',
 '''**8,624 tests pass**, including 44 new cases, with 235 focused tests passing.
Ten standard NPC records/final hashes match the parent, mixed-seat results
agree across hash seeds with zero hard findings or partials, and the historical
100-game balance guard passes its unchanged band. The report records the
frozen source, protected inputs, evidence and cross-revision replay limit.''', 1))
entries = {}
for name in ['fs-slingers-full.xml', 'fs-slingers-full.log', 'fs-slingers-targeted.log',
 'fs-slingers-mixed0.json', 'fs-slingers-mixed0.log', 'fs-slingers-mixed987.json',
 'fs-slingers-mixed987.log', 'fs-slingers-balance.log', 'fs-slingers-proof-parent.xml',
 'fs-slingers-proof-parent.log', 'fs-slingers-proof-final.xml', 'fs-slingers-proof-final.log',
 'test_slingers_parent_proof.py', 'fs-slingers-verify.py', 'fs-slingers-package.py']:
    entries['accepted/'+name] = Path('/tmp/'+name).read_bytes()
for label, directory in [('parent', '/tmp/fs-slingers-bots-parent'),
                         ('accepted', '/tmp/fs-slingers-bots-final')]:
    for path in Path(directory).iterdir():
        if path.is_file():
            entries[label+'/bots/'+path.name] = path.read_bytes()
for name in ['fs-slingers-initial.log', 'fs-slingers-retry.log']:
    entries['development/'+name] = Path('/tmp/'+name).read_bytes()
entries['development/README.txt'] = b'The initial 43-case run paused the later-casualty fixture at its earlier Retreat request. The fixture now delegates Retreat while retaining casualty pause/save/replay assertions. The accepted directed rerun has 44 cases, adding the first-applicable NPC priority case. Accepted focused and full logs are separate.\n'
entries['accepted/source.patch'] = patch
for name in new_files:
    entries['accepted/'+name] = Path(name).read_bytes()
protected = [p for p in Path('Reference Documents').rglob('*') if p.is_file()]
protected += [Path('fs_bot/rules_consts.py'), Path('fs_bot/tools/balance_baseline.json')]
entries['accepted/protected-inputs.json'] = json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}, indent=2).encode()
entries['accepted/results.json'] = json.dumps(result, indent=2).encode()
entries['commands.txt'] = ('\n'.join(commands)+'\n\nRun paired NPC batches and unchanged proof cases from their respective parent/current directories. Parent proof gives four behavioral failures and two passing controls; accepted proof gives six passing cases. All game matrices here are bounded general regression checks; directed tests exercise the new Slingers request.\n').encode()
entries['README.txt'] = (f"Parent {result['source']['commit']}. Apply accepted/source.patch and copy the three accepted/fs_bot new files to reconstruct the accepted source. Digest {result['source']['source_sha256']} across 517 files. Full suite 8624 passed, 44 new cases, 235 focused tests. Six probes give four parent failures and two passing controls; all six pass on the repair. Ten standard NPC records/final hashes match parent. Mixed-seat complete JSON matches across hash seeds 0/987, with zero hard findings or partials. The historical 100-game balance guard passes its unchanged 15-point band. Original bundle remains 39/50 closed (78%), with BE-09 still open for the prospective queue and Card 59. {result['compatibility_limit']}\n").encode()
entries['SHA256SUMS.txt'] = ''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(entries.items())).encode()
p = Path('docs/reviews/'+prefix+'-evidence.zip')
with zipfile.ZipFile(p, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(p) as archive:
    assert archive.testzip() is None
    for line in archive.read('SHA256SUMS.txt').decode().splitlines():
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest
print(json.dumps(dict(suite=suite.attrib, archive_bytes=p.stat().st_size, source=result['source'])))
