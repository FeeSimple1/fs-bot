"""BM10-01: public Divination dispatch after Abatis then Stalwart.

Read-only production audit. Expected arithmetic derives from supplied A3.4.4,
3.3.4 and cards A31/A64, and expected choice from 8.2.3/8.6.2. No mocking.
"""
import argparse
import copy
import json
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--repo', default='/workspace/scratch/521fc7ecea8c/falling-sky')
args = parser.parse_args()
sys.path.insert(0, args.repo)

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces, get_available
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.cards.divination_np import choose_divination_action, _high_value_forced
from fs_bot.battle.losses import calculate_losses, defender_abatis_active
from fs_bot.bots.bot_common import predict_battle
from fs_bot.engine.agent import RETREAT, LOSS_ORDER, RETREAT_DISPOSITION
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT, ACTION_COMMAND
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.tools.seat_session import validate_response

REGION = rc.CARNUTES

def check(state):
    result = {'census_errors': validate_state(state),
              'structure_errors': check_structural_integrity(state)}
    assert not result['census_errors'] and not result['structure_errors'], result
    return result

def pieces(state):
    return {
        'belgic_warbands_carnutes': count_pieces(state, REGION, rc.BELGAE, rc.WARBAND),
        'belgic_ally_aulerci': state['tribes'][rc.TRIBE_AULERCI]['allied_faction'],
        'belgic_warbands_available': get_available(state, rc.BELGAE, rc.WARBAND),
        'german_warbands_carnutes': count_pieces(state, REGION, rc.GERMANS, rc.WARBAND),
        'german_warbands_elsewhere': sum(count_pieces(state, r, rc.GERMANS, rc.WARBAND)
                                       for r in state['spaces'] if r != REGION),
        'german_warbands_available': get_available(state, rc.GERMANS, rc.WARBAND),
        'abatis_owner': state['markers'].get(REGION, {}).get(rc.MARKER_ABATIS),
    }

def event(state, card, actor, *, shaded=False, **params):
    state['current_card'] = state['current_card_id'] = card
    response = {'action': ACTION_EVENT, 'player_action': {
        'command': rc.FIRST_DID_EVENT, 'sa': 'No SA', 'details': {
            'card_id': card,
            'text_preference': rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,
            'event_params': params}}}
    validate_response(state, {'kind': 'turn', 'faction': actor, 'options': [ACTION_EVENT]}, response)
    result = execute_decision(state, actor, response)
    assert result['executed'] and not result.get('errors'), result
    check(state)
    return result

def position(abatis, stalwart, leader=True):
    state = build_initial_state(rc.SCENARIO_ARIOVISTUS, seed=13)
    state['non_player_factions'] = set()
    for faction in (rc.GERMANS, rc.BELGAE, rc.AEDUI, rc.ROMANS):
        state['resources'][faction] = 20
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    if leader:
        place_piece(state, REGION, rc.GERMANS, rc.LEADER, leader_name=rc.ARIOVISTUS_LEADER)
    place_piece(state, REGION, rc.GERMANS, rc.WARBAND, 2)
    place_piece(state, REGION, rc.BELGAE, rc.WARBAND, 2)
    assert _ally_tribe(state, rc.TRIBE_AULERCI, rc.BELGAE)
    check(state)
    acquisitions = []
    if abatis:
        acquisitions.append(event(state, 'A64', rc.BELGAE, region=REGION))
    if stalwart:
        acquisitions.append(event(state, 'A31', rc.GERMANS, shaded=True))
    state['non_player_factions'] = {rc.AEDUI}
    return state, acquisitions

def public_divination_case(abatis, stalwart, leader=True):
    state, acquisitions = position(abatis, stalwart, leader)
    before = pieces(state)
    validation_before = check(state)
    forecast = {
        'raw_standing_losses': calculate_losses(state, REGION, rc.GERMANS, rc.BELGAE),
        'raw_retreat_losses': calculate_losses(state, REGION, rc.GERMANS, rc.BELGAE, is_retreat=True),
        'resolver_standing_losses': predict_battle(state, REGION, rc.GERMANS, rc.BELGAE)['inflicted'],
        'resolver_retreat_losses': predict_battle(state, REGION, rc.GERMANS, rc.BELGAE, is_retreat=True)['inflicted'],
        'active_abatis': defender_abatis_active(state, REGION, rc.GERMANS, rc.BELGAE),
        'a4_high_value_gate': _high_value_forced(state, REGION, rc.BELGAE),
        'planning_command': choose_divination_action(copy.deepcopy(state), rc.AEDUI)['command'],
    }
    result = event(state, 'A34', rc.ROMANS, faction=rc.AEDUI)
    free = result['free_actions'][0]
    expected_command = rc.CMD_BATTLE if leader and (not abatis or stalwart) else rc.CMD_MARCH
    return {
        'abatis': abatis, 'stalwart': stalwart, 'ariovistus': leader,
        'acquisition_events': acquisitions, 'before': before,
        'before_validation': validation_before, 'forecast': forecast,
        'expected_command': expected_command, 'actual_command': free['result']['command'],
        'event_result': result, 'after': pieces(state), 'after_validation': check(state),
    }

def public_battle_control(retreat):
    state, acquisitions = position(True, True)
    requests = []
    def agent(board, faction, request):
        requests.append(copy.deepcopy(request))
        if request['kind'] == RETREAT:
            return {'retreat': retreat}
        if request['kind'] == RETREAT_DISPOSITION:
            return {'region': None, 'stay_leader': False, 'stay_hidden_warbands': 0}
        return None
    state['decision_agent'] = agent
    response = {'action': ACTION_COMMAND, 'player_action': {
        'command': rc.CMD_BATTLE, 'sa': 'No SA', 'regions': [REGION],
        'details': {'battle_plan': [{'region': REGION, 'target': rc.BELGAE}]}}}
    validate_response(state, {'kind': 'turn', 'faction': rc.GERMANS, 'options': [ACTION_COMMAND]}, response)
    before, validation = pieces(state), check(state)
    result = execute_decision(state, rc.GERMANS, response)
    assert result['executed'] and not result['errors'], result
    loss_requests = [r for r in requests if r['kind'] == LOSS_ORDER]
    assert loss_requests[0]['num_losses'] == (2 if retreat else 4), loss_requests
    assert state['tribes'][rc.TRIBE_AULERCI]['allied_faction'] is None
    assert count_pieces(state, REGION, rc.BELGAE) == 0
    assert state['markers'][REGION][rc.MARKER_ABATIS] == rc.BELGAE
    return {'retreat': retreat, 'acquisition_events': acquisitions,
            'before': before, 'before_validation': validation, 'result': result,
            'first_loss_count': loss_requests[0]['num_losses'],
            'loss_requests': loss_requests, 'after': pieces(state),
            'after_validation': check(state)}

cases = [public_divination_case(a, s) for a, s in
         ((True, True), (False, True), (True, False), (False, False))]
cases.append(public_divination_case(True, True, False))
assert cases[0]['actual_command'] == rc.CMD_MARCH
assert cases[0]['expected_command'] == rc.CMD_BATTLE
assert cases[0]['forecast']['raw_standing_losses'] == 2
assert cases[0]['forecast']['resolver_standing_losses'] == 4
assert cases[0]['after']['belgic_ally_aulerci'] == rc.BELGAE
for case in cases[1:]:
    assert case['actual_command'] == case['expected_command'], case

print(json.dumps({'finding': 'BM10-01',
                  'scenario': rc.SCENARIO_ARIOVISTUS, 'rng_seed': 13,
                  'cases': cases,
                  'public_battle_controls': [public_battle_control(False), public_battle_control(True)]},
                 indent=2, sort_keys=True))
