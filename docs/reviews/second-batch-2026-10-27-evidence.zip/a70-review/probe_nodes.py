"""Read-only A70 node/dispatcher probe. Sets up states but plays no games."""
import argparse
import copy
import json
from pathlib import Path
from fs_bot import rules_consts as rc
from fs_bot.state.setup import setup_scenario
from fs_bot.state.serialize import encode
from fs_bot.bots.bot_common import should_decline_event, get_event_instruction, is_no_faction_event
from fs_bot.bots.aedui_bot import node_a3
from fs_bot.bots.roman_bot import node_r4
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.cards.event_eval import is_event_effective
from fs_bot.cards.event_conditions import np_event_available
from fs_bot.engine.game_engine import next_winter_is_final
from fs_bot.tools.validation_metadata import source_identity

p = argparse.ArgumentParser()
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
source = source_identity()
rows = []
for scenario in rc.ARIOVISTUS_SCENARIOS:
    for belgae_np in (True, False):
        state = setup_scenario(scenario, seed=3)
        state['non_player_factions'] = {rc.ROMANS, rc.AEDUI, rc.GERMANS} | ({rc.BELGAE} if belgae_np else set())
        state['current_card'] = state['current_card_id'] = 'A70'
        state['can_play_event'] = True
        state['is_second_eligible'] = False
        state['current_card_faction_order'] = [rc.BELGAE, rc.AEDUI, rc.GERMANS, rc.ROMANS]
        state['next_card_faction_order'] = [rc.ROMANS, rc.AEDUI]
        for faction, node in ((rc.ROMANS, node_r4), (rc.AEDUI, node_a3)):
            before = encode(state)
            row = {'scenario': scenario, 'faction': faction, 'belgae_np': belgae_np,
                   'instruction': get_event_instruction('A70', faction, scenario).instruction,
                   'unconditional_no_event': is_no_faction_event('A70', faction, scenario),
                   'final_year': next_winter_is_final(state), 'effective': is_event_effective(state, 'A70', False),
                   'np_available': np_event_available(state, 'A70', faction, False),
                   'should_decline': should_decline_event(state, 'A70', faction), 'actual_node': node(state),
                   'expected_decline': belgae_np}
            row['query_board_rng_unchanged'] = before == encode(state)
            action = dispatch_bot_turn(copy.deepcopy(state), faction)
            row['dispatch_command'] = action['command']
            row['dispatch_details'] = action.get('details')
            row['matches_printed_restriction'] = row['should_decline'] is belgae_np and row['actual_node'] == ('Yes' if belgae_np else 'No') and (row['dispatch_command'] != 'Event') is belgae_np
            rows.append(row)
report = {'source': source, 'source_after': source_identity(), 'full_games_executed': 0,
          'state_setup_and_node_cases': len(rows), 'cases': rows,
          'printed_restriction_failures': sum(not r['matches_printed_restriction'] for r in rows)}
with a.out.open('x') as f:
    json.dump(report, f, indent=2, sort_keys=True)
    f.write('\n')
print(json.dumps({k:v for k,v in report.items() if k!='cases'}, indent=2))
