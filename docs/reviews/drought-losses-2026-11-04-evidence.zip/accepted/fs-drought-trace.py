from pathlib import Path
import hashlib,json,sys
from fs_bot import rules_consts as rc
from fs_bot.tools import run_batch as batch
from fs_bot.cards import card_effects as ce
from fs_bot.tools.seat_session import board_copy
from fs_bot.state.serialize import encode
root=[None];cards=[];drought=[]
def payload(state):return encode(board_copy(state))
def digest(state):return hashlib.sha256(json.dumps(payload(state),sort_keys=True).encode()).hexdigest()
setup,play,handler=batch.setup_scenario,batch.play_card,ce._BASE_HANDLERS[49]
def new_setup(*args,**kwargs):
 state=setup(*args,**kwargs);root[0]=state;return state
batch.setup_scenario=new_setup
def trace_handler(state,*args,**kwargs):
 if state is not root[0]:return handler(state,*args,**kwargs)
 before=payload(state)
 result=handler(state,*args,**kwargs)
 drought.append({'before':before,'after':payload(state)})
 return result
ce._BASE_HANDLERS[49]=trace_handler
def trace_card(state,*args,**kwargs):
 before=digest(state)
 result=play(state,*args,**kwargs)
 cards.append({'before':before,'after':digest(state),'result':encode(result)})
 return result
batch.play_card=trace_card
record=batch.play_one((rc.SCENARIO_RECONQUEST,2))
assert record['completed'] and not record['errors'] and not record['integrity_findings']
Path(sys.argv[1]).write_text(json.dumps({'record':record,'cards':cards,'drought':drought},indent=2)+'\n')
print(json.dumps({'cards':len(cards),'live_droughts':len(drought),'final_hash':record['final_state_sha256']}))
