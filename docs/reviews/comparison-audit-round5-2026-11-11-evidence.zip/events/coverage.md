# Fifth audit Event partition

Audited fs-bot `bd30d522e8baa2d303b9e372d7d9c550351e91a5`. Comparator lod-bot `2991ea279062773548ec390a1da75f3e85381702`. FS references and existing provisional rulings were the only rule authorities. Comparator reading included `coin-implementation-lessons.md` (boundaries, data representation, scoped effects, and tracing stored effects to consumers) and `lod_ai/event_choices.py` (typed mandatory choice schema).

Final portable command, from the fs-bot checkout:

```sh
PYTHONPATH=. python /path/to/events/probe_events.py
```

`probe_events.py` passes on the audited source and emits `observed.json`. Its assertions intentionally reproduce defects and must be inverted into source-correct regressions during repair. It has 27 final named cases, including valid and invalid controls. All fixtures pass census and structural checks before and after. Public previews are checked to leave the live state and RNG unchanged. Failed Forced Marches commits are checked to roll back atomically. Durable response shape validation and `validate_player_action` are exercised, but this partition does not claim to have completed saved-session play/submit/replay for these witnesses.

The final three groups are separate mechanisms. Cards10/63 share copied recipient-acquisition code. Colony lacks a playability check. Forced Marches uses a stale map representation. No gameplay or repository test files were edited.

## Review coverage and limits

- Read numeric Event handlers 1–72 plus A-prefix handlers and their delegated validation modules around the leads, concentrating on exact selected recipients, mandatory target conditions, dynamic map state and data handoff to consumers. This is source inspection, not a claim of exhaustive dynamic coverage for all cards.
- Re-read the prior 50/21/15/16 finding ledgers and current open questions. No original finding is recounted. Prior fourth Horse ownership and third Colony creation/consumers are explicitly distinguished in `findings.json`.
- Considered A27/A32 Uprising's unconditional `_unally_tribe` as a possible counterpart of repaired A24 Citadel removal. Rejected: all printed target Tribes for A27/A32 are non-Cities, so no legal Citadel witness exists there. The general helper fallback alone does not establish a defect.
- A35 owner/type mismatch can skip its mobile placement, but its mobile quota is expressly optional. No new mandatory-placement finding was made from that path. The already repaired A69 mandatory owner/type case remains distinct.
- Considered Forced Marches admitting non-Romans to active Gallia Togata in an Ariovistus state. Rejected as evidence because numeric32 is replaced by A32 in that scenario. The accepted witnesses use base scenarios with real Card5.
- Existing A33 outnumbering and Assembly ability-repeat/German-guidance source questions were not reopened or counted.
- Scarce-pool fixed placement ordering on original34/60/61/69 and A27/A32 remains an existing unverified source question, not a new finding.
- `explore.py` and `explore-output.json` retain preliminary probes. They also show Cicero accepting a non-enumerated direction and Sappers accepting a faction without a Citadel, leaving otherwise mandatory effects unapplied. These two narrow invalid-scalar candidates were not included in this partition's final three-group count; no complete turn or saved-session witness was developed for them. They are available for a later focused mandatory-selection pass rather than being silently labeled repaired.
- No naturally sampled encounter frequency, comprehensive card certification, fresh full test run or self-play matrix is claimed by this partition. Root validation supplies any whole-repository checks.
