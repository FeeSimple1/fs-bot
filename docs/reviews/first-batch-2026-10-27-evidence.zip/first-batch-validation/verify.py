"""Verify the accepted first-batch matrix without rerunning any games."""
import json
from collections import Counter
from fractions import Fraction
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
run = root / 'attempt3'
repo = root.parent / 'fs-bot'
sys.path.insert(0, str(repo))
from fs_bot.tools.validation_metadata import source_identity
from fs_bot.tools.run_batch import SCENARIOS

identity = json.loads((run / 'source.json').read_text())
assert source_identity()['source_sha256'] == identity['source_sha256']
report = {'source': identity, 'accepted_attempt': 3, 'bot_batches': {}}
all_rows = []
for edition, seeds in [('legacy', range(1, 21)), ('original', range(201, 211)),
                       ('second-edition', range(201, 211))]:
    folder = run / ('bots-' + edition)
    metadata = json.loads((folder / 'metadata.json').read_text())
    assert metadata['source_sha256'] == identity['source_sha256']
    rows = [json.loads(line) for line in (folder / 'games.jsonl').read_text().splitlines()]
    expected = {(scenario, seed, edition) for scenario in SCENARIOS for seed in seeds}
    actual = [(r['scenario'], r['seed'], r['card_edition']) for r in rows]
    assert len(actual) == len(set(actual)) and set(actual) == expected
    for r in rows:
        assert all(r.get(k) is True for k in ('completed', 'game_completed', 'audit_completed')), r
        assert not r['errors'] and not r['integrity_findings'], r
        assert all(d['severity'] == 'legal-decline' for d in r['diagnostics']), r
        assert len(r['final_ranking']) == 4 and r['final_state_sha256'], r
        assert r['engine_ranking_output_missing'] is False, r
        assert r['winner_differs_from_highest_margin'] is False, r
        assert r['source_sha256'] == identity['source_sha256'], r
    report['bot_batches'][edition] = {
        'games': len(rows), 'seeds': list(seeds), 'scenarios': list(SCENARIOS),
        'accepted': len(rows), 'winner_counts': {
            scenario: dict(Counter(r['winner'] for r in rows if r['scenario'] == scenario))
            for scenario in SCENARIOS},
    }
    all_rows += rows

base = json.loads((repo / 'fs_bot/tools/balance_baseline.json').read_text())['games']
balance = {}
for scenario in SCENARIOS:
    rows = [r for r in all_rows if r['card_edition'] == 'legacy' and r['scenario'] == scenario]
    before = Counter(base[f"{scenario}|{r['seed']}"]['winner'] for r in rows)
    after = Counter(r['winner'] for r in rows)
    delta = {f: Fraction(after[f] - before[f], 20) for f in before.keys() | after.keys()}
    assert all(abs(d) <= Fraction(3, 20) for d in delta.values()), (scenario, delta)
    balance[scenario] = {'before': dict(before), 'after': dict(after),
        'percentage_point_change': {f: float(d * 100) for f, d in delta.items()},
        'changed_winner_seeds': sorted(r['seed'] for r in rows
            if base[f"{scenario}|{r['seed']}"]['winner'] != r['winner'])}
report['balance'] = {'band_percentage_points': 15, 'baseline_updated': False,
                     'passed': True, 'scenarios': balance}

fuzz = [json.loads((run / f'fuzz{h}.json').read_text()) for h in (0, 7)]
assert fuzz[0] == fuzz[1]
for data in fuzz:
    assert data['metadata']['source_sha256'] == identity['source_sha256']
    assert data['games'] == 20 and data['hard_findings'] == 0
    expected = {(s, n) for s in SCENARIOS for n in range(1, 5)}
    assert {(r['scenario'], r['seed']) for r in data['records']} == expected
    assert all(r['game_completed'] and not r['findings'] for r in data['records'])
report['mixed_seats'] = {'unique_cases': 20, 'executions_including_replay': 80,
    'hash_seeds': [0, 7], 'cross_hash_equal': True, 'hard_findings': 0,
    'partial': fuzz[0]['partial'], 'rejected_random_plans_per_hash': sum(r['rejected'] for r in fuzz[0]['records']),
    'batch_digest': fuzz[0]['batch_digest']}

census = [json.loads((run / f'census{h}.json').read_text()) for h in (0, 7)]
assert census[0] == census[1]
for data in census:
    assert data['metadata']['source_sha256'] == identity['source_sha256']
    assert data['games'] == data['completed'] == 25
    assert data['failed_games'] == 0 and not data['failures']
    assert all(k == 'legal-decline' or n == 0 for k, n in data['by_severity'].items())
report['strict_census'] = {'unique_cases': 25, 'executions': 50, 'cross_hash_equal': True,
                         'defects': 0, 'by_severity_per_hash': census[0]['by_severity']}

suite = ET.parse(run / 'tests.xml').getroot().find('testsuite')
assert suite is not None
assert all(int(suite.attrib[k]) == 0 for k in ('errors', 'failures', 'skipped'))
report['pytest'] = {k: suite.attrib[k] for k in ('tests', 'errors', 'failures', 'skipped', 'time')}
(root / 'results.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('bot_batches', 'balance')}, indent=2))
print('Accepted bot games:',len(all_rows),'Unchanged balance band: PASS')
