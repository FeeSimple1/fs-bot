"""Retain immediate worker failures even if a slow parallel run is interrupted."""
import os


def pytest_runtest_logreport(report):
    if report.failed:
        with open(os.environ['FS_BATCH_FAIL_REPORT'], 'a') as stream:
            stream.write(report.nodeid + '\n' + str(report.longrepr) + '\n')
