"""Witness XC2-01 on b23c8cd. Assertions freeze observed defective behavior."""
from copy import deepcopy
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import json

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, place_piece
from fs_bot.cli.display import HumanTurnDisplay
from fs_bot.engine.action_validation import validate_human_structure
from fs_bot.engine.game_engine import ACTION_COMMAND, ACTION_LIMITED_COMMAND, play_card
from fs_bot.state.serialize import decode, encode, save_game, load_game
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import validate_state, check_structural_integrity
from fs_bot.tools.seat_session import SeatSession, validate_response
from fs_bot.tools import llm_seat


def recruit(regions):
    return {'command': rc.CMD_RECRUIT, 'sa': 'No SA', 'regions': [], 'details': {
        'recruit_plan': [{'region': region, 'action': 'place_auxilia', 'count': 1}
                         for region in regions]}}


def position():
    s = setup_scenario(rc.SCENARIO_GREAT_REVOLT, seed=4)
    place_piece(s, rc.SEQUANI, rc.ROMANS, rc.FORT)
    s['non_player_factions'] = {rc.ARVERNI, rc.AEDUI, rc.BELGAE}
    s['current_card'] = s['current_card_id'] = 31
    s['played_cards'], s['deck'], s['next_card'] = [31], [], None
    for f in s['eligibility']:
        s['eligibility'][f] = rc.ELIGIBLE if f in (rc.ARVERNI, rc.ROMANS) else rc.INELIGIBLE
    def first_and_pause(state, faction, options, position):
        if faction == rc.ROMANS:
            assert options == [ACTION_LIMITED_COMMAND, 'pass']
            raise EOFError
        return {'action': ACTION_COMMAND, 'player_action': {'command': rc.CMD_RALLY,
            'details': {'rally_plan': {'warbands': [rc.ARVERNI_REGION]}}}}
    try:
        play_card(s, first_and_pause, execute=True)
    except EOFError:
        pass
    assert not validate_state(s), validate_state(s)
    assert not check_structural_integrity(s), check_structural_integrity(s)
    return s


def main():
    s = position()
    action = recruit([rc.PROVINCIA, rc.SEQUANI])
    control_error = validate_human_structure(s, rc.ROMANS, action, limited=True)
    assert 'Limited Command' in control_error
    action['details']['command_parts'] = [recruit([rc.PROVINCIA])]
    assert validate_human_structure(s, rc.ROMANS, action, limited=True) is None
    response = {'action': ACTION_LIMITED_COMMAND, 'player_action': action}
    assert validate_response(s, {'kind': 'turn', 'faction': rc.ROMANS,
                                'options': [ACTION_LIMITED_COMMAND, 'pass']}, response) == response
    baseline = {r: count_pieces(s, r, rc.ROMANS, rc.AUXILIA) for r in (rc.PROVINCIA, rc.SEQUANI)}
    with TemporaryDirectory() as temp:
        path = Path(temp)
        meta = {'scenario': rc.SCENARIO_GREAT_REVOLT, 'seat': rc.ROMANS}
        SeatSession(s, meta, [], HumanTurnDisplay(StringIO()))
        save_game(s, path/'save.json', meta=meta, log=[])
        output = StringIO()
        with redirect_stdout(output):
            assert llm_seat.cmd_play(SimpleNamespace(dir=temp)) == 0
            for _ in range(30):
                current, current_meta, log = load_game(path/'save.json', validate=True)
                pending = current_meta['assistant_session']['pending']
                if pending is None:
                    break
                request = decode(pending['request'])
                if request['kind'] == 'turn':
                    answer = response
                    assert request['options'] == [ACTION_LIMITED_COMMAND, 'pass']
                elif request['kind'] == 'resource_transfer':
                    answer = {'transfers': []}
                elif request['kind'] == 'voluntary_removal':
                    answer = {'done': True}
                else:
                    answer = {'use_default': True}
                assert llm_seat.cmd_submit(SimpleNamespace(dir=temp, decision_id=pending['id'],
                                                          response=json.dumps(answer))) == 0
            else:
                raise AssertionError('Session did not finish')
        changes = {r: count_pieces(current, r, rc.ROMANS, rc.AUXILIA)-baseline[r] for r in baseline}
        assert changes == {rc.PROVINCIA:1, rc.SEQUANI:1}, (changes, output.getvalue())
        assert not validate_state(current) and not check_structural_integrity(current)
        assert any(entry.get('player_action') == action for entry in log)
        return {'control_without_shadow': control_error, 'shadow_plan_accepted': True,
                'offered_actions': [ACTION_LIMITED_COMMAND, 'pass'],
                'committed_auxilia_changes': changes, 'state_integrity_errors': [],
                'durable_plan_in_log': True}

if __name__ == '__main__':
    print(json.dumps(main(), indent=2))
