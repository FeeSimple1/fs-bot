Spring Leader placement validation, starting commit a537511a1220ea4d2b0e94e63ab5cc581ef3a605.
This is a new evidence run. Earlier Event repair evidence is historical and is not overwritten or relabeled.

Preparation only until the parent explicitly freezes the integrated Python source.
Run from this workspace with login:false; the default login shell previously hung.
Python: /workspace/scratch/534c265c65f4/fs-test-venv/bin/python
Repository: /workspace/scratch/534c265c65f4/fs-bot

Starting source: 071485179ff2949ba9e2163ca48f6761c52f617084f90a0a60ee521f35926d8b.
Starting balance baseline: 15dd335d71fb38288348651c158462a1db8ca42868393ac4fcee4ce682c364bf.
starting-source.json independently hashes committed Python blobs. The live tree was already being edited when this agent began; its current bytes are not labeled as the starting revision. Parent confirms the before-suite finished before implementation began. Its original JUnit and text output are retained.

Agreed bounded matrix (all five scenarios for every seed/profile group):
  100 legacy bot games: seeds 1-20; PYTHONHASHSEED=0.
   25 original bot games: seeds 201-205; PYTHONHASHSEED=0.
   25 second-edition bot games: seeds 201-205; PYTHONHASHSEED=0.
   80 mixed executions: seeds 1-4, each case internally replayed, hash seeds 0 and 7.
   50 strict census executions: seeds 1-5, hash seeds 0 and 7.
Legacy bots gate the remaining six commands, so nonlegal diagnostics stop expansion promptly. Default workers=2, remaining-job parallelism=2. Logs, exact argv/environment, actual child exits, source before/after, baseline bytes and file inventory are captured. The source and baseline remain frozen during all accepted runs. A failed attempt remains and any correction requires a fresh attempt directory.

Commands after explicit source freeze:
  python orchestrate.py --attempt attempt1 --source-sha256 FROZEN_SHA
  python run_tests.py --attempt attempt1 --source-sha256 FROZEN_SHA --check probes
  python run_tests.py --attempt attempt1 --source-sha256 FROZEN_SHA
  python verify.py --attempt attempt1
Use the named Python above. The validation agent owns the final full pytest using run_tests.py, recording tests.xml, tests.log and tests.status.json in the attempt directory. The parent owns targeted integration checks. Expected full-suite status schema: exit_code, cwd, argv, source and source_after, with source_sha256/commit in both source identities. A pre-pytest read-only matrix check may use --skip-pytest; final acceptance includes the full suite.

Independent verification checks exact150 unique bot keys across separate profiles; all completion flags/errors/integrity/diagnostics; final and emitted four-faction rankings including all-NP tie precedence; winner, final hash, termination and Interlude; all summaries; frozen command statuses; source and baseline identities; exact mixed case coverage/replay digest/cross-hash JSON equality; strict census aggregate/cross-hash equality; and full pytest. Optional rejected random plans are reported separately; they are not silently counted as complete human-choice coverage. The census tool emits metadata and aggregate successes, not per-success case records, and this limit stays disclosed.

Balance uses the same100 audited legacy records, without a redundant second100-game run, and exact fractions against the committed starting baseline with unchanged inclusive15-percentage-point band. The verifier intentionally fails when the original guardrail fails and preserves that result. It also requires the live original baseline; it is not the post-refresh acceptance wrapper.

Targeted integration acceptance is source-derived and parent-owned: named/successor Spring placement, optional Vercingetorix arrival, human legal choices and invalid/missing-response behavior, NP plurality/ties, base/expansion isolation, scoped Gallic War Interlude Caesar/Ambiorix choices, state/piece conservation, preview purity, save/load and exact session replay. At freeze the actual targeted test modules/commands and pass counts must be linked; random mixed games are not a substitute for these deterministic cases.

If the original balance band fails after clean mechanics/tests, first compare changed winner/card/final hashes against exact prior-source records. Prior attempt5 source071485 is byte-identical to starting a537511, but retains its actual historical commit04b and own provenance. No historical trace is relabeled as this run. Trace only actual changed outcomes needed to explain the failure, starting beyond-band scenarios. Record earliest actual decision/state/RNG divergence and exact old/new final hashes against their audited records; distinguish richer reporting from behavioral changes. Check each distinct mechanism against the supplied sources. Reuse a verified cached prior trace only with exact source/profile/scenario/seed/hash match. No blind refresh, policy tuning, widened threshold, or broad redundant reruns.

prepare_candidate.py is review-only and may be used only after the parent authorizes a candidate following source review. It produces100 winner/cards keys from the current accepted legacy records, retains original failed evidence, and never installs a baseline. Any approved installation/post-refresh checks remain separate and parent-owned. No commit/push is performed by this validation agent.
