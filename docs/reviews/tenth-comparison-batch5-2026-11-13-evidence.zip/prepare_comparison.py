"""Prepare and review paired validation data for the tenth audit's last batch."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re

from fs_bot import rules_consts as rc
from fs_bot.state.serialize import decode
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues


ROOT = Path(__file__).resolve().parent
PARENT = 'd27e774bd90c5c6c172d5b69dbce574fd176702c'
PARENT_DIGEST = '4a50d48f9557eb793bd746cdfd4e1c2d815d56675ba9eda49223a29a054c1240'
BALANCE_ROW = re.compile(r'^\[(.+) seed= *(\d+)\] winner=(.+) \((\d+) cards\)$', re.M)
EDITIONS = {'legacy': range(1, 21), 'second-edition': range(53, 57)}


def load(name):
    return json.loads((ROOT / name).read_bytes())


def dump(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def read_games(folder, edition, digest):
    seeds = EDITIONS[edition]
    metadata = load(f'{folder}/metadata.json')
    assert metadata['source_sha256'] == digest and metadata['hash_seed'] == 0
    assert metadata['card_edition'] == edition and metadata['seeds'] == list(seeds)
    rows = [json.loads(line) for line in (ROOT / folder / 'games.jsonl').read_text().splitlines()]
    games = {(row['scenario'], row['seed']): row for row in rows}
    assert len(rows) == len(games) == len(SCENARIOS) * len(seeds)
    assert set(games) == {(scenario, seed) for scenario in SCENARIOS for seed in seeds}
    for row in rows:
        assert row['source_sha256'] == digest and row['card_edition'] == edition
        assert row['completed'] and row['game_completed'] and row['audit_completed']
        assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row)
        assert len(row['final_state_sha256']) == 64
        assert all(d['severity'] == 'legal-decline' for d in row['diagnostic_occurrences'])
    return games


def paired_runs():
    source = load('source.json')
    digest = source['source_sha256']
    assert source['commit'] == PARENT and source['dirty']
    games, tasks, summary = {}, [], {}
    for edition in EDITIONS:
        old = read_games(f'parent-{edition}', edition, PARENT_DIGEST)
        new = read_games(edition, edition, digest)
        changes = [k for k in new if old[k]['final_state_sha256'] != new[k]['final_state_sha256']]
        tasks.extend({'task': [*key, edition], 'mixed': False} for key in changes)
        summary[edition] = {
            'games': len(new), 'changed_final_states': len(changes),
            'changed_winners': sum(old[key]['winner'] != row['winner'] for key, row in new.items()),
            'changed_card_counts': sum(old[key]['cards'] != row['cards'] for key, row in new.items()),
            'interludes': sum(row['interlude_completed'] for row in new.values()),
            'diagnostic_occurrences': sum(len(row['diagnostic_occurrences']) for row in new.values()),
        }
        games[edition] = old, new
    before, after = load('parent-fuzz0.json'), load('fuzz0.json')
    assert before['metadata']['source_sha256'] == PARENT_DIGEST
    assert after['metadata']['source_sha256'] == digest
    assert all(after['metadata'][key] for key in ('replay', 'events', 'reactive'))
    assert after['metadata']['seeds'] == list(EDITIONS['second-edition'])
    assert after['metadata']['card_edition'] == 'second-edition'
    for extension in ('json', 'log'):
        assert (ROOT / f'fuzz0.{extension}').read_bytes() == (ROOT / f'fuzz987.{extension}').read_bytes()
    assert after['games'] == len(after['records']) == 20 and after['hard_findings'] == 0
    mixed_old, mixed_new = {}, {}
    for old, new in zip(before['records'], after['records'], strict=True):
        key = new['scenario'], new['seed']
        assert key == (old['scenario'], old['seed'])
        assert new['game_completed'] and not new['findings']
        mixed_old[key], mixed_new[key] = old, new
        if old != new:
            tasks.append({'task': [*key, new['card_edition']], 'mixed': True})
    mixed = {key: after[key] for key in ('games', 'human_turns', 'event_turns',
                                        'events_ok', 'partial', 'hard_findings', 'batch_digest')}
    mixed['changed_digests'] = sum(entry['mixed'] for entry in tasks)
    return games, (mixed_old, mixed_new), tasks, {'bot_games': summary, 'mixed': mixed}


def compare_traces(games, mixed, tasks, digest):
    before, after = [decode(load(f'trace-{side}.json')) for side in ('parent', 'repair')]
    assert before['source']['source_sha256'] == PARENT_DIGEST
    assert after['source']['source_sha256'] == digest
    changes = []
    for old, new, entry in zip(before['games'], after['games'], tasks, strict=True):
        task, is_mixed = entry['task'], entry['mixed']
        assert old['task'] == new['task'] == task and old['mixed'] == new['mixed'] == is_mixed
        key = tuple(task[:2])
        records = mixed if is_mixed else games[task[2]]
        for trace, rows in zip((old, new), records, strict=True):
            expected = rows[key]
            assert all(trace['outcome'][field] == expected[field] for field in trace['outcome'])
        differences = [(x, y) for x, y in zip(old['cards'], new['cards'])
                       if x['after'] != y['after'] or x['actions'] != y['actions']]
        if not differences:
            assert is_mixed and len(old['cards']) == len(new['cards'])
            x, y = next((x, y) for x, y in zip(old['cards'], new['cards'])
                        if x['arverni'] != y['arverni'])
            assert x['before'] == y['before']
            assert any(row['kind'] == 'ability' and row['outcome'].get('declined_no_effect')
                       for row in y['arverni'])
            changes.append(dict(entry, card=y['card'], ordinal=y['ordinal'], effect='legal decline'))
            continue
        x, y = differences[0]
        assert x['before'] == y['before'] and x['card'] == y['card'], entry
        first = next(row for row in y['arverni'] if row['kind'] == 'ability'
                     and row['outcome'].get('executed') and row['before'] != row['after'])
        ability = first['outcome']['sa']
        assert ability in (rc.SA_DEVASTATE, rc.SA_ENTREAT)
        regions = first['outcome'].get('regions') or [
            action['region'] for action in first['outcome'].get('actions', ())]
        repeated = sorted(set(regions) & set(first['marked_before'])) if ability == rc.SA_DEVASTATE else []
        if first['command'] != rc.CMD_MARCH:
            assert repeated and ability == rc.SA_DEVASTATE
        if ability == rc.SA_DEVASTATE:
            assert first['losses']
        changes.append(dict(entry, card=y['card'], ordinal=y['ordinal'], command=first['command'],
                            effect=ability, regions=regions, repeat_regions=repeated,
                            losses=first.get('losses', []),
                            resources=[first['resources_before'], first['resources_after']],
                            winners=[r['outcome'].get('winner') for r in (old, new)],
                            card_counts=[len(r['cards']) for r in (old, new)]))
    return changes


def original_balance(games):
    old, new = games['legacy']
    log = (ROOT / 'balance.log').read_text()
    records = {f'{scenario}|{seed}': {'winner': faction, 'cards': int(cards)}
               for scenario, seed, faction, cards in BALANCE_ROW.findall(log)}
    expected = {f'{scenario}|{seed}': {key: row[key] for key in ('winner', 'cards')}
                for (scenario, seed), row in new.items()}
    assert len(records) == 100 and records == expected
    baseline = load('pre-repair-balance-baseline.json')['games']
    shifts = {}
    for scenario in SCENARIOS:
        prefix = scenario + '|'
        before = Counter(row['winner'] for key, row in baseline.items() if key.startswith(prefix))
        after = Counter(row['winner'] for key, row in records.items() if key.startswith(prefix))
        shifts[scenario] = {f: 5 * (after[f] - before[f]) for f in rc.FACTIONS
                            if before[f] or after[f]}
    largest = max(abs(points) for values in shifts.values() for points in values.values())
    assert largest == 20 and 'FAIL: a faction win rate moved beyond the band.' in log
    winners = [[*key, old[key]['winner'], new[key]['winner']] for key in new
               if old[key]['winner'] != new[key]['winner']]
    return {'games': 100, 'largest_shift_points': largest, 'band_points': 15,
            'drift_by_scenario': shifts, 'changed_winners_from_parent': winners}, {'games': records}


def main():
    import sys
    games, mixed, tasks, summary = paired_runs()
    if sys.argv[1:] == ['--tasks']:
        dump('trace-tasks.json', tasks)
        return
    assert tasks == load('trace-tasks.json')
    changes = compare_traces(games, mixed, tasks, load('source.json')['source_sha256'])
    balance, candidate = original_balance(games)
    summary.update(balance=balance, first_changes=changes)
    dump('comparison.json', summary)
    (ROOT / 'reviewed-baseline.json').write_text(json.dumps(candidate, indent=1, sort_keys=True) + '\n')
    print(json.dumps({key: value for key, value in summary.items() if key != 'first_changes'},
                     indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
