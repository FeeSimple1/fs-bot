"""Verify the paired Sappers and Drought repair evidence against the checkout."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
from xml.etree import ElementTree
from zipfile import ZipFile

from compare_traces import compare, read_games
from fs_bot.tools.error_census import _severity
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


HERE = Path(__file__).resolve().parent
REPO = Path(__import__('fs_bot').__file__).resolve().parents[1]
PARENT = '7313c9d96436b5602323d1299ba34a904bd6514d'
OLD_SOURCE = '7cb64407ff5594eb2bbd671a8159c408410fa8cc26e7a784da7afe0fd47363db'
SOURCE = 'f7c8439d35b50bb0c00488cf86e211fd94c2dfb4804b3585b8e638420777e452'
BASELINE = REPO / 'fs_bot/tools/balance_baseline.json'
EDITION_SEEDS = {'legacy': range(1, 21), 'second-edition': range(71, 75)}


def load(name):
    return json.loads((HERE / name).read_bytes())


def verify_source(audit):
    assert source_identity()['source_sha256'] == SOURCE
    assert len(list((REPO/'fs_bot').rglob('*.py'))) == 630
    hashes = json.loads(audit.read('validation/protected-sources.json'))
    references = {path.relative_to(REPO).as_posix() for path in
                  (REPO/'Reference Documents').rglob('*') if path.is_file()}
    assert len(references) == 47 and hashes.keys() == references | {'fs_bot/rules_consts.py'}
    assert all(hashlib.sha256((REPO/path).read_bytes()).hexdigest() == digest
               for path, digest in hashes.items())
    assert audit.read('events/results.json') == (HERE/'parent-witness.json').read_bytes()
    assert (HERE/'test_twelfth_comparison_events.py').read_bytes() == (
        REPO/'fs_bot/tests/test_twelfth_comparison_events.py').read_bytes()
    return len(hashes)


def verify_tests():
    counts = {'parent-final': (41, 37), 'directed0': (332, 0),
              'directed987': (332, 0), 'full': (10490, 0)}
    for name, (total, failed) in counts.items():
        suite, = ElementTree.parse(HERE/f'{name}.xml').iter('testsuite')
        assert int(suite.get('tests')) == total and int(suite.get('failures')) == failed, name
        assert int(suite.get('errors')) == int(suite.get('skipped')) == 0, name
    return {name: {'passed': total - failed, 'failed': failed}
            for name, (total, failed) in counts.items()}


def read_audit(get, folder, edition, expected_source):
    metadata = json.loads(get(f'{folder}/metadata.json'))
    assert metadata['card_edition'] == edition
    assert metadata['source_sha256'] == expected_source
    assert metadata['all_factions_bots'] and metadata['hash_seed'] == 0
    seeds = EDITION_SEEDS[edition]
    assert metadata['seeds'] == list(seeds)
    games = read_games(get(f'{folder}/games.jsonl').decode())
    assert games.keys() == {(edition, scenario, seed)
                            for scenario in SCENARIOS for seed in seeds}
    for game in games.values():
        assert game['completed'] and game['game_completed'] and game['audit_completed']
        assert not (game['errors'] or game['integrity_findings'] or _outcome_issues(game))
        assert len(game['final_state_sha256']) == 64
        assert game['source_sha256'] == expected_source
        for incident in game['diagnostic_occurrences']:
            assert incident['severity'] == _severity(incident['kind'], incident['message']) == 'legal-decline'
    return games


def verify_games(audit):
    def local(name):
        return (HERE/name).read_bytes()

    before, after, summary = {}, {}, {}
    for edition in EDITION_SEEDS:
        parent_get = local if edition == 'legacy' else audit.read
        folder = 'parent-legacy' if edition == 'legacy' else 'validation/bots'
        old = read_audit(parent_get, folder, edition, OLD_SOURCE)
        new = read_audit(local, edition, edition, SOURCE)
        before.update(old)
        after.update(new)
        summary[edition] = {
            'games': len(new), 'interludes': sum(row['interlude_completed'] for row in new.values()),
            'legal_declines': sum(len(row['diagnostic_occurrences']) for row in new.values()),
            'changed': {field: sum(row[field] != old[key][field] for key, row in new.items())
                        for field in ('cards', 'winner', 'final_state_sha256')},
        }
    return before, after, summary


def verify_mixed(audit):
    for suffix in ('json', 'log'):
        assert (HERE/f'fuzz0.{suffix}').read_bytes() == (HERE/f'fuzz987.{suffix}').read_bytes()
    mixed = load('fuzz0.json')
    assert mixed['games'] == len(mixed['records']) == 20
    assert mixed['hard_findings'] == 0
    assert all(row['game_completed'] and not row['findings'] for row in mixed['records'])
    metadata = mixed['metadata']
    assert metadata['source_sha256'] == SOURCE and metadata['commit'] == PARENT
    assert metadata['card_edition'] == 'second-edition' and metadata['seeds'] == list(EDITION_SEEDS['second-edition'])
    assert all(metadata[key] for key in ('events','reactive','replay'))
    before = {(r['scenario'], r['seed']): r for r in json.loads(audit.read('validation/fuzz0.json'))['records']}
    assert before.keys() == {(r['scenario'], r['seed']) for r in mixed['records']}
    result = {key: mixed[key] for key in ('games','human_turns','event_turns','events_ok','hard_findings','partial','batch_digest')}
    result['changed_cases'] = sum(before[r['scenario'], r['seed']] != r for r in mixed['records'])
    return result


def balance_records(games):
    return {f'{scenario}|{seed}': {field: game[field] for field in ('winner','cards')}
            for (edition, scenario, seed), game in games.items() if edition == 'legacy'}


def verify_balance(before, after):
    original, reviewed = balance_records(before), balance_records(after)
    assert original == load('balance-baseline-parent.json')['games']
    assert reviewed == json.loads(BASELINE.read_bytes())['games']
    for name, limit, result in (('balance-original', 20, 'FAIL:'), ('balance-reviewed', 20, 'OK:'),
                                ('canary', 3, 'OK:')):
        log = (HERE/f'{name}.log').read_text()
        lines = re.findall(r'^\[(.+) seed= *(\d+)\] winner=(.+) \((\d+) cards\)$', log, re.M)
        games = {f'{scenario}|{seed}': {'winner':winner, 'cards':int(cards)}
                 for scenario, seed, winner, cards in lines}
        requested = {f'{scenario}|{seed}' for scenario in SCENARIOS for seed in range(1,limit+1)}
        assert len(lines) == len(games) and games == {key: reviewed[key] for key in requested}
        assert any(line.startswith(result) for line in log.splitlines())
    return {
        'games': len(reviewed), 'canary_games': 15,
        'changed_records': sum(original[key] != game for key, game in reviewed.items()),
        'changed_winners': sum(original[key]['winner'] != game['winner'] for key, game in reviewed.items()),
        'changed_cards': sum(original[key]['cards'] != game['cards'] for key, game in reviewed.items()),
        'original_gallic_war_aedui_wins': sum(game['winner'] == 'Aedui' for key,game in original.items()
                                              if key.startswith('The Gallic War|')),
        'reviewed_gallic_war_aedui_wins': sum(game['winner'] == 'Aedui' for key,game in reviewed.items()
                                              if key.startswith('The Gallic War|')),
        'baseline_sha256': hashlib.sha256(BASELINE.read_bytes()).hexdigest(),
    }


def verify_traces(before, after):
    saved = load('first-differences.json')
    expected = {key for key in before if before[key]['final_state_sha256'] != after[key]['final_state_sha256']}
    seen = set()
    for pair in saved['changes']:
        key = pair['edition'], pair['scenario'], pair['seed']
        assert key not in seen and key in expected
        seen.add(key)
        old, new = pair['parent'], pair['repair']
        assert old['before'] == new['before'] == pair['entry_board_sha256']
        assert len(pair['entry_board_sha256']) == 64
        assert old['after'] != new['after'] and old['card'] == new['card'] == pair['card']
        assert pair['old_winner'] == before[key]['winner'] and pair['new_winner'] == after[key]['winner']
        assert pair['old_cards'] == before[key]['cards'] and pair['new_cards'] == after[key]['cards']
        actor = pair['first_changed_faction']
        old_decision, new_decision = (
            next(entry for entry in card['decisions'] if entry['faction'] == actor)
            for card in (old, new))
        assert old_decision['before'] == new_decision['before']
        assert old_decision['decision']['action'] == 'event'
        if new_decision['decision']['action'] == 'event':
            assert old_decision['before_execution'] == new_decision['before_execution']
            assert old_decision['after_effects'] != new_decision['after_effects']
    assert expected == seen and len(seen) == saved['games_changed']
    assert saved['first_cards'] == Counter(str(pair['card']) for pair in saved['changes'])
    assert saved['winner_changes'] == Counter(
        str(pair['card']) for pair in saved['changes'] if pair['old_winner'] != pair['new_winner'])
    return {key:saved[key] for key in ('games_changed','first_cards','winner_changes')}


def main():
    path = REPO/'docs/reviews/comparison-audit-round12-2026-11-13-evidence.zip'
    with ZipFile(path) as audit:
        protected = verify_source(audit)
        before, after, games = verify_games(audit)
        mixed = verify_mixed(audit)
    print(json.dumps({
        'parent': PARENT, 'python_source_sha256': SOURCE, 'protected_files': protected,
        'tests': verify_tests(), 'audited_games': games, 'mixed': mixed,
        'trace': verify_traces(before, after), 'balance': verify_balance(before, after),
    }, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
