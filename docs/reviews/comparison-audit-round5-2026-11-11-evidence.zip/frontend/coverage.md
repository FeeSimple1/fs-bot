# Frontend audit coverage

Audited `bd30d522e8baa2d303b9e372d7d9c550351e91a5` without modifying engine, tests or reference data.

The Liberty or Death implementation lessons at `2991ea279062773548ec390a1da75f3e85381702` supplied the search patterns of missing production call wiring and forced/free actions bypassing ordinary behavior. Its rules were not used as Falling Sky authority.

Read the shared action validators, free-action validator and dispatch, Assembly52's two-ability orchestration, March group execution and drop-off callbacks, durable response validation/signatures, and relevant prior audit dispositions. The portable witness confirms two groups in the ordinary-shape Event-granted March integration.

Run from the fs-bot root:

```sh
PYTHONPATH=. python /path/to/frontend/probe_frontend.py
```

The script's assertions deliberately preserve the audited defects. It covers public Event execution, public ordinary-action controls, clean board/piece inventories, preview nonmutation, a durable free-action request, save/load, acceptance, and deterministic replay. Its paired drop-off test advertises the same callback support for both ordinary and Event-granted Commands. `probe-output.json` is the captured successful output.

The initial `quick.py` exploratory script is superseded by the portable script. It is not needed for the final evidence archive. An initial incomplete March plan omitted `destinations`; this was correctly refused. Final witnesses use complete canonical `origins`/`destinations`/`routes`/`groups` and assert the control outcomes.

Negative/static coverage, not an exhaustive correctness claim:

- Ordinary Britannia March with an ability rejects before any board/RNG mutation. Free crossing without an ability and mainland free March with an ability remain valid controls.
- The repaired nested/null SA detail lookup is shared with execution. No new duplicate of FE4-02 was accepted.
- The Event validator derives implicit March origins and extra groups for grant Region/max-Region enforcement. No new Limited Command scope bypass was established.
- Battle command_parts are forbidden before execution, so reserved Battle modifiers cannot be hidden through that older split-Command representation.
- Seize Event-only flags now come from the trusted engine grant, so nested caller flags were not accepted as a material exploit.
- Assembly repeat-ability-type and base German controller questions remain existing unresolved questions and are excluded.
- A free Battle using the representational `sa_timing: during` with Ambush appears liable to the generic split-Command branch, but the Battle modifier can be expressed without that redundant timing field. No standalone finding is asserted without further interface/source review.
- No new session journal, stable-ID, rollback or preview mutation defect was found in the witness. The session faithfully records and replays the engine's incorrectly accepted legal scope.

These are controlled-position reproductions, not a frequency estimate or a claim that every boundary was audited. All fixtures include Provincia's permanent Fort and use production piece helpers. Full-suite and integrated matrices are coordinated by the parent audit.
