"""Round-nine frontend witnesses; assertions describe defects at f4c8372.

Run with the audited checkout on --repo. No game-source edits or monkeypatches.
The optional output directory receives human transcripts and resumable saves.
"""
import argparse
import copy
import io
import json
from pathlib import Path
import sys
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--repo', required=True)
parser.add_argument('--out-dir')
args = parser.parse_args()
sys.path.insert(0, str(Path(args.repo).resolve()))
from fs_bot import rules_consts as r
from fs_bot.board.pieces import place_piece, count_pieces, count_pieces_by_state
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.cli.display import HumanTurnDisplay, format_board, snapshot_state
from fs_bot.cli.human_plan import collect_player_action
from fs_bot.cli.reactive import make_cli_reactive
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND_SA, ACTION_EVENT, get_sop_factions, _action_transaction
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.state.serialize import encode, decode, save_game, load_game
from fs_bot.tools.seat_session import SeatSession, DecisionPending, board_copy, fingerprint

OUT = Path(args.out_dir) if args.out_dir else None
if OUT:
    OUT.mkdir(parents=True, exist_ok=True)


def save_text(name, text):
    if OUT:
        (OUT / name).write_text(text)


def check(state):
    result = {'census': validate_state(state), 'structure': check_structural_integrity(state)}
    assert result == {'census': [], 'structure': []}, result
    return result


def event(state, card, actor, shaded=False):
    state['current_card'] = card
    result = execute_decision(state, actor, {'action': ACTION_EVENT, 'player_action': {
        'command': r.FIRST_DID_EVENT, 'details': {'card_id': card,
        'text_preference': r.EVENT_SHADED if shaded else r.EVENT_UNSHADED}}})
    assert result['executed'] and not result.get('errors'), result
    return result


def enlist_fixture(capability=True):
    state = build_initial_state(r.SCENARIO_ARIOVISTUS, seed=19)
    state['non_player_factions'] = set(get_sop_factions(state)) - {r.BELGAE}
    place_piece(state, r.PROVINCIA, r.ROMANS, r.FORT)
    place_piece(state, r.SUGAMBRI, r.BELGAE, r.LEADER, leader_name=r.BODUOGNATUS)
    place_piece(state, r.SUGAMBRI, r.GERMANS, r.WARBAND, 3)
    place_piece(state, r.CARNUTES, r.BELGAE, r.WARBAND)
    state['resources'][r.GERMANS] = 10
    if capability:
        event(state, 8, r.GERMANS, shaded=True)
    state['current_card'] = 8
    check(state)
    return state


def enlist_plan(count, expanded=False):
    sub = {'type': 'german_raid', 'region': r.SUGAMBRI}
    if expanded:
        sub['actions'] = [{'type': 'gain'} for _ in range(count)]
    else:
        sub['count'] = count
    return {'command': r.CMD_RAID, 'sa': r.SA_ENLIST, 'sa_regions': [r.SUGAMBRI],
            'details': {'raid_plan': [{'region': r.CARNUTES}], 'enlist': sub}}


class TerminalInput:
    """Answer only offered optional removal menus, then a fixed human transcript."""
    def __init__(self, output, answers):
        self.output, self.answers = output, iter(answers)
        self.offset, self.used = 0, []

    def readline(self):
        recent = self.output.getvalue()[self.offset:]
        self.offset = len(self.output.getvalue())
        if 'Voluntary removal?' in recent:
            answer = 'Finish voluntary removal'
        else:
            try:
                answer = next(self.answers)
            except StopIteration:
                return ''
        self.used.append(answer)
        return answer + '\n'


def enlist_cases():
    rows = []
    for name, cap, n, expanded, expected in [
        ('owned_capability_compact_three_accepted', True, 3, False, True),
        ('owned_capability_expanded_three_control', True, 3, True, True),
        ('owned_capability_compact_two_control', True, 2, False, True),
        ('no_capability_expanded_three_rejected_control', False, 3, True, False),
        ('no_capability_compact_two_control', False, 2, False, True),
    ]:
        state = enlist_fixture(cap)
        result = execute_decision(state, r.BELGAE, {
            'action': ACTION_COMMAND_SA, 'player_action': enlist_plan(n, expanded)})
        assert result['executed'] and not result.get('errors')
        assert result['sa_execution']['executed'] is expected
        used = n if expected else 0
        assert state['resources'][r.GERMANS] == 10 + used
        assert count_pieces_by_state(state, r.SUGAMBRI, r.GERMANS, r.WARBAND, r.HIDDEN) == 3-used
        rows.append({'case': name, 'result': result,
                     'german_resources': state['resources'][r.GERMANS],
                     'german_hidden': 3-used, 'checks': check(state)})
    state = enlist_fixture()
    output = io.StringIO()
    source = TerminalInput(output, [
        'Special Activity first, then Command', 'Enlist', 'Raid', r.SUGAMBRI,
        '1', '(just gain 1 Resource)', '(just gain 1 Resource)', '(just gain 1 Resource)',
        'Raid', r.CARNUTES, 'gain 1 Resource', '(done)'])
    # Actual supported CLI reactive frontend, including action windows.
    state['decision_agent'] = make_cli_reactive([r.BELGAE], source, output)
    before = fingerprint(board_copy(state))
    plan = collect_player_action(state, r.BELGAE, ACTION_COMMAND_SA, source, output)
    assert fingerprint(board_copy(state)) == before
    text = output.getvalue()
    assert "  1) 3" in text
    assert len(plan['details']['enlist']['actions']) == 3
    result = execute_decision(state, r.BELGAE, {'action': ACTION_COMMAND_SA, 'player_action': plan})
    assert result['sa_execution']['executed'] and state['resources'][r.GERMANS] == 13
    save_text('enlist-terminal.txt', output.getvalue())
    start = text.index('Raid with how many Hidden German Warbands?')
    end = text.index('Raid 1 target', start)
    rows.append({'case': 'live_terminal_accepts_third_raider', 'menu': text[start:end],
                 'inputs': source.used, 'plan': plan, 'result': result,
                 'planning_unchanged': True, 'german_resources': 13, 'checks': check(state)})
    return rows


def morbihan_fixture(slingers):
    state = build_initial_state(r.SCENARIO_ARIOVISTUS, seed=7)
    state['non_player_factions'] = set(get_sop_factions(state)) - {r.ROMANS}
    place_piece(state, r.PROVINCIA, r.ROMANS, r.FORT)
    assert _ally_tribe(state, r.TRIBE_VENETI, r.ARVERNI)
    for region in (r.VENETI, r.PICTONES):
        place_piece(state, region, r.ARVERNI, r.WARBAND, 2)
        place_piece(state, region, r.AEDUI, r.WARBAND, 2 if region == r.VENETI else 1)
    place_piece(state, r.CARNUTES, r.ROMANS, r.AUXILIA, 2, piece_state=r.REVEALED)
    if slingers:
        event(state, 13, r.ROMANS)
    state['current_card'] = 'A20'
    check(state)
    return state


def attach(session):
    session.state['decision_agent'] = session.reactive
    def driver(*_):
        pass
    driver.transaction_checkpoint = session.checkpoint
    driver.transaction_restore = session.restore
    driver.transaction_complete = session.transaction_complete
    return driver


def advance(session):
    driver = attach(session)
    try:
        with _action_transaction(session.state, driver):
            result = event(session.state, 'A20', r.GERMANS, shaded=True)
    except DecisionPending:
        return None
    session.finish()
    check(session.state)
    return result


def answer(session):
    pending = session.data['pending']
    request = decode(pending['request'])
    response = {'region': r.CARNUTES} if request['kind'] == 'slingers_region' else {'use_default': True}
    session.import_inbox({'decision_id': pending['id'], 'response': response})


def pending_details(pending):
    board = decode(pending['board'])
    context = board['_morbihan_projection']
    before = fingerprint(board)
    rendered = format_board(board)
    snap = snapshot_state(board)
    assert fingerprint(board) == before
    survivors = {region: sum(counts.values()) for region, counts in context['survivors'].items()}
    displayed = {region: snap['pieces'].get((region, r.ARVERNI, r.WARBAND), 0)
                 for region in context['sources']}
    region_rows = [line for line in rendered.splitlines()
                   if line.startswith((r.CARNUTES+' ', r.VENETI+' ', r.PICTONES+' '))
                   and ('W:' in line or 'A:' in line)]
    return {'pending_id': pending['id'], 'request': decode(pending['request']),
            'survivors': survivors, 'displayed': displayed,
            'available_arverni_warbands': board['available'][r.ARVERNI][r.WARBAND],
            'snapshot_controls': {region: snap['controls'][region] for region in context['sources']},
            'rendered_region_rows': region_rows,
            'active_force_line': next(line.strip() for line in rendered.splitlines() if 'Morbihan: Arverni' in line),
            'display_did_not_mutate_pending': True}, rendered


def morbihan_case(slingers, directory):
    state = morbihan_fixture(slingers)
    before = fingerprint(board_copy(state))
    baseline = copy.deepcopy(state)
    baseline['decision_agent'] = lambda board, faction, request: (
        {'region': r.CARNUTES} if request['kind'] == 'slingers_region' else None)
    expected = event(baseline, 'A20', r.GERMANS, shaded=True)
    check(baseline)
    session = SeatSession(state, {'seat': r.ROMANS, 'scenario': state['scenario'], 'seed': 7},
                          [], HumanTurnDisplay(io.StringIO()))
    for _ in range(20):
        assert advance(session) is None
        assert fingerprint(board_copy(state)) == before
        request = decode(session.data['pending']['request'])
        if request['kind'] == 'loss_order':
            break
        answer(session)
    else:
        raise AssertionError('No Roman casualty prompt')
    pending = copy.deepcopy(session.data['pending'])
    detail, rendered = pending_details(pending)
    actual_count = 3 if slingers else 4
    assert sum(detail['survivors'].values()) == actual_count
    assert detail['displayed'] == detail['survivors']
    assert detail['available_arverni_warbands'] == 35-actual_count
    assert any(line.startswith('Carnutes      Rom') and 'A:2' in line for line in detail['rendered_region_rows'])
    name = 'morbihan-slingers' if slingers else 'morbihan-no-slingers'
    save_text(name+'-pending-board.txt', rendered)
    path = directory / (name+'-pending.json')
    save_game(state, path, meta=session.meta, log=session.log)
    resumed_state, meta, log = load_game(path, validate=True)
    resumed = SeatSession(resumed_state, meta, log, HumanTurnDisplay(io.StringIO()))
    restored_detail, restored_rendered = pending_details(resumed.data['pending'])
    assert restored_detail == detail and restored_rendered == rendered
    # Re-enter the pending checkpoint after load: both accepted Slingers choice
    # and the outstanding casualty prompt must repeat at the same board/RNG.
    assert advance(resumed) is None
    assert resumed.data['pending'] == pending
    result = None
    for _ in range(20):
        answer(resumed)
        result = advance(resumed)
        if result is not None:
            break
    assert result == expected
    assert fingerprint(board_copy(resumed_state)) == fingerprint(board_copy(baseline))
    assert '_morbihan_projection' not in resumed_state
    final_count = sum(count_pieces(resumed_state, region, r.ARVERNI, r.WARBAND)
                      for region in (r.VENETI,r.PICTONES))
    assert final_count == actual_count
    detail.update({'case': name, 'pre_pause_rollback': True,
                   'saved_pending_display_reproduced': True, 'accepted_journal_replayed': True,
                   'final_matches_uninterrupted': True, 'final_arverni_warbands': final_count,
                   'final_hash': fingerprint(board_copy(resumed_state)),
                   'result': result, 'checks': check(resumed_state)})
    return detail


with tempfile.TemporaryDirectory() as temporary:
    directory = OUT or Path(temporary)
    result = {'UI9-01': enlist_cases(),
              'UI9-02': [morbihan_case(True,directory), morbihan_case(False,directory)]}
print(json.dumps(result, sort_keys=True, indent=2))
