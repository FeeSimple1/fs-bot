# Third comparison repair Batch 2 evidence

The accepted final working tree is over 8b7227054fe520e05f74646a622296140e3d0f70.
Its Python-source SHA-256 is e0c0f1e5dd86bf95978cb6f3226c82d5e46859fb006424b7374f8137aa515f24.
Root source.json, pytest.xml, verification.json, bots/, fuzz0.json, fuzz987.json,
balance.json and seasonal-cause.json describe that exact source. The full suite
passes 9,522 tests. The reviewed 100-game balance check passes at the existing
15-point band; the seed set remains 1–20 in all five scenarios.

There are 49 added cases and one corrected legacy expectation. Copy the four
accepted-tests modules into the corresponding fs_bot/tests paths to rerun on
this revision. parent-regressions.xml/log runs the 50 changed cases on clean
parent 8b72270: 28 fail and 22 positive controls pass. Tests run outside the
parent package so pytest cannot resolve the repaired fs_bot package by accident.
Earlier regressions-against-parent.log used the wrong package resolution and
is superseded by parent-regressions.xml. The other preliminary parent logs
retain their narrower scope.

Twenty bot games use seeds 21–24 in all five scenarios, legacy edition. Inspect
every completion, legality, structural, ranking and source field. Mixed-player
runs use the same cases under hash seeds 0 and 987 with reactions, Events and
internal replay enabled. Their JSON outputs match exactly, with zero hard
findings and four soft partial plans per hash. Eighty executions include those
internal replay repeats.

The accepted parent game records are copied from the preceding batch archive;
their 42da33aca92ecd23c750e2ea17e29f3f71d50c66e2e50db03a0f325966c12069
Python-source digest exactly matches clean parent 8b72270. The fresh parent
regression checkout has that same digest.

check_seasonal_cause.py restores only parent Harvest/Senate function definitions
in a separate process, leaving repaired Scout/Battle behavior active. It records
the exact restored function names and file hashes. All 100 counterfactual winners
and lengths match the parent. The initial old-baseline failure is preserved in
candidate1 and candidate2. stored-baseline-before.json is unchanged, and
reviewed-baseline.json records exactly the accepted corrected 100 outcomes.

To rerun from the repaired checkout, use the tool commands in SELFPLAY_PLAYBOOK.md
with seeds 21–24 for bots/mixed play and seeds 1–20 for balance. For the causal
check, provide a clean 8b72270 checkout as its first argument and an output JSON
path beside the extracted parent/ directory as its second. run_balance.py merely
records the official balance runner's results. verify_results.py validates the
accepted records and full XML, and expects this extracted layout.

Candidate directories and investigation logs retain interrupted or superseded
runs, the preservation of Bellovaci partial execution, and the obsolete legacy
Lost Eagle assertion. Only the accepted root results supply final claims.
