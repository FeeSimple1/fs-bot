# Eleventh comparison repair Batch 3 evidence

The published Batch 2 parent is `fbd3126290df2794593847c9a4f4e30a6dfe97d3`.
Some repair logs record the equivalent local parent commit
`5c7171a123571ea036351d7651ba0c51203b1591`. Both point to tree
`5c47a0f9e1849dc8398333dccd8e15560b87df76`. The repaired Python source SHA-256
is `c22251669bf85ddc8726ffeb16b94f373be09abae5f10af6ae80ee41f02746c0`.
The archive verifier reads the parent game and protected-source records from
the committed Batch 2 evidence. `SHA256SUMS` covers the other archive entries.

## Run the comparisons

Use Python 3.12.14 with pytest and pytest-xdist. From the repaired checkout,
set `EVIDENCE` to the extracted archive, `PARENT` to a clean checkout of the
published Batch 2 parent, and `OUT` to an empty absolute output directory.

```bash
PYTHONHASHSEED=0 python "$EVIDENCE/probe_lifecycle.py" --repo "$PARENT"
PYTHONHASHSEED=0 python "$EVIDENCE/probe_lifecycle.py" --repo . --repaired
PYTHONHASHSEED=987 python "$EVIDENCE/probe_lifecycle.py" --repo . --repaired
PYTHONHASHSEED=0 python "$EVIDENCE/trace_interlude.py" --repo "$PARENT"
PYTHONHASHSEED=0 python "$EVIDENCE/trace_interlude.py" --repo .
PYTHONHASHSEED=987 python "$EVIDENCE/trace_interlude.py" --repo .
PYTHONHASHSEED=0 python "$EVIDENCE/review_saved_interlude.py" --repo "$PARENT"
PYTHONHASHSEED=0 python "$EVIDENCE/review_saved_interlude.py" --repo .
PYTHONHASHSEED=987 python "$EVIDENCE/review_saved_interlude.py" --repo .
PYTHONHASHSEED=0 python -m pytest -q -n 6 -o "cache_dir=$OUT/.pytest_cache" --junitxml="$OUT/full.xml"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out "$OUT/legacy"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 57-60 --card-edition second-edition --workers 2 --out "$OUT/second-edition"
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 57-60 --card-edition second-edition --out "$OUT/fuzz0.json"
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 57-60 --card-edition second-edition --out "$OUT/fuzz987.json"
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20 --baseline "$PARENT/fs_bot/tools/balance_baseline.json"
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
PYTHONPATH=. python "$EVIDENCE/verify_results.py"
```

To reproduce the directed parent failures, run the archived
`test_interlude_arverni_choices.py` against the parent checkout's import path
with `-k 'randomizes_arverni_reductions or early_ally_exception or exact_early_allies'`.
Three new regression cases fail and the two priority controls pass. The two
sets of 233 focused tests in the repair use `fs_bot/tests/test_interlude*.py`,
`fs_bot/tests/test_fourth_comparison_interlude.py` and
`fs_bot/tests/test_fifth_comparison_interlude.py` at hash seeds 0 and 987.

`full-initial.xml` records the two pre-review failures. `full.xml` records the
full rerun with the reviewed balance and fixture expectations.
`trace_interlude.py` records the adjustment boundary in the ten changed game
records while dispatching the original engine call. The public lifecycle
probe and game matrices execute without instrumentation.
