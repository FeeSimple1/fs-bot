"""Repeat the lifecycle witnesses and inspect the Winter draw boundary independently.

Run from fs-bot with PYTHONPATH=. PYTHONDONTWRITEBYTECODE=1 and a specified
PYTHONHASHSEED. Outputs stay in this validation lane.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent / 'fs-bot'
sys.path.insert(0, str(ROOT))
from fs_bot.engine.game_engine import next_winter_is_final, _count_winter_cards_in_game, draw_card
from fs_bot.rules_consts import WINTER_CARD
from fs_bot.tools.validation_metadata import source_identity

out = HERE / 'lifecycle-review-evidence'
out.mkdir(exist_ok=True)
script = HERE.parent / 'lifecycle/witness_lifecycle.py'
spec = importlib.util.spec_from_file_location('lifecycle_witness_review', script)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
m.HERE = out
result = {'source': source_identity(),
          'witness_sha256': hashlib.sha256(script.read_bytes()).hexdigest(),
          'LC8-01': m.final_winter_cases(), 'LC8-02': m.solo_victory_cases()}
(out / f'hash{os.environ["PYTHONHASHSEED"]}.json').write_text(json.dumps(result, indent=2) + '\n')

# A prediction and resolution of the same physical Winter disagree solely
# because draw_card transfers it from the remaining to the played pile.
s = m.interlude_board()
m.cursor_at_winter(s, 3)
while s['deck'][0] != WINTER_CARD:
    draw_card(s)
s['winter_count'] = 6
before = {'winter_count': s['winter_count'],
          'played_winters': s['played_cards'].count(WINTER_CARD),
          'deck_winters': s['deck'].count(WINTER_CARD),
          'computed_total': _count_winter_cards_in_game(s),
          'next_winter_is_final': next_winter_is_final(s), 'integrity': m.clean(s)}
draw_card(s)
after = {'winter_count': s['winter_count'],
         'played_winters': s['played_cards'].count(WINTER_CARD),
         'deck_winters': s['deck'].count(WINTER_CARD),
         'computed_total': _count_winter_cards_in_game(s),
         'current_winter_is_final_formula': s['winter_count'] + 1 >= _count_winter_cards_in_game(s),
         'integrity': m.clean(s)}
assert before['next_winter_is_final'] is False and after['current_winter_is_final_formula'] is True
trace = {'before_drawing_fourth_second_half_winter': before,
         'after_drawing_same_winter_without_resolving_anything': after}
(out / 'draw-boundary.json').write_text(json.dumps(trace, indent=2) + '\n')
print(json.dumps({'hash_seed': os.environ['PYTHONHASHSEED'], 'primary_case_records': 9,
                  'save_load_repeats': 2, 'draw_boundary': trace}, indent=2))
