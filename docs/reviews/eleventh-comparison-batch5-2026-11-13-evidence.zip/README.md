# Verification for eleventh comparison Batch 5

Tests used Python 3.12.14, parent `2e7fe17af7aa1a18e29ea69a90b886887c2fe331`
and repaired Python source SHA-256
`7cb64407ff5594eb2bbd671a8159c408410fa8cc26e7a784da7afe0fd47363db`.
The matrix metadata names the parent and marks the tested repair as dirty.
The source digest identifies the tested bytes.

`first-differences.json` records the first changed card for each changed
winner. Each case includes the common entry-state digest, both exit-state
digests and the relevant plans or execution results. The instrumented
replays agree with the original audited matrix on winner, card count and
final state digest. The two earlier exploratory runs are recorded in the
initial diagnostic logs. The accepted balance check uses the repaired
source and its independently checked baseline.

## Reproduce the witnesses

Extract this archive outside the checkout. Set `FS_REPO` to the absolute
path of the Batch 5 checkout and set `FS_PARENT` to an absolute path for
a detached parent worktree. Run these commands from the extracted folder.

```sh
sha256sum -c SHA256SUMS
git -C "$FS_REPO" worktree add --detach "$FS_PARENT" 2e7fe17af7aa1a18e29ea69a90b886887c2fe331
PYTHONPATH="$FS_REPO" python verify_results.py
PYTHONHASHSEED=0 python probe_bots.py --repo "$FS_PARENT" > rerun-parent-witness.json
PYTHONHASHSEED=0 python probe_bots.py --repo "$FS_REPO" --repaired > rerun-repair-witness.json
cmp parent-witness.json rerun-parent-witness.json
cmp final-repair-witness0.json rerun-repair-witness.json
```

## Reproduce the traced games

```sh
PYTHONHASHSEED=0 python trace_batch.py --repo "$FS_PARENT" --cases trace-cases.json --out parent-trace.jsonl
PYTHONHASHSEED=0 python trace_batch.py --repo "$FS_REPO" --cases trace-cases.json --out repair-trace.jsonl
python compare_traces.py \
  --parent-archive "$FS_REPO/docs/reviews/eleventh-comparison-batch4-2026-11-13-evidence.zip" \
  --parent-trace parent-trace.jsonl --repair-trace repair-trace.jsonl > rerun-first-differences.json
cmp first-differences.json rerun-first-differences.json
```

## Reproduce the broader checks

From the repaired checkout, after installing development requirements, run
the following. Use a separate output directory for each attempt.

```sh
PYTHONHASHSEED=0 python -m pytest -q
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 3 --out /tmp/batch5-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 57-60 --card-edition second-edition --workers 2 --out /tmp/batch5-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 57-60 --card-edition second-edition --out /tmp/batch5-fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 57-60 --card-edition second-edition --out /tmp/batch5-fuzz987.json
cmp /tmp/batch5-fuzz0.json /tmp/batch5-fuzz987.json
python -m fs_bot.tools.balance_smoke --seeds 1-20
python -m fs_bot.tools.balance_smoke --seeds 1-3 --band 0.40
```
