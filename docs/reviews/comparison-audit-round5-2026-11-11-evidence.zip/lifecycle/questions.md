# Uncounted source question draft

## Q-OPTIMATES-PAX-PHASE-COUNT — whether Pax's skipped Victory Phase counts for Optimates

The audit checked Card20's earliest possible ending during Pax Gallica. Card Reference20, lines193–196, says: “Upon the game’s 2nd and each later Victory Phase” apply its ending if Roman victory exceeds12. The Pax Gallica setup, lines30–34, says: “Skip that Victory Phase (the game continues)” during the first Winter Round.

The implementation checks winter_count>=2 (fs_bot/engine/winter.py:187–193). That counts the first Winter even though its Victory Phase is skipped. The portable probe uses ordinary Pax setup plus legal physical Alliances to give Roman score13 with no qualified victor, executes Card20 through the production Event path, and resolves the first Winter, whose result explicitly reports the skipped Victory Phase. On the second Winter the engine removes all8 remaining on-map Legions and ends the game through Optimates. A diagnostic clone with only the Event flag disabled continues the same Winter and finishes with12 on-map Legions. Census and structural checks are clean throughout.

Two readings remain possible. Count scheduled Victory Phase positions, including a position that the scenario instructs players to skip, so the second Winter qualifies as the second phase and current behavior is correct. Or count only actually conducted Victory Phases, so the second Pax Winter is the first and Optimates cannot trigger until the third Winter. The supplied wording does not explicitly resolve whether a skipped phase retains its ordinal position. No adopted project ruling covers it.

This is an observed behavior with unresolved interpretation, not a confirmed bug. No code or expectations should change until clarification or an expressly adopted ruling chooses the counting convention. Separate consideration would be needed for whether first-half Victory Phases count after the Gallic War Interlude; that game remains a single extended scenario, so a local reset should not be inferred from the Pax case.
