"""Tests for the self-play heuristic agent and the balance guardrail."""
import subprocess
import sys
from pathlib import Path

import pytest

import fs_bot.rules_consts as rc
from fs_bot.agents.heuristic import PROFILES
from fs_bot.tools.heuristic_selfplay import play_game

_BASELINE = Path(__file__).resolve().parents[1] / "tools" / "balance_baseline.json"


def test_every_profile_finishes_a_game():
    """Each real profile occupies a human seat in an appropriate scenario."""
    from fs_bot.tools.heuristic_selfplay import _make
    for name, prof in PROFILES.items():
        fac, planner = _make(name, 1)
        scenario = (rc.SCENARIO_ARIOVISTUS if fac == rc.GERMANS
                    else rc.SCENARIO_GREAT_REVOLT)
        r = play_game(scenario, seed=1, agent_faction=fac, planner=planner)
        assert r["winner"] is not None, f"{name} produced no winner"
        assert r["cards"] >= 1
        assert r["decisions"] > 0
        assert r["completed"], (name, r)


def test_random_plan_policy_finishes():
    from fs_bot.agents.heuristic import RandomPlanPolicy
    pol = RandomPlanPolicy(rc.ROMANS, seed=3)
    r = play_game(rc.SCENARIO_PAX_GALLICA, seed=3,
                  agent_faction=rc.ROMANS, planner=pol.plan_turn)
    assert r["winner"] is not None


@pytest.mark.skipif(not _BASELINE.exists(), reason="no balance baseline")
def test_bot_balance_canary():
    """Fixed-seed bot-only games must match the committed baseline. If an
    intended change moves outcomes, refresh:
    python -m fs_bot.tools.balance_smoke --update"""
    proc = subprocess.run(
        [sys.executable, "-m", "fs_bot.tools.balance_smoke",
         "--seeds", "1-3", "--band", "0.40"],
        capture_output=True, text=True, timeout=300,
        cwd=str(Path(__file__).resolve().parents[2]),
    )
    assert proc.returncode == 0, (
        "Bot balance drifted from baseline. If intended, run "
        "'python -m fs_bot.tools.balance_smoke --update' and commit it.\n\n"
        + proc.stdout[-2000:] + proc.stderr[-400:]
    )


def test_np_roman_quarters_relocation_and_pay_plan():
    """Q12: NP Roman Winter Quarters follows §6.3.3/§8.8.7 — Legions in
    Supply-Line Regions relocate to Provincia and the pay plan covers the
    rest in priority order, instead of the old roll-for-all default."""
    from fs_bot.bots.roman_bot import build_np_winter_relocations
    from fs_bot.state.setup import setup_scenario

    st = setup_scenario(rc.SCENARIO_GREAT_REVOLT, seed=1)
    st["non_player_factions"] = {rc.ROMANS, rc.ARVERNI, rc.AEDUI, rc.BELGAE}

    relo = build_np_winter_relocations(st)
    moves_list = relo[rc.ROMANS]
    quartering = relo[rc.ROMANS + "_quartering"]

    # Some Legions must be relocating toward Provincia at Great Revolt start
    # (8 Legions sit in Mandubii with a Supply Line available).
    legion_moves = [m for m in moves_list if m[0] == rc.LEGION]
    assert legion_moves, "expected Legion relocations in the §6.3.3 plan"
    assert any(m[2] == rc.PROVINCIA for m in moves_list), \
        "expected at least one move into Provincia"
    # Pay order is present and well-formed.
    assert "_pay_order" in quartering
    for r in quartering["_pay_order"]:
        assert quartering[r]["pay"] >= 1


def test_np_roman_quarters_changes_winter_outcome():
    """End-to-end: with the wiring, far fewer Legions bleed off-map in a
    Great Revolt bot game than the historical roll-all behavior (which
    ended games with ~12 off-map Legions)."""
    from fs_bot.tools.heuristic_selfplay import play_game
    import fs_bot.engine.victory as V

    # Play a full bot game and inspect final off-map Legions via baseline
    # tool path (winner recorded in the balance baseline as deterministic).
    r = play_game(rc.SCENARIO_GREAT_REVOLT, seed=2)
    assert r["winner"] in (rc.ARVERNI, rc.AEDUI, rc.BELGAE, rc.ROMANS)


def test_ae_deep_profile_finishes_and_suborn_remove_carries_tribe():
    """AE-DEEP completes games; its Suborn remove_ally ops carry the tribe so
    the executor can keep state["tribes"] in sync (Q13)."""
    from fs_bot.agents.heuristic import (PROFILES, build_suborn_plan,
                                         _allied_tribes_in_region)
    from fs_bot.state.setup import setup_scenario

    prof = PROFILES["AE-DEEP"]
    r = play_game(rc.SCENARIO_RECONQUEST, seed=3,
                  agent_faction=rc.AEDUI, planner=prof["planner"])
    assert r["winner"] is not None

    st = setup_scenario(rc.SCENARIO_RECONQUEST, seed=1)
    st["non_player_factions"] = {rc.ROMANS, rc.ARVERNI, rc.AEDUI, rc.BELGAE}
    plan = build_suborn_plan(st, 20)
    if plan:
        for a in plan[1]:
            if a["action"] == "remove_ally":
                assert a.get("tribe"), "remove_ally must carry its tribe"


def test_error_census_severity_classification():
    """The census must separate genuine illegal-move defects from the
    flowchart legally declining, so the headline reflects real bugs."""
    from fs_bot.tools.error_census import _severity

    # Executor rejections of an illegal proposal -> illegal.
    assert _severity("command-error", "{'error': 'No Roman Allies Available'}") \
        == "illegal"
    assert _severity("sa-error", "{'error': 'Only N * Ally in *, need N'}") \
        == "illegal"

    # An SA attached but with no effect -> wasteful (play quality, not a defect).
    assert _severity("sa-no-effect", "no effect") == "wasteful-sa"

    # Flowchart IF-NONE fall-throughs and "no legal effect" -> legal-decline.
    assert _severity(
        "command-refused",
        "expand/mass march: nothing marchable (leader/warbands pinned ...)"
    ) == "legal-decline"
    assert _severity("sa-skipped", "command produced no legal effect") \
        == "legal-decline"
    assert _severity("command-refused", "command produced no legal effect") \
        == "legal-decline"

    # An Event that did nothing -> ineffective-event (play quality).
    assert _severity(
        "command-refused", "event not applicable: CommandError('*')"
    ) == "ineffective-event"


def test_structural_integrity_checker_flags_corruption():
    """The structural checker must catch the silent-corruption classes that
    validate_state (pool conservation) cannot: 2 Citadels in a Region, a Tribe
    allegiance with no backing piece, a stale Control flag, negative Resources.
    """
    from fs_bot.state.setup import setup_scenario
    from fs_bot.state.state_schema import check_structural_integrity
    st = setup_scenario(rc.SCENARIO_PAX_GALLICA, seed=1)
    assert check_structural_integrity(st) == []  # clean at setup
    st["spaces"]["Mandubii"]["pieces"].setdefault("Arverni", {})["Citadel"] = 2
    st["spaces"]["Bituriges"]["pieces"].setdefault("Romans", {})["Fort"] = 2
    st["tribes"]["Morini"]["allied_faction"] = "Aedui"  # no backing piece
    st["spaces"]["Carnutes"]["control"] = "Roman Control"  # stale
    st["resources"]["Belgae"] = -3
    errs = check_structural_integrity(st)
    joined = " | ".join(errs)
    assert "2 Citadels" in joined
    assert "2 Forts" in joined
    assert "Morini/Aedui" in joined
    assert "stale" in joined
    assert "Belgae Resources negative" in joined


def test_self_play_maintains_structural_integrity():
    """Regression guard for the silent-corruption class (e.g. the Citadel
    over-placement): every bot-only game must keep the board structurally
    sound (one Citadel/Region, Tribe<->piece allegiance sync, fresh Control
    flags, non-negative pools) at every turn boundary."""
    scenarios = (rc.SCENARIO_PAX_GALLICA, rc.SCENARIO_GREAT_REVOLT,
                 rc.SCENARIO_RECONQUEST, rc.SCENARIO_ARIOVISTUS,
                 rc.SCENARIO_GALLIC_WAR)
    for scenario in scenarios:
        for seed in (1, 2):
            result = play_game(scenario, seed)
            assert result["completed"], (scenario, seed, result)
            assert result["integrity_findings"] == []
