"""Confirmed third-audit witnesses. Assertions freeze defects, not correct rules.

Run with PYTHONPATH pointing to the audited Falling Sky checkout.
"""
import copy
import json

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_allied_discs, count_on_map
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.winter import harvest_phase, senate_phase
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import validate_state, check_structural_integrity
from fs_bot.tools.validation_metadata import source_identity


def integrity(state):
    errors = validate_state(state) + check_structural_integrity(state)
    assert not errors, errors
    return errors


def event(state, card, shaded=False, params=None):
    # Select the actual current Event; no off-card execution bypass.
    state['current_card'] = card
    decision = {'action': 'event', 'player_action': {
        'command': 'Event', 'regions': [], 'sa': 'No SA', 'sa_regions': [],
        'details': {'card_id': card,
                    'text_preference': rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,
                    'event_params': params or {}}}}
    result = execute_decision(state, rc.ROMANS, decision)
    assert result['executed'], result
    integrity(state)
    return result


def harvest_witness():
    records = []
    for scenario in rc.ALL_SCENARIOS:
        state = setup_scenario(scenario, seed=1)
        integrity(state)
        before = copy.deepcopy(state['resources'])
        counts = {f: {'ally_discs': count_allied_discs(state, f),
                      'citadels': count_on_map(state, f, rc.CITADEL)}
                  for f in rc.GALLIC_FACTIONS
                  if not (scenario in rc.ARIOVISTUS_SCENARIOS and f == rc.ARVERNI)}
        expected = {f: 2 * (v['ally_discs'] + v['citadels']) +
                       (4 if f == rc.AEDUI else 0) for f, v in counts.items()}
        result = harvest_phase(state)
        integrity(state)
        observed = {f: result[f] for f in counts}
        # Existing no-Citadel setups are useful negative controls.
        assert all(observed[f] - expected[f] == 2 * counts[f]['citadels']
                   for f in counts)
        records.append({'scenario': scenario, 'counts': counts,
                        'expected_earnings': expected, 'actual_earnings': observed,
                        'before_resources': before,
                        'after_resources': state['resources'], 'integrity_errors': []})
    return records


def lost_eagle_witness():
    records = []
    for card, params in [(1, {'senate_direction': rc.SENATE_DOWN}), (3, {})]:
        normal = setup_scenario(rc.SCENARIO_RECONQUEST, seed=1)
        blocked = copy.deepcopy(normal)
        event(blocked, 33, shaded=True)
        start = copy.deepcopy(blocked['senate'])
        event(normal, card, params=params)
        result = event(blocked, card, params=params)
        assert normal['senate'] != start
        assert blocked['senate'] == start
        records.append({'case': f'33S_then_{card}U', 'before': start,
                        'expected': normal['senate'], 'actual': blocked['senate'],
                        'executed': result['executed'], 'integrity_errors': []})

    # The Pax first Winter explicitly sets Intrigue instead of shifting.
    # Observe the marker after that Senate, then the next actual Senate.
    state = setup_scenario(rc.SCENARIO_PAX_GALLICA, seed=1)
    event(state, 33, shaded=True)
    first = senate_phase(state, force_position=rc.INTRIGUE)
    survived = state['event_modifiers'].get('lost_eagle_no_shift_down')
    assert survived is True
    control = copy.deepcopy(state)
    control['event_modifiers'].pop('lost_eagle_no_shift_down')
    second = senate_phase(state)
    legal_second = senate_phase(control)
    integrity(state)
    integrity(control)
    assert state['senate']['position'] == rc.INTRIGUE
    assert control['senate']['position'] == rc.ADULATION
    records.append({'case': 'first_Pax_Senate_does_not_expire_marker',
                    'first_senate': first, 'flag_after_first': survived,
                    'second_senate': second, 'expected_second_senate': legal_second,
                    'actual_position': state['senate'], 'expected_position': control['senate'],
                    'integrity_errors': []})
    return records


if __name__ == '__main__':
    print(json.dumps({'source': source_identity(), 'WS3-01': harvest_witness(),
                      'BE3-LE': lost_eagle_witness()}, indent=2))
