"""Verify the paired LC11-01 evidence against the repaired checkout."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
from xml.etree import ElementTree
from zipfile import ZipFile

from fs_bot import rules_consts as rc
from fs_bot.tools.error_census import _severity
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


ROOT = Path(__file__).resolve().parent
REPO = Path(rc.__file__).resolve().parents[1]
REPAIRED = 'c22251669bf85ddc8726ffeb16b94f373be09abae5f10af6ae80ee41f02746c0'
PARENT = '4bb6812831b996cdb8941c6684650ff1e6661e5db0963bd1733f802188711a31'
LOCAL_PARENT = '5c7171a123571ea036351d7651ba0c51203b1591'
PUBLISHED_PARENT = 'fbd3126290df2794593847c9a4f4e30a6dfe97d3'
SEEDS = {'legacy': list(range(1, 21)), 'second-edition': list(range(57, 61))}


def load(name):
    return json.loads((ROOT / name).read_bytes())


def verify_tests():
    expected = {
        'parent-directed': (5, 3), 'directed0': (233, 0), 'directed987': (233, 0),
        'full-initial': (10426, 2), 'full': (10426, 0), 'compatibility-and-canary': (42, 0),
    }
    for name, (tests, failures) in expected.items():
        suite, = ElementTree.parse(ROOT / f'{name}.xml').iter('testsuite')
        assert (int(suite.get('tests')), int(suite.get('failures'))) == (tests, failures), name
        assert int(suite.get('errors')) == int(suite.get('skipped')) == 0, name
    return {name: {'tests': tests, 'failures': failures}
            for name, (tests, failures) in expected.items()}


def verify_witnesses():
    assert (ROOT / 'audit-lifecycle-results.json').read_bytes() == (ROOT / 'parent-witness.json').read_bytes()
    assert (ROOT / 'repair-witness0.json').read_bytes() == (ROOT / 'repair-witness987.json').read_bytes()
    before, after = load('parent-witness.json'), load('repair-witness0.json')
    assert before['case_count'] == after['case_count'] == 54
    for key in ('ordinary_region_random_controls', 'ordinary_regions_removed_distribution',
                'specified_arverni_last_controls', 'human_legal_removal_controls'):
        assert after[key] == before[key], key
    picked = {}
    for region in (rc.CARNUTES, rc.PICTONES, rc.VENETI):
        rows = after['protected_expansion_homes'][region]
        picked[region] = Counter(next(space for space, count in row['after']['warbands'].items()
                                      if count == 0) for row in rows)
        assert picked[region] == {region: 7, rc.SEQUANI: 5}
        assert all(row['before']['census_errors'] == row['after']['census_errors'] == []
                   and row['before']['structure_errors'] == row['after']['structure_errors'] == []
                   for row in rows)
    return picked


def audited_games(edition, read, expected_source):
    meta = json.loads(read(f'{edition}/metadata.json'))
    rows = [json.loads(line) for line in read(f'{edition}/games.jsonl').splitlines()]
    games = {(row['scenario'], row['seed']): row for row in rows}
    assert meta['source_sha256'] == expected_source and meta['card_edition'] == edition
    assert meta['hash_seed'] == 0 and meta['all_factions_bots'] and meta['seeds'] == SEEDS[edition]
    assert len(rows) == len(games)
    assert games.keys() == {(scenario, seed) for scenario in SCENARIOS for seed in SEEDS[edition]}
    for row in rows:
        assert row['source_sha256'] == expected_source and row['card_edition'] == edition
        assert row['completed'] and row['game_completed'] and row['audit_completed']
        assert len(row['final_state_sha256']) == 64
        assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row), row
        for d in row['diagnostic_occurrences']:
            assert d['severity'] == _severity(d['kind'], d['message']) == 'legal-decline'
    return games


def verify_games(archive):
    changes, counts = {}, {}
    for edition in SEEDS:
        before = audited_games(edition, archive.read, PARENT)
        after = audited_games(edition, lambda path: (ROOT / path).read_bytes(), REPAIRED)
        skip = {'commit', 'source_sha256', 'seconds'}
        for key, old in before.items():
            new = after[key]
            assert old['interlude_completed'] == new['interlude_completed']
            if {k: v for k, v in old.items() if k not in skip} == {
                    k: v for k, v in new.items() if k not in skip}:
                continue
            assert key[0] == rc.SCENARIO_GALLIC_WAR and new['interlude_completed'], key
            assert new['final_state_sha256'] != old['final_state_sha256']
            changes[(edition, key[1], False)] = (old, new)
        counts[edition] = {
            'games': len(after), 'interludes': sum(row['interlude_completed'] for row in after.values()),
            'legal_declines': sum(len(row['diagnostic_occurrences']) for row in after.values()),
        }
    assert set(changes) == {('legacy', seed, False) for seed in (1, 2, 3, 5, 6, 12, 17, 20)} | {
        ('second-edition', 58, False)}
    return changes, counts


def verify_mixed(archive):
    for ext in ('json', 'log'):
        assert (ROOT / f'fuzz0.{ext}').read_bytes() == (ROOT / f'fuzz987.{ext}').read_bytes()
    before, after = json.loads(archive.read('fuzz0.json')), load('fuzz0.json')
    assert before['metadata']['source_sha256'] == PARENT
    assert after['metadata']['source_sha256'] == REPAIRED
    assert after['metadata']['seeds'] == SEEDS['second-edition']
    assert after['metadata']['card_edition'] == 'second-edition'
    assert all(after['metadata'][flag] for flag in ('events', 'reactive', 'replay'))
    cases = {(row['scenario'], row['seed']) for row in after['records']}
    assert cases == {(scenario, seed) for scenario in SCENARIOS for seed in SEEDS['second-edition']}
    assert after['games'] == len(after['records']) == 20 and after['hard_findings'] == 0
    assert after['partial'] == 4 and all(row['game_completed'] and not row['findings']
                                         for row in after['records'])
    changes = {}
    for old, new in zip(before['records'], after['records'], strict=True):
        assert (old['scenario'], old['seed']) == (new['scenario'], new['seed'])
        if old != new:
            assert new['scenario'] == rc.SCENARIO_GALLIC_WAR and new['ending_scenario'] == rc.SCENARIO_PAX_GALLICA
            assert rc.GERMANS not in new['seats'] and new['digest'] != old['digest']
            changes[('second-edition', new['seed'], True)] = (old, new)
    assert set(changes) == {('second-edition', 59, True)}
    return changes, {k: v for k, v in after.items() if k not in ('metadata', 'records')}


def verify_traces(changes):
    assert (ROOT / 'trace-repair.json').read_bytes() == (ROOT / 'trace-repair-hash987.json').read_bytes()
    trace_changes = set()
    for before, after in zip(load('trace-parent.json'), load('trace-repair.json'), strict=True):
        key = (before['edition'], before['seed'], before['mixed'])
        assert key == (after['edition'], after['seed'], after['mixed']) and key not in trace_changes
        assert before['before'] == after['before'] and before['adjustment'] == after['adjustment']
        assert before['after']['board'] != after['after']['board']
        rng_only = key == ('legacy', 5, False)
        assert (before['after']['board_without_rng'] == after['after']['board_without_rng']) == rng_only
        if rng_only:
            assert before['after']['rng'] != after['after']['rng']
        for trace, record in zip((before, after), changes[key], strict=True):
            assert trace['outcome'] == {field: record[field] for field in trace['outcome']}
        trace_changes.add(key)
    assert trace_changes == set(changes)


def verify_balance(archive):
    def checked(log_name):
        log = (ROOT / log_name).read_text()
        rows = re.findall(r'^\[(.+) seed= *(\d+)\] winner=(.+) \((\d+) cards\)$', log, re.M)
        games = {f'{scenario}|{seed}': {'winner': winner, 'cards': int(cards)}
                 for scenario, seed, winner, cards in rows}
        assert len(rows) == len(games) == 100 and 'OK: balance within band' in log
        return games

    old = json.loads(archive.read('balance-baseline.json'))['games']
    current = json.loads((REPO / 'fs_bot/tools/balance_baseline.json').read_bytes())['games']
    assert current == checked('balance.log') == checked('balance-reviewed.log')
    assert old.keys() == current.keys()
    changes = {game: [old[game], current[game]] for game in old if old[game] != current[game]}
    assert set(changes) == {f'{rc.SCENARIO_GALLIC_WAR}|{seed}' for seed in (1, 2, 3, 5, 12, 17)}
    assert sum(a['winner'] != b['winner'] for a, b in changes.values()) == 4
    assert sum(a['cards'] != b['cards'] for a, b in changes.values()) == 4
    return changes


def verify_save():
    assert (ROOT / 'historical-repair0.json').read_bytes() == (ROOT / 'historical-repair987.json').read_bytes()
    before, after = load('historical-parent.json'), load('historical-repair0.json')
    manifest = json.loads((REPO / 'fs_bot/tests/fixtures/compatibility_8ef88e2/manifest.json').read_bytes())
    fixture = manifest['fixtures']['pre-interlude.json']
    assert before['fixture_sha256'] == after['fixture_sha256'] == fixture['file_sha256']
    assert before['generator_sha256'] == after['generator_sha256'] == manifest['generator_sha256']
    assert before['loaded'] == after['loaded']
    assert before['adjustment']['result'] == after['adjustment']['result']
    assert before['adjustment']['rng_before'] == after['adjustment']['rng_before']
    assert before['adjustment']['rng_after'] == after['adjustment']['rng_after']
    assert before['rebuilt_deck_counts'] == after['rebuilt_deck_counts'] and before['next_card'] == after['next_card']
    assert before['final_warbands'][rc.ATREBATES] == 7 and after['final_warbands'][rc.ATREBATES] == 10
    assert before['final_warbands'][rc.MANDUBII] == 3 and after['final_warbands'][rc.MANDUBII] == 0
    assert before['continuation_sha256'] == fixture['continuation_history'][-1]['continued_sha256']
    assert after['continuation_sha256'] == fixture['continued_sha256']
    return [before['continuation_sha256'], after['continuation_sha256']]


def main():
    assert source_identity()['source_sha256'] == REPAIRED
    archive_path = REPO / 'docs/reviews/eleventh-comparison-batch2-2026-11-13-evidence.zip'
    with ZipFile(archive_path) as archive:
        protected = json.loads(archive.read('protected-sources.json'))
        assert set(protected) == {p.relative_to(REPO).as_posix()
                                  for p in (REPO / 'Reference Documents').rglob('*') if p.is_file()} | {
                                      'fs_bot/rules_consts.py'}
        for path, sha in protected.items():
            assert hashlib.sha256((REPO / path).read_bytes()).hexdigest() == sha, path
        games, counts = verify_games(archive)
        mixed, mixed_counts = verify_mixed(archive)
        verify_traces(games | mixed)
        result = dict(source_sha256=REPAIRED, parent_source_sha256=PARENT,
                      local_parent=LOCAL_PARENT, published_parent=PUBLISHED_PARENT,
                      protected_files=len(protected), tests=verify_tests(), witnesses=verify_witnesses(),
                      bot_games=counts, changed_bot_cases=len(games), mixed=mixed_counts,
                      changed_mixed_cases=len(mixed), balance=verify_balance(archive),
                      continuation_sha256=verify_save())
    print(json.dumps(result, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
