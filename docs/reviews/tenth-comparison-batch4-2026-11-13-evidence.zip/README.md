# Tenth comparison repair Batch 4 evidence

`source.json` identifies the tested repair to parent
`4cef37157157c3b3ec04886d3b6713bacd1605cb`. The two parent witnesses are
from rerunning the audit probes on that revision. The parent test
selection exercises the same outcomes with the original APIs.

The legacy save files were created by the parent at hash seeds 0 and 987.
Each repair replay uses the opposite seed. The paired JSON records include
the identical accepted decision and the complete later pending request
and board. The tests also exercise verified replay, a mid-card Battle save,
and mismatches that must still stop replay.

The parent bot and mixed-seat records come from Batch 3 and match the
parent source digest. The mixed comparison removes only the new
`battle_sa` display field from the repaired state and trajectory before
recomputing the parent digest. `SHA256SUMS` covers every other archive
member.

## Reproduce the checks

Use Python 3.12.14 and the development test environment. From the repaired
repository root, set `OUT` to an empty directory, `EVIDENCE` to the
extracted archive and `PARENT` to a clean checkout of the parent commit.

```bash
PYTHONHASHSEED=0 python -m pytest -q fs_bot/tests/test_tenth_comparison_frontends.py fs_bot/tests/test_tenth_comparison_supply_replay.py fs_bot/tests/test_sixth_comparison_free_actions.py
PYTHONHASHSEED=987 python -m pytest -q fs_bot/tests/test_tenth_comparison_frontends.py fs_bot/tests/test_tenth_comparison_supply_replay.py
PYTHONHASHSEED=0 python -m pytest -q -n 4 --junitxml="$OUT/full.xml"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out "$OUT/legacy"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 53-56 --card-edition second-edition --workers 2 --out "$OUT/second-edition"
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 53-56 --card-edition second-edition --out "$OUT/fuzz0.json"
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 53-56 --card-edition second-edition --out "$OUT/fuzz987.json"
PYTHONPATH=. PYTHONHASHSEED=0 python "$EVIDENCE/verify_mixed_metadata.py" > "$OUT/mixed-display-compat.json"
PYTHONHASHSEED=987 python -m fs_bot.tests.test_tenth_comparison_supply_replay resume "$EVIDENCE/legacy-save-0.json" 1
PYTHONHASHSEED=0 python -m fs_bot.tests.test_tenth_comparison_supply_replay resume "$EVIDENCE/legacy-save-987.json" 1
PYTHONPATH=. python "$EVIDENCE/verify_results.py"
```

From the parent checkout, run the cases that use the original request and
result formats to reproduce the nine failures and ten passing controls.

```bash
cd "$PARENT"
PYTHONPATH=. PYTHONHASHSEED=0 python -m pytest -q "$EVIDENCE/test_tenth_comparison_frontends.py" "$EVIDENCE/test_tenth_comparison_supply_replay.py" -k 'not old_midcard_save and not legacy_quarters_signature and not verified_legacy'
```
