import json
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces
from fs_bot.state.state_schema import build_initial_state, validate_state
from fs_bot.engine.execute import _resolve_card45_battle
from fs_bot.commands.sa_ambush import validate_ambush_region
s=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=1)
s['non_player_factions']=set(rc.FACTIONS)
place_piece(s,rc.CARNUTES,rc.ROMANS,rc.AUXILIA,10)
place_piece(s,rc.CARNUTES,rc.BELGAE,rc.WARBAND,10)
place_piece(s,rc.CARNUTES,rc.BELGAE,rc.LEADER,leader_name=rc.AMBIORIX)
place_piece(s,rc.MANDUBII,rc.ROMANS,rc.LEGION,from_legions_track=True)
place_piece(s,rc.MANDUBII,rc.BELGAE,rc.WARBAND,2)
ambush=validate_ambush_region(s,rc.MANDUBII,rc.BELGAE,rc.ROMANS)[0]
r=_resolve_card45_battle(s,rc.BELGAE)
print(json.dumps({'expected_region':rc.MANDUBII,'mandubii_ambush_legal':ambush,'observed_region':r[0].get('region'),'remaining_legion':count_pieces(s,rc.MANDUBII,rc.ROMANS,rc.LEGION),'integrity':validate_state(s),'result':r}))
