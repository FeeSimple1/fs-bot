import contextlib,io,json,tempfile
from types import SimpleNamespace
from pathlib import Path
from fs_bot import rules_consts as rc
from fs_bot.tools import llm_seat
from fs_bot.state.serialize import load_game,decode

with tempfile.TemporaryDirectory() as directory:
    args=SimpleNamespace(dir=directory,scenario=rc.SCENARIO_GREAT_REVOLT,seed=46,seat=rc.ROMANS)
    with contextlib.redirect_stdout(io.StringIO()):
        llm_seat.cmd_init(args)
        llm_seat.cmd_play(args)
    path=Path(directory)/'save.json'
    sent=False
    initial=None
    for i in range(30):
        state,meta,log=load_game(path,validate=True)
        pending=meta['assistant_session']['pending']
        assert pending
        request=decode(pending['request'])
        if request['kind']=='turn':
            if sent:
                break
            assert state['current_card']==16
            initial={'current_card':state['current_card'],'id':pending['id'],'request':request,'capabilities':state['capabilities']}
            response={'action':'event','player_action':{'command':'Event','details':{'card_id':13,'text_preference':rc.EVENT_UNSHADED}}}
            sent=True
        else:
            response={'use_default':True}
        with contextlib.redirect_stdout(io.StringIO()):
            code=llm_seat.cmd_submit(SimpleNamespace(dir=directory,decision_id=pending['id'],response=json.dumps(response)))
        assert code==0
    else:
        raise AssertionError('Did not finish accepted off-card Event')
    assert 13 in state['capabilities']
    recorded=next(entry for entry in log if entry.get('action')=='event')
    assert recorded['card']==16 and recorded['player_action']['details']['card_id']==13
    print(json.dumps({'case':'normal_init_play_submit_accepts_other_card','seed':46,'initial':initial,'capabilities_after':state['capabilities'],'recorded_event':recorded},default=str))
