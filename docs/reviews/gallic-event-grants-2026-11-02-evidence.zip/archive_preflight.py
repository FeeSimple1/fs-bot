"""Prepare/verify bounded BE-03 evidence; never run games or edit the repository.

Default: inspect retained evidence and write archive-preflight-plan.json only.
Creating an archive requires root's final freeze, --create, an explicit source
SHA and accepted attempt. Failed/superseded attempts remain labelled evidence.
"""
from collections import Counter
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
import zipfile

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'fs-bot'
PARENT = HERE.parent / 'fs-gallic-grants-before'
PARENT_SHA = 'c3c3cd4fd4370f4367db759106b7418449bcc0c27b34ceae2e93c014c64b3bf4'
SCENARIOS = {'Pax Gallica?', 'Reconquest of Gaul', 'The Great Revolt', 'Ariovistus', 'The Gallic War'}


def read(path):
    return json.loads(path.read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def source(repo):
    digest = hashlib.sha256()
    files = {}
    for path in sorted((repo / 'fs_bot').rglob('*.py')):
        name = path.relative_to(repo).as_posix()
        data = path.read_bytes()
        files[name] = sha(data)
        digest.update(name.encode() + b'\0' + data)
    return {'python_sha256': digest.hexdigest(), 'python_files': len(files), 'files': files}


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def validate_bots(directory, edition, seeds, expected_sha):
    data = rows(directory / 'games.jsonl')
    metadata = read(directory / 'metadata.json')
    expected = {(scenario, seed) for scenario in SCENARIOS for seed in seeds}
    assert len(data) == len(expected) and {(r['scenario'], r['seed']) for r in data} == expected
    assert metadata['source_sha256'] == expected_sha and metadata['card_edition'] == edition
    for r in data:
        assert r['source_sha256'] == expected_sha and r['commit'] == metadata['commit']
        assert r['card_edition'] == edition
        assert all(isinstance(r[k], bool) for k in ('completed', 'game_completed', 'audit_completed'))
        assert all(isinstance(r[k], list) for k in ('errors', 'integrity_findings', 'diagnostics', 'final_ranking'))
        assert isinstance(r['cards'], int) and isinstance(r['winner'], str)
        assert len(r['final_state_sha256']) == 64
    return data, metadata


def validate_attempt(directory):
    before = read(directory / 'source-manifest-before.json')
    after = read(directory / 'source-manifest-after.json')
    assert before == after, 'frozen source changed during matrix'
    result = read(directory / 'integration-results.json')
    assert result['source']['python_sha256'] == before['python_sha256']
    assert before['python_files'] == len(before['files'])
    commands = read(directory / 'integration-commands.json')
    assert len(commands) == 11 and len({c['name'] for c in commands}) == 11
    counts = {}
    for edition, seeds in [('legacy', range(1, 21)), ('original', range(201, 206)), ('second-edition', range(201, 206))]:
        data, metadata = validate_bots(directory / ('bots-' + edition), edition, seeds, before['python_sha256'])
        assert metadata['python'] == '3.10.22' and metadata['hash_seed'] == 0
        counts[edition] = {'records': len(data), 'engine_completed': sum(r['game_completed'] for r in data),
                           'audit_completed': sum(r['audit_completed'] for r in data)}
        if result['passed']:
            assert all(r['completed'] and r['game_completed'] and r['audit_completed'] and not r['errors'] and not r['integrity_findings'] for r in data)
    validate_bots(directory / 'parent-bots-legacy', 'legacy', range(1, 21), PARENT_SHA)
    mixed = {}
    for edition, seeds in [('legacy', range(1, 41)), ('original', range(201, 203)), ('second-edition', range(201, 203))]:
        both = [read(directory / f'fuzz-{edition}-{seed}.json') for seed in (0, 7)]
        expected = {(scenario, seed) for scenario in SCENARIOS for seed in seeds}
        for data in both:
            assert data['games'] == len(data['records']) == len(expected)
            assert {(r['scenario'], r['seed']) for r in data['records']} == expected
            assert data['metadata']['source_sha256'] == before['python_sha256'] and data['metadata']['replay'] is True
            assert data['metadata']['python'] == '3.10.22' and data['metadata']['card_edition'] == edition
            assert all(isinstance(r['findings'], list) and isinstance(r['game_completed'], bool) for r in data['records'])
        equal = both[0] == both[1]
        stdout_equal = (directory / f'fuzz-{edition}-0.log').read_bytes() == (directory / f'fuzz-{edition}-7.log').read_bytes()
        if result['passed']:
            assert equal and stdout_equal and all(d['hard_findings'] == 0 for d in both)
        mixed[edition] = {'distinct_cases': len(expected), 'executions': 4 * len(expected), 'cross_hash_equal': equal,
                           'stdout_equal': stdout_equal, 'hard_findings_per_hash': [d['hard_findings'] for d in both]}
    census = [read(directory / f'census-{seed}.json') for seed in (0, 7)]
    for data in census:
        assert data['games'] == 10 and data['metadata']['source_sha256'] == before['python_sha256']
        assert data['metadata']['strict'] is True and data['metadata']['python'] == '3.10.22'
    if result['passed']:
        assert census[0] == census[1] and all(d['completed'] == 10 and not d['failures'] for d in census)
        assert all(c['exit_code'] == 0 and c['source_unchanged_after'] and c['protected_unchanged_after'] for c in commands)
    return {'source_sha256': before['python_sha256'], 'matrix_checks_passed': result['passed'],
            'counts_are_separate_not_pooled': True, 'bots': counts, 'mixed': mixed,
            'strict_census_executions': sum(d['games'] for d in census)}


def validate_trace(path, known_sources):
    summary = read(path.with_name(path.name.removesuffix('.jsonl.gz') + '-summary.json'))
    known_source = summary['source']['source_sha256'] in known_sources
    count = 0
    with gzip.open(path, 'rt') as stream:
        for line in stream:
            row = json.loads(line)
            assert row['index'] == count
            for key in ('board', 'rng'):
                assert row[key + '_sha256'] == sha(json.dumps(row[key], sort_keys=True, separators=(',', ':')).encode())
            assert isinstance(row['stage'], str)
            count += 1
    assert count == summary['checkpoints'], 'truncated or mismatched trace'
    return {'checkpoints': count, 'source_sha256': summary['source']['source_sha256'], 'gzip_crc_verified': True,
            'source_provenance': 'retained_manifest' if known_source else 'reported_sha_only_unverified_historical_diagnostic'}


def validate_rejected_captures(selected):
    """Retain explicitly documented failed bytes, without treating them as valid traces."""
    rejected = {}
    for metadata in sorted(HERE.rglob('capture-integrity-failures.json')):
        for item in read(metadata):
            assert Path(item['file']).name == item['file'], 'Failure entry must name one basename'
            path = metadata.parent / 'failed-captures' / item['file']
            name = path.relative_to(HERE).as_posix()
            assert selected.get(name) == path and sha(path.read_bytes()) == item['sha256']
            observed_error = None
            try:
                with gzip.open(path, 'rb') as stream:
                    while stream.read(1024 * 1024):
                        pass
            except (EOFError, gzip.BadGzipFile) as exc:
                observed_error = repr(exc)
            assert observed_error == item['error'], ('Rejected bytes no longer match documented failure', name)
            summary = path.with_name(path.name.removesuffix('.jsonl.gz') + '-summary.json')
            assert summary.is_file()
            rejected[name] = {'bytes': path.stat().st_size, 'sha256': item['sha256'], 'documented_error': item['error'],
                              'observed_error': observed_error, 'accepted_trace': False,
                              'metadata': metadata.relative_to(HERE).as_posix(),
                              'original_summary': summary.relative_to(HERE).as_posix(),
                              'classification': 'Rejected capture bytes preserved; excluded only from successful-trace CRC/checkpoint checks.'}
    return rejected


def snapshot_proofs():
    manifests = [HERE / 'parent-source.json', *sorted(HERE.glob('candidate-source*.json'))]
    known = {read(path)['python_sha256']: path for path in manifests}
    parent = source(PARENT)
    assert parent['python_sha256'] == PARENT_SHA and parent['files'] == read(HERE / 'parent-source.json')['files']
    protected = read(HERE / 'protected-before.json')
    snapshots = []
    for path in sorted(HERE.glob('causal-traces*/*')):
        if not path.is_dir() or not (path / 'fs_bot').is_dir():
            continue
        ident = source(path)
        manifest = known.get(ident['python_sha256'])
        assert manifest is not None and ident['files'] == read(manifest)['files'], ('unrecognized snapshot', path)
        assert all((path / name).is_file() and sha((path / name).read_bytes()) == digest for name, digest in protected.items())
        suffix = manifest.stem.removeprefix('candidate-source')
        patch = HERE / ('prepared-source' + suffix + '.patch')
        assert patch.is_file()
        with tempfile.TemporaryDirectory(prefix='fs-evidence-source-') as temp:
            root = Path(temp)
            shutil.copytree(PARENT / 'fs_bot', root / 'fs_bot', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
            subprocess.run(['git', 'apply', str(patch)], cwd=root, check=True, capture_output=True)
            assert source(root) == ident, ('source patch does not reconstruct snapshot', path)
        files = [p for p in path.rglob('*') if p.is_file()]
        snapshots.append({'path': path.relative_to(HERE).as_posix(), 'files': len(files), 'bytes': sum(p.stat().st_size for p in files),
                          'source_sha256': ident['python_sha256'], 'manifest': manifest.name, 'patch': patch.name,
                          'reason': 'Reproducible source/reference snapshot; exact Python bytes independently reconstructed from parent plus retained patch.'})
    return known, snapshots


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--create', action='store_true', help='Only after explicit root final freeze authorization')
    parser.add_argument('--archive', type=Path)
    parser.add_argument('--accepted-attempt')
    parser.add_argument('--expected-source-sha')
    parser.add_argument('--fresh-balance-dir', type=Path, help='Fresh legacy100 records after reviewed baseline refresh')
    parser.add_argument('--include-unaccepted-code', action='store_true', help='Default excludes labelled prototype code but retains its explanatory notes')
    args = parser.parse_args()
    if args.create and not all((args.archive, args.accepted_attempt, args.expected_source_sha)):
        parser.error('--create requires --archive, --accepted-attempt and --expected-source-sha')
    known, snapshots = snapshot_proofs()
    excluded, selected = [], {}
    for path in sorted(HERE.rglob('*')):
        if not path.is_file():
            continue
        name = path.relative_to(HERE).as_posix()
        reason = None
        if any(name.startswith(item['path'] + '/') for item in snapshots):
            continue
        if any(part in {'__pycache__', '.pytest_cache', '.git'} for part in path.relative_to(HERE).parts) or path.suffix in {'.pyc', '.tmp', '.zip'}:
            reason = 'cache/temporary/archive output'
        elif path.name.startswith('archive-preflight-') or path.name == 'evidence-index.json':
            reason = 'generated preflight/index output'
        elif '.UNACCEPTED.' in path.name and not args.include_unaccepted_code:
            reason = 'Unaccepted prototype code; retained locally, explanatory notes included in archive.'
        if reason:
            excluded.append({'path': name, 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes()), 'reason': reason})
        else:
            selected[name] = path
    # The reused baseline suite otherwise points outside this evidence directory.
    previous = HERE.parent / 'fuzz-determinism-2026-11-02'
    for name in ('after-full.xml', 'after-full.log', 'prepared-source.json', 'acceptance-results.json'):
        selected['inherited-parent-evidence/' + name] = previous / name
    inherited_source = read(previous / 'prepared-source.json')
    inherited_results = read(previous / 'acceptance-results.json')
    assert inherited_source['source']['python_sha256'] == inherited_results['prepared_source']['python_sha256'] == PARENT_SHA
    assert inherited_source['files'] == read(HERE / 'parent-source.json')['files']
    assert inherited_results['passed'] and inherited_results['full_tests']['passed'] == 6886
    assert inherited_results['full_tests']['python'] == '3.10.22'
    attempts = {path.name: validate_attempt(path) for path in sorted(HERE.glob('attempt*'))
                if path.is_dir() and (path / 'integration-results.json').is_file()}
    rejected_captures = validate_rejected_captures(selected)
    traces, schemas, suites = {}, Counter(), {}
    for name, path in selected.items():
        if path.suffix == '.json':
            read(path); schemas['json_files'] += 1
        elif path.suffix == '.jsonl':
            parsed = rows(path); schemas['jsonl_files'] += 1; schemas['jsonl_records'] += len(parsed)
        elif path.name.endswith('.jsonl.gz'):
            if name in rejected_captures:
                schemas['retained_rejected_gzip_files'] += 1
            else:
                traces[name] = validate_trace(path, known); schemas['gzip_jsonl_files'] += 1
        elif path.suffix == '.xml':
            root = ET.parse(path).getroot()
            group = [root] if root.tag == 'testsuite' else list(root.iter('testsuite'))
            if group:
                tests = sum(int(s.attrib['tests']) for s in group)
                assert tests == sum(len(s.findall('testcase')) for s in group)
                suites[name] = {key: sum(int(s.attrib.get(key, 0)) for s in group) for key in ('tests', 'failures', 'errors', 'skipped')}
    assert suites['inherited-parent-evidence/after-full.xml'] == {'tests': 6886, 'failures': 0, 'errors': 0, 'skipped': 0}
    protected = read(HERE / 'protected-before.json')
    changed = [name for name, digest in protected.items() if sha((REPO / name).read_bytes()) != digest]
    assert not set(changed) - {'fs_bot/tools/balance_baseline.json'}, ('immutable rule inputs changed', changed)
    refresh = None
    if args.fresh_balance_dir:
        data, metadata = validate_bots(args.fresh_balance_dir, 'legacy', range(1, 21), args.expected_source_sha)
        assert args.fresh_balance_dir.resolve().is_relative_to(HERE), 'Keep fresh balance evidence inside this archive evidence tree'
        assert metadata['python'] == '3.10.22' and metadata['hash_seed'] == 0 and metadata['all_factions_bots'] is True
        baseline = read(REPO / 'fs_bot/tools/balance_baseline.json')['games']
        assert all(r['completed'] and r['audit_completed'] and not r['errors'] and not r['integrity_findings'] for r in data)
        assert all(all(r[key] == baseline[f"{r['scenario']}|{r['seed']}"][key] for key in ('winner', 'cards')) for r in data)
        if args.accepted_attempt:
            accepted_records = {(r['scenario'], r['seed']): r for r in rows(HERE / args.accepted_attempt / 'bots-legacy/games.jsonl')}
            assert all(all(r[key] == accepted_records[r['scenario'], r['seed']][key] for key in ('winner', 'cards', 'final_state_sha256')) for r in data)
        refresh = {'games': 100, 'exact_winner_card_match': True, 'source_sha256': metadata['source_sha256'],
                   'previous_baseline_sha256': protected['fs_bot/tools/balance_baseline.json'],
                   'new_baseline_sha256': sha((REPO / 'fs_bot/tools/balance_baseline.json').read_bytes()),
                   'records_directory': str(args.fresh_balance_dir)}
    current = source(REPO)
    if args.create:
        assert current['python_sha256'] == args.expected_source_sha
        assert attempts[args.accepted_attempt]['matrix_checks_passed'] is True
        assert attempts[args.accepted_attempt]['source_sha256'] == args.expected_source_sha
        assert not changed or refresh is not None, 'Changed baseline requires reviewed fresh100 evidence'
    proof = {'schema_version': 1, 'mode': 'create' if args.create else 'plan_only_no_archive',
             'task_acceptance': 'Not inferred by archive packaging; root owns final rules/causal/full-suite approval.',
             'selected_files': len(selected), 'selected_bytes': sum(p.stat().st_size for p in selected.values()),
             'reproducible_snapshots_excluded': snapshots, 'other_exclusions': excluded,
             'attempts_separately_validated': attempts, 'schemas': dict(schemas), 'traces_verified': traces, 'junit_suites': suites,
             'rejected_captures_preserved': rejected_captures,
             'source_provenance_gaps': [name for name, value in traces.items() if value['source_provenance'] != 'retained_manifest'],
             'immutable_rule_inputs_unchanged': 48, 'baseline_changed': bool(changed), 'baseline_refresh_check': refresh,
             'source_at_preflight': {k: v for k, v in current.items() if k != 'files'},
             'historical_status_notes': ['Attempt1 is rejected.', 'Attempt2 is superseded by a later confirmed NPC67 issue.',
                 'causal-traces-final is the historical attempt2 directory, not final current acceptance.',
                 'The attempt2 truncated GreatRevolt5 capture was overwritten before this preflight; its bytes cannot be recovered. Existing revision-status.json documents that limitation.',
                 'Intermediate a09a6fb8 diagnostic trace lacks a retained per-file source manifest; its reported source SHA is not independently verified and is not acceptance proof.',
                 'roman-retreat-import-bootstrap.log imported current code through pytest path setup; it is an import diagnostic, not parent proof. roman-retreat-parent.json identifies the actual parent module path and records 3 failures/6 passes; repaired source records 9 passes.',
                 'The 207-pass/55.97-second integration run occurred during PR11 source changes; it is exploratory evidence, not final frozen-source acceptance.',
                 'Unaccepted prototype notes record an earlier decision; user subsequently adopted PR10/PR11 recommendations. They are retained as history, not current instructions.']}
    plan_path = HERE / ('archive-preflight-created.json' if args.create else 'archive-preflight-plan.json')
    if args.create:
        archive = args.archive.resolve()
        assert not archive.exists(), 'Use a new archive path; do not overwrite retained prior archive'
        rejected_paths = set(rejected_captures) | {item['original_summary'] for item in rejected_captures.values()}
        entries = {name: {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes()),
                          'evidence_role': 'rejected_capture' if name in rejected_paths else 'retained_evidence'}
                   for name, path in selected.items()}
        index = {'schema_version': 1, 'entries': entries, 'preflight': proof}
        with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
            for name, path in selected.items():
                data = path.read_bytes()
                assert sha(data) == entries[name]['sha256'], ('evidence changed while packaging', name)
                handle.writestr(name, data)
            handle.writestr('evidence-index.json', json.dumps(index, indent=2) + '\n')
        with zipfile.ZipFile(archive) as handle:
            assert handle.testzip() is None
            assert len(handle.namelist()) == len(set(handle.namelist())) == len(entries) + 1
            assert set(handle.namelist()) == set(entries) | {'evidence-index.json'}
            for name, metadata in entries.items():
                data = handle.read(name)
                assert len(data) == metadata['bytes'] and sha(data) == metadata['sha256']
        proof['archive'] = {'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()),
                            'entries': len(entries) + 1, 'crc_schema_count_and_manifest_verified': True,
                            'historical_source_provenance_gaps_disclosed': len(proof['source_provenance_gaps'])}
    plan_path.write_text(json.dumps(proof, indent=2) + '\n')
    print(json.dumps({key: proof[key] for key in ('mode', 'selected_files', 'selected_bytes', 'schemas', 'baseline_changed')}, indent=2))
    print('Snapshots excluded:', len(snapshots), 'bytes:', sum(s['bytes'] for s in snapshots))
    print('Verified traces:', len(traces), 'checkpoints:', sum(t['checkpoints'] for t in traces.values()))


if __name__ == '__main__':
    main()
