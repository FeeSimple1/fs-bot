"""Twelfth comparison audit, public Aedui March witnesses and controls."""
import argparse
import copy
import json
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--repo', required=True)
args = parser.parse_args()
sys.path.insert(0, args.repo)

from fs_bot import rules_consts as rc
from fs_bot.board.control import refresh_all_control, is_controlled_by
from fs_bot.board.pieces import place_piece, count_pieces, count_pieces_by_state
from fs_bot.bots.aedui_bot import node_a5, _determine_trade_sa
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.cli.dispatcher import _translate_bot_action
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND, ACTION_COMMAND_SA, get_first_eligible_options
from fs_bot.state.serialize import encode
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity


def integrity(state):
    result = {'census': validate_state(state), 'structure': check_structural_integrity(state)}
    assert result == {'census': [], 'structure': []}, result
    return result


def position(scenario, seed, visibility, with_sa):
    # A canonical sparse mid-year board, not an untouched scenario setup.
    # Mandubii's Devastated marker represents a prior Arverni action.
    state = build_initial_state(scenario, seed=seed)
    state['non_player_factions'] = {rc.ROMANS, rc.ARVERNI, rc.AEDUI, rc.BELGAE}
    state['can_play_event'] = False
    state['_command_with_sa'] = with_sa
    state['resources'].update({rc.ROMANS: 10, rc.AEDUI: 10})
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    place_piece(state, rc.MANDUBII, rc.AEDUI, rc.WARBAND, 4, piece_state=visibility)
    place_piece(state, rc.SUGAMBRI, rc.AEDUI, rc.WARBAND, 1, piece_state=visibility)
    place_piece(state, rc.SUGAMBRI, rc.GERMANS, rc.WARBAND, 2)
    state['markers'].setdefault(rc.MANDUBII, {})[rc.MARKER_DEVASTATED] = True
    refresh_all_control(state)
    assert node_a5(state) == 'No'
    return state


def counts(state):
    return {region: {'warbands': count_pieces(state, region, rc.AEDUI, rc.WARBAND),
                     'hidden': count_pieces_by_state(state, region, rc.AEDUI, rc.WARBAND, rc.HIDDEN),
                     'aedui_control': is_controlled_by(state, region, rc.AEDUI)}
            for region in (rc.MANDUBII, rc.ATREBATES, rc.TREVERI, rc.CARNUTES, rc.SUGAMBRI)}


def run(name, scenario, seed, *, visibility=rc.REVEALED, with_sa=True,
        split_control=False, sa_label_control=False):
    state = position(scenario, seed, visibility, with_sa)
    before = integrity(state)
    original = encode(state)
    initial_trade = _determine_trade_sa(state, scenario)
    assert encode(state) == original
    action = dispatch_bot_turn(state, rc.AEDUI)
    assert encode(state) == original, 'This fixture must leave board and RNG unchanged in planning'
    assert action['command'] == rc.CMD_MARCH, action
    source_plan = copy.deepcopy(action)
    plan = action['details']['march_plan']
    targets = plan['spread_destinations']
    assert plan['origin'] == rc.MANDUBII and len(targets) == len(set(targets)) == 3
    assert set(targets) == {rc.ATREBATES, rc.TREVERI, rc.CARNUTES}
    kind = _translate_bot_action(action, get_first_eligible_options())
    if split_control:
        # An explicit player plan demonstrates the required three legal groups.
        state['non_player_factions'].remove(rc.AEDUI)
        action = {'command': rc.CMD_MARCH, 'sa': 'No SA', 'details': {
            'march_plan': {'explicit_moves': [
                {'origin': rc.MANDUBII, 'path': [region],
                 'group': {rc.WARBAND: 1}} for region in targets]}}}
        result = execute_decision(state, rc.AEDUI, {'action': ACTION_COMMAND, 'player_action': action})
    else:
        if sa_label_control:
            # Keep the exact movement plan, opening only the source-required
            # post-Command SA dispatch. The live chooser derives Trade itself.
            action['sa'] = 'Suborn'
            kind = ACTION_COMMAND_SA
        result = execute_decision(state, rc.AEDUI, {'action': kind, 'bot_action': action})
    assert result['executed'] and not result.get('errors'), result
    assert result['total_cost'] == 2 and result['origin_costs'] == {rc.MANDUBII: 2}
    after_command = counts(state)
    after_resources = state['resources'][rc.AEDUI]
    final = encode(state)
    current_trade = _determine_trade_sa(state, scenario)
    assert encode(state) == final
    sa = result.get('sa_execution')
    if split_control:
        assert len(result['marches']) == 3
        assert all(after_command[region]['warbands'] == 1 for region in targets)
        assert after_command[rc.MANDUBII]['warbands'] == 1
    else:
        assert len(result['marches']) == 1
        assert after_command[rc.ATREBATES]['warbands'] == 3
        assert after_command[rc.TREVERI]['warbands'] == after_command[rc.CARNUTES]['warbands'] == 0
    if with_sa and visibility == rc.REVEALED and not sa_label_control:
        assert initial_trade[0] == 'No SA' and source_plan['sa'] == 'No SA'
        assert kind == ACTION_COMMAND and sa is None
        assert current_trade[0] == 'Trade' and current_trade[2]['trade_resources'] == 12
        assert after_resources == 8
    if sa_label_control or (with_sa and visibility == rc.HIDDEN):
        assert sa['executed'] and sa['sa'] == 'Trade' and sa['result']['resources_gained'] == 12
        assert after_resources == 20
    if not with_sa:
        assert sa is None and after_resources == 8
    return {'name': name, 'scenario': scenario, 'seed': seed,
            'visibility': visibility, 'with_sa': with_sa,
            'integrity_before': before, 'integrity_after': integrity(state),
            'planning_board_and_rng_unchanged': True,
            'initial_trade_choice': initial_trade,
            'dispatched_action': source_plan, 'action_type': kind,
            'control_action': action if split_control or sa_label_control else None,
            'execution': result, 'after': after_command, 'resources_after': after_resources,
            'post_command_trade_choice': current_trade}


def main():
    cases = []
    for scenario in (rc.SCENARIO_PAX_GALLICA, rc.SCENARIO_GREAT_REVOLT):
        for seed in (6, 19):
            cases.append(run('spread_collapsed', scenario, seed, with_sa=False, visibility=rc.HIDDEN))
            cases.append(run('explicit_three_groups_control', scenario, seed, with_sa=False,
                             visibility=rc.HIDDEN, split_control=True))
            cases.append(run('new_trade_omitted', scenario, seed))
            cases.append(run('live_trade_dispatch_control', scenario, seed, sa_label_control=True))
            cases.append(run('existing_hidden_sa_control', scenario, seed, visibility=rc.HIDDEN))
            cases.append(run('command_only_control', scenario, seed, with_sa=False))
    print(json.dumps({'case_count': len(cases), 'cases': cases}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
