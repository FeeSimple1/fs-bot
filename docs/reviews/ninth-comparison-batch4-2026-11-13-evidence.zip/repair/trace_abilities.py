"""Observe the first changed decisions on paired, fixed-seed bot games."""

import argparse
from concurrent.futures import ProcessPoolExecutor
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.engine import execute
from fs_bot.engine.devastate_losses import removal_request
from fs_bot.state.serialize import encode
from fs_bot.tools import run_batch
from fs_bot.tools.validation_metadata import source_identity


def digest(value):
    return hashlib.sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def board_digest(state):
    excluded = {'decision_agent', 'rng', '_card_turn', '_resolved_card'}
    return digest({key: value for key, value in state.items() if key not in excluded})


def snapshot(state):
    return {'board': board_digest(state), 'rng': digest(state['rng'].getstate())}


def plan_summary(action):
    details = action.get('details') or {}
    enlist = details.get('enlist')
    return dict(command=action.get('command'), sa=action.get('sa'),
                sa_regions=action.get('sa_regions'),
                enlist=enlist and {key: enlist[key] for key in ('type', 'regions')},
                recheck_after_command=details.get('post_command_sa'))


def trace(task):
    cards = []
    play = run_batch.play_card
    execute_decision = execute.execute_decision

    def record_card(state, decide, **kwargs):
        row = dict(card=state['current_card'], scenario=state['scenario'],
                   ordinal=len(cards) + 1, before=snapshot(state), actions=[], abilities=[])

        def record_decision(board, faction, options, slot):
            before = snapshot(board)
            decision = decide(board, faction, options, slot)
            row['actions'].append(dict(faction=faction, slot=slot, options=options,
                                       decision=decision['action'], before=before,
                                       plan=plan_summary(decision['bot_action']),
                                       after_planning=snapshot(board)))
            return decision

        def record_execution(board, faction, decision):
            result = execute_decision(board, faction, decision)
            action = row['actions'][-1]
            assert action['faction'] == faction
            ability = result.get('sa_execution') or {}
            action.update(executed=result.get('executed'), sa=ability.get('sa'),
                          sa_executed=ability.get('executed'),
                          battle_sa=result.get('battle_sa_executed'),
                          after_execution=snapshot(board))
            return result

        def record_ability(name):
            resolve = getattr(execute, name)

            def recorded(board, faction, action):
                if board is not state:
                    return resolve(board, faction, action)
                entry = dict(faction=faction, name=name.removeprefix('_execute_'),
                             plan=plan_summary(action), before=snapshot(board))
                row['abilities'].append(entry)
                if name == '_execute_devastate':
                    entry['casualty_quotas'] = {
                        region: {owner: removal_request(board, region, owner)['count']
                                 for owner in rc.FACTIONS}
                        for region in action.get('sa_regions', []) if isinstance(region, str)
                    }
                result = resolve(board, faction, action)
                entry.update(executed=result.get('executed'), after=snapshot(board))
                return result

            return recorded

        with ExitStack() as stack:
            stack.enter_context(patch.object(execute, 'execute_decision', record_execution))
            for name in ('_execute_devastate', '_execute_entreat',
                         '_execute_rampage', '_execute_enlist'):
                stack.enter_context(patch.object(execute, name, record_ability(name)))
            result = play(state, record_decision, **kwargs)
        effective = result.get('turn_result', {}).get('actions_taken', {})
        for action in row['actions']:
            if action['faction'] in effective:
                action['effective'] = effective[action['faction']]['action']
        row.update(after=snapshot(state), winner=result.get('winner'))
        cards.append(row)
        return result

    with patch.object(run_batch, 'play_card', record_card):
        result = run_batch.play_one(task)
    assert result['completed'], result
    outcome = {key: result[key] for key in ('winner', 'cards', 'final_state_sha256', 'interlude_completed')}
    return dict(task=task, cards=cards, outcome=outcome)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('tasks', type=Path)
    parser.add_argument('--workers', type=int, default=2)
    args = parser.parse_args()
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        games = list(pool.map(trace, json.loads(args.tasks.read_text())))
    print(json.dumps(encode(dict(source=source_identity(), games=games)), sort_keys=True))


if __name__ == '__main__':
    main()
