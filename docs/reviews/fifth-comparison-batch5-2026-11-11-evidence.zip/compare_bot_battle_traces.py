"""Compare matched traces at their first divergence and verify its cause."""

from itertools import zip_longest
import json
from pathlib import Path
import sys


def action(row):
    choice = row['choice']
    bot = choice['bot_action']
    return dict(faction=row['faction'], sop=choice['action'], command=bot['command'],
                sa=bot['sa'], regions=bot['regions'], targets=bot['details'].get('battle_plan'))


def first_divergence(old, new):
    case = {key: old[key] for key in ('scenario', 'seed', 'card_edition')}
    assert all(new[key] == value for key, value in case.items()), case
    assert old['winner'] != new['winner'], case
    for before, after in zip(old['cards'], new['cards']):
        assert before['before'] == after['before'], case
        if before['after'] != after['after']:
            break
    else:
        raise AssertionError(case)
    assert before['card'] == after['card'] and before['draw'] == after['draw'], case
    for previous, current in zip_longest(before['decisions'], after['decisions']):
        if previous != current:
            break
    else:
        raise AssertionError(case)
    assert previous['before'] == current['before'], case
    earlier = action(previous)
    later = action(current)
    assert earlier['faction'] == later['faction'] == 'Aedui', case
    assert earlier['command'] == 'Battle' and later['command'] in ('Rally', 'March'), case
    targets = {(row['region'], row['target']) for row in earlier['targets']
               if row['priority'] == 'high_value'}
    assert targets, case
    old_qualifiers = [row for row in before['forecasts'] if row['kind'] == 'Aedui target'
                      and row['qualifies'] and (row['region'], row['target']) in targets]
    assert targets == {(row['region'], row['target']) for row in old_qualifiers}, case
    assert all(row['high_value'] == 0 for row in old_qualifiers), case
    for row in after['forecasts']:
        if row['kind'] == 'Aedui target' and (row['region'], row['target']) in targets:
            assert not row['qualifies'] and row['high_value'] == 0, case
    return dict(**case, draw=before['draw'], card=before['card'],
                winner_before=old['winner'], winner_after=new['winner'],
                identical_before=before['before'], before=before, after=after,
                first_decision_before=earlier, first_decision_after=later)


def main(before_path, after_path, output):
    before = json.loads(Path(before_path).read_text())
    after = json.loads(Path(after_path).read_text())
    games = [first_divergence(old, new) for old, new in zip(before['games'], after['games'], strict=True)]
    report = dict(parent=before['source'], repaired=after['source'], games=games)
    Path(output).write_text(json.dumps(report, indent=2) + '\n')
    print(f'{len(games)} changed winners first diverge at an Aedui Battle with no high-value target.')


if __name__ == '__main__':
    main(*sys.argv[1:])
