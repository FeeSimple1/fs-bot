# Seventh comparison Batch 1 validation

The repair was tested on parent `5c1fdb002f3c98909f515e021958ecd16249608c`
with Python 3.12.14. `source.json` identifies the tested Python bytes. The
earlier sixth Batch 5 evidence in the repository contains the paired
parent game records. The seventh audit commit used the same Python bytes.

Run the evidence verifier from the repaired repository root with its Python
environment active.

```sh
PYTHONPATH=. python /path/to/evidence/verify_results.py /path/to/evidence
```

The validation runs used these commands, with each output going into a fresh
directory.

```sh
PYTHONHASHSEED=0 python -m pytest -q -n 5 --junitxml=pytest.xml
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out bots-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 41-44 --card-edition second-edition --workers 2 --out bots-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
```

`directed.log` contains the 20 public-path regressions. The same test file
run on the parent reproduces 13 failures and passes seven controls.
`audit-before.json` matches the prior audit's observed Battle output.

`first-changes.json` records both versions of each first changed card,
including matching pre-card board and RNG digests, initial fire and Battle
Losses. To reproduce it, run `trace_battle_changes.py` with
`trace-parent-input.json` and a fresh parent trace output path on the parent
checkout. Then run the script with `trace-candidate-input.json`, a fresh
output path, and the parent trace path on the repaired checkout. Use
`PYTHONHASHSEED=0 PYTHONPATH=.` for both invocations.
