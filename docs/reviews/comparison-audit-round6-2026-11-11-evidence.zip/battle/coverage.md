# Sixth audit: Battle partition

Audited Falling Sky at `86fb0c2d8ddf86a4548a863dc9c9da27d0c708ad`; no production edits.
Comparator Liberty or Death at `2991ea279062773548ec390a1da75f3e85381702`. Inspected
`docs/audit_set_but_never_applied_s76.md`, especially modifier-to-consumer and
free-action routing patterns. Falling Sky's own references govern findings.

Three confirmed groups in findings.json; one portable script produces their
raw JSON. Script assertions describe the observed broken behavior on this
revision. Source-correct repair regressions must reverse those assertions.
A31 modifiers are acquired after the affected capabilities in all witnesses.

Coverage includes both battle calculators, the complete live resolver,
loss tiers and physical casualties, Abatis, surviving Counterattack handling,
Retreat disposition, Diviciacus cooperation, Enlist and combined force views,
ordinary Battle integration, German guidance, and automatic Germans/Arverni
Battle callsites. Round 2, 3, 4 and 5 ledgers and relevant original human-choice,
Slingers and Horse repair reports were checked for overlap. Fixture validity
checks include deck membership for combined Ariovistus capabilities, piece
conservation, Tribe/structure checks and the permanent Provincia Fort.

Uncounted:

- Existing A33 outnumbered ambiguity remains an existing source question.
- Besiege-decline/10U cancellation timing was inspected but not established
  enough to claim a new rule defect.
- Card 27 is replaced by A27 in Ariovistus; no impossible mixed-deck witness
  is counted. No Interlude specimen was needed for the confirmed A31 group.
- Automatic Arverni and several other Event direct Battle callers have the
  same capability bypass risk; only public cards 17 and 53 and normal Germans
  Phase were reproduced and counted together.
- The ordinary German command pipeline case is an engine comparison,
  not an assertion that base-game Germans have a human Sequence-of-Play seat.

A discarded exploratory card 53 Slingers fixture let Rally add Allies and Warbands;
the final public card 53 Slingers fixture instead uses three Germans against four Auxilia,
no German Control/Ally at Carnutes and no extra local Rally. Final probe output
contains only the corrected fixture. No randomness or production methods were
monkeypatched; gameplay RNG is the seeded Random supplied by initial state.
