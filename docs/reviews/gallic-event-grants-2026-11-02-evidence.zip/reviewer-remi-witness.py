"""Independent BE-03 witness: fixed City effect preserves unrelated Region objects."""
from copy import deepcopy
import json

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, get_available, count_pieces
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.cards import remi_event_effect as remi
from fs_bot.state.state_schema import build_initial_state, validate_state


def main():
    st = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=681)
    st['executing_faction'] = rc.AEDUI
    st['event_params'] = {'target_city': rc.CITY_ALESIA}
    _ally_tribe(st, rc.TRIBE_REMI, rc.AEDUI)
    _ally_tribe(st, rc.TRIBE_MANDUBII, rc.BELGAE)
    place_piece(st, rc.MANDUBII, rc.ROMANS, rc.FORT)
    place_piece(st, rc.MANDUBII, rc.ROMANS, rc.AUXILIA, 2)
    st['markers'].setdefault(rc.MANDUBII, {})[rc.MARKER_ABATIS] = rc.ARVERNI
    for city in (rc.CITY_BIBRACTE, rc.CITY_AVARICUM):
        tribe = rc.CITY_TO_TRIBE[city]
        place_piece(st, rc.TRIBE_TO_REGION[tribe], rc.AEDUI, rc.CITADEL)
        st['tribes'][tribe]['allied_faction'] = rc.AEDUI
    place_piece(st, rc.VENETI, rc.AEDUI, rc.WARBAND,
                get_available(st, rc.AEDUI, rc.WARBAND))
    before = deepcopy(st['markers'][rc.MANDUBII])
    assert get_available(st, rc.AEDUI, rc.CITADEL) == 0
    assert get_available(st, rc.AEDUI, rc.WARBAND) == 0
    assert remi.execute(st)['accepted']
    assert st['tribes'][rc.TRIBE_MANDUBII]['allied_faction'] is None
    assert count_pieces(st, rc.MANDUBII, rc.BELGAE, rc.ALLY) == 0
    assert count_pieces(st, rc.MANDUBII, rc.AEDUI) == 0
    assert count_pieces(st, rc.MANDUBII, rc.ROMANS, rc.FORT) == 1
    assert count_pieces(st, rc.MANDUBII, rc.ROMANS, rc.AUXILIA) == 2
    assert st['markers'][rc.MANDUBII] == before
    assert validate_state(st) == []
    print(json.dumps({'check': 'Remi City removal with exhausted recipient pools',
                      'city_ally_removed': True, 'unrelated_fort_auxilia_abatis_preserved': True,
                      'invariants': 'pass'}))


if __name__ == '__main__':
    main()
