from pathlib import Path
import hashlib,json,platform,re,subprocess,xml.etree.ElementTree as ET,zipfile
from fs_bot.tools.validation_metadata import source_identity
prefix='drought-losses-2026-11-04';result=json.loads(Path('/tmp/fs-drought-results.json').read_text())
assert source_identity()['source_sha256']==result['source']['source_sha256']=='b33a8d39c1fcb3ba138527c95393986493eccf847b3193356d7c706249306037'
suite=ET.parse('/tmp/fs-drought-full.xml').getroot().find('testsuite')
assert suite.attrib['tests']=='8260' and all(suite.attrib[k]=='0' for k in ('errors','failures','skipped'))
assert Path('/tmp/test_drought_losses_parent.py').read_bytes()==Path('fs_bot/tests/test_drought_losses.py').read_bytes()
proof=ET.parse('/tmp/fs-drought-parent.xml').getroot().find('testsuite')
assert proof.attrib['tests']=='36' and proof.attrib['failures']=='35' and proof.attrib['errors']=='0'
assert all('assert' in t.find('failure').attrib['message'].lower() for t in proof if t.find('failure') is not None)
log=Path('/tmp/fs-drought-targeted-frozen.log').read_text();assert re.search(r'\n284 passed in ',log) and 'failed' not in log
result['full_suite']=suite.attrib;result['parent_suite']=proof.attrib;result['python']=platform.python_version()
Path('docs/reviews/'+prefix+'-results.json').write_text(json.dumps(result,indent=2)+'\n')
p=Path('docs/reviews/'+prefix+'.md');s=p.read_text().replace('Final full suite pending.',f"**8,260 tests pass** in the final full suite ({float(suite.attrib['time']):.2f} seconds), with zero failures, errors or skips.").replace('Parent behavioral proof pending.', '''An isolated parent runs the unchanged new test file through existing APIs:
**35 behavioral failures** reproduce missing owner choices and incorrect default
casualties; **one game-run control passes**, with 33 cases deselected. Failures
are behavior assertions, not missing helper imports.''').replace('Results pending final inspection.', '''All ten native-bot games complete and audit successfully, with no errors or
integrity findings, four ranked factions, consistent winner/ranking fields and
nonempty final hashes. Nine gameplay records/final hashes match parent exactly,
excluding only elapsed seconds, commit and source digest. Reconquest seed 2
changes play but retains the Belgae winner. An instrumented replay matches the
batch final hashes and locates its first divergence at the seventh card, Drought
(49), with identical pre-card and pre-Event boards and identical marker maps.
At Morini, the parent removes a Roman Legion and retains a Revealed Auxilia;
the repair removes that Auxilia and retains the Legion, as §8.4.1 requires.
The raw before/after Event boards and per-card trace are archived.

Both mixed-seat outputs agree in complete JSON across hash seeds: 356 human
turns, 96 Event attempts, 90 successful Events, zero hard findings, zero partials,
batch digest `d899b5732da10db5`. Internal replay makes 40 executions in total.''')
b=result['balance_smoke'];s=s.replace('Balance results pending.',f"The check passes, with a largest absolute difference of {b['maximum_absolute_delta_percentage_points']} percentage points and {b['historical_baseline_winner_changes']} winner changes versus the historical baseline. These are not changes versus the parent.");p.write_text(s)
p=Path('docs/current-status.md');s=p.read_text().replace('Validation: see the final report and machine-readable results.', '''**8,260 tests pass**, including 69 new cases; 284 targeted tests pass. All ten
native-bot games audit cleanly: nine match parent, and the one changed game's
first divergence is traced to the corrected Drought casualty. Forty mixed
executions agree across hash seeds with zero hard findings or partials. The
100-game historical balance check passes its unchanged baseline and band.
See the report for frozen source provenance and evidence bounds.''',1);p.write_text(s)
entries={}
for file in ['/tmp/fs-drought-full.xml','/tmp/fs-drought-full.log','/tmp/fs-drought-targeted-frozen.log','/tmp/fs-drought-parent.xml','/tmp/fs-drought-parent.log','/tmp/test_drought_losses_parent.py','/tmp/fs-drought-mixed0.json','/tmp/fs-drought-mixed0.log','/tmp/fs-drought-mixed987.json','/tmp/fs-drought-mixed987.log','/tmp/fs-drought-balance.log','/tmp/fs-drought-verify.py','/tmp/fs-drought-package.py','/tmp/fs-drought-trace.py','/tmp/fs-drought-trace-parent.json','/tmp/fs-drought-trace-final.json','/tmp/fs-drought-trace-parent.log','/tmp/fs-drought-trace-final.log']:
 entries['accepted/'+Path(file).name]=Path(file).read_bytes()
for label,directory in [('parent','/tmp/fs-drought-bots-parent'),('accepted','/tmp/fs-drought-bots-final')]:
 for p in Path(directory).iterdir():
  if p.is_file():entries[label+'/bots/'+p.name]=p.read_bytes()
entries['accepted/results.json']=json.dumps(result,indent=2).encode()
entries['accepted/source.patch']=subprocess.check_output(['git','diff','HEAD','--','fs_bot'])
for name in ['fs_bot/cards/drought.py','fs_bot/cli/drought.py','fs_bot/tests/test_drought_losses.py']:entries['accepted/'+name]=Path(name).read_bytes()
protected=[p for p in Path('Reference Documents').rglob('*') if p.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
entries['accepted/protected-inputs.json']=json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected},indent=2).encode()
entries['commands.txt']=b'''Accepted source: parent e42b213dcfd57105f13f9ae44674fdd20b243a6a plus accepted/source.patch and the three accepted/fs_bot Python files.
python -m pytest -q --junitxml=/tmp/fs-drought-full.xml
python -m pytest -q fs_bot/tests/test_drought_losses.py fs_bot/tests/test_card_effects.py fs_bot/tests/test_event_action_windows.py fs_bot/tests/test_event_timing_planning.py fs_bot/tests/test_assistant_session.py fs_bot/tests/test_devastate_losses.py
In isolated unmodified parent checkout, with unchanged new test file copied outside the tree:
PYTHONPATH=/tmp/fs-drought-parent python -m pytest -q /tmp/test_drought_losses_parent.py -k 'owner_selects_exact_physical_visibility or owner_selects_named_ally_without_clearing_another_tribe or owner_can_select_legion_to_fallen_instead_of_auxilia or roman_owner_can_sacrifice_leader_or_nonpermanent_fort or default_roman_loss_preserves_legion_and_hidden_auxilia or default_soft_loss_removes_scouted_before_hidden or game_run_arverni_in_expansion_never_receives_human_request' --junitxml=/tmp/fs-drought-parent.xml
In parent and accepted trees separately, with distinct output directories:
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --games 2 --workers 2 --out OUT
PYTHONHASHSEED=0 PYTHONPATH=CHECKOUT python /tmp/fs-drought-trace.py TRACE.json
In accepted tree:
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out /tmp/fs-drought-mixed0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out /tmp/fs-drought-mixed987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
PYTHONPATH=. python /tmp/fs-drought-verify.py
PYTHONPATH=. python /tmp/fs-drought-package.py
'''
entries['README.txt']=b'Accepted Python source b33a8d39c1fcb3ba138527c95393986493eccf847b3193356d7c706249306037 over parent e42b213dcfd57105f13f9ae44674fdd20b243a6a. Apply source.patch and add the three accepted/fs_bot Python files to reconstruct frozen sources. Full suite:8260 passed; 69 new cases. Isolated-parent proof:35 behavioral failures, one control passes, 33 deselected. Ten native-bot games audit cleanly; nine gameplay records/final hashes match parent except timing/source provenance. Reconquest seed2 changes after Drought, traced to the corrected Roman loss (Auxilia instead of Legion). Mixed outputs agree in complete JSON across hash seeds0/987 with zero hard findings/partials and 40 executions including replay. The 100-game historical balance smoke retains baseline/seeds1-20/allfive scenarios/15-point band. It is not a parent-delta count or full rules-compliance proof.\n'
entries['SHA256SUMS.txt']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(entries.items())).encode()
p=Path('docs/reviews/'+prefix+'-evidence.zip')
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(entries.items()):z.writestr(name,data)
print(json.dumps({'full_suite':suite.attrib,'targeted':284,'evidence_bytes':p.stat().st_size,'source':result['source']}))
