"""Verify exact tested source and retained evidence before publication."""
from pathlib import Path
import json
import subprocess
import xml.etree.ElementTree as ET
from integration_matrix import identity, protected_files

HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'fs-bot'
read=lambda p:json.loads((HERE/p).read_text())
source=read('candidate-source-attempt1.json')
assert identity()==source
assert protected_files()==read('protected-before.json')
matrix=read('attempt1/integration-results.json')
assert matrix['passed'] and not matrix['failures']
assert matrix['source']['python_sha256']==source['python_sha256']
assert matrix['bot_games']==150
assert matrix['bot_hash_seed_repeat_executions']==25
assert matrix['mixed_seat_distinct_cases']==220
assert matrix['mixed_seat_executions_including_replay_and_hash_repeat']==880
assert matrix['strict_census_executions']==20
assert all(x['hard_findings']==x['partial']==0 for x in matrix['fuzz'].values())
assert matrix['parent_comparison']['all_editions_semantic_changes']==0
assert not matrix['parent_comparison']['causal_review_required']
assert matrix['baseline_comparison']['passed'] and not matrix['baseline_comparison']['baseline_changed']
provenance=read('parent-provenance-preflight.json')
assert provenance['all_non_test_python_files_identical']
assert provenance['parent_source_sha256']==read('parent-source.json')['python_sha256']

def junit(name):
 suites=list(ET.parse(HERE/name).getroot().iter('testsuite'))
 return {key:sum(int(s.get(key,'0')) for s in suites) for key in ('tests','failures','errors','skipped')}
parent=junit('parent-candidate-suite-attempt2.xml')
final=junit('candidate-suite-attempt1.xml')
assert parent==dict(tests=7205,failures=0,errors=0,skipped=0)
assert final==dict(tests=7347,failures=0,errors=0,skipped=0)
assert '142 passed' in (HERE/'focused-python312.log').read_text()
subprocess.run(['git','diff','--check'],cwd=REPO,check=True)
progress=json.loads((REPO/'docs/human-choice-progress.json').read_text())
assert progress['total']==len(progress['findings'])==50
assert progress['closed']==sum(x['status']=='closed' for x in progress['findings'])==20
assert progress['open']==30
assert progress['tested_source']['python_sha256']==source['python_sha256']
result={
 'date':'2026-11-03','timezone':'America/Chicago','accepted':True,
 'parent_commit':source['commit'],
 'final_source':{k:v for k,v in source.items() if k!='files'},
 'full_suite':final,'parent_full_suite':parent,'new_regressions':142,
 'focused_python312':{'version':'3.12.14','passed':142,'log':'focused-python312.log'},
 'gameplay_matrix':matrix,
 'parent_provenance':'parent-provenance-preflight.json; original labels retained in copied parent records',
 'protected_files_unchanged':True,'protected_input_count':49,
 'progress':{'closed':20,'total':50,'open':30,'percent':40,'newly_closed':['BE-02'],
             'unadopted_source_questions_separate':3},
 'limits':['Equality is of recorded gameplay fields, not proof of identical full trajectories.',
           'Bots cover fixed seeds across all five scenarios and three card-edition profiles, not exhaustive states.',
           'Non-player Litaviccus target prediction remains separately open; no new provisional ruling is adopted.',
           'Save schema is unchanged; old response logs are not promised exact cross-version replay.',
           'Remote CI follows publication and is separate from this local acceptance.']}
(HERE/'acceptance-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'accepted':True,'tests':final['tests'],'matrix_checks':len(matrix['checks_passed']),'source':source['python_sha256']}))
