"""Read-only independent review of the nine authorized Spring outcome pairs."""
from collections import Counter
from datetime import datetime, timezone
import gzip, hashlib, json, random, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'attempt1'
OUT = RUN / 'drift-review'
BASE = ROOT.parent / 'fs-spring-baseline'
CURRENT = ROOT.parent / 'fs-bot'
sys.path.insert(0, str(BASE))
from fs_bot import rules_consts as rc
from fs_bot.state.serialize import decode, encode
from fs_bot.board.pieces import count_pieces, get_leader_in_region

checks = 0
failures = []
def check(value, message):
    global checks
    checks += 1
    if not value:
        failures.append(message)
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def objsha(value):
    return sha(json.dumps(value, sort_keys=True).encode())
def load(path):
    with gzip.open(path, 'rt') as f:
        return json.load(f)
def domains(a, b):
    return sorted(k for k in a['domain_sha256'].keys() | b['domain_sha256'].keys()
                  if a['domain_sha256'].get(k) != b['domain_sha256'].get(k))
def boundary(p):
    return {k:p[k] for k in ('ordinal', 'stage', 'card_index', 'card', 'faction', 'position', 'depth')}
def select(t, stage, card, faction=None):
    rows = [p for p in t['checkpoints'] if p['stage'] == stage and p['card_index'] == card and p['faction'] == faction]
    assert len(rows) == 1, (stage, card, faction, len(rows))
    return rows[0]
def physical_counts(p, faction, exclude_leader=False):
    state = decode(p['phase_snapshot'])
    before = encode(state['rng'])
    counts = {r:count_pieces(state, r, faction) for r in state['spaces']}
    check(counts == {r:fs[faction] for r,fs in p['facts']['pieces_by_region_and_faction'].items()}, 'Observed region counts match independently decoded physical state')
    if exclude_leader:
        counts = {r:n - int(get_leader_in_region(state,r,faction) is not None) for r,n in counts.items()}
    check(encode(state['rng']) == before, 'Read-only counts do not consume checkpoint RNG')
    return counts

def rng_result(p, candidates):
    probe = random.Random(0)
    probe.setstate(decode(p['phase_snapshot']['rng']).getstate())
    value = probe.choice(candidates)
    return value, objsha(encode(probe))

plan = json.loads((RUN / 'drift-plan.json').read_text())
cases = {(c['scenario'], c['seed']):c for c in plan['cases']}
expected = {('Pax Gallica?',3),('Pax Gallica?',5)} | {('The Gallic War',n) for n in (1,3,4,8,12,14,18)}
check(set(cases) == expected, 'Exactly nine authorized changed-winner pairs')
source_ids = {'baseline':'071485179ff2949ba9e2163ca48f6761c52f617084f90a0a60ee521f35926d8b',
              'current':'32fc2e1f0c2eb2e005db4c7638884a6d2022246c5eda9d87b7ade87da4caeb74'}
for label,path in [('baseline',BASE),('current',CURRENT)]:
    digest = hashlib.sha256()
    for p in sorted((path/'fs_bot').rglob('*.py')):
        digest.update(str(p.relative_to(path)).encode()+b'\0'+p.read_bytes())
    check(digest.hexdigest() == source_ids[label], f'{label}: independent live source digest')
    check(subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip() == 'a537511a1220ea4d2b0e94e63ab5cc581ef3a605',f'{label}: actual checked-out commit')
check(subprocess.check_output(['git','status','--porcelain'],cwd=BASE,text=True).strip() == '', 'Baseline checkout clean')
rows = []
core_stages = {'after_setup','after_start','before_card','after_card','before_decision','after_decision','before_execute','after_execute'}
for key, case in cases.items():
    scenario, seed = key
    slug = scenario.lower().replace('?','').replace(' ','-') + f'-{seed:02}'
    folder = OUT / slug
    paths = {'baseline':folder/'baseline.json.gz', 'current':folder/('current-recaptured.json.gz' if key == ('The Gallic War',14) else 'current.json.gz')}
    ts = {label:load(path) for label,path in paths.items()}
    for label,t in ts.items():
        context = f'{scenario}|{seed}/{label}'
        expected_record = case[label]
        check(t['source']['source_sha256'] == t['source_after']['source_sha256'] == source_ids[label], context+': frozen source before/after')
        check(t['source']['commit'] == t['source_after']['commit'] == 'a537511a1220ea4d2b0e94e63ab5cc581ef3a605', context+': actual execution commit')
        check((t['scenario'],t['seed'],t['record']['card_edition']) == (scenario,seed,'legacy'), context+': exact scenario/seed/profile')
        check(t['passed'] and t['final_hash_matches_audited_record'], context+': trace successful')
        check(t['expected_final_state_sha256'] == t['record']['final_state_sha256'] == expected_record['final_state_sha256'], context+': exact audited final hash')
        for field in ('winner','cards','ending_scenario','interlude_completed','termination','final_ranking','engine_final_ranking','diagnostics','diagnostic_occurrences'):
            check(t['record'][field] == expected_record[field], context+': '+field+' matches audited row')
        check(all(t['record'][f] is True for f in ('completed','game_completed','audit_completed')) and not t['record']['errors'] and not t['record']['integrity_findings'], context+': full game audit clean')
        for i,p in enumerate(t['checkpoints']):
            check(p['ordinal'] == i, context+': checkpoint ordinal')
            if 'phase_snapshot' in p:
                check(objsha(p['phase_snapshot']) == p['state_sha256'], context+': recomputed phase full-state hash')
                check({k:objsha(v) for k,v in p['phase_snapshot'].items()} == p['domain_sha256'], context+': all phase domain hashes')
                check(objsha(p['phase_snapshot']['rng']) == p['rng_sha256'], context+': recomputed phase RNG hash')
    old,new = ts['baseline'],ts['current']
    a,b = [[p for p in t['checkpoints'] if p['stage'] in core_stages] for t in (old,new)]
    desc = ('stage','card_index','card','faction','position','depth')
    first_state = next((i,x,y) for i,(x,y) in enumerate(zip(a,b)) if x['state_sha256'] != y['state_sha256'])
    index,x,y = first_state
    for n,(l,r) in enumerate(zip(a[:index+1],b[:index+1])):
        check(all(l[k] == r[k] for k in desc), f'{key}: identical common-core boundary sequence through first state change')
        if n < index:
            check(l['state_sha256'] == r['state_sha256'], f'{key}: complete state unchanged before first changed common-core state')
            if l['stage'] in ('before_decision','after_decision','before_execute'):
                check(l.get('payload') == r.get('payload'), f'{key}: no earlier decision/plan difference')
    first_observable = next((i,l,r) for i,(l,r) in enumerate(zip(a,b)) if l['state_sha256'] != r['state_sha256'] or l.get('payload') != r.get('payload'))
    card = x['card_index']
    report = {'scenario':scenario,'seed':seed,'old_winner':case['baseline']['winner'],'new_winner':case['current']['winner'],
              'trace_paths':{k:str(p) for k,p in paths.items()},'trace_sha256':{k:sha(p.read_bytes()) for k,p in paths.items()},
              'final_state_sha256':{k:t['record']['final_state_sha256'] for k,t in ts.items()},
              'both_final_hashes_verified':True,'common_core_equal_state_prefix':index,
              'first_common_core_state_difference':{'baseline':boundary(x),'current':boundary(y),'changed_domains':domains(x,y)},
              'first_common_core_observable_difference':{'baseline':boundary(first_observable[1]),'current':boundary(first_observable[2]),'changed_domains':domains(first_observable[1],first_observable[2])}}
    if key in {('Pax Gallica?',3),('The Gallic War',4)}:
        faction, olddest, newdest = ('Belgae','Morini','Nervii') if scenario == 'Pax Gallica?' else ('Germans','Sugambri','Sequani')
        ob = select(old,'before_phase:_place_successor_leaders',card);nb = select(new,'before_phase:_place_successor_leaders',card)
        oa = select(old,'after_phase:_place_successor_leaders',card);na = select(new,'after_phase:_place_successor_leaders',card)
        check(ob['state_sha256'] == nb['state_sha256'], f'{key}: identical state immediately before Successor placement')
        check(oa['payload'] == [{'__tuple__':[faction,olddest]}] and na['payload'] == [{'__tuple__':[faction,newdest]}], f'{key}: exact corrected Successor destinations')
        counts = physical_counts(nb,faction)
        choice = select(new,'before_choice:leader_placement_region',card,faction)
        candidates = choice['observed_call']['kwargs']['candidates']
        check(counts[newdest] == max(counts[r] for r in candidates) and sum(counts[r] == counts[newdest] for r in candidates) == 1, f'{key}: unique most-own-piece legal destination')
        check(ob['rng_sha256'] == nb['rng_sha256'] == oa['rng_sha256'] == na['rng_sha256'], f'{key}: deterministic unique placement preserves RNG')
        report.update(category='corrected NP Successor priority',source_basis=['Chapter 6 §6.6','Chapter 8 §8.3.2'],faction=faction,card_index=card,winter_count=nb['facts']['winter_count'],old_destination=olddest,new_destination=newdest,old_destination_piece_count=counts[olddest],new_destination_piece_count=counts[newdest],legal_candidates=candidates,first_meaningful_boundary={'baseline':boundary(oa),'current':boundary(na)},explanation='Old path selected a Home Region first; new path selects the unique legal Region with most own pieces.')
    elif key == ('Pax Gallica?',5):
        ob=select(old,'before_choice:leader_placement_region',card,'Arverni');nb=select(new,'before_choice:leader_placement_region',card,'Arverni')
        oa=select(old,'after_choice:leader_placement_region',card,'Arverni');na=select(new,'after_choice:leader_placement_region',card,'Arverni')
        oc,nc=physical_counts(ob,'Arverni'),physical_counts(nb,'Arverni');candidates=sorted(r for r,n in nc.items() if n==max(nc.values()))
        check(oc==nc and candidates==['Arverni','Mandubii'] and nc['Arverni']==5,f'{key}: equal most-own-piece Verc candidates')
        check(ob['rng_sha256']==nb['rng_sha256']==oa['rng_sha256'] and na['rng_sha256']!=nb['rng_sha256'],f'{key}: old deterministic choice versus new tie draw')
        selected,expected_rng=rng_result(nb,candidates)
        check(selected==na['payload']==oa['payload']=='Mandubii' and expected_rng==na['rng_sha256'],f'{key}: independently reproduced new seeded tie selection')
        check(domains(x,y)==['rng'],f'{key}: first complete-Winter state change is solely RNG')
        report.update(category='new NP random tie',source_basis=['Chapter 8 §§8.3.2,8.3.4','Scenario - Pax Gallica first Winter Spring'],faction='Arverni',card_index=card,winter_count=nb['facts']['winter_count'],candidate_counts={r:nc[r] for r in candidates},old_destination=oa['payload'],new_destination=na['payload'],first_meaningful_boundary={'baseline':boundary(oa),'current':boundary(na)},explanation='Both place named Vercingetorix at Mandubii; the new path correctly draws for two equal candidates, changing later RNG. New named placement is at Spring beginning; moved placement ordering and unlock bookkeeping do not cause any earlier completed-Winter board difference.')
    else:
        ob=select(old,'before_phase:_adjust_belgae_forces',card);nb=select(new,'before_phase:_adjust_belgae_forces',card)
        check(ob['state_sha256']==nb['state_sha256'],f'{key}: identical state before Belgic Interlude adjustment')
        oc=select(old,'before_choice:interlude_leader_region',card,'Belgae');nc=select(new,'before_choice:interlude_leader_region',card,'Belgae')
        od=select(old,'after_choice:interlude_leader_region',card,'Belgae');nd=select(new,'after_choice:interlude_leader_region',card,'Belgae')
        oldcounts,newcounts=physical_counts(oc,'Belgae'),physical_counts(nc,'Belgae',exclude_leader=True)
        check(oldcounts==newcounts,f'{key}: old removed-incumbent versus new exclude-incumbent counts identical')
        best=max(newcounts.values());candidates=sorted(r for r,n in newcounts.items() if n==best)
        check(oc['rng_sha256']==nc['rng_sha256'],f'{key}: same RNG entering the first changed Interlude choice')
        oldorder=[r for r in rc.ALL_REGIONS if r in candidates]
        old_selected,old_rng=rng_result(oc,oldorder)
        check(old_selected==od['payload'] and old_rng==od['rng_sha256'],f'{key}: independent old choice/RNG reproduction')
        if len(candidates)==1:
            check(od['payload']==nd['payload']==candidates[0] and oc['rng_sha256']!=od['rng_sha256'] and nc['rng_sha256']==nd['rng_sha256'],f'{key}: unnecessary old one-candidate RNG draw removed')
            old_after=select(old,'after_phase:_adjust_belgae_forces',card);new_after=select(new,'after_phase:_adjust_belgae_forces',card)
            check(domains(old_after,new_after)==['rng'],f'{key}: Belgic adjustment results same except RNG')
            category='removed one-candidate Interlude RNG draw'
            explanation='Both place named Ambiorix at the same unique maximum. The old rng.choice still advances RNG; the new shared mandatory one-candidate selection does not. This is a deterministic implementation consequence of the scoped choice refactor; no arbitrary random tie exists here.'
        else:
            selected,new_rng=rng_result(nc,candidates)
            check(candidates==['Atrebates','Nervii'] and oldorder==['Nervii','Atrebates'],f'{key}: exact tie order change')
            check(selected==nd['payload']=='Atrebates' and od['payload']=='Nervii' and new_rng==nd['rng_sha256']==od['rng_sha256'],f'{key}: uniform choice maps same draw to reordered legal candidates')
            category='legal Interlude tie mapping changed'
            explanation='Both paths choose uniformly between the same two equal legal Regions. The shared choice request sorts candidate names, reversing their order from the original map insertion order. The same RNG draw therefore maps Nervii to Atrebates; this is not evidence that the old tie violated the printed rule.'
        report.update(category=category,source_basis=['A Scenario - The Gallic War, Adjust Forces: Belgae','Chapter 8 §8.3.4'],faction='Belgae',card_index=card,winter_count=nc['facts']['winter_count'],candidate_counts={r:newcounts[r] for r in candidates},old_candidate_order=oldorder,new_candidate_order=candidates,old_destination=od['payload'],new_destination=nd['payload'],first_meaningful_boundary={'baseline':boundary(od),'current':boundary(nd)},explanation=explanation)
    rows.append(report)
report={'status':'Independent source/trace review passed' if not failures else 'Independent review failed','reviewed_utc':datetime.now(timezone.utc).isoformat(),'reviewer':'spring_causal_review','checks':checks,'failures':failures,'cases_reviewed':len(rows),'accepted_trace_files':18,'all_exact_final_hashes_verified':not failures,'category_counts':dict(Counter(r['category'] for r in rows)),'source_identities':source_ids,'baseline_execution_commit':'a537511a1220ea4d2b0e94e63ab5cc581ef3a605','baseline_record_provenance':'Prior source071485 audited rows retain their actual historical commit04b; newly executed clean a537511 traces reproduce their exact final hashes. No old evidence relabeled.','original_balance_failure':'Gallic War Arverni4/20 to0/20, -20 percentage points exceeds unchanged inclusive15-point band; preserved, not converted to a pass.','artifact_recovery':'Original Gallic War14 current gzip is truncated and retained. Review uses the separately saved current-recaptured.json.gz with exact frozen source/final hash; one extra current game was run by parent only for artifact recovery.','instrumentation_review':'Original engine functions are called exactly once. Snapshot/hash/capsule queries do not execute planners and assert live RNG preservation. Added helper checkpoints are excluded only from common-core alignment, while every phase snapshot hash is checked and the implicated phase/choice data is reviewed directly.','reporting_and_bookkeeping':'The first observable report payload can differ earlier than gameplay. New first-Pax unlock flag and earlier named Spring entry are not counted alone as outcome causes. All full-state domains are retained, and common-core full states/decisions agree before the localized changed Winter.','cases':rows,'new_games_run_by_reviewer':0,'repository_changes_by_reviewer':0,'baseline_installation_authorized_by_this_review':False,'limitations':['First divergence explains the start of deterministic drift, not proof it alone caused a final winner; later corrected behavior may also contribute.','Two Interlude tie outcomes are legal mapping changes, and four are removal of an unnecessary one-candidate draw; do not describe these six as proof the old selected Region was illegal.','This covers nine changed-winner seeds, not all100 game paths or every possible human choice.']}
with (OUT/'independent-nine-case-source-review.json').open('x') as f:json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('cases','instrumentation_review','reporting_and_bookkeeping')},indent=2))
raise SystemExit(0 if not failures else 1)
