# Frontend review scope

Source revision: e62b0360c1b91032741ef8f6afa4d247c8ea2437. Comparator: 2991ea279062773548ec390a1da75f3e85381702.

Read CLAUDE.md, agent/session and relevant player documentation, the thirteen adopted-ruling register, original human-choice inventory, and comparison ledgers through round 7. The LoD human_qa harness contributes only the engineering pattern of exercising actual frontend paths with save/reload and invariant checks. No LoD game rule or external game reference determines a finding.

Two confirmed findings concern the paid Winter Campaign entry point. UI8-01 is missing unchanged Battle selection validation; UI8-02 is missing human March drop-off orchestration. They share a lower dispatcher call but need distinct repairs. Correcting one does not correct the other.

The standalone script uses public capability acquisition and winter_campaign_after_harvest. Its real SeatSession uses the same engine transaction hooks as the production Winter card path. It saves and reloads missing, rejected, accepted-then-paused, and completed states; verifies preserved pending IDs and journals; checks full encoded board/RNG rollback at every pause; and performs signature-checked deterministic transcript replay. This is a consumer-level controlled position, not a sampled full-game or full-Winter claim. All board/census checks pass. Off-route Allies and canonical Tribe restrictions additionally establish that no Faction already wins the preceding Victory check.

The ordinary repeated-Battle validator and ordinary March drop-off remain effective. A two-Region Aedui Ambush is also already rejected through Winter Campaign and is retained as a narrowing control, not a finding. No production files or repository tests were modified. Unconfirmed boundaries are omitted.

Run from fs-bot:

```sh
PYTHONPATH=. PYTHONHASHSEED=0 .venv/bin/python ../audit8-work/frontend/probe_winter_campaign.py
```

Hash seeds 0 and 987 produce the same output SHA-256:
`2b01284091455d74770725bd573e6494daab4047e975a5f1a57ad965738f3a7f`.
