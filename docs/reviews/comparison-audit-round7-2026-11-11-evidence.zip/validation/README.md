# Seventh comparison audit baseline validation

All new runs use the unchanged Falling Sky commit `c67d501711471bf790d805c017c2125b2c254639`, Python 3.12.14 and pytest 9.2.0. `source.json` records the clean initial source identity. Run from that repository root with an installed pytest and optional xdist environment. The captured output directory is named `validation` below for portability.

```sh
PYTHONHASHSEED=0 python -m pytest -q -n 5 --junitxml=validation/pytest.xml > validation/pytest.log 2>&1
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 41-44 --card-edition second-edition --workers 2 --out validation/bots-second > validation/bots-second.log 2>&1
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out validation/fuzz0.json > validation/fuzz0.log 2>&1
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out validation/fuzz987.json > validation/fuzz987.log 2>&1
PYTHONPATH=. python validation/verify_validation.py validation
```

The verifier checks every bot record's completion, rankings, inventory/structure, diagnostic severity, source digest and exact seed coverage. It checks both mixed-player JSON files and stdout byte-for-byte as well as the individual mixed-case records. Mixed cases execute twice internally for replay, so the two hash runs cover 20 distinct scenario/seed cases and 80 executions. A soft partial count is reported separately from hard findings.

The unchanged-source audit does not modify or refresh the balance baseline. No new legacy balance matrix was requested. `github-actions.json` separately records the completed successful CI and Package installation runs for the audited commit; these are prior GitHub runs, not the local fresh validation.
