"""Validate each small repair in isolation before its individual commit."""
import hashlib, json, os, shutil, subprocess, sys
from pathlib import Path
import xml.etree.ElementTree as ET

BASE = Path(__file__).resolve().parent.parent
SOURCE = BASE / 'fs-bot'
TARGET = BASE / 'fs-cheap-validation'
OUT = Path(__file__).resolve().parent
STAGES = [
 ('supply', 'Keep malformed Supply reconsideration pending for human correction',
  ['fs_bot/engine/supply_reconsideration.py','fs_bot/tests/test_supply_refusal_malformed.py']),
 ('transfers', 'Reject game-run Arverni Resource transfers per A1.5.2 and A1.8',
  ['fs_bot/commands/transfer.py','fs_bot/cli/human_plan.py','fs_bot/tools/seat_session.py','fs_bot/tests/test_transfer_scenario_eligibility.py']),
 ('regions', 'Enforce one Seize or Entreat selection per Region under sections 3.1 and 4.1',
  ['fs_bot/engine/action_validation.py','fs_bot/engine/free_actions.py','fs_bot/tests/test_repeated_seize_entreat_regions.py']),
 ('losses', 'Enforce mandatory Battle casualty tiers per sections 3.2.4 and 3.3.4',
  ['fs_bot/battle/losses.py','fs_bot/tests/test_battle_loss_tiers.py']),
 ('setup', 'Start sole human Belgae with Ambiorix in The Great Revolt',
  ['fs_bot/state/setup.py','fs_bot/cli/app.py','fs_bot/tools/llm_seat.py','fs_bot/tests/test_great_revolt_belgae_setup.py']),
 ('policy-setup', 'Apply human-seat setup rules to validation and policy games',
  ['fs_bot/tools/player_fuzz.py','fs_bot/tools/heuristic_selfplay.py','fs_bot/tests/test_great_revolt_validation_setup.py','fs_bot/tests/test_strategy_harness.py'])]

def git(*args):
    return subprocess.check_output(['git', *args], cwd=TARGET, text=True).strip()

def identity():
    files = sorted(TARGET.glob('fs_bot/**/*.py'), key=lambda p:p.relative_to(TARGET).as_posix())
    h=hashlib.sha256()
    for p in files:
        h.update(p.relative_to(TARGET).as_posix().encode()); h.update(b'\0'); h.update(p.read_bytes())
    return {'python_files':len(files),'python_sha256':h.hexdigest()}

record = OUT/'commit-validation.json'
results = json.loads(record.read_text()) if record.exists() else []
env=os.environ.copy();env.update(PYTHONPATH=str(TARGET),PYTHONHASHSEED='0')
for name,message,files in STAGES:
    if any(x['stage']==name for x in results):
        continue
    for n in files:
        shutil.copyfile(SOURCE/n,TARGET/n)
    command=[sys.executable,'-m','pytest','-q','-n','6',f'--junitxml={OUT/name}.xml']
    print(f'{name}: full suite starting',flush=True)
    with (OUT/(name+'.pytest.txt')).open('w') as log:
        run=subprocess.run(command,cwd=TARGET,env=env,stdout=log,stderr=subprocess.STDOUT)
    if run.returncode:
        print(f'{name}: FAILED; see {OUT/name}.pytest.txt',flush=True)
        raise SystemExit(run.returncode)
    suite=ET.parse(OUT/(name+'.xml')).getroot().find('testsuite')
    assert suite is not None and all(suite.attrib[x]=='0' for x in ('errors','failures','skipped'))
    git('diff','--check')
    git('add',*files)
    git('commit','-m',message)
    entry={'stage':name,'commit':git('rev-parse','HEAD'),'message':message,'files':files,
           'pytest':suite.attrib,'command':command,'exit_code':run.returncode,**identity()}
    results.append(entry);record.write_text(json.dumps(results,indent=2)+'\n')
    print(f'{name}: {suite.attrib["tests"]} passed; committed {entry["commit"][:7]}',flush=True)
