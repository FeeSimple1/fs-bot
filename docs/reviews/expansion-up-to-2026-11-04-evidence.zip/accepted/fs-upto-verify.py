from pathlib import Path
import json,re,subprocess
from fs_bot import rules_consts as rc
from fs_bot.tools.validation_metadata import source_identity
parent='feaed4bce9f1be8ebe2a514f074332958e091ee6';source=source_identity()
assert source['source_sha256']=='e81fb7e8e9c8db1965ce44ebcb13b4f3d40f6d6507341ada0a0b6d6d25652c58'
records={}
for label,directory in [('parent','/tmp/fs-upto-bots-parent'),('final','/tmp/fs-upto-bots-final')]:
 rows=[json.loads(x) for x in Path(directory+'/games.jsonl').read_text().splitlines()]
 records[label]={(r['scenario'],r['seed']):r for r in rows}
 assert len(rows)==10 and set(records[label])=={(s,n) for s in rc.ALL_SCENARIOS for n in (1,2)}
 for row in rows:
  assert all(row[k] for k in ('completed','game_completed','audit_completed','final_state_sha256'))
  assert not row['errors'] and not row['integrity_findings']
  assert len(row['final_ranking'])==4 and not row['winner_differs_from_highest_margin'] and not row['engine_ranking_output_missing']
  assert all(d['severity']=='legal-decline' for d in row['diagnostics'])
ignored={'seconds','commit','source_sha256'}
for k,p in records['parent'].items():
 c=records['final'][k]
 assert {f:v for f,v in p.items() if f not in ignored}=={f:v for f,v in c.items() if f not in ignored},k
assert json.loads(Path('/tmp/fs-upto-bots-final/metadata.json').read_text())['source_sha256']==source['source_sha256']
x=json.loads(Path('/tmp/fs-upto-mixed0.json').read_text());y=json.loads(Path('/tmp/fs-upto-mixed987.json').read_text())
assert x==y and not x['hard_findings'] and x['partial']==0 and all(r['game_completed'] for r in x['records'])
assert x['metadata']['source_sha256']==source['source_sha256']
protected=[p for p in Path('Reference Documents').rglob('*') if p.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
assert len(protected)==49
for p in protected:assert p.read_bytes()==subprocess.check_output(['git','show',parent+':'+str(p)])
result={'date':'2026-11-04','timezone':'America/Chicago','source':source,'python_files':len(list(Path('fs_bot').rglob('*.py'))),'protected_files':len(protected),'protected_files_unchanged':True,'targeted_passed':292,'new_tests':87,'parent_proof':{'behavioral_failures':17,'controls_passed':8,'deselected':62},'bots':{'games':10,'all_completed_and_audited':True,'all_gameplay_fields_and_final_hashes_equal':True,'excluded':sorted(ignored)},'mixed':x,'mixed_complete_json_equal':True,'hash_seeds':[0,987],'mixed_executions_including_replay':40,'original_progress':{'closed':33,'total':50,'percent':66,'open':17},'remaining':'CV-PERSISTENCE, BATTLE-RAMPAGE-VICTIM, BE-09 and the NPC Intimidate targeting lead remain open'}
balance_log=Path('/tmp/fs-upto-balance.log').read_text()
assert 'OK: balance within band (' in balance_log
rows=re.findall(r'^\[(.*?) seed=\s*(\d+)\] winner=(.*?) \((\d+) cards\)$',balance_log,re.M)
assert len(rows)==100 and {(r[0],int(r[1])) for r in rows}=={(sc,n) for sc in rc.ALL_SCENARIOS for n in range(1,21)}
deltas=[abs(int(v)) for v in re.findall(r'\(([+-]\d+)%\)',balance_log)]
assert deltas and max(deltas)<=15
changes=int(re.search(r'OK: balance within band \((\d+) winner changes\)',balance_log)[1])
result['balance_smoke']={'games':100,'seeds':list(range(1,21)),'scenarios':list(rc.ALL_SCENARIOS),'band_percentage_points':15,'maximum_absolute_delta_percentage_points':max(deltas),'historical_baseline_winner_changes':changes,'baseline_unchanged':True,'passed':True,'results':[{'scenario':r[0],'seed':int(r[1]),'winner':r[2],'cards':int(r[3])} for r in rows]}
Path('/tmp/fs-upto-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':source,'new_tests':87,'targeted':292,'bots_equal':10,'mixed_equal':True,'hard_findings':x['hard_findings'],'partials':x['partial'],'human_turns':x['human_turns'],'event_turns':x['event_turns'],'events_ok':x['events_ok'],'protected':len(protected),'balance_max_delta_pp':max(deltas),'historical_winner_changes':changes}))
