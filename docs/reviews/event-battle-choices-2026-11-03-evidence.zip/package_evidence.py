"""Package this batch after acceptance, retaining original and failed evidence."""
from pathlib import Path
import hashlib, json, zipfile

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'fs-bot'
OUT = REPO / 'docs/reviews/event-battle-choices-2026-11-03-evidence.zip'
assert not OUT.exists(), 'Do not overwrite an existing evidence archive'
files = sorted(p for p in HERE.rglob('*') if p.is_file()
               and '__pycache__' not in p.parts
               and p.name not in ('archive-index.json', 'archive-check.json', 'update_docs.py'))
index = {p.relative_to(HERE).as_posix(): {
    'bytes': p.stat().st_size,
    'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
(HERE / 'archive-index.json').write_text(json.dumps(index, indent=2) + '\n')
with zipfile.ZipFile(OUT, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for p in files + [HERE / 'archive-index.json']:
        archive.write(p, p.relative_to(HERE).as_posix())
with zipfile.ZipFile(OUT) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(index) | {'archive-index.json'}
    for name, record in index.items():
        data = archive.read(name)
        assert len(data) == record['bytes']
        assert hashlib.sha256(data).hexdigest() == record['sha256']
record = {'path': str(OUT.relative_to(REPO)), 'bytes': OUT.stat().st_size,
          'sha256': hashlib.sha256(OUT.read_bytes()).hexdigest(),
          'indexed_files': len(index), 'integrity_passed': True}
(HERE / 'archive-check.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
