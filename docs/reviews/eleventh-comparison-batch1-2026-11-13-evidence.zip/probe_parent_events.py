"""Public Event audit witnesses and controls; emits deterministic JSON only."""
import argparse
import copy
import json
import sys
from pathlib import Path
parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, default=Path('/workspace/scratch/521fc7ecea8c/falling-sky'))
args = parser.parse_args()
sys.path.insert(0, str(args.repo))
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import find_leader, get_leader_in_region, place_piece, remove_piece
from fs_bot.bots.bot_common import should_decline_event
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.cards.card_effects import _ally_tribe, _unally_tribe
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT, ACTION_COMMAND_SA, get_sop_factions
from fs_bot.state.setup import setup_scenario
from fs_bot.state.serialize import encode
from fs_bot.state.state_schema import validate_state, check_structural_integrity

EFFECT_FIELDS = ('spaces', 'tribes', 'available', 'resources', 'senate', 'legions_track',
                 'fallen_legions', 'removed_pieces', 'markers', 'capabilities',
                 'capability_owners', 'eligibility', 'forced_ineligible',
                 'stay_eligible', 'event_modifiers')


def integrity(state):
    result = {'census': validate_state(state), 'structure': check_structural_integrity(state)}
    assert result['census'] == result['structure'] == []
    return result


def ready(scenario, card, seed=1, seats=None):
    state = setup_scenario(scenario, seed=seed)
    state.update(current_card=card, current_card_id=card, can_play_event=True,
                 non_player_factions=set(get_sop_factions(state)) if seats is None else set(seats))
    integrity(state)
    return state


def effects(state):
    return {key: copy.deepcopy(state.get(key)) for key in EFFECT_FIELDS}


def leader(state):
    origin = find_leader(state, rc.ARVERNI)
    return {'region': origin, 'name': get_leader_in_region(state, origin, rc.ARVERNI) if origin else None,
            'available': state['available'][rc.ARVERNI][rc.LEADER]}


def event(state, faction, params, card=None, shaded=False):
    card = state['current_card'] if card is None else card
    state.update(current_card=card, current_card_id=card, can_play_event=True)
    result = execute_decision(state, faction, {'action': ACTION_EVENT, 'player_action': {
        'command': rc.FIRST_DID_EVENT, 'details': {'card_id': card,
            'text_preference': rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,
            'event_params': params}}})
    assert result['executed'] and not result.get('errors'), result
    return {'result': result, 'after_integrity': integrity(state)}


def natural(state, faction):
    before = effects(state)
    pre = integrity(state)
    encoded = encode(state)
    decline = should_decline_event(state, state['current_card'], faction)
    assert encode(state) == encoded, 'availability query mutates board or RNG'
    action = dispatch_bot_turn(state, faction)
    assert action['command'] == rc.FIRST_DID_EVENT, action
    result = execute_decision(state, faction, {'action': ACTION_EVENT, 'bot_action': action})
    assert result['executed'] and not result.get('errors'), result
    return {'before_integrity': pre, 'after_integrity': integrity(state),
            'should_decline_event': decline, 'action': action, 'result': result,
            'changed_effect_fields': [key for key in EFFECT_FIELDS if before[key] != state.get(key)]}


def fallback(state, faction):
    trial = copy.deepcopy(state)
    trial['can_play_event'] = False
    before = effects(trial)
    action = dispatch_bot_turn(trial, faction)
    assert action['command'] not in (rc.FIRST_DID_EVENT, 'Pass'), action
    result = execute_decision(trial, faction, {'action': ACTION_COMMAND_SA, 'bot_action': action})
    assert result['executed'] and not result.get('errors'), result
    return {'action': action, 'result': result, 'after_integrity': integrity(trial),
            'changed_effect_fields': [k for k in EFFECT_FIELDS if before[k] != trial.get(k)]}


lucterius = []
for scenario in (rc.SCENARIO_RECONQUEST, rc.SCENARIO_GREAT_REVOLT):
    for form in ('named', 'available', 'successor'):
        state = ready(scenario, 19)
        origin = find_leader(state, rc.ARVERNI)
        assert origin
        if form != 'named':
            remove_piece(state, origin, rc.ARVERNI, rc.LEADER)
            if form == 'successor':
                place_piece(state, origin, rc.ARVERNI, rc.LEADER, leader_name=rc.SUCCESSOR)
        integrity(state)
        explicit = copy.deepcopy(state)
        before = leader(state)
        alternate = fallback(state, rc.ARVERNI)
        observed = natural(state, rc.ARVERNI)
        assert observed['changed_effect_fields'] == []
        assert leader(state) == before
        control = event(explicit, rc.ARVERNI, {'target_region': origin}, shaded=True)
        if form == 'named':
            assert leader(explicit) == before
        else:
            assert leader(explicit) == {'region': origin, 'name': rc.VERCINGETORIX, 'available': 0}
        lucterius.append({'scenario': scenario, 'leader_form': form, 'initial_leader': before,
                          'observed': observed, 'final_leader': leader(state),
                          'explicit_target_control': {**control, 'final_leader': leader(explicit)},
                          'event_disabled_control': alternate})

assembly = []
for scenario, faction in [(rc.SCENARIO_PAX_GALLICA, rc.ROMANS),
                          (rc.SCENARIO_PAX_GALLICA, rc.AEDUI),
                          (rc.SCENARIO_GREAT_REVOLT, rc.AEDUI),
                          (rc.SCENARIO_ARIOVISTUS, rc.ROMANS),
                          (rc.SCENARIO_ARIOVISTUS, rc.AEDUI),
                          (rc.SCENARIO_GALLIC_WAR, rc.AEDUI)]:
    state = ready(scenario, 52, seats={faction})
    _unally_tribe(state, rc.TRIBE_CARNUTES)
    integrity(state)
    before = dict(state['resources'])
    targets = [rc.BELGAE] if scenario in rc.ARIOVISTUS_SCENARIOS else [rc.ARVERNI, rc.BELGAE]
    assert all(before[target] > 0 for target in targets)
    explicit = copy.deepcopy(state)
    blocked = copy.deepcopy(state)
    assert _ally_tribe(blocked, rc.TRIBE_CARNUTES, rc.ARVERNI)
    blocked_before = effects(blocked)
    blocked_control = event(blocked, faction, {'target_factions': targets})
    assert effects(blocked) == blocked_before
    observed = natural(state, faction)
    assert observed['changed_effect_fields'] == []
    control = event(explicit, faction, {'target_factions': targets})
    expected = {**before, **{target: max(0, before[target] - 8) for target in targets}}
    assert explicit['resources'] == expected
    assembly.append({'scenario': scenario, 'faction': faction, 'targets': targets,
                     'initial_resources': before, 'observed': observed,
                     'final_resources': dict(state['resources']),
                     'blocked_prerequisite_control': {**blocked_control, 'changed_effect_fields': []},
                     'explicit_target_control': {**control, 'final_resources': dict(explicit['resources'])}})

loyalties = []
for scenario in (rc.SCENARIO_PAX_GALLICA, rc.SCENARIO_ARIOVISTUS, rc.SCENARIO_GALLIC_WAR):
    for insertion_order in ((12, 55), (55, 12)):
        state = ready(scenario, 50, seats={rc.ROMANS})
        for card in insertion_order:
            event(state, rc.ROMANS if card == 12 else rc.BELGAE, {}, card=card, shaded=card == 55)
        state.update(current_card=50, current_card_id=50, can_play_event=True)
        explicit = copy.deepcopy(state)
        before = dict(state['capabilities'])
        observed = natural(state, rc.ROMANS)
        removed = set(before) - set(state['capabilities'])
        assert removed == {insertion_order[0]}
        control = event(explicit, rc.ROMANS, {'target_capability': 55})
        assert explicit['capabilities'] == {12: rc.EVENT_UNSHADED}
        loyalties.append({'scenario': scenario, 'acquisition_order': list(insertion_order),
                          'initial_capabilities': before, 'observed': observed,
                          'actual_removed': sorted(removed), 'expected_removed': [55],
                          'wrong_priority': removed != {55},
                          'explicit_target_control': {**control, 'remaining_capabilities': dict(explicit['capabilities'])}})

print(json.dumps({'audited_commit': '702d60a3754ce94a73ead0d0148d647232ecd816',
                  'EV11-01': lucterius, 'EV11-02': assembly, 'EV11-03': loyalties,
                  'summary': {'lucterius_cases': len(lucterius),
                              'assembly_cases': len(assembly),
                              'loyalties_cases': len(loyalties),
                              'loyalties_wrong_priority': sum(x['wrong_priority'] for x in loyalties)}},
                 indent=2, sort_keys=True))
