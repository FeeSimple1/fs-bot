"""Seventh comparison Event witnesses; assertions describe audited defects.
Run: PYTHONPATH=<fs-bot-root> python probe_events.py
Requires audited source c67d501711471bf790d805c017c2125b2c254639.
"""
from copy import deepcopy
import json
from fs_bot import rules_consts as rc
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.state.serialize import encode
from fs_bot.board.pieces import place_piece, move_piece, count_pieces, get_available
from fs_bot.board.control import calculate_control
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.bots.bot_common import should_decline_event
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT

KEYS = ('spaces','tribes','available','resources','eligibility','capabilities','capability_owners','markers','event_modifiers','fallen_legions','senate','legions_track','removed_legions','forced_ineligible','stay_eligible')
def effects(s): return {k:encode(s.get(k,{})) for k in KEYS}
def clean(s):
    assert count_pieces(s,rc.PROVINCIA,rc.ROMANS,rc.FORT)==1
    assert validate_state(s)==[],validate_state(s)
    assert check_structural_integrity(s)==[],check_structural_integrity(s)
def ready(s,card):
    s['non_player_factions']={rc.ROMANS,rc.AEDUI,rc.BELGAE,rc.GERMANS if s['scenario'] in rc.ARIOVISTUS_SCENARIOS else rc.ARVERNI}
    s.update(current_card=card,current_card_id=card,can_play_event=True)
    clean(s)
    return s
def board(card, scenario=rc.SCENARIO_GREAT_REVOLT):
    s=build_initial_state(scenario,seed=1)
    place_piece(s,rc.PROVINCIA,rc.ROMANS,rc.FORT)
    for faction in s['resources']:
        if faction!=rc.ARVERNI or scenario not in rc.ARIOVISTUS_SCENARIOS:
            s['resources'][faction]=10
    return ready(s,card)
def bot(s,faction,card):
    assert not should_decline_event(s,card,faction)
    before=effects(s)
    a=dispatch_bot_turn(s,faction)
    assert a['command']=='Event',a
    result=execute_decision(s,faction,{'action':ACTION_EVENT,'bot_action':a})
    assert result['executed'] and not result.get('errors'),result
    clean(s)
    return {'action':a,'execution':result,'effects_unchanged':before==effects(s)}
def explicit(s,faction,card,params=None,shaded=True):
    result=execute_decision(s,faction,{'action':ACTION_EVENT,'player_action':{'command':'Event','details':{'card_id':card,'text_preference':rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,'event_params':params or {}}}})
    assert result['executed'] and not result.get('errors'),result
    clean(s)
    return result

def oppida():
    s=board(28)
    # One Subdued City remains eligible for Belgae. Every other City already
    # has another Faction's Ally; no supply scarcity or tie obscures the result.
    for city,tribe in rc.CITY_TO_TRIBE.items():
        if tribe==rc.TRIBE_BITURIGES: continue
        owner=rc.ARVERNI if tribe==rc.TRIBE_ARVERNI else rc.AEDUI
        assert _ally_tribe(s,tribe,owner)
    clean(s)
    full=deepcopy(s);existing=deepcopy(s)
    assert get_available(s,rc.BELGAE,rc.CITADEL)==1
    result=bot(s,rc.BELGAE,28)
    assert count_pieces(s,rc.BITURIGES,rc.BELGAE,rc.ALLY)==1
    assert count_pieces(s,rc.BITURIGES,rc.BELGAE,rc.CITADEL)==0
    assert get_available(s,rc.BELGAE,rc.CITADEL)==1
    control=explicit(full,rc.BELGAE,28,{'ally_placements':[{'tribe':rc.TRIBE_BITURIGES,'faction':rc.BELGAE}],'citadel_upgrades':[rc.CITY_AVARICUM]})
    assert count_pieces(full,rc.BITURIGES,rc.BELGAE,rc.CITADEL)==1
    assert count_pieces(full,rc.BITURIGES,rc.BELGAE,rc.ALLY)==0
    assert _ally_tribe(existing,rc.TRIBE_BITURIGES,rc.BELGAE)
    clean(existing)
    existing_result=bot(existing,rc.BELGAE,28)
    assert count_pieces(existing,rc.BITURIGES,rc.BELGAE,rc.CITADEL)==1
    return {'bot':result,'observed':{'new_allies':1,'citadels':0,'available_citadels':1},'full_plan_control':control,'control_citadels':1,'preexisting_ally_control':existing_result,'preexisting_ally_control_citadels':1}

def missing_np_plans():
    rows=[]
    s=board('A19',rc.SCENARIO_ARIOVISTUS)
    place_piece(s,rc.AEDUI_REGION,rc.ROMANS,rc.LEADER,leader_name=rc.CAESAR)
    assert _ally_tribe(s,rc.TRIBE_BITURIGES,rc.BELGAE)
    clean(s);control=deepcopy(s)
    result=bot(s,rc.ROMANS,'A19')
    assert result['effects_unchanged']
    expected=explicit(control,rc.ROMANS,'A19',{'replacements':[{'tribe':rc.TRIBE_BITURIGES}]},shaded=False)
    assert control['tribes'][rc.TRIBE_BITURIGES]['allied_faction']==rc.ROMANS
    rows.append({'case':'A19 Roman unshaded','bot':result,'observed_owner':rc.BELGAE,'control':expected,'control_owner':rc.ROMANS})
    for faction in (rc.BELGAE,rc.GERMANS):
        s=ready(setup_scenario(rc.SCENARIO_ARIOVISTUS,seed=1),'A26')
        clean(s);control=deepcopy(s)
        german_before={region:calculate_control(s,region)==rc.GERMANIC_CONTROL for region in s['spaces']}
        available=get_available(control,rc.ARVERNI,rc.WARBAND)
        assert available>=12
        result=bot(s,faction,'A26')
        assert result['effects_unchanged']
        before=count_pieces(control,rc.AEDUI_REGION,rc.ARVERNI,rc.WARBAND)
        expected=explicit(control,faction,'A26',{'placements':[{'region':rc.AEDUI_REGION,'count':12}]})
        assert count_pieces(control,rc.AEDUI_REGION,rc.ARVERNI,rc.WARBAND)==before+12
        # The German instruction is preserved by the positive comparison.
        assert all(not had_control or calculate_control(control,region)==rc.GERMANIC_CONTROL for region,had_control in german_before.items())
        rows.append({'case':f'A26 {faction} shaded','bot':result,'observed_placed':0,'control':expected,'control_placed':12,'control_preserves_all_german_control':True})
    return rows

def ineffective_rhenus():
    rows=[]
    for faction in (rc.BELGAE,rc.GERMANS):
        s=ready(setup_scenario(rc.SCENARIO_ARIOVISTUS,seed=1),'A18')
        control=deepcopy(s);fallback=deepcopy(s)
        # The untouched scenario has its Roman Legions in Provincia, beyond
        # one Region of Germania. The exact same NP card selection is unused.
        result=bot(s,faction,'A18')
        assert result['effects_unchanged']
        move_piece(control,rc.PROVINCIA,rc.TREVERI,rc.ROMANS,rc.LEGION)
        clean(control)
        resources=control['resources'][rc.ROMANS]
        positive=explicit(control,faction,'A18')
        assert control['resources'][rc.ROMANS]==max(0,resources-6)
        assert control['forced_ineligible'][rc.ROMANS]==1
        fallback['can_play_event']=False
        alternative=dispatch_bot_turn(fallback,faction)
        assert alternative['command'] not in ('Event','Pass'),alternative
        rows.append({'faction':faction,'bot':result,'positive_control':positive,'control_resources_removed':6,'control_roman_forced_ineligible':1,'available_fallback':alternative})
    return rows

if __name__=='__main__':
    print(json.dumps({'BE7-01':oppida(),'BE7-02':missing_np_plans(),'BE7-03':ineffective_rhenus()},sort_keys=True,indent=2))
