# Seventh audit — Battle partition

Audited `c67d501711471bf790d805c017c2125b2c254639` without production changes.

Inspected both ordinary attack and casualty calculators, ordinary Battle orchestration,
fixed modified Event Battles, German and Arverni scheduled Battles, Slingers and Horse
choice helpers, Ballistae and Elite casualty hooks. Used Liberty or Death's
`coin-implementation-lessons.md` (A/C/F) and `docs/audit_set_but_never_applied_s76.md`
for integration-pattern guidance only. Falling Sky's supplied references and current
project rulings remain the rules authority.

`probe_battle.py` has fifteen public-entrypoint cases. Every board starts with
`build_initial_state`, uses canonical piece placement, retains the permanent Provincia
Fort, acquires capabilities through actual Event execution, and passes both census and
structural checks before and after. Seed 7 is fixed. The output preserves active
capability sides and owners and both observed and source-required results.

## Confirmed groups

- BM7-01 — command capability hooks missing on remaining fixed Event/automatic
  Arverni paths. Numeric 2/25/36 Slingers, numeric36 shaded Horse, and full
  Arverni Phase Slingers share one counted integration group.
- BM7-02 — Ballistae Fort casualty threshold ignores Stalwart cancellation.

The exact numeric2 control has no Legion, so its printed first-Legion exception
has no effect. Comparing it to ordinary public Battle isolates the lost Slingers
hook. Morasses retains its no-Retreat/no-Counterattack/Hidden exception while still
owing the unrelated capability effects. The Arverni fixture exercises complete
Rally/March/Raid/Battle sequencing: Rally adds the legal Carnutes Ally, Frost skips
March, zero Roman Resources prevents Raid, and Battle is mandatory under A6.2.4.

## Held or delegated leads

- Other direct Event Battle consumers (Numidians, Camulogenus, Litaviccus, various
  expansion Events) warrant the same wiring review, but are not separately counted
  without a final public witness.
- Archers/Elite cancellation by A31 remains a source-and-fixture lead. Elite requires
  a lawful post-Interlude named Arverni Leader, and late-played card precedence must
  be controlled. No illegal first-half Vercingetorix fixture was used.
- Ariovistus + Stalwart + enemy Abatis forecast drift was handed to the bot partition:
  `calculate_losses` checks the raw Abatis marker when deciding Ariovistus doubling,
  while the execution calculator uses the effective/cancelled marker. No bot result
  is claimed by this partition.
- The old BM6-02 German paths were reviewed as comparison controls and not reopened.
  Its own limitations explicitly identify automatic Arverni and fixed Events as
  previously unproved static risks.

These are controlled legal positions, not measured natural frequency or a proof that
all possible Battle combinations are now exhausted. No production fixes, no baseline
changes, and no new unresolved source question was required for the counted groups.
