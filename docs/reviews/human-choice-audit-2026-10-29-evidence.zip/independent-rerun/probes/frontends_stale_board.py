"""Reproduce CLI b/board showing the pre-Build state at a following March.

Only measurement wraps the Command collector; every choice uses real menus.
Run with the audit venv Python and PYTHONPATH pointing at fs-bot.
"""
import io
import json
import re
from pathlib import Path
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.cli import human_plan, menus
from fs_bot.cli.display import format_board
from fs_bot.engine.game_engine import ACTION_COMMAND_SA, start_game
from fs_bot.state.setup import setup_scenario
from fs_bot.state.serialize import encode
from fs_bot.state.state_schema import validate_state
from fs_bot.board.pieces import count_pieces

out = io.StringIO()
state = setup_scenario(rc.SCENARIO_PAX_GALLICA, seed=13)
state['non_player_factions'] = {rc.ARVERNI, rc.AEDUI, rc.BELGAE}
start_game(state)
state['_cli_action_windows'] = True
assert not validate_state(state)
before = encode(state)
observations = {}
original_collect = human_plan._collect_command_plan


def measured_collect(board, faction, cmd, *args, **kwargs):
    observations['command'] = cmd
    observations['actual_resources'] = board['resources'][rc.ROMANS]
    observations['actual_forts'] = count_pieces(board, rc.ATREBATES, rc.ROMANS, rc.FORT)
    observations['expected_board'] = format_board(board)
    assert not validate_state(board)
    return original_collect(board, faction, cmd, *args, **kwargs)


class Player:
    def __init__(self):
        self.pos = 0
        self.picked_region = False
        self.inspect_start = None

    def readline(self):
        text = out.getvalue()
        delta, self.pos = text[self.pos:], len(text)
        if self.inspect_start is not None:
            observations['displayed_board'] = text[self.inspect_start:]
            return ''
        options = re.findall(r'^\s*(\d+)\) (.*)$', delta, re.M)
        if 'March OUT of which Region' in delta:
            self.inspect_start = len(text)
            return 'b\n'
        if 'Build in which Region' in delta:
            wanted = '(done)' if self.picked_region else rc.ATREBATES
            self.picked_region = True
        elif 'Which accompanying Command?' in delta:
            wanted = 'March'
        else:
            wanted = next((label for label in (
                'Finish voluntary removal',
                'Special Activity first, then Command',
                'Build', 'Place a Fort', 'Skip this Build option')
                if any(o[1] == label for o in options)), None)
        match = next((number for number, label in options if label == wanted), None)
        if match is None:
            raise AssertionError(f'Unexpected prompt: {delta}')
        return match + '\n'


menus.set_board_hook(lambda: out.write(format_board(state)))
try:
    with patch.object(human_plan, '_collect_command_plan', measured_collect):
        try:
            human_plan.collect_player_action(state, rc.ROMANS, ACTION_COMMAND_SA, Player(), out)
        except EOFError:
            pass
finally:
    menus.set_board_hook(None)

assert observations['command'] == 'March'
assert observations['actual_resources'] == 6
assert observations['actual_forts'] == 1
assert observations['expected_board'] not in observations['displayed_board']
assert format_board(state) in observations['displayed_board']
assert encode(state) == before
output = Path(__file__).with_suffix('.out.txt')
output.write_text(out.getvalue())
result = {k: v for k, v in observations.items() if not k.endswith('board')}
result.update(displayed_resources=state['resources'][rc.ROMANS],
              displayed_forts=count_pieces(state, rc.ATREBATES, rc.ROMANS, rc.FORT),
              live_state_unchanged=True, transcript=str(output))
print(json.dumps(result, indent=2))
