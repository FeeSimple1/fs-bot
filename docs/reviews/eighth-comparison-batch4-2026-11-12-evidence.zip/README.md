# Eighth comparison repair evidence, Batch 4

Parent commit: `0443eecba4d717bbfc6a89fc9d83e1645e13807b`. The runs used
Python 3.12.14. The repaired digest covers 615 Python files.

Run the evidence verifier from the repaired checkout with this archive
extracted.

```sh
PYTHONPATH=. python /path/to/evidence/verify_results.py
```

`parent-final` records the directed module on the parent. Fifteen cases
reproduce the three findings and three controls pass. `focused-final`
covers the adjacent Event, Battle, and bot tests. `pytest-before-baseline`
records the full run with the prior baseline and its canary failure.
`pytest-final` records the full run with the refreshed baseline. Both use
five pytest-xdist workers and hash seed 0.

```sh
PYTHONHASHSEED=0 PYTHONPATH=. python -m pytest -q /path/to/evidence/test_eighth_comparison_events.py
```

`final-legacy` covers seeds 1–20 across all scenarios. `final-second`
covers second-edition seeds 45–48. Both use hash seed 0 and two workers.
`fuzz0-final` and `fuzz987-final` cover the same second-edition seeds.
`fuzz-ci0` and `fuzz-ci7` cover second-edition CI seeds 201–203. Both
mixed samples use reactions, Events, and internal replay.

The trace script records results, starting and ending board/RNG hashes,
and the affected Events' derived parameters. Run it from each checkout
on the matching case list.

```sh
PYTHONHASHSEED=0 PYTHONPATH=. python /path/to/evidence/trace_events.py /path/to/evidence/bot-changed.json
PYTHONHASHSEED=0 PYTHONPATH=. python /path/to/evidence/trace_events.py /path/to/evidence/mixed-changed.json --mixed
```

The balance logs compare the same 100 legacy games before and after the
baseline refresh. The 15-game canary uses its original band. The two
baseline files record the reviewed inputs. Parent game and mixed-player
records are from the Batch 3 archive. `SHA256SUMS` records the digest of
each other file in this archive.
