# Named Event durable-session regression handoff

Owned file: `fs_bot/tests/test_named_event_sessions.py` only. No production,
CLI, reference, baseline, or project-documentation edits; no commit.

25 new cases passed on the integrated working source in
`sessions-integrated-03.log` (0.62 seconds). Root owns the final frozen-source
full suite and integration checks.

Coverage uses the real `SeatSession`, actual Event handlers, engine transaction
rollback, normal save/load serialization, and exact recorded-request replay:

- Cards 2U,18U,23U,26S and A18U, each executed by Belgae with the named human
  Roman/Arverni seat. No missing input silently becomes a bot choice.
- Invalid target, numeric default, null and forged acting-faction responses keep
  the same pending ID, request, pending board, live board/RNG and empty journal.
- Current/upcoming card names and a real Resource change are displayed before
  the named owner's choice.
- Roman acceptance across original/second-edition profiles persists through
  save/load and replays identical requests, outcomes, complete state and RNG.
  Tests assert actual Legion source allocation, all German visibility and Ally
  removals, A18 Settlement/Successor removals, and the precise Razed City plus
  Roman Resources.
- Explicit decline preserves physical state. Explicit defaults are journaled as
  choices rather than normalized to missing input.
- Gobannitio has three multi-stage saved paths: accepted empty lists, exact
  Cadurci replacement while retaining the other Ally, and explicit default.
  Each reaches Arverni's independently scoped free Rally on the updated board.
  An invalid out-of-area Rally preserves the earlier accepted decision and
  later pending ID; save/load and exact full replay complete the one-Warband
  free Rally. Whole-effect decline skips that sequence entirely.

Failure provenance:

- `sessions-before-01.log`: initial18 cases on pre-implementation source expose
  absent named-owner prompts. A18 was added afterward, raising the initial
  integrated suite to23 cases; all five fixtures pass `validate_state`.
- `sessions-integrated-01.log`:22 passed,1 failed because the first test version
  interpreted Card26 decline as skipping only Ally rearrangement. Root's final
  reviewed interpretation is whole optional sentence decline; empty lists
  instead accept zero rearrangement and preserve the later Rally. The failure
  was a superseded test interpretation, not a remaining implementation bug.
- `sessions-integrated-02.log`:23 passed after making the smaller-selection case
  explicit with empty lists.
- `sessions-integrated-03.log`:25 passed after adding separate whole-effect26
  decline and default-then-Rally replay coverage. Earlier logs are preserved.
