from pathlib import Path
import hashlib, json, platform, subprocess, xml.etree.ElementTree as ET, zipfile
from fs_bot.tools.validation_metadata import source_identity

prefix='rampage-victims-2026-11-04'
result=json.loads(Path('/tmp/fs-rampage-victim-results.json').read_text())
assert source_identity()==result['source']
suite=ET.parse('/tmp/fs-rampage-victim-full.xml').getroot().find('testsuite')
assert suite.attrib['tests']=='8465' and all(suite.attrib[k]=='0' for k in ('failures','errors','skipped'))
assert sum(t.attrib['classname'].endswith('test_rampage_victims') for t in suite)==42
result['full_suite']=suite.attrib
result['python']=platform.python_version()
result['compatibility_limit']='Older terminal replays with two recorded host-consent rounds may need their Rampage segment recorded again. Verified old durable prompts and raw all-or-none adapters are supported.'
commands=[
    'python -m pytest -q --junitxml=/tmp/fs-rampage-victim-full.xml',
    'python -m pytest -q fs_bot/tests/test_rampage*.py fs_bot/tests/test_special_activities.py fs_bot/tests/test_execute_integration.py fs_bot/tests/test_assistant_session.py fs_bot/tests/test_agent_interface.py fs_bot/tests/test_battle_loss_identity.py fs_bot/tests/test_battle_action_windows.py',
    'PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --games 2 --workers 2 --out OUT',
    'PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
    'PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
    'PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20',
    'PYTHONPATH=. python -m pytest -q /tmp/test_rampage_victim_parent_proof.py --junitxml=OUT.xml',
    'PYTHONPATH=. python /tmp/fs-rampage-victim-verify.py',
    'PYTHONPATH=. python /tmp/fs-rampage-victim-package.py',
]
result['commands']=commands
Path('docs/reviews/'+prefix+'-results.json').write_text(json.dumps(result,indent=2)+'\n')
p=Path('docs/reviews/'+prefix+'.md');s=p.read_text().replace('Final full-suite and evidence inspection pending.',f"**8,465 tests pass**, including 42 new cases, with zero failures, errors or skips ({float(suite.attrib['time']):.2f} seconds).")
x=result['mixed']
s=s.replace('Frozen source,\nprotected inputs, final results and archive checksums are verified separately.',f'''All ten native NPC records complete and audit cleanly, with four ranked
factions, no errors or integrity findings, and consistent winner/ranking data.
Every gameplay field and final board hash matches the parent, excluding only
elapsed seconds, source digest and commit identity.

Both complete mixed-seat JSON outputs agree under hash seeds 0 and 987. They
cover {x['human_turns']} human turns, {x['event_turns']} Event attempts and {x['events_ok']} successful Events, with zero hard
findings and zero partial games. Their batch digest is `{x['batch_digest'][:16]}`.
Internal replay gives 40 executions total. The historical 100-game balance
check passes the existing band, with a maximum difference of 15 percentage
points and 35 winner changes versus the historical baseline. These are separate
from the paired parent/current NPC comparisons.

All 49 protected inputs match the parent byte for byte, including 47 supplied
references, canonical constants and the historical balance baseline. The
archive includes commands, raw results, source reconstruction data and verified
checksums. Earlier failed development/fixture logs are retained separately and
excluded from accepted totals.''')
p.write_text(s)
p=Path('docs/current-status.md');s=p.read_text().replace('Validation pending the final full suite and evidence inspection.', '''**8,465 tests pass**, including 42 new cases, with 469 focused tests passing.
Ten audited NPC records/final hashes match the parent. Mixed-seat runs agree
across hash seeds with zero hard findings or partials. The 100-game historical
balance guard passes its existing band. The report records source provenance,
raw evidence, protected inputs and the older terminal replay compatibility limit.''',1);p.write_text(s)
entries={}
for name in ['fs-rampage-victim-full.xml','fs-rampage-victim-full.log',
             'fs-rampage-victim-targeted.log','fs-rampage-victim-mixed0.json',
             'fs-rampage-victim-mixed0.log','fs-rampage-victim-mixed987.json',
             'fs-rampage-victim-mixed987.log','fs-rampage-victim-balance.log',
             'fs-rampage-victim-proof-parent.xml','fs-rampage-victim-proof-parent.log',
             'fs-rampage-victim-proof-final.xml','fs-rampage-victim-proof-final.log',
             'test_rampage_victim_parent_proof.py','fs-rampage-victim-verify.py',
             'fs-rampage-victim-package.py']:
    entries['accepted/'+name]=Path('/tmp/'+name).read_bytes()
for label,directory in [('parent','/tmp/fs-rampage-victim-bots-parent'),('accepted','/tmp/fs-rampage-victim-bots-final')]:
    for path in Path(directory).iterdir():
        if path.is_file():
            entries[label+'/bots/'+path.name]=path.read_bytes()
for name in ['fs-rampage-victim-initial.log','fs-rampage-victim-compat.log']:
    entries['development/'+name]=Path('/tmp/'+name).read_bytes()
entries['development/README.txt']=b'Earlier development logs are excluded from accepted totals. The first run exposed a missing local import. The next run exposed an old quantity fixture that submitted an all-or-none response to a fresh physical prompt. That fixture now supplies exact victim actions; its count, pending and save/resume assertions remain. The low-level Retreat fixture now establishes the printed friendly Control.\n'
entries['accepted/source.patch']=subprocess.check_output(['git','diff','HEAD','--','fs_bot'])
for name in ('fs_bot/engine/rampage_choices.py','fs_bot/cli/rampage.py','fs_bot/tests/test_rampage_victims.py'):
    entries['accepted/'+name]=Path(name).read_bytes()
protected=[path for path in Path('Reference Documents').rglob('*') if path.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
entries['accepted/protected-inputs.json']=json.dumps({str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in protected},indent=2).encode()
entries['accepted/results.json']=json.dumps(result,indent=2).encode()
entries['commands.txt']=('\n'.join(commands)+'\n\nRun paired native bot batches in their respective parent/current working directories. Run the seven standalone proof cases unchanged with PYTHONPATH=. The parent produces five behavioral failures and two passing controls. All seven pass on the accepted source.\n').encode()
entries['README.txt']=('Parent '+result['source']['commit']+'. Apply accepted/source.patch and copy the three accepted/fs_bot files to reconstruct Python sources. Accepted digest '+result['source']['source_sha256']+' across 509 files. Full suite 8465 passed, 42 new cases, 469 focused tests. Parent proof five behavioral failures and two passing controls; accepted proof seven passing. Ten audited NPC gameplay records/final hashes match parent. Mixed-seat outputs agree across hash seeds0/987 with zero hard findings/partials, forty executions including replay. The historical 100-game guard passes its unchanged 15-point band. '+result['compatibility_limit']+'\n').encode()
entries['SHA256SUMS.txt']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(entries.items())).encode()
p=Path('docs/reviews/'+prefix+'-evidence.zip')
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(entries.items()):
        z.writestr(name,data)
with zipfile.ZipFile(p) as z:
    assert z.testzip() is None
    for line in z.read('SHA256SUMS.txt').decode().splitlines():
        digest,name=line.split('  ',1)
        assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps({'suite':suite.attrib,'archive_bytes':p.stat().st_size,'source':result['source']}))
