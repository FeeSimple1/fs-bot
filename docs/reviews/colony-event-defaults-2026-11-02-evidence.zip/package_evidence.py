"""Write and verify the complete bounded repair evidence archive."""
from pathlib import Path
import hashlib
import json
import zipfile

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'fs-bot'
paths = [p for p in sorted(HERE.rglob('*')) if p.is_file()
         and '__pycache__' not in p.parts and not p.name.endswith('.tmp')
         and p.name != 'evidence-index.json']
index = {str(p.relative_to(HERE)): {'bytes': p.stat().st_size,
          'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths}
manifest = HERE / 'evidence-index.json'
manifest.write_text(json.dumps(index, indent=2) + '\n')
archive = REPO / 'docs/reviews/colony-event-defaults-2026-11-02-evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in [*paths, manifest]:
        z.write(p, p.relative_to(HERE))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, item in index.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == item['sha256']
result_path = REPO / 'docs/reviews/colony-event-defaults-2026-11-02-results.json'
results = json.loads(result_path.read_text())
results['evidence_archive'] = {'path': archive.name, 'bytes': archive.stat().st_size,
                             'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                             'entries': len(index) + 1, 'crc_and_manifest_verified': True}
result_path.write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results['evidence_archive'], indent=2))
