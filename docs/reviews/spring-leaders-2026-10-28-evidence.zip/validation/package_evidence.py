"""Build final local acceptance and a fully read-back-verified evidence archive.

Original failures, source-specific traces and historical provenance stay intact.
No simulations, baseline updates, commits or pushes are performed here.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'fs-bot'
RUN = ROOT / 'attempt1'
OUTPUT = REPO / 'docs/reviews'
SOURCE = '32fc2e1f0c2eb2e005db4c7638884a6d2022246c5eda9d87b7ade87da4caeb74'
BASELINE = '815b6f363134159b4cf5772abd4dc76a5e8e0be8fd0bb852dc571390504814f5'
FIXTURE = '0e1609c9158d2a2e635eca578681442764b05637200f7000ae5554ccceb060ef'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(name):
    return json.loads((RUN / name).read_text())


def dump(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def main():
    archive_path = OUTPUT / 'spring-leaders-2026-10-28-evidence.zip'
    result_path = OUTPUT / 'spring-leaders-2026-10-28-results.json'
    assert not archive_path.exists() and not result_path.exists(), 'Never overwrite an existing published evidence artifact'
    results = read('results.json')
    expected_failure = 'balance/The Gallic War/Arverni: drift -1/5 exceeds unchanged 3/20 band'
    assert results['failures'] == [expected_failure]
    assert results['pytest'] == {'errors': 0, 'exit_code': 0, 'failures': 0, 'skipped': 0, 'tests': 5226, 'time': 53.352}
    tests, balance = read('tests-after-fixture.status.json'), read('balance-final.status.json')
    assert tests['exit_code'] == tests['runner_exit_code'] == balance['exit_code'] == balance['runner_exit_code'] == 0
    assert not tests['source_changed'] and not balance['source_changed']
    assert tests['source']['source_sha256'] == tests['source_after']['source_sha256'] == SOURCE
    assert balance['source_before']['source_sha256'] == balance['source_after']['source_sha256'] == SOURCE
    assert tests['fixture_files_before'] == tests['fixture_files_after']
    assert balance['exact_candidate_records_match'] and balance['record_count'] == 100
    candidate = (RUN / 'balance-candidate.json').read_bytes()
    assert sha(candidate) == BASELINE == sha((REPO / 'fs_bot/tools/balance_baseline.json').read_bytes())
    assert json.loads(candidate) == read('balance-final-records.json')
    assert sha((REPO / 'fs_bot/tests/fixtures/compatibility_8ef88e2/manifest.json').read_bytes()) == FIXTURE
    causal = read('drift-review/independent-nine-case-source-review.json')
    assert causal['status'] == 'Independent source/trace review passed'
    assert causal['cases_reviewed'] == 9 and causal['accepted_trace_files'] == 18 and causal['all_exact_final_hashes_verified']
    assert read('independent-raw-review.json')['raw_matrix_review_passed']
    assert read('independent-candidate-review.json')['candidate_mapping_review_passed']
    post = read('final-postchecks-review.json')
    # Independent review is archived verbatim, in addition to this verifier's
    # separate source/records/JUnit checks above and below.
    suites = ET.parse(RUN / 'tests-after-fixture.xml').getroot().findall('.//testsuite')
    counts = {k: sum(int(s.attrib[k]) for s in suites) for k in ('tests', 'failures', 'errors', 'skipped')}
    assert counts == {'tests': 5226, 'failures': 0, 'errors': 0, 'skipped': 0}
    first = ET.parse(RUN / 'tests.xml').getroot().findall('.//testsuite')
    first_counts = {k: sum(int(s.attrib[k]) for s in first) for k in ('tests', 'failures', 'errors', 'skipped')}
    assert first_counts == {'tests': 5226, 'failures': 1, 'errors': 0, 'skipped': 0}
    assert read('tests.status.json')['exit_code'] == 1
    freeze = read('freeze.json')
    sources = {}
    digest = hashlib.sha256()
    for path in sorted((REPO / 'fs_bot').rglob('*.py')):
        name, raw = str(path.relative_to(REPO)), path.read_bytes()
        sources[name] = raw
        digest.update(name.encode() + b'\0' + raw)
    assert len(sources) == 315 and digest.hexdigest() == SOURCE
    assert {name: sha(raw) for name, raw in sources.items()} == freeze['source_files']
    protected = {}
    paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', freeze['commit'], '--', 'Reference Documents', 'fs_bot/rules_consts.py'], cwd=REPO, text=True).splitlines()
    for name in paths:
        raw = (REPO / name).read_bytes()
        assert raw == subprocess.check_output(['git', 'show', freeze['commit'] + ':' + name], cwd=REPO)
        protected[name] = sha(raw)
    assert len(protected) == 48
    dump(RUN / 'final-protected-source-review.json', {'commit': freeze['commit'], 'files': protected, 'passed': True})
    bot_rows = [json.loads(line) for edition in ('legacy', 'original', 'second-edition')
                for line in (RUN / ('bots-' + edition) / 'games.jsonl').read_text().splitlines()]
    acceptance = {
        'schema_version': 1,
        'recorded_utc': datetime.now(timezone.utc).isoformat(),
        'accepted': True,
        'scope': 'Spring Leader placement and scoped Gallic War Interlude named Leader choices',
        'source': dict(read('source.json'), python_files=315),
        'local_validation_only': True,
        'remote_ci': {'status': 'not run or verified by this local evidence package', 'claimed_pass': False},
        'starting_baseline_full_suite': {'tests': 5112, 'failures': 0, 'exit_code': 0,
             'launch_provenance': 'Parent observed session40215; exact argv and source provenance in starting-source.json'},
        'initial_frozen_full_suite': dict(first_counts, passed_tests=5225, exit_code=1,
             reason='pre-interlude legacy fixture continuation digest changed; old failure preserved'),
        'final_full_suite': dict(results['pytest'], console_seconds=53.43,
             output_prefix='tests-after-fixture', fixture_manifest_sha256=FIXTURE),
        'matrix': {'bot_games': 150, 'bot_profiles': results['bot_batches'],
             'mixed_seats': results['mixed_seats'], 'strict_census': results['strict_census'],
             'runner_job_exit_codes': results['runner']['job_exit_codes'],
             'all_bot_completion_flags_true': all(all(r[k] is True for k in ('completed', 'game_completed', 'audit_completed')) for r in bot_rows),
             'bot_diagnostic_occurrences': sum(len(r['diagnostic_occurrences']) for r in bot_rows)},
        'same_api_rule_probes': results['same_api_rule_probes'],
        'original_balance': results['balance'],
        'baseline_refresh': {'authorized': True, 'installed_sha256': BASELINE,
             'original_sha256': freeze['balance_baseline_sha256'], 'keys': 100,
             'changed_records': 11, 'changed_winners': 9, 'changed_card_counts': 6,
             'threshold_percentage_points': 15, 'exact_band': '3/20',
             'original_guardrail_passed': False, 'original_failure_preserved': expected_failure,
             'fresh_check': {'games': 100, 'exit_code': balance['exit_code'],
                 'runner_exit_code': balance['runner_exit_code'], 'exact_winner_cards_match': True,
                 'changed_winners': 0, 'changed_card_counts': 0}},
        'causal_review': {'cases': 9, 'checks': causal['checks'], 'accepted_trace_files': 18,
             'diagnostic_game_executions': 19, 'all_final_hashes_verified': True,
             'categories': {'corrected_np_successor_priority': 2, 'newly_randomized_vercingetorix_tie': 1,
                 'removed_singleton_interlude_rng_draw': 4, 'legal_sorted_tie_mapping_drift': 2},
             'limitation': 'First source-backed divergence localizes implementation drift; it does not prove that mechanism alone caused the final winner.',
             'recovery': 'Gallic War14 current gzip was truncated after initial successful compare; original retained and one same-source current case recaptured to a separate file.'},
        'compatibility_fixture': {'original_failure_preserved': True, 'final_manifest_sha256': FIXTURE,
             'provenance': 'compatibility-review/causal-review.json; original generator/fixture bytes and old continuation hash history preserved'},
        'independent_reviews': ['independent-raw-review.json', 'independent-candidate-review.json',
             'independent-trace-integrity-review.json', 'final-postchecks-review.json',
             'drift-review/independent-nine-case-source-review.json'],
        'protected_files_unchanged': 48,
        'verifier_correction_disclosed': 'verifier-correction.json: removed unsupported Optimates-must-be-Arverni assumption; initial verifier report retained',
        'acceptance_distinction': 'Final acceptance follows reviewed fixture expectation/baseline refresh and passing fresh checks. Neither the initial full suite nor the original balance guardrail passed.'}
    dump(RUN / 'final-acceptance.json', acceptance)
    (ROOT / 'FINAL_README.txt').write_text(
        'Accepted Spring validation, Python32fc2e1f... at base commita537511 (dirty during runs).\n'
        '150 audited bot games (100legacy1-20;25original201-205;25second-edition201-205),80 mixed replay executions and50 strict census executions.\n'
        'Original full suite:5225 passed/1 compatibility-fixture failure, exit1. Original baseline:GallicWarArverni4/20 to0/20 (-20pp), failed unchanged15pp band. Both failures remain preserved.\n'
        'Source-reviewed compatibility JSON expectation updated with history; final manifest0e1609c9.... Baseline candidate815b6f36... reviewed and installed after9 paired causal cases.\n'
        'Final full suite5226 passed, exit0; fresh100balance exactly matches every reviewed winner/cards, exit0. Local checks are separate from remoteCI, which is not claimed as run.\n'
        'Two Interlude tie order mappings are legal implementation drift, not old-rule violations. Early bookkeeping/reporting differences are distinguished from actual placement/RNG differences.\n'
        '19 diagnostic game executions =18 accepted paired traces plus1 GallicWar14 artifact recapture. The original truncated gzip remains as failed artifact evidence; current-recaptured.json.gz is the accepted trace.\n'
        'Earlier historical raw baseline records retain actual04b metadata/source071485; new clean-a537511 baseline traces match those exact final hashes. No historical evidence relabeled.\n'
        'MANIFEST.json hashes every other archive member. frozen-python-source contains all315 executed Python files, including originally untracked modules/tests.\n'
        'The results.json verifier still exits1 solely to preserve the original band failure; final-acceptance.json and fresh balance-final files record the separate reviewed acceptance.\n')
    payload = {}
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path.suffix in ('.pyc', '.pyo'):
            continue
        if path.name in ('package-verification.json',):
            continue
        payload['validation/' + str(path.relative_to(ROOT))] = path.read_bytes()
    payload.update({'frozen-python-source/' + name: raw for name, raw in sources.items()})
    payload['final-inputs/fs_bot/tools/balance_baseline.json'] = (REPO / 'fs_bot/tools/balance_baseline.json').read_bytes()
    payload['final-inputs/fs_bot/tests/fixtures/compatibility_8ef88e2/manifest.json'] = (REPO / 'fs_bot/tests/fixtures/compatibility_8ef88e2/manifest.json').read_bytes()
    patterns = {
        'private_key': rb'-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----',
        'github_token': rb'(?:github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9]{30,})',
        'openai_style_key': rb'\bsk-(?:proj-)?[A-Za-z0-9_-]{32,}',
        'google_api_key': rb'\bAIza[A-Za-z0-9_-]{30,}',
        'aws_access_id': rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
        'slack_token': rb'\bxox[baprs]-[A-Za-z0-9-]{20,}',
    }
    findings = [{'member': name, 'pattern': kind} for name, raw in payload.items()
                for kind, pattern in patterns.items() if re.search(pattern, raw)]
    assert not findings, 'Credential-pattern scan flagged members; no values printed: ' + json.dumps(findings)
    manifest = {'schema_version': 1, 'self_exclusion': 'MANIFEST.json lists every other member; its own digest is not recursively included.',
                'members': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(payload.items())}}
    payload['MANIFEST.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(payload.items()):
            archive.writestr(name, raw)
    with zipfile.ZipFile(archive_path) as archive:
        assert len(archive.namelist()) == len(payload) == len(set(archive.namelist()))
        assert set(archive.namelist()) == set(payload)
        for name in archive.namelist():
            actual = archive.read(name)
            assert actual == payload[name]
            if name != 'MANIFEST.json':
                assert len(actual) == manifest['members'][name]['bytes'] and sha(actual) == manifest['members'][name]['sha256']
        assert archive.testzip() is None
    package = {'path': str(archive_path), 'sha256': sha(archive_path.read_bytes()), 'bytes': archive_path.stat().st_size,
               'members': len(payload), 'payload_bytes': sum(len(raw) for raw in payload.values()),
               'all_members_read_back': True, 'per_member_sha256_and_sizes_verified': True,
               'credential_pattern_scan': {'findings': 0, 'pattern_categories': sorted(patterns),
                     'scope': 'Every payload member byte stream; high-confidence patterns, not a guarantee against arbitrary secret formats.'},
               'source_snapshot_python_files': 315}
    dump(ROOT / 'package-verification.json', package)
    dump(result_path, dict(acceptance, evidence_archive=package))
    print(json.dumps({'accepted': True, 'results_path': str(result_path), 'results_sha256': sha(result_path.read_bytes()),
                      'archive': package}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
