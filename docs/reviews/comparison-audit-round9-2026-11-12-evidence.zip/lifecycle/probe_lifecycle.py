#!/usr/bin/env python3
"""Round 9 audit witness, not a repair. Assertions encode the current defect.

Run: .venv/bin/python ../audit9-work/lifecycle/probe_lifecycle.py --repo .
All physical counters use production helpers. These are controlled lawful
positions, not claimed naturally sampled game traces. The failing entry is
the public Quarters phase with no supplied relocation or payment choices.
"""
import argparse
import copy
import json
import sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--out-dir', type=Path, default=Path(__file__).resolve().parent)
args = parser.parse_args()
sys.path.insert(0, str(args.repo.resolve()))
args.out_dir.mkdir(parents=True, exist_ok=True)

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, place_piece
from fs_bot.bots.roman_bot import build_np_winter_relocations
from fs_bot.commands.rally import has_supply_line
from fs_bot.engine.quarters import quarters_factions, validate_quarters_plan
from fs_bot.engine.winter import quarters_phase
from fs_bot.state.serialize import load_game, save_game
from fs_bot.state.state_schema import build_initial_state, check_structural_integrity, validate_state


def integrity(state):
    checked = dict(census=validate_state(state), structure=check_structural_integrity(state))
    assert checked == dict(census=[], structure=[]), checked
    return checked


def position(scenario, *, reverse=False, funds=20, evacuate=True):
    state = build_initial_state(scenario, seed=1)
    state['non_player_factions'] = set(quarters_factions(state))
    state['resources'][rc.ROMANS] = funds
    origin, dest = (rc.NERVII, rc.MORINI) if reverse else (rc.MORINI, rc.NERVII)
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    place_piece(state, dest, rc.ROMANS, rc.AUXILIA, 1 if evacuate else 3)
    if evacuate:
        place_piece(state, origin, rc.ROMANS, rc.AUXILIA, 2)
        state['markers'].setdefault(origin, {})[rc.MARKER_DEVASTATED] = True
    blockers = [rc.ATREBATES, rc.SUGAMBRI, rc.TREVERI]
    if scenario in rc.BASE_SCENARIOS:
        blockers.append(rc.BRITANNIA)
    for region in blockers:
        place_piece(state, region, rc.BELGAE, rc.WARBAND, 1)
    # No route to Italy exists. All other factions stay during Quarters;
    # the non-devastated refuge has Roman Control before and after arrival.
    assert not has_supply_line(state, origin, rc.ROMANS)
    assert not has_supply_line(state, dest, rc.ROMANS)
    integrity(state)
    return state, origin, dest


def snapshot(state, origin, dest):
    return dict(origin_auxilia=count_pieces(state, origin, rc.ROMANS, rc.AUXILIA),
                destination_auxilia=count_pieces(state, dest, rc.ROMANS, rc.AUXILIA),
                roman_resources=state['resources'][rc.ROMANS])


def run(state, origin, dest, *, corrected_plan=False):
    pre = integrity(state)
    plan = build_np_winter_relocations(copy.deepcopy(state))
    assert not validate_quarters_plan(state, plan)
    if corrected_plan:
        # Same physical relocation, ordinary public authored phase plan.
        # Only the payment amount changes to all three actual end pieces.
        plan[rc.ROMANS + '_quartering'][dest]['pay'] = 3
        assert not validate_quarters_plan(state, plan)
    before = snapshot(state, origin, dest)
    result = quarters_phase(state, relocations=plan if corrected_plan else None)
    return dict(pre_integrity=pre, before=before, planner=plan,
                result=result, after=snapshot(state, origin, dest),
                post_integrity=integrity(state))


cases = []
for index, scenario in enumerate(rc.ALL_SCENARIOS):
    state, origin, dest = position(scenario)
    save_path = args.out_dir / f'LC9-01-before-{index}.json'
    save_game(state, save_path)
    restored, _, _ = load_game(save_path, validate=True)
    actual = run(copy.deepcopy(state), origin, dest)
    restored_actual = run(restored, origin, dest)
    assert actual == restored_actual
    assert actual['planner'][rc.ROMANS + '_quartering'][dest]['pay'] == 1
    assert actual['result']['roman_relocation'] == [(rc.AUXILIA, origin, dest, 2)]
    assert actual['result']['roman_quartering']['total_cost'] == 2
    assert actual['result']['roman_quartering']['rolls'][dest]['rolls'] == [2, 5]
    assert actual['after'] == dict(origin_auxilia=0, destination_auxilia=2, roman_resources=18)
    control = run(copy.deepcopy(state), origin, dest, corrected_plan=True)
    assert control['result']['roman_quartering']['rolls'] == {}
    assert control['result']['roman_quartering']['total_cost'] == 6
    assert control['after'] == dict(origin_auxilia=0, destination_auxilia=3, roman_resources=14)
    reverse, reverse_origin, reverse_dest = position(scenario, reverse=True)
    reverse_control = run(reverse, reverse_origin, reverse_dest)
    assert reverse_control['result']['roman_quartering']['rolls'] == {}
    assert reverse_control['result']['roman_quartering']['total_cost'] == 6
    assert reverse_control['after']['destination_auxilia'] == 3
    stable, stable_origin, stable_dest = position(scenario, evacuate=False)
    stable_control = run(stable, stable_origin, stable_dest)
    assert stable_control['result']['roman_quartering']['rolls'] == {}
    assert stable_control['result']['roman_quartering']['total_cost'] == 6
    poor, poor_origin, poor_dest = position(scenario, reverse=True, funds=2)
    budget_control = run(poor, poor_origin, poor_dest)
    assert budget_control['planner'][rc.ROMANS + '_quartering'][poor_dest]['pay'] == 3
    assert budget_control['result']['roman_quartering']['total_cost'] == 2
    assert budget_control['result']['roman_quartering']['rolls'][poor_dest]['rolls'] == [2, 5]
    cases.append(dict(scenario=scenario, defective=actual, save_load_identical=True,
                      complete_payment_control=control, opposite_direction_control=reverse_control,
                      stationary_stack_control=stable_control, inadequate_funds_control=budget_control))

output = dict(audited_commit='f4c8372c396981c0a31dc6f4545e67f8c6f2e981',
              finding='LC9-01', cases=cases)
(args.out_dir / 'results.json').write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps(output, indent=2))
