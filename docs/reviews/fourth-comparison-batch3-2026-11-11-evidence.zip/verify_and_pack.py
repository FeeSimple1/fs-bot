from collections import Counter
from pathlib import Path
from platform import python_version
from xml.etree import ElementTree
from zipfile import ZIP_DEFLATED, ZipFile
import json

from fs_bot.tools.run_batch import SCENARIOS
from fs_bot.tools.validation_metadata import source_identity

root = Path('../batch3-publish')
earlier = Path('../batch3-accepted')
parent_root = Path('../batch3-verification')
source = source_identity()
source.update(python=python_version(), python_files=len(list(Path('fs_bot').rglob('*.py'))))


def audited(folder, seeds, edition):
    metadata = json.loads((folder / 'metadata.json').read_text())
    records = [json.loads(line) for line in (folder / 'games.jsonl').read_text().splitlines()]
    keyed = {(r['scenario'], r['seed']): r for r in records}
    assert len(records) == len(keyed) == len(seeds) * len(SCENARIOS)
    assert keyed.keys() == {(scenario, seed) for scenario in SCENARIOS for seed in seeds}
    for record in records:
        assert record['card_edition'] == metadata['card_edition'] == edition
        assert record['source_sha256'] == metadata['source_sha256']
        assert all(record[key] for key in ('completed', 'game_completed', 'audit_completed'))
        assert all(not record[key] for key in ('errors', 'integrity_findings',
            'engine_ranking_output_missing', 'winner_differs_from_highest_margin'))
        assert len(record['final_ranking']) == len(record['engine_final_ranking']) == 4
        assert len(record['final_state_sha256']) == 64
        assert all(entry['severity'] == 'legal-decline' for field in
                   ('diagnostics', 'diagnostic_occurrences') for entry in record[field])
    return metadata, keyed


matrices = {}
for name, edition, seeds in [('legacy', 'legacy', range(1, 21)),
                             ('second', 'second-edition', range(25, 29))]:
    metadata, new = audited(root / name, seeds, edition)
    old_metadata, old = audited(parent_root / f'parent-{name}', seeds, edition)
    assert metadata['source_sha256'] == source['source_sha256']
    assert old_metadata['commit'] == source['commit'] and not old_metadata['dirty']
    _, reviewed = audited(earlier / name, seeds, edition)
    # The final rerun includes the updated test fixture and baseline. Verify
    # every recorded gameplay field against the revision used for the traces.
    for key in new:
        ignored = {'seconds', 'source_sha256'}
        assert {k:v for k,v in new[key].items() if k not in ignored} == {
            k:v for k,v in reviewed[key].items() if k not in ignored}
    matrices[edition] = dict(games=len(new), changed_winners=sum(
        old[k]['winner'] != new[k]['winner'] for k in new))
    if edition == 'legacy':
        baseline = json.loads(Path('fs_bot/tools/balance_baseline.json').read_text())['games']
        assert baseline == {f'{scen}|{seed}': {k:v[k] for k in ('winner', 'cards')}
                            for (scen, seed), v in new.items()}

fuzz = json.loads((root / 'fuzz0.json').read_text())
assert (root / 'fuzz0.json').read_bytes() == (root / 'fuzz987.json').read_bytes()
assert (root / 'fuzz0.log').read_bytes() == (root / 'fuzz987.log').read_bytes()
assert fuzz['metadata']['replay'] and fuzz['metadata']['source_sha256'] == source['source_sha256']
assert fuzz['games'] == len(fuzz['records']) == 20 and fuzz['hard_findings'] == 0
assert {(r['scenario'], r['seed']) for r in fuzz['records']} == {
    (scenario, seed) for scenario in SCENARIOS for seed in range(25, 29)}
assert all(r['game_completed'] and not r['findings'] for r in fuzz['records'])

suite = ElementTree.parse(root / 'pytest.xml').getroot().find('testsuite')
assert all(suite.get(key) == '0' for key in ('failures', 'errors', 'skipped'))
assert int(suite.get('tests')) == 9794
assert (root / 'balance.log').read_text().endswith('OK: balance within band.\n')
assert (earlier / 'balance.log').read_text().count('DRIFT > ±15%') == 1
changes = json.loads((earlier / 'changed-outcomes.json').read_text())
assert Counter(row['edition'] for row in changes) == {
    edition: row['changed_winners'] for edition, row in matrices.items()}
assert sum(row['parent']['retreats'] != row['repair']['retreats'] for row in changes) == 29

verification = dict(source=source, full_suite=int(suite.get('tests')),
    new_regressions=17, parent_regression_failures=8, bot_matrices=matrices,
    mixed={key:fuzz[key] for key in ('games', 'human_turns', 'event_turns', 'events_ok',
                                    'hard_findings', 'partial', 'batch_digest')},
    balance=dict(games=len(baseline), prior_baseline_changed_winners=36,
                 prior_baseline_changed_records=49, prior_guardrail_exit=1,
                 reviewed_guardrail_exit=0, band=0.15))
(root / 'verification.json').write_text(json.dumps(verification, indent=2) + '\n')

report = 'fourth-comparison-batch3-2026-11-11.md'
archive_name = report.replace('.md', '-evidence.zip')
ledger_path = Path('docs/reviews/comparison-audit-round4-2026-11-10.json')
ledger = json.loads(ledger_path.read_text())
closed = ['BM4-01', 'BM4-02', 'NP4-01', 'NP4-02']
for finding in ledger['findings']:
    if finding['id'] in closed:
        assert finding['status'] == 'open'
        finding.update(status='closed', repair_batch=3, repair_report=report)
pending = [f for f in ledger['findings'] if f['status'] == 'open']
assert [f['id'] for f in pending] == ['WS4-02', 'WS4-03']
ledger.update(closed=ledger['total'] - len(pending), open=len(pending),
              open_severity_counts=dict(Counter(f['severity'] for f in pending)),
              latest_repair=dict(batch=3, date='2026-11-11', report=report,
                  evidence=archive_name, source=source, closed_ids=closed,
                  passed_tests=verification['full_suite'], new_regressions=17,
                  balance_guardrail_exit=0, previous_balance_guardrail_exit=1))
ledger['repair_history'].append(dict(batch=3, report=report, closed=ledger['closed'], open=ledger['open']))
ledger_path.write_text(json.dumps(ledger, indent=2, ensure_ascii=False) + '\n')

archive_path = ledger_path.parent / archive_name
with ZipFile(archive_path, 'w', compression=ZIP_DEFLATED, compresslevel=9) as archive:
    for file in ('README.md', 'verification.json', 'verify_and_pack.py', 'pytest.log', 'pytest.xml',
                 'second.log', 'legacy.log', 'fuzz0.log', 'fuzz987.log', 'fuzz0.json', 'fuzz987.json',
                 'balance.log'):
        archive.write(root / file, file)
    for file in ('focused.log', 'parent-regressions.log', 'canary.log', 'candidate-balance.log',
                 'trace_game_changes.py', 'changed-outcomes.json', 'trace_a24_battle.py',
                 'a24-parent.json', 'a24-repair.json', 'previous-baseline.json', 'candidate-baseline.json'):
        archive.write(earlier / file, file)
    archive.write(earlier / 'balance.log', 'previous-balance-check.log')
    for folder, path in [('legacy', root), ('second', root),
                         ('parent-legacy', parent_root), ('parent-second', parent_root)]:
        for file in ('metadata.json', 'games.jsonl', 'summary.json'):
            archive.write(path / folder / file, f'{folder}/{file}')
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None
print(json.dumps(verification, indent=2))
print(f'{archive_path.name}: {archive_path.stat().st_size} bytes')
