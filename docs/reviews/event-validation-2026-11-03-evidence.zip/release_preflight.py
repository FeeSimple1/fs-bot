"""Verify final documentation links, counts and protected/source identities."""
from pathlib import Path
from urllib.parse import unquote
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'fs-bot'
manifest = json.loads((HERE / 'final-source-manifest.json').read_text())
for name, digest in manifest['files'].items():
    assert hashlib.sha256((REPO / name).read_bytes()).hexdigest() == digest, name
protected = json.loads((HERE / 'protected-before.json').read_text())
unchanged = []
for name, digest in protected.items():
    if name == 'fs_bot/tools/balance_baseline.json':
        continue
    assert hashlib.sha256((REPO / name).read_bytes()).hexdigest() == digest, name
    unchanged.append(name)
assert len(unchanged) == 48
assert (REPO / 'fs_bot/tools/balance_baseline.json').read_bytes() == (HERE / 'baseline-after.json').read_bytes()
frozen = json.loads((HERE / 'causal-review/frozen-causal-manifest.json').read_text())
for name, digest in frozen['files'].items():
    assert hashlib.sha256((HERE / 'causal-review' / name).read_bytes()).hexdigest() == digest, name
progress = json.loads((REPO / 'docs/human-choice-progress.json').read_text())
assert progress['total'] == len(progress['findings']) == 50
assert progress['closed'] == sum(f['status'] == 'closed' for f in progress['findings']) == 17
assert progress['open'] == 33
for f in progress['findings']:
    if f['status'] == 'closed':
        assert (REPO / 'docs' / f['report']).is_file(), f
suites = {}
for name in ('integrated-full-01', 'documentation-full-01'):
    suite = ET.parse(HERE / (name + '.xml')).getroot().find('testsuite')
    assert int(suite.attrib['tests']) == 6728
    assert all(int(suite.attrib[key]) == 0 for key in ('errors', 'failures', 'skipped'))
    suites[name] = suite.attrib
changed = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=REPO, text=True).splitlines()
markdown = [REPO / name for name in changed if name.endswith('.md')]
markdown += [REPO / 'docs/reviews/event-validation-2026-11-03.md']
local_links = 0
for file in markdown:
    content = file.read_text()
    for target in re.findall(r'\]\(([^)]+)\)', content):
        target = target.split('#', 1)[0]
        if not target or '://' in target or target.startswith('mailto:'):
            continue
        path = (file.parent / unquote(target)).resolve()
        assert path.exists(), (str(file.relative_to(REPO)), target)
        local_links += 1
report = (REPO / 'docs/reviews/event-validation-2026-11-03.md').read_text()
assert '{{' not in report and 'Pending execution' not in report
results = json.loads((REPO / 'docs/reviews/event-validation-2026-11-03-results.json').read_text())
assert results['full_tests']['final_documentation_status'] == 'passed'
assert results['passed'] and results['baseline_refresh']['passed']
assert not results['original_baseline_comparison']['passed']
result = {'python_files_unchanged': len(manifest['files']), 'immutable_source_inputs_unchanged': len(unchanged),
          'sealed_causal_files_unchanged': len(frozen['files']), 'markdown_files_checked': len(markdown),
          'local_links_resolve': local_links, 'progress': {'closed': 17, 'total': 50, 'open': 33},
          'full_suites': suites, 'baseline_matches_reviewed_refresh': True, 'passed': True}
(HERE / 'release-preflight.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
