# Bounded paired outcome review

Parent `d3241e7` versus candidate `13e9637`, legacy edition, `PYTHONHASHSEED=0`. All twelve traced outcomes match the supplied before/after records. Every pair has identical earlier trace rows, declared decisions, and pre-execution board/RNG. No unexplained first divergence or blocker was found.

| Scenario | Seed | First differing execution | Concrete change | RNG at that execution |
|---|---:|---|---|---|
| Ariovistus | 2 | Card count 5, A58, Romans | Flowchart omits the unsafe Auxilia attack; forbidden enemy Rally rolls and placements disappear. | Same before; parent advances, candidate does not. |
| Ariovistus | 4 | Card count 4, A19, Belgae | Provincia → Cisalpina compulsory whole Roman March now occurs. | Same before and after; neither advances. |
| Ariovistus | 17 | Card count 29, A19, Belgae | Morini → Sugambri compulsory whole Roman March now occurs. | Same before and after; neither advances. |
| The Gallic War | 2 | Card count 5, A58, Romans | Flowchart omits the unsafe Auxilia attack; forbidden enemy Rally rolls and placements disappear. | Same before; parent advances, candidate does not. |
| The Gallic War | 4 | Card count 4, A19, Belgae | Provincia → Cisalpina compulsory whole Roman March now occurs. | Same before and after; neither advances. |
| The Gallic War | 17 | Card count 29, A19, Belgae | Morini → Sugambri compulsory whole Roman March now occurs. | Same before and after; neither advances. |

A58 explicitly grants no enemy Rally. The parent rolled Arverni 1 and Belgae 2 after dispersing Atrebates, placing three Arverni Allies plus Warbands and a Belgic Rally. Candidate correctly omits those rolls. Both versions Seize for 8 Resources and one Dispersal. The separate Battle change follows §8.2.3’s requirement to use Roman flowchart conditions (§8.8.1); the old heuristic attacked with one Auxilia and lost it.

A19 shaded orders a whole Roman March to an adjacent Region containing Germans. The parent skipped this for the Belgic executor. At seed 4 the corrected move is 6 Legions, 8 Auxilia and Caesar from Provincia to Cisalpina; at seed 17 it is 8 Legions, 11 Auxilia and Caesar from Morini to Sugambri. The special no-Fort/outnumber instruction is printed only for NP Germans, not Belgae. These changes are deterministic and consume no RNG.

No A20 effect is the first divergence in these six pairs. This review establishes the initial causal change, not a decomposition of every later winner/length difference. It does not refresh the baseline, tune policies, or constitute a new balance study.

## Reproducibility and interruption

`trace_games.py` runs the real engine with live-only snapshot wrappers; `summarize_traces.py` verifies the outcomes and equal prefixes, then regenerates JSON/Markdown. Twelve gzip traces, complete parent/candidate manifests, source byte digests and RNG hashes are retained. `causal-summary.json` includes exact first differing execution results.

The original parent Gallic War seed 17 capture was interrupted while writing. Its corrupt output is preserved as `parent-The-Gallic-War-17.interrupted.json.gz`; the single-game rerun is recorded in `parent17-retry.log`. The valid replacement reproduces Belgae winning after 105 cards. The trace script now writes to a temporary file before renaming, preventing partial files from looking complete.

Commands (use the shared venv Python; substitute absolute checkouts/evidence paths):

```sh
PYTHONHASHSEED=0 python trace_games.py --worktree /path/to/fs-human-grants-parent --label parent --out /path/to/evidence/causal-review
PYTHONHASHSEED=0 python trace_games.py --worktree /path/to/fs-bot --label candidate --out /path/to/evidence/causal-review
PYTHONHASHSEED=0 python trace_games.py --worktree /path/to/fs-human-grants-parent --label parent --scenario "The Gallic War" --seed 17 --out /path/to/evidence/causal-review
python summarize_traces.py
```
