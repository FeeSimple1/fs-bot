"""Recreate the exact historical attempt4 Python bytes in an isolated checkout.

This is the repeatable form of the reconstruction recorded under
attempt5/a70-causal-review/historical-source-reconstruction.json. It never
changes the live checkout; every historical file must match the frozen hash.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "fs-bot"
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--target", type=Path, required=True)
args = parser.parse_args()
assert not args.target.exists(), "use a new isolated path"
freeze = json.loads((ROOT / "attempt4/freeze.json").read_text())
source = json.loads((ROOT / "attempt4/source.json").read_text())
subprocess.run(["git", "clone", "--shared", "--no-checkout", str(REPO), str(args.target)], check=True)
subprocess.run(["git", "-C", str(args.target), "checkout", "--detach", source["commit"]], check=True)
for path in (args.target / "fs_bot").rglob("*.py"):
    if str(path.relative_to(args.target)) not in freeze["source_files"]:
        path.unlink()
for name, wanted in freeze["source_files"].items():
    data = (REPO / name).read_bytes()
    if name == "fs_bot/bots/bot_common.py":
        start = data.index(b'    # Both expansion Roman/Aedui instruction sheets say Nervii is\n')
        end = data.index(b'    # Capability in final year', start)
        data = data[:start] + data[end:]
    assert hashlib.sha256(data).hexdigest() == wanted, name
    path = args.target / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
digest = hashlib.sha256()
for path in sorted((args.target / "fs_bot").rglob("*.py")):
    digest.update(str(path.relative_to(args.target)).encode() + b"\0" + path.read_bytes())
assert digest.hexdigest() == source["source_sha256"]
print(json.dumps({"target": str(args.target), "source_sha256": digest.hexdigest(),
                  "verified_files": len(freeze["source_files"]), "live_checkout_modified": False}, indent=2))
