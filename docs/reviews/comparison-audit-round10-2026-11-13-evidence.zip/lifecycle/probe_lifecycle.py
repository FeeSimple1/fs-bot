#!/usr/bin/env python3
"""Read-only LC10-01 public Quarters witness; no monkeypatches or production edits."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    if args.repo:
        sys.path.insert(0, str(args.repo.resolve()))
    from fs_bot import rules_consts as rc
    from fs_bot.board.control import refresh_all_control
    from fs_bot.board.pieces import count_pieces, place_piece
    from fs_bot.commands.rally import has_supply_line
    from fs_bot.engine.agent import AGREEMENT
    from fs_bot.engine.quarters import validate_quarters_plan
    from fs_bot.engine.winter import quarters_phase, run_winter_round
    from fs_bot.map.map_data import get_adjacent_for_state
    from fs_bot.state.state_schema import (
        build_initial_state, check_structural_integrity, validate_state,
    )
    from fs_bot.state.setup import setup_scenario
    from fs_bot.state.serialize import encode

    def state_digest(value):
        payload = json.dumps(encode(value), sort_keys=True, separators=(',', ':'))
        return hashlib.sha256(payload.encode()).hexdigest()

    def run_case(name, *, destination=rc.PROVINCIA, host=rc.AEDUI,
                 agree=True, origin=rc.ARVERNI_REGION, blocked=True):
        state = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=11)
        place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
        place_piece(state, origin, rc.ROMANS, rc.LEGION, from_legions_track=True)
        # Keep the same physical cohorts across controls, relocating only
        # the two German origin blockers / two Aedui destination hosts.
        place_piece(state, origin if blocked else rc.MORINI,
                    rc.GERMANS, rc.WARBAND, 2)
        place_piece(state, destination if host == rc.AEDUI else rc.VENETI,
                    rc.AEDUI, rc.WARBAND, 2)
        state['resources'][rc.ROMANS] = 10
        refresh_all_control(state)
        plan = {f: [] for f in (rc.BELGAE, rc.AEDUI, rc.ARVERNI, rc.ROMANS)}
        plan[rc.ROMANS] = [(rc.LEGION, origin, destination, 1)]
        if destination != rc.PROVINCIA:
            plan[rc.ROMANS + '_quartering'] = {destination: {'pay': 1}}

        requests = []

        def choose(board, faction, request):
            requests.append({'faction': faction, 'request': deepcopy(request)})
            if request.get('kind') == AGREEMENT:
                return agree
            return None

        def summary(board):
            return {
                'census_errors': validate_state(board),
                'structural_errors': check_structural_integrity(board),
                'roman_resources': board['resources'][rc.ROMANS],
                'legions': {r: count_pieces(board, r, rc.ROMANS, rc.LEGION)
                            for r in board['spaces']
                            if count_pieces(board, r, rc.ROMANS, rc.LEGION)},
                'control': {r: board['spaces'][r]['control']
                            for r in (origin, destination)},
                'fallen_legions': board['fallen_legions'],
                'track_legions': dict(board['legions_track']),
            }

        before = summary(state)
        assert before['census_errors'] == before['structural_errors'] == []
        adjacency = destination in get_adjacent_for_state(state, origin, rc.ROMANS)
        supplied = has_supply_line(state, origin, rc.ROMANS,
                                   agreements={f: True for f in rc.FACTIONS})
        validation_errors = validate_quarters_plan(state, plan)
        state['decision_agent'] = choose
        snapshot = deepcopy({k: v for k, v in state.items() if k != 'decision_agent'})
        rng_before = state['rng'].getstate()
        result, error = None, None
        try:
            result = quarters_phase(state, relocations=plan)
        except Exception as exc:
            error = {'type': type(exc).__name__, 'message': str(exc)}
        after = summary(state)
        assert after['census_errors'] == after['structural_errors'] == []
        unchanged = all(state[k] == v for k, v in snapshot.items() if k != 'rng')
        unchanged = unchanged and state['rng'].getstate() == rng_before
        return {
            'name': name, 'scenario': rc.SCENARIO_GREAT_REVOLT, 'seed': 11,
            'origin': origin, 'destination': destination,
            'host_agrees': agree, 'adjacent': adjacency,
            'origin_has_supply_even_if_all_permitted_hosts_agree': supplied,
            'plan': plan, 'before': before, 'validation_errors': validation_errors,
            'phase_error': error, 'phase_result': result,
            'agreement_requests': [r for r in requests if r['request']['kind'] == AGREEMENT],
            'after': after, 'board_and_rng_unchanged': unchanged,
        }

    cases = [
        run_case('willing_aedui_provincia_rejected'),
        run_case('refusing_aedui_provincia_rejected', agree=False),
        run_case('roman_controlled_provincia_accepted', host=rc.ROMANS),
        run_case('willing_aedui_other_adjacent_region_accepted', destination=rc.SEQUANI),
        run_case('refusing_aedui_other_adjacent_region_rejected', destination=rc.SEQUANI,
                 agree=False),
        run_case('nonadjacent_without_supply_rejected', origin=rc.NERVII),
        run_case('supplied_origin_to_aedui_provincia_accepted', blocked=False),
    ]
    by_name = {r['name']: r for r in cases}
    # Characterize the current defect, not the proposed corrected behavior.
    assert by_name['willing_aedui_provincia_rejected']['phase_error']
    assert by_name['willing_aedui_provincia_rejected']['agreement_requests'] == []
    assert by_name['willing_aedui_provincia_rejected']['board_and_rng_unchanged']
    for name in ('roman_controlled_provincia_accepted',
                 'willing_aedui_other_adjacent_region_accepted',
                 'supplied_origin_to_aedui_provincia_accepted'):
        assert by_name[name]['validation_errors'] == []
        assert by_name[name]['phase_error'] is None
        assert by_name[name]['after']['legions'] == {by_name[name]['destination']: 1}
    for name in ('refusing_aedui_other_adjacent_region_rejected',
                 'refusing_aedui_provincia_rejected',
                 'nonadjacent_without_supply_rejected'):
        assert by_name[name]['phase_error']
        assert by_name[name]['board_and_rng_unchanged']
    assert by_name['refusing_aedui_other_adjacent_region_rejected']['agreement_requests']
    full_winter_cases = []
    for agreeing_host in (True, False):
        state = setup_scenario(rc.SCENARIO_PAX_GALLICA, seed=11)
        place_piece(state, rc.ARVERNI_REGION, rc.ROMANS, rc.LEGION,
                    from_legions_track=True)
        place_piece(state, rc.ARVERNI_REGION, rc.GERMANS, rc.WARBAND, 5)
        place_piece(state, rc.PROVINCIA if agreeing_host else rc.VENETI,
                    rc.AEDUI, rc.WARBAND, 4)
        refresh_all_control(state)
        plan = {f: [] for f in (rc.BELGAE, rc.AEDUI, rc.ARVERNI, rc.ROMANS)}
        plan[rc.ROMANS] = [(rc.LEGION, rc.ARVERNI_REGION, rc.PROVINCIA, 1)]
        requests = []

        def choose_winter(board, faction, request):
            requests.append({'faction': faction, 'request': deepcopy(request)})
            return True if request.get('kind') == AGREEMENT else None

        before = {'census_errors': validate_state(state),
                  'structural_errors': check_structural_integrity(state),
                  'winter_count': state['winter_count'],
                  'first_winter_special': deepcopy(state['first_winter_special']),
                  'origin_control': state['spaces'][rc.ARVERNI_REGION]['control'],
                  'provincia_control': state['spaces'][rc.PROVINCIA]['control']}
        assert before['census_errors'] == before['structural_errors'] == []
        state['decision_agent'] = choose_winter
        snapshot = deepcopy({k: v for k, v in state.items() if k != 'decision_agent'})
        error, result = None, None
        try:
            result = run_winter_round(state, relocations=plan)
        except Exception as exc:
            error = {'type': type(exc).__name__, 'message': str(exc)}
        after = {'census_errors': validate_state(state),
                 'structural_errors': check_structural_integrity(state),
                 'winter_count': state['winter_count'],
                 'origin_legions': count_pieces(state, rc.ARVERNI_REGION,
                                                rc.ROMANS, rc.LEGION)}
        assert after['census_errors'] == after['structural_errors'] == []
        unchanged = all(state[k] == v for k, v in snapshot.items() if k != 'rng')
        unchanged = unchanged and state['rng'].getstate() == snapshot['rng'].getstate()
        if agreeing_host:
            assert error and unchanged and after['winter_count'] == 0
            assert requests == []
        else:
            assert error is None and after['winter_count'] == 1
            assert after['origin_legions'] == 0
            assert result['phases']['victory']['skipped']
            assert result['phases']['germans']['skipped']
            assert result['phases']['quarters']['roman_relocation'] == plan[rc.ROMANS]
        full_winter_cases.append({
            'name': ('actual_pax_willing_aedui_provincia_rejected' if agreeing_host else
                     'actual_pax_roman_controlled_provincia_completes_winter'),
            'scenario': rc.SCENARIO_PAX_GALLICA, 'seed': 11, 'plan': plan,
            'before': before, 'after': after, 'winter_error': error,
            'winter_result': result, 'board_and_rng_unchanged': unchanged,
            'final_board_and_rng_sha256': state_digest(
                {k: v for k, v in state.items() if k != 'decision_agent'}),
            'final_rng_sha256': state_digest(state['rng']),
            'digest_scope': 'Full engine encode(state), excluding only decision_agent; '
                            'JSON sort_keys=True and compact separators; RNG included.',
            'agreement_requests': [r for r in requests if r['request']['kind'] == AGREEMENT],
            'fixture': 'Actual Pax setup; canonical extra one Legion and five German Warbands '
                       'in Arverni; four Aedui Warbands in Provincia or Veneti control. '
                       'Printed first-Winter skips retained, no victory bypass or mocks.',
        })
    output = {'id': 'LC10-01', 'cases': cases, 'full_winter_cases': full_winter_cases,
              'assertions_passed': True,
              'fixture': 'Canonical build_initial_state plus place_piece; permanent Provincia Fort; '
                         'one Legion, two German and two Aedui Warbands; no markers/capabilities; '
                         'all factions human; explicit no-move plans for non-Romans; '
                         'no mocks, monkeypatches, bespoke RNG, or production edits.'}
    encoded = json.dumps(output, indent=2, sort_keys=True)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(encoded + '\n')
    print(encoded)


if __name__ == '__main__':
    main()
