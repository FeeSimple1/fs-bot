"""Record the full-suite command and actual exit status for this frozen batch."""
import json
import hashlib
import argparse
import os
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime, timezone

root = Path(__file__).resolve().parent
repo = root.parent / 'fs-bot'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--attempt', required=True)
parser.add_argument('--source-sha256', required=True)
parser.add_argument('--post-baseline', action='store_true')
args = parser.parse_args()
assert Path(args.attempt).name == args.attempt
run = root / args.attempt
if args.post_baseline:
    run = run / 'post-baseline'
    run.mkdir(exist_ok=True)
sys.path.insert(0, str(repo))
from fs_bot.tools.validation_metadata import source_identity

expected = args.source_sha256
assert run.is_dir(), 'Start the matrix orchestrator first'
assert source_identity()['source_sha256'] == expected
argv = [sys.executable, '-m', 'pytest', '-q', '-n', '6',
        '--junitxml=' + str(run / 'tests.xml')]
status = {'argv': argv, 'cwd': str(repo), 'source': source_identity(),
          'started_utc': datetime.now(timezone.utc).isoformat(), 'exit_code': None,
          'environment': {'PYTHONHASHSEED': '0'},
          'balance_baseline_sha256': hashlib.sha256(
              (repo / 'fs_bot/tools/balance_baseline.json').read_bytes()).hexdigest()}
status_path = run / 'tests.status.json'
status_path.write_text(json.dumps(status, indent=2) + '\n')
start = time.monotonic()
with (run / 'tests.log').open('x') as output:
    process = subprocess.run(argv, cwd=repo, env=dict(os.environ, PYTHONHASHSEED='0'),
                             stdout=output, stderr=subprocess.STDOUT)
status.update(exit_code=process.returncode, elapsed_seconds=time.monotonic() - start,
              finished_utc=datetime.now(timezone.utc).isoformat(), source_after=source_identity())
status_path.write_text(json.dumps(status, indent=2) + '\n')
assert status['source_after']['source_sha256'] == expected, 'Source changed during suite'
print(json.dumps(status, indent=2))
sys.exit(process.returncode)
