# Independent lifecycle review

Both finalized lifecycle findings are confirmed on unchanged audited commit
`e62b0360c1b91032741ef8f6afa4d247c8ea2437`. The same nine primary case records
and two validated save/load repetitions match byte-for-byte under hash seeds
0 and 987. Every recorded pre/post inventory and structure check is clean.
`lifecycle-review.json` binds this review to the ledger and witness digests.

**LC8-01:** The fourth of the five rebuilt Winter cards prematurely forces
final scoring, although no faction passes its threshold and one Winter remains.
Chapter 2 §2.4.1 and the Gallic War second-half deck instructions support the
expected fifth-Winter boundary. The third/fifth second-half Winters and ordinary
Pax fourth Winter provide appropriate controls.

An additional independent boundary trace locates the error precisely. Before
drawing that fourth Winter, resolved Winters are 6, played rebuilt Winters are
3, and remaining Winters are 2. The helper returns 8 and predicts non-final.
Drawing that same Winter, with no resolution or other state changes, leaves
resolved Winters at 6, played rebuilt Winters at 4, and remaining Winters at 1.
The helper now returns 7 and resolution marks the Winter final. This drops the
current unresolved Winter when cumulative resolved history dominates the
rebuilt played-card count. The trace is in `lifecycle-review-evidence/draw-boundary.json`.

**LC8-02:** The sole human Roman's first-Winter threshold win violates standard
§8.9. §6.1 explicitly names that exception; the separate Easy option is neither
selected nor represented in this fixture. The multiplayer, all-NP, NP-Roman,
and final-Winter controls isolate the missing policy gate. The repair should
remain at Victory Phase/end-of-game selection: §8.4.4 expressly preserves
threshold-based Frost restrictions even when the human cannot yet win.

The fixtures are controlled phase integrations with explicit historical clock
and one-shot-flag assumptions. They use canonical physical helpers, real deck
draws, production Interlude/Winter execution, and validated saves. Their limits
are adequately disclosed; they establish the mechanisms and do not claim a
natural full-game encounter frequency. No production changes were made.

Reproduce from the repository root:

```sh
PYTHONHASHSEED=0 PYTHONDONTWRITEBYTECODE=1 .venv/bin/python ../audit8-work/validation/review_lifecycle.py
PYTHONHASHSEED=987 PYTHONDONTWRITEBYTECODE=1 .venv/bin/python ../audit8-work/validation/review_lifecycle.py
```
