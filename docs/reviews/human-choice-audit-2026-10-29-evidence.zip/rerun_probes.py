"""Rerun the frozen audit witnesses against a checkout; NOT regression tests.

Usage: python rerun_probes.py --repo /path/to/fs-bot --out /tmp/audit-rerun
Use the project's test interpreter. Assertions describe the audited defects;
after repairs they are expected to fail until converted to desired-behavior tests.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

SCRIPTS = ('action_timing.py', 'base_events_probe.py', 'base_events_extra.py', 'battle_march.py',
           'commands_probe.py', 'commands_cli_probe.py', 'expansion_events_probe.py',
           'frontends_inventory.py', 'frontends_invalid_supply.py',
           'frontends_stale_board.py', 'winter_setup_probe.py')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    root = args.repo.resolve()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    source = Path(__file__).resolve().parent / 'probes'
    probe_dir = out / 'probes'
    probe_dir.mkdir()
    for name in SCRIPTS:
        shutil.copyfile(source / name, probe_dir / name)
    env = os.environ.copy()
    env['PYTHONPATH'] = str(root)
    env['PYTHONHASHSEED'] = '0'
    def run(name):
        proc = subprocess.run([sys.executable, str(probe_dir / name)], cwd=root,
                              env=env, stdin=subprocess.DEVNULL,
                              capture_output=True, text=True, timeout=120)
        (out / (name + '.stdout.txt')).write_text(proc.stdout)
        (out / (name + '.stderr.txt')).write_text(proc.stderr)
        return {'script': name, 'exit_code': proc.returncode,
                'script_sha256': hashlib.sha256((probe_dir / name).read_bytes()).hexdigest(),
                'stdout': name + '.stdout.txt', 'stderr': name + '.stderr.txt'}
    with ThreadPoolExecutor(max_workers=3) as pool:
        checks = list(pool.map(run, SCRIPTS))
    result = {'checks': checks, 'passed': all(c['exit_code'] == 0 for c in checks),
              'audited_defect_witnesses_not_desired_behavior_tests': True}
    (out / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    if not result['passed']:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
