# Base Event review

Reviewed Falling Sky b23c8cd73c9747e6e39157a042a1af13cc703a48 against its supplied card text and Chapters 1, 5, and 7. Liberty or Death 2991ea279062773548ec390a1da75f3e85381702 supplied the comparison method through docs/human_mode_audit.md, docs/card1_human_choice_audit.md, and lod_ai/event_choices.py. Its correction from hook inventory to printed choices led to checking target predicates even for already wired Event parameters.

Seven confirmed groups have twenty executable witnesses, covering original and second-edition profiles. Every fixture passes validate_state before and after, every authored response passes durable validate_response, and every effect runs through execute_decision. The witnesses assert observed defects and exit zero while those defects exist. They exercise durable validation and normal Event execution, rather than a full persisted assistant session. Reports identify when a defect requires an illegal authored input versus when a legal selection produces the wrong effect.

The static sweep sampled numeric handler bodies and delegated paths for target restrictions, minimums, quantities, piece identity, and owner-scoped effects. Close source comparison and new witnesses concentrate on cards 7, 11, 19, 23, 52, 56, and 68. Existing modules for Boii, Roman Wine, Surus, and named effects supplied validation patterns. The existing Lucterius test named as a Successor relocation actually creates Vercingetorix, encoding the defect.

All ten previously unverified base rows were re-read. They cover 34 shaded, 60 shaded, 61 shaded, and both aliases of 69 in each explicit edition. Their scarce-pool allocation question remains unresolved, as recorded individually in prior-unverified.json. Fixed replacement loops have no separate scarcity selection, but the supplied instruction to execute text in order does not settle the allocation interpretation conclusively. These rows add no confirmed bugs.

Capability flag searches found several write-only descriptive flags. Observation-point inspection showed corresponding behavior handled directly in the resolver for Numidians, Aquitani, and Marcus Antonius. Those unused flags are not counted as missing effects. No new claim is made about already recorded Circumvallation persistence or adopted provisional rulings.

Limits include no exhaustive combinations of all capabilities, no new complete game matrix, no new live CLI transcript, and no repair changes. The original 50 findings retain their closed dispositions. This review does not certify every remaining Event path.
