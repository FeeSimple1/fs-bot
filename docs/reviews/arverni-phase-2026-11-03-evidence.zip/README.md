# Ordinary Arverni Phase evidence — 3 November 2026

Parent: 474a5929dfd54c06ecb3731c558493013c04c3de. Final source is
candidate-source-attempt2.json. The only production edit is
fs_bot/engine/arverni_phase.py; source-derived tests cover seven defects.

## Acceptance provenance

- parent-suite.log/xml: fresh parent full suite, 7,149 passing tests.
- candidate-suite.log/xml: first full suite, 7,204 pass and one stale Seize
  test fails because it expects an Ally without Arverni Control. Preserved.
- candidate-suite-attempt2.log/xml: final full suite after correcting only
  that test; verify its exit and JUnit totals before accepting.
- attempt1/integration-results.json: frozen-source gameplay matrix,
  150 bot games, 25 hash repeats, 220 mixed cases at two hash seeds with
  replay (880 executions), and 20 strict census executions.
- production-equivalence-attempt1-to-attempt2.json: only one test file
  changed afterward. All 187 non-test Python files are identical. Gameplay
  results keep their actual attempt1 source labels; they are not relabeled.
- causal-review/: 58 paired full-game traces explain the first divergence
  in all 29 changed winner/card-count cases, plus Seize Rally witnesses.
- parent-provenance-preflight.json and attempt1/parent-record-provenance.json:
  reused parent records were measured with the preceding accepted source,
  whose exact bytes were subsequently committed as 474a592.

## Retained failures

The engine/ directory retains an initial nonexistent fixture label and a
supplemental missing helper failure, their corrections, and valid negative
regressions against the parent. independent-before-invalid-import-path.log
is disqualified because it imported candidate source; corrected runs verify
the actual parent import path. Expected old-source regression failures are
not failures of the repaired production code. The first full-suite stale
Seize assertion remains separately recorded.

## Reproduction

Use Python 3.10.22, the recorded hash seeds and exact source manifests.
Scripts assume this directory beside fs-bot and the detached parent checkout
fs-arverni-phase-before; adjust paths when extracting elsewhere. Apply the
corresponding prepared-source patch to parent474 for each snapshot. Both
patches include the new tests. Never mix or overwrite attempts. The report
and results JSON explain which source supports each measurement.

Reference Documents, rules_consts.py and the committed balance baseline
remain unchanged. No win-rate tuning or baseline refresh was used.
