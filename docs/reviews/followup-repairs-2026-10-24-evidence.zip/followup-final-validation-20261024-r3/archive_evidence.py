from pathlib import Path
import hashlib,json,zipfile,re
root=Path(__file__).resolve().parent.parent
repo=root/'fs-bot'; final=Path(__file__).resolve().parent
output=repo/'docs/reviews/followup-repairs-2026-10-24-evidence.zip'
assert not output.exists(), 'Refuse to overwrite published evidence'
entries=[]
for name in ('followup-final-validation-20261024','followup-final-validation-20261024-r2','followup-final-validation-20261024-r3'):
 base=root/name
 for path in sorted(base.rglob('*')):
  if not path.is_file():continue
  relative=path.relative_to(base)
  if any(part in ('__pycache__','.pytest_cache') or part.startswith('staged-') for part in relative.parts):continue
  if path.name in ('commit-groups.json','evidence-manifest.json'):continue
  data=path.read_bytes()
  assert not re.search(rb'github_pat_[A-Za-z0-9_]{20,}|ghp_[A-Za-z0-9]{20,}',data), 'Credential-like content must not enter archive'
  entries.append((path,f'{name}/{relative.as_posix()}',len(data),hashlib.sha256(data).hexdigest()))
manifest={'files':[{'path':name,'bytes':size,'sha256':sha} for _,name,size,sha in entries]}
(final/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for path,name,_,_ in entries:archive.write(path,name)
 archive.write(final/'evidence-manifest.json','evidence-manifest.json')
with zipfile.ZipFile(output) as archive:
 assert archive.testzip() is None
 assert len(archive.namelist())==len(entries)+1
result={'path':str(output.relative_to(repo)),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'files':len(entries)+1}
(final/'archive-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
