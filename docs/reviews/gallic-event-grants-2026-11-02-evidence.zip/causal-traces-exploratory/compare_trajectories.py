"""Compare frozen candidate checkpoints to immediate parent, not old baseline."""
import gzip
import json
from pathlib import Path

out = Path(__file__).resolve().parent
workspace = out.parents[1]
baseline = json.loads((workspace / 'fs-bot/fs_bot/tools/balance_baseline.json').read_text())['games']


def load(stem, label):
    with gzip.open(out / f'{label}-{stem}.jsonl.gz', 'rt') as source:
        rows = [json.loads(line) for line in source]
    summary = json.loads((out / f'{label}-{stem}-summary.json').read_text())
    return rows, summary


def key(row):
    return {k: row[k] for k in ('index', 'card_index', 'card', 'stage', 'faction')}


def board(row):
    # _card_turn embeds action execution receipts. Added result annotations
    # are not a changed board, rule choice, or RNG result.
    return {k: v for k, v in row['board'].items() if k != '_card_turn'}


def choice(row):
    return {k: v for k, v in row.get('decision', {}).items() if k != 'execution'}


records = []
for scenario, seed in [('The Great Revolt', 1), ('The Great Revolt', 3), ('The Gallic War', 1)]:
    stem = scenario.lower().replace(' ', '-') + '-' + str(seed)
    parent, ps = load(stem, 'parent-e37b965')
    candidate, cs = load(stem, 'candidate-1922429')
    first_choice = first_board = first_rng = first_annotation = first_behavior = None
    for left, right in zip(parent, candidate):
        if key(left) != key(right):
            break
        if first_annotation is None and left != right:
            first_annotation = key(left)
        if first_choice is None and choice(left) != choice(right):
            first_choice = key(left)
        if first_board is None and board(left) != board(right):
            first_board = key(left)
        if first_rng is None and left['rng'] != right['rng']:
            first_rng = key(left)
        if first_behavior is None and (board(left) != board(right)
                or left['rng'] != right['rng'] or choice(left) != choice(right)):
            first_behavior = {'checkpoint': key(left),
                'parent_choice': choice(left), 'candidate_choice': choice(right),
                'same_prechoice_board': parent[left['index'] - 1]['board'] == candidate[right['index'] - 1]['board'],
                'same_prechoice_rng': parent[left['index'] - 1]['rng'] == candidate[right['index'] - 1]['rng'],
                'same_postchoice_board': board(left) == board(right),
                'same_postchoice_rng': left['rng'] == right['rng'],
                'remi': left['board']['tribes']['Remi']}
            (out / f'first-semantic-{stem}.json').write_text(json.dumps(
                {'parent': left, 'candidate': right}, indent=2) + '\n')
    record = {'scenario': scenario, 'seed': seed,
        'older_committed_balance_baseline': baseline[f'{scenario}|{seed}'],
        'immediate_parent_reproduced': {'winner': ps['winner'], 'cards': ps['cards']},
        'frozen_candidate_reproduced': {'winner': cs['winner'], 'cards': cs['cards']},
        'first_behavior_divergence': first_behavior,
        'first_physical_board_divergence': first_board,
        'first_rng_divergence_within_aligned_prefix': first_rng,
        'first_any_annotation_divergence': first_annotation,
        'checkpoint_counts': {'parent': len(parent), 'candidate': len(candidate)}}
    if first_behavior is None:
        record['finding'] = ('All 427 checkpoints have identical board, RNG and choices. '
            'This seed already differs from the older committed baseline on immediate parent; '
            'the current bundle does not introduce its winner change.')
    else:
        record['finding'] = ('The first behavioral difference is Belgae declining an ineffective '
            'shaded Remi Influence and taking Rally+Enlist. No Gallic faction owns Remi at '
            'that checkpoint. Parent selected the Event but its effect was a no-op. '
            'Candidate correctly applies the printed ownership condition and the Belgic '
            'requirement to increase Allies+Citadels. This establishes a first intended '
            'rules divergence, not a proof that it alone explains the eventual winner.')
    records.append(record)

report = {'status': 'exploratory frozen attempt1, requires final-source revalidation',
    'parent_commit': 'e37b965e5ce420e29e486c7221661e51b9803282',
    'parent_python_sha256': 'c3c3cd4fd4370f4367db759106b7418449bcc0c27b34ceae2e93c014c64b3bf4',
    'candidate_python_sha256': '192242924a77eca4a608dec95f4d51125e00442baaf23fabf8448d6e0cdd44c4',
    'python': '3.10.22', 'hash_seed': 0, 'parallel_jobs': 1,
    'comparison_rules': 'Ignore embedded _card_turn result receipts and decision.execution annotations when finding behavioral divergence; preserve full raw checkpoints.',
    'source_authority': [
        'Reference Documents/Card Reference, card 68: shaded benefit requires a Gallic faction owning Remi.',
        'Reference Documents/belgae_bot_event_instructions.txt, Remi Influence: unless increasing Belgic Allies+Citadels, treat as No Belgae.',
        'Reference Documents/Ariovistus/belgae_bot_event_instructions_ariovistus.txt, same Remi Influence instruction.'],
    'records': records}
(out / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
