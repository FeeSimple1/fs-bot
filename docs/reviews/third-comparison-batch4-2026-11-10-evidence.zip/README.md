# Falling Sky third comparison, Batch 4 verification

Accepted code is identified by `source.json` and `verification.json`. Its
parent is `9c180986c5bde4f56c5a92e7ed2173bfc7603f82`. The archived paired bot,
mixed, and balance records from Batch 3 match the parent's Python digest.
`parent-regressions.xml` runs the new case files against that clean parent
engine. Failures there are expected evidence of the old behavior.

Copy the scripts, `source.json`, `parent-regressions.xml`, and `parent/` into
a fresh output directory. Run the following from the repaired checkout with
pytest installed. `verify_results.py` validates the outputs against the
checkout's Python-source digest and exact coverage.

```sh
batch4_output=/path/to/fresh-output
python -m pytest -q --junitxml="$batch4_output/pytest.xml"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 21-24 --workers 2 --out "$batch4_output/bots"
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 21-24 --out "$batch4_output/fuzz0.json" > "$batch4_output/fuzz0.txt"
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 21-24 --out "$batch4_output/fuzz987.json" > "$batch4_output/fuzz987.txt"
PYTHONPATH="$PWD" PYTHONHASHSEED=0 python "$batch4_output/run_balance.py" "$batch4_output/balance.json"
python "$batch4_output/verify_results.py" "$PWD"
```

`run_balance.py` evaluates the standard 100 balance games in four processes,
then runs the unchanged guardrail over their results. `trace_reconquest.py`
records actual card results, board state and RNG identity without altering
decisions. Run it against the parent and repaired checkouts with hash seed 0.
Its paired output locates the first differing board on card 43, during the
Roman Seize of the Colony at Atrebates.
