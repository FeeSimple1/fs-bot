# Independent reviewer copy includes permanent Provincia Fort, per Chapter1 1.4.2.
import contextlib,copy,io,json,os,sys,tempfile
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,sys.argv[1])
from fs_bot import rules_consts as r
from fs_bot.state.state_schema import build_initial_state,validate_state,check_structural_integrity
from fs_bot.board.pieces import place_piece,count_pieces,count_pieces_by_state
from fs_bot.state.serialize import save_game,load_game,encode,decode
from fs_bot.tools import llm_seat
from fs_bot.tools.seat_session import SeatSession,validate_response
from fs_bot.cli.display import HumanTurnDisplay
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.free_actions import validate_free_action_response,execute_free_action_plan
from fs_bot.engine import game_engine as ge
OUT=Path(sys.argv[2]);OUT.mkdir(parents=True,exist_ok=True)

def state(seed=1):
 s=build_initial_state(r.SCENARIO_GREAT_REVOLT,seed=seed)
 s.update(current_card=52,current_card_id=52,next_card=16,deck=[16,1,2,3],played_cards=[52],non_player_factions={r.ARVERNI,r.AEDUI,r.BELGAE})
 s['eligibility']={f:(r.ELIGIBLE if f==r.ROMANS else r.INELIGIBLE) for f in r.FACTIONS}
 s['resources'][r.ROMANS]=20
 place_piece(s,r.PROVINCIA,r.ROMANS,r.FORT)
 place_piece(s,r.CARNUTES,r.ROMANS,r.AUXILIA)
 place_piece(s,r.PROVINCIA,r.ROMANS,r.AUXILIA,6)
 place_piece(s,r.SEQUANI,r.BELGAE,r.WARBAND,2)
 clean(s)
 return s

def clean(s):
 assert validate_state(s)==[],validate_state(s)
 assert check_structural_integrity(s)==[],check_structural_integrity(s)

def action():
 return {'command':r.CMD_BATTLE,'regions':[r.SEQUANI],'sa':r.SA_SCOUT,'sa_timing':'before','details':{'battle_plan':[{'region':r.SEQUANI,'target':r.BELGAE}], 'scout_plan':{'auxilia_moves':[{'from_region':r.PROVINCIA,'to_region':r.SEQUANI,'count':2,'piece_state':r.HIDDEN}], 'scout_targets':[]}}}

def snapshot(s):
 return {'roman_sequani':count_pieces(s,r.SEQUANI,r.ROMANS,r.AUXILIA),'belgic_sequani':count_pieces(s,r.SEQUANI,r.BELGAE,r.WARBAND),'roman_provincia':count_pieces(s,r.PROVINCIA,r.ROMANS,r.AUXILIA),'roman_resources':s['resources'][r.ROMANS]}

def read(args):
 return load_game(Path(args.dir)/'save.json',validate=True)

def submit(args,response):
 s,m,l=read(args);p=m['assistant_session']['pending'];assert p
 return llm_seat.cmd_submit(SimpleNamespace(dir=args.dir,response=json.dumps(response),decision_id=p['id']))

def initialize(s,label):
 args=SimpleNamespace(dir=str(OUT/label));Path(args.dir).mkdir()
 meta={'seat':r.ROMANS,'scenario':s['scenario'],'seed':1}
 SeatSession(s,meta,[],HumanTurnDisplay(io.StringIO()))
 save_game(s,Path(args.dir)/'save.json',meta=meta,log=[])
 assert llm_seat.cmd_play(args)==0
 return args

def until(args,kind):
 for i in range(25):
  s,m,l=read(args);p=m['assistant_session']['pending'];assert p
  q=decode(p['request'])
  if q['kind']==kind:return s,m,l
  assert q['kind']!='turn',q
  assert submit(args,{'use_default':True})==0
 raise AssertionError('No expected request')

records={}
with contextlib.redirect_stdout(io.StringIO()) as screen:
 # Ordinary control is accepted and executes the identical pre-Battle Scout.
 s=state();before=snapshot(s)
 submitted={'action':ge.ACTION_COMMAND_SA,'player_action':action()}
 validate_response(s,{'kind':'turn','faction':r.ROMANS,'options':[ge.ACTION_COMMAND_SA]},submitted)
 result=execute_decision(s,r.ROMANS,submitted)
 assert result['executed'] and result['sa_execution']['executed'];clean(s)
 records['ordinary_control']={'before':before,'after':snapshot(s),'result':result}
 # Real save, play, Event submission and nested choice submission.
 args=initialize(state(),'event-session')
 assert submit(args,{'action':ge.ACTION_EVENT,'player_action':{'command':'Event','sa':'No SA','details':{'card_id':52,'text_preference':r.EVENT_SHADED}}})==0
 s,m,l=until(args,'free_action');p=copy.deepcopy(m['assistant_session']['pending']);request=decode(p['request'])
 before=encode(s);journal=copy.deepcopy(m['assistant_session']['journal'])
 assert request['with_sa'] is True and request['allowed_regions'] is None
 assert submit(args,action())==0
 after,am,al=read(args)
 assert am['assistant_session']['pending']==p
 assert encode(after)==before and al==l and am['assistant_session']['journal']==journal
 clean(after)
 records['event_rejection']={'pending_id':p['id'],'request':request,'error':validate_free_action_response(decode(p['board']),r.ROMANS,request,action()),'board_unchanged':True,'rng_unchanged':True,'journal_unchanged':True,'accepted_event':decode(journal[0]['assistant_response'])}
 # Starting-board-presence control: the same free plan becomes accepted.
 s=state();place_piece(s,r.SEQUANI,r.ROMANS,r.AUXILIA)
 error=validate_free_action_response(s,r.ROMANS,request,action());assert error is None,error
 result=execute_free_action_plan(s,r.ROMANS,request,action());assert result['executed'];clean(s)
 records['event_presence_control']={'after':snapshot(s),'result':result}
(OUT/'transcript.txt').write_text(screen.getvalue())
(OUT/'observations.json').write_text(json.dumps(records,indent=2,default=str))
print(json.dumps(records,indent=2,default=str))
