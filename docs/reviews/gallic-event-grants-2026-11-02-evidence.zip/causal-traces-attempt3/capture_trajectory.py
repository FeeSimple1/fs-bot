"""Read-only live-game trace for comparing the immediate parent and frozen candidate.

Run one process per source/game.  The bot callback is balance_smoke's callback,
and instrumentation observes actual engine transactions, never speculative bot
previews.  Trace output includes full serialized checkpoints for independent
comparison; it neither calls RNG nor installs a reactive decision agent.
"""
import argparse
import contextlib
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import sys
import time

ap = argparse.ArgumentParser()
ap.add_argument('--repo', required=True)
ap.add_argument('--scenario', required=True)
ap.add_argument('--seed', type=int, required=True)
ap.add_argument('--label', required=True)
ap.add_argument('--out', required=True)
args = ap.parse_args()
assert os.environ.get('PYTHONHASHSEED') == '0'
sys.path.insert(0, args.repo)

from fs_bot.state.setup import setup_scenario
from fs_bot.state.serialize import encode
from fs_bot.engine import game_engine as game
from fs_bot.engine import execute as execution
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.cli.dispatcher import _translate_bot_action
from fs_bot.tools.validation_metadata import source_identity

out = Path(args.out)
out.mkdir(parents=True, exist_ok=True)
slug = args.scenario.lower().replace(' ', '-').replace('?', '') + '-' + str(args.seed)
path = out / (args.label + '-' + slug)
trace = gzip.open(str(path) + '.jsonl.gz', 'wt', encoding='utf-8')
index = 0
card_index = 0
active_card = None


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def record(stage, state, faction=None, **extra):
    global index
    board = encode({k: v for k, v in state.items() if k != 'decision_agent'})
    rng = board.pop('rng')
    payload = dict(index=index, card_index=card_index, card=active_card,
                   stage=stage, faction=faction, board_sha256=digest(board),
                   rng_sha256=digest(rng), board=board, rng=rng,
                   **encode(extra))
    trace.write(json.dumps(payload, sort_keys=True) + '\n')
    index += 1


def decide(state, faction, options, position):
    record('decision-before', state, faction, options=options, position=position)
    state['current_card_id'] = state.get('current_card')
    state['is_second_eligible'] = (position == '2nd_eligible')
    state['can_play_event'] = (game.ACTION_EVENT in options)
    action = dispatch_bot_turn(state, faction)
    decision = {'action': _translate_bot_action(action, options), 'bot_action': action}
    record('decision-after', state, faction, decision=decision, position=position)
    return decision


original_execute = game._maybe_execute


def execute(state, faction, decision, actions_taken):
    record('execute-before', state, faction, decision=decision)
    result = original_execute(state, faction, decision, actions_taken)
    record('execute-after', state, faction, decision=decision, result=result)
    return result


game._maybe_execute = execute
original_retreat = execution._decide_defender_retreat


def retreat(board, region, attacker, defender, is_ambush):
    # Observe only the live board. Optimizer and ordinary bot previews use
    # detached copies and must not masquerade as executed game decisions.
    live = board is globals().get('state')
    if live:
        record('retreat-before', board, defender, region=region,
               attacker=attacker, is_ambush=is_ambush)
    result = original_retreat(board, region, attacker, defender, is_ambush)
    if live:
        record('retreat-after', board, defender, region=region,
               attacker=attacker, is_ambush=is_ambush, result=result)
    return result


execution._decide_defender_retreat = retreat
started = time.monotonic()
with contextlib.redirect_stdout(io.StringIO()):
    state = setup_scenario(args.scenario, seed=args.seed)
    state['non_player_factions'] = set(game.get_sop_factions(state))
    record('setup', state)
    game.start_game(state)
    card_results = []
    while state['current_card'] is not None:
        card_index += 1
        active_card = state['current_card']
        record('card-before', state)
        result = game.play_card(state, decide, execute=True)
        card_results.append(result)
        record('card-after', state, result=result)
        if result['game_over']:
            break
trace.close()
summary = dict(scenario=args.scenario, seed=args.seed, label=args.label,
               source=source_identity(), python=platform.python_version(),
               hash_seed=os.environ['PYTHONHASHSEED'], card_edition='legacy/default',
               winner=next((r['winner'] for r in reversed(card_results) if r.get('winner')), 'none'),
               cards=len(card_results), checkpoints=index, elapsed=time.monotonic()-started,
               trace=str(path) + '.jsonl.gz', exploratory=False)
Path(str(path) + '-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, sort_keys=True), flush=True)
