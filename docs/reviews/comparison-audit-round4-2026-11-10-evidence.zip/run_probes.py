"""Run the fourth-audit defect witnesses against the pinned source checkout."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('repository', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
repo = args.repository.resolve()
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=False)
root = Path(__file__).resolve().parent
env = dict(os.environ, PYTHONPATH=str(repo), PYTHONHASHSEED='0')
probes = [
    ('base-events/witness.py', 'plain'),
    ('commands/probe_commands.py', 'plain'),
    ('expansion/probe_expansion.py', 'plain'),
    ('bots-review/probe_bots.py', 'repo'),
    ('frontend/probe_frontend.py', 'session'),
    ('frontend/probe_grant_scope.py', 'session'),
    ('frontend/probe_second_sa.py', 'session'),
    ('seasonal/probe_negative_harvest.py', 'plain'),
    ('seasonal/probe_interlude_deck.py', 'plain'),
    ('seasonal/probe_interlude_nori.py', 'plain'),
]
digest = hashlib.sha256()
files = sorted((repo/'fs_bot').rglob('*.py'))
for path in files:
    digest.update(str(path.relative_to(repo)).encode() + b'\0' + path.read_bytes())
identity = dict(source_sha256=digest.hexdigest(), python_files=len(files))
assert identity['source_sha256'] == 'fb0bbf5af4a7513bbac1157f17054948d2ec5b3724ab612296b10a1d017ea51b', identity
records = []
for relative, mode in probes:
    name = relative.replace('/', '--').removesuffix('.py')
    command = [sys.executable, str(root/relative)]
    if mode in ('repo', 'session'):
        command.append(str(repo))
    if mode == 'session':
        command.append(str(out/name))
    run = subprocess.run(command, cwd=repo, env=env, text=True,
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (out/(name+'.log')).write_text(run.stdout)
    records.append(dict(script=relative, exit_code=run.returncode,
                        script_sha256=hashlib.sha256((root/relative).read_bytes()).hexdigest(),
                        log=name+'.log'))
    print(f'{relative}: exit {run.returncode}', flush=True)
(out/'results.json').write_text(json.dumps(dict(source=identity, records=records), indent=2)+'\n')
sys.exit(int(any(row['exit_code'] != 0 for row in records)))
