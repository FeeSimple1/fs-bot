"""Extract source-specific facts from captured identical pre-states; no games."""
from collections import Counter
from copy import deepcopy
import gzip,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parents[1]/'fs-bot'))
from fs_bot import rules_consts as rc
from fs_bot.state.serialize import decode
from fs_bot.cards.named_event_effects import options,np_available,default_params
from fs_bot.board.pieces import count_pieces,get_leader_in_region
from fs_bot.board.control import is_controlled_by
from fs_bot.map.map_data import get_adjacent_for_state
from fs_bot.tools.validation_metadata import source_identity
report=json.loads((root/'first-divergences.json').read_text())
assert source_identity()['source_sha256']==report['source']['candidate']['source_sha256']
rows=[]
for entry in report['pairs']:
 pair=json.loads((root/entry['first_rows_file']).read_text())
 before=decode(pair['candidate']['before']); card=entry['card']
 opts=options(before,card)
 facts={'scenario':entry['scenario'],'seed':entry['seed'],'card':card,
  'kind':entry['kind'],'actor':entry['actor'],'played_card_count':entry['played_card_count'],
  'options':opts,'npc_available':np_available(before,card),
  'default':default_params(deepcopy(before),card)}
 if card==2:
  facts['senate']=before['senate']
  facts['provincia_legions']={label:count_pieces(decode(pair[label]['after']),rc.PROVINCIA,rc.ROMANS,rc.LEGION) for label in ('parent','candidate')}
  facts['legions_track']={label:pair[label]['after']['legions_track'] for label in ('parent','candidate')}
  facts['cause_code']='placed_required_legions' if entry['kind']=='execution' else 'declined_unavailable_legiones'
 elif card in (18,'A18'):
  facts['germania']={r:{'control':before['spaces'][r]['control'],
      'roman_control_neighbors':sorted(p for p in get_adjacent_for_state(before,r) if is_controlled_by(before,p,rc.ROMANS)),
      'german_count':count_pieces(before,r,rc.GERMANS),'german_leader':get_leader_in_region(before,r,rc.GERMANS),
      'germans_after':{label:count_pieces(decode(pair[label]['after']),r,rc.GERMANS) for label in ('parent','candidate')}} for r in rc.GERMANIA_REGIONS}
  facts['cause_code']='named_roman_removal_on_foreign_event' if entry['kind']=='execution' else 'declined_unavailable_rhenus'
 elif card==23:
  facts['roman_resources']=before['resources'][rc.ROMANS]
  facts['cities']={city:before['tribes'][tribe] for city,tribe in rc.CITY_TO_TRIBE.items() if tribe in before['tribes']}
  facts['cause_code']='declined_unavailable_sacking'
 traces={}
 for label in ('parent','candidate'):
  with gzip.open(root/entry['trace_files'][label],'rt') as f:traces[label]=json.load(f)['trace']
 first_state=next(i for i,(a,b) in enumerate(zip(traces['parent'],traces['candidate'])) if a['after']!=b['after'])
 a,b=traces['parent'][first_state],traces['candidate'][first_state]
 facts['first_complete_poststate_difference']={'trace_index_zero_based':first_state,'kind':a['kind'],'card':a['card'],
     'actor':a['faction'],'same_prestate':a['before']==b['before'],
     'same_rng_before':a['before']['rng']==b['before']['rng'],
     'same_rng_after':a['after']['rng']==b['after']['rng'],
     'changed_after_keys':sorted(k for k in set(a['after'])|set(b['after']) if a['after'].get(k)!=b['after'].get(k)),
     'earlier_raw_difference':first_state!=entry['trace_index_zero_based']}
 assert first_state>=entry['trace_index_zero_based']
 facts['raw_prefix_identical']=all(a==b for a,b in zip(traces['parent'][:entry['trace_index_zero_based']],traces['candidate'][:entry['trace_index_zero_based']]))
 facts['first_row_complete_prestate_and_rng_identical']=pair['parent']['before']==pair['candidate']['before']
 assert facts['raw_prefix_identical'] and facts['first_row_complete_prestate_and_rng_identical']
 rows.append(facts)
output={'source':source_identity(),'pairs':rows,'cause_counts':dict(Counter(r['cause_code'] for r in rows)),
 'additional_full_games':0}
(root/'causal-facts.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
