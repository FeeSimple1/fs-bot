"""NP11-01 and NP11-02 before and after the March repairs."""
import argparse
import copy
import json
import pathlib
import sys

p = argparse.ArgumentParser()
p.add_argument('--repo', required=True)
p.add_argument('--repaired', action='store_true')
args = p.parse_args()
sys.path.insert(0, str(pathlib.Path(args.repo).resolve()))

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, count_pieces_by_state, get_available, place_piece, remove_piece, find_leader
from fs_bot.board.control import is_controlled_by
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.bots.belgae_bot import _check_enlist_after_command, node_b4
from fs_bot.bots.german_bot import node_g1b, node_g5
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.cli.dispatcher import _translate_bot_action
from fs_bot.engine.execute import execute_decision, _resolve_free_command
from fs_bot.engine.game_engine import ACTION_COMMAND, ACTION_COMMAND_SA, get_first_eligible_options
from fs_bot.engine.victory import check_any_victory
from fs_bot.map.map_data import get_adjacent, get_tribes_in_region
from fs_bot.state.serialize import encode
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.tools.seat_session import board_copy


def clean(s):
    checks = {'census': validate_state(s), 'structure': check_structural_integrity(s)}
    assert checks == {'census': [], 'structure': []}, checks
    return checks


def position(scenario):
    s = build_initial_state(scenario, seed=6)
    fourth = rc.GERMANS if scenario == rc.SCENARIO_ARIOVISTUS else rc.ARVERNI
    s['non_player_factions'] = {rc.ROMANS, rc.BELGAE, rc.AEDUI, fourth}
    s['can_play_event'] = False
    s['resources'].update({f: 10 for f in s['non_player_factions']})
    place_piece(s, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    return s


def execute(s, faction, *, authored=None, sa=None, command_only=False):
    before = clean(s)
    frozen = encode(board_copy(s))
    action = dispatch_bot_turn(s, faction)
    unchanged = frozen == encode(board_copy(s))
    if args.repaired and faction == rc.GERMANS:
        planned = encode(board_copy(s))
        assert {k: v for k, v in frozen.items() if k != 'rng'} == {
            k: v for k, v in planned.items() if k != 'rng'}
    else:
        assert unchanged
    dispatched = copy.deepcopy(action)
    human = authored is not None
    if human:
        s['non_player_factions'].remove(faction)
        action = authored
    elif sa:
        action['sa'] = sa
        action['sa_regions'] = [rc.TREVERI]
    kind = ACTION_COMMAND if command_only else _translate_bot_action(action, get_first_eligible_options())
    result = execute_decision(s, faction, {'action': kind, 'player_action' if human else 'bot_action': action})
    assert result['executed'] and not result.get('errors'), result
    assert not (result.get('sa_execution') or {}).get('errors'), result
    return {'integrity_before': before, 'integrity_after': clean(s),
            'planning_board_and_rng_unchanged': unchanged, 'dispatched_action': dispatched,
            'executed_action': action, 'action_type': kind, 'execution': result}


def belgic_position(german_region=rc.TREVERI, *, with_sa=True):
    # Pax Gallica permits named Ambiorix; markers can persist from Devastate.
    s = position(rc.SCENARIO_PAX_GALLICA)
    s['_command_with_sa'] = with_sa
    place_piece(s, rc.CARNUTES, rc.BELGAE, rc.LEADER, leader_name=rc.AMBIORIX)
    place_piece(s, rc.MANDUBII, rc.BELGAE, rc.WARBAND, 5)
    if german_region:
        place_piece(s, german_region, rc.GERMANS, rc.WARBAND, 2, piece_state=rc.REVEALED)
    for region in (*rc.BELGAE_HOME_REGIONS, rc.CARNUTES, rc.MANDUBII):
        s['markers'].setdefault(region, {})[rc.MARKER_DEVASTATED] = True
    assert node_b4(s) == 'No'
    return s


def belgic(name, *, region=rc.TREVERI, with_sa=True, authored_sa=None, scoped=False):
    s = belgic_position(region, with_sa=with_sa)
    before_choice = _check_enlist_after_command(s, s['scenario'])
    if scoped:
        before = clean(s)
        result = _resolve_free_command(s, rc.BELGAE,
            allowed_regions={rc.CARNUTES, rc.MANDUBII},
            exclude_commands={rc.CMD_RALLY, rc.CMD_RAID, rc.CMD_BATTLE}, with_sa=True)
        assert result['executed'] and not result.get('errors'), result
        out = {'integrity_before': before, 'integrity_after': clean(s), 'execution': result}
    else:
        out = execute(s, rc.BELGAE, sa=authored_sa, command_only=not with_sa)
        assert out['dispatched_action']['command'] == rc.CMD_MARCH
    out.update(name=name, before_choice=before_choice,
               after_choice=_check_enlist_after_command(s, s['scenario']),
               leader_region=find_leader(s, rc.BELGAE), resources=s['resources'][rc.BELGAE],
               german_hidden=(count_pieces_by_state(s, region, rc.GERMANS, rc.WARBAND, rc.HIDDEN) if region else 0),
               german_revealed=(count_pieces_by_state(s, region, rc.GERMANS, rc.WARBAND, rc.REVEALED) if region else 0))
    if name == 'belgic_new_enlist_omitted':
        assert before_choice is None
        if args.repaired:
            assert out['action_type'] == ACTION_COMMAND_SA
            assert out['german_hidden'] == 2 and out['german_revealed'] == 0
            enlisted = out['execution']['sa_execution']
            assert enlisted['executed'] and enlisted['type'] == 'german_march_hide'
            assert enlisted['region'] == rc.TREVERI
            assert out['leader_region'] == rc.ATREBATES and out['resources'] == 6
        else:
            assert out['action_type'] == ACTION_COMMAND
            assert out['after_choice']['type'] == 'german_march_hide'
            assert out['after_choice']['region'] == rc.TREVERI
            assert out['german_revealed'] == 2 and out['german_hidden'] == 0
            assert 'sa_execution' not in out['execution']
    if authored_sa or name == 'belgic_existing_enlist_control':
        assert out['execution']['sa_execution']['executed']
        assert out['german_hidden'] == 2 and out['german_revealed'] == 0
    if name == 'belgic_stale_positive_control':
        assert before_choice and out['after_choice'] is None
        assert not out['execution']['sa_execution']['executed']
    if not with_sa or scoped:
        assert not (out['execution'].get('sa_execution') or {}).get('executed')
        assert out['german_revealed'] == 2
    if region is None:
        assert out['after_choice'] is None
    return out


def german_position():
    s = position(rc.SCENARIO_ARIOVISTUS)
    place_piece(s, rc.UBII, rc.GERMANS, rc.LEADER, leader_name=rc.ARIOVISTUS_LEADER)
    for region in get_adjacent(rc.UBII, s['scenario']):
        place_piece(s, region, rc.GERMANS, rc.WARBAND)
    place_piece(s, rc.UBII, rc.GERMANS, rc.WARBAND, get_available(s, rc.GERMANS, rc.WARBAND))
    # Exhaust the real pools, so no Rally or Settle can qualify; no markers needed.
    for region in (rc.UBII, rc.SUGAMBRI, rc.TREVERI, rc.SEQUANI):
        for tribe in get_tribes_in_region(region, s['scenario']):
            if get_available(s, rc.GERMANS, rc.ALLY):
                assert _ally_tribe(s, tribe, rc.GERMANS)
    for region in (rc.TREVERI, rc.SEQUANI, rc.CISALPINA, rc.NERVII, rc.MANDUBII, rc.ATREBATES):
        place_piece(s, region, rc.GERMANS, rc.SETTLEMENT)
    # Keep every faction below victory and G1b inactive, with legal Tribe identities.
    for region in (rc.CARNUTES, rc.PICTONES):
        for tribe in get_tribes_in_region(region, s['scenario']):
            assert _ally_tribe(s, tribe, rc.AEDUI)
    for region in (rc.NERVII, rc.MANDUBII, rc.ATREBATES):
        place_piece(s, region, rc.ROMANS, rc.AUXILIA, 2)
    assert check_any_victory(s) is None
    assert node_g1b(s) == node_g5(s) == 'No'
    clean(s)
    return s


def german(name, *, authored=False, adjacent_target=False, frost=False, no_leader=False):
    s = german_position()
    if adjacent_target:
        place_piece(s, rc.TREVERI, rc.ROMANS, rc.AUXILIA, 4)
    if frost:
        s['frost'] = True
    if no_leader:
        remove_piece(s, rc.UBII, rc.GERMANS, rc.LEADER)
    action = None
    if authored:
        action = {'command': rc.CMD_MARCH, 'sa': 'No SA',
                  'details': {'origins': [rc.UBII], 'destinations': [rc.TREVERI],
                              'groups': {rc.UBII: {rc.LEADER: True, rc.WARBAND: 25}}}}
    out = execute(s, rc.GERMANS, authored=action)
    out.update(name=name, leader_region=find_leader(s, rc.GERMANS),
               ubii_warbands=count_pieces(s, rc.UBII, rc.GERMANS, rc.WARBAND),
               treveri_warbands=count_pieces(s, rc.TREVERI, rc.GERMANS, rc.WARBAND),
               resources=s['resources'][rc.GERMANS])
    if name == 'german_surrounded_leader_raid':
        if args.repaired:
            assert out['dispatched_action']['command'] == rc.CMD_MARCH
            assert out['leader_region'] in get_adjacent(rc.UBII, s['scenario'])
            assert out['ubii_warbands'] == 1 and out['resources'] == 9
            assert count_pieces(s, out['leader_region'], rc.GERMANS, rc.WARBAND) == 26
            assert is_controlled_by(s, rc.UBII, rc.GERMANS)
            assert any(not is_controlled_by(s, neighbor, rc.GERMANS)
                       for neighbor in get_adjacent(out['leader_region'], s['scenario']))
        else:
            assert out['dispatched_action']['command'] == rc.CMD_RAID
            assert out['leader_region'] == rc.UBII and out['ubii_warbands'] == 26
    if authored:
        assert out['leader_region'] == rc.TREVERI and out['ubii_warbands'] == 1
        assert out['treveri_warbands'] == 26 and out['resources'] == 9
    if adjacent_target:
        assert out['dispatched_action']['command'] == rc.CMD_MARCH
    if frost or no_leader:
        assert out['dispatched_action']['command'] == rc.CMD_RAID
    return out


results = [
    belgic('belgic_new_enlist_omitted'),
    belgic('belgic_authored_enlist_control', authored_sa=rc.SA_ENLIST),
    belgic('belgic_existing_enlist_control', region=rc.MANDUBII),
    belgic('belgic_stale_positive_control', region=rc.BITURIGES),
    belgic('belgic_no_sa_control', with_sa=False),
    belgic('belgic_absent_germans_control', region=None),
    belgic('belgic_scoped_free_control', scoped=True),
    german('german_surrounded_leader_raid'),
    german('german_authored_toward_control', authored=True),
    german('german_adjacent_target_control', adjacent_target=True),
    german('german_frost_control', frost=True),
    german('german_no_leader_control', no_leader=True),
]
print(json.dumps({'case_count': len(results), 'cases': results}, sort_keys=True, indent=2))
