"""Capture the unchanged Ariovistus17 A45 default failure at its source."""
import gzip, json, sys, traceback
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'fs-bot'))
from fs_bot.cards import expansion_validation as ev
from fs_bot.tools import player_fuzz
from fs_bot.state.serialize import encode
from fs_bot.tools.validation_metadata import source_identity
before=source_identity(); original=ev._default_entry; failures=[]
def wrapped(state,card_id,owner,choices,previous_region=None,**kwargs):
 try:return original(state,card_id,owner,choices,previous_region,**kwargs)
 except TypeError:
  failures.append({'card_id':card_id,'owner':owner,'choices':choices,'previous_region':previous_region,'traceback':traceback.format_exc(),'state':encode({k:v for k,v in state.items() if k!='decision_agent'})})
  raise
ev._default_entry=wrapped
result=player_fuzz.play_game('Ariovistus',17)
assert source_identity()==before
with gzip.open(HERE/'a45-source-failure.json.gz','wt') as f:json.dump({'source':before,'result':result,'failures':failures},f)
for failure in failures:
 print(failure['card_id'],failure['owner'],failure['choices']);print(failure['traceback'])
print(result)
