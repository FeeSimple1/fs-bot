# Falling Sky comparative audit evidence

Audited Falling Sky commit `b23c8cd73c9747e6e39157a042a1af13cc703a48`.
Liberty or Death comparison commit `2991ea279062773548ec390a1da75f3e85381702`.

The finding ledger records 21 confirmed groups. Each partition includes its
probe scripts, observations, and coverage notes. The assertions deliberately
freeze the observed defects. They should be translated into expected legal
behavior when the corresponding repairs are implemented.

Run all nine scripts against a checkout of the audited Falling Sky revision.
Python 3.10 or newer and the game package are sufficient.

```sh
python run_probes.py /path/to/fs-bot /path/to/new-results
```

The output directory must be new. Each script gets its own log. The runner
returns a nonzero status if any witness fails to reproduce. Findings requiring
malformed authored input exercise durable validation and normal execution.
The two full frontend journeys initialize ordinary games without editing a
board or save. Other cases use controlled initialized positions.

The audit report and combined ledger accompany this ZIP in the repository.
The full existing suite passed 9,334 tests. The independent review and the
portable rerun cover all nine scripts. No new balance study was performed.
