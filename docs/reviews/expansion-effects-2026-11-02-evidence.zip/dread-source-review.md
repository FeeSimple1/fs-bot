# A22 Dread — bounded independent source review

Read-only review for EXP-10 on parent 95e7a20. Supplied source inventory and CLAUDE.md checked; no production or protected files changed. No external rules consulted. PR-01–09 are unrelated to this specific interaction and remain unchanged.

## Certain source requirements

- `Ariovistus/A Card Reference`, A22 shaded: “Intimidate may Reveal 1 added Warband to remove 1 extra piece.” Ordinary Intimidate therefore may use three Warbands/removals rather than its normal maximum of two. This does not change eligible Regions, target piece types, the single target Faction, or that Faction's Leader protection.
- `Ariovistus/Chapter A4`, A4.6.2: “Each selected Region, flip one or two Hidden Germanic Warbands to Revealed” to place the marker and remove that many Warbands, Auxilia, and/or Allies “of one Faction that has no Leader there.” Regional eligibility is Ariovistus present, or Germanic Control with his proximity/Successor conditions.
- A4.6.2 note distinguishes intrinsic Raid Intimidate from a later ordinary Intimidate using additional Hidden Warbands. They are separate resolutions, and the intrinsic resolution does not spend the accompanying Special Ability.
- `Ariovistus/Chapter A3`, A3.4.3: Germans Raid one or two Hidden Warbands, and “such Warbands Raiding with Ariovistus in the Region may free Intimidate at the same time”. Actual Raid participants may thus supply the ordinary Reveal requirement; unrelated old Revealed Warbands may not be invented as credits.
- With only one or two actual Raiders, a Dread bonus beyond those participants needs an additional genuinely Hidden Warband. One Raider plus one extra permits two removals; two Raiders plus one extra permit three. The Capability's extra is optional and is for an extra removal, not a free fictional Reveal or an automatic marker-only expenditure.
- `Ariovistus/Chapter A8`, A8.7.1 lists the target priorities (player Allies, Romans then Aedui then Belgae; player Auxilia/Aedui/Belgic Warbands; NP Roman/Aedui Allies; other NP Roman/Aedui pieces) and excludes guaranteed subsequent Battle removals. It only uses ordinary marker-only Intimidate after a qualifying removal, while intrinsic Ariovistus Raid may place a marker alone. §8.1.3 executes sequential priorities to maximum extent. No special Dread override occurs in the German Event instruction sheet, so Dread's extra capacity should feed those existing priorities when it removes another qualifying piece.
- Unshaded A22 says Intimidate and Intimidated markers have no effect on Romans; the wrong side must not activate the extra Reveal.

## Baggage Trains interaction — interpretation requiring parent review

Base card 8 shaded says “Your Raids may use 3 Warbands per Region”; its Tip explicitly changes Raid's normal two to three. It does not separately change Intimidate's normal two. Therefore **four Intimidate removals are not supported**: A22 adds only one to Intimidate's ordinary two.

The supplied text does not expressly say that Dread's added Warband must be a **non-raiding** Warband. A3.4.3 says the actual Raiders may Intimidate “at the same time”; together with card 8's three Raiders and A22's three-Intimidator capacity, the third simultaneously revealed Raider can plausibly satisfy the added Reveal. A hard rule requiring a fourth, fresh non-raiding Warband in every three-Raider case would introduce a restriction not explicitly in the text.

A literal combined implementation to consider is: ordinary credit cap two without Dread; with Dread, allow three removals using three actual Raid participants without another fresh flip. Also allow an explicit extra-fresh-Warband choice that uses up to two actual Raider credits plus one Hidden flip. Never allow four removals. This is a derived reading, not a discovered designer FAQ; it was sent to the implementing parent/root for resolution before commitment. No new project ruling has been assumed here.

A29's “They free Raid” keeps the granted operation tied to its actual newly placed surviving cohort. Existing physical-force scope should continue to constrain any additional Hidden piece participating in that operation; resident Ariovistus's presence remains a distinct prerequisite rather than a new Raider. This preserves the preceding source-reviewed grant boundary; no broader resident participation permission was found in A22.

## Suggested direct regressions

Ordinary Dread three versus ordinary two; wrong side/absent Capability; one-Faction/Leader protection and exact visibility; two-Raider intrinsic bonus consumes one genuine Hidden piece; one-Raider plus bonus permits only two; old unrelated Revealed pieces never grant credits; no Hidden bonus piece rejects before mutation; Baggage three-Raider interaction matches the final source decision and never permits four removals; normal subsequent Intimidate remains independent; NP exact priorities and exclusion of guaranteed subsequent losses; A29 executor ownership and actual cohort restrictions.


## Parent resolution and second-stage code review — 2026-11-03

The implementing parent and root/effects reviewer accepted the simultaneous interpretation described above: with card 8 shaded and A22 shaded, three actual Raiders can supply three removals without a fourth counter. With only one or two actual Raiders, a further removal requires one genuinely Hidden additional participant. An explicit fresh-participant choice remains available; it uses at most two actual Raider credits plus that fresh counter. This is a source-derived combined reading, not a new designer clarification.

Read-only review of the in-progress implementation found two integration issues, both corrected during review: (1) the explicit A22 Capability side must override a stale legacy unshaded flag, and (2) the non-timing human Intimidate collector must use the same immunity helper as the executor. The ordinary, timing, typed engine, A45, and German NPC consumers now route their capacity through the shared Dread-aware rule. The remaining A45 applicability probe's old two cap was only a boolean existence check; the parent also centralized that caller during review.

The intrinsic adapter correctly distinguishes actual Raider credit from an explicit fresh participant, validates physical target visibility before mutations, retains one-Faction and enemy-Leader restrictions, preserves A29 executor ownership and its actual placed-cohort scope, and defaults to spending no additional Hidden piece when three actual Raiders already provide the full Dread capacity. Ordinary Intimidate after Raid is computed from the previewed/live post-intrinsic board; the preview is detached and preserves the live RNG state. The current test additions cover selected quantities, exact visibility, wrong/absent/removed Capability, forged credit, no fourth removal, CLI optionality, after-Raid residual budgets, A29 scope, and durable invalid/pending/save/replay choices. No additional functional hard-two cap was found in the examined Intimidate consumers.

A nearby pre-existing same-card gap was independently reproduced and sent to the parent for scope decision: `commands/rally.py:validate_recruit_region` treats an Intimidated marker as blocking Romans despite active unshaded A22. With a Roman Fort in Ubii and unshaded Dread, validation returns `(True, None)` before adding the marker, then `(False, 'Region is Intimidated and has no Roman Leader')` after adding it. A22 explicitly says the markers have no effect on Romans. The new shared immunity helper can address that conditional while leaving other Recruit restrictions intact.

An unchanged NPC policy limitation was flagged separately for a future combat-policy audit, not changed as part of this review: `_check_intimidate_before_battle` excludes the entire selected defender Faction, whereas A8.7.1 excludes only pieces guaranteed removed in the immediately following Battle. Existing tests intentionally enforce the broader exclusion, so repairing that requires a distinct source-backed guaranteed-loss projection review.

No production, protected source, constant, or baseline file was edited by this reviewer. Full-suite validation and final implementation freeze remain the parent's responsibility.
