from pathlib import Path
import json
r=Path('/workspace/scratch/534c265c65f4/fs-bot');e=Path(__file__).resolve().parent
accepted=json.loads((e/'acceptance-results.json').read_text());assert accepted['accepted']
a=json.loads((e/'archive-check.json').read_text())
p=r/'docs/current-status.md';s=p.read_text();needle='## Follow-up repairs\n'
text='''
### 3 November Event Battle choices — BE-02 closed

The [Event Battle repair](reviews/event-battle-choices-2026-11-03.md) restores
human Region and defender choices on 11/25/36/45/70 while retaining each
card's mandatory follow-on, printed exceptions and cooperation permissions.
It also protects revised Numidians' excluded Roman counters, removes Aedui
self-double-counting in Litaviccus, and includes Event Loss modifiers in
non-player Retreat forecasts. Board/card inspection and durable save/replay
are covered by the new regressions.

**20/50 original findings are closed (40%); 30 remain open.** The 34
unverified inventory rows, three unadopted source questions and eleven
existing provisional rulings remain separate. Non-player Litaviccus target
prediction is a newly documented follow-up; card 70's whole-benefit
acceptance and March planning remain part of BE-01.

The exact source passes **7,347 tests**, including 142 added cases, and all
142 added cases also pass on Python 3.12. Validation includes 150 bot games,
25 additional bot hash-seed repeats, 220 mixed-player cases with replay and
cross-hash repetition (880 executions), and 20 strict-census executions.
All recorded gameplay fields in the 150 bot games match the verified parent;
this is not a complete trajectory comparison. The existing balance baseline
and 15-percentage-point limit remain unchanged. See the report for source
identity, parent provenance, limitations and retained evidence.
'''
assert needle in s;s=s.replace(needle,needle+text,1);p.write_text(s)
p=r/'docs/reviews/event-battle-choices-2026-11-03.md';s=p.read_text()
old='''Final source identity, measured results and evidence will be recorded after
the integrated checks complete. The parent full suite and GitHub checks are
reused only after exact-source verification; gameplay comparisons preserve
the preceding matrix's original source labels and its documented test-only
equivalence to this parent.
'''
new='''The exact accepted Python source is 452 files, SHA-256
`7d627253f5b38bdedcfe5c84214a5476f68898d1f9cd11d50ef29377a42fe108`,
prepared over parent `4e9a82ed35052198987dad4c91dd79ce9c5b4ab9`.
No Python source changed between the freeze, full suite and game matrix.
All 49 protected files (47 supplied references, canonical constants and the
existing balance baseline) retain their original bytes.

| Check | Result |
|---|---|
| Full suite, Python 3.10.22 | 7,347 passed; zero failures, errors or skips |
| New regression cases, Python 3.12.14 | All 142 passed |
| Independent final Retreat review | 57 focused cases passed; no acceptance blocker |
| Zero-player games | 150 completed and audited across all five scenarios and three edition profiles |
| Bot repeat under another Python hash seed | 25 additional executions; matching recorded results |
| Mixed-player validation | 220 distinct cases, replayed and repeated at hash seeds 0 and 7: 880 executions; zero hard findings or partial games |
| Strict census | 20 completed executions; zero illegal or failed games; cross-hash output matches |
| Parent comparison | All 150 records match in gameplay fields, including final-state hash; elapsed time and source labels excluded |
| Existing balance check | Passes the unchanged 15-percentage-point limit; baseline file unchanged |

Bots use legacy seeds 1–20 and original/second-edition seeds 201–205.
Mixed-player checks use legacy seeds 1–40 and each explicit edition's seeds
201–202; census uses seeds 201–202. These are bounded regression samples,
not an exhaustive rules proof or a new balance estimate. Equality of the
recorded game results does not prove every intermediate decision identical.
The constructed regressions exercise repaired edge cases that these bot
seeds did not change.

The six new regression modules cover engine legality and card exceptions,
terminal choices/display, independent source examples, durable sessions,
Numidians physical participants and randomized human-choice coverage.
Final parent-negative runs reproduce defects before repair; retained passing
controls protect existing behavior. Earlier failed development attempts,
including a withdrawn borrowed-only fixture and a private-helper free-cost
fixture correction, remain labeled as superseded evidence rather than
counted as additional product defects. The earlier setup attempt without
pytest is retained separately from passing verification.

The parent's 7,205-test suite and 14 passing GitHub checks are reused after
exact-source verification. Parent gameplay records retain their original
source labels: the previous matrix's production files are byte-identical
to this parent, with only a subsequent test expectation changed. The archive
includes that 187-production-file equivalence proof, original parent records,
commands, manifests, current raw results, focused logs and JUnit. No paired
trajectory rerun was needed because no recorded NPC gameplay result changed.

## Progress and retained evidence

BE-02 is closed. The original audit now stands at **20/50 closed (40%),
with 30 open**. This measures grouped findings, not engineering effort or
overall game correctness. Related mechanics repaired here do not inflate the
original denominator. Three unadopted source questions and the 34 unverified
inventory rows remain separate; the eleven existing provisional rulings are
unchanged.

- [Machine-readable acceptance](event-battle-choices-2026-11-03-results.json)
- [Evidence archive](event-battle-choices-2026-11-03-evidence.zip)

'''
new+=f"Archive: {a['bytes']:,} bytes, {a['indexed_files']} indexed files; SHA-256\n`{a['sha256']}`. Its member sizes and hashes were verified after packaging.\n"
assert old in s;s=s.replace(old,new);p.write_text(s)
(r/'docs/reviews/event-battle-choices-2026-11-03-results.json').write_text(json.dumps(accepted,indent=2)+'\n')
