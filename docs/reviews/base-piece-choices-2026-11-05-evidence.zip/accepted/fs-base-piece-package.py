from pathlib import Path
import hashlib, io, json, platform, subprocess, tarfile, tempfile, zipfile
import xml.etree.ElementTree as ET
from fs_bot.tools.validation_metadata import source_identity

prefix='base-piece-choices-2026-11-05'
result=json.loads(Path('/tmp/fs-base-piece-results.json').read_text())
assert source_identity()==result['source']
suite=ET.parse('/tmp/fs-base-piece-full.xml').getroot().find('testsuite')
assert suite.attrib['tests']=='8858'
assert all(suite.attrib[k]=='0' for k in ('failures','errors','skipped'))
assert sum(t.attrib['classname'].endswith('test_base_piece_choices') for t in suite)==89
patch=subprocess.check_output(['git','diff','HEAD','--','fs_bot'])
new_files=('fs_bot/cards/base_piece_choices.py','fs_bot/cli/base_piece_choices.py',
           'fs_bot/tests/test_base_piece_choices.py')
with tempfile.TemporaryDirectory(prefix='fs-base-piece-reconstruct-') as directory:
    root=Path(directory)
    parent=subprocess.check_output(['git','archive',result['source']['commit'],'fs_bot'])
    with tarfile.open(fileobj=io.BytesIO(parent)) as archive:
        archive.extractall(root,filter='data')
    subprocess.run(['git','apply','--unsafe-paths','-'],cwd=root,input=patch,check=True)
    for name in new_files: (root/name).write_bytes(Path(name).read_bytes())
    files=sorted((root/'fs_bot').rglob('*.py'))
    assert len(files)==529
    digest=hashlib.sha256()
    for path in files: digest.update(str(path.relative_to(root)).encode()+b'\0'+path.read_bytes())
    assert digest.hexdigest()==result['source']['source_sha256']
commands=[
 'python -m pytest -q --junitxml=/tmp/fs-base-piece-full.xml',
 'python -m pytest -q fs_bot/tests/test_base_piece_choices.py fs_bot/tests/test_card_effects.py fs_bot/tests/test_param_schema.py fs_bot/tests/test_human_plan.py fs_bot/tests/test_event_action_windows.py fs_bot/tests/test_event_timing_planning.py fs_bot/tests/test_event_timing_review.py fs_bot/tests/test_assistant_session.py fs_bot/tests/test_player_fuzz.py',
 'python -m pytest -q fs_bot/tests/test_base_piece_choices.py --junitxml=/tmp/fs-base-piece-directed.xml',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --games 2 --workers 2 --out OUT',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
 'PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
 'PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20',
 'python -m pytest -q /tmp/test_base_piece_parent_proof.py --junitxml=OUT.xml',
 'PYTHONPATH=. python /tmp/fs-base-piece-verify.py',
 'PYTHONPATH=. python /tmp/fs-base-piece-package.py']
result.update(full_suite=suite.attrib,python=platform.python_version(),commands=commands,
    source_reconstruction_verified=True,
    compatibility_limit='Older histories can stop at the new live request or diverge under corrected Gallic Hostages replacements. Legacy explicit plans retain their contract. Expanded human choices change the fuzz agent decision sequence.')
Path('docs/reviews/'+prefix+'-results.json').write_text(json.dumps(result,indent=2)+'\n')
p=Path('docs/reviews/'+prefix+'.md');s=p.read_text().replace('Final full-suite and evidence inspection pending.',
    f"**8,858 tests pass**, with zero failures, errors or skips ({float(suite.attrib['time']):.2f} seconds).")
x=result['mixed'];b=result['balance']
s=s.replace('Frozen source, protected inputs, final results and archive checksums are\nverified separately.',f'''All ten paired NPC games finish and audit cleanly, with four ranked factions,
consistent winner/ranking output, no integrity findings and only legal-decline
diagnostics. Every gameplay field and final state hash matches the parent,
excluding elapsed seconds, commit and source identity. The Gallic War seed 1
completes its Interlude.

Complete mixed-seat JSON matches across hash seeds 0/987: ten completed games,
{x['human_turns']} human turns, {x['event_turns']} Event attempts and {x['events_ok']} successful Events, zero hard findings
and zero partials. Internal replay gives 40 executions. Digest:
`{x['batch_digest'][:16]}`. The historical 100-game balance guard passes its
unchanged 15-point band, maximum drift {b['maximum_absolute_delta_percentage_points']} percentage points, with
{b['historical_baseline_winner_changes']} historical winner changes. These historical comparisons are separate from
the ten exact parent/current pairs.

All 49 protected inputs match the parent byte for byte: 47 supplied references,
canonical constants and the balance baseline. Archive checksums and exact
529-file source reconstruction verify the accepted digest.''');p.write_text(s)
p=Path('docs/current-status.md');s=p.read_text().replace('Validation pending the final full suite and evidence inspection.',
    '''**8,858 tests pass**, including 89 new cases; 294 focused tests pass. Ten paired
NPC records/final hashes match the parent. Mixed-seat JSON matches across hash
seeds with zero hard findings or partials. The unchanged 100-game balance guard
passes. The report records the exact source, protected inputs, evidence and
cross-revision replay limit.''',1);p.write_text(s)
entries={}
for name in ['fs-base-piece-full.xml','fs-base-piece-full.log','fs-base-piece-directed.xml',
 'fs-base-piece-directed.log','fs-base-piece-targeted.log','fs-base-piece-mixed0.json',
 'fs-base-piece-mixed0.log','fs-base-piece-mixed987.json','fs-base-piece-mixed987.log',
 'fs-base-piece-balance.log','fs-base-piece-proof-parent.xml','fs-base-piece-proof-parent.log',
 'fs-base-piece-proof-final.xml','fs-base-piece-proof-final.log','test_base_piece_parent_proof.py',
 'fs-base-piece-verify.py','fs-base-piece-package.py']:
    entries['accepted/'+name]=Path('/tmp/'+name).read_bytes()
for label,directory in [('parent','/tmp/fs-base-piece-bots-parent'),('accepted','/tmp/fs-base-piece-bots-final')]:
    for path in Path(directory).iterdir():
        if path.is_file(): entries[label+'/bots/'+path.name]=path.read_bytes()
for name in ['fs-base-piece-initial.log','fs-base-piece-directed-development.log']:
    entries['development/'+name]=Path('/tmp/'+name).read_bytes()
entries['development/README.txt']=b'The initial sanity command named a missing test file and ran no tests. The first directed run had seven fixture failures because all 20 Aedui Warbands were already on the map, leaving none Available for the expected replacements. The accepted fixture places 18 before testing two replacements. Accepted directed, focused and full results are separate. No protected inputs changed.\n'
entries['accepted/source.patch']=patch
for name in new_files: entries['accepted/'+name]=Path(name).read_bytes()
protected=[p for p in Path('Reference Documents').rglob('*') if p.is_file()]
protected += [Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
entries['accepted/protected-inputs.json']=json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected},indent=2).encode()
entries['accepted/results.json']=json.dumps(result,indent=2).encode()
entries['commands.txt']=('\n'.join(commands)+'\n\nRun parent/current NPC batches and unchanged proof script in their respective directories. All matrices are bounded regressions; directed tests exercise the new choices.\n').encode()
entries['README.txt']=(f"Parent {result['source']['commit']}. Apply accepted/source.patch and copy the three accepted/fs_bot new files to reconstruct the accepted digest {result['source']['source_sha256']} across 529 Python files. Full suite 8858 passed, 89 new cases, 294 focused. Eight probes give six parent behavioral failures and two passing controls; all eight pass on the repair. Ten native NPC records and final hashes match. Mixed complete JSON matches across hash seeds 0/987, no hard findings or partials. Historical 100-game balance passes unchanged 15-point band. Original bundle remains 40/50 closed (80%): BE-06 retains numeric 3/5 mandatory Roman allocations, BE-07/08 retain other cards. {result['compatibility_limit']}\n").encode()
entries['SHA256SUMS.txt']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(entries.items())).encode()
p=Path('docs/reviews/'+prefix+'-evidence.zip')
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,data in sorted(entries.items()): archive.writestr(name,data)
with zipfile.ZipFile(p) as archive:
    assert archive.testzip() is None
    for line in archive.read('SHA256SUMS.txt').decode().splitlines():
        digest,name=line.split('  ',1)
        assert hashlib.sha256(archive.read(name)).hexdigest()==digest
print(json.dumps({'suite':suite.attrib,'source':result['source'],'archive_bytes':p.stat().st_size}))
