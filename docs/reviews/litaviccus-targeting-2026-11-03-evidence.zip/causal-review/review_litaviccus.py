"""Pair changed all-edition records and capture the first live divergence.

Preparation is read-only; --run requires a frozen candidate and completed
matrix bot records. Traces retain their exact source and audit results.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import gzip
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
PARENT_SHA = '7d627253f5b38bdedcfe5c84214a5476f68898d1f9cd11d50ef29377a42fe108'
IGNORED = {'seconds', 'source_sha256', 'commit'}


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def records(directory, prefix):
    rows = {}
    for edition in ('legacy', 'original', 'second-edition'):
        for row in map(json.loads, (directory / (prefix + edition) / 'games.jsonl').read_text().splitlines()):
            key = (edition, row['scenario'], row['seed'])
            assert key not in rows
            rows[key] = row
    assert len(rows) == 150
    return rows


def semantic(row):
    return {k: v for k, v in row.items() if k not in IGNORED}


def trace(directory):
    with gzip.open(directory / 'trace.jsonl.gz', 'rt') as stream:
        return [json.loads(line) for line in stream]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--matrix', type=Path, required=True)
    parser.add_argument('--candidate-sha', required=True)
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    parent = records(args.matrix, 'parent-bots-')
    candidate = records(args.matrix, 'bots-')
    assert parent.keys() == candidate.keys()
    assert {r['source_sha256'] for r in parent.values()} == {PARENT_SHA}
    assert {r['source_sha256'] for r in candidate.values()} == {args.candidate_sha}
    changed = sorted(k for k in parent if semantic(parent[k]) != semantic(candidate[k]))
    plan = {'candidate_sha256': args.candidate_sha, 'parent_sha256': PARENT_SHA,
            'compared_records': 150, 'changed_semantic_records': changed,
            'matrix_directory': str(args.matrix),
            'comparison_scope': 'Recorded gameplay fields excluding time/source labels, not full trajectories.'}
    print(json.dumps({'changed_cases': changed, 'captures_planned': 2 * len(changed)}), flush=True)
    if not args.run:
        return
    out = HERE / args.attempt
    out.mkdir(exist_ok=False)
    write(out / 'plan.json', plan)
    jobs = []
    for edition, scenario, seed in changed:
        slug = edition + '-' + scenario.lower().replace(' ', '-').replace('?', '') + '-' + str(seed)
        for label, repo, sha in [('parent', ROOT / 'fs-litaviccus-before', PARENT_SHA),
                                 ('candidate', ROOT / 'fs-bot', args.candidate_sha)]:
            path = out / (label + '-' + slug)
            command = [sys.executable, str(HERE / 'capture_litaviccus.py'), '--repo', str(repo),
                       '--scenario', scenario, '--seed', str(seed), '--edition', edition,
                       '--expected-source', sha, '--out', str(path)]
            jobs.append((edition, scenario, seed, label, path, command))

    def run(job):
        edition, scenario, seed, label, path, command = job
        result = subprocess.run(command, cwd=ROOT / 'fs-bot',
                                env={**os.environ, 'PYTHONHASHSEED': '0'}, text=True, capture_output=True)
        (out / (path.name + '.log')).write_text(result.stdout + result.stderr)
        return {'edition': edition, 'scenario': scenario, 'seed': seed, 'label': label,
                'path': str(path), 'command': command, 'exit_code': result.returncode}

    with ThreadPoolExecutor(max_workers=2) as executor:
        launches = list(executor.map(run, jobs))
    write(out / 'launches.json', launches)
    assert all(job['exit_code'] == 0 for job in launches), 'Capture failure retained; inspect launches/logs'
    reviews = []
    for key in changed:
        edition, scenario, seed = key
        paths = {j['label']: Path(j['path']) for j in launches
                 if (j['edition'], j['scenario'], j['seed']) == key}
        expected = {'parent': parent[key], 'candidate': candidate[key]}
        for label, path in paths.items():
            observed = json.loads((path / 'summary.json').read_text())['result']
            assert semantic(observed) == semantic(expected[label]), (key, label, 'matrix outcome mismatch')
        a, b = trace(paths['parent']), trace(paths['candidate'])
        first = None
        for old, new in zip(a, b):
            aligned = (old['stage'], old['card_index'], old['current_card']) == (
                new['stage'], new['card_index'], new['current_card'])
            difference = (not aligned or any(old.get(field) != new.get(field)
                          for field in ('board_sha256', 'rng_sha256', 'result')))
            if difference:
                first = {'parent': old, 'candidate': new,
                         'preceding_parent': a[old['index'] - 1] if old['index'] else None,
                         'preceding_candidate': b[new['index'] - 1] if new['index'] else None,
                         'aligned': aligned}
                break
        assert first, (key, 'no first divergence despite changed record')
        old, new = first['parent'], first['candidate']
        previous_old, previous_new = first['preceding_parent'], first['preceding_candidate']
        matched_input = bool(previous_old and previous_new and
            previous_old['board_sha256'] == previous_new['board_sha256'] and
            previous_old['rng_sha256'] == previous_new['rng_sha256'])
        expected_stage = old['stage'] in ('_resolve_card45_battle-after', 'decision-after')
        filename = paths['candidate'].name.removeprefix('candidate-') + '-first-divergence.json'
        write(out / filename, first)
        reviews.append({'edition': edition, 'scenario': scenario, 'seed': seed,
                        'first_stage': old['stage'], 'card_index': old['card_index'],
                        'current_card': old['current_card'], 'aligned': first['aligned'],
                        'equal_preceding_board_and_rng': matched_input,
                        'within_litaviccus_boundary': expected_stage and matched_input,
                        'semantic_board_changed': old['board_sha256'] != new['board_sha256'],
                        'rng_changed': old['rng_sha256'] != new['rng_sha256'],
                        'parent_result': old.get('result'), 'candidate_result': new.get('result'),
                        'first_divergence_file': filename, 'matrix_outcome_reproduced': True})
    summary = {**plan, 'capture_executions': len(launches), 'reviews': reviews,
               'all_traces_match_matrix_records': True,
               'all_first_divergences_at_litaviccus': all(r['within_litaviccus_boundary'] for r in reviews),
               'source_review_required': bool(reviews),
               'limits': 'Boundary attribution still requires reviewing target scores/rules; it does not prove every later action.'}
    write(out / 'review-summary.json', summary)
    print(json.dumps({'reviewed_cases': len(reviews), 'all_first_divergences_at_litaviccus':
                      summary['all_first_divergences_at_litaviccus']}), flush=True)
    assert summary['all_first_divergences_at_litaviccus'], 'Unexplained first divergence; inspect retained evidence'


if __name__ == '__main__':
    main()
