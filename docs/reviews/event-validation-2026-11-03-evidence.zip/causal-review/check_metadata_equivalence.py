"""Check the three replay-order exceptions through their next actual execution."""
from copy import deepcopy
import contextlib, io, json, sys
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parents[1]/'fs-bot'))
from fs_bot.engine.execute import execute_decision
from fs_bot.state.serialize import encode,decode
from fs_bot.tools.validation_metadata import source_identity
summary=json.loads((root/'first-divergences.json').read_text())
assert source_identity()['source_sha256']==summary['source']['candidate']['source_sha256']
replays=json.loads((root/'candidate-first-row-replays.json').read_text())['replays']
rows=[]
for r in replays:
 if r['exact_replay']:continue
 entry=next(s for s in summary['pairs'] if (s['scenario'],s['seed'])==(r['scenario'],r['seed']))
 pair=json.loads((root/entry['first_rows_file']).read_text())
 decision=pair['candidate']; snapshots=[]; results=[]
 for key in ('expected_result','actual_result'):
  state=decode(decision['after'])
  with contextlib.redirect_stdout(io.StringIO()):
   result=execute_decision(state,r['faction'],deepcopy(r[key]))
  results.append(encode(result)); snapshots.append(encode(state))
 assert results[0]==results[1],(r['scenario'],r['seed'],'execution result')
 assert snapshots[0]==snapshots[1],(r['scenario'],r['seed'],'execution state/RNG')
 expected=deepcopy(r['expected_result']);actual=deepcopy(r['actual_result'])
 expected_order=expected['bot_action']['details']['sa_details'].pop('trade_regions')
 actual_order=actual['bot_action']['details']['sa_details'].pop('trade_regions')
 assert expected==actual and sorted(expected_order)==sorted(actual_order)
 rows.append({'scenario':r['scenario'],'seed':r['seed'],'card':r['card'],
              'only_difference':'bot_action.details.sa_details.trade_regions order',
              'expected_order':expected_order,'decoded_order':actual_order,
              'same_decision_poststate_and_rng':r['exact_state'],
              'same_following_execution_result':True,'same_following_full_state_and_rng':True})
(root/'metadata-equivalence.json').write_text(json.dumps({'source':summary['source']['candidate'],'exceptions':rows,
 'limitation':'These three decision payloads are not byte-identical after sorted map serialization. Each selected the same action and has identical decision and next-execution state/RNG. Existing unused Trade metadata only; no new full games.'},indent=2)+'\n')
print(json.dumps({'metadata_exceptions':len(rows),'all_next_executions_identical':True}))
