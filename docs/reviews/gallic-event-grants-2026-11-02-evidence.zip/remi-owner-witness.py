"""Run unchanged against the parent and repaired checkout via PYTHONPATH."""
import json
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.engine.execute import _execute_event
from fs_bot.state.state_schema import build_initial_state, validate_state

results = []
for case, params in [('foreign_preselection', {'target_city': rc.CITY_ALESIA}),
                     ('named_owner_response', {})]:
    state = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=612)
    _ally_tribe(state, rc.TRIBE_REMI, rc.AEDUI)
    state['executing_faction'] = rc.BELGAE
    state['non_player_factions'] = set()
    state['event_params'] = {}
    calls = []
    def choose(board, faction, request):
        calls.append({'faction': faction, 'request_type': request.get('request_type')})
        return {'target_city': rc.CITY_ALESIA}
    state['decision_agent'] = choose
    result = _execute_event(state, rc.BELGAE, {'command': rc.FIRST_DID_EVENT,
        'details': {'card_id': 68, 'text_preference': rc.EVENT_SHADED,
                    'event_params': params}}, human=True)
    results.append({'case': case, 'executed': result['executed'],
                    'rejected': result.get('rejected', False), 'requests': calls,
                    'pieces_at_Alesia': {f: {p: count_pieces(state, rc.MANDUBII, f, p)
                         for p in (rc.CITADEL, rc.WARBAND)} for f in (rc.AEDUI, rc.BELGAE)},
                    'validation_errors': validate_state(state)})
print(json.dumps(results, indent=2))
