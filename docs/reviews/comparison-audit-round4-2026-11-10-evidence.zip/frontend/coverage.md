# Fourth comparison audit — frontend partition

Audited Falling Sky commit b951908af2b21cc87a7e27d9a5314b3f257d0147. No repository sources modified.

## Comparison and method

Read Liberty or Death `docs/human_mode_audit.md` (including its correction that hook inventories are not printed-choice completeness), `lod_ai/engine.py` action simulation/commit and Event/free-operation flow, and relevant typed choices in `lod_ai/event_choices.py`. These prompted checking the same actual execution path as validation, granting all printed human decisions, and separating Non-player defaults from human choices. Game conclusions use Falling Sky supplied references only.

Read current CLAUDE.md, current-status, all three comparison findings/ledgers, original 490-row inventory selections, relevant QUESTIONS.md scope, and inspected the complete Reference Documents file listing. Static review covered SeatSession validation, receipts, checkpoint/restore, journal integrity and legacy compatibility, llm_seat play/submit/replay, game_engine eligibility/action recording, player ownership/Interlude seat handover, resource-transfer frame/choice validation, generic free-action validation/execution and SA plan normalization.

## Confirmed

Three grouped findings in `findings.json`, independently reproducible by three scripts. FE4-01 exercises actual durable saved session/play/submit and checks rejected-response atomicity. FE4-02 and FE4-03 exercise public `execute_decision` through full printed Events and capture the actual human requests.

The fixtures are controlled states built with `build_initial_state` and official piece helpers. They set current Event/deck/eligibility explicitly where necessary. Every fixture and completed result passes census/structure. They are not claims of randomly discovered full-game sequences.

## Supported or rejected leads

- Engine-owned turn metadata and journal collisions remain guarded. Third-audit regression module rerun, no reopening of FE3-01.
- Alternate ordinary March footprints, Event identity and action types now have normalization and authority guards. No new finding counted here.
- Durable rejection in FE4-01 correctly preserves original board, RNG, accepted Event and pending request. The defect is rejection of a legal plan, not transaction corruption.
- Canonical out-of-scope Mons Scout is correctly rejected with complete Event rollback. Legal Scout out of the destination is allowed, as §5.4 permits. Only the null/nested lookup mismatch is counted.
- Assembly52's Non-player single-SA resolution has an existing explicit source disposition in QUESTIONS.md. No new claim is made about bots. The original audit mistakenly marked the human second-SA path supported; this is a newly verified human gap.
- Generic malformed nested JSON can raise broader exceptions than the durable response catch list; no severity/count claim made without a durable loss-of-progress witness.
- No claims about maliciously edited saves, retrospective replay recertification, specialized-menu completeness for every Event, or unexamined grants.

## Rerun

Use Python 3.10+; runtime dependencies are standard library. Each output path must be new, especially the durable session probe.

```
python probe_frontend.py /path/to/fs-bot /path/to/new-session-results
python probe_grant_scope.py /path/to/fs-bot /path/to/new-scope-results
python probe_second_sa.py /path/to/fs-bot /path/to/new-second-sa-results
```

The probe assertions freeze observed defects plus positive controls, and must be rewritten to source-correct expectations during repair.

Initial exploration of the scope witness incorrectly expected an exception to escape. Public Event execution instead returns a rejected result and rolls back; the final assertion checks that actual contract. No code change was needed, and this exploratory correction does not affect the confirmed scope bypass.

## Independent fixture correction

The base-Events reviewer identified that the first controlled fixtures omitted the permanent Provincia Fort. Final scripts now include it. FE4-03 now Builds a Roman Ally at Subdued Helvii rather than an impermissible additional Provincia Fort. Final accepted outputs are `final-session`, `final-scope`, and `final-second-sa`; earlier run1/scope1/second-sa1 and rerun outputs are superseded exploration, not accepted witnesses. All three final scripts pass after this correction.
