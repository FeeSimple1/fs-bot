"""Pair changed outcomes at their first Aedui planning or execution difference."""

import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, get_leader_in_region
from fs_bot.engine import game_engine, winter_campaign
from fs_bot.state.serialize import encode
from fs_bot.tools import player_fuzz, run_batch
from fs_bot.tools.validation_metadata import source_identity


def digest(value):
    return hashlib.sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def board_hash(state):
    return digest({k: v for k, v in state.items() if k != 'decision_agent'})


def snapshot(state, action):
    regions = set(action.get('regions', ())) | set(action.get('sa_regions', ()))
    pieces = (rc.WARBAND, rc.AUXILIA, rc.LEGION, rc.ALLY, rc.CITADEL, rc.FORT, rc.SETTLEMENT)
    return {
        'resources': {f: state['resources'].get(f, 0) for f in (rc.AEDUI, rc.ROMANS)},
        'capabilities': state.get('capabilities', {}).copy(),
        'regions': {
            region: {
                faction: {
                    **{p: count for p in pieces if (count := count_pieces(state, region, faction, p))},
                    **({'leader': leader} if (leader := get_leader_in_region(state, region, faction)) else {}),
                }
                for faction in rc.FACTIONS if count_pieces(state, region, faction)
            }
            for region in sorted(regions)
        },
    }


def trace(task, mixed):
    cards, plans = [], []
    play_card = game_engine.play_card
    maybe_execute = game_engine._maybe_execute
    winter_execute = winter_campaign._execute_plan

    def record_command(state, faction, action, kind, run, *, is_bot=True):
        if faction != rc.AEDUI:
            return run()
        row = {'phase': kind, 'action': deepcopy(action), 'bot': is_bot,
               'before': snapshot(state, action)}
        plans.append(row)
        result = run()
        row['result'] = deepcopy(result)
        row['after'] = snapshot(state, action)
        return result

    def record_sequence(state, faction, decision, actions_taken):
        action = decision.get('bot_action') or decision.get('player_action') or {}
        return record_command(
            state, faction, action, 'sequence',
            lambda: maybe_execute(state, faction, decision, actions_taken),
            is_bot='bot_action' in decision)

    def record_campaign(state, faction, action, *args, **kwargs):
        return record_command(
            state, faction, action, 'winter',
            lambda: winter_execute(state, faction, action, *args, **kwargs),
            is_bot=kwargs.get('uses_bot', False))

    def record_card(state, decide, **kwargs):
        plans.clear()
        row = {'ordinal': len(cards) + 1, 'scenario': state['scenario'],
               'card': state['current_card'], 'before_sha256': board_hash(state),
               'before_rng_sha256': digest(state['rng'].getstate())}
        result = play_card(state, decide, **kwargs)
        row.update(after_sha256=board_hash(state),
                   after_rng_sha256=digest(state['rng'].getstate()),
                   actions={f: {'action': rec['action'], 'execution': deepcopy(rec.get('execution'))}
                            for f, rec in result.get('turn_result', {}).get('actions_taken', {}).items()},
                   actions_sha256=digest(result.get('turn_result', {}).get('actions_taken', {})),
                   aedui=list(plans), winner=result.get('winner'))
        cards.append(row)
        return result

    with (patch.object(game_engine, 'play_card', record_card),
          patch.object(run_batch, 'play_card', record_card),
          patch.object(game_engine, '_maybe_execute', record_sequence),
          patch.object(winter_campaign, '_execute_plan', record_campaign)):
        if mixed:
            scenario, seed, edition = task
            result = player_fuzz.play_game(scenario, seed, card_edition=edition)
            assert result['game_completed'] and not result['findings'], result
            outcome = {'digest': result['digest']}
        else:
            result = run_batch.play_one(task)
            assert result['completed'], result['errors']
            assert cards[-1]['after_sha256'] == result['final_state_sha256']
            outcome = {key: result[key] for key in
                       ('winner', 'cards', 'winters', 'termination', 'final_state_sha256')}
    return {'task': task, 'cards': cards, 'outcome': outcome}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pairs', type=Path, nargs='+')
    parser.add_argument('--mixed', action='store_true')
    args = parser.parse_args()
    tasks = [task for path in args.pairs for task in json.loads(path.read_text())]
    games = [trace(task, args.mixed) for task in tasks]
    print(json.dumps(encode({'source': source_identity(), 'games': games}),
                     sort_keys=True, separators=(',', ':')))


if __name__ == '__main__':
    main()
