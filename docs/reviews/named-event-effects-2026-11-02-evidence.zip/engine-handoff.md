# BE-04 engine handoff — named-faction optional Events

Stable candidate (before parent commit): parent `2edf53e6a0dae774b391e64ce883fdcc5f622ba9`; 422 Python files, SHA256 `9d4cc73f2efaa33b8e6ad871fb432ae43c7471d5222b1c13d9c9b571c0c3c4a8`.

## Scope and source decisions

Covered numeric Card 2 unshaded, 18 unshaded, 23 unshaded, 26 shaded and their existing second-edition dispatch aliases. Added distinct expansion A18 unshaded as the same directly adjacent ownership defect. A18 remains distinct from numeric18. No other sides changed.

Sources are the supplied `Reference Documents/Card Reference` entries 2,18,23,26; `Reference Documents/Ariovistus/A Card Reference` A18; Chapter 5 §§5.1–5.1.3; Chapter 8 §§8.2.3,8.3.1,8.3.4,8.4.1; Ariovistus A1.4/A8.2.3/A8.3.1; and the Roman/Arverni faction Event instructions. Independent source reviewer `/root/named_event_review` confirmed the decisions below. No external research or provisional rule choices were introduced.

- Named owner is Romans for 2/18/A18/23 and Arverni for 26, independently of the Event executor. The owner may accept exact choices, explicitly decline, or explicitly use a seeded default.
- Accepted Legiones shifts Senate first and places exactly two Legions as far as possible. Off-track Senate or Firm Uproar prevents the prerequisite shift and therefore the effect. Nonfirm Uproar may flip Firm. Humans may accept fewer than two when stock is genuinely short; the Roman NPC instruction declines unless both can be placed. No printed Track-versus-Fallen priority exists, so complete legal allocations use seeded equal selection. Existing NPC code shifted Senate but placed zero; the new default supplies counts.
- Rhenus targets legal Germania Regions under or adjacent to Roman Control. A18 additionally excludes the Region containing named Ariovistus. “All Germans” includes Scouted Warbands, Allies, Settlements and removable Successor; the old A18 implementation omitted Scouted Warbands and Successor. Humans retain legal empty-Region targets.
- Sacking permits any City at Roman Control, including own, empty, Dispersed and already-Razed Cities. It replaces the exact selected City's allegiance/structure, sets Razed and adds eight Roman Resources up to 45. No supplied source restricts human selection to fresh/enemy Cities or adds a Razed supply cap. NPC selection excludes already-Razed zero-effect targets at the resource cap and prefers enemy structures/Allies under printed priorities. The old broad Citadel-cleanup loop is removed, but this is not claimed as demonstrated collateral damage on a valid one-City-per-Region board.
- Gobannitio removes exact Allies of any faction in Arverni Region, never Citadels, and places only legal Available Arverni Allies. Empty rearrangement lists can still offer the independently optional free Rally within 1 of actual Vercingetorix. Explicit whole-effect decline skips that later Rally.

## Contract

`fs_bot/cards/named_event_effects.py` exports `supported(card_id, shaded)`, `owner(card_id)`, `options(state, card_id)`, detached `preview(state, card_id, params, complete=False)`, `validate_response(state, faction, request, response)`, `default_params`, `request`, `execute`, `derive_params`, and `np_available`.

Reactive request type is `named_event_effect`, with `kind=free_action`, named `acting_faction`, exact `card_id`, `allow_decline=True`, `validate_default_response=True`, and current legal options. Concrete responses:

- 2: `legions_from_track`, `legions_from_fallen`, nonnegative exact integer counts.
- 18/A18: `target_region`; A18 also normalizes its previous `region` alias and rejects disagreement.
- 23: `target_city`, an actual City constant rather than a Tribe.
- 26: `ally_removals` and `ally_placements`, ordered exact Tribe lists without duplicate entries within a component.
- `decline` or `use_default` must be the sole field and exactly boolean true.

Missing or invalid human responses remain pending under SeatSession. Foreign executors cannot supply the named owner's choices. Preview is detached, excludes decision-agent consultation, and preserves the input board/RNG. Initial CLI Event plans intentionally collect no owner selections; the live named-owner request collects them on the current board.

## Timing authority and edge fixes

The trusted action-window scope retains the original Event executor. Only while applying an owner response, `executing_faction` becomes the named owner, so Arverni can author its independent Spring entry. This does not authorize foreign-owner reclamation of either its own or the executor's pieces. Original executor fields are restored afterward.

Owner responses support only `stage_timing_actions`, not silently ignored top-level `timing_actions`. Supported component keys are `2.legions`, `2.fallen_legions`, and exact 26 removal/placement indices including the tail window. Unknown, malformed, duplicate-form or out-of-range stage keys reject.

Original outer Event params additionally retain `handler_complete` and (26 only) `grant.card_26_arverni_rally`. These are stripped from the owner-effect plan and remain in the original restored Event params for the outer engine to consume under the original executor. Owner replies may not author those outer stages. This preserves a parent-compatible outer Rally grant stage that initial stricter validation accidentally rejected.

Legion source availability can change at the later `2.fallen_legions` window through legal reclamation. The engine places the currently available part of the chosen Track allocation first and defers an initially unavailable remainder until that later window, without moving authored timing. Complete validation rejects any still-impossible source allocation and still enforces the full possible quota. Frontend revisits allocations when a late change makes a new complete source mix available, including when the old mix already totals two.

## Files and tests

Engine-owned changes: new `cards/named_event_effects.py`; handler delegation in `cards/card_effects.py`; condition/schema routing; `engine/execute.py` derivation and `engine/free_actions.py` validation hook; new `tests/test_named_event_effects.py` (77 cases). Existing `test_event_grant_outcomes.py` Citadel-as-Ally witness now expects explicit ValueError and retains its unchanged-Citadel assertions, because that submitted target is illegal.

Frontend owns its new collector, CLI hooks and 42 CLI cases; durable child owns 25 SeatSession cases. Total 144 new cases. The final combined focused pass is **430 passed in 1.43s**, logged in `engine-focused-final-03.log`. Parent owns the mandatory full-suite and integration matrix; those are not claimed as complete here.

Meaningful regressions cover ownership, accept/decline/default, exact targets and source splits, human/NPC distinctions, alias/scenario dispatch, Senate behavior, state integrity, RNG determinism and preview purity, foreign Spring authority, forbidden owner reclamation, forged stages, late source availability, outer Rally-stage compatibility and atomic impossible-source rejection. CLI/session coverage additionally checks saved pending requests, invalid responses, replay and journal/RNG/board preservation.

## Evidence provenance

`engine-witness-before.json` ran `engine-witness.py` against the untouched parent worktree. Parent: NPC2 placed 0 Legions after shifting Senate; A18 left one Scouted Warband and the Successor; all witness starting/ending state integrity checks passed.

`engine-witness-after-final-02.json` corresponds to the stable hash above. Candidate: NPC2 places 2; A18 removes all German pieces; integrity checks pass. Earlier after JSONs refer to earlier candidate hashes and are retained rather than overwritten.

`engine-focused-final-02.log` retains the failing frontend late-source-option witness during concurrent work (429 passed / 1 failed). `engine-focused-final-03.log` is the subsequent passing stable run. Other earlier failed/fixed runs remain in the evidence directory. Reviewer's outer-stage before/candidate witness independently demonstrates the compatibility issue that is now repaired.

No protected Reference Documents, rules constants, balance baselines, commits or pushes were modified by this agent. Source is frozen; only this evidence handoff was written after freeze.
