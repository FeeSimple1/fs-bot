"""Trace Quarters in the public games whose paired records differ."""

from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces
from fs_bot.engine import winter
from fs_bot.state.serialize import encode
from fs_bot.tools import player_fuzz, run_batch
from fs_bot.tools.validation_metadata import source_identity


def digest(value):
    return hashlib.sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def snapshot(state):
    excluded = {'rng', 'decision_agent', '_card_turn', '_resolved_card'}
    return {'board': digest({key: value for key, value in state.items() if key not in excluded}),
            'rng': digest(state['rng'].getstate())}


def trace(task, *, mixed=False):
    quarters = []
    resolve = winter.quarters_phase
    declare = winter._apply_relocations

    def observe_phase(state, *args, **kwargs):
        row = {'scenario': state['scenario'], 'winter': state['winter_count'],
               'before': snapshot(state), 'romans': None, 'agreements': []}
        quarters.append(row)
        row['result'] = resolve(state, *args, **kwargs)
        row['after'] = snapshot(state)
        return row['result']

    def observe_relocation(state, faction, moves):
        if faction != rc.ROMANS or not quarters:
            return declare(state, faction, moves)
        row = quarters[-1]
        row['romans'] = {
            'before': snapshot(state),
            'control': {r: s['control'] for r, s in state['spaces'].items()},
            'troops': {r: {p: count_pieces(state, r, rc.ROMANS, p)
                           for p in (rc.LEGION, rc.AUXILIA)}
                       for r in state['spaces']},
            'moves': moves,
        }
        if mixed:
            from fs_bot.engine.quarters import _QuartersAgreementCache
            ask = _QuartersAgreementCache.__call__

            def observe_agreement(cache, board, host, request):
                answer = ask(cache, board, host, request)
                if request.get('kind') == 'agreement':
                    row['agreements'].append([host, request['request_type'], answer])
                return answer

            with patch.object(_QuartersAgreementCache, '__call__', observe_agreement):
                result = declare(state, faction, moves)
        else:
            result = declare(state, faction, moves)
        row['romans']['after'] = snapshot(state)
        return result

    with ExitStack() as patches:
        patches.enter_context(patch.object(winter, 'quarters_phase', observe_phase))
        patches.enter_context(patch.object(winter, '_apply_relocations', observe_relocation))
        if mixed:
            scenario, seed, edition = task
            outcome = player_fuzz.play_game(scenario, seed, card_edition=edition)
            assert outcome['game_completed'] and not outcome['findings']
        else:
            outcome = run_batch.play_one(task)
            assert outcome['completed'] and not outcome['errors']
            outcome = {k: outcome[k] for k in ('winner', 'cards', 'final_state_sha256')}
    return {'task': task, 'outcome': outcome, 'quarters': quarters}


def main():
    root = Path(__file__).resolve().parent
    tasks = json.loads((root / 'trace-legacy-tasks.json').read_bytes())
    games = [trace(task) for task in tasks]
    mixed_tasks = json.loads((root / 'trace-mixed-tasks.json').read_bytes())
    print(json.dumps(encode({'source': source_identity(), 'games': games,
                             'mixed': [trace(task, mixed=True) for task in mixed_tasks]}),
                     indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
