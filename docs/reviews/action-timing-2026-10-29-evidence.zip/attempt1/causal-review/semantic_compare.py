"""Keep raw localization; separately skip the documented Seize report expansion."""
from pathlib import Path
import gzip,json,hashlib
from collections import Counter
ROOT=Path(__file__).resolve().parent

def read(path):
 with gzip.open(path,'rt') as f:return json.load(f)
def sha(value):return hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()
def normalize(value):
 if isinstance(value,list):return [normalize(v) for v in value]
 if not isinstance(value,dict):return value
 # Candidate's extra per-Region Seize result list is a report, while the
 # old aggregate fields (and all actual board/action state) remain compared.
 return {k:normalize(v) for k,v in value.items() if not
         (k=='regions' and value.get('command')=='Seize' and 'regions_resolved' in value)}
def diffs(left,right,path=''):
 if left==right:return []
 if isinstance(left,dict) and isinstance(right,dict):
  return [d for key in sorted(set(left)|set(right)) for d in diffs(left.get(key,'__ABSENT__'),right.get(key,'__ABSENT__'),path+'/'+str(key))]
 return [{'path':path,'parent':left,'candidate':right}]

def main():
 summaries=[]
 for folder in sorted(ROOT.iterdir()):
  if not(folder/'comparison.json').exists():continue
  old,new=read(folder/'parent.json.gz'),read(folder/'candidate.json.gz')
  assert old['passed'] and new['passed']
  rows1,rows2=old['checkpoints'],new['checkpoints']
  previous=None;ignored=[];first=None
  descriptor=('stage','card_index','card','faction','position','depth')
  for index,(a,b) in enumerate(zip(rows1,rows2)):
   same_boundary=all(a.get(k)==b.get(k) for k in descriptor)
   sa,sb=normalize(a['state_snapshot']),normalize(b['state_snapshot'])
   decision=b['stage'] in ('before_decision','after_decision','before_execute')
   same_decision=not decision or normalize(a.get('payload'))==normalize(b.get('payload'))
   if not same_boundary or sa!=sb or not same_decision:
    changed=sorted(k for k in set(sa)|set(sb) if sa.get(k)!=sb.get(k))
    first={'ordinal':index,'boundary':{k:b.get(k) for k in descriptor},'same_boundary':same_boundary,'changed_domains':changed,
       'rng_changed':a['rng_sha256']!=b['rng_sha256'],'decision_differs':not same_decision,
       'parent_payload':a.get('payload'),'candidate_payload':b.get('payload'),
       'state_changes':diffs({k:v for k,v in sa.items() if k!='rng'},{k:v for k,v in sb.items() if k!='rng'}),
       'previous_equal_boundary':previous,
       'parent_state_sha256':a['state_sha256'],'candidate_state_sha256':b['state_sha256']}
    # Locate the exact immediate preceding action/decision input, for a
    # local replay probe. It is only a causal input if both normalized
    # snapshots and payloads match, which is asserted in the report.
    needed='before_decision' if b['stage']=='after_decision' else 'before_execute'
    matches=[(j,x,y) for j,(x,y) in enumerate(zip(rows1[:index],rows2[:index]))
             if x['stage']==y['stage']==needed and x.get('faction')==y.get('faction')==b.get('faction')]
    if matches:
     j,x,y=matches[-1]
     first['input']={'ordinal':j,'boundary':{k:y.get(k) for k in descriptor},'state_equal':normalize(x['state_snapshot'])==normalize(y['state_snapshot']),
                     'payload_equal':normalize(x.get('payload'))==normalize(y.get('payload')),
                     'parent_state_sha256':x['state_sha256'],'candidate_state_sha256':y['state_sha256'],
                     'parent_payload':x.get('payload'),'candidate_payload':y.get('payload')}
    break
   if a['state_sha256']!=b['state_sha256']:
    ignored.append({'ordinal':index,'boundary':{k:b.get(k) for k in descriptor},'domains':[k for k in a['domain_sha256'].keys()|b['domain_sha256'].keys() if a['domain_sha256'].get(k)!=b['domain_sha256'].get(k)]})
   previous={'ordinal':index,'boundary':{k:b.get(k) for k in descriptor},'normalized_state_sha256':sha(sa),'rng_sha256':a['rng_sha256']}
  category='no mechanical divergence'
  if first:
   boundary=first['boundary']; payload=first['candidate_payload'] or {}; text=json.dumps(payload)
   if boundary['stage']=='after_decision' and boundary['faction']=='Romans':category='Roman decision/ranking: needs local probe'
   elif boundary['stage']=='after_execute' and ('rally_opportunities' in text):category='Seize-triggered Rally: needs source check'
   elif boundary['stage']=='after_execute' and payload.get('card_id')==51:category='Surus: needs source check'
   elif boundary['stage']=='after_execute' and payload.get('command')=='Battle' and first['changed_domains']==['spaces']:category='Battle visibility/casualty: needs source check'
   else:category='unclassified'
  report={'scenario':new['scenario'],'seed':new['seed'],'parent':{'source':old['source'],'winner':old['record']['winner'],'cards':old['record']['cards'],'final_state_sha256':old['record']['final_state_sha256']},
          'candidate':{'source':new['source'],'winner':new['record']['winner'],'cards':new['record']['cards'],'final_state_sha256':new['record']['final_state_sha256']},
          'normalization':'Only regions field in Seize execution reports with regions_resolved; raw comparisons/snapshots retained unchanged.',
          'ignored_report_only_state_boundaries':ignored,'first_mechanical_difference':first,'provisional_category':category,
          'limitations':['Localization proves an initial divergence on equal inputs, not exclusive causation of the final winner.','Complete run_batch diagnostic audit remains separate.']}
  out=folder/'semantic-review.json'
  if out.exists():
   assert json.loads(out.read_text())==report
  else:out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
  summaries.append({'case':[new['scenario'],new['seed']],'winner_changed':old['record']['winner']!=new['record']['winner'],'cards_changed':old['record']['cards']!=new['record']['cards'],
                    'category':category,'first_boundary':first and first['boundary'],'review':str(out)})
 print(json.dumps({'cases':len(summaries),'categories':dict(Counter(r['category'] for r in summaries)),'summaries':summaries},indent=2))
 out=ROOT/f'semantic-localizations-{len(summaries)}.json'
 if not out.exists():out.write_text(json.dumps(summaries,indent=2,sort_keys=True)+'\n')

if __name__=='__main__':main()
