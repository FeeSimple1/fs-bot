# Batch 4 verification

The tested source is identified in `verification.json`. The parent is
`b0d936c4c066565e6237818a8d1801389f5c8770`. Run from the tested checkout
with fresh output paths.

```sh
python -m pytest -q -n 6 --junitxml=pytest.xml
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --workers 2 --out repaired-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 25-28 --card-edition second-edition --workers 2 --out repaired-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 25-28 --card-edition second-edition --out fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 25-28 --card-edition second-edition --out fuzz987.json
cmp fuzz0.json fuzz987.json
python -m fs_bot.tools.balance_smoke --seeds 1-20
```

The full suite uses pytest-xdist. Run the two bot matrices in the parent
checkout using the output names `parent-legacy` and `parent-second`.
To reproduce the parent regression failures, copy
`test_fourth_comparison_interlude.py` from the repair into a directory
outside both checkouts. Run pytest on that copy with `PYTHONPATH` pointing
at the parent.

Run `trace_interlude_outcomes.py` from each checkout with
`PYTHONHASHSEED=0` and `PYTHONPATH` pointing at the checkout. Arguments are
`parent` or `repaired`, the directory containing the game matrices, and an
output JSON filename. The script's `compare` mode takes both trace files
and an output path. It checks that the boards match before the Interlude.
Run `review_saved_interludes.py` from each checkout with an output path to
produce the continuation boards for the saved-game comparison.
