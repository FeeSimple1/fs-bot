# Ninth comparative audit: non-player lane

Audited source: `f4c8372c396981c0a31dc6f4545e67f8c6f2e981`. Two new medium-priority repair groups are confirmed. No production source, protected reference, repository test, or prior report was changed. This lane did not run the full repository suite; the separate validation lane owns that evidence.

The complete `Reference Documents` inventory, `CLAUDE.md`, adopted rulings PR-01–PR-13, original finding register, and comparative ledgers through round 8 were inspected. All prior comparative findings are closed. Liberty or Death at `2991ea279062773548ec390a1da75f3e85381702` was used only for engineering patterns: `coin-implementation-lessons.md` sections A (unreached consumers), E (flowchart gate/fallback violations), and F (cross-faction consumers). Every rules conclusion below comes from supplied Falling Sky references. No new source ruling is required.

## NP9-01 — Arverni Devastate chooses Regions from piece presence rather than actual casualties

**Priority:** Medium. This can damage only Arverni while removing no enemy, and can suppress source-required favorable Devastation.

**Sources:** `Reference Documents/Chapter 8:645–655` requires Devastate to force removal of a Legion, two Auxilia, or at least one enemy and at least as many Roman plus Aedui pieces as Arverni pieces. `Reference Documents/Chapter 4:121–137` removes one-quarter of Arverni Warbands and one-third of each other faction's Warbands/Auxilia/Legions, rounding down; it then places the marker. Chapter 8:701–711 places this SA after Rally.

**Implementation:** `fs_bot/bots/arverni_bot.py:1271–1289` checks `roman_legions > 0`, `roman_auxilia >= 2`, and otherwise compares total enemy pieces with total Arverni pieces. These are presence/force-size checks rather than removal forecasts. `fs_bot/engine/execute.py:4980–4999` reuses the same predicate at live SA time. The actual casualty mechanic in `fs_bot/engine/devastate_losses.py:10–22` already applies the correct floor division.

**Public witness:** Great Revolt, seed 6, all four seats non-player, no Event, Command+SA allowed, 10 Resources each. Permanent Roman Fort in Provincia. Vercingetorix in Arverni; four Revealed Arverni Warbands and one track-sourced Roman Legion in Bituriges. Public `dispatch_bot_turn` selects Rally with Devastate. Public `execute_decision` Rallies, then Devastates Bituriges, removing one Arverni Warband and **zero** Romans; the lone Legion remains and the Region becomes Devastated. Substituting two Roman Auxilia produces the same wrongful one-own/zero-enemy result. Both violate every listed non-player Devastate trigger.

**Opposite boundary:** Substituting three Aedui Warbands for the Romans produces Rally with No SA and leaves four Arverni/three Aedui Warbands untouched, despite lawful Devastate requiring exactly one casualty per faction. The live chooser still omits the Region after Rally. On a detached copy of that exact resulting board, `validate_devastate_region` accepts and production `devastate_region` removes one Arverni and one Aedui, establishing the source-required mechanic. That direct-mechanic control is explicitly not represented as another bot turn.

**Controls:** Three Roman Legions yields a correct one-Legion/one-Arverni Devastate. One Auxilium correctly produces no Devastate. Command-only permission correctly suppresses the SA. All pre/post inventory and structure checks pass.

**Earlier distinction:** Original `CMD-DEVASTATE-LOSSES` fixed casualty ownership/physical selection. `CM2-03` fixed repeated Devastate Regions. `NP6-03` addressed the Roman Rampage threat predicate, not the Arverni Devastate chooser. None corrected this casualty forecast. Current revisions reproduce it after all round-8 repairs.

**Repair scope:** Derive actual mandatory casualty totals and forced Legion/Auxilia losses from eligible troop counts and the printed owner casualty freedoms. Compare actual Roman+Aedui removals with actual Arverni removals. Preserve leader range, Control, Devastated exclusion, resource/action scopes, normal live casualty ownership, and Command-only restrictions. Both pre-Command and live SA consumers must use the corrected rule.

**Limits:** Controlled legal board witnesses, not sampled whole-game encounter rates. No claim about all Devastate target combinations or every Command timing; the proven public path is Rally+SA. No Battle, casualty roll, capability, borrowed forces, or human response enters these fixtures.

## NP9-02 — Post-Command Special Ability transitions remain incomplete for Arverni and Belgae

**Priority:** Medium. This repair group contains two separately evidenced consumers of the late-state SA chain, rather than counting each omitted branch as a separate finding.

### A. Arverni Rally creates Entreat but its earlier No SA blocks reconsideration

**Sources:** `Reference Documents/Chapter 8:661–675` gives the Devastate→Entreat→none order and replacement priorities; Chapter 8:710–711 requires this after Rally. `Reference Documents/Chapter 4:107–120` requires a Hidden Arverni Warband within Vercingetorix's range and charges one Resource per Region for the eligible replacement.

**Implementation:** `fs_bot/bots/arverni_bot.py:928–940` chooses the SA on the pre-Rally board. `fs_bot/engine/execute.py:4784–4786` exits for No SA; its Arverni live replanner at lines 4824–4829 consequently never runs for that newly enabled opportunity.

**Public witness:** Great Revolt seed 6, all four seats non-player, Command+SA allowed and 10 Resources. Vercingetorix at Mandubii; Arverni Aulerci Ally and one Roman Auxilium at Carnutes; no initial Arverni Warbands. Unmodified dispatch selects Rally with No SA. Public execution legally Rallies two Hidden Arverni Warbands at Carnutes, leaves the Roman Auxilium, and ends with 7 Resources. On that resulting board the ordinary SA chooser immediately returns Entreat at Carnutes. Printed Entreat would replace the Auxilium with one additional Arverni Warband: three Hidden Arverni, zero Romans, 6 Resources.

**Controls:** Adding one initial Hidden Arverni Warband causes natural dispatch to select and execute Entreat (Roman removed, two final Hidden Arverni, 6 Resources; the Rally option differs because that initial Warband permits Control). A genuine Command-only case retains the Roman and omits Entreat. A no-enemy case omits Entreat. A source-required execution control repeats the original failing board, changes only the dispatched SA label to Entreat, and lets the existing live executor derive every actual target; it produces the expected three Hidden Arverni, zero Romans, 6 Resources. This supplied label is explicitly identified, not claimed as an unmodified bot selection.

### B. Belgic Raid invalidates Rampage and then omits its required Enlist fallback

**Sources:** `Reference Documents/Chapter 8:304–338` requires Rampage after Raid, then Enlist if no Rampage is possible, including March in place to Hide at least two Revealed German Warbands. Chapter 8:376–389 governs the Raid and repeats the post-Raid Rampage/Enlist requirement.

**Implementation:** `fs_bot/bots/belgae_bot.py:959–974` selects Rampage before Raid changes visibility. `fs_bot/engine/execute.py:4893–4908` rechecks Rampage after Raid but returns `declined_no_effect` rather than entering Enlist. The existing Enlist live producer at lines 4927–4949 handles the legal fallback if reached.

**Public witness:** Great Revolt seed 1, all four seats non-player, Command+SA allowed. Belgae have zero Resources, Ambiorix and two Hidden Warbands in Carnutes with three Roman Auxilia. Two Revealed Germanic Warbands are in adjacent Bituriges. No threat, Rally placement, or Event takes precedence. Natural dispatch selects Raid+Rampage. Raid gains two Resources and Reveals both Belgic Warbands. The live Rampage now correctly finds none eligible, but returns a legal-decline result and stops. Both German Warbands remain Revealed although the current Enlist chooser returns `german_march_hide` in Bituriges. The printed fallback must Hide those two German Warbands.

**Controls:** With three initial Hidden Belgic Warbands, Raid leaves one for a successful Rampage; Romans fall from three to two, and German Warbands correctly remain Revealed. Removing the German candidates produces a genuine no-fallback case. Command-only permission suppresses the SA. A source-required control repeats the failing board, changes only the dispatched SA label to Enlist, and lets its existing live producer derive the free German March; both German Warbands become Hidden, Romans remain three, and Belgic Resources remain two.

**Earlier distinction:** `NP8-02` repaired the equivalent empty-SA transition for Aedui Rally specifically; its repair changed Aedui planning and the Druids grant, not the Arverni consumer above. Earlier live-SA rederivation prevents stale illegality only after a provisional SA was selected. The Belgic consumer is a different missing transition: selected Rampage→no longer possible→required Enlist, with a false `if none` endpoint. Original Rampage count/victim repairs addressed physical quantities and victim choices. Neither current witness is a recurrence of those repaired mechanics.

**Repair scope:** Forecast or defer the printed post-Command SA chain so a newly enabled Arverni SA and a required Belgic fallback are still considered. Preserve genuine Command-only scope, the actual SoP action type, human-authored no-SA decisions, Britannia and Event restrictions, resource budgets, and one-SA-per-Command. Re-evaluate the complete eligible chain at its real timing, not only the provisional label.

**Limits:** Two controlled ordinary base-game consumers. No claim that all March/Rally/Raid routes, every faction, or expansion interactions fail. Neither witness proves encounter frequency. All source-required controls are labeled, and no production functions are patched.

## Reproduction and observed coverage

Run `.venv/bin/python /path/to/probe_bots.py --repo /path/to/fs-bot` on the audited revision. `probe_bots-output.json` is the hash-0 output; `probe_bots-hash987.json` is the matching hash-987 output. Both match byte-for-byte. The probe runs 16 public dispatch/execution cases and one detached direct Devastate control, totaling 34 successful pre/post census and structural checks. Assertions describe the defects as observed and should fail once corrected. Exploratory `explore.py` is not part of portable final evidence.
