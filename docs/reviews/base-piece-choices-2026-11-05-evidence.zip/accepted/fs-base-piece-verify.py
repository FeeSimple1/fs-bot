from pathlib import Path
import json
import re
import subprocess
import xml.etree.ElementTree as ET
from fs_bot import rules_consts as rc
from fs_bot.tools.validation_metadata import source_identity

parent='4789ba3f594889b145148f75130eecca153dbee0'
source=source_identity()
assert source['source_sha256']=='d8a561bf3092f6fc210910f69c7db3433135dfc325338608c649414dc2b16eb2'
assert len(list(Path('fs_bot').rglob('*.py')))==529
records={}
for label,directory in [('parent','/tmp/fs-base-piece-bots-parent'),('accepted','/tmp/fs-base-piece-bots-final')]:
    rows=[json.loads(line) for line in Path(directory+'/games.jsonl').read_text().splitlines()]
    records[label]={(row['scenario'],row['seed']):row for row in rows}
    assert len(rows)==10 and set(records[label])=={(s,n) for s in rc.ALL_SCENARIOS for n in (1,2)}
    for row in rows:
        assert all(row[key] for key in ('completed','game_completed','audit_completed','final_state_sha256'))
        assert not row['errors'] and not row['integrity_findings']
        assert len(row['final_ranking'])==4 and not row['winner_differs_from_highest_margin']
        assert not row['engine_ranking_output_missing']
        assert all(d['severity']=='legal-decline' for d in row['diagnostics'])
ignored={'seconds','commit','source_sha256'}
for key,old in records['parent'].items():
    new=records['accepted'][key]
    assert {k:v for k,v in old.items() if k not in ignored}=={k:v for k,v in new.items() if k not in ignored},key
assert records['accepted'][rc.SCENARIO_GALLIC_WAR,1]['interlude_completed']
assert json.loads(Path('/tmp/fs-base-piece-bots-parent/metadata.json').read_text())['source_sha256']=='9f1e25a3b40487698e087aab9287d73564a63f7c0a2df9eb432810352ba132f6'
assert json.loads(Path('/tmp/fs-base-piece-bots-final/metadata.json').read_text())['source_sha256']==source['source_sha256']
mixed=json.loads(Path('/tmp/fs-base-piece-mixed0.json').read_text())
assert mixed==json.loads(Path('/tmp/fs-base-piece-mixed987.json').read_text())
assert not mixed['hard_findings'] and mixed['partial']==0 and all(r['game_completed'] for r in mixed['records'])
assert mixed['metadata']['source_sha256']==source['source_sha256']
protected=[p for p in Path('Reference Documents').rglob('*') if p.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
assert len(protected)==49
for path in protected:
    assert path.read_bytes()==subprocess.check_output(['git','show',parent+':'+str(path)])
proof=ET.parse('/tmp/fs-base-piece-proof-parent.xml').getroot().find('testsuite')
assert proof.attrib['tests']=='8' and proof.attrib['failures']=='6' and proof.attrib['errors']=='0'
assert all(('assert' in t.find('failure').attrib['message'].lower() or
            'did not raise' in t.find('failure').attrib['message'].lower())
           for t in proof if t.find('failure') is not None)
accepted_proof=ET.parse('/tmp/fs-base-piece-proof-final.xml').getroot().find('testsuite')
assert accepted_proof.attrib['tests']=='8' and accepted_proof.attrib['failures']=='0' and accepted_proof.attrib['errors']=='0'
assert re.search(r'\n294 passed in ',Path('/tmp/fs-base-piece-targeted.log').read_text())
log=Path('/tmp/fs-base-piece-balance.log').read_text()
rows=re.findall(r'^\[(.*?) seed=\s*(\d+)\] winner=(.*?) \((\d+) cards\)$',log,re.M)
assert len(rows)==100 and {(s,int(n)) for s,n,_,_ in rows}=={(s,n) for s in rc.ALL_SCENARIOS for n in range(1,21)}
deltas=[abs(int(v)) for v in re.findall(r'\(([+-]\d+)%\)',log)]
assert deltas and max(deltas)<=15 and 'OK: balance within band' in log
changes=int(re.search(r'OK: balance within band \((\d+) winner changes\)',log)[1])
result={'date':'2026-11-05','timezone':'America/Chicago','source':source,'python_files':529,
        'protected_files':49,'protected_files_unchanged':True,'new_tests':89,'targeted_passed':294,
        'parent_proof':{'behavioral_failures':6,'controls_passed':2,'accepted_passed':8},
        'bots':{'games':10,'all_completed_and_audited':True,'gameplay_and_final_hashes_equal':True,
                'interlude_exercised':{'scenario':rc.SCENARIO_GALLIC_WAR,'seed':1},'excluded':sorted(ignored)},
        'mixed':mixed,'mixed_complete_json_equal':True,'hash_seeds':[0,987],'mixed_executions_including_replay':40,
        'balance':{'games':100,'band_percentage_points':15,'maximum_absolute_delta_percentage_points':max(deltas),
                   'historical_baseline_winner_changes':changes,'baseline_unchanged':True,'passed':True},
        'progress':{'closed':40,'total':50,'percent':80,'open':10},
        'remaining':'BE-06 advances for numeric 19/22; mandatory Roman allocations on numeric 3/5 remain. BE-07 physical-choice and BE-08 schema rows retain other cards. Two unadopted source questions and thirteen provisional rulings remain. Original bundle stays 40/50 closed. Separate mechanics leads and source questions retain their dispositions.'}
Path('/tmp/fs-base-piece-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':source,'bots_equal':10,'mixed_equal':True,'hard_findings':0,'partials':0,
                  'new_cases':89,'targeted':294,'balance_max_delta_pp':max(deltas)}))
