"""Run the frozen-source mixed-seat acceptance matrix; no repository writes."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.path.insert(0, str(Path.cwd()))
from fs_bot.tools.validation_metadata import source_identity

parser = argparse.ArgumentParser()
parser.add_argument('--source-sha', required=True)
args = parser.parse_args()
root = Path('/workspace/scratch/534c265c65f4/followup-final-validation-20261024-r2')
root.mkdir(parents=True, exist_ok=True)
before = source_identity()
assert before['source_sha256'] == args.source_sha, (before, args.source_sha)
(root / 'fuzz-source-before.json').write_text(json.dumps(before, indent=2) + '\n')
runs = []
for edition, seeds in [('legacy', '1-40'), ('original', '201-205'),
                       ('second-edition', '201-205')]:
    for hash_seed in (0, 7):
        name = f'fuzz-{edition}-hash{hash_seed}'
        output = root / (name + '.json')
        stdout = root / (name + '.txt')
        command = [sys.executable, '-m', 'fs_bot.tools.player_fuzz',
                   '--seeds', seeds, '--card-edition', edition, '--out', str(output)]
        stream = stdout.open('w')
        process = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT,
            env=dict(os.environ, PYTHONHASHSEED=str(hash_seed)), cwd=Path.cwd())
        runs.append(dict(name=name, edition=edition, hash_seed=hash_seed,
            command=command, json=str(output), stdout=str(stdout),
            process=process, stream=stream))
manifest = {'source_before': before, 'runs': [
    {k: v for k, v in run.items() if k not in ('process', 'stream')} for run in runs]}
(root / 'fuzz-launches.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Launched six mixed-seat runs on source ' + args.source_sha, flush=True)
pending = list(runs)
last_update = time.monotonic()
failed = False
while pending:
    for run in list(pending):
        status = run['process'].poll()
        if status is None:
            continue
        run['stream'].close()
        pending.remove(run)
        after = source_identity()
        run['source_after'] = after
        run['exit_status'] = status
        if Path(run['json']).exists():
            report = json.loads(Path(run['json']).read_text())
            summary = {key: report[key] for key in ('games', 'human_turns',
                'event_turns', 'events_ok', 'hard_findings', 'partial', 'batch_digest')}
            run['summary'] = summary
            failed |= bool(report['hard_findings'])
        else:
            summary = {'missing_report': True}
            failed = True
        failed |= status != 0 or after != before
        print(json.dumps({'run': run['name'], 'exit_status': status,
                          'same_source': after == before, **summary}), flush=True)
    if failed:
        for run in pending:
            run['process'].terminate()
        for run in pending:
            run['process'].wait()
            run['stream'].close()
        print('ACCEPTANCE ABORTED: run failed or source changed.', flush=True)
        break
    if time.monotonic() - last_update >= 30:
        print('Still running: ' + ', '.join(run['name'] for run in pending), flush=True)
        last_update = time.monotonic()
    time.sleep(0.3)
after = source_identity()
(root / 'fuzz-source-after.json').write_text(json.dumps(after, indent=2) + '\n')
comparisons = []
if not failed:
    for edition in ('legacy', 'original', 'second-edition'):
        a, b = [run for run in runs if run['edition'] == edition]
        same_json = Path(a['json']).read_bytes() == Path(b['json']).read_bytes()
        same_stdout = Path(a['stdout']).read_bytes() == Path(b['stdout']).read_bytes()
        comparisons.append(dict(edition=edition, full_json_identical=same_json,
            stdout_identical=same_stdout, **a['summary']))
        failed |= not (same_json and same_stdout)
        print(json.dumps(comparisons[-1]), flush=True)
result = {'source_before': before, 'source_after': after,
          'source_unchanged': before == after, 'passed': not failed,
          'comparisons': comparisons, 'runs': [
              {k: v for k, v in run.items() if k not in ('process', 'stream')}
              for run in runs]}
(root / 'fuzz-acceptance.json').write_text(json.dumps(result, indent=2) + '\n')
raise SystemExit(1 if failed else 0)
