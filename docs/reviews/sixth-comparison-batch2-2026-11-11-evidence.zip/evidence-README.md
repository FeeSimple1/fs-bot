# Sixth comparison repair Batch 2 evidence

The parent is `1e8cfbd604d19950fdc68664ccc14e87750735ee`. The tested Python
source identity and accepted results are in `final/source.json` and
`final/summary.json`. `SHA256SUMS.json` covers every other archive member.

Run the following from the repaired checkout with Python 3.12, pytest and
pytest-xdist. Use fresh output paths.

```sh
PYTHONHASHSEED=0 python -m pytest -q -n 5 --dist loadfile --tb=short --show-capture=no --junitxml=pytest.xml
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 3 --out bots-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 41-44 --card-edition second-edition --workers 2 --out bots-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
```

The 100 reviewed baseline records pass the existing 15-point band. The
first matrix's sole failed audit is preserved under `first-matrix` with
its own Python source identity. `camulogenus-live.json` captures the
Arverni plan just before the crossing refusal. The isolated seed-20
rerun with the final code is under `camulogenus-verification`.

The new cases can be replayed on the parent to reproduce seven failures
and six passing controls.

```sh
PYTHONPATH=. PYTHONHASHSEED=0 python -m pytest -q --tb=short /path/to/evidence/test_parent_germans_phase.py
PYTHONPATH=. PYTHONHASHSEED=0 python -m pytest -q --tb=short /path/to/evidence/test_parent_free_command_planning.py -k bot_camulogenus_marches_with_entreat_only_on_a_legal_route
```

The earlier audited records are in the sixth comparison Batch 1 evidence
archive under `final/bots-legacy` and `final/bots-second`. The included
trace inputs use those records and this batch's final records. Each replay
checks the source hash, winner, game length and final board digest.
Generate each trace in its matching checkout.

```sh
PYTHONPATH=. PYTHONHASHSEED=0 python /path/to/evidence/trace_germans_phase.py record /path/to/evidence/trace-parent-input.json /path/to/parent-trace.json
PYTHONPATH=. PYTHONHASHSEED=0 python /path/to/evidence/trace_germans_phase.py record /path/to/evidence/trace-repaired-input.json /path/to/repaired-trace.json
PYTHONPATH=. python /path/to/evidence/trace_germans_phase.py compare /path/to/parent-trace.json /path/to/repaired-trace.json /path/to/first-divergences.json
PYTHONPATH=. python /path/to/evidence/verify_results.py /path/to/batch1-evidence/final
```

`final/paired-outcomes.json` records all 120 scenario, seed and edition
pairs. `final/first-divergences.json` records the identical starting board
and RNG digests and the Rally or March result that changed in each of
the 26 replays. The final bot and mixed-player records are included.
