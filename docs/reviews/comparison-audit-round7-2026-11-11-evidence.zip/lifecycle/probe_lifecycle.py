"""Seventh audit witness on c67d501: omitted non-Roman NPC Quarters.
Run with the audited fs-bot repository on PYTHONPATH. No production patches.
Assertions confirm observed defects and the legal explicit-plan controls.
"""
from copy import deepcopy
import json
from fs_bot import rules_consts as rc
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.state.setup import setup_scenario
from fs_bot.board.pieces import place_piece, count_pieces, find_leader
from fs_bot.board.control import refresh_all_control
from fs_bot.engine.quarters import quarters_factions, validate_quarters_plan
from fs_bot.engine.winter import quarters_phase, run_winter_round


def integrity(state):
    result = {'census': validate_state(state), 'structure': check_structural_integrity(state)}
    assert result == {'census': [], 'structure': []}, result
    assert count_pieces(state, rc.PROVINCIA, rc.ROMANS, rc.FORT) == 1
    for tribe, info in state['tribes'].items():
        restriction = rc.TRIBE_FACTION_RESTRICTION.get(tribe)
        assert not restriction or info['allied_faction'] in (None, restriction)
    return dict(result, permanent_provincia_fort=True, restricted_tribes_valid=True)


def position(faction):
    scenario = rc.SCENARIO_ARIOVISTUS if faction == rc.GERMANS else rc.SCENARIO_GREAT_REVOLT
    state = build_initial_state(scenario, seed=1)
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    state['non_player_factions'] = set(quarters_factions(state))
    return state


def evacuation(faction, *, explicit=False, blocked=False, full_winter=False):
    if full_winter:
        assert faction == rc.AEDUI
        state = setup_scenario(rc.SCENARIO_PAX_GALLICA, seed=1)
        state['non_player_factions'] = set(quarters_factions(state))
    else:
        state = position(faction)
    origin, destination = rc.CARNUTES, rc.BITURIGES
    place_piece(state, origin, faction, rc.WARBAND, 3)
    place_piece(state, destination, faction, rc.WARBAND)
    state['markers'].setdefault(origin, {})[rc.MARKER_DEVASTATED] = True
    if blocked:
        state['markers'].setdefault(destination, {})[rc.MARKER_DEVASTATED] = True
    refresh_all_control(state)
    before = integrity(state)
    plan = {f: [] for f in quarters_factions(state)}
    plan[faction] = [(rc.WARBAND, origin, destination, 3, rc.HIDDEN)]
    errors = validate_quarters_plan(state, plan)
    if blocked:
        assert errors, 'Matched control must have no legal escape'
    else:
        assert not errors, errors
    fn = run_winter_round if full_winter else quarters_phase
    result = fn(state, relocations=plan if explicit else None)
    quarter_result = result['phases']['quarters'] if full_winter else result
    actual_origin = count_pieces(state, origin, faction, rc.WARBAND)
    actual_destination = count_pieces(state, destination, faction, rc.WARBAND)
    if explicit:
        assert actual_origin == 0 and actual_destination == 4
        assert quarter_result['gallic_desertion'][faction] == {}
    else:
        assert quarter_result['gallic_relocations'][faction] == []
        assert quarter_result['gallic_desertion'][faction][origin]['rolls']
        # Full Winter leaves the target's survivors in place through Spring.
        assert actual_origin < 3
        if not blocked:
            assert actual_destination == 1
    if full_winter:
        assert result['phases']['germans'] == {'skipped': '1st Winter special rule'}
    return {
        'faction': faction, 'scenario': state['scenario'], 'full_winter': full_winter,
        'explicit_plan_control': explicit, 'escape_blocked_control': blocked,
        'source_region': origin, 'legal_refuge': destination,
        'starting_warbands': {'origin': 3, 'destination': 1},
        'required_escape_plan': plan[faction], 'escape_validation_errors': errors,
        'observed_end_warbands': {'origin': actual_origin, 'destination': actual_destination},
        'quarter_result': quarter_result, 'before_integrity': before,
        'after_integrity': integrity(state),
        'preceding_germans_phase': result['phases']['germans'] if full_winter else None,
    }


def consolidate(faction, *, explicit=False):
    state = position(faction)
    origin, destination = rc.CARNUTES, rc.BITURIGES
    names = {rc.BELGAE: rc.AMBIORIX, rc.ARVERNI: rc.VERCINGETORIX, rc.GERMANS: rc.ARIOVISTUS_LEADER}
    place_piece(state, origin, faction, rc.LEADER, leader_name=names[faction])
    place_piece(state, origin, faction, rc.WARBAND, 3)
    place_piece(state, destination, faction, rc.WARBAND, 8)
    refresh_all_control(state)
    before = integrity(state)
    plan = {f: [] for f in quarters_factions(state)}
    plan[faction] = [(rc.LEADER, origin, destination, 1),
                     (rc.WARBAND, origin, destination, 2, rc.HIDDEN)]
    assert not validate_quarters_plan(state, plan)
    result = quarters_phase(state, relocations=plan if explicit else None)
    leader_region = find_leader(state, faction)
    leader_warbands = count_pieces(state, leader_region, faction, rc.WARBAND)
    assert leader_warbands == (10 if explicit else 3)
    assert count_pieces(state, origin, faction, rc.WARBAND) == (1 if explicit else 3)
    return {'faction': faction, 'explicit_plan_control': explicit,
            'required_minimum_warbands_with_leader': 10,
            'observed_warbands_with_leader': leader_warbands,
            'observed_leader_region': leader_region,
            'legal_control_plan': plan[faction], 'quarter_result': result,
            'before_integrity': before, 'after_integrity': integrity(state)}


def main():
    return {'WS7-01': {
        'evacuation': [evacuation(f, explicit=control)
                       for f in (rc.BELGAE, rc.AEDUI, rc.ARVERNI, rc.GERMANS)
                       for control in (False, True)],
        'no_legal_escape_control': evacuation(rc.AEDUI, blocked=True),
        'leader_consolidation': [consolidate(f, explicit=control)
                                for f in (rc.BELGAE, rc.ARVERNI, rc.GERMANS)
                                for control in (False, True)],
        'full_winter': [evacuation(rc.AEDUI, explicit=control, full_winter=True)
                        for control in (False, True)],
    }}

if __name__ == '__main__':
    print(json.dumps(main(), indent=2, sort_keys=True))
