"""Bind the reviewed seven paired outcomes to their retained raw evidence."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent / 'attempt1'
summary = json.loads((HERE / 'review-summary.json').read_text())
inputs = json.loads((HERE / 'source-explanation-inputs.json').read_text())
assert summary['all_traces_match_matrix_records']
assert summary['all_first_divergences_at_litaviccus']
assert summary['capture_executions'] == 14
assert len(summary['reviews']) == len(inputs['cases']) == 7
assert all(row['equal_preceding_board_and_rng'] for row in summary['reviews'])
matrix = HERE.parent.parent / 'attempt1'
matrix_differences = json.loads((matrix / 'parent-all-edition-semantic-differences.json').read_text())
assert {(row['card_edition'], row['scenario'], row['seed']) for row in matrix_differences} == {
    tuple(case) for case in summary['changed_semantic_records']}

cases = []
for row in summary['reviews']:
    detail = next(item for item in inputs['cases'] if item['file'] == row['first_divergence_file'])
    if row['first_stage'] == 'decision-after':
        assert detail['predicted_plan'] is None
        assert all(region['minimum_legion_losses'] == 0 for region in detail['regions'])
        assert detail['input_and_rng_unchanged']
        cause = ('The previous Event choice counted Roman targets without establishing a Legion Loss. '
                 'Every candidate region forecasts zero Legion Losses on the recorded input. '
                 'The new No Belgae path correctly rejects this Event and the bot chooses its ordinary Rally alternative.')
        references = ['Reference Documents/belgae_bot_event_instructions.txt: Litaviccus',
                      'docs/provisional-rulings.md: PR-12', 'fs_bot/cards/litaviccus_np.py: plan/available',
                      'fs_bot/engine/execute.py: _execute_card45_battle_plan']
    elif row['edition'] == 'legacy':
        cause = ('The Arverni-executed shaded Battle uses the Aedui pieces as its force. '
                 'The Roman Counterattack now removes those participating Aedui Warbands to their physical Available pool. '
                 'The parent left those participating Warbands immune to Counterattack because their physical owner was Aedui.')
        references = ['Reference Documents/Card Reference: numeric 45 shaded',
                      'Reference Documents/Chapter 3: Battle Counterattack',
                      'fs_bot/battle/combined.py: litaviccus_force/loss_choices/operate',
                      'fs_bot/battle/losses.py: resolve_losses']
    else:
        cause = ('The Arverni-executed shaded Battle uses nine Hidden Aedui Warbands against the Roman Fort in Sequani. '
                 'They now become Revealed as surviving attackers after the granted Ambush. '
                 'The parent treated them as attackers for damage but left all nine Hidden after Battle.')
        references = ['Reference Documents/Card Reference: numeric 45 shaded',
                      'Reference Documents/Chapter 3: Battle Reveal',
                      'fs_bot/battle/combined.py: litaviccus_force/operate',
                      'fs_bot/battle/resolve.py: _reveal_survivors']
    cases.append({**row, 'source_explanation': detail, 'causal_disposition': 'explained',
                  'explanation': cause, 'source_references': references})

result = {'parent_source_sha256': summary['parent_sha256'],
          'candidate_source_sha256': summary['candidate_sha256'],
          'compared_semantic_records': 150, 'unchanged_semantic_records': 143,
          'changed_semantic_records': 7, 'paired_capture_executions': 14,
          'all_captures_reproduce_matrix_records': True,
          'all_first_divergences_follow_identical_board_and_rng': True,
          'all_first_divergences_are_litaviccus': True,
          'all_changed_cases_explained': True,
          'all_reviewed': True,
          'unexplained_cases': [],
          'exact_changed_case_set_matches_matrix': True,
          'root_review': {'confirmed_all_seven_cases': True,
                          'confirmed_all_fourteen_reproductions': True,
                          'confirmed_matching_predivergence_board_and_rng': True,
                          'scope': 'Bounded first-divergence attribution; no full-trajectory correctness claim.'},
          'independent_engine_review': {
              'reviewer': '/root/event_battle_engine',
              'confirmed_all_seven_cases': True,
              'exact_preceding_board_and_rng_reconstructed': True,
              'decision_cases': 'All three independently yield plan=None and only (0 Legion Losses, unsafe, Frost-permitted). No live input/RNG mutation.',
              'execution_cases': 'All four reproduce complete physical afterboards; full grant replay also matches recorded result and post-grant RNG hash.',
              'counterattack_detail': 'Legacy Great Revolt2 removes 1 Aedui Scouted Warband to 8 Counterattack Losses; Great Revolt16 removes 2 Revealed Warbands to 16 Counterattack Losses.',
              'reveal_detail': 'Original and second-edition Great Revolt202 each Reveal 9 Aedui Warbands after Ambush.',
              'rules_basis': 'Printed Belgic Litaviccus No Belgae criterion; card45 using Aedui pieces as your own; section3.3.4 Counterattack/Reveal.',
              'scope': 'First-divergence review only; no assertion about every later decision or full trajectories.'},
          'metadata_only_changed_records': 0,
          'raw_evidence_sha256': {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
                                 for name in ('review-summary.json', 'source-explanation-inputs.json')},
          'cases': cases,
          'limits': ('The 143 unchanged records match recorded semantic fields; full trajectory equality is not claimed. '
                     'For seven changed cases, the paired traces establish the first divergence and reproduce final audited records. '
                     'Later cascading gameplay is not independently rule-proved. PR-12 remains provisional as approved. '
                     'This report does not edit or approve a historical balance baseline.')}
with (HERE / 'causal-source-review.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'changed': 7, 'explained': True, 'captures': 14}))
