"""Verify paired bot replays, directed witnesses, and reviewed balance."""

from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
import re
import sys
from xml.etree import ElementTree
from zipfile import ZipFile

from fs_bot import rules_consts as rc
from fs_bot.tools.balance_smoke import _rates
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


def load(path):
    return json.loads(path.read_bytes())


def key(row):
    return row['scenario'], row['seed'], row['card_edition']


def games(raw):
    rows = [json.loads(line) for line in raw.splitlines()]
    keyed = {key(row): row for row in rows}
    assert len(keyed) == len(rows)
    return keyed


def outcomes(rows):
    return {f'{s}|{seed}': dict(winner=row['winner'], cards=row['cards'])
            for (s, seed, _), row in rows.items()}


def balance_games(path):
    rows = re.findall(r'^\[(.+) seed=\s*(\d+)\] winner=(.+) \((\d+) cards\)$',
                      path.read_text(), re.MULTILINE)
    assert len(rows) == 100
    return {f'{scenario}|{seed}': dict(winner=winner, cards=int(cards))
            for scenario, seed, winner, cards in rows}


def battle_rows(action):
    return {(entry['region'], entry['target'])
            for entry in action['details'].get('battle_plan', ())}


def explain_battle(old, new):
    before, after = old['action'], new['action']
    old_rows, new_rows = battle_rows(before), battle_rows(after)
    gained = new_rows - old_rows
    possible_ambushes = {(c['region'], c['target']) for c in new['checks']
                        if c['ambush'] and c['favorable']}
    if before == after:
        assert old['rng_after'] != new['rng_after']
        if all(c['cost'] > old['resources'] for c in old['checks']):
            assert len(old['checks']) > 1 and not new['checks']
            assert old['rng_after'] != old['rng_before'] == new['rng_after']
            return 'Unaffordable Battle tie skipped'
        ordinary_refusals = {(c['region'], c['target']) for c in old['checks']
                             if not c['favorable']}
        assert possible_ambushes & ordinary_refusals and new['rng_after'] != new['rng_before']
        return 'New Ambush target adds a tie'
    if before['command'] != rc.CMD_BATTLE:
        assert after['command'] == rc.CMD_BATTLE and after['sa'] == rc.SA_AMBUSH
        assert possible_ambushes & new_rows
        return 'Ambush enables Battle'
    if after['sa'] != rc.SA_AMBUSH:
        assert before['sa'] == rc.SA_AMBUSH and old_rows == new_rows
        opening = after['details']['battle_plan'][0]
        assert any(c['region'] == opening['region'] and c['target'] == opening['target']
                   and c['favorable'] and not c['ambush'] for c in new['checks'])
        return 'Opening Battle declines Ambush'
    assert after['command'] == rc.CMD_BATTLE
    assert possible_ambushes & new_rows
    if before['sa'] == rc.SA_AMBUSH:
        assert gained and gained & possible_ambushes
        return 'Existing Ambush gains a Region or target'
    return 'Existing Battle gains Ambush'


def explain(row):
    old, new = row['prior'], row['current']
    assert (old['card'], old['before'], old['rng_before']) == (
        new['card'], new['before'], new['rng_before'])
    assert old['after'] != new['after']
    context = ('faction', 'resources', 'free', 'scope', 'permits_sa', 'rng_before')
    for a, b in zip(old['battles'], new['battles']):
        if all(a[k] == b[k] for k in context) and (
                a['action'], a['rng_after']) != (b['action'], b['rng_after']):
            return explain_battle(a, b)
    for a, b in zip(old['raids'], new['raids']):
        if a['entries'] == b['entries']:
            continue
        assert (a['faction'], a['capacity'], a['cohort'], a['hidden']) == (
            b['faction'], b['capacity'], b['cohort'], b['hidden'])
        assert a['capacity'] == 3 and a['cohort'] is None
        before = Counter(entry['region'] for entry in a['entries'])
        after = Counter(entry['region'] for entry in b['entries'])
        assert before.keys() == after.keys() and len(a['entries']) < len(b['entries'])
        assert all(count == min(b['hidden'][region], 3) for region, count in after.items())
        return 'Baggage Trains adds Raiders'
    raise AssertionError(f'No changed Battle or Raid planner for {key(row)}')


def verify_matrix(root, archive, identity, label, edition, seeds):
    path = f'bots-{label}/games.jsonl'
    previous = games(archive.read(path))
    current = games((root / path).read_bytes())
    assert previous.keys() == current.keys() == {
        (scenario, seed, edition) for scenario in SCENARIOS for seed in seeds}
    parent = json.loads(archive.read('source.json'))['source_sha256']
    metadata = load(root / f'bots-{label}/metadata.json')
    assert all(metadata[field] == value for field, value in identity.items())
    assert metadata['hash_seed'] == 0 and metadata['card_edition'] == edition
    differences = {}
    for case, row in current.items():
        assert previous[case]['source_sha256'] == parent
        assert all(row[field] == identity[field] for field in ('commit', 'source_sha256'))
        assert all(row[field] for field in ('completed', 'game_completed',
                                           'audit_completed', 'final_state_sha256'))
        assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row)
        assert len(row['final_ranking']) == len(row['engine_final_ranking']) == 4
        assert all(item['severity'] == 'legal-decline' for item in row['diagnostics'])
        prior = previous[case]
        if row['final_state_sha256'] != prior['final_state_sha256']:
            differences[case] = (prior, row)
        else:
            assert (prior['winner'], prior['cards']) == (row['winner'], row['cards'])
    summary = dict(games=len(current), final_states_changed=len(differences),
                   winners_changed=sum(a['winner'] != b['winner'] for a, b in differences.values()),
                   lengths_changed=sum(a['cards'] != b['cards'] for a, b in differences.values()),
                   interludes=sum(row['interlude_completed'] for row in current.values()))
    return previous, current, differences, summary


def verify_witnesses(root):
    audit = Path('docs/reviews/comparison-audit-round7-2026-11-11-evidence.zip')
    with ZipFile(audit) as archive:
        assert (root / 'audit-before.json').read_bytes() == archive.read('bots/probe_bots-output.json')
    before, after = (load(root / f'audit-{label}.json') for label in ('before', 'after'))
    assert before['cases'] == after['cases'] == 17
    for old, new in zip(before['NP7-01'], after['NP7-01'], strict=True):
        assert old['faction'] == new['faction']
        assert old['bot']['action']['command'] == rc.CMD_MARCH
        assert new['bot']['action']['command'] == old['expected_command']
        assert new['public_legal_ambush'] == old['public_legal_ambush']
    for old, new in zip(before['NP7-02'], after['NP7-02'], strict=True):
        assert old['faction'] == new['faction']
        assert old['observed_gain'] == 2
        assert new['observed_gain'] == new['legal_capacity_and_expected_gain']
        assert new['remaining_hidden'] == 3 - new['observed_gain']
        assert new['public_maximum_raid'] == old['public_maximum_raid']


def main(evidence):
    root = Path(evidence)
    identity = load(root / 'source.json')
    assert source_identity()['source_sha256'] == identity['source_sha256']
    prior_report = Path('docs/reviews/seventh-comparison-batch4-2026-11-11-evidence.zip')
    with ZipFile(prior_report) as archive:
        prior, legacy, legacy_diff, legacy_counts = verify_matrix(
            root, archive, identity, 'legacy', 'legacy', range(1, 21))
        _, _, second_diff, second_counts = verify_matrix(
            root, archive, identity, 'second', 'second-edition', range(41, 45))

    differences = legacy_diff | second_diff
    trace = load(root / 'first-changes.json')
    assert trace['source'] == identity
    assert len(trace['games']) == len(differences) and {key(r) for r in trace['games']} == differences.keys()
    causes = Counter()
    for row in trace['games']:
        a, b = differences[key(row)]
        assert (row['prior_winner'], row['current_winner']) == (a['winner'], b['winner'])
        causes[explain(row)] += 1

    fuzz0, fuzz987 = (root / 'fuzz0.json').read_bytes(), (root / 'fuzz987.json').read_bytes()
    assert fuzz0 == fuzz987 and (root / 'fuzz0.log').read_bytes() == (root / 'fuzz987.log').read_bytes()
    fuzz = json.loads(fuzz0)
    assert fuzz['games'] == len(fuzz['records']) == 20 and fuzz['hard_findings'] == 0
    assert {key(r) for r in fuzz['records']} == {
        (scenario, seed, 'second-edition') for scenario in SCENARIOS for seed in range(41, 45)}
    assert all(r['game_completed'] and not r['findings'] for r in fuzz['records'])
    assert all(fuzz['metadata'][field] == value for field, value in identity.items())

    before = load(root / 'baseline-prior.json')['games']
    refreshed = load(Path('fs_bot/tools/balance_baseline.json'))['games']
    assert 'FAIL: a faction win rate moved beyond the band.' in (root / 'balance-before.log').read_text()
    assert 'OK: balance within band.' in (root / 'balance.log').read_text()
    assert balance_games(root / 'balance-before.log') == balance_games(root / 'balance.log') == refreshed
    assert before == outcomes(prior) and refreshed == outcomes(legacy)
    assert refreshed.keys() == before.keys()
    updated = {k for k in refreshed if refreshed[k] != before[k]}
    assert updated <= {f'{s}|{seed}' for s, seed, _ in legacy_diff}
    shifts = {}
    for scenario in SCENARIOS:
        rates_before, rates_after = _rates(before, scenario), _rates(refreshed, scenario)
        for faction, rate in rates_before.items():
            shift = rates_after[faction] - rate
            if abs(shift) > Fraction(15, 100):
                shifts[f'{scenario}|{faction}'] = int(shift * 100)
    assert shifts == {
        f'{rc.SCENARIO_PAX_GALLICA}|{rc.ROMANS}': -20,
        f'{rc.SCENARIO_PAX_GALLICA}|{rc.BELGAE}': 20,
        f'{rc.SCENARIO_RECONQUEST}|{rc.ROMANS}': -40,
        f'{rc.SCENARIO_RECONQUEST}|{rc.BELGAE}': 30,
    }

    suites = list(ElementTree.parse(root / 'pytest.xml').getroot().iter('testsuite'))
    tests = sum(int(s.attrib['tests']) for s in suites)
    assert tests == 10116 and not any(int(s.attrib.get(k, 0)) for s in suites
                                    for k in ('errors', 'failures', 'skipped'))
    before_pytest = (root / 'pytest-before.log').read_text()
    assert '1 failed, 10115 passed' in before_pytest and 'FAILED fs_bot/tests/test_selfplay_tools.py::test_bot_balance_canary' in before_pytest
    assert '49 passed' in (root / 'directed.log').read_text()
    assert '17 failed, 30 passed' in (root / 'parent-regressions.log').read_text()
    assert '699 passed' in (root / 'focused-final.log').read_text()
    verify_witnesses(root)

    summary = dict(source=identity, python=fuzz['metadata']['python'], full_tests=tests,
        directed_tests=49, parent_defect_reproductions=17, focused_tests=699,
        paired_outcomes=dict(legacy=legacy_counts, second=second_counts), first_differences=dict(causes),
        mixed_player={k: fuzz[k] for k in ('games', 'human_turns', 'event_turns',
            'events_ok', 'partial', 'hard_findings', 'batch_digest')},
        balance=dict(games=len(refreshed), band=0.15, records_updated=len(updated),
            winners_changed=legacy_counts['winners_changed'], lengths_changed=legacy_counts['lengths_changed'],
            prior_baseline_out_of_band_points=shifts))
    (root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main(sys.argv[1])

