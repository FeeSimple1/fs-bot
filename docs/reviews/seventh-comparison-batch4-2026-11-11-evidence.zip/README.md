# Seventh comparison Batch 4 validation

The repair was tested on parent `5cd57e5fe88f6f4dc9f2fbef1b40bbdb4f970d1d`
with Python 3.12.14. `source.json` identifies the tested Python bytes. The
seventh Batch 3 archive supplies the paired parent game records. The seventh
audit archive supplies the original Event witnesses. `SHA256SUMS` covers the
archived files.

Run the verifier from the repaired repository root with its Python
environment active.

```sh
PYTHONPATH=. python /path/to/evidence/verify_results.py /path/to/evidence
```

The validation runs used these commands with a fresh output directory.

```sh
PYTHONHASHSEED=0 python -m pytest -q -n 5 --junitxml=pytest.xml
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out bots-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 41-44 --card-edition second-edition --workers 2 --out bots-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
```

`balance-before.log` and `pytest-before.log` used `baseline-prior.json` in
the repository's baseline path. The final balance and pytest runs used the
reviewed Batch 4 baseline. Both runs used the same seeds and thresholds.
`directed.log` records the 25 new Event cases. The same file run on the
parent reproduces 21 failures and passes four controls. `audit-before.json`
matches the original audit's Event witness output.

`first-changes.json` records both versions of each first changed card,
with pre-card board and RNG digests, action decisions, Event availability,
parameters and piece effects. To reproduce it, run `trace_event_changes.py`
with `trace-parent-input.json` and a fresh parent trace output path on the
parent checkout. Then run the script with `trace-candidate-input.json`, a
fresh output path, and the parent trace path on the repaired checkout. Use
`PYTHONHASHSEED=0 PYTHONPATH=.` for both invocations.
