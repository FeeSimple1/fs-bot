# Automatic Arverni: Event-granted single Command

Read-only external research, 2026-11-03. No code, ruling, or owner decision changed.

## Sources

1. GMT, Ariovistus Rules of Play, copyright 2018, sections A3.1, A4.3/A4.3.3, A5.4, A6.2, A8.2.3/A8.3.1:
   https://s3-us-west-2.amazonaws.com/gmtwebsiteassets/Ariovistus/Ariovisus_Rules_Final_Lo-Res.pdf
   Web refs: turn119view0, turn140view1, turn141view3. The misspelling Ariovisus is in the actual publisher URL. Search publication timestamps reflect indexing; no evidence this is a newly revised 2026 rulebook.
2. GMT, Falling Sky Rules of Play, second edition, copyright 2015/2018, sections 4.5.1, 5.1.1, 5.4, 8.2.3:
   https://gmtwebsiteassets.s3-us-west-2.amazonaws.com/FallingSky/FS_Rules_2018.pdf
   Web refs: turn140view0, turn142view0, turn142view1.
3. GMT, Ariovistus Playbook, copyright 2018, A66:
   https://s3-us-west-2.amazonaws.com/gmtwebsiteassets/Ariovistus/Ariovistus_Playbook_Final_Lo-Res.pdf
   Web refs: turn129view1, turn140view2.
4. Publisher product page, identifying the linked Final Rules and Final Playbook:
   https://www.gmtgames.com/p-603-ariovistus-a-falling-sky-expansion.aspx
   Web refs: turn114view0, turn119view1.

## What these settle

A8.2.3 says, “For actions by Arverni, follow the Arverni Phase rules as applicable”. A6.2 requires At War for the normal phase and sequences Rally, March, Raid, Battle. It supplies no express rule converting that sequence into a choice of one Command.

A3.1 and A4.3.3 make Arverni Battle intrinsically accompany Ambush: “always accompany their Battle with Ambush”. They require more Hidden attackers than Hidden defenders; no Leader is required. Arverni never Entreat or Devastate. A5.4 permits granted Special Abilities to enable Ambush where applicable.

Base-game 4.5.1 grants an Enlisted German free Limited Command and still requires Ambush for its Battle. This is a same-game analogue supporting inherent Ambush despite a grant naming only a Command. Ordinary free actions otherwise preserve restrictions under 5.1.1/5.4. Base 8.2.3 uses the recipient's flowchart for Command choice, and random selection for otherwise unprioritized Event choices.

Playbook A66 explicitly gives a whole Arverni phase as if At War. That contrasts with the single-Command issue but does not directly resolve it.

## Provisional recommendation, not adopted

Keep the actual At War requirement. If at war, choose the first possible Command in phase order that the Event permits; use that Command's printed targets/priorities and stop after that one Command. If Battle is chosen, include its inherent Ambush and enforce Hidden superiority. Do not use the base-game Arverni flowchart, whose Leader, victory objectives, and Special Abilities differ.

This is an inference from the explicit A6.2 cross-reference, not an authoritative answer to the single-Command gap. Phase order is not expressly a choice priority. Random choice among legal Commands is a plausible competing reading of base 8.2.3. Retaining At War avoids adding an unstated awakening effect, but whether the Event itself bypasses that phase gate remains unresolved.

## Search limit

Focused searches covered official GMT rules/playbook/product links and BGG combinations of Ariovistus, Arverni, Celtic Rites, free Command, At Peace, A8.2.3, and designer names. No specific designer ruling answering these questions was located. Several BGG threads were inaccessible or unreadable through the available retrieval service, including the supplied errata thread 2072553; this is not proof that no ruling exists. The user's supplied 2018 errata text contains no answer to this issue.

Root must reopen cited web refs before using them in a user-facing final answer. Keep total direct quotation from the Ariovistus rules below 25 words; the two fragments above total 20 words.
