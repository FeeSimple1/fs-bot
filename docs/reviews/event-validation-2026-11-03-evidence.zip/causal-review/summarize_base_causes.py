"""Annotate all20 captured base first causes against the supplied rule receipts."""
import json
from pathlib import Path
root=Path(__file__).resolve().parent
report=json.loads((root/'first-divergences.json').read_text())
plans={label:{(r['scenario'],r['seed']):r for r in json.loads((root/f'{label}-base-causes.json').read_text())} for label in ('parent','candidate')}
replays={(r['scenario'],r['seed']):r for r in json.loads((root/'candidate-first-row-replays.json').read_text())['replays']}
rows=[]
for r in report['pairs']:
 if r['card'] not in (41,42):continue
 key=r['scenario'],r['seed']
 assert replays[key]['exact_replay']
 if r['card']==41:
  cause='Avaricum legal City/Ally priorities and seeded equal-candidate choices'
  detail='Both traces execute the same Event from identical state. The corrected plan gives Cities priority and uses seeded equal-candidate selections for placement/upgrade. Reconquest8 reaches the same board after two genuine tie draws; GreatRevolt8 upgrades the equally legal Mandubii Ally instead of Bituriges. These are live choices, not preview RNG.'
  sources=['Reference Documents/Card Reference:41','Reference Documents/Chapter 8:8.2.3,8.3.1,8.3.4,8.4.1']
 elif r['actor']=='Aedui':
  cause='Aedui declines Roman Wine because specific instruction forbids targeting Non-players'
  detail='All eligible opponent seats are Non-players. The supplied instruction permits player Arverni/Belgae in base or player Germans/Belgae in Ariovistus only. Candidate correctly continues on the flowchart instead of taking the old forbidden Event. No RNG is consumed by this availability determination.'
  sources=['Reference Documents/aedui_bot_event_instructions.txt:Roman Wine','Reference Documents/Ariovistus/aedui_bot_event_instructions_ariovistus.txt:Roman Wine','Reference Documents/Chapter 8:8.1.1,8.2.1']
 elif r['kind']=='decision':
  cause='Belgae declines shaded Roman Wine without Roman-Aedui Supply targets'
  detail='Captured board has no Supply-Line Regions even with hypothetical Roman and Aedui agreement. Thus no eligible shaded targets exist. Candidate continues to Raid; its normal flowchart die draw accounts for RNG advancement.'
  sources=['Reference Documents/Card Reference:42 shaded and Tips','Reference Documents/Chapter 8:8.1.1']
 elif r['actor']=='Romans':
  cause='Roman Wine uses the previously missing adjacent-to-Roman-Control alternative'
  detail='Parent derived no removal plan and executed an empty effect. Candidate selects exactly two eligible enemy Allies in Regions adjacent to Roman Control, preserving the printed alternative quota. A genuine equal-target ordering draw changes RNG. See exact targets and allowed Regions in candidate-base-causes.json.'
  sources=['Reference Documents/Card Reference:42 unshaded and Tips','Reference Documents/Chapter 8:8.2.3,8.3.4,8.4.1','Reference Documents/Ariovistus/Chapter A8:A8.4']
 else:
  cause='Belgic Roman Wine respects Belgica first and City/Remi priority'
  detail='Candidate removes Roman Remi in Belgica before spending remaining choices outside Belgica. Parent omitted Remi in favor of Catuvellauni or Lingones. Equal remaining candidates are chosen using the seeded RNG rather than alphabetical order. Both versions remove three legal Ally counters; the changed selection follows the specific instruction.'
  sources=['Reference Documents/Card Reference:42 shaded and Tips','Reference Documents/belgae_bot_event_instructions.txt:Roman Wine','Reference Documents/Chapter 8:8.2.1,8.2.3,8.3.1,8.3.4']
 rows.append({'scenario':r['scenario'],'seed':r['seed'],'card':r['card'],'actor':r['actor'],'kind':r['kind'],
              'cause':cause,'detail':detail,'sources':sources,'parent_plan':plans['parent'][key]['plan'],
              'candidate_plan':plans['candidate'][key]['plan'],'candidate_equal_choices':plans['candidate'][key]['random_choices'],
              'identical_prefix_and_complete_prestate':True,'exact_captured_row_replay':True,
              'classification':'source_supported_correction_no_unintended_first_cause_found'})
(root/'base-causal-review.json').write_text(json.dumps({'pairs':rows,'pair_count':len(rows),'independent_source_review':'event_validation_review cleared all20 concrete base positions','limitation':'First divergence only; no exhaustive downstream attribution and no new games.'},indent=2)+'\n')
print(json.dumps({'base_pairs':len(rows),'exact_row_replays':len(rows),'source_review_cleared':True}))
