#!/usr/bin/env python3
"""External, source-pinned audit of the optional base Diviciacus rule.

No repository files are changed. Each worker calls the maintained outcome
runner, injecting only setup_scenario(diviciacus_option=True), and retains
the exact initial/final states and every returned card result for inspection.
The default matrix is 3 base scenarios x 3 editions x seeds 201-210 = 90 games.
"""
from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import traceback


def canonical(value):
    if isinstance(value, list):
        return [canonical(item) for item in value]
    if isinstance(value, dict):
        result = {key: canonical(item) for key, item in value.items()}
        if set(result) == {"__dict__"}:
            result["__dict__"].sort(key=lambda pair: json.dumps(pair[0], sort_keys=True))
        return result
    return value


def digest(encoded):
    body = json.dumps(canonical(encoded), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(body.encode()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def file_name(scenario, edition, seed):
    slug = "-".join(scenario.lower().replace("?", "").split())
    return f"{slug}__{edition}__{seed}.json"


def play_task(task):
    repository, out, expected_source, scenario, edition, seed = task
    sys.path.insert(0, repository)
    from fs_bot import rules_consts as rc
    from fs_bot.engine.game_engine import get_sop_factions
    from fs_bot.state.serialize import encode
    from fs_bot.state.state_schema import validate_state, check_structural_integrity
    from fs_bot.tools import run_batch
    from fs_bot.tools.error_census import game_completion_error
    from fs_bot.tools.validation_metadata import source_identity

    initial_state = final_state = state = None
    cards, card_audits, extra_errors = [], [], []
    source_before = source_identity()
    original_setup, original_play = run_batch.setup_scenario, run_batch.play_card

    def persistent(current):
        return encode({key: value for key, value in current.items()
                       if key != "decision_agent"})

    def setup(*args, **kwargs):
        nonlocal state, initial_state
        kwargs["diviciacus_option"] = True
        state = original_setup(*args, **kwargs)
        state["non_player_factions"] = set(get_sop_factions(state))
        initial_state = persistent(state)
        return state

    def play(current, *args, **kwargs):
        result = original_play(current, *args, **kwargs)
        cards.append(result)
        findings = ([{"kind": "conservation", "message": message}
                     for message in validate_state(current)]
                    + [{"kind": "structural", "message": message}
                       for message in check_structural_integrity(current)])
        if current.get("diviciacus_option") is not True:
            findings.append({"kind": "option", "message": "Optional Leader rule lost"})
        if current.get("non_player_factions") != set(get_sop_factions(current)):
            findings.append({"kind": "seats", "message": "Not all active seats are NP"})
        for key in ("_diviciacus_force", "_diviciacus_confirmations",
                    "_diviciacus_preview", "_diviciacus_planning_faction"):
            if key in current:
                findings.append({"kind": "temporary-state", "message": key})
        card_audits.append({"card_index": len(cards), "card": result.get("card"),
            "state_sha256": digest(persistent(current)), "findings": findings})
        return result

    record = {"scenario": scenario, "seed": seed, "card_edition": edition,
              "diviciacus_option": True, "completed": False}
    try:
        if source_before["source_sha256"] != expected_source:
            raise RuntimeError("Source differs from the frozen digest before this game")
        run_batch.setup_scenario, run_batch.play_card = setup, play
        record.update(run_batch.play_one((scenario, seed, edition)))
        if state is None:
            raise RuntimeError("No game state was created")
        last = cards[-1] if cards else {}
        trajectory = {"card_results": cards, "total_cards_played": len(cards),
                      "game_over": last.get("game_over") is True}
        completion_error = game_completion_error(trajectory, state["scenario"])
        if completion_error:
            extra_errors.append({"stage": "completion", "message": completion_error})
        ranking = record.get("final_ranking") or []
        if len(ranking) != 4 or {entry[0] for entry in ranking} != set(get_sop_factions(state)):
            extra_errors.append({"stage": "ranking", "message": "Invalid final ranking factions"})
        if state["scenario"] != scenario:
            extra_errors.append({"stage": "scenario", "message": "Base scenario unexpectedly changed"})
    except Exception as exc:
        extra_errors.append({"stage": "external-runner", "type": type(exc).__name__,
                             "message": str(exc), "traceback": traceback.format_exc()})
    finally:
        run_batch.setup_scenario, run_batch.play_card = original_setup, original_play

    if state is not None:
        try:
            final_state = persistent(state)
            record["canonical_final_state_sha256"] = digest(final_state)
            record["state_and_trajectory_sha256"] = digest(
                {"state": final_state, "card_results": encode(cards)})
        except Exception as exc:
            extra_errors.append({"stage": "external-serialization", "message": str(exc)})
    source_after = source_identity()
    if source_after["source_sha256"] != expected_source:
        extra_errors.append({"stage": "source", "message": "Source changed during this game"})
    record.update(source_sha256=expected_source, source_before=source_before,
                  source_after=source_after, extra_errors=extra_errors,
                  cards_audited=len(card_audits),
                  additional_integrity_findings=[dict(card_index=audit["card_index"], **finding)
                    for audit in card_audits for finding in audit["findings"]])
    record["completed"] = (record.get("completed") is True and not extra_errors
        and not record["additional_integrity_findings"]
        and record.get("cards") == len(card_audits) == len(cards))
    artifact = file_name(scenario, edition, seed)
    record["artifact"] = f"games/{artifact}"
    write_json(Path(out) / "games" / artifact, {
        "record": record, "initial_state": initial_state,
        "card_results": encode(cards), "card_audits": card_audits,
        "final_state": final_state})
    return record


def summarize(records, source_unchanged, expected_keys):
    groups = {}
    for record in records:
        key = f"{record['scenario']} / {record['card_edition']}"
        group = groups.setdefault(key, {"attempted": 0, "completed": 0,
            "wins": Counter(), "terminations": Counter(), "diagnostics": Counter(),
            "cards_audited": 0, "failures": []})
        group["attempted"] += 1
        group["cards_audited"] += record.get("cards_audited", 0)
        for diagnostic in record.get("diagnostics", []):
            group["diagnostics"][diagnostic["severity"]] += diagnostic["count"]
        if record.get("completed"):
            group["completed"] += 1
            group["wins"][record["winner"]] += 1
            group["terminations"][record["termination"]] += 1
        else:
            group["failures"].append({"seed": record["seed"],
                                      "artifact": record.get("artifact")})
    identities = [{key: record.get(key) for key in (
        "scenario", "card_edition", "seed", "winner", "final_ranking",
        "canonical_final_state_sha256", "state_and_trajectory_sha256", "completed")}
        for record in sorted(records, key=lambda row: (
            row["scenario"], row["card_edition"], row["seed"]))]
    actual_keys = [(record["scenario"], record["card_edition"], record["seed"])
                   for record in records]
    matrix_complete = (len(records) == len(set(actual_keys)) == len(expected_keys) == 90
                       and set(actual_keys) == set(expected_keys))
    return {"attempted": len(records), "matrix_complete": matrix_complete,
            "completed": sum(record.get("completed") is True for record in records),
            "source_unchanged": source_unchanged,
            "accepted": source_unchanged and matrix_complete
                        and all(record.get("completed") is True for record in records),
            "matrix_results_sha256": digest(identities), "groups": groups}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path,
        default=Path("/workspace/scratch/534c265c65f4/fs-bot"))
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=3)
    parser.add_argument("--expect-source-sha256", required=True,
                        help="Required frozen source digest supplied by the integrator")
    args = parser.parse_args()
    if os.environ.get("PYTHONHASHSEED") != "0":
        parser.error("Launch with PYTHONHASHSEED=0")
    if args.workers < 1:
        parser.error("--workers must be positive")
    if args.out.exists() and any(args.out.iterdir()):
        parser.error("Output directory must be fresh; prior runs are never overwritten")
    sys.path.insert(0, str(args.repo.resolve()))
    from fs_bot import rules_consts as rc
    from fs_bot.cards.edition import CARD_EDITIONS
    from fs_bot.tools.validation_metadata import source_identity
    before = source_identity()
    if before["source_sha256"] != args.expect_source_sha256:
        parser.error("Current source does not match --expect-source-sha256")
    scenarios = [rc.SCENARIO_PAX_GALLICA, rc.SCENARIO_RECONQUEST,
                 rc.SCENARIO_GREAT_REVOLT]
    editions, seeds = list(CARD_EDITIONS), list(range(201, 211))
    if len(editions) != 3:
        parser.error("Expected the documented three card editions")
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "games").mkdir()
    metadata = {"metadata_version": 1, "tool": "optional_diviciacus_validation",
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "source": before, "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "python": platform.python_version(), "hash_seed": 0,
        "repo": str(args.repo.resolve()), "workers": args.workers,
        "scenarios": scenarios, "card_editions": editions, "seeds": seeds,
        "diviciacus_option": True, "all_factions_bots": True, "expected_games": 90,
        "command": sys.argv, "audit_boundaries": ["setup", "before-decision", "after-card"],
        "diagnostic_coverage": "returned-cards-only; exceptions retained as failures"}
    write_json(args.out / "metadata.json", metadata)
    tasks = [(str(args.repo.resolve()), str(args.out.resolve()), args.expect_source_sha256,
              scenario, edition, seed) for scenario in scenarios
             for edition in editions for seed in seeds]
    records = []
    with ProcessPoolExecutor(max_workers=args.workers) as pool, \
            (args.out / "games.jsonl").open("w") as output:
        futures = {pool.submit(play_task, task): task for task in tasks}
        for future in as_completed(futures):
            task = futures[future]
            try:
                record = future.result()
            except Exception as exc:
                record = {"scenario": task[3], "card_edition": task[4], "seed": task[5],
                    "completed": False, "source_sha256": args.expect_source_sha256,
                    "extra_errors": [{"stage": "worker", "type": type(exc).__name__,
                        "message": str(exc), "traceback": traceback.format_exc()}]}
            records.append(record)
            output.write(json.dumps(record, sort_keys=True) + "\n")
            output.flush()
            print(f"{len(records)}/90 {record['scenario']} / {record['card_edition']} "
                  f"seed {record['seed']}: {'PASS' if record['completed'] else 'FAIL'}", flush=True)
    after = source_identity()
    summary = summarize(records, after["source_sha256"] == args.expect_source_sha256,
                        {(task[3], task[4], task[5]) for task in tasks})
    summary["source_after"] = after
    write_json(args.out / "summary.json", summary)
    metadata["finished_utc"] = datetime.now(timezone.utc).isoformat()
    write_json(args.out / "metadata.json", metadata)
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0 if summary["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
