# Colony Event defaults and fuzz validation

This archive preserves a failed CI result, its reproduction, the underlying
repair and final acceptance. It uses no new rule source or project ruling.

The task parent is 3873ff97505194557e1ed63b833d7bf2e5317fdc, whose 422-file
Python digest is 9d4cc73f2efaa33b8e6ad871fb432ae43c7471d5222b1c13d9c9b571c0c3c4a8.
The prepared candidate has 424 Python files, digest
c3c3cd4fd4370f4367db759106b7418449bcc0c27b34ceae2e93c014c64b3bf4.
Acceptance occurs before committing the candidate; original parent/dirty-tree
metadata is retained. The manifest and patch identify the tested bytes.

- github-player-fuzz-failed.log records the Python 3.10.22 hash discrepancy.
- before-hash0/7 use Python 3.12.14, each 200 cases with replay; both match.
  before-full records 6,872 passing tests on that parent runtime.
- reproduce_ci.py runs the same 200-case/replay loop under Python 3.10.22,
  hash 7, saving differing complete histories without changing execution.
  before-python310-hash7 reproduces the exact GitHub digest. Only Ariovistus
  seed 17 differs from hash 0; its final state and RNG agree.
- ariovistus17-final-diffs.json and a45-source-failure show the caught mixed
  None/string sort caused by the Colony's absent static-map lookup.
- colony-regressions-before-final.log records five failures with the parent
  module; colony-regressions-after-final.log records 45 focused passes.
  Earlier fixture attempts remain retained and are explained in the handoff.
- captured-bot-rejection-proof.json re-evaluates the old retained trajectory
  with the new oracle: one hard finding, unchanged digest, no new game.
- partial-review.md explains the two intentional random-policy Resource
  shortfalls. Two diagnostic games reproduce them; they remain reported.
- after-full is the final Python 3.10 suite. after-hash0/7 each run the exact
  200-case CI fuzz set with replay: 800 executions total, 200 distinct cases.
  These are repeat observations, not 800 independent games.
- bots contains 100 fresh audited zero-player games. parent-bots preserves
  previous records with exactly the task parent's Python bytes, although
  their original metadata identifies the earlier prepared source over 2edf53e.
  Reused records are not newly executed games.
- check_acceptance.py verifies full records, source/protected files, exact
  cross-hash JSON/stdout and the unchanged 15-point balance band.

Independent review cleared source, test and CI changes. Source/protected-file
verification and archive CRC/per-entry SHA checks accompany publication.
The original 50-finding register remains 18 closed and 32 open. This follow-up
adds no claim of exhaustive rules compliance or statistical balance.
