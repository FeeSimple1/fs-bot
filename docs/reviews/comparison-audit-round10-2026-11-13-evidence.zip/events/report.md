# Tenth audit — Events and NP Event selection

Audited Falling Sky commit: `ae238c6482a792dda98af4f1f9b11abf820a3964`. No production files changed. Two new medium findings are proven.

## Method and coverage

The final script uses production `setup_scenario` for Ariovistus and The Gallic War, seeds 1 and 317. Physical setup is unchanged for positive and recipient controls; negative prerequisites are created only with `_unally_tribe` and `_ally_tribe`. Every witness invokes public `dispatch_bot_turn` and `execute_decision`. Every case asserts complete `validate_state` and `check_structural_integrity` success and the permanent Provincia Fort before/after. Conditional-effect queries must not change board or RNG.

`results.json` contains eight no-effect natural Event witnesses, eight executed ordinary-flowchart controls with Event disabled, six original-setup positive controls, four Aedui self-benefit witnesses, and four explicit human Warband controls. The script is deterministic and accepts `--repo` for independent reruns. This is bounded controlled coverage, not an exhaustive Events audit or encounter-frequency measurement.

The audit read current Event-effect dispatch, the generic effect-flag evaluator, per-Event applicability gates, the NP parameter producers, relevant expansion handlers, current provisional rulings, historical rounds 6–9, original human Event inventory, expansion optional-quantity repair, and earlier A51/A69 reports. Already repaired Oppida sequential planning, Procillus/Divico parameters, Rhenus Bridge, Legiones, Lost Eagle, Alpine Tribes, Sabis scope and Aedui Arduenna gates were distinguished from these new cases. Other reviewed handlers were not promoted without a public witness.

## EV10-01 — Conditional Bellovaci and Siege of Bibrax select ineffective Events

**Expected.** Chapter 8 lines 30–46 requires declining ineffective Events. A Card Reference lines 231–236 conditions all A51 unshaded text on Remi being Roman/Aedui Allied or Subdued; lines 316–321 condition A69 shaded on Bellovaci being a Belgic Ally. Chapter A8 lines 1–10 adopts these NP rules for both expansion scenarios.

**Observed.** In both scenarios, NP Belgae choose and successfully execute shaded A69 with Bellovaci Subdued or Aedui Allied. NP Romans and Aedui likewise choose and successfully execute unshaded A51 with Remi Belgic Allied. Nothing changes in the tracked game effects. All eight same-board controls with Event unavailable instead execute an ordinary non-Pass Command, with actual effects. Original-setup positive controls satisfy each printed condition and do place pieces.

**Cause.** `bot_common.py:373–381` defers to `np_event_available` and `is_event_effective`. No side-specific A51/A69 prerequisite guard exists. The A69 `FREE_BATTLE` flag returns true at `event_eval.py:1073–1081`; the A51 `PLACES_AUXILIA` flag returns true from Available stock at lines 1139–1141. Their handlers correctly return without effects at `card_effects.py:3346–3357` and 3691–3702. Thus the admission check and real handler disagree.

**Repair scope.** Reuse the actual conditional predicates in NP applicability and retain all legal human and partial execution behavior. This does not require changing the printed handlers' existing condition logic. Preserve A51 own-recipient handling as separate EV10-02 work.

**Prior distinction.** BE7-03 concerned conditional Rhenus Bridge; EV9-02 concerned Lost Eagle. Original EXP-08 concerned human A51 removal quantities/Scouted casualties; EX2-02 concerned A51 shaded exact Allied-Tribe removals. EX4-02 concerned A69 unshaded owner/type compatibility and EXP-04 its shaded Ambush chooser. None established these A51/A69 NP admission failures.

**Limits.** Only the named false prerequisites are proven. No universal Event-effectiveness or exhausted-stock claim is made. Game-effect comparison includes physical board and pools, tribes, resources, Senate, Legion track/Fallen/removed, markers, capabilities/owners, eligibility and persistent eligibility modifiers, and Event modifiers.

## EV10-02 — Aedui give Siege of Bibrax troops to Romans

**Expected.** A51 unshaded offers Roman Auxilia or Aedui Warbands (A Card Reference lines 231–236). Chapter 8 lines 120–128 requires NP factions to select themselves for Event benefits. No Aedui instruction exception applies. With 17 Aedui Warbands Available, Aedui must choose four of their own.

**Observed.** NP Aedui naturally select A51 on untouched physical Ariovistus/Gallic War setups and receive zero Warbands while Romans receive four Auxilia. Four cases cover both scenarios and both human/NP Roman seats. Each identical-board explicit human Warband control succeeds, placing four Aedui Warbands and no Auxilia. The mandated Roman Fort and removal of the original Belgic Warband also work. NP Roman controls correctly receive Auxilia.

**Cause.** `_derive_event_params` (`execute.py:5967–6012`) and `_EVENT_PARAM_DERIVERS` (6568–6609) omit unshaded A51 ownership. `execute_card_A51` (`card_effects.py:3358–3369`) defaults missing `piece_type` to Auxilia. The later optional-removal chooser cannot repair this already executed prefix.

**Repair scope.** Produce the NP's legal troop choice before mandatory placement. Preserve human ownership choice, the mandatory Fort, removal behavior and partial-execution semantics. Inspect own-stock boundaries under the supplied rules, without treating an enemy stock as the NP benefit.

**Prior distinction.** BE6-02 and BE7-02 covered missing NP producers for other cards. EV9-01/03 concerned A40 priorities/stacking. Original EXP-08 fixed A51 human optional removal quantities, leaving this prefix unchanged. EX2-02 concerned the shaded side. EV10-01 controls whether the Event can act and cannot fix ownership on an otherwise legal Event.

**Limits.** This finding proves the adequate-own-stock case only; zero/scarce-stock choice semantics and human legacy defaults are not independently classified.

## Comparator inspection

Comparator `lod-bot` commit `2991ea279062773548ec390a1da75f3e85381702` was inspected only for engineering patterns. `lod_ai/bots/base_bot.py:459–505` executes Event handlers on isolated before/after states for effectiveness, includes queued operations, and avoids future combat RNG. `lod_ai/engine.py:500–550` distinguishes legal no-plan declines from planner execution errors and completes Event evidence after granted free operations. `docs/audit_event_gain_priorities_cards1_16_21.md` documents that a working generic selector does not prove per-card benefit ordering when local handlers bypass it. These suggested checking the actual effect and actual beneficiary behind coarse flags/defaults; Liberty or Death rules supply no Falling Sky rule authority.

## Reproduction

```sh
PYTHONHASHSEED=0 /workspace/scratch/4aba5bd9b1ab/fs-bot/.venv/bin/python audit10/events/probe_events.py --repo /workspace/scratch/521fc7ecea8c/falling-sky
```

Use the absolute script path when running outside `/workspace/scratch/521fc7ecea8c`. Machine-readable exact source/code ranges, controls, repair scopes and limits are in `findings.json`.
