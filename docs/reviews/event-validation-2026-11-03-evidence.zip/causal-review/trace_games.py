"""Bounded live-only paired traces, adapted from the prior verified trace codec.

The parent is a committed tree. The candidate is an explicitly prepared,
uncommitted tree identified by its full Python manifest; HEAD alone is not
its executed source. Only pairs in --differences are run, without previews.
"""
import argparse
import contextlib
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

ap = argparse.ArgumentParser()
ap.add_argument('--worktree', required=True)
ap.add_argument('--label', choices=('parent', 'candidate'), required=True)
ap.add_argument('--out', required=True)
ap.add_argument('--differences', required=True)
ap.add_argument('--parent-commit', default='8db858b14cd13856059d42db1ad3931e523b5ed4')
ap.add_argument('--candidate-manifest', required=True)
ap.add_argument('--verify-only', action='store_true')
args = ap.parse_args()
assert os.environ.get('PYTHONHASHSEED') == '0'
root = Path(args.worktree).resolve()
out = Path(args.out).resolve()
out.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(root))
from fs_bot import rules_consts as rc
from fs_bot.engine import execute as ex
from fs_bot.engine.game_engine import run_game, ACTION_EVENT, get_sop_factions
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.cli.dispatcher import _translate_bot_action
from fs_bot.state.setup import setup_scenario
from fs_bot.state.serialize import encode
from fs_bot.tools.validation_metadata import source_identity


def verify_source():
    files = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
             for p in sorted((root / 'fs_bot').rglob('*.py'))}
    identity = source_identity()
    if args.label == 'parent':
        assert identity['commit'] == args.parent_commit, identity
        changes = subprocess.check_output(
            ['git', 'diff', 'HEAD', '--', 'fs_bot'], cwd=root, text=True)
        extras = subprocess.check_output(
            ['git', 'ls-files', '--others', '--exclude-standard', '--', 'fs_bot'],
            cwd=root, text=True).splitlines()
        assert not changes and not any(p.endswith('.py') for p in extras)
        identity.update(verification='committed_parent_python_tree',
                        verified_source_commit=args.parent_commit)
    else:
        expected = json.loads(Path(args.candidate_manifest).read_text())
        assert files == expected['files'], 'Prepared Python manifest no longer matches'
        assert identity['source_sha256'] == expected['source']['python_sha256'], identity
        identity.update(verification='prepared_uncommitted_python_manifest',
                        prepared_source=expected['source'],
                        prepared_manifest=str(Path(args.candidate_manifest).resolve()))
    identity.update(python=platform.python_version(), hash_seed='0',
                    worktree=str(root), python_files=len(files), card_edition='legacy')
    return identity


identity = verify_source()
pairs = json.loads(Path(args.differences).read_text())
assert len({(p['scenario'], p['seed']) for p in pairs}) == len(pairs)
assert all(p['scenario'] in rc.ALL_SCENARIOS for p in pairs)
source_record = {'source': identity, 'difference_file': str(Path(args.differences).resolve()),
                 'difference_sha256': hashlib.sha256(Path(args.differences).read_bytes()).hexdigest(),
                 'bounded_pair_count': len(pairs)}
(out / f'{args.label}-source-verification.json').write_text(json.dumps(source_record, indent=2) + '\n')
if args.verify_only:
    print(json.dumps(source_record), flush=True)
    raise SystemExit(0)

manifest = []
original = ex.execute_decision
for pair in pairs:
    scenario, seed = pair['scenario'], pair['seed']
    st = setup_scenario(scenario, seed=seed)
    st['non_player_factions'] = set(get_sop_factions(st))
    trace = []

    def snap(board):
        return encode({k: v for k, v in board.items() if k != 'decision_agent'})

    def choose(board, faction, options, position):
        row = {'index': len(trace), 'kind': 'decision', 'card': board.get('current_card'),
               'card_index': len(board.get('played_cards', [])), 'faction': faction,
               'position': position, 'options': options, 'before': snap(board)}
        board['current_card_id'] = board.get('current_card')
        board['is_second_eligible'] = position == '2nd_eligible'
        board['can_play_event'] = ACTION_EVENT in options
        ba = dispatch_bot_turn(board, faction)
        result = {'action': _translate_bot_action(ba, options), 'bot_action': ba}
        row.update(decision=encode(result), after=snap(board))
        trace.append(row)
        return result

    def execute(board, faction, decision, *a, **kw):
        if board is not st:
            return original(board, faction, decision, *a, **kw)
        row = {'index': len(trace), 'kind': 'execution', 'card': board.get('current_card'),
               'card_index': len(board.get('played_cards', [])), 'faction': faction,
               'decision': encode(decision), 'before': snap(board)}
        result = original(board, faction, decision, *a, **kw)
        row.update(result=encode(result), after=snap(board))
        trace.append(row)
        return result

    ex.execute_decision = execute
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            result = run_game(st, decision_func=choose, execute=True)
    finally:
        ex.execute_decision = original
    winner = next((r['winner'] for r in reversed(result['card_results']) if r.get('winner')), None)
    outcome = {'winner': winner, 'cards': result['total_cards_played']}
    expected = pair['before' if args.label == 'parent' else 'after']
    assert outcome == expected, (scenario, seed, outcome, expected)
    name = f"{args.label}-{scenario.replace(' ', '-').replace('?', '')}-{seed}.json.gz"
    record = {'source': identity, 'scenario': scenario, 'seed': seed,
              'outcome': outcome, 'trace': trace, 'result': encode(result), 'final': snap(st)}
    with gzip.open(out / (name + '.tmp'), 'wt', encoding='utf-8', compresslevel=6) as handle:
        json.dump(record, handle, sort_keys=True)
    (out / (name + '.tmp')).replace(out / name)
    entry = {'file': name, 'scenario': scenario, 'seed': seed, 'outcome': outcome,
             'rows': len(trace), 'sha256': hashlib.sha256((out / name).read_bytes()).hexdigest()}
    manifest.append(entry)
    (out / f'{args.label}-manifest.json').write_text(
        json.dumps({'source': identity, 'games': manifest}, indent=2) + '\n')
    print(json.dumps(entry), flush=True)
assert verify_source() == identity, 'Executed source identity changed during trace run'
print(json.dumps({'completed': len(manifest), 'source_verified_after': True}), flush=True)
