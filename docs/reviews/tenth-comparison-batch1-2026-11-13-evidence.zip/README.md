# Tenth comparison repair Batch 1 evidence

This archive records Bellovaci and Siege of Bibrax repairs for EV10-01
and EV10-02. The audit revision is `62cb21484da257600c6ebddc04d2e531d545965e`.
`source.json` identifies the tested patch and Python version. `SHA256SUMS`
covers each other member. The two repaired sides and their human-choice
controls use normal bot dispatch and public execution on canonical boards.

The 100 parent legacy games come from the ninth audit's final repair batch
and match the audit revision's Python source digest. The parent second-edition
games and mixed replay come from the tenth audit. The paired traces rerun all
15 changed legacy games using both revisions and capture their first different
card, its board and RNG fingerprints, and the immediate Event effects.

## Reproduce the checks

Use the repaired checkout, Python 3.12.14 and the development test environment.
Run from the repository root with `OUT` set to an empty directory for the new
outputs. `EVIDENCE` points to the extracted archive and `PARENT` to a clean
checkout of the audit revision.

```bash
PYTHONHASHSEED=0 python -m pytest -q fs_bot/tests/test_tenth_comparison_events.py
PYTHONHASHSEED=0 python -m pytest -q -n 4 --junitxml="$OUT/full.xml"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out "$OUT/legacy"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 53-56 --card-edition second-edition --workers 2 --out "$OUT/second-edition"
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 53-56 --card-edition second-edition --out "$OUT/fuzz0.json" > "$OUT/fuzz0.log"
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 53-56 --card-edition second-edition --out "$OUT/fuzz987.json" > "$OUT/fuzz987.log"
cmp "$OUT/fuzz0.json" "$OUT/fuzz987.json"
cmp "$OUT/fuzz0.log" "$OUT/fuzz987.log"
PYTHONPATH=. PYTHONHASHSEED=0 python "$EVIDENCE/trace_events.py" "$EVIDENCE/trace-legacy-tasks.json"
```

The targeted suite also reproduces the parent failures with the included
test file. Run the following from the audit checkout. The expected result
is 18 failures and five passing controls.

```bash
cd "$PARENT"
PYTHONPATH=. PYTHONHASHSEED=0 python -m pytest -q "$EVIDENCE/test_tenth_comparison_events.py"
PYTHONPATH=. PYTHONHASHSEED=0 python "$EVIDENCE/trace_events.py" "$EVIDENCE/trace-legacy-tasks.json"
```

To verify the preserved outputs and the patched source digest, return to the
repaired checkout and run `PYTHONPATH=. python "$EVIDENCE/verify_results.py"`.
The original logs record their own checkout and source identity.
