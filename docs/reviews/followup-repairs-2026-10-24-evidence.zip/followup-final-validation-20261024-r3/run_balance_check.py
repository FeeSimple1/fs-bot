"""Run actual balance CLI and audit every winner/card pair independently."""
from pathlib import Path
import json,os,re,subprocess,sys
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'fs-bot'
sys.path.insert(0,str(REPO))
from fs_bot.tools.validation_metadata import source_identity
from fs_bot.tools.run_batch import SCENARIOS
expected=json.loads((ROOT/'freeze.json').read_text())['source_sha256']
before=source_identity()
assert before['source_sha256']==expected
cmd=[sys.executable,'-u','-m','fs_bot.tools.balance_smoke','--seeds','1-20']
with (ROOT/'balance-smoke-final.log').open('x') as log:
    proc=subprocess.Popen(cmd,cwd=REPO,env={**os.environ,'PYTHONHASHSEED':'0'},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    for line in proc.stdout:
        log.write(line);log.flush()
        if 'seed=20]' in line:print(line.strip(),flush=True)
    code=proc.wait()
current={}
for line in (ROOT/'balance-smoke-final.log').read_text().splitlines():
    match=re.fullmatch(r'\[(.+) seed=\s*(\d+)\] winner=(.+) \((\d+) cards\)',line)
    if match:
        scenario,seed,winner,cards=match.groups()
        key=f'{scenario}|{int(seed)}'
        assert key not in current
        current[key]=dict(winner=winner,cards=int(cards))
keys={f'{scenario}|{seed}' for scenario in SCENARIOS for seed in range(1,21)}
baseline=json.loads((REPO/'fs_bot/tools/balance_baseline.json').read_text())['games']
differences=[dict(key=k,baseline=baseline.get(k),current=current.get(k)) for k in sorted(keys) if baseline.get(k)!=current.get(k)]
after=source_identity()
report=dict(command=cmd,exit_code=code,source_before=before,source_after=after,source_stable=after['source_sha256']==expected,games=len(current),coverage_exact=set(current)==keys,winner_and_card_differences=differences,current=current)
(ROOT/'balance-smoke-final-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='current'},indent=2),flush=True)
raise SystemExit(0 if code==0 and report['source_stable'] and report['coverage_exact'] and not differences else 1)
