import json,subprocess
from pathlib import Path
from fs_bot import rules_consts as rc
from fs_bot.tools.validation_metadata import source_identity
parent='70c571cca14380c33f310b45c02cf615143b3ed0'
source=source_identity()
assert source['source_sha256']=='5179ad47b36917a8447e1e4dbe8b122f7e795e1d499736e68b0b66eb0e019d76'
a=[json.loads(x) for x in Path('/tmp/fs-intimidate-bots-parent/games.jsonl').read_text().splitlines()]
b=[json.loads(x) for x in Path('/tmp/fs-intimidate-bots-final-v3/games.jsonl').read_text().splitlines()]
key=lambda r:(r['scenario'],r['seed']);a={key(r):r for r in a};b={key(r):r for r in b}
assert set(a)==set(b)=={(s,n) for s in rc.ALL_SCENARIOS for n in (1,2)}
ignored={'seconds','commit','source_sha256'}
for k in a:
 assert {f:v for f,v in a[k].items() if f not in ignored}=={f:v for f,v in b[k].items() if f not in ignored},k
 for r in (a[k],b[k]):
  assert all(r[f] for f in ('completed','game_completed','audit_completed','final_state_sha256'))
  assert not r['errors'] and not r['integrity_findings']
  assert len(r['final_ranking'])==4
  assert not r['engine_ranking_output_missing'] and not r['winner_differs_from_highest_margin']
  assert all(d['severity']=='legal-decline' for d in r['diagnostics'])
m0=json.loads(Path('/tmp/fs-intimidate-mixed0-v3.json').read_text());m987=json.loads(Path('/tmp/fs-intimidate-mixed987-v3.json').read_text());assert m0==m987 and not m0['hard_findings']
assert m0['metadata']['source_sha256']==source['source_sha256']
assert json.loads(Path('/tmp/fs-intimidate-bots-final-v3/metadata.json').read_text())['source_sha256']==source['source_sha256']
protected=[p for p in Path('Reference Documents').rglob('*') if p.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
for p in protected:assert p.read_bytes()==subprocess.check_output(['git','show',parent+':'+str(p)])
trace=json.loads(Path('/tmp/fs-intimidate-partial-inspect-v3.json').read_text())
assert trace['source']['source_sha256']==source['source_sha256']
assert trace['record']['digest']==next(r['digest'] for r in m0['records'] if r['scenario']==rc.SCENARIO_PAX_GALLICA and r['seed']==2)
result={'date':'2026-11-04','timezone':'America/Chicago','source':source,'python_files':len(list(Path('fs_bot').rglob('*.py'))),'protected_files':len(protected),'protected_files_unchanged':True,'targeted_passed':229,'new_tests':44,'parent_proof':{'behavioral_failures':23,'passing_controls':2,'deselected':19},'bots':{'games':10,'all_completed_and_audited':True,'all_gameplay_fields_and_final_hashes_equal':True,'excluded':sorted(ignored)},'mixed':m0,'hash_seeds':[0,987],'mixed_complete_json_equal':True,'mixed_executions_including_replay':40,'partial_trace':trace,'original_progress':{'closed':23,'total':50,'percent':46,'open':27},'remaining_CV-PERSISTENCE':'open; no marked-group tracking, movement or virtual Fort repair in this batch'}
Path('/tmp/fs-intimidate-results-v3.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':source,'targeted':229,'new_tests':44,'bot_games_equal':10,'mixed_equal':True,'hard_findings':m0['hard_findings'],'soft_partial_per_10_cases':m0['partial'],'protected_files':len(protected)}))
