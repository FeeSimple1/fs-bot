"""Read-only derivation of captured Card41/42 first causes; no full games."""
import argparse, json, sys
from pathlib import Path
ap=argparse.ArgumentParser(); ap.add_argument('--worktree',required=True); ap.add_argument('--label',required=True); args=ap.parse_args()
sys.path.insert(0,args.worktree)
from fs_bot.engine import execute as ex
from fs_bot.state.serialize import decode,encode
from fs_bot.tools.validation_metadata import source_identity
from fs_bot.bots import bot_common
root=Path(__file__).resolve().parent
summary=json.loads((root/'first-divergences.json').read_text())
assert source_identity()['source_sha256']==summary['source'][args.label]['source_sha256']
records=[]
original=bot_common.random_select
for item in summary['pairs']:
 if item['card'] not in (41,42): continue
 row=json.loads((root/item['first_rows_file']).read_text())[args.label]
 st=decode(row['before']); st['executing_faction']=row['faction']
 shaded=(row['decision']['bot_action'].get('details',{}).get('text_preference')=='Shaded') if row['kind']=='execution' else row['faction']=='Belgae'
 calls=[]
 def traced(state,candidates):
  before=encode(state['rng']); result=original(state,candidates)
  calls.append({'options':encode(list(candidates)),'selected':encode(result),'consumed_rng':encode(state['rng'])!=before})
  return result
 bot_common.random_select=traced
 try:
  plan=getattr(ex,f"_derive_card_{item['card']}")(st,row['faction'],shaded)
 finally: bot_common.random_select=original
 rec={'scenario':item['scenario'],'seed':item['seed'],'card':item['card'],'kind':item['kind'],'actor':row['faction'],'shaded':shaded,'plan':encode(plan),'random_choices':calls}
 if args.label=='candidate' and item['card']==42:
  from fs_bot.cards.base_event_limits import wine_regions,wine_targets
  modes=wine_regions(st,shaded)
  rec['eligible_targets']={m:{t:st['tribes'][t]['allied_faction'] for t in wine_targets(st,regions,shaded)} for m,regions in modes.items()}
  rec['allowed_regions']={m:sorted(regions) for m,regions in modes.items()}
  rec['non_player_factions']=sorted(st.get('non_player_factions',[]))
 records.append(rec)
(root/f'{args.label}-base-causes.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'label':args.label,'captured_causes':len(records)}))
