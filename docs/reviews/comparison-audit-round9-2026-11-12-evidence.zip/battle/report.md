# Ninth audit: battle lane

Audited commit: `f4c8372c396981c0a31dc6f4545e67f8c6f2e981`.
No independent battle-mechanics finding was promoted in this lane. This is a bounded review result, not a claim that combat is defect-free.

The review covered shared Attack/Counterattack Loss calculation, opening Slingers/Archers hooks, fixed Event and queued automatic Battles, borrowed Enlist/free-force and combined-force ownership, projected Morbihan casualties, Retreat declarations/disposition, Elite physical cohorts, Besiege and Ballistae target handling. The supplied reference inventory is retained in `reference_inventory.txt`. Comparative finding ledgers through round eight were checked; rules remain governed by the supplied Falling Sky/Ariovistus documents and adopted project rulings. Liberty or Death's engineering lessons were used only as a checklist for alternate consumers, force views, and scoped modifiers.

The directed current-Event candidate is explicitly **excluded**, not a confirmed defect: with Stalwart already active, numeric6 Marcus Antonius still doubles Roman Auxilia's Attack Losses against Germans. Eight public-path cases cover Germans/Belgae, active/inactive Stalwart and ordinary/Event Battles. Every fixture passes census and structural checks before and after. The observation is reproducible but the supplied §5.1.2 gives the current Event precedence; a generic reading of Stalwart cannot establish a new bug in the face of that rule. Historical QUESTIONS.md:2902–2907 records a narrower owner-delegated interpretation for no-retreat/warband_full_loss, not this exact modifier. No repair or additional ruling is requested from this excluded candidate.

Morbihan's presentation view appeared to restore original Warband counts after Slingers prefire instead of surviving counts. This lead was handed to the frontend lane for its own public-path and durable-session verification; it must be counted only there if confirmed. A speculative concern about Morbihan's forecast before opening fire was not promoted.

Existing targeted regression suite: **347 passed**, no failures, one external pytest/anyio deprecation warning, 3.40 seconds. `focused-tests.log` and `focused-tests.xml` preserve the invocation results. These tests cover the existing suite and are distinct from any new directed witnesses; no production sources, tests, references, or game rulings changed.

An independent review of the Event lane is recorded separately once its final witnesses are frozen.
