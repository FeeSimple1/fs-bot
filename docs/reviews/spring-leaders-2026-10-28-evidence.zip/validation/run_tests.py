"""Capture final full-suite or same-API rule probes on the explicit frozen source.

This scratch runner never changes repository files. Each output set is exclusive;
failed/interrupted checks remain evidence and cannot be silently overwritten.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "fs-bot"
PYTHON = ROOT.parent / "fs-test-venv/bin/python"


def identity():
    source = hashlib.sha256()
    for path in sorted((REPO / "fs_bot").rglob("*.py")):
        source.update(str(path.relative_to(REPO)).encode() + b"\0" + path.read_bytes())
    commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip()
    tracked = subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=no"], cwd=REPO, text=True)
    untracked = subprocess.check_output(["git", "ls-files", "--others", "--exclude-standard", "-z", "--", "fs_bot"], cwd=REPO, text=True).split("\0")
    return {"source_sha256": source.hexdigest(), "commit": commit,
            "dirty": bool(tracked.strip() or any(p.endswith(".py") for p in untracked))}


def utc():
    return datetime.now(timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attempt", required=True)
    parser.add_argument("--source-sha256", required=True)
    parser.add_argument("--check", choices=("tests", "probes"), default="tests")
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--label", default="tests", help="fresh full-suite output prefix")
    parser.add_argument("--approved-baseline-sha256", help="explicit parent-approved baseline identity for final post-refresh suite")
    args = parser.parse_args()
    if any(Path(v).name != v for v in (args.attempt, args.label)) or args.workers < 1:
        parser.error("simple attempt name and positive workers required")
    run = ROOT / args.attempt
    if not run.is_dir():
        parser.error("start the frozen matrix orchestrator first")
    freeze = json.loads((run / "freeze.json").read_text())
    source = identity()
    baseline = (REPO / "fs_bot/tools/balance_baseline.json").read_bytes()
    if source["source_sha256"] != args.source_sha256 or freeze["source_sha256"] != args.source_sha256:
        parser.error("current/requested/attempt source digests differ")
    expected_baseline = args.approved_baseline_sha256 or freeze["balance_baseline_sha256"]
    if source["commit"] != freeze["commit"] or hashlib.sha256(baseline).hexdigest() != expected_baseline:
        parser.error("commit or original baseline differs from frozen attempt")
    if args.check == "tests":
        prefix, output_path = args.label, run / (args.label + ".log")
        argv = [str(PYTHON), "-m", "pytest", "-q", "-n", str(args.workers),
                "--junitxml=" + str(run / (args.label + ".xml"))]
        reserved = [run / (args.label + ".xml")]
        probe_digest = None
    else:
        prefix, output_path = "rule-probes-final", run / "rule-probes-final.json"
        probe = ROOT / "rule_probes.py"
        probe_digest = hashlib.sha256(probe.read_bytes()).hexdigest()
        argv = [str(PYTHON), "-c", f"import runpy; runpy.run_path({str(probe)!r}, run_name='__main__')"]
        reserved = []
    status_path = run / (prefix + ".status.json")
    if any(p.exists() for p in [output_path, status_path, *reserved]):
        parser.error("output exists; preserve this evidence and choose a new attempt")
    def fixture_identity():
        return {str(p.relative_to(REPO)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in sorted((REPO / "fs_bot/tests/fixtures").rglob("*")) if p.is_file() and p.suffix not in (".py", ".pyc", ".pyo") and "__pycache__" not in p.parts}
    fixtures = fixture_identity()
    status = {"argv": argv, "cwd": str(REPO), "source": source, "started_utc": utc(),
              "exit_code": None, "runner_exit_code": None, "source_changed": False,
              "environment": {"PYTHONHASHSEED": "0", "PYTHONUNBUFFERED": "1"},
              "balance_baseline_sha256": hashlib.sha256(baseline).hexdigest(),
              "check": args.check, "probe_sha256": probe_digest, "fixture_files_before": fixtures,
              "original_frozen_baseline_sha256": freeze["balance_baseline_sha256"],
              "approved_baseline_override": args.approved_baseline_sha256}
    def save():
        status_path.write_text(json.dumps(status, indent=2, sort_keys=True) + "\n")
    def frozen():
        current = identity()
        return (current["commit"] == source["commit"] and current["source_sha256"] == args.source_sha256
                and (REPO / "fs_bot/tools/balance_baseline.json").read_bytes() == baseline
                and fixture_identity() == fixtures
                and (probe_digest is None or hashlib.sha256((ROOT / "rule_probes.py").read_bytes()).hexdigest() == probe_digest))
    save()
    started = time.monotonic()
    with output_path.open("x") as output:
        process = subprocess.Popen(argv, cwd=REPO,
                    env=dict(os.environ, PYTHONHASHSEED="0", PYTHONUNBUFFERED="1"),
                    stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        status["pid"] = process.pid
        save()
        try:
            while True:
                try:
                    status["exit_code"] = process.wait(timeout=15)
                    break
                except subprocess.TimeoutExpired:
                    if not frozen():
                        status["source_changed"] = True
                        os.killpg(process.pid, signal.SIGTERM)
                        try:
                            status["exit_code"] = process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid, signal.SIGKILL)
                            status["exit_code"] = process.wait()
                        break
        except KeyboardInterrupt:
            os.killpg(process.pid, signal.SIGTERM)
            status["exit_code"] = process.wait()
            status["interrupted"] = True
    status.update(source_after=identity(), fixture_files_after=fixture_identity(), finished_utc=utc(), elapsed_seconds=time.monotonic() - started)
    status["source_changed"] = status["source_changed"] or not frozen()
    status["runner_exit_code"] = 125 if status["source_changed"] else status["exit_code"]
    if args.check == "probes" and status["exit_code"] == 0:
        try:
            data = json.loads(output_path.read_text())
            status["probe_results_passed"] = (
                all(data[k]["actual"] == data[k]["expected"] for k in (
                    "belgic_successor_most_own", "human_successor_destination", "interlude_restores_ambiorix"))
                and data["human_successor_destination"]["requests"] == ["spring_leader"]
                and set(data["roman_ties"]["distinct"]) == {"Provincia", "Sequani"})
        except (KeyError, TypeError, ValueError) as exc:
            status["probe_results_passed"] = False
            status["probe_parse_error"] = repr(exc)
        if not status["probe_results_passed"] and status["runner_exit_code"] == 0:
            status["runner_exit_code"] = 1
    save()
    print(json.dumps(status, indent=2, sort_keys=True), flush=True)
    return status["runner_exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
