# Dynamic Colony geography repair

The failing case is Ariovistus seed 17 under CPython 3.10.22. Comparing hash
seeds 0 and 7 finds identical complete final state and RNG, and exactly one
different trajectory leaf: the operand order in a caught TypeError during
non-player Aedui's A45 unshaded Event. `ariovistus17-final-diffs.json` records
the comparison without reordering lists. `inspect_a45.py` captures the source
failure: `_default_entry` tries to sort Region names together with `None`.
Its candidates are Senones, Lingones and `Colony_Mandubii`.

The Colony's Region is stored on its runtime Tribe record. Four default
selection sites consulted only the printed `TRIBE_TO_REGION` map. The repair
uses the existing state-aware `_tribe_region` through one small helper for
candidate grouping, same-Region filtering, chosen-target selection and the
previous-Region tracker. It does not stringify the invalid value, suppress
the exception text, remove Colony choices or change seeded tie priorities.

Source basis: supplied Card Reference 71 expressly makes a Colony a Tribe;
A Card Reference A45 allows non-German Allies in its specified Celtic area;
A36 shaded removes any two Allies in its area. Chapter 8 §§8.2.3/8.3.1/8.3.4
govern own benefits, completion within the selected Region and equal seeded
choices. No new ruling is needed. A36's adjacent shared-helper omission is
confirmed by a real Colony plus ordinary Allied Tribe witness.

Five new regressions construct Colonies through Card71, use actual piece
operations and preserve state integrity. They cover A45 default/live
placement, A36 default/live removal, A45 remembering a first Colony Region,
and A45/A36 continuation at an already selected Colony Region without
unnecessary RNG advancement. The focused family reports 45 passing tests in
`colony-regressions-after-final.log`.

The five tests fail on the unchanged default module in the clean 2edf parent
worktree; its bytes are verified equal to task-base 3873ff9 before importing.
`colony-regressions-before-final.log` records that exact provenance. This is
an imported parent implementation check, not a claim that the new test file
existed in that historical commit.

Earlier attempts are retained: the first A45 fixture lacked a markers entry,
and the next could fill three ordinary Tribes without reaching its Colony.
The final fixture occupies other legal candidate Tribes with actual Allies,
leaving exactly three valid choices including the Colony; it fails on the
parent TypeError. These exploratory runs are not the accepted regression
evidence. Root owns full-suite, full fuzz/CI, documentation and publication
checks. No production file besides expansion_validation.py was edited here.
