# Batch 1 evidence for Sappers and Drought

The audited parent is `7313c9d96436b5602323d1299ba34a904bd6514d`.
The repair has Python source SHA-256
`f7c8439d35b50bb0c00488cf86e211fd94c2dfb4804b3585b8e638420777e452`.
The candidate game runs record the parent commit and mark the worktree
dirty. The source digest identifies the tested Python files.

Extract this archive outside the checkout. Set `FS_REPAIR_REPO` to the
absolute path to the Batch 1 checkout. Run these commands from the
extracted directory.

```sh
sha256sum -c SHA256SUMS
PYTHONPATH="$FS_REPAIR_REPO" python verify_batch.py > verified-summary.json
cmp summary.json verified-summary.json
```

The audit archive in the checkout contains the original 43-case probe
and its paired controls. Run that probe on the parent. The included
`test_twelfth_comparison_events.py` can also run on the parent to reproduce
the 37 behavior failures and four passing controls. The repair's focused
test run includes the new file, `test_drought_losses.py`,
`test_sappers_choices.py`, `test_eleventh_comparison_events.py`,
`test_event_eval.py`, and `test_card_effects.py`.

For a full paired replay, create a detached worktree of the parent,
set `FS_PARENT_REPO` to that checkout, and run the following.

```sh
PYTHONHASHSEED=0 python trace_events.py --repo "$FS_PARENT_REPO" --cases trace-cases.json --out parent-traces-final.jsonl
PYTHONHASHSEED=0 python trace_events.py --repo "$FS_REPAIR_REPO" --cases trace-cases.json --out repair-traces-final.jsonl
python compare_traces.py --audit "$FS_REPAIR_REPO/docs/reviews/comparison-audit-round12-2026-11-13-evidence.zip" > rerun-first-differences.json
cmp first-differences.json rerun-first-differences.json
```

The tracer records the existing execution path's input and output. Its
final board hash, winner, and number of resolved cards must match each
independent audited game record before a difference is counted. The
included first differing cards record both full action plans, the
matching entry fingerprints, and the change in Event effects.

From the Batch 1 checkout, the broader validation commands are

```sh
PYTHONHASHSEED=0 python -m pytest -q
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 3 --out /tmp/fs-batch12-1-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 71-74 --card-edition second-edition --workers 2 --out /tmp/fs-batch12-1-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 71-74 --card-edition second-edition --out /tmp/fs-batch12-1-fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 71-74 --card-edition second-edition --out /tmp/fs-batch12-1-fuzz987.json
cmp /tmp/fs-batch12-1-fuzz0.json /tmp/fs-batch12-1-fuzz987.json
python -m fs_bot.tools.balance_smoke --baseline /absolute/extracted/balance-baseline-parent.json --seeds 1-20
python -m fs_bot.tools.balance_smoke --seeds 1-20
python -m fs_bot.tools.balance_smoke --seeds 1-3 --band 0.40
```

Use a fresh output directory for each game run. The original balance
reference reports the expected 30-point Gallic War Aedui win-rate change.
The supplied validation summary checks the independent driver results
against the audited games and the reviewed balance reference.

The first pytest launcher rejected its cache path before collection.
The recorded runs disable that cache plugin. A preliminary replay pair
recorded two Python source hashes across a readability edit. The final
pair uses one source hash and matches byte for byte.
