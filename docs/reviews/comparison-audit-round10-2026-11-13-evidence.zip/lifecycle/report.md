# Tenth audit — lifecycle lane

Audited Falling Sky `ae238c6482a792dda98af4f1f9b11abf820a3964`. No production files changed. One new medium-severity group is confirmed. The fixture uses canonical piece helpers, public Quarters validation and phase execution, with clean census and structure checks before and after all nine cases.

## LC10-01 — Agreed adjacent Quarters into Provincia is rejected

Chapter 6 §6.3.3, lines 84–90, first allows Roman mobile pieces to relocate to adjacent undevastated Regions under Roman Control or an agreeing eligible faction's Control. It then allows a separate transfer from Supply Line Regions to Provincia. The first permission includes Provincia; it does not require the origin to have a Supply Line. Chapter 3 §3.2.1, lines 29–37, confirms German-controlled origins cannot participate in a base-game Supply Line.

The witness begins with a permanent Roman Fort and two Aedui Warbands in Provincia (Aedui Control), and a Roman Legion plus two German Warbands in adjacent Arverni (Germanic Control). Romans have 10 Resources. The other three player factions explicitly leave their pieces in place. The Aedui callback would agree to hosting the Roman Legion. There are no markers, capabilities or Leaders.

Expected: ask Aedui for Quarters agreement, then move the Legion directly into Provincia without a supply requirement or quartering charge. Actual: `validate_quarters_plan` and `quarters_phase` both reject with `Arverni has no agreed Supply Line to Provincia`, before any agreement request. The Legion remains at Arverni and Resources remain 10. Both state validators remain clean and the rejection restores board and RNG.

Cause: `fs_bot/engine/quarters.py:224–231` classifies every Roman move to Provincia as the later Provincia step. That bypasses the ordinary adjacent movement/host consent logic at lines 245–258. The fallback at lines 318–322 permits an adjacent unsupplied origin only when Provincia has Roman Control, omitting an eligible agreeing controller. The same restriction appears in `_provincia_options`, lines 365–376. Both supplied full-phase plans and per-faction plans pass through validation in `fs_bot/engine/winter.py:370–374,409–428`.

| Probe | Validation | Public phase outcome |
|---|---|---|
| Willing Aedui, adjacent Provincia, German-controlled origin | Rejects | Rejects before asking host; defect |
| Refusing Aedui, otherwise same Provincia fixture | Rejects | Same premature rejection; consent never considered |
| Roman-controlled Provincia, same German-controlled origin | Accepts | Legion reaches Provincia; Resources 10 |
| Willing Aedui, ordinary adjacent Sequani | Accepts conditionally | Asks Quarters agreement, moves Legion, pays 2 Resources |
| Refusing Aedui, ordinary adjacent Sequani | Accepts conditionally | Asks and rejects; board/RNG restored |
| Nonadjacent German-controlled Nervii to Provincia | Rejects | Correctly rejects absent Supply Line |
| Supplied Roman-controlled Arverni to Aedui Provincia | Accepts | Later Supply Line transfer succeeds |

Repair scope: keep adjacent and Supply Line movement permissions distinct, including host consent and the existing simultaneous adjacent-step control/cohort rules. Freeze supply only after adjacent moves. Preserve the nonadjacent/no-supply and host-refusal negative controls. The fix should cover validation, execution and live continuation choices without weakening the forbidden-host checks.

This is distinct from WS-F05's visibility choices, WS7-01's missing non-Roman NP planners and LC9-01's Roman NP arrival-payment overwrite. It affects core movement legality before any payment or NP decision. The evidence includes a lawful constructed phase position and an actual Pax setup whole-Winter pair, not a measured encounter frequency; frontend menus are not claimed.

## Whole-Winter entry-point confirmation

The added pair begins with actual `setup_scenario(Pax Gallica?, seed=11)`, retaining every original setup piece, Resource value and first-Winter special rule. Canonical helpers add one tracked Roman Legion and five German Warbands in Arverni, producing Germanic Control. Four available Aedui Warbands enter Provincia, outnumbering the original Roman Fort and two Auxilia. All factions choose no relocation except the Legion's adjacent move to Provincia, and the Aedui callback agrees.

Public `run_winter_round` reaches Quarters after the printed first-Winter Victory/Germans skips, then rejects the legal move with the same error before asking any question. The whole Winter rolls back, including `winter_count=0`, its one-shot rules and RNG. The control puts those same four Aedui Warbands in Veneti, leaving Roman Control at Provincia. It completes the entire Winter, records the Legion's relocation and increments `winter_count` to 1. Both before/after census and structural validators are clean. No test patches or artificial Victory bypasses are used.

## Comparison inspected

Actual comparator code at `lod-bot` revision `2991ea279062773548ec390a1da75f3e85381702` keeps year-end Supply and Leader Redeployment in separate functions (`lod_ai/util/year_end.py:1313–1335`). Its French Supply human choices encode `(action, destination)` and dispatch explicitly (`260–276`), while redeployment has its own candidate builder (`846–858`). The applicable engineering lesson is to preserve stage/permission in action dispatch when a destination can be reached under multiple rules. No LOD rule is used as Falling Sky authority.

## Other inspected boundaries and dispositions

- Reviewed first-Pax Winter skips, Harvest-box Legion release, Senate reset and Vercingetorix unlock; post-Interlude one-shot flags; Winter/Interlude finality; standard solo and paired-player victory selection; Senate Fallen return and Lost Eagle cleanup; Spring eligibility, marker and visibility reset. No additional new witness established.
- Reviewed base Germans Rally/March and Ariovistus Arverni Rally/March/Raid phase boundaries against supplied Chapters 6/A6. The German original-group movement and Rally per-Region limits are already covered by WS6 repairs. No new count asserted from that inspection.
- Rejected speculative forced-eligibility carryover: ordinary Event adjustment consumes the through-next-card grant, and no legal public path leaving a fresh grant across Winter was established.
- Rejected duplicate negative Roman Harvest as a new group: WS4-01 already repaired the Resource floor and explicitly leaves the positive-balance meaning of a negative award unresolved.
- Did not promote full preplanned-Quarters validation against German relocation/desertion as a separate defect: it lacks a completed legal witness and does not need to be counted to establish LC10-01.
- Excluded known Circumvallation persistence and Aedui subsidy timing limitations from new findings.

## Reproduce

```sh
/workspace/scratch/4aba5bd9b1ab/fs-bot/.venv/bin/python \
  /workspace/scratch/521fc7ecea8c/audit10/lifecycle/probe_lifecycle.py \
  --repo /workspace/scratch/521fc7ecea8c/falling-sky \
  --out /workspace/scratch/521fc7ecea8c/audit10/lifecycle/results.json
```

The script also supports `PYTHONPATH` instead of `--repo`. It emits JSON with exact plans, both public outcomes, agreement requests, piece/control summaries, board/RNG restoration checks and validators. It asserts the phase defect and six phase comparison controls, plus the whole-Winter failing/succeeding pair. Production repository remains clean at the audited revision.

## Raw hash-seed comparison

`results.hash0.json` and `results.hash987.json` preserve the raw callback requests, including Supply Line `context.region`; no normalization was applied. `results.json` is the hash-0 baseline. The successful whole-Winter control selects a different representative Aedui Region in that request under the two hash seeds. The full final encoded board plus RNG digest and separate RNG digest are identical for both whole-Winter cases. This does not establish that differing requests are harmless for durable sessions; the frontend lane independently investigates that consequence. Core LC10-01 outcomes and all nine assertions are unchanged. The original pre-digest output is preserved at `results/raw-before-digest.json`.
