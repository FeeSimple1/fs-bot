# Fifth comparison, Batch 1 validation

The final results use parent `9257837240f9cf78d39feb553a6419d73b708f6e`
with repaired Python source SHA-256
`b3e251be9d703fada9c38235f04e4f69b772cebb2d49def2bc2156090054b8c9`
across 592 files. `summary.json` records the accepted checks. The initial
full-suite run has a separate log and source identity in `initial-full-suite`.
It found a fixture that used the bot executor for a human Capability gift.

`final/paired-outcomes.json` includes both source identities and each final
board hash from the matched legacy and second-edition matrices. The parent
records come from the fourth repair Batch 4 and fifth audit archives. The
parent Python digest matches the audit commit. Each repaired bot record
passed checks for completed game, full ranking, inventory and structure,
errors and nonlegal diagnostics. The two mixed JSON files and stdout logs
match exactly. The balance log compares with the stored legacy baseline.

Run the following from the repaired repository checkout. Use new output
directories. `pytest-xdist` supplies the optional `-n 6` runner flag.

```sh
python -m pytest -q -n 6
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out new-bots-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 29-32 --card-edition second-edition --workers 2 --out new-bots-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 29-32 --card-edition second-edition --out new-fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 29-32 --card-edition second-edition --out new-fuzz987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
```

`test_fifth_comparison_events.py` contains the final 31 new cases. From the
parent checkout, run `PYTHONPATH=. python -m pytest -q /path/to/test_fifth_comparison_events.py`.
The archived parent run has 26 expected failures and five passing controls.
The repaired suite passes all 31. `final/recipient-effects.json` records
successful Ballistae and Winter Campaign gifts followed through their
production consumers using the fifth audit's legal fixtures.
