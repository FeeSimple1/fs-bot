"""Trace the adjustment boundary in naturally reached LC11-01 games."""

import argparse
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
from pathlib import Path
import sys


# Exactly the paired bot and mixed-seat games whose recorded results changed.
CASES = tuple(('legacy', seed, False) for seed in (1, 2, 3, 5, 6, 12, 17, 20)) + (
    ('second-edition', 58, False),
    ('second-edition', 59, True),
)


def digest(data):
    return hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()


def trace(case):
    from fs_bot import rules_consts as rc
    from fs_bot.engine import interlude
    from fs_bot.engine.interlude_reductions import ARVERNI_HALF, reduction_request
    from fs_bot.state.serialize import encode
    from fs_bot.tools.player_fuzz import play_game
    from fs_bot.tools.run_batch import play_one

    edition, seed, mixed = case
    scenario = rc.SCENARIO_GALLIC_WAR
    boundaries = []

    def snapshot(state):
        board = encode({key: value for key, value in state.items()
                        if key != 'decision_agent'})
        return dict(board=digest(board), rng=digest(board.pop('rng')),
                    board_without_rng=digest(board),
                    arverni=reduction_request(state, ARVERNI_HALF))

    adjust = interlude._adjust_arverni_forces

    def record(state):
        before = snapshot(state)
        result = adjust(state)
        boundaries.append(dict(before=before, after=snapshot(state), adjustment=result))
        return result

    interlude._adjust_arverni_forces = record
    try:
        if mixed:
            outcome = play_game(scenario, seed, card_edition=edition)
            assert outcome['game_completed'] and not outcome['findings'], outcome
        else:
            row = play_one((scenario, seed, edition))
            assert row['completed'], row
            fields = ('winner', 'cards', 'final_ranking', 'final_state_sha256')
            outcome = {key: row[key] for key in fields}
    finally:
        interlude._adjust_arverni_forces = adjust
    assert len(boundaries) == 1
    return dict(edition=edition, seed=seed, mixed=mixed, outcome=outcome, **boundaries[0])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--workers', type=int, default=2)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo.resolve()))
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        rows = list(pool.map(trace, CASES))
    print(json.dumps(rows, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
