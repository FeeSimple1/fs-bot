import contextlib,io,json,tempfile
from types import SimpleNamespace
from pathlib import Path
from fs_bot import rules_consts as rc
from fs_bot.tools import llm_seat
from fs_bot.state.serialize import load_game,decode
from fs_bot.board.pieces import count_pieces

with tempfile.TemporaryDirectory() as directory:
    args=SimpleNamespace(dir=directory,scenario=rc.SCENARIO_GREAT_REVOLT,seed=46,seat=rc.BELGAE)
    with contextlib.redirect_stdout(io.StringIO()):
        llm_seat.cmd_init(args)
        llm_seat.cmd_play(args)
    path=Path(directory)/'save.json'
    sent=False
    initial=None
    effect=None
    for i in range(40):
        state,meta,log=load_game(path,validate=True)
        pending=meta['assistant_session']['pending']
        assert pending
        request=decode(pending['request']);board=decode(pending['board'])
        if sent and count_pieces(board,rc.PROVINCIA,rc.ROMANS,rc.AUXILIA)==initial['auxilia']+6:
            effect={'auxilia':count_pieces(board,rc.PROVINCIA,rc.ROMANS,rc.AUXILIA),'window':request}
        if request['kind']=='turn':
            if sent:break
            assert state['current_card']==16 and request['options']==['limited_command','pass'],request
            initial={'current_card':state['current_card'],'id':pending['id'],'request':request,'auxilia':count_pieces(board,rc.PROVINCIA,rc.ROMANS,rc.AUXILIA)}
            response={'action':'limited_command','player_action':{'command':'Event','details':{'event_params':{'target_region':rc.PROVINCIA}}}}
            sent=True
        else:response={'use_default':True}
        with contextlib.redirect_stdout(io.StringIO()):
            code=llm_seat.cmd_submit(SimpleNamespace(dir=directory,decision_id=pending['id'],response=json.dumps(response)))
        assert code==0
    else:raise AssertionError('Did not finish accepted forbidden Event')
    recorded=next(entry for entry in log if entry.get('action')=='limited_command')
    assert recorded['card']==16 and recorded['player_action']['command']=='Event'
    assert effect is not None
    print(json.dumps({'case':'normal_init_play_submit_accepts_event_as_limited_command','seed':46,'initial':initial,'effect':effect,'recorded_action':recorded},default=str))
