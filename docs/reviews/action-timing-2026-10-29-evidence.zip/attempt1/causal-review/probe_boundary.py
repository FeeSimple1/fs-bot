"""Replay one stored equal-input boundary, observing choices without modifying rules."""
import argparse,contextlib,gzip,hashlib,io,json,os,sys
from pathlib import Path

def sha(v):return hashlib.sha256(json.dumps(v,sort_keys=True).encode()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--folder',type=Path,required=True);ap.add_argument('--side',choices=('parent','candidate'),required=True);args=ap.parse_args()
 assert os.environ.get('PYTHONHASHSEED')=='0';sys.path.insert(0,os.getcwd())
 from fs_bot.state.serialize import encode,decode
 from fs_bot.tools.validation_metadata import source_identity
 from fs_bot.cli.dispatcher import make_decision_func
 from fs_bot.engine.execute import execute_decision
 review=json.loads((args.folder/'semantic-review.json').read_text());first=review['first_mechanical_difference']
 assert first and first['input']['state_equal'] and first['input']['payload_equal']
 with gzip.open(args.folder/(args.side+'.json.gz'),'rt') as f:trace=json.load(f)
 assert source_identity()['source_sha256']==trace['source']['source_sha256']
 row=trace['checkpoints'][first['input']['ordinal']]; expected=trace['checkpoints'][first['ordinal']]
 st=decode(row['state_snapshot']);assert sha(encode(st))==row['state_sha256']
 calls=[]
 watched={'_rank_march_destinations','random_select','_build_loss_priority','_resolve_dispersion_rally','_check_dispersion_rally','choose_surus_action','_derive_surus','resolve_surus','_default_seize_rally','_seize_rally'}
 def profile(frame,event,arg):
  name=frame.f_code.co_name;file=frame.f_code.co_filename
  if event!='return' or not (('/fs_bot/' in file and name in watched) or (file.endswith('/random.py') and name in ('randint','choice','shuffle'))):return
  stack=[];caller=frame.f_back
  while caller:
   if '/fs_bot/' in caller.f_code.co_filename:stack.append(caller.f_code.co_filename.split('/fs_bot/')[-1]+':'+caller.f_code.co_name)
   caller=caller.f_back
  loc={k:encode(v) for k,v in frame.f_locals.items() if k in ('region','faction','defending_faction','attacking_faction','a','b','candidates','all_candidates','tier1','tier2','tier3','tier4','die','is_retreat')}
  calls.append({'function':name,'module':file.split('/fs_bot/')[-1] if '/fs_bot/' in file else 'random.py','locals':loc,'return':encode(arg),'stack':stack,
                'live_state':frame.f_locals.get('state') is st,'live_rng':frame.f_locals.get('self') is st['rng']})
 with contextlib.redirect_stdout(io.StringIO()):
  sys.setprofile(profile)
  try:
   if row['stage']=='before_decision':
    bot=make_decision_func({},stdin=io.StringIO(),stdout=io.StringIO(),pause=False)
    result=bot(st,row['faction'],decode(row['payload'])['options'],row['position'])
   else:result=execute_decision(st,row['faction'],decode(row['payload']))
  finally:sys.setprofile(None)
 after=encode({k:v for k,v in st.items() if k!='decision_agent'})
 report={'source':source_identity(),'scenario':trace['scenario'],'seed':trace['seed'],'input_ordinal':row['ordinal'],'input_state_sha256':row['state_sha256'],
   'expected_output_ordinal':expected['ordinal'],'output_state_sha256':sha(after),'output_state_matches_trace':sha(after)==expected['state_sha256'],
   'output_payload_matches_trace':encode(result)==expected.get('payload'),'calls':calls,'result':encode(result),
   'note':'Read-only profiler; executes original boundary once on restored detached input. No rule replacement, RNG substitution, or source changes.'}
 out=args.folder/(args.side+'.probe.json');assert not out.exists();out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 assert report['output_state_matches_trace'] and report['output_payload_matches_trace'], 'local replay differed from captured boundary'
 print(json.dumps({'case':[trace['scenario'],trace['seed']],'side':args.side,'calls':len(calls),'passed':True}))
if __name__=='__main__':main()
