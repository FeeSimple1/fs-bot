"""Capture original A37 seed3 decisions from the unmodified batch parent."""
import gzip
import json
from pathlib import Path
from fs_bot import rules_consts as rc
from fs_bot.engine import game_engine
from fs_bot.state.serialize import encode
from fs_bot.tools.error_census import play_game

DEST = Path('/workspace/scratch/534c265c65f4/fs-expansion-event-validation/fs_bot/tests/fixtures/a37_before_exp09')
DEST.mkdir(parents=True, exist_ok=True)
original = game_engine._maybe_execute
class Captured(Exception):
    pass

def capture(state, faction, decision, actions_taken):
    if state.get('current_card') == 'A37' and faction == rc.AEDUI and decision.get('action') == game_engine.ACTION_EVENT:
        scenario = state['scenario']
        record = {
            'source_commit': '8db858b14cd13856059d42db1ad3931e523b5ed4',
            'scenario': scenario, 'seed': 3, 'card': 'A37', 'faction': faction,
            'state': encode({k: v for k, v in state.items() if k != 'decision_agent'}),
            'decision': encode(decision),
        }
        path = DEST / ('ariovistus-3.json.gz' if scenario == rc.SCENARIO_ARIOVISTUS else 'the-gallic-war-3.json.gz')
        path.write_bytes(gzip.compress(json.dumps(record, sort_keys=True, separators=(',', ':')).encode(), mtime=0))
        raise Captured()
    return original(state, faction, decision, actions_taken)

game_engine._maybe_execute = capture
for scenario in (rc.SCENARIO_ARIOVISTUS, rc.SCENARIO_GALLIC_WAR):
    try:
        play_game(scenario, 3)
    except Captured:
        print('Captured:', scenario)
    else:
        raise AssertionError('Original Event decision not reached: ' + scenario)
