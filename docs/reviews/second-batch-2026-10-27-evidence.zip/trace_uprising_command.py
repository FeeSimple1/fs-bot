"""Targeted A66 pre/post placement and actual scoped Command observation."""
import argparse
import gzip
import json
import os
from pathlib import Path
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--scenario", required=True)
parser.add_argument("--seed", type=int, required=True)
parser.add_argument("--source-sha256", required=True)
parser.add_argument("--expected-final-sha256",
                    help="prior audited final hash for a failure reproduction; omit for a new repair localization")
parser.add_argument("--out", type=Path, required=True)
args = parser.parse_args()
assert os.environ.get("PYTHONHASHSEED") == "0"
assert not args.out.exists()
sys.path.insert(0, os.getcwd())
from fs_bot.tools.run_batch import play_one
from fs_bot.tools.validation_metadata import source_identity
from fs_bot.state.serialize import encode
from fs_bot.engine import execute as ex

source = source_identity()
assert source["source_sha256"] == args.source_sha256
records = []
active = False
original_resolve, original_command, original_constrain = ex._resolve_winter_uprising, ex._resolve_free_command, ex._constrain_bot_action


def snapshot(state):
    return encode({k:v for k,v in state.items() if k != "decision_agent"})


def resolve(state, *a, **kw):
    global active
    active = True
    record = {"stage": "uprising", "before": snapshot(state), "kwargs": encode(kw)}
    records.append(record)
    try:
        result = original_resolve(state, *a, **kw)
        record.update(result=encode(result), after=snapshot(state))
        return result
    finally:
        active = False


def command(state, faction, *a, **kw):
    if not active:
        return original_command(state, faction, *a, **kw)
    record = {"stage": "free_command_after_placement", "faction": faction,
              "args": encode(a), "kwargs": encode(kw), "before": snapshot(state)}
    records.append(record)
    result = original_command(state, faction, *a, **kw)
    record.update(result=encode(result), after=snapshot(state))
    return result


def constrain(action, allowed, **kw):
    if not active:
        return original_constrain(action, allowed, **kw)
    record = {"stage": "constrain_actual_plan", "input_action": encode(action),
              "allowed_regions": sorted(allowed), "faction": kw.get("faction"),
              "planning_state": snapshot(kw["state"]) if kw.get("state") is not None else None}
    records.append(record)
    result = original_constrain(action, allowed, **kw)
    record["constrained_action"] = encode(result)
    return result


ex._resolve_winter_uprising, ex._resolve_free_command, ex._constrain_bot_action = resolve, command, constrain
game = play_one((args.scenario, args.seed, "legacy"))
after = source_identity()
matched = (game.get("final_state_sha256") == args.expected_final_sha256
           if args.expected_final_sha256 else None)
result = {"scope": "targeted failure localization; not an accepted matrix", "source": source,
          "source_after": after, "source_unchanged": source["source_sha256"] == after["source_sha256"],
          "expected_final_state_sha256": args.expected_final_sha256, "final_hash_matches_audited_record": matched,
          "record": game, "uprising_observations": records}
args.out.parent.mkdir(parents=True, exist_ok=True)
with gzip.open(args.out, "xt") as stream:
    json.dump(result, stream, sort_keys=True)
summary = {"path": str(args.out), "source": source, "source_unchanged": result["source_unchanged"],
           "matched": matched, "game_completed": game["game_completed"], "audited": game["completed"],
           "winner": game.get("winner"), "cards": game["cards"], "final_state_sha256": game.get("final_state_sha256"),
           "nonlegal": [d for d in game["diagnostics"] if d["severity"] != "legal-decline"],
           "observed_constraints": [{k:v for k,v in r.items() if k != "planning_state"}
                                     for r in records if r["stage"] == "constrain_actual_plan"]}
print(json.dumps(summary, indent=2))
accepted = matched if args.expected_final_sha256 else game["completed"]
raise SystemExit(0 if accepted and result["source_unchanged"] else 1)
