# Independent review: LC9-01 Roman Quarters arrival payments

**Verdict: confirmed, medium priority.** This is a distinct surviving accounting defect in the Roman non-player Quarters planner. It is not a new game-rule interpretation or a failure of the physical inventory validator.

Reviewed Falling Sky commit `f4c8372c396981c0a31dc6f4545e67f8c6f2e981`. Inspected the complete witness `../lifecycle/probe_lifecycle.py`, the governing supplied rules, the live planner and consumer, and earlier audit records. Independently reran the witness under hash seeds 0 and 987. Both exit statuses were zero; `lifecycle-hash0/results.json` and `lifecycle-hash987/results.json` match byte-for-byte. Logs and saved pre-action states are retained beside this review. `lifecycle-independent-review.json` records a compact outcome check.

## Source and code check

- `Reference Documents/Chapter 8:974–981` requires the non-player Romans to pay for all pieces necessary to avoid removal rolls, after relocation and with the stated priority order. This supplies the expected behavior directly.
- `Reference Documents/Chapter 6:84–98` permits the adjacent relocation and applies payment to the actual final Legion/Auxilia pieces outside Provincia. A Region without a Roman Ally costs two Resources per piece; no Fort or Ally in the witness gives free stays.
- `QUESTIONS.md:966–1042` records Q12's earlier wiring repair and the owner's adopted pay-all-affordable/no-reserve decision. The new finding neither reopens routing ambiguity nor alters that decision.
- `fs_bot/bots/roman_bot.py:1873–1925` processes Regions from the original board. It adds evacuated arrivals into `remaining[hop]` at lines 1921–1922, then overwrites that same Region's entry at line 1925 when the destination is encountered later. The pay payload at lines 1939–1947 consequently contains only the original destination stack.
- `fs_bot/engine/winter.py:395–436` proves ordinary non-player `quarters_phase(state)` selects this planner, accepts and executes its relocation, and forwards the understated payment count. `fs_bot/engine/quarters.py:496–568` allocates the unrequested remainder to rolls; it cannot infer that the non-player planner meant to pay more.

## Fixture and controls

The witness builds a sparse canonical position in each of all five supported scenarios, with seed 1, twenty Roman Resources, two Auxilia in Devastated Morini, one Auxilia in un-Devastated Roman-controlled Nervii, and the permanent Provincia Fort. Canonical Belgic Warband placements block the Supply routes. Both origins are explicitly checked as lacking a Supply Line, so Provincia evacuation cannot supersede the reported case. All physical counters are placed with production piece helpers. Other factions have no relevant Quarters relocation. The fixture is controlled legal state, not an untouched scenario or a measured natural encounter.

The public automatic phase moves both Auxilia to Nervii, then pays only two Resources, rolls twice (2 and 5), loses one Auxilia, and leaves eighteen Resources. The source requires paying six Resources for all three Auxilia, preserving all three and leaving fourteen Resources.

The same public phase with the same derived relocation and only its payment count changed to three gives exactly that correct result. Reversing the direction so the destination is processed first preserves the arrivals in the automatic planner and correctly pays six. A stationary three-Auxilia stack also automatically pays six. The reversed movement with only two Resources legally pays for one and rolls for two; this confirms the expected correction must retain real affordability limits. Each case's initial and final physical census and structural checks are empty. All five saved initial states load with validation and exactly reproduce their direct execution results.

The direction and stationary controls isolate this to arrivals overwritten during planning, not a general Quarters cost calculation, random casualty choice, or unavailable funds. No production function is monkeypatched, and no production source changes are made.

## Prior-finding distinction and repair boundary

Q12 dealt with an entirely unconsumed Roman Quarters plan. Original WS-F05 concerned human visibility selection. LC7-01 concerned unexecuted non-Roman NPC evacuation/consolidation. The round 8 lifecycle findings concerned final-Winter counting and solo victory eligibility. None reports or fixes this Roman arrival-payment overwrite.

A repair should derive payment demand from the validated projected final board or separately accumulate original residents and arrivals without overwrite. Preserve free-stay Auxilia, all physical ownership/visibility, legal Provincia movement and agreements, actual Resource caps, payment priority, and human authored payment choices. The witness confirms Auxilia accounting; broader Legion, multi-origin, Fort, Ally, and agreement interactions should be covered during the repair rather than claimed proven here. No encounter frequency or win-rate impact is established by these constructed positions.
