# EXP-04 handoff — Harudes and Bellovaci human grants

Branch: `repair/event-cohorts-2026-11-02` in `fs-human-event-cohorts`.
Base: `d3241e7ad0ed5e11a88d114958e886221dd36db9`.
Final commit: `e0a1667e406a42da3d00c073c0908fbca4ef0780`.

## Scope and authority

Closes inventory EXP-04: A29 shaded Raid targets/counts and A69 shaded Ambush
defender are now explicit Event-executor choices in mechanics, CLI and durable
sessions. New implementation lives in `fs_bot/cards/harudes_bellovaci.py` and
`fs_bot/cli/harudes_bellovaci.py`; `execute.py` retains small A29/A69 delegates.

Sources checked (all supplied, read-only):

- `Reference Documents/Ariovistus/A Card Reference`, A29 shaded:
  “Place 4 German Warbands & 1 Settlement among Regions adjacent to Germania.
  They free Raid.”
- Same file, A69 shaded: “If Bellovaci a Belgic Ally, place 6 Belgic Warbands
  there. They Ambush causing 1 Loss each.”
- `Reference Documents/Chapter 5`, §5.1: “Unless otherwise specified, the
  executing Faction makes all selections allowed for in implementing the text”.
  This controls Raid count/target and Ambush defender, even when the physical
  Germans/Belgae have another player. §5.1.1 preserves ordinary rules, and
  §5.1.3 requires the possible follow-on action. §5.4 makes explicitly granted
  Ambush include its Battle and waives cost/Eligibility effects.
- `Reference Documents/Chapter 3`, §3.3.3: one or two Hidden Warbands per
  selected Region, gain outside Devastation or steal from an eligible enemy.
  Card 8 shaded's owning-faction exception still increases the intrinsic limit
  to three without creating extra placed counters.
- `Reference Documents/Ariovistus/Chapter A3`, A3.4.3: German Raid follows
  Gallic Raid; actual Warbands Raiding with Ariovistus may simultaneously
  free Intimidate. This optional offensive selection is part of A29's directed
  Raid and follows its executor, while counters, Resource beneficiary and
  removal credit remain German. A4.6.2 governs its actual targets/limits.
- `Reference Documents/Chapter 4`, §§4.3.3/4.5.3: normal Hidden comparison,
  Leader proximity and Belgic Caesar exception remain in force.
- `Reference Documents/Ariovistus/Chapter A1`, A1.4: Roman/Aedui defensive
  cooperation can enable or block Ambush. This remains a legal reaction even
  when a previously valid A69 Ambush is canceled by that new agreement.

All Reference Documents were inventoried. CLAUDE.md, README, documentation map,
the API contract and adopted PR-01–PR-09 register were consulted. No protected
source or canonical constant changed, and no new provisional ruling is used.

## Public request/response contract

Both new requests have `kind: "free_action"`, `allow_decline: false` and
`free: true`. They consult the **executing Faction**. Their `acting_faction`
is engine-owned context and cannot be overridden in the response.

### `harudes_raid`

Request includes `card_id: "A29"`, `acting_faction: Germans`, surviving
`cohort` entries, and `regions` keyed by Region. Each Region supplies
`max_raiders`, `can_gain` and its legal stealing `targets`.

Response example:

```json
{"raid_actions":[{"region":"Treveri","target_faction":null}]}
```

There is exactly one list entry per selected Warband. `null` means gain a
Resource; a faction value means steal. Repeated Region entries supply its
count. The response may select fewer than the maximum and choose any legal
stealing target, including one disfavored by the NPC policy. It must select
at least one action. Extra fields, invented factions/Regions, count overflow,
unavailable Resources, protected stealing targets and Devastated gain are
rejected before live mutation. Validation executes the shared cohort Raid on
an isolated board/RNG without a live callback.

Only the actual placed survivors can Raid. The existing precise ledger is
read even when empty after reclamation, then transferred into the existing
scoped physical-force executor. A removed placed counter cannot be replaced
by an unrelated resident. The Settlement contributes no Raider.

The later `raid_intimidate` request retains its existing response schema,
but for A29 it consults the Event executor. If that differs from Germans, its
request now adds `acting_faction: Germans`. This narrow temporary routing
does not remap defender, casualty, consent or voluntary-removal authority.

### `bellovaci_ambush`

Request includes `card_id: "A69"`, `acting_faction: Belgae`, fixed `region`,
legal `defenders`, `placed_warbands`, `default_available` and the internal
`validate_default_response: true` guard.

```json
{"defender":"Aedui"}
```

The human can choose any legal listed defender, regardless of its piece count.
They cannot submit another Region, attacker, SA, damage or other effect.
Ordinary resident participants retain ordinary Losses; **only surviving new
Warbands gain the one-Loss bonus**. Existing loss-cohort tracking remains in
the Battle implementation and is not replaced with a blanket Warband bonus.

The grant now also rechecks its requirements after later voluntary-removal
windows at the Battle boundary. If only one new Hidden Warband remains against
two Hidden defenders, it skips the impossible Ambush rather than downgrading
to an ordinary Battle. If all placed Warbands were removed, residents cannot
inherit the grant. Earlier placements and chosen removals remain as partial
Event execution (§5.1.3). An otherwise legal Ambush canceled by a new
Diviciacus defense agreement retains the authoritative A1.4 exception.

A legal Ambush may inflict zero Losses (for example one new Warband against a
Fort). Humans may select that legal target. The historical NPC/default policy
continues to filter to positive-Loss targets, then select the largest enemy
force. If this policy has no action but a legal human target remains, explicit
`use_default` is rejected and the durable request stays pending. The CLI omits
an unavailable default choice. The ordinary raw callback's `None` still
retains its documented NPC fallback/no-effect contract.

### Shared behavior

`{"use_default":true}` is explicit delegation, not missing human input.
Both follow-ons are mandatory when offered, so `decline` is invalid. With no
surviving cohort or legal action there is no artificial human prompt.
Missing/invalid durable input leaves the same request and ID pending. The
whole Event rolls back on a pending or invalid choice while retaining
accepted journal entries for replay. No save-format version changed.

The common terminal menus preserve numeric choices and `board`/`b`; the
existing reactive wrapper displays current/upcoming cards and changes.

## Integration notes

- `engine/free_actions.py`: two namespaced subtype validators and A69 default
  validation before the generic sentinel return.
- `cli/free_actions.py`: the same two subtype dispatches.
- `engine/execute.py`: A29/A69 call sites and resolver bodies, plus the trusted
  optional `_require_ambush` Battle keyword used only by A69. The keyword
  gates late timing rechecks; it is not a client-submittable plan field.
- `engine/raid_intimidate.py`: only the A29-scoped offensive chooser override.
- `tools/seat_session.py`: six-line `validate_default_response` gate. The
  battles agent has the identical functional hook; keep it once on integration.
- New tests: `test_harudes_bellovaci_choices.py`, 44 tests. Existing nested
  Event, action-window and Raid Intimidate tests remain unchanged.

Root owns project/API/current-status documentation and progress-register edits.
This handoff provides the exact new contract for those updates.

## Validation and evidence

- `cohorts-focused-failed-01.log`: preserved first fixture failure; the test
  incorrectly put a Devastated marker in a space-local container. The canonical
  `state["markers"]` fixture was corrected; production code was not implicated.
- `cohorts-focused-02.log`: 36 passing tests at that intermediate source.
- `cohorts-focused-03.log`: 89 passing tests, including 38 new tests plus the
  pre-existing cohort/Raid suites, before the final durability extension.
- `cohorts-focused-04.log`: intermediate focused set, **90 passed in 0.54s**.
- `cohorts-focused-05.log` / `-06.log`: preserved Diviciacus regression fixture
  failures. First the fixture left Roman/Aedui seats under NPC rules instead
  of requesting human cooperation; then its assertion counted a separate
  Retreat permission request together with Diviciacus agreements. Correcting
  the fixture/assertion demonstrated the retained A1.4 exception.
- `cohorts-focused-07.log`: final expanded focused set, **119 passed in 0.64s**.
- `cohorts-late-ambush-prefixed-witness.log`: pre-fix behavior reproduced with
  only the new trusted guard disabled. With 6→1 placed Warbands against two
  Hidden Romans it performs ordinary Battle despite an Ambush error; with all
  six placed Warbands removed it lets four residents inherit the Ambush.
  Both cases fail the new source-derived regression without the guard.
- `cohorts-full-01.log`: intermediate **6316 passed in 113.88s**. Superseded by
  A69 zero-Loss/default validation and additional tests; not final-source proof.
- `cohorts-full-02.log`: incomplete, stopped at 82% without a pytest summary
  despite the execution tool reporting zero. Not counted as successful proof.
- `cohorts-full-03.log` and `.xml`: **6319 passed in 100.72s**; JUnit confirms
  6319 testcases, zero failures/errors/skips. A subsequent trailing blank-line
  cleanup in the new test file is the only source difference from that run.
- `cohorts-full-04.log` and `.xml`: full rerun after that whitespace cleanup;
  **6319 passed in 120.62s**. Superseded by the late required-Ambush repair.
- `cohorts-full-05.log` and `.xml`: final full suite including that repair;
  **6324 passed in 108.16s**. JUnit independently confirms 6324 testcase
  entries, zero failures, zero errors and zero skips. Command:
  `/workspace/scratch/534c265c65f4/fs-test-venv/bin/python -m pytest -q -n2 --junitxml=../human-event-grants-2026-11-02/cohorts-full-05.xml`.

Focused coverage includes executor distinct from the physical faction,
non-player Roman executor with human Germans, nonpriority target/smaller Raid,
intrinsic Intimidate authority/credit, fort and Devastation limits, Card 8's
exception, partial/all cohort reclamation before the grant, A69 resident
ordinary Losses, Caesar Counterattack casualties to the physical Belgic owner,
post-selection removals invalidating Ambush or emptying the placed cohort,
valid surviving-cohort controls and the legal Diviciacus cancellation,
spoofed grants, whole-Event rollback, board/EOF terminal behavior, accepted
choices surviving pending/save/load, and exact replay. The A29 durable test
saves again with intrinsic Intimidate pending after its Raid was accepted.

Independent read-only review by the Event-grant review agent found no remaining
defect in scoped targeting, grant spoofing, ledger handoff, preview/RNG
separation or default handling. It prompted the corrected zero-Loss human vs
NPC distinction before final validation. The reviewer also approved the final
required-Ambush guard: its boundary precedes defense and Battle execution.
Later retreat-choice/attack windows occur after Battle begins; they retain
the established Ambush status while surviving-cohort Losses remain live.

Final commit is one logical commit directly on the stated base. No push was
made. `git diff --check HEAD^ HEAD` is clean; protected sources/constants have
no changes. An earlier local candidate hash (`83034a4`) was amended and must
not be used for integration or final-source validation.

## Boundaries

This closes the two scoped EXP-04 human grant omissions. It does not claim a
new audit of all placement collectors, all capability interactions, or all
Events. Existing source-derived Ambush/Raid mechanics and precise cohort
tracking remain the implementation underneath these choices. The root's
integrated full suite, replay/census/balance checks still need to validate the
combined batch. No source research outside Reference Documents was used.

