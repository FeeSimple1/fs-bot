"""Read-only tenth-audit bot witnesses; production is imported, never patched."""
import argparse
import copy
import hashlib
import json
import sys

p = argparse.ArgumentParser()
p.add_argument('--repo', required=True)
args = p.parse_args()
sys.path.insert(0, args.repo)

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, count_pieces_by_state, place_piece
from fs_bot.bots.arverni_bot import _check_devastate, _determine_march_sa
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.cli.dispatcher import _translate_bot_action
from fs_bot.commands.sa_devastate import devastate_region, validate_devastate_region
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND, ACTION_COMMAND_SA, get_first_eligible_options
from fs_bot.state.serialize import encode
from fs_bot.state.state_schema import build_initial_state, check_structural_integrity, validate_state
from fs_bot.tools.seat_session import board_copy


def clean(s):
    answer = {'census': validate_state(s), 'structure': check_structural_integrity(s)}
    assert answer == {'census': [], 'structure': []}, answer
    return answer


def digest(s):
    return hashlib.sha256(json.dumps(encode(board_copy(s)), sort_keys=True).encode()).hexdigest()


def position(resources=4):
    s = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=6)
    s['non_player_factions'] = {rc.ROMANS, rc.ARVERNI, rc.AEDUI, rc.BELGAE}
    s['can_play_event'] = False
    s['resources'][rc.ARVERNI] = resources
    place_piece(s, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    return s


def execute(s, *, authored_sa=None, command_only=False):
    pre = clean(s)
    before_plan = digest(s)
    action = dispatch_bot_turn(s, rc.ARVERNI)
    immutable = digest(s) == before_plan
    assert immutable
    original = copy.deepcopy(action)
    if authored_sa:
        action['sa'] = authored_sa
        action['sa_regions'] = [rc.CARNUTES]
    action_type = (ACTION_COMMAND if command_only else
                   _translate_bot_action(action, get_first_eligible_options()))
    result = execute_decision(s, rc.ARVERNI, {'action': action_type, 'bot_action': action})
    assert result['executed'] and not result.get('errors'), result
    assert not (result.get('sa_execution') or {}).get('errors'), result
    return {'integrity_before': pre, 'integrity_after': clean(s),
            'planner_board_and_rng_unchanged': immutable,
            'dispatched_action': original, 'executed_action': action,
            'action_type': action_type, 'execution': result}


def march(name, *, authored_sa=None, command_only=False, resources=4, enemy=True):
    s = position(resources)
    place_piece(s, rc.MANDUBII, rc.ARVERNI, rc.LEADER, leader_name=rc.VERCINGETORIX)
    place_piece(s, rc.MANDUBII, rc.ARVERNI, rc.WARBAND, 9)
    if enemy:
        place_piece(s, rc.CARNUTES, rc.ROMANS, rc.AUXILIA)
    before = _determine_march_sa(s, s['scenario'])
    out = execute(s, authored_sa=authored_sa, command_only=command_only)
    assert out['dispatched_action']['command'] == rc.CMD_MARCH, out
    assert out['dispatched_action']['details']['march_plan']['type'] == 'March (spread)'
    out.update(name=name, before_choice=before, after_choice=_determine_march_sa(s, s['scenario']),
               resources=s['resources'][rc.ARVERNI],
               roman_auxilia_carnutes=count_pieces(s, rc.CARNUTES, rc.ROMANS, rc.AUXILIA),
               arverni_hidden_carnutes=count_pieces_by_state(s, rc.CARNUTES, rc.ARVERNI, rc.WARBAND, rc.HIDDEN))
    if name == 'march_missing_live_entreat':
        assert out['action_type'] == ACTION_COMMAND
        assert out['before_choice'] == ('No SA', [])
        assert out['after_choice'] == (rc.SA_ENTREAT, [rc.CARNUTES])
        assert out['roman_auxilia_carnutes'] == 1 and out['resources'] == 3
        assert 'sa_execution' not in out['execution']
    if authored_sa and not command_only:
        assert out['execution']['sa_execution']['executed']
        assert out['action_type'] == ACTION_COMMAND_SA
        assert out['roman_auxilia_carnutes'] == 0 and out['resources'] == 2
    if command_only:
        assert out['roman_auxilia_carnutes'] == 1
        assert 'sa_execution' not in out['execution']
    if resources == 1:
        assert out['resources'] == 0 and out['after_choice'] == ('No SA', [])
    if not enemy:
        assert out['after_choice'] == ('No SA', [])
    return out


def repeat(name, *, remove_marker=False, command_only=False, out_of_range=False):
    s = position(10)
    place_piece(s, rc.ARVERNI_REGION, rc.ARVERNI, rc.LEADER, leader_name=rc.VERCINGETORIX)
    place_piece(s, rc.BITURIGES, rc.ARVERNI, rc.WARBAND, 8, piece_state=rc.REVEALED)
    place_piece(s, rc.BITURIGES, rc.ROMANS, rc.LEGION, 6, from_legions_track=True)
    setup_integrity = clean(s)
    assert validate_devastate_region(s, rc.BITURIGES)[0]
    # Canonical prior legal use creates the marker and removes the exact quotas.
    previous = devastate_region(s, rc.BITURIGES)
    assert previous['devastated_placed']
    assert count_pieces(s, rc.BITURIGES, rc.ARVERNI, rc.WARBAND) == 6
    assert count_pieces(s, rc.BITURIGES, rc.ROMANS, rc.LEGION) == 4
    after_previous_integrity = clean(s)
    if remove_marker:
        del s['markers'][rc.BITURIGES][rc.MARKER_DEVASTATED]
    if out_of_range:
        from fs_bot.board.pieces import move_piece
        move_piece(s, rc.ARVERNI_REGION, rc.VENETI, rc.ARVERNI, rc.LEADER)
    legal_before = validate_devastate_region(s, rc.BITURIGES)
    bot_before = _check_devastate(s, s['scenario'])
    out = execute(s, command_only=command_only)
    out.update(name=name, setup_integrity=setup_integrity, previous_legal_devastate=previous,
               after_previous_integrity=after_previous_integrity,
               canonical_region_validation_before=legal_before, bot_targets_before=bot_before,
               arverni_warbands=count_pieces(s, rc.BITURIGES, rc.ARVERNI, rc.WARBAND),
               roman_legions=count_pieces(s, rc.BITURIGES, rc.ROMANS, rc.LEGION),
               fallen_legions=s['fallen_legions'])
    assert out['dispatched_action']['command'] == rc.CMD_RALLY
    if name == 'repeat_devastate_omitted':
        assert legal_before == (True, '') and bot_before == []
        assert out['execution']['sa_execution']['declined_no_effect']
        assert (out['arverni_warbands'], out['roman_legions']) == (6, 4)
        assert validate_devastate_region(s, rc.BITURIGES)[0]
        public = copy.deepcopy(s)
        public['non_player_factions'].remove(rc.ARVERNI)
        public_before = clean(public)
        authored = {'command': rc.CMD_RAID, 'sa': rc.SA_DEVASTATE,
                    'sa_timing': 'after', 'sa_regions': [rc.BITURIGES],
                    'details': {'raid_plan': [{'region': rc.ARVERNI_REGION, 'target': None}]}}
        public_result = execute_decision(public, rc.ARVERNI,
                                         {'action': ACTION_COMMAND_SA, 'player_action': authored})
        assert public_result['executed'] and not public_result.get('errors'), public_result
        assert public_result['sa_execution']['executed'], public_result
        assert not public_result['sa_execution'].get('errors'), public_result
        assert (count_pieces(public, rc.BITURIGES, rc.ARVERNI, rc.WARBAND),
                count_pieces(public, rc.BITURIGES, rc.ROMANS, rc.LEGION)) == (5, 3)
        out['public_authored_repeat_control'] = {
            'action': authored, 'execution': public_result,
            'integrity_before': public_before, 'integrity_after': clean(public),
            'arverni_warbands': 5, 'roman_legions': 3,
            'devastated_marker': public['markers'][rc.BITURIGES][rc.MARKER_DEVASTATED]}
        legal = devastate_region(s, rc.BITURIGES)
        assert not legal['devastated_placed']
        assert (count_pieces(s, rc.BITURIGES, rc.ARVERNI, rc.WARBAND),
                count_pieces(s, rc.BITURIGES, rc.ROMANS, rc.LEGION)) == (5, 3)
        out['canonical_repeat_control'] = legal
        out['canonical_repeat_integrity'] = clean(s)
    if remove_marker and not command_only:
        assert bot_before == [rc.BITURIGES]
        assert out['execution']['sa_execution']['executed']
        assert (out['arverni_warbands'], out['roman_legions']) == (5, 3)
    if command_only or out_of_range:
        assert (out['arverni_warbands'], out['roman_legions']) == (6, 4)
    if out_of_range:
        assert not legal_before[0] and bot_before == []
    return out


results = [
    march('march_missing_live_entreat'),
    march('march_legal_authored_after_entreat', authored_sa=rc.SA_ENTREAT),
    march('march_command_only_control', command_only=True),
    march('march_unaffordable_entreat_control', resources=1),
    march('march_no_target_control', enemy=False),
    repeat('repeat_devastate_omitted'),
    repeat('repeat_no_marker_control', remove_marker=True),
    repeat('repeat_command_only_control', remove_marker=True, command_only=True),
    repeat('repeat_out_of_range_control', out_of_range=True),
]
print(json.dumps({'cases': results, 'case_count': len(results)}, sort_keys=True, indent=2))
