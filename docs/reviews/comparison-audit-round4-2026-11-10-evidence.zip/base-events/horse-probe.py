import json
from fs_bot import rules_consts as rc
from fs_bot.state.setup import setup_scenario
from fs_bot.board.pieces import place_piece,count_pieces
from fs_bot.state.state_schema import validate_state,check_structural_integrity
from fs_bot.engine.execute import execute_decision
from fs_bot.tools.seat_session import validate_response
from fs_bot.engine.moves import validate_player_action
out=[]
for actor,params in [(rc.BELGAE,{}),(rc.BELGAE,{'faction':rc.AEDUI}),(rc.ROMANS,{'faction':rc.AEDUI})]:
 s=setup_scenario(rc.SCENARIO_GREAT_REVOLT,seed=4);s['current_card']=59;s['non_player_factions']=set();s['card_edition']='original'
 place_piece(s,rc.PICTONES,rc.AEDUI,rc.WARBAND,4);place_piece(s,rc.PICTONES,rc.GERMANS,rc.WARBAND,8)
 d={'action':'event','player_action':{'command':'Event','details':{'card_id':59,'text_preference':rc.EVENT_SHADED,'event_params':params}}}
 validate_response(s,{'kind':'turn','faction':actor,'options':['event']},d)
 ok,info=validate_player_action(s,actor,d['player_action']);assert ok,info
 event=execute_decision(s,actor,d)
 d={'action':'command','player_action':{'command':rc.CMD_BATTLE,'details':{'battle_plan':[{'region':rc.PICTONES,'target':rc.GERMANS}]}}}
 result=execute_decision(s,rc.AEDUI,d)
 out.append({'actor':actor,'params':params,'event':event,'owner':s['capability_owners'].get(59),'battle':result,'germans_remaining':count_pieces(s,rc.PICTONES,rc.GERMANS,rc.WARBAND),'census':validate_state(s),'structure':check_structural_integrity(s)})
print(json.dumps(out,indent=2,default=str))
