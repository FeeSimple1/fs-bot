"""Same public-scale position against parent checkout and accepted PR11 code."""
import json
from random import Random

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, find_leader, place_piece
from fs_bot.state.state_schema import build_initial_state, validate_state


class FixedRemovals(Random):
    def randint(self, low, high):
        return low


state = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=67)
state.update(current_card=67, next_card=3, executing_faction=rc.ARVERNI,
             non_player_factions={rc.ROMANS, rc.ARVERNI, rc.AEDUI, rc.BELGAE},
             rng=FixedRemovals(67))
place_piece(state, rc.VENETI, rc.ARVERNI, rc.LEADER, leader_name=rc.VERCINGETORIX)
place_piece(state, rc.VENETI, rc.ARVERNI, rc.WARBAND, 6)
place_piece(state, rc.ATREBATES, rc.ARVERNI, rc.WARBAND, 1)
place_piece(state, rc.NERVII, rc.ROMANS, rc.LEGION, 4, from_legions_track=True)
try:
    from fs_bot.cards import base_arduenna_np as policy
except ImportError:
    from fs_bot.engine.execute import _resolve_card67_arduenna
    selected = None
    results = _resolve_card67_arduenna(state, rc.ARVERNI)
else:
    selected = policy.plan(state)
    results = policy.default_sequence(state)
print(json.dumps({'selected': selected, 'results': results,
                  'fallen_legions': state['fallen_legions'],
                  'leader_region': find_leader(state, rc.ARVERNI),
                  'veneti_warbands': count_pieces(state, rc.VENETI, rc.ARVERNI, rc.WARBAND),
                  'validation': validate_state(state)}, indent=2))
