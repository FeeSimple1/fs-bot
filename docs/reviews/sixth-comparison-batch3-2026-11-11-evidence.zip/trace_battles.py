"""Replay paired games and retain the first changed Battle card and its calls."""
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from contextlib import ExitStack, redirect_stdout
from functools import wraps
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import sys
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.battle import losses, resolve as battle_module
from fs_bot.cards import aduatuca, german_guidance
from fs_bot.commands import enlist_free
from fs_bot.engine import arverni_phase, execute, germans_battle, slingers_choice, winter
from fs_bot.cli.dispatcher import make_decision_func
from fs_bot.engine.game_engine import get_sop_factions, play_card, start_game
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.tools.validation_metadata import source_identity


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def digest(value):
    return sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def board_digest(state):
    return digest({key: value for key, value in state.items() if key != 'decision_agent'})


def game_key(row):
    return tuple(row[key] for key in ('scenario', 'seed', 'card_edition'))


def trace(row):
    scenario, seed, edition = game_key(row)
    state = setup_scenario(scenario, seed=seed, card_edition=edition)
    state['non_player_factions'] = set(get_sop_factions(state))
    bot = make_decision_func({}, stdin=StringIO(), stdout=StringIO(), pause=False)
    cards, calls = [], []
    stack = [calls]

    def observe(kind, board, metadata, fn):
        if board is not state:
            return fn()
        call = dict(kind=kind, **metadata, before=board_digest(board),
                    rng_before=digest(board['rng'].getstate()), calls=[])
        region = metadata.get('region')
        if region:
            call['before_pieces'] = encode(board['spaces'][region]['pieces'])
        call['capabilities'] = {str(card): side for card, side in board.get('capabilities', {}).items()
                                if card in (13, 15, 59, 'A31')}
        stack[-1].append(call)
        stack.append(call['calls'])
        try:
            result = fn()
        finally:
            stack.pop()
        call.update(after=board_digest(board), rng_after=digest(board['rng'].getstate()),
                    result=encode(result))
        if region:
            call['after_pieces'] = encode(board['spaces'][region]['pieces'])
        return result

    def tracked(label, fn):
        @wraps(fn)
        def wrapped(board, *args, **kwargs):
            return observe(label, board, {}, lambda: fn(board, *args, **kwargs))
        return wrapped

    original_battle = battle_module.resolve_battle

    def battle(board, region, attacking_faction, defending_faction, **options):
        return observe('Battle', board, dict(region=region, attacker=attacking_faction,
                       defender=defending_faction, ambush=options.get('is_ambush', False)),
                       lambda: original_battle(board, region, attacking_faction,
                                               defending_faction, **options))

    original_losses = losses.resolve_losses

    def prefire_legacy(board, region, faction, num_losses, **options):
        # The parent resolved Slingers inline. Its chosen Region and loss
        # amount are still live at that call, before it clears the Region.
        caller = sys._getframe(1)
        apply = lambda: original_losses(board, region, faction, num_losses, **options)
        if (caller.f_code.co_name == '_execute_battle'
                and caller.f_locals.get('_c13_region') == region
                and caller.f_locals.get('_pre') == num_losses):
            return observe('Slingers', board, dict(region=region, attacker=faction), apply)
        return apply()

    with ExitStack() as scopes:
        scopes.enter_context(redirect_stdout(StringIO()))
        for module in (battle_module, execute, germans_battle, arverni_phase):
            scopes.enter_context(patch.object(module, 'resolve_battle', battle))
        phase = tracked('Germans Phase Battle', germans_battle.germans_phase_battle)
        for module in (germans_battle, winter):
            if hasattr(module, 'germans_phase_battle'):
                scopes.enter_context(patch.object(module, 'germans_phase_battle', phase))
        for module, symbol, label in (
            (execute, '_execute_battle', 'Battle Command'),
            (execute, '_execute_event', 'Event'),
            (german_guidance, 'resolve', 'German guidance'),
            (aduatuca, 'resolve', 'Aduatuca'),
            (enlist_free, 'execute_free_enlist', 'Free Enlist Command'),
        ):
            scopes.enter_context(patch.object(module, symbol, tracked(label, getattr(module, symbol))))
        scopes.enter_context(patch.object(losses, 'resolve_losses', prefire_legacy))
        if hasattr(slingers_choice, 'fire'):
            original_fire = slingers_choice.fire

            def fire(board, region, attacker):
                return observe('Slingers', board, dict(region=region, attacker=attacker),
                               lambda: original_fire(board, region, attacker))

            scopes.enter_context(patch.object(slingers_choice, 'fire', fire))

        start_game(state)
        for draw in range(1, 201):
            calls.clear()
            before = board_digest(state)
            result = play_card(state, bot, execute=True)
            after = board_digest(state)
            cards.append(dict(draw=draw, card=result['card'], before=before,
                              after=after, calls=list(calls)))
            if result['game_over']:
                break
    assert (result['winner'], draw, after) == (row['winner'], row['cards'], row['final_state_sha256'])
    return dict(scenario=scenario, seed=seed, card_edition=edition, winner=result['winner'],
                final_board=after, cards=cards)


def record(inputs, output):
    source = source_identity()
    rows = json.loads(Path(inputs).read_text())
    assert rows and all(row['source_sha256'] == source['source_sha256'] for row in rows)
    with ProcessPoolExecutor(max_workers=2) as pool:
        games = list(pool.map(trace, rows))
    write_json(output, dict(source=source, games=games))
    print(f'{len(games)} traces match the audited winners, game lengths and final boards')


def first_changed_call(before, after):
    for old, new in zip(before, after):
        if (old['kind'], old['before'], old['rng_before']) != (
                new['kind'], new['before'], new['rng_before']):
            return None
        if old['after'] != new['after']:
            return first_changed_call(old['calls'], new['calls']) or (old, new)
    return None


def compare(previous, repaired, output):
    previous = json.loads(Path(previous).read_text())
    repaired = json.loads(Path(repaired).read_text())
    changes = []
    for old, new in zip(previous['games'], repaired['games'], strict=True):
        assert game_key(old) == game_key(new) and old['final_board'] != new['final_board']
        for left, right in zip(old['cards'], new['cards']):
            assert (left['draw'], left['card'], left['before']) == (
                right['draw'], right['card'], right['before'])
            if left['after'] != right['after']:
                break
        else:
            raise AssertionError(game_key(old))
        battle = first_changed_call(left['calls'], right['calls'])
        assert battle, (game_key(old), left['card'])
        changes.append(dict(zip(('scenario', 'seed', 'card_edition'), game_key(old)),
                            previous_winner=old['winner'], current_winner=new['winner'],
                            draw=left['draw'], card=left['card'],
                            common_scope=battle[0]['kind'], previous=battle[0], current=battle[1]))
    result = dict(parent=previous['source'], repaired=repaired['source'], games=len(changes),
                  changed_winners=sum(row['previous_winner'] != row['current_winner'] for row in changes),
                  first_card_counts=dict(Counter(str(row['card']) for row in changes)), changes=changes)
    write_json(output, result)
    for row in changes:
        print(game_key(row), row['draw'], row['card'], row['common_scope'])


if __name__ == '__main__':
    mode, *paths = sys.argv[1:]
    {'record': record, 'compare': compare}[mode](*paths)
