"""Verify the ninth-audit Batch 3 evidence against a repaired checkout."""

import json
import re
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree

from fs_bot import rules_consts as rc
from fs_bot.tools.balance_smoke import BASELINE_PATH
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


ROOT = Path(__file__).resolve().parent
PARENT = "db2ca384fe794e825f5467f2f0933aedfeb6a242"
PARENT_DIGEST = "9c2c9c927fc544966796c9fac5ff086e9152dec48148966ba41c88672a379144"
BALANCE_LINE = re.compile(r"^\[(.+) seed= *(\d+)\] winner=(.+) \((\d+) cards\)$", re.M)


def load(path):
    return json.loads((ROOT / path).read_text())


def suite(path, count, failures=0):
    tree = ElementTree.parse(ROOT / path)
    group, = tree.iter("testsuite")
    expected = {"tests": count, "failures": failures, "errors": 0, "skipped": 0}
    assert all(int(group.get(key)) == value for key, value in expected.items()), path
    return tree


def game_records(path, edition, seeds, digest):
    meta = load(path / "metadata.json")
    assert meta["source_sha256"] == digest and meta["card_edition"] == edition
    assert meta["seeds"] == list(seeds) and meta["hash_seed"] == 0
    assert set(meta["scenarios"]) == set(SCENARIOS)
    rows = [json.loads(line) for line in (ROOT / path / "games.jsonl").read_text().splitlines()]
    cases = {(r["scenario"], r["seed"]): r for r in rows}
    assert len(rows) == len(cases)
    assert cases.keys() == {(scenario, seed) for scenario in SCENARIOS for seed in seeds}
    for row in cases.values():
        assert row["source_sha256"] == digest and row["card_edition"] == edition
        assert row["completed"] and row["game_completed"] and row["audit_completed"]
        assert not row["errors"] and not row["integrity_findings"] and not _outcome_issues(row)
        assert len(row["final_state_sha256"]) == 64
        assert all(entry["severity"] == "legal-decline" for entry in row["diagnostic_occurrences"])
    return cases


def compare_games(folder, edition, seeds, digest):
    before = game_records(Path("parent") / folder, edition, seeds, PARENT_DIGEST)
    after = game_records(Path("repair") / folder, edition, seeds, digest)
    ignored = {"commit", "source_sha256", "seconds"}
    for key, row in after.items():
        assert {k: v for k, v in row.items() if k not in ignored} == {
            k: v for k, v in before[key].items() if k not in ignored
        }, key
    return after


def compare_replay(stem, other_hash, seeds, digest):
    for extension in ("json", "log"):
        first = ROOT / f"repair/{stem}-0.{extension}"
        assert first.read_bytes() == (ROOT / f"repair/{stem}-{other_hash}.{extension}").read_bytes()
    before = load(f"parent/{stem}-0.json")
    after = load(f"repair/{stem}-0.json")
    for result, tested in ((before, PARENT_DIGEST), (after, digest)):
        meta = result["metadata"]
        assert meta["source_sha256"] == tested and meta["card_edition"] == "second-edition"
        assert all(meta[key] for key in ("events", "reactive", "replay"))
        assert meta["seeds"] == list(seeds)
        assert result["games"] == len(result["records"]) == len(seeds) * len(SCENARIOS)
        assert {(r["scenario"], r["seed"]) for r in result["records"]} == {
            (scenario, seed) for scenario in SCENARIOS for seed in seeds
        }
        assert not result["hard_findings"]
        assert all(row["game_completed"] and not row["findings"] for row in result["records"])
    assert {k: v for k, v in before.items() if k != "metadata"} == {
        k: v for k, v in after.items() if k != "metadata"
    }
    return {k: after[k] for k in ("games", "hard_findings", "partial", "batch_digest")}


def verify_witness():
    before = load("parent/witness.json")
    after = load("repair/witness.json")
    assert after == load("repair/witness-hash987.json")
    assert len(before["UI9-01"]) == len(after["UI9-01"]) == 6
    assert [r["german_resources"] for r in before["UI9-01"]] == [10, 13, 12, 10, 12, 12]
    assert [r["german_resources"] for r in after["UI9-01"]] == [13, 13, 12, 10, 12, 13]
    assert after["UI9-01"][-1]["planning_unchanged"]
    assert len(before["UI9-02"]) == len(after["UI9-02"]) == 2
    for old, new in zip(before["UI9-02"], after["UI9-02"]):
        assert old["case"] == new["case"]
        assert all(old[key] == new[key] for key in ("pending_id", "request", "survivors", "final_hash"))
        assert new["displayed"] == new["survivors"]
        assert new["snapshot_controls"][rc.CARNUTES] == rc.ROMAN_CONTROL
        assert new["snapshot_controls"][rc.PICTONES] == rc.ARVERNI_CONTROL
        assert any(row.startswith(f"{rc.CARNUTES:<14}Rom") for row in new["rendered_region_rows"])
        assert all(new[key] for key in (
            "display_did_not_mutate_pending", "saved_pending_display_reproduced",
            "pre_pause_rollback", "accepted_journal_replayed", "final_matches_uninterrupted",
        ))
        assert new["checks"] == {"census": [], "structure": []}
    assert before["UI9-02"][0]["displayed"][rc.VENETI] == 2
    assert after["UI9-02"][0]["displayed"][rc.VENETI] == 1
    assert after["UI9-02"][0]["snapshot_controls"][rc.VENETI] == rc.NO_CONTROL


def main():
    source = load("repair/source.json")
    digest = source["source_sha256"]
    assert source["commit"] == PARENT and source_identity()["source_sha256"] == digest
    parent = suite("parent/directed.xml", 11, failures=6)
    assert Counter(
        node.get("name").split("[")[0] for node in parent.iter("testcase")
        if node.find("failure") is not None
    ) == {
        "test_german_baggage_trains_accepts_compact_and_explicit_enlist_raids": 2,
        "test_enlist_terminal_collects_three_legal_raids_without_applying_them": 2,
        "test_morbihan_saved_pending_board_shows_survivors_and_physical_control": 2,
    }
    suite("repair/directed.xml", 11)
    suite("repair/focused.xml", 408)
    suite("repair/full.xml", 10251)
    verify_witness()
    legacy = compare_games("legacy", "legacy", range(1, 21), digest)
    second = compare_games("second-edition", "second-edition", range(49, 53), digest)
    balance = (ROOT / "repair/balance.log").read_text()
    rows = BALANCE_LINE.findall(balance)
    reported = {f"{s}|{seed}": {"winner": winner, "cards": int(cards)}
                for s, seed, winner, cards in rows}
    sampled = {f"{s}|{seed}": {key: row[key] for key in ("winner", "cards")}
               for (s, seed), row in legacy.items()}
    assert len(rows) == len(reported) == 100
    assert reported == sampled == json.loads(BASELINE_PATH.read_text())["games"]
    assert "OK: balance within band." in balance
    result = {
        "source": source, "parent_failures": 6, "directed": 11, "focused": 408,
        "full": 10251, "audited_bot_games": len(legacy) + len(second),
        "interludes": sum(r["interlude_completed"] for r in (*legacy.values(), *second.values())),
        "mixed_primary": compare_replay("fuzz-49-52", 987, range(49, 53), digest),
        "mixed_additional": compare_replay("fuzz-201-203", 7, range(201, 204), digest),
        "balance_games": len(reported),
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
