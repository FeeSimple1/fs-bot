"""Refresh only after paired source review; verify every new game against matrix-02."""
from pathlib import Path
from fractions import Fraction
from collections import Counter
import hashlib
import json
import os
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'fs-bot'
BASELINE = REPO / 'fs_bot/tools/balance_baseline.json'
manifest = json.loads((HERE / 'final-source-manifest.json').read_text())
protected = json.loads((HERE / 'protected-before.json').read_text())

def verify_source():
    for name, digest in manifest['files'].items():
        assert hashlib.sha256((REPO / name).read_bytes()).hexdigest() == digest, name
    for name, digest in protected.items():
        if name != 'fs_bot/tools/balance_baseline.json':
            assert hashlib.sha256((REPO / name).read_bytes()).hexdigest() == digest, name

verify_source()
assert BASELINE.read_bytes() == (HERE / 'baseline-before.json').read_bytes()
assert (HERE / 'reviewer-handoff.md').is_file()
assert json.loads((HERE / 'final-a30-replay.json').read_text())
env = os.environ.copy()
env['PYTHONHASHSEED'] = '0'
command = [sys.executable, '-m', 'fs_bot.tools.balance_smoke', '--update', '--seeds', '1-20', '--band', '0.15']
with (HERE / 'baseline-refresh-games.log').open('w') as log:
    subprocess.run(command, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
fresh = json.loads(BASELINE.read_text())['games']
rows = [json.loads(line) for line in (HERE / 'matrix-02/bots-legacy/games.jsonl').read_text().splitlines()]
expected = {f"{row['scenario']}|{row['seed']}": {k: row[k] for k in ('winner', 'cards')} for row in rows}
assert len(fresh) == len(expected) == 100
assert fresh == expected, 'Fresh balance update differs from independently reviewed matrix-02 outcomes'
verify_source()
(HERE / 'baseline-after.json').write_bytes(BASELINE.read_bytes())
old = json.loads((HERE / 'baseline-before.json').read_text())['games']
changes = [k for k in fresh if fresh[k] != old[k]]
rate_checks = []
for scenario in sorted({row['scenario'] for row in rows}):
    for faction in ('Romans', 'Arverni', 'Aedui', 'Belgae', 'Germans'):
        stored = sum(v['winner'] == faction for k, v in fresh.items() if k.startswith(scenario + '|'))
        observed = sum(row['winner'] == faction for row in rows if row['scenario'] == scenario)
        assert abs(Fraction(stored - observed, 20)) <= Fraction('0.15')
        rate_checks.append({'scenario': scenario, 'faction': faction, 'baseline_wins': stored, 'matrix_wins': observed, 'percentage_point_change': 5 * (observed - stored)})
result = {
    'source': manifest['source'],
    'command': command,
    'review': 'reviewer-handoff.md; causal-review/causal-summary.json; final-a30-replay.json; final-source-equivalence.json',
    'fresh_update_games': 100,
    'fresh_outcomes_exactly_match_final_matrix': True,
    'before_sha256': hashlib.sha256((HERE / 'baseline-before.json').read_bytes()).hexdigest(),
    'after_sha256': hashlib.sha256(BASELINE.read_bytes()).hexdigest(),
    'changed_winner_or_card_count_records': len(changes),
    'unchanged_seed_set': '1-20 in all five scenarios',
    'unchanged_band': 0.15,
    'comparison_after_reviewed_refresh': rate_checks,
    'immutable_source_inputs': 48,
    'immutable_source_inputs_unchanged': True,
    'prior_failed_comparisons_retained': ['matrix-01/integration-results.json', 'matrix-02/integration-results.json'],
    'passed': True,
}
(HERE / 'baseline-refresh.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
