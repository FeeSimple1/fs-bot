"""Package accepted and superseded evidence, with a verified member index."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'fs-bot'
archive = REPO / 'docs/reviews/camulogenus-2026-11-03-evidence.zip'
assert json.loads((HERE / 'acceptance-results.json').read_text())['accepted']
excluded = {'archive-index.json', 'archive-check.json'}
files = [p for p in sorted(HERE.rglob('*')) if p.is_file()
         and '__pycache__' not in p.parts and p.name not in excluded]
index = {p.relative_to(HERE).as_posix(): {
    'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
    for p in files}
(HERE / 'archive-index.json').write_text(json.dumps(index, indent=2) + '\n')
with ZipFile(archive, 'w', compression=ZIP_DEFLATED, compresslevel=9) as z:
    for p in files:
        z.write(p, p.relative_to(HERE).as_posix())
    z.write(HERE / 'archive-index.json', 'archive-index.json')
with ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == set(index) | {'archive-index.json'}
    for name, expected in index.items():
        data = z.read(name)
        assert len(data) == expected['bytes']
        assert hashlib.sha256(data).hexdigest() == expected['sha256']
result = {'verified': True, 'indexed_files': len(index), 'bytes': archive.stat().st_size,
          'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
(HERE / 'archive-check.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
