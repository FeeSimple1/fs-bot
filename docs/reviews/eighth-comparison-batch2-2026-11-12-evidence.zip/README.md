# Eighth comparison repair evidence, Batch 2

The parent is `54e7eb89b75d7282febca16b672176d740d470bb`. The repaired Python
source digest is `dc70177dad775609cf18849dfe3c598be3b00cc892c0787ad4f348ad5f32ccd2`.
The runs used Python 3.12.14 and 613 Python files.

Run the evidence verifier from the repaired checkout with this archive extracted.

```sh
PYTHONPATH=. python /path/to/evidence/verify_results.py
```

`parent-final` records the copied directed test module on the parent. Its 13
failures reproduce the old behavior and its 12 passing cases are controls.
`focused-final` covers 175 cases on the repair, including all 25 new cases.
`pytest-final` covers the full suite with five pytest-xdist workers and hash
seed 0. To repeat the new tests on either engine, use that checkout on
`PYTHONPATH`.

```sh
PYTHONHASHSEED=0 PYTHONPATH=. python -m pytest -q /path/to/evidence/test_eighth_comparison_archers.py
```

`final-legacy` covers seeds 1–20 in all scenarios with hash seed 0 and two
workers. `final-second` covers second-edition seeds 45–48 with one worker.
`fuzz0-final` and `fuzz987-final` cover the same second-edition seeds with
Events, reactions and internal replay enabled. `balance-final.log` records
the existing 100-game legacy guardrail. Paired parent records come from the
Batch 1 evidence archive and have the parent engine's Python source digest.
`SHA256SUMS` lists the digest of every other archive file.
