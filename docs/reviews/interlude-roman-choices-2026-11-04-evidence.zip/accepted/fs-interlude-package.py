from pathlib import Path
import hashlib
import json
import platform
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from fs_bot.tools.validation_metadata import source_identity

prefix='interlude-roman-choices-2026-11-04'
result=json.loads(Path('/tmp/fs-interlude-results.json').read_text())
assert source_identity()==result['source']
suite=ET.parse('/tmp/fs-interlude-accepted-full.xml').getroot().find('testsuite')
assert suite.attrib['tests']=='8373' and all(suite.attrib[k]=='0' for k in ('failures','errors','skipped'))
result['full_suite']=suite.attrib
result['python']=platform.python_version()
result['commands']=[
    'python -m pytest -q --junitxml=/tmp/fs-interlude-accepted-full.xml',
    'python -m pytest -q fs_bot/tests/test_interlude_roman_choices.py fs_bot/tests/test_interlude.py fs_bot/tests/test_interlude_leader_choices.py fs_bot/tests/test_pieces.py fs_bot/tests/test_harvest_legions.py fs_bot/tests/test_cli_decision_journeys.py fs_bot/tests/test_winter.py fs_bot/tests/test_winter_uprising_sessions.py',
    'PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --games 2 --workers 2 --out OUT',
    'PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
    'PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out OUT.json',
    'PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20',
    'PYTHONPATH=. python -m pytest -q /tmp/test_interlude_roman_parent_proof.py --junitxml=OUT.xml',
    'PYTHONPATH=. python /tmp/fs-interlude-verify.py',
    'PYTHONPATH=. python /tmp/fs-interlude-package.py',
]
Path('docs/reviews/'+prefix+'-results.json').write_text(json.dumps(result,indent=2)+'\n')
p=Path('docs/reviews/'+prefix+'.md')
s=p.read_text().replace('Final full-suite and matrix results pending.',
                       f"**8,373 tests pass**, with no failures, errors or skips, in {float(suite.attrib['time']):.2f} seconds. All 330 focused tests pass.")
s=s.replace('Frozen source and protected inputs are\nverified by the archived script.', '''All ten audited NPC records and final board hashes match the parent, excluding
only elapsed seconds, source digest and commit identity. The Gallic War seed-1
record completes the Interlude. Every record completes and audits cleanly,
with four ranked factions, no errors, no integrity findings and consistent
winner/ranking fields.

Both complete mixed-seat JSON outputs match across hash seeds, covering 356
human turns and 96 Event attempts, with 90 successful Events, zero hard
findings and zero partial games. Their batch digest is
`d899b5732da10db5`. Internal replay yields 40 executions in total.
The 100-game historical guard passes with a maximum difference of 15
percentage points and 35 different winners versus its historical baseline.
All 49 protected inputs, comprising 47 game references, canonical constants
and the balance baseline, match the parent byte for byte.
Frozen source and protected inputs are verified by the archived script.''')
s=s.replace('The earlier run stopped being accepted when', 'The earlier full-suite run was superseded when')
p.write_text(s)
p=Path('docs/current-status.md');s=p.read_text().replace('Validation pending the final full suite.', '''**8,373 tests pass**, including 53 new cases, with 330 focused tests passing.
Ten audited NPC gameplay records and final hashes match the parent, including
an Interlude. Mixed-seat replays agree across hash seeds with zero hard findings
or partials. The 100-game historical balance check passes its existing band.
The report contains source identity, compatibility limits and archived evidence.''',1);p.write_text(s)
entries={}
accepted=[
    'fs-interlude-accepted-full.xml','fs-interlude-accepted-full.log',
    'fs-interlude-accepted-targeted.log','fs-interlude-accepted-mixed0.json',
    'fs-interlude-accepted-mixed0.log','fs-interlude-accepted-mixed987.json',
    'fs-interlude-accepted-mixed987.log','fs-interlude-accepted-balance.log',
    'fs-interlude-proof-parent.xml','fs-interlude-proof-parent.log',
    'fs-interlude-accepted-proof.xml','fs-interlude-accepted-proof.log',
    'test_interlude_roman_parent_proof.py','fs-interlude-verify.py','fs-interlude-package.py',
]
for name in accepted:
    entries['accepted/'+name]=Path('/tmp/'+name).read_bytes()
for label,directory in [('parent','/tmp/fs-interlude-bots-parent'),('accepted','/tmp/fs-interlude-accepted-bots')]:
    for path in Path(directory).iterdir():
        if path.is_file():
            entries[label+'/bots/'+path.name]=path.read_bytes()
for name in ['fs-interlude-new.log','fs-interlude-targeted.log','fs-interlude-final-targeted.log',
             'fs-interlude-full.log','fs-interlude-full.xml']:
    path=Path('/tmp/'+name)
    if path.is_file():
        entries['superseded/'+name]=path.read_bytes()
for path in Path('/tmp/fs-interlude-bots-rejected-wrong-cwd').iterdir():
    if path.is_file():
        entries['superseded/wrong-working-directory/'+path.name]=path.read_bytes()
entries['superseded/README.txt']=b'These files are excluded from accepted results. The initial targeted test exposed incorrect fixture assumptions about absent zero counters and menu order, then passed after fixture correction. The first full-suite run used the earlier source before direct Winter rollback and its two tests. Its available logs/XML are retained as superseded. The wrong-working-directory bot batch ran repaired sources rather than the requested parent; its actual source metadata is preserved. Accepted parent runs use /tmp/fs-interlude-parent as their working directory.\n'
entries['accepted/source.patch']=subprocess.check_output(['git','diff','HEAD','--','fs_bot'])
for name in ('fs_bot/cli/interlude.py','fs_bot/engine/interlude_choices.py','fs_bot/tests/test_interlude_roman_choices.py'):
    entries['accepted/'+name]=Path(name).read_bytes()
protected=[p for p in Path('Reference Documents').rglob('*') if p.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
entries['accepted/protected-inputs.json']=json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected},indent=2).encode()
entries['accepted/results.json']=json.dumps(result,indent=2).encode()
entries['commands.txt']=('\n'.join(result['commands'])+'\n\nRun the audited bot command separately in the parent and repaired checkouts. Run the six standalone proof tests unchanged in both checkouts with PYTHONPATH=. The parent must have four behavioral failures and two passing controls.\n').encode()
entries['README.txt']=('Parent '+result['source']['commit']+'. Apply accepted/source.patch and copy the three accepted/fs_bot files at their relative paths to reconstruct Python sources. Accepted digest '+result['source']['source_sha256']+' across 505 files. Full suite 8373 passed, 53 new regressions, 330 focused tests. Parent proof four behavioral failures and two controls; repair six passing. Ten audited NPC records/final hashes equal, including Interlude seed 1. Mixed outputs equal across hash seeds0/987, forty executions including replay, zero hard findings/partials. Historical 100-game balance guard passes its unchanged 15-point band. Superseded entries are not accepted evidence.\n').encode()
entries['SHA256SUMS.txt']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(entries.items())).encode()
p=Path('docs/reviews/'+prefix+'-evidence.zip')
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(entries.items()):
        z.writestr(name,data)
with zipfile.ZipFile(p) as z:
    assert z.testzip() is None
    for line in z.read('SHA256SUMS.txt').decode().splitlines():
        digest,name=line.split('  ',1)
        assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps({'suite':suite.attrib,'archive_bytes':p.stat().st_size,'source':result['source']}))
