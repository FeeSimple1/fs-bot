"""Source-pinned, independently audited two-edition matrix; preserves evidence."""
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,json,os,subprocess,sys
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'fs-bot'
sys.path.insert(0,str(REPO))
from fs_bot.tools.validation_metadata import source_identity
from fs_bot.tools.run_batch import SCENARIOS

def main():
    freeze=json.loads((ROOT/'freeze.json').read_text())
    expected=freeze['source_sha256']
    before=source_identity()
    assert before['source_sha256']==expected
    editions=('original','second-edition')
    commands={e:[sys.executable,'-u','-m','fs_bot.tools.run_batch','--seeds','201-300','--card-edition',e,'--workers','2','--out',str(ROOT/(e+'-heldout-500'))] for e in editions}
    manifest=ROOT/'edition-commands.json'
    assert not manifest.exists()
    manifest.write_text(json.dumps(dict(commands=commands,source_pre=before,workdir=str(REPO),hash_seed=0),indent=2)+'\n')
    def run(edition):
        with (ROOT/(edition+'-heldout-500.log')).open('x') as log:
            proc=subprocess.Popen(commands[edition],cwd=REPO,env={**os.environ,'PYTHONHASHSEED':'0'},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
            for line in proc.stdout:
                log.write(line);log.flush()
                if 'games; errors=' in line:print(edition,line.strip(),flush=True)
            code=proc.wait()
        return edition,code
    with ThreadPoolExecutor(max_workers=2) as pool:statuses=dict(pool.map(run,editions))
    after=source_identity()
    result=dict(verification_version=2,source_pre=before,source_post=after,source_unchanged=after['source_sha256']==expected,editions={})
    for e in editions:
        folder=ROOT/(e+'-heldout-500')
        rows=[json.loads(x) for x in (folder/'games.jsonl').read_text().splitlines()]
        meta=json.loads((folder/'metadata.json').read_text())
        summary=json.loads((folder/'summary.json').read_text())
        checks=dict(process_ok=statuses[e]==0,metadata_matches=meta['source_sha256']==expected and meta['card_edition']==e,
            exact_coverage=len(rows)==500 and {(r['scenario'],r['seed']) for r in rows}=={(s,n) for s in SCENARIOS for n in range(201,301)},
            all_accepted=all(all(r.get(k) is True for k in ('completed','game_completed','audit_completed')) for r in rows),
            all_source_and_edition=all(r['source_sha256']==expected and r['card_edition']==e for r in rows),
            no_errors=all(not any(r.get(k) for k in ('error','errors','integrity_findings')) for r in rows),
            no_nonlegal_diagnostics=all(d['severity']=='legal-decline' for r in rows for d in r['diagnostics']),
            positive_cards_and_sha256=all(r['cards']>0 and len(r['final_state_sha256'])==64 for r in rows),
            ranking_valid=all(r['winner']==r['final_ranking'][0][0] and r['engine_final_ranking']==r['final_ranking'] and len(r['final_ranking'])==4 and len({f for f,m in r['final_ranking']})==4 and not r['winner_differs_from_highest_margin'] and not r['engine_ranking_output_missing'] for r in rows),
            summary_matches=all(summary[s]['completed']==100 and summary[s]['wins']==dict(Counter(r['winner'] for r in rows if r['scenario']==s)) for s in SCENARIOS))
        result['editions'][e]=dict(rows=len(rows),accepted=sum(r['completed'] for r in rows),checks=checks,diagnostic_incidents=dict(Counter({severity:sum(d['count'] for r in rows for d in r['diagnostics'] if d['severity']==severity) for severity in {d['severity'] for r in rows for d in r['diagnostics']}})),file_sha256={name:hashlib.sha256((folder/name).read_bytes()).hexdigest() for name in ('games.jsonl','metadata.json','summary.json')})
    result['verified']=result['source_unchanged'] and all(all(v['checks'].values()) for v in result['editions'].values())
    (ROOT/'edition-verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)
    return 0 if result['verified'] else 1
if __name__=='__main__':raise SystemExit(main())
