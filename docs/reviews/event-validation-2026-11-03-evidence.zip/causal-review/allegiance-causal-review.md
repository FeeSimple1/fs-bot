# BE-12 first-divergence source review — 3 November 2026

Scope: the 13 Card 65 first-divergence rows in `first-divergences.json`, from the frozen prepared candidate Python source SHA256 `29f477d5382d87fac2abc4fe9e93ff4b8ca7abcfbad08e5bd0abb9bff2dfb9b5`, against parent commit `8db858b14cd13856059d42db1ad3931e523b5ed4`. This is a bounded read-only review of captured rows; no additional games, production edits, baseline changes, or new rule interpretations were made. These results explain first causes, not the causal importance of every later move or winner.

## Source contract and observed causes

`Reference Documents/Card Reference`, Card 65 shaded, permits removing/replacing German Warbands and an Ally only where the executing faction has Control. `Reference Documents/Chapter 8` §8.1.1 requires a Non-player to decline an Event with no effect. The Aedui Event Instructions expressly select shaded German Allegiances. The Belgic Event Instructions require this Event to increase the number of Belgic Allies plus Citadels, otherwise treating it as No Belgae.

The complete before-state and earlier trace prefix match in every reviewed pair. Read-only `targets`/`np_available` queries of those captured before-states are recorded in `allegiance-causal-targets.json`.

| Actor | Scenario and seed | Eligible German targets | Source-supported cause |
|---|---|---|---|
| Arverni | Pax Gallica? 11, 19; Reconquest of Gaul 11, 17; The Great Revolt 11, 12, 14 | No Warbands or Allies in Arverni-controlled Regions in all seven | Decline ineffective shaded Event, then follow the existing Command flowchart |
| Aedui | Pax Gallica? 12; Reconquest of Gaul 19; The Great Revolt 4 | No Warbands or Allies in Aedui-controlled Regions in all three | Aedui instructions choose shaded text, which is ineffective; proceed to Command |
| Belgae | Pax Gallica? 17 | Two Warbands, no Ally | Cannot add a Belgic Ally/Citadel; specific No Belgae instruction applies |
| Belgae | The Great Revolt 6 | One Warband, no Ally | Cannot add a Belgic Ally/Citadel; specific No Belgae instruction applies |
| Belgae | The Great Revolt 19 | No Warbands or Allies | Both ineffective and unable to increase Belgic Allies/Citadels |

All 13 candidate availability checks are false. The parent chose the ineffective/prohibited Event in 12 cases. The exception is The Great Revolt seed 12: both versions choose the same Raid, but the parent first rolls a 6 on the Arverni Event die while the candidate correctly skips that die.

This RNG change is itself prescribed by §8.7.2: first check whether the Event is ineffective, a final-year Capability, or No Arverni; if any applies, proceed to Rally. Only if none applies does the Arverni check Auto 1–4 or roll. The supplied Arverni flowchart likewise sends V2b Yes directly to V3 and V2b No to V2c. The seven parent Arverni rows each consume exactly one d6 for an ineffective Event (results 4, 1, 4, 3, 2, 6, 1 in the table's order); the candidate consumes none. No live RNG is consumed by either side at the three Aedui or three Belgic first-decision boundaries.

Thus all 13 first causes are the intended Card 65 applicability correction. None indicates a replacement-selection tie or an unintended Card 65 piece mutation. These are decision boundaries, so all board Regions remain unchanged at the boundary itself. The downstream game may then change because the Non-player performs a legal Command instead of spending the turn on a no-op Event, or because a prohibited Event die is omitted.

## Captured-row exact replay exception

The Great Revolt seed 4 candidate replay differs only in `bot_action.details.sa_details.trade_regions`: the recorded list is Carnutes, Bituriges, Aedui; replay after the diagnostic JSON codec sorts map keys yields Aedui, Bituriges, Carnutes. The command, ordered Rally plan, top-level Region lists, Trade amount, complete postdecision state, and RNG are identical. The same existing metadata issue appears at the two A45 first-decision rows reviewed by the expansion agent.

The reason is outside Card 65: `aedui_bot._get_trade_regions` returns `get_controlled_regions`, which inherits `state['spaces']` insertion order; `_make_action` canonicalizes the top-level `sa_regions` but leaves nested Trade metadata in its original order. The trace writer uses `json.dump(..., sort_keys=True)`, changing decoded map insertion order. Normal `save_game` does not sort object keys, so this evidence specifically demonstrates an order-only difference in the diagnostic codec, not a demonstrated normal-save game-state drift.

No executable branch consumes the plural `trade_regions` metadata. `sa_trade.selection_from_action` reads only the distinct, authored singular `trade_region` field; Non-player Trade/Suborn is rederived at actual SA time by `execute._execute_sa`. The coordinator's `metadata-equivalence.json` confirms that both decision forms produce identical complete execution results, state, and RNG for all three exceptions. Card 65's own target enumeration explicitly sorts Regions and Tribes before randomized choices.

Disposition: record the existing non-executed metadata ordering difference accurately; no cleanup in this batch, as directed by root. The Card 65 first-cause review is clear. Preserve the exact-replay exception in reported evidence rather than labeling all candidate result dictionaries byte-identical.
