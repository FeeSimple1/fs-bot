# Independent BE-02 source review — 2026-11-03

Scope: local authoritative rule/card transcriptions only; no new external ruling or policy. Production review is limited to the human Battle target boundary on cards 11, 25 unshaded, 36 unshaded, 45 shaded, and 70 unshaded. BE-01 March choices remain separate.

## Printed requirements

| Card | Decision owner / legal scope | Printed exceptions |
| --- | --- | --- |
| 11 original | Romans; one defender in the Region where Auxilia were placed | All Roman forces participate; Auxilia cause double Losses before rounding. |
| 11 revised | Romans; same fixed Region | Only Auxilia participate, with double Losses before rounding. Other physical Roman counters still affect Control, but do not attack, take Counterattack Losses, or enable Leader-dependent Battle effects. Agreed Diviciacus Warbands can participate as Auxilia under the existing cooperation scope. |
| 25 unshaded | Executor; either Pictones or Arverni Region, unless that Region was already explicitly supplied | Adds 3 Losses; removes an Ally first. Card Tips expressly permit Battle without any friendly force. |
| 36 unshaded | Executor; one Region against a Gallic faction | No Retreat, Counterattack, or Citadel effect on Losses. Attackers stay Hidden. |
| 45 shaded | Executor; one Region against Romans; Aedui counters can supply all attackers | Uses Aedui as own and Ambushes if able. Normal Leader-location restrictions remain: the Hidden-piece tip states a necessary condition, not a waiver of other conditions. An Aedui executor counts its own counters once. Romans cannot attack themselves. |
| 70 unshaded | Romans; one defender at the selected March destination | The Roman permission is for the March-and-Battle grant. Once the accepted March is done, the Battle has no separate opt-out. Initial March/grant acceptance is BE-01 and remains outside this closure. |

Sources: `Reference Documents/Card Reference` entries 11/25/36/45/70; revised 11 in `Reference Documents/Ariovistus/A Card Reference`; `Reference Documents/Chapter 5` §§5.1 (named versus executor selections), 5.1.1 (normal restrictions retained), 5.1.3 (all possible text required), and 5.4 (free actions). Card 6's separate “then may” wording contrasts with card 70's single permission. Card 70's tip about only moving pieces explains March flipping; it does not establish a new exclusion of resident pieces from the following Battle.

`Reference Documents/Ariovistus/A Setup` retains revised numeric 11 in Ariovistus. Numeric 25 and 36 are replaced by A25/A36, 45 by A45, and 70 by A70. No extra human-target pathway for those expansion cards is implied by this work.

## Diviciacus false lead, corrected

An intermediate test proposed lending Aedui Warbands when Romans had a Legion but zero Auxilia. This was invalid: card38 says the two piece types must be together; A1.4 likewise specifies Aedui Warbands and Auxilia together. `diviciacus.eligible_regions` requires both physical Auxilia and Aedui Warbands. This review withdraws that suspected bug and requests no eligibility change. The invalid test version is retained as `independent-with-invalid-borrow-fixture.py.txt`; the corrected final boundary test expects no Auxilia-only Battle or cooperation request when zero physical Auxilia are present.

## Independent regression evidence

Test file: `fs_bot/tests/test_event_battle_choices_independent.py`.

- Corrected candidate run: **19 passed**, `independent-candidate-attempt2.log`.
- Identical corrected tests against detached parent 4e9a82ed35052198987dad4c91dd79ce9c5b4ab9: **18 failed, 1 passed**, `independent-parent-corrected-final.log`. The log prints the imported parent's execute.py path before pytest. The passing case is the original Numidians control, where a Legion still participates and can be lost.
- Earlier attempts remain in this directory. Candidate attempt1 was work-in-progress (16 passed / 3 failed), including missing then-unfinished cohort scope and the invalid borrowing fixture. These are not final acceptance results.

Independent tests cover named-Roman ownership, explicit defender/Region selections overriding automatic ranking, no-friendly-force Aquitani, fixed supplied Region binding, Morasses restrictions and Hidden preservation, illegal targets/forged Event modifiers with unchanged state, combined Aedui Litaviccus Ambush, card70's post-March Battle target, no independent decline for all five possible Battles, edition-specific Numidians participation, and Aedui self-double-count prevention. Public transactional session tests and CLI tests are owned by the session/frontend reviewers and are required alongside these lower-level witnesses.

## Bounded follow-ups

1. **NP Belgic Litaviccus target priority:** independently confirmed existing mismatch; see `litaviccus-np-source-question.md` and funded parent witness. Current choice uses Roman stack size, despite the printed instruction to force the most Legion Losses. Human-Roman Retreat forecasting lacks an adopted policy here, and numeric67 PR11 does not automatically apply. This is recorded for a separate targeted task, not silently treated as repaired by BE-02.
2. **Retreat modifier defect corrected and independently reviewed:** §8.4.3 refers to Losses the defender will suffer. The final fixed-Event wrapper forwards doubled Auxilia, extra Losses, and first-Ally priority into `_decide_defender_retreat`. The ordinary force sum is halved/rounded under §3.2.4/3.3.4, then Aquitani adds its printed extra Losses exactly as the existing live resolver does. The mandatory first Ally absorbs one Loss before the mobile-survival estimate and precedes other pieces in projected Legion exposure. Defaults remain false/zero, so ordinary Battle and card2 mechanics are unchanged. Added tests cover both11 profiles, excluded-piece visibility, Aquitani survival, and two first-Ally counterexamples. No acceptance blocker found. The focused independent review run is recorded in `retreat-final-review.log`; this mechanical correction is separate from the unsettled NPC45 target ranking above.

## Closure criteria

BE-02 can close after public Event routing, durable pause/reload/retry, exact legal target validation, named-faction ownership, CLI visibility, deterministic NPC fallback, and the printed modifiers/cohort regressions pass for both 11 profiles and the base numeric cards. Card70's automatic March and separate NPC45 forecasting remain explicitly open under their own work items. No rules choice outside the printed scope is adopted by this review.
