"""Read-only audit reproduction. Run from a checkout with PYTHONPATH=. using its audit virtualenv.
Uses initialized, valid empty scenario boards; all counters use piece helpers.
Tribal allegiance metadata is paired explicitly with static piece placement.
No production files are modified. JSON output includes actual terminal menus.
"""
import io, json, copy
from pathlib import Path
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces, count_pieces_by_state
from fs_bot.state.state_schema import build_initial_state, validate_state
from fs_bot.state.serialize import encode, decode, save_game, load_game
from fs_bot.cli.reactive import make_cli_reactive
from fs_bot.cli.display import HumanTurnDisplay
from fs_bot.cli.human_plan import _collect_march, _collect_rampage, collect_player_action, _collect_sa_plan
from fs_bot.battle.losses import resolve_losses, _build_loss_priority
from fs_bot.battle.resolve import resolve_battle
from fs_bot.engine.execute import _execute_battle, _decide_defender_retreat, _execute_rampage, execute_decision
from fs_bot.engine.game_engine import _action_transaction, ACTION_COMMAND
from fs_bot.tools.seat_session import SeatSession, DecisionPending, board_copy

OUT = Path(__file__).parent

def board(scenario=rc.SCENARIO_GREAT_REVOLT):
    s=build_initial_state(scenario, seed=81)
    s['non_player_factions']=set()
    s['resources']={f:20 for f in rc.FACTIONS}
    return s

def valid(s):
    errors=validate_state(s)
    assert not errors, errors
    return errors

def static(s,r,f,p,t):
    place_piece(s,r,f,p)
    s['tribes'][t]['allied_faction']=f

def session(s, seat, meta=None, log=None):
    ss=SeatSession(s, meta or {'seat':seat}, [] if log is None else log, HumanTurnDisplay(io.StringIO()))
    s['decision_agent']=ss.reactive
    def driver(*a): pass
    driver.transaction_checkpoint=ss.checkpoint
    driver.transaction_restore=ss.restore
    return ss,driver

def transaction(s,driver,fn):
    with _action_transaction(s,driver): return fn(s)

# 1. Illegal static loss tier accepted by real menu and durable session.
result={}
s=board(); place_piece(s,rc.CARNUTES,rc.ARVERNI,rc.WARBAND)
static(s,rc.CARNUTES,rc.ARVERNI,rc.ALLY,rc.TRIBE_CARNUTES); valid(s)
menu=io.StringIO(); s['decision_agent']=make_cli_reactive([rc.ARVERNI],io.StringIO('Ally\n(default order for the rest)\n'),menu)
r=resolve_losses(s,rc.CARNUTES,rc.ARVERNI,1)
assert count_pieces(s,rc.CARNUTES,rc.ARVERNI,rc.WARBAND)==1 and count_pieces(s,rc.CARNUTES,rc.ARVERNI,rc.ALLY)==0
result['loss_tier_cli']={'result':r,'menu':menu.getvalue(),'state_errors':valid(s)}
s=board(); place_piece(s,rc.CARNUTES,rc.ARVERNI,rc.WARBAND)
static(s,rc.CARNUTES,rc.ARVERNI,rc.ALLY,rc.TRIBE_CARNUTES)
ss,driver=session(s,rc.ARVERNI); before=encode(board_copy(s))
fn=lambda state: resolve_losses(state,rc.CARNUTES,rc.ARVERNI,1)
try: transaction(s,driver,fn)
except DecisionPending: pass
assert encode(board_copy(s))==before
pending=copy.deepcopy(ss.data['pending']); request=decode(pending['request'])
save_game(s,OUT/'battle_loss_pending.json',meta=ss.meta,log=ss.log)
restored,meta,log=load_game(OUT/'battle_loss_pending.json',validate=True)
ss,driver=session(restored,rc.ARVERNI,meta,log)
ss.import_inbox({'decision_id':pending['id'],'response':[[rc.ALLY,None]]})
r=transaction(restored,driver,fn); ss.finish()
assert count_pieces(restored,rc.CARNUTES,rc.ARVERNI,rc.WARBAND)==1
result['loss_tier_session']={'pending':request,'same_pending_id_after_load':pending['id'],'result':r,'journal_length':len(ss.log),'state_errors':valid(restored)}
# Retreating defender can illegally assign mobile before still-present Allied Tribe.
s=board(); place_piece(s,rc.CARNUTES,rc.ARVERNI,rc.WARBAND)
static(s,rc.CARNUTES,rc.ARVERNI,rc.ALLY,rc.TRIBE_CARNUTES)
ss,driver=session(s,rc.ARVERNI); ss.import_inbox([{'response':[[rc.WARBAND,None]]}])
r=transaction(s,driver,lambda state: resolve_losses(state,rc.CARNUTES,rc.ARVERNI,1,is_retreat=True)); ss.finish()
result['retreat_loss_tier_session']={'result':r,'ally_remaining':count_pieces(s,rc.CARNUTES,rc.ARVERNI,rc.ALLY),'state_errors':valid(s)}

# 2. Ordinary human casualties omit visibility and physical Allied Tribe.
s=board(); place_piece(s,rc.CARNUTES,rc.ARVERNI,rc.WARBAND,1)
place_piece(s,rc.CARNUTES,rc.ARVERNI,rc.WARBAND,1,piece_state=rc.REVEALED)
ss,driver=session(s,rc.ARVERNI)
try: transaction(s,driver,lambda state: resolve_losses(state,rc.CARNUTES,rc.ARVERNI,1))
except DecisionPending: pass
req=decode(ss.data['pending']['request']); assert req['pieces']==[(rc.WARBAND,None),(rc.WARBAND,None)]
ss.import_inbox({'decision_id':ss.data['pending']['id'],'response':[[rc.WARBAND,rc.REVEALED]]})
try: transaction(s,driver,lambda state: resolve_losses(state,rc.CARNUTES,rc.ARVERNI,1))
except DecisionPending: pass
menu=io.StringIO(); make_cli_reactive([rc.ARVERNI],io.StringIO('1\n(default order for the rest)\n'),menu)(s,rc.ARVERNI,req)
result['ordinary_casualty_visibility']={'menu':menu.getvalue(),'request':req,'explicit_revealed_rejected':ss.error,'state_errors':valid(s)}
s=board()
tribes=[t for t,r in rc.TRIBE_TO_REGION.items() if r==rc.NERVII]
for t in tribes[:2]: static(s,rc.NERVII,rc.ARVERNI,rc.ALLY,t)
assert len(tribes)>=2; valid(s)
ss,driver=session(s,rc.ARVERNI)
try: transaction(s,driver,lambda state: resolve_losses(state,rc.NERVII,rc.ARVERNI,1))
except DecisionPending: pass
result['ordinary_casualty_tribe']={'tribes':tribes[:2],'request':decode(ss.data['pending']['request'])}

# 3. Retreat stay/move/removal choices missing in base and Ariovistus.
for scenario,defender,leader in [(rc.SCENARIO_GREAT_REVOLT,rc.ARVERNI,rc.VERCINGETORIX),(rc.SCENARIO_ARIOVISTUS,rc.GERMANS,rc.ARIOVISTUS_LEADER)]:
    s=board(scenario); place_piece(s,rc.CARNUTES,rc.ROMANS,rc.AUXILIA)
    place_piece(s,rc.CARNUTES,defender,rc.WARBAND,2)
    place_piece(s,rc.CARNUTES,defender,rc.LEADER,leader_name=leader)
    place_piece(s,rc.ATREBATES,defender,rc.WARBAND)
    valid(s); ss,driver=session(s,defender)
    ss.import_inbox([{'response':{'retreat':True,'region':rc.ATREBATES}}])
    fn=lambda state: _execute_battle(state,rc.ROMANS,{'command':rc.CMD_BATTLE,'details':{'battle_plan':[{'region':rc.CARNUTES,'target':defender}]}})
    r=transaction(s,driver,fn); ss.finish()
    assert count_pieces(s,rc.CARNUTES,defender,rc.WARBAND)==2
    result['retreat_'+scenario]={'origin_warbands':count_pieces(s,rc.CARNUTES,defender,rc.WARBAND),'origin_leader':count_pieces(s,rc.CARNUTES,defender,rc.LEADER),'destination_warbands':count_pieces(s,rc.ATREBATES,defender,rc.WARBAND),'result':r,'requests':[decode(e['assistant_request']) for e in ss.log],'state_errors':valid(s)}
s=board(); place_piece(s,rc.CARNUTES,rc.ARVERNI,rc.WARBAND,2)
menu=io.StringIO(); s['decision_agent']=make_cli_reactive([rc.ARVERNI],io.StringIO('1\n'),menu)
r=_decide_defender_retreat(s,rc.CARNUTES,rc.ROMANS,rc.ARVERNI,False)
result['retreat_no_destination_cli']={'result':r,'menu':menu.getvalue()}
ss,driver=session(s,rc.ARVERNI); ss.import_inbox([{'response':{'retreat':True,'region':None}}])
try: transaction(s,driver,lambda state:_decide_defender_retreat(state,rc.CARNUTES,rc.ROMANS,rc.ARVERNI,False))
except DecisionPending: pass
result['retreat_no_destination_session']={'error':ss.error,'request':decode(ss.data['pending']['request']),'state_errors':valid(s)}

# 4. Besiege target choice absent from actual action plan and execution.
s=board(); place_piece(s,rc.CARNUTES,rc.ROMANS,rc.LEGION,from_legions_track=True)
static(s,rc.CARNUTES,rc.ARVERNI,rc.CITADEL,rc.TRIBE_CARNUTES)
# Use Nervii (Nervii+Eburones) for two physical Allies; typed besiege_target ignored.
static(s,rc.CARNUTES,rc.ARVERNI,rc.ALLY,next(t for t,r in rc.TRIBE_TO_REGION.items() if r==rc.CARNUTES and t!=rc.TRIBE_CARNUTES))
valid(s)
menu=io.StringIO()
menu_action=_collect_sa_plan(s,rc.ROMANS,{'command':rc.CMD_BATTLE,'details':{'battle_plan':[{'region':rc.CARNUTES,'target':rc.ARVERNI}]},'sa_regions':[]},io.StringIO('Carnutes\n'),menu,sa=rc.SA_BESIEGE)
ss,driver=session(s,rc.ROMANS)
ss.import_inbox([{'response':{'done':True}}]*50)
action={'command':rc.CMD_BATTLE,'sa':rc.SA_BESIEGE,'sa_regions':[rc.CARNUTES], 'details':{'battle_plan':[{'region':rc.CARNUTES,'target':rc.ARVERNI,'besiege_target':rc.ALLY}]}}
r=transaction(s,driver,lambda state:execute_decision(state,rc.ROMANS,{'player_action':action}));ss.finish()
assert count_pieces(s,rc.CARNUTES,rc.ARVERNI,rc.CITADEL)==0 and count_pieces(s,rc.CARNUTES,rc.ARVERNI,rc.ALLY)==1
result['besiege']={'menu':menu.getvalue(),'menu_plan':menu_action,'citadel_remaining':count_pieces(s,rc.CARNUTES,rc.ARVERNI,rc.CITADEL),'ally_remaining':count_pieces(s,rc.CARNUTES,rc.ARVERNI,rc.ALLY),'requested':rc.ALLY,'result':r,'roman_requests':[decode(e['assistant_request']) for e in ss.log],'state_errors':valid(s)}

# 5. Rampage victim cannot choose counter identities or mix remove/Retreat.
s=board(); place_piece(s,rc.NERVII,rc.BELGAE,rc.LEADER,leader_name=rc.AMBIORIX)
place_piece(s,rc.NERVII,rc.BELGAE,rc.WARBAND,2)
place_piece(s,rc.NERVII,rc.ROMANS,rc.AUXILIA,1)
place_piece(s,rc.NERVII,rc.ROMANS,rc.AUXILIA,1,piece_state=rc.REVEALED)
place_piece(s,rc.NERVII,rc.ROMANS,rc.LEGION,from_legions_track=True)
place_piece(s,rc.ATREBATES,rc.ROMANS,rc.AUXILIA)
valid(s); ss,driver=session(s,rc.ROMANS)
ss.import_inbox([{'response':{'retreat':False}}])
r=transaction(s,driver,lambda state:_execute_rampage(state,rc.BELGAE,{'command':rc.CMD_RALLY,'sa':rc.SA_RAMPAGE,'sa_regions':[{'region':rc.NERVII,'target':rc.ROMANS}]})); ss.finish()
result['rampage_victim']={'result':r,'requests':[decode(e['assistant_request']) for e in ss.log],'remaining_auxilia':count_pieces(s,rc.NERVII,rc.ROMANS,rc.AUXILIA),'remaining_legions':count_pieces(s,rc.NERVII,rc.ROMANS,rc.LEGION),'state_errors':valid(s)}

# 6. March dropoff field is ignored by standard executor; menu lacks it.
s=board(); place_piece(s,rc.PROVINCIA,rc.ROMANS,rc.AUXILIA,2)
menu=io.StringIO(); a=collect_player_action(s,rc.ROMANS,ACTION_COMMAND,io.StringIO('March\nProvincia\nArverni → Bituriges\nall 2\nn\n'),menu)
a['details']['dropoffs']={rc.ARVERNI_REGION:{rc.AUXILIA:1}}
ss,driver=session(s,rc.ROMANS)
ss.import_inbox([{'response':{'done':True}}]*50)
r=transaction(s,driver,lambda state:execute_decision(state,rc.ROMANS,{'player_action':a}));ss.finish()
assert count_pieces(s,rc.ARVERNI_REGION,rc.ROMANS,rc.AUXILIA)==0
result['march_dropoff']={'plan':a,'result':r,'menu':menu.getvalue(),'intermediate_auxilia':count_pieces(s,rc.ARVERNI_REGION,rc.ROMANS,rc.AUXILIA),'destination_auxilia':count_pieces(s,rc.BITURIGES,rc.ROMANS,rc.AUXILIA),'state_errors':valid(s)}

# 7. March hide-in-place: empty route is rejected before hiding/payment.
s=board(); place_piece(s,rc.CARNUTES,rc.AEDUI,rc.WARBAND,2,piece_state=rc.REVEALED)
a={'command':rc.CMD_MARCH,'details':{'explicit_moves':[{'origin':rc.CARNUTES,'path':[]}]}}
ss,driver=session(s,rc.AEDUI)
ss.import_inbox([{'response':{'done':True}}]*50)
r=transaction(s,driver,lambda state:execute_decision(state,rc.AEDUI,{'player_action':a}));ss.finish()
result['march_hide_in_place']={'plan':a,'result':r,'revealed_remaining':count_pieces_by_state(s,rc.CARNUTES,rc.AEDUI,rc.WARBAND,rc.REVEALED),'resources':s['resources'][rc.AEDUI],'state_errors':valid(s)}
print(json.dumps(encode(result),indent=2))
