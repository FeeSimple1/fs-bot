"""Round-four witness: legal Ariovistus positions can have negative Roman earnings.
Run from repo root with PYTHONPATH=. python /path/to/this/file.py.
Fixture uses piece helpers and sets matching Tribe metadata. No gameplay patching.
"""
from copy import deepcopy
import json
from fs_bot import rules_consts as rc
from fs_bot.state.state_schema import build_initial_state,validate_state,check_structural_integrity
from fs_bot.board.pieces import place_piece,count_pieces,remove_piece
from fs_bot.board.control import refresh_all_control
from fs_bot.engine.victory import calculate_victory_score,check_any_victory
from fs_bot.engine.winter import harvest_phase,run_winter_round


def fixture():
 s=build_initial_state(rc.SCENARIO_ARIOVISTUS,seed=14)
 # Both Suebi are German Allies; other allied Tribes are drawn from normal spaces.
 tribes=list(s['tribes'])
 allocation={rc.GERMANS:list(rc.SUEBI_TRIBES)}
 rest=[t for t in tribes if t not in rc.SUEBI_TRIBES]
 allocation[rc.ARVERNI]=rest[:10]
 allocation[rc.AEDUI]=rest[10:16]
 allocation[rc.BELGAE]=rest[16:24]
 for f,ts in allocation.items():
  for t in ts:
   r=rc.TRIBE_TO_REGION[t]
   place_piece(s,r,f,rc.ALLY)
   s['tribes'][t]['allied_faction']=f
 # Six Settlements, each in its own playable Region. Equal enemy discs prevent
 # most of these Settlements from producing German Control.
 settlements=[rc.MORINI,rc.NERVII,rc.ATREBATES,rc.TREVERI,rc.CARNUTES,rc.MANDUBII]
 for r in settlements:place_piece(s,r,rc.GERMANS,rc.SETTLEMENT)
 # Deny Belgic Control so no Faction has won before this Harvest.
 for r in s['spaces']:
  n=count_pieces(s,r,rc.BELGAE,rc.ALLY)
  if n:place_piece(s,r,rc.ROMANS,rc.AUXILIA,n)
 place_piece(s,rc.PROVINCIA,rc.ROMANS,rc.FORT)
 place_piece(s,rc.PROVINCIA,rc.ROMANS,rc.LEADER,leader_name=rc.CAESAR)
 place_piece(s,rc.AEDUI_REGION,rc.AEDUI,rc.LEADER,leader_name=rc.DIVICIACUS)
 place_piece(s,rc.UBII,rc.GERMANS,rc.LEADER,leader_name=rc.ARIOVISTUS_LEADER)
 place_piece(s,rc.BITURIGES,rc.BELGAE,rc.LEADER,leader_name=rc.BODUOGNATUS)
 refresh_all_control(s)
 assert validate_state(s)==[],validate_state(s)
 assert check_structural_integrity(s)==[],check_structural_integrity(s)
 assert check_any_victory(s) is None,check_any_victory(s)
 return s

base=fixture()
rows=[]
for starting in [0,1,10]:
 s=deepcopy(base);s['resources'][rc.ROMANS]=starting
 before=calculate_victory_score(s,rc.ROMANS)
 result=harvest_phase(s)
 row=dict(case='negative_score',roman_score=before,resources_before=starting,resources_after=s['resources'][rc.ROMANS],earnings=result[rc.ROMANS],census=validate_state(s),structure=check_structural_integrity(s))
 assert before==-2
 assert s['resources'][rc.ROMANS]==starting-2
 rows.append(row)
# Positive control with all Settlements removed: same exact Tribe configuration.
s=deepcopy(base)
for r in s['spaces']:
 n=count_pieces(s,r,rc.GERMANS,rc.SETTLEMENT)
 if n:remove_piece(s,r,rc.GERMANS,rc.SETTLEMENT,n)
result=harvest_phase(s)
assert s['resources'][rc.ROMANS]==4
assert not check_structural_integrity(s)
rows.append(dict(case='positive_control',roman_score=4,resources_before=0,resources_after=s['resources'][rc.ROMANS],earnings=result[rc.ROMANS],census=validate_state(s),structure=check_structural_integrity(s)))
# Full Winter public orchestrator also exposes the same corruption.
s=deepcopy(base)
before=dict(census=validate_state(s),structure=check_structural_integrity(s),
            winner=check_any_victory(s),roman_score=calculate_victory_score(s,rc.ROMANS))
result=run_winter_round(s,relocations={})
assert result['phases']['victory']['game_over'] is False
assert s['resources'][rc.ROMANS]==-2
rows.append(dict(case='full_winter',before=before,resources_before=0,
                 resources_after=s['resources'][rc.ROMANS],
                 earnings=result['phases']['harvest'][rc.ROMANS],
                 census=validate_state(s),structure=check_structural_integrity(s)))
print(json.dumps(rows,indent=2))
