"""Cross-process durable Quarters agreement replay witness (read-only sources)."""
import argparse, copy, io, json, os, pathlib, subprocess, sys, tempfile

p=argparse.ArgumentParser()
p.add_argument('--repo', required=True)
p.add_argument('--worker', choices=['record','resume'])
p.add_argument('--save')
p.add_argument('--single-region', action='store_true')
a=p.parse_args()
sys.path.insert(0,str(pathlib.Path(a.repo).resolve()))

if not a.worker:
    def run(mode, seed, path, single):
        command=[sys.executable,__file__,'--repo',a.repo,'--worker',mode,'--save',str(path)]
        if single: command.append('--single-region')
        result=subprocess.run(command,env=dict(os.environ,PYTHONHASHSEED=str(seed)),
                              capture_output=True,text=True,check=True)
        return json.loads(result.stdout)
    with tempfile.TemporaryDirectory() as directory:
        out={}
        for single in (False,True):
            path=pathlib.Path(directory)/('single.json' if single else 'multi.json')
            out['single_region_control' if single else 'multiple_host_regions']={
                'record_hash0':run('record',0,path,single),
                'resume_hash0':run('resume',0,path,single),
                'resume_hash987':run('resume',987,path,single)}
    assert out['multiple_host_regions']['resume_hash987']['error'] == 'Saved decision no longer matches its board/request; replay stopped.'
    assert out['multiple_host_regions']['resume_hash0']['error'] is None
    assert out['single_region_control']['resume_hash987']['error'] is None
    print(json.dumps(out,indent=2,sort_keys=True))
    sys.exit()

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece
from fs_bot.cli.display import HumanTurnDisplay
from fs_bot.engine.game_engine import _action_transaction
from fs_bot.engine.winter import quarters_phase
from fs_bot.state import player_ownership
from fs_bot.state.serialize import encode,decode,save_game,load_game
from fs_bot.state.state_schema import build_initial_state,validate_state,check_structural_integrity
from fs_bot.tools.seat_session import SeatSession,DecisionPending,board_copy

if a.worker=='record':
    state=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=11)
    place_piece(state,rc.PROVINCIA,rc.ROMANS,rc.FORT)
    place_piece(state,rc.ARVERNI_REGION,rc.ROMANS,rc.LEGION,from_legions_track=True)
    place_piece(state,rc.AEDUI_REGION,rc.AEDUI,rc.WARBAND)
    if not a.single_region:
        place_piece(state,rc.VENETI,rc.AEDUI,rc.WARBAND)
    state['resources'][rc.ROMANS]=10
    player_ownership.install(state,{rc.ROMANS:'Player 1',rc.AEDUI:'Player 1'})
    meta={'seat':rc.ROMANS,'player_id':'Player 1'}
    log=[]
else:
    state,meta,log=load_game(a.save,validate=True)

assert validate_state(state)==check_structural_integrity(state)==[]
initial=encode(board_copy(state))
session=SeatSession(state,meta,log,HumanTurnDisplay(io.StringIO()))
state['decision_agent']=session.reactive
plan={f:[] for f in (rc.BELGAE,rc.AEDUI,rc.ARVERNI,rc.ROMANS)}
plan[rc.ROMANS]=[(rc.LEGION,rc.ARVERNI_REGION,rc.PROVINCIA,1)]
def driver(*args): pass
driver.transaction_checkpoint=session.checkpoint
driver.transaction_restore=session.restore
driver.transaction_complete=session.transaction_complete

requests=[]
for attempt in range(40):
    try:
        with _action_transaction(state,driver):
            result=quarters_phase(state,relocations=plan)
        raise AssertionError('Expected a later actual human window to retain agreement journal')
    except DecisionPending:
        pending=session.data['pending']
        request=decode(pending['request'])
        requests.append(request)
        if a.worker=='resume':
            break
        accepted_supply=any(decode(e['assistant_request']).get('request_type')=='supply_line'
                            for e in session.data['journal'])
        if accepted_supply:
            assert encode(board_copy(state))==initial
            save_game(state,a.save,meta=meta,log=log)
            break
        response=True if request.get('request_type')=='supply_line' else {'use_default':True}
        session.import_inbox({'decision_id':pending['id'],'response':response})
else:
    raise AssertionError('No saved supply agreement')

assert validate_state(state)==check_structural_integrity(state)==[]
assert encode(board_copy(state))==initial
print(json.dumps({'error':session.error,'pending_id':session.data['pending']['id'],
                  'pending_request':decode(session.data['pending']['request']),
                  'journal':[{'id':e['assistant_id'],'request':decode(e['assistant_request']),
                              'response':decode(e['assistant_response'])}
                             for e in session.data['journal']],
                  'board_and_rng_unchanged':True,'census':[],'structure':[]},
                 indent=2,sort_keys=True))
