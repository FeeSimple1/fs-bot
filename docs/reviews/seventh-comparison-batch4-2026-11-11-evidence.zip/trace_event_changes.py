"""Replay paired games and trace the first difference in Event decisions/effects."""

from concurrent.futures import ProcessPoolExecutor
from contextlib import ExitStack, redirect_stdout
from functools import wraps
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import sys
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.board.control import is_controlled_by
from fs_bot.board.pieces import count_pieces
from fs_bot.cards import card_effects, event_conditions, event_eval
from fs_bot.cli.dispatcher import make_decision_func
from fs_bot.engine import execute
from fs_bot.engine.game_engine import get_sop_factions, play_card, start_game
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.tools.validation_metadata import source_identity


def digest(value):
    return sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def board_digest(state):
    return digest({key: value for key, value in state.items() if key != 'decision_agent'})


def key(row):
    return row['scenario'], row['seed'], row['card_edition']


def watched(card_id, shaded):
    return (card_id == 28 or (card_id in (18, 'A18', 'A26') and shaded)
            or (card_id == 'A19' and not shaded))


def facts(state, card_id):
    if card_id == 28:
        return {city: [state['tribes'][tribe]['allied_faction'],
                       card_effects._tribe_piece_type(state, tribe)]
                for city, tribe in rc.CITY_TO_TRIBE.items() if tribe in state['tribes']}
    if card_id == 'A19':
        return {tribe: info['allied_faction'] for tribe, info in state['tribes'].items()
                if info.get('allied_faction') is not None}
    if card_id == 'A26':
        return {region: dict(warbands=count_pieces(state, region, rc.ARVERNI, rc.WARBAND),
                             german_control=is_controlled_by(state, region, rc.GERMANS))
                for region in (rc.AEDUI_REGION, rc.SEQUANI)}
    return dict(roman_resources=state['resources'][rc.ROMANS],
                roman_eligibility=state['eligibility'][rc.ROMANS],
                roman_forced_ineligible=state.get('forced_ineligible', {}).get(rc.ROMANS))


def trace(task):
    row, parent = task
    scenario, seed, edition = key(row)
    state = setup_scenario(scenario, seed=seed, card_edition=edition)
    state['non_player_factions'] = set(get_sop_factions(state))
    bot = make_decision_func({}, stdin=StringIO(), stdout=StringIO(), pause=False)
    decisions, checks, plans, effects, cards = [], [], [], [], []
    check_effective = event_eval.is_event_effective
    check_available = event_conditions.np_event_available
    derive = execute._derive_event_params
    run_event = execute._execute_event

    def decide(board, faction, options, position):
        decision = bot(board, faction, options, position)
        decisions.append(encode(dict(faction=faction, position=position, decision=decision)))
        return decision

    @wraps(check_effective)
    def effective(board, card_id, shaded=False):
        result = check_effective(board, card_id, shaded)
        if watched(card_id, shaded):
            checks.append(dict(kind='effectiveness', card=card_id, shaded=shaded, result=result))
        return result

    @wraps(check_available)
    def available(board, card_id, faction, shaded):
        result = check_available(board, card_id, faction, shaded)
        if watched(card_id, shaded):
            checks.append(dict(kind='availability', card=card_id, faction=faction,
                               shaded=shaded, result=result))
        return result

    @wraps(derive)
    def plan(board, faction, card_id, shaded):
        if board is not state or not watched(card_id, shaded):
            return derive(board, faction, card_id, shaded)
        before = digest(board['rng'].getstate())
        result = derive(board, faction, card_id, shaded)
        plans.append(encode(dict(card=card_id, faction=faction, shaded=shaded, params=result,
                                 rng_before=before, rng_after=digest(board['rng'].getstate()))))
        return result

    @wraps(run_event)
    def event(board, faction, action, *, human=False):
        details = action.get('details') or {}
        card_id = details.get('card_id', board.get('current_card'))
        shaded = details.get('text_preference') == rc.EVENT_SHADED
        if board is not state or not watched(card_id, shaded):
            return run_event(board, faction, action, human=human)
        before = facts(board, card_id)
        result = run_event(board, faction, action, human=human)
        effects.append(dict(card=card_id, faction=faction, shaded=shaded,
                            before=before, after=facts(board, card_id), executed=result['executed']))
        return result

    with ExitStack() as stack:
        stack.enter_context(redirect_stdout(StringIO()))
        stack.enter_context(patch.object(event_eval, 'is_event_effective', effective))
        stack.enter_context(patch.object(event_conditions, 'np_event_available', available))
        stack.enter_context(patch.object(execute, '_derive_event_params', plan))
        stack.enter_context(patch.object(execute, '_execute_event', event))
        start_game(state)
        for draw in range(1, 201):
            decisions.clear()
            checks.clear()
            plans.clear()
            effects.clear()
            before = board_digest(state)
            rng_before = digest(state['rng'].getstate())
            result = play_card(state, decide, execute=True)
            card = dict(draw=draw, card=result['card'], before=before, rng_before=rng_before,
                        after=board_digest(state), decisions=list(decisions), checks=list(checks),
                        plans=list(plans), effects=list(effects))
            if parent is not None:
                prior = parent['cards'][draw - 1]
                assert (prior['card'], prior['before'], prior['rng_before']) == (
                    card['card'], before, rng_before)
                if prior['after'] != card['after']:
                    return dict(scenario=scenario, seed=seed, card_edition=edition,
                                prior_winner=parent['winner'], current_winner=row['winner'],
                                draw=draw, card=card['card'], prior=prior, current=card)
            else:
                cards.append(card)
            if result['game_over']:
                break
    assert parent is None, f'No first changed card for {key(row)}'
    assert (result['winner'], draw, card['after']) == (
        row['winner'], row['cards'], row['final_state_sha256'])
    return dict(scenario=scenario, seed=seed, card_edition=edition, winner=row['winner'], cards=cards)


def main(inputs, output, parent_file=None):
    rows = json.loads(Path(inputs).read_text())
    parents = {} if not parent_file else {key(row): row for row in
        json.loads(Path(parent_file).read_text())['games']}
    assert not parent_file or parents.keys() == {key(row) for row in rows}
    with ProcessPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(trace, ((row, parents.get(key(row))) for row in rows)))
    Path(output).write_text(json.dumps(dict(source=source_identity(), games=results), indent=2) + '\n')
    print(f'{len(results)} games traced')


if __name__ == '__main__':
    main(*sys.argv[1:])
