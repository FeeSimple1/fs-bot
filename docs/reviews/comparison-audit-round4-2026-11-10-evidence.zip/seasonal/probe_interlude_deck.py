"""Round four: Interlude filters pre-substitution IDs and always omits cards5/71."""
import json
from fs_bot import rules_consts as rc
from fs_bot.state.setup import setup_scenario
from fs_bot.engine.execute import _execute_event
from fs_bot.engine.interlude import run_interlude
from fs_bot.state.state_schema import validate_state,check_structural_integrity

rows=[]
for card in [None,'A38',8]:
 s=setup_scenario(rc.SCENARIO_GALLIC_WAR,seed=21)
 s['non_player_factions']={rc.ROMANS,rc.AEDUI,rc.GERMANS,rc.BELGAE}
 if card:
  result=_execute_event(s,rc.AEDUI,{'details':{'card_id':card,'text_preference':rc.EVENT_UNSHADED,'event_params':{}}},human=True)
  assert result['executed'],result
 before={'census':validate_state(s),'structure':check_structural_integrity(s),'active':dict(s['capabilities'])}
 assert not before['census'] and not before['structure']
 result=run_interlude(s,britannia_decision=False)
 assert validate_state(s)==[] and check_structural_integrity(s)==[]
 assert s['deck'].count('A38')==1
 if card=='A38':assert s['capabilities']['A38']==rc.EVENT_UNSHADED
 if card==8:assert 8 not in s['deck']
 # At seed21 with no active5/A5 or71, they still are forcibly removed.
 assert 5 not in s['deck'] and 71 not in s['deck']
 rows.append({'case':str(card),'before':before,'active_after':s['capabilities'],
              'deck_A38_count':s['deck'].count('A38'),'deck_8_count':s['deck'].count(8),
              'deck_5_count':s['deck'].count(5),'deck_71_count':s['deck'].count(71),
              'deck_result':result['step10_deck'],'census':validate_state(s),
              'structure':check_structural_integrity(s)})
# Baseline setup positive control: inactive5/71 ARE in the normal shuffled pool.
s=setup_scenario(rc.SCENARIO_PAX_GALLICA,seed=21)
assert 5 in s['deck'] and 71 in s['deck']
rows.append({'case':'ordinary_pax_setup_control','deck_5_count':s['deck'].count(5),
             'deck_71_count':s['deck'].count(71)})
print(json.dumps(rows,indent=2))
