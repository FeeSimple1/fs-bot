"""Executable witnesses on b23c8cd. Assertions preserve observed defects, not desired behavior."""
import json
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, place_piece, remove_piece, get_available
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT
from fs_bot.engine.moves import validate_player_action
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.tools.seat_session import validate_response
from fs_bot.tools.validation_metadata import source_identity


def board(card, faction=rc.BELGAE):
    state = build_initial_state(rc.SCENARIO_ARIOVISTUS, seed=317)
    state.update(non_player_factions=set(), current_card=card, next_card='A67', executing_faction=faction)
    return state


def run(state, card, params, shaded=False):
    assert validate_state(state) == []
    assert check_structural_integrity(state) == []
    action = {'command': rc.FIRST_DID_EVENT, 'regions': [], 'sa': 'No SA', 'sa_regions': [],
              'details': {'card_id': card, 'text_preference': rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,
                          'event_params': params}}
    decision = {'action': ACTION_EVENT, 'player_action': action}
    validate_response(state, {'kind': 'turn', 'faction': state['executing_faction'], 'options': [ACTION_EVENT]}, decision)
    valid = validate_player_action(state, state['executing_faction'], action)[0]
    result = execute_decision(state, state['executing_faction'], decision)
    assert valid and result['executed'], result
    return {'valid': valid, 'executed': result['executed'], 'errors': result.get('errors'),
            'pool_errors': validate_state(state), 'structural_errors': check_structural_integrity(state)}


def citadel(state, tribe=rc.TRIBE_SEQUANI):
    region = rc.TRIBE_TO_REGION[tribe]
    assert _ally_tribe(state, tribe, rc.AEDUI)
    remove_piece(state, region, rc.AEDUI, rc.ALLY)
    place_piece(state, region, rc.AEDUI, rc.CITADEL)


def main():
    out = {}
    for visibility in (rc.HIDDEN, rc.REVEALED, rc.SCOUTED):
        state = board('A64')
        place_piece(state, rc.ATREBATES, rc.BELGAE, rc.WARBAND, piece_state=visibility)
        key = 'A64_' + visibility
        out[key] = run(state, 'A64', {'region': rc.ATREBATES})
        out[key]['marker'] = state['markers'].get(rc.ATREBATES, {}).get(rc.MARKER_ABATIS)
        assert out[key]['marker'] == (None if visibility == rc.SCOUTED else rc.BELGAE)

    state = board('A51')
    _ally_tribe(state, rc.TRIBE_REMI, rc.ROMANS)
    _ally_tribe(state, rc.TRIBE_ATREBATES, rc.ROMANS)
    out['A51_exact_tribe'] = run(state, 'A51', {'removals': [
        {'faction': rc.ROMANS, 'piece_type': rc.ALLY, 'tribe': rc.TRIBE_REMI}]}, True)
    out['A51_exact_tribe']['tribes'] = {tribe: state['tribes'][tribe]['allied_faction']
                                      for tribe in (rc.TRIBE_ATREBATES, rc.TRIBE_REMI)}
    assert state['tribes'][rc.TRIBE_ATREBATES]['allied_faction'] is None
    assert state['tribes'][rc.TRIBE_REMI]['allied_faction'] == rc.ROMANS

    state = board('A24')
    citadel(state)
    place_piece(state, rc.SEQUANI, rc.AEDUI, rc.WARBAND, 20)
    out['A24_citadel'] = run(state, 'A24', {})
    out['A24_citadel']['aedui_warbands'] = count_pieces(state, rc.SEQUANI, rc.AEDUI, rc.WARBAND)
    out['A24_citadel']['aedui_citadel'] = count_pieces(state, rc.SEQUANI, rc.AEDUI, rc.CITADEL)
    assert out['A24_citadel']['aedui_citadel'] == 0
    assert out['A24_citadel']['aedui_warbands'] == 20

    state = board('A43')
    citadel(state)
    out['A43_collateral_citadel'] = run(state, 'A43', {}, True)
    out['A43_collateral_citadel']['aedui_citadel'] = count_pieces(state, rc.SEQUANI, rc.AEDUI, rc.CITADEL)
    assert out['A43_collateral_citadel']['aedui_citadel'] == 0

    state = board('A30')
    _ally_tribe(state, rc.TRIBE_SEQUANI, rc.AEDUI)
    assert get_available(state, rc.ARVERNI, rc.WARBAND) >= 9
    out['A30_omit_mandatory'] = run(state, 'A30', {'placements': []}, True)
    out['A30_omit_mandatory']['arverni_pieces'] = sum(count_pieces(state, r, rc.ARVERNI) for r in (rc.SEQUANI, rc.AEDUI_REGION))
    assert out['A30_omit_mandatory']['arverni_pieces'] == 0
    assert state['tribes'][rc.TRIBE_SEQUANI]['allied_faction'] is None

    state = board('A56')
    state['resources'][rc.BELGAE] = 0
    assert get_available(state, rc.BELGAE, rc.WARBAND) >= 4 and get_available(state, rc.BELGAE, rc.ALLY) >= 2
    out['A56_omit_mandatory'] = run(state, 'A56', {'warband_placements': [], 'ally_placements': []}, True)
    out['A56_omit_mandatory']['resources'] = state['resources'][rc.BELGAE]
    assert state['resources'][rc.BELGAE] == 4 and count_pieces(state, rc.MORINI, rc.BELGAE) == 0

    state = board('A65')
    place_piece(state, rc.MORINI, rc.BELGAE, rc.WARBAND, 4)
    _ally_tribe(state, rc.TRIBE_MORINI, rc.BELGAE)
    _ally_tribe(state, rc.TRIBE_MENAPII, rc.BELGAE)
    assert get_available(state, rc.GERMANS, rc.WARBAND) >= 4 and get_available(state, rc.GERMANS, rc.ALLY) >= 2
    out['A65_omit_mandatory'] = run(state, 'A65', {'from_faction': rc.BELGAE,
        'warband_replacements': [], 'ally_replacements': []}, True)
    assert count_pieces(state, rc.MORINI, rc.BELGAE) == 6 and count_pieces(state, rc.MORINI, rc.GERMANS) == 0

    state = board('A65')
    place_piece(state, rc.MORINI, rc.AEDUI, rc.WARBAND, 4)
    _ally_tribe(state, rc.TRIBE_MORINI, rc.AEDUI)
    _ally_tribe(state, rc.TRIBE_MENAPII, rc.AEDUI)
    out['A65_wrong_source'] = run(state, 'A65', {'from_faction': rc.AEDUI,
        'warband_replacements': [{'region': rc.MORINI}] * 4,
        'ally_replacements': [{'tribe': t} for t in (rc.TRIBE_MORINI, rc.TRIBE_MENAPII)]}, True)
    out['A65_wrong_source']['aedui_after'] = count_pieces(state, rc.MORINI, rc.AEDUI)
    out['A65_wrong_source']['belgae_after'] = count_pieces(state, rc.MORINI, rc.BELGAE)
    assert out['A65_wrong_source']['aedui_after'] == 0 and out['A65_wrong_source']['belgae_after'] == 6

    for leader in (rc.CAESAR, rc.SUCCESSOR):
        state = board('A19')
        place_piece(state, rc.SEQUANI, rc.ROMANS, rc.LEADER, leader_name=leader)
        _ally_tribe(state, rc.TRIBE_SEQUANI, rc.GERMANS)
        key = 'A19_' + leader
        out[key] = run(state, 'A19', {'replacements': [{'tribe': rc.TRIBE_SEQUANI}]})
        out[key]['ally_after'] = state['tribes'][rc.TRIBE_SEQUANI]['allied_faction']
        assert out[key]['ally_after'] == rc.ROMANS

    state = board('A30')
    out['A30_citadel_backing'] = run(state, 'A30', {'placements': [
        {'region': rc.SEQUANI, 'piece_type': rc.CITADEL},
        {'region': rc.SEQUANI, 'piece_type': rc.WARBAND, 'count': 8}]}, True)
    out['A30_citadel_backing']['city_tribe'] = state['tribes'][rc.TRIBE_SEQUANI]['allied_faction']
    assert out['A30_citadel_backing']['city_tribe'] is None
    assert len(out['A30_citadel_backing']['structural_errors']) == 2
    print(json.dumps({'source': source_identity(), 'witnesses': out}, indent=2))


if __name__ == '__main__':
    main()
