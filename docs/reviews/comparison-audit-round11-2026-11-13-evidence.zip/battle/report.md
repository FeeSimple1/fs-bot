# Eleventh audit: combat lane

Audited clean Falling Sky commit `702d60a3754ce94a73ead0d0148d647232ecd816`. One confirmed medium finding, BM11-01. No production or test files changed. `probe_battle.py` exercises public Event acquisition and dispatch in six census-valid controlled positions; `results.json` records every result and reactive defender choice.

## BM11-01 — Divination treats an Abatis-protected Ally as a guaranteed high-value Loss

**Expected.** A34 unshaded lets non-player Aedui command Germans according to the Aedui flowchart. In Carnutes, Ariovistus and ten German Warbands face two Belgic Warbands, the Aulerci Ally and a Belgic Abatis acquired through public A64. No Stalwart is active. Abatis blocks Ariovistus doubling and halves six ordinary Losses to three. The Belgae can stand, remove their two Warbands, and assign the third Loss to Abatis, preserving Aulerci regardless of that roll. No enemy Leader, Ally, Citadel, Legion or Settlement is sure to take a Loss, so §8.6.2's Battle gate fails. This otherwise isolated A34 position should choose its permitted March.

**Observed.** The accepted A34 Event chooses and executes Battle. The human Belgic defender stands and assigns the final Loss to the offered Abatis. Both Warbands disappear, the Abatis absorbs the final Loss, and Aulerci remains Belgic. The same defect occurs without Ariovistus using twelve German Warbands. Raw and live Battle calculations agree on three Losses in both cases. This is a target-identity forecast error, not incorrect arithmetic or a failure of live casualty selection.

**Root cause.** `fs_bot/cards/divination_np.py:69–83` calls `_build_loss_priority` without `abatis_defender`, whose default is false (`fs_bot/battle/losses.py:615–616`). The resulting list omits the marker and the code slices the first three entries as if they were forced losses: two Warbands and the Ally. It returns true at the A4 gate (`divination_np.py:105–110`) and again promotes the target at lines139–142. Actual loss resolution correctly supplies effective Abatis and offers it as a static casualty (`losses.py:474–478,794–802`).

**Source basis.** The supplied A Card Reference lines146–150 grants A34's command choice and lines288–292 makes defending Abatis act as a Fort. Chapter A3 lines118–131 applies Gallic Battle and Ariovistus's Fort exception. Chapter3 lines311–338 supplies the loss rates, defender halving, casualty choice and static-piece tier. Chapter8 lines105–118 requires the beneficiary's flowchart for Event-driven German actions; lines448–462 requires certainty of a high-value Loss before entering Aedui Battle. The primary witness preserves Aulerci even if Abatis fails its save, so it does not depend on a favorable die assumption or unresolved casualty interpretation.

| Public A34 case | Standing Losses (raw/live) | Expected | Observed | Aulerci after |
| --- | --- | --- | --- | --- |
| Active Abatis, Ariovistus + 10 Warbands | 3 / 3 | March | Battle | Belgae |
| Active Abatis, 12 Warbands, no Ariovistus | 3 / 3 | March | Battle | Belgae |
| No Abatis, Ariovistus + 1 Warband | 3 / 3 | Battle | Battle | Removed |
| Active Abatis, Ariovistus + 6 Warbands | 2 / 2 | March | March | Belgae |
| Active Abatis, no high-value target | 3 / 3 | March | March | Absent at setup |
| Abatis then Stalwart, Ariovistus + 2 Warbands | 4 / 4 | Battle | Battle | Removed |

The repaired ordinary Aedui predicate in `fs_bot/bots/aedui_bot.py:232–258` correctly rejects both defect fixtures when given the same German attacking force. The final control preserves the BM10-01 repair: canceled Abatis no longer blocks Ariovistus doubling, and A34 correctly Battles.

**Prior-audit distinction.** This is a newly demonstrated unrepaired consumer of an existing defect class. NP6-02 (`docs/reviews/comparison-audit-round6-2026-11-11.md:256–276`) repaired the ordinary Aedui/Arverni target-guarantee calculations, including a Roman Fort that could protect an Ally. A34 retains a separate priority-slicing implementation. BM10-01 (`docs/reviews/comparison-audit-round10-2026-11-13.md:107–127`) repaired canceled-Abatis arithmetic in `calculate_losses`; those calculations now agree with live resolution here and its positive control still passes. BM5-02 repaired the human Abatis casualty choice exercised successfully by this witness. None of those closed groups supplied A34's missing active-marker guarantee handling.

**Repair scope.** Evaluate A34's Aedui target guarantee through the existing resolver-backed approach, retaining the real German force, effective Abatis, legal alternatives in the casualty tier and allowed Retreat responses. Reusing the repaired ordinary predicate is preferable to adding another parallel approximation. A simple list insertion alone would still leave general saving-roll/choice modeling fragile. Add public A34 regressions with both the new active-marker cases and the prior canceled-marker case. Do not alter live Battle arithmetic or remove the legal defender choice.

**Validation and limits.** All six fixtures use `build_initial_state`, `place_piece` and `_ally_tribe`, include Provincia's mandatory Fort and stay within physical stocks. Marker and capability acquisition and the final A34 response pass durable turn-response validation and public `execute_decision`. `validate_state` and `check_structural_integrity` return empty lists before and after all Events. The callback supplies only legal defender reactions and delegates the Event-granted action to the existing Aedui policy. No function or RNG is mocked. Seed1 is deterministic. These are controlled witnesses, not a claim about natural-game frequency or exhaustive capability coverage. No new owner ruling is required.

## Other inspected consumers and comparator lesson

Inspected the remaining direct forecast uses of `_build_loss_priority`: the Morasses branch at `fs_bot/bots/arverni_bot.py:215–222`, and Frost exploration at `fs_bot/cards/divination_np.py:330–346,503–520`. No additional source-backed public failure was finalized for those paths, and they are not counted. Existing unresolved Elite, Optimates and Circumvallation questions remain excluded.

Actually inspected authorized comparator `lod-bot` at `2991ea279062773548ec390a1da75f3e85381702`: `lod_ai/commands/battle.py:383–410` computes bot selection scores using the exact modifier helpers used by the live resolver at lines788–799, and `lod_ai/bots/british_bot.py:2041–2050` calls that shared helper. The engineering lesson applied is to share the relevant resolution semantics with decision consumers and verify the outer dispatch, rather than assuming a correct live resolver guarantees a correct bot gate. No Liberty or Death rule is used as Falling Sky authority.

Reproduce:

```bash
/workspace/scratch/4aba5bd9b1ab/fs-bot/.venv/bin/python /workspace/scratch/521fc7ecea8c/audit11/battle/probe_battle.py --repo /workspace/scratch/521fc7ecea8c/falling-sky
```

The probe emits deterministic JSON and asserts the two currently wrong decisions plus four expected controls. `findings.json` contains exact rule and implementation anchors and evidence paths.
