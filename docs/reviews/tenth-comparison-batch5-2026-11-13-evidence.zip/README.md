# Tenth comparison repair Batch 5 evidence

`source.json` identifies the tested repair to parent
`d27e774bd90c5c6c172d5b69dbce574fd176702c`. The parent witness was rerun
on that revision and matches the original audit output. The directed
regressions exercise normal dispatch, live execution and the controls
for affordability, grants, Britannia, Winter Campaign and repeat use.

The parent game records come from Batch 4. The paired traces run the
ordinary engine and record the first changed card on each revision.
The original balance comparison uses the previous checked-in baseline.
The revised baseline comes from the 100 audited legacy games and is
independently confirmed by the balance runner on the same seeds.
The 27 balance canary and guardrail tests pass with the refreshed baseline.
`SHA256SUMS` covers every other archive member.

## Reproduce the checks

Use Python 3.12.14 and the development test environment. From the repaired
repository root, set `OUT` to an empty output directory, `EVIDENCE` to
the extracted archive and `PARENT` to a clean checkout of the parent
commit.

```bash
PYTHONHASHSEED=0 python -m pytest -q fs_bot/tests/test_tenth_comparison_arverni.py
PYTHONHASHSEED=987 python -m pytest -q fs_bot/tests/test_tenth_comparison_arverni.py
PYTHONHASHSEED=0 python -m pytest -q -n 4 --junitxml="$OUT/full.xml"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out "$OUT/legacy"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 53-56 --card-edition second-edition --workers 2 --out "$OUT/second-edition"
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 53-56 --card-edition second-edition --out "$OUT/fuzz0.json"
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 53-56 --card-edition second-edition --out "$OUT/fuzz987.json"
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20 --baseline "$EVIDENCE/pre-repair-balance-baseline.json"
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
PYTHONPATH=. PYTHONHASHSEED=0 python "$EVIDENCE/trace_arverni.py" "$EVIDENCE/trace-tasks.json" --workers 3 > "$OUT/trace-repair.json"
PYTHONPATH=. python "$EVIDENCE/verify_results.py"
```

The previous balance comparison reproduces the 20-point drift and exits
with status 1. The reviewed comparison passes within the original band.
From the parent checkout, run the new cases and repeat the paired trace.

```bash
cd "$PARENT"
PYTHONPATH=. PYTHONHASHSEED=0 python -m pytest -q "$EVIDENCE/test_tenth_comparison_arverni.py"
PYTHONPATH=. PYTHONHASHSEED=0 python "$EVIDENCE/trace_arverni.py" "$EVIDENCE/trace-tasks.json" --workers 3 > "$OUT/trace-parent.json"
```
