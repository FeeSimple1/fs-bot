# Cross-cutting comparison audit evidence

Audited Falling Sky `3c23a3414c3e870e274ef63c278db8cb3f1ee747` against Liberty or Death engineering patterns at `2991ea279062773548ec390a1da75f3e85381702`. Falling Sky's supplied references govern every rules conclusion.

From the Falling Sky checkout, with its root on `PYTHONPATH`, run either script. They require only Python's standard library and the game package. Both scripts assert the current defective behavior and print JSON. A future repair must reverse the relevant expectations rather than retain these as positive behavior tests.

- `probe_dynamic_colony.py` exercises a real Event-created Colony through Seize, Build, Entreat, Trade, and a controlled Belgic scoring fixture. Its result and limitations are in `dynamic_colony_results.json` and `findings.json`.
- `probe_razed_seize.py` executes Sacking and Seize through the normal decision executor, then compares two Spring phases to a Razed control. The permanent marker becomes temporary and disappears. Its output is `razed_seize_results.json`.

The dynamic Colony cases are one common representation/consumer repair group. The production Seize Forage and authored-plan rejection are end-to-end action witnesses. Build and Entreat use legal Region prerequisites and production primitives. The Dispersed Colony marker is a source-legal fixture assigned directly because the Seize bug prevents that legal state from being constructed through Seize. All fixtures and resulting positions pass state and structural validators.

The audit changes no engine code, source references, or tests. Coverage and rejected hypotheses are explicit in the ledger.
