"""
Tests for aedui_bot.py — Non-Player Aedui flowchart per §8.6.

Tests every flowchart node with Yes/No branches, seeded RNG, and
both base game and Ariovistus scenarios.
"""

import pytest

from fs_bot.rules_consts import (
    ROMANS, ARVERNI, AEDUI, BELGAE, GERMANS,
    LEADER, LEGION, AUXILIA, WARBAND, FORT, ALLY, CITADEL, SETTLEMENT,
    HIDDEN, REVEALED, SCOUTED,
    SCENARIO_PAX_GALLICA, SCENARIO_ARIOVISTUS,
    SCENARIO_GREAT_REVOLT, SCENARIO_GALLIC_WAR,
    BASE_SCENARIOS, ARIOVISTUS_SCENARIOS,
    DIVICIACUS, CAESAR, AMBIORIX,
    MORINI, NERVII, ATREBATES, PROVINCIA, MANDUBII, SUGAMBRI, UBII,
    AEDUI_REGION, ARVERNI_REGION, SEQUANI, BITURIGES,
    CARNUTES, PICTONES, VENETI, TREVERI,
    TRIBE_CARNUTES, TRIBE_AULERCI, TRIBE_ARVERNI, TRIBE_AEDUI,
    TRIBE_MANDUBII, TRIBE_BITURIGES, TRIBE_MORINI,
    TRIBE_ATREBATES, TRIBE_SEQUANI,
    EVENT_UNSHADED,
    TRIBE_SUEBI_NORTH,
)
from fs_bot.state.state_schema import build_initial_state
from fs_bot.board.pieces import place_piece, count_pieces, get_available
from fs_bot.board.control import refresh_all_control, is_controlled_by
from fs_bot.bots.aedui_bot import (
    # Node functions
    node_a1, node_a2, node_a3, node_a4, node_a5, node_a6,
    # Process nodes
    node_a_event, node_a_battle,
    node_a_rally, node_a_raid, node_a_march,
    # SA helpers
    _check_ambush, _determine_trade_sa, _determine_suborn_sa,
    # Winter
    node_a_quarters,
    # Agreements
    node_a_agreements,
    # Diviciacus
    node_a_diviciacus,
    # Main driver
    execute_aedui_turn,
    # Helpers
    _count_aedui_warbands_on_map, _estimate_rally_placements,
    _would_raid_gain_enough, _aedui_at_victory,
    _estimate_battle_losses, _would_force_loss_on_high_value,
    _get_battle_enemies, _estimate_trade_resources,
    # Action constants
    ACTION_BATTLE, ACTION_MARCH, ACTION_RALLY, ACTION_RAID,
    ACTION_EVENT, ACTION_PASS,
    SA_ACTION_AMBUSH, SA_ACTION_TRADE, SA_ACTION_SUBORN, SA_ACTION_NONE,
)
from fs_bot.bots.bot_dispatch import (
    dispatch_bot_turn, BotDispatchError,
)


# ===================================================================
# Test helpers
# ===================================================================

def _make_state(scenario=SCENARIO_PAX_GALLICA, seed=42, non_players=None):
    """Build a minimal test state with common defaults."""
    state = build_initial_state(scenario, seed=seed)
    if non_players is None:
        non_players = {ARVERNI, BELGAE, AEDUI}
    state["non_player_factions"] = non_players
    state["can_play_event"] = True
    state["current_card_id"] = 1
    state["final_year"] = False
    state["frost"] = False
    state["current_card_faction_order"] = []
    state["next_card_faction_order"] = []
    state["is_second_eligible"] = False
    return state


def _place_aedui_force(state, region, *, warbands=0, ally_tribe=None,
                        citadel=False, hidden=True):
    """Helper to place Aedui forces in a region."""
    if warbands > 0:
        piece_state = HIDDEN if hidden else REVEALED
        place_piece(state, region, AEDUI, WARBAND, warbands,
                    piece_state=piece_state)
    if ally_tribe:
        state["tribes"][ally_tribe]["allied_faction"] = AEDUI
        place_piece(state, region, AEDUI, ALLY)
    if citadel:
        place_piece(state, region, AEDUI, CITADEL)


def _place_roman_force(state, region, *, leader=False, legions=0, auxilia=0,
                       ally_tribe=None, fort=False):
    """Helper to place Roman forces in a region."""
    if leader:
        place_piece(state, region, ROMANS, LEADER, leader_name=CAESAR)
    if legions > 0:
        place_piece(state, region, ROMANS, LEGION, legions,
                    from_legions_track=True)
    if auxilia > 0:
        place_piece(state, region, ROMANS, AUXILIA, auxilia)
    if ally_tribe:
        state["tribes"][ally_tribe]["allied_faction"] = ROMANS
        place_piece(state, region, ROMANS, ALLY)
    if fort:
        place_piece(state, region, ROMANS, FORT)


def _place_enemy_force(state, region, faction, *, warbands=0, ally_tribe=None,
                       citadel=False, leader=False, auxilia=0):
    """Helper to place enemy pieces."""
    if warbands > 0:
        place_piece(state, region, faction, WARBAND, warbands)
    if ally_tribe:
        state["tribes"][ally_tribe]["allied_faction"] = faction
        place_piece(state, region, faction, ALLY)
    if citadel:
        place_piece(state, region, faction, CITADEL)
    if auxilia > 0:
        place_piece(state, region, faction, AUXILIA, auxilia)
    if leader:
        leader_name = AMBIORIX if faction == BELGAE else CAESAR
        place_piece(state, region, faction, LEADER, leader_name=leader_name)


# ===================================================================
# A1: Aedui 1st on upcoming but not current card, and roll 1-4?
# ===================================================================

class TestNodeA1:
    """A1 decision node tests."""

    def test_pass_when_first_next_not_first_current_roll_low(self):
        """Pass when Aedui 1st on next card, not on current, and roll 1-4."""
        state = _make_state(seed=1)  # seed 1 should give a low roll
        state["next_card_faction_order"] = [AEDUI, ROMANS, BELGAE, ARVERNI]
        state["current_card_faction_order"] = [ROMANS, AEDUI, BELGAE, ARVERNI]
        # Try multiple seeds to find one that gives 1-4
        for s in range(100):
            state["rng"] = __import__("random").Random(s)
            result = node_a1(state)
            if result == "Yes":
                break
        assert result == "Yes"

    def test_no_when_first_on_both(self):
        """No pass when Aedui 1st on both cards."""
        state = _make_state()
        state["next_card_faction_order"] = [AEDUI, ROMANS, BELGAE, ARVERNI]
        state["current_card_faction_order"] = [AEDUI, ROMANS, BELGAE, ARVERNI]
        assert node_a1(state) == "No"

    def test_no_when_not_first_on_next(self):
        """No pass when Aedui not 1st on next card."""
        state = _make_state()
        state["next_card_faction_order"] = [ROMANS, AEDUI, BELGAE, ARVERNI]
        state["current_card_faction_order"] = [ROMANS, AEDUI, BELGAE, ARVERNI]
        assert node_a1(state) == "No"

    def test_no_when_empty_orders(self):
        """No pass when card orders are empty."""
        state = _make_state()
        assert node_a1(state) == "No"


# ===================================================================
# A2: Can play Event?
# ===================================================================

class TestNodeA2:
    """A2 decision node tests."""

    def test_yes_when_can_play_event(self):
        state = _make_state()
        state["can_play_event"] = True
        assert node_a2(state) == "Yes"

    def test_no_when_cannot_play_event(self):
        state = _make_state()
        state["can_play_event"] = False
        assert node_a2(state) == "No"


# ===================================================================
# A3: Event Ineffective or No Aedui?
# ===================================================================

class TestNodeA3:
    """A3 decision node tests."""

    def test_yes_when_no_card(self):
        """Decline when no current card."""
        state = _make_state()
        state["current_card_id"] = None
        assert node_a3(state) == "Yes"

    def test_no_for_normal_card(self):
        """Don't decline for a normal card."""
        state = _make_state()
        state["current_card_id"] = 9  # Mons Cevenna — no special Aedui instr
        # Its geographic free actions still need a presence in the theatre.
        from fs_bot.rules_consts import SEQUANI
        place_piece(state, SEQUANI, AEDUI, WARBAND)
        assert node_a3(state) == "No"


# ===================================================================
# A4: Battle would force high-value Loss?
# ===================================================================

class TestNodeA4:
    """A4 decision node tests."""

    def test_yes_when_can_force_ally_loss(self):
        """Battle when we can force a Loss on an enemy Ally."""
        state = _make_state()
        # Place Aedui force and enemy with only an Ally (no expendable pieces)
        _place_aedui_force(state, MANDUBII, warbands=6)
        state["tribes"][TRIBE_MANDUBII]["allied_faction"] = ARVERNI
        place_piece(state, MANDUBII, ARVERNI, ALLY)
        refresh_all_control(state)
        assert node_a4(state) == "Yes"

    def test_no_when_enemy_has_many_expendable(self):
        """No Battle when enemy has many expendable pieces shielding targets."""
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=2)
        _place_enemy_force(state, MANDUBII, ARVERNI, warbands=10,
                           ally_tribe=TRIBE_MANDUBII)
        refresh_all_control(state)
        assert node_a4(state) == "No"

    def test_no_when_no_aedui_pieces(self):
        """No Battle when Aedui have no pieces anywhere."""
        state = _make_state()
        assert node_a4(state) == "No"


# ===================================================================
# A5: Rally conditions
# ===================================================================

class TestNodeA5:
    """A5 decision node tests."""

    def test_yes_when_few_warbands(self):
        """Rally when fewer than 5 Warbands on map."""
        state = _make_state()
        _place_aedui_force(state, AEDUI_REGION, warbands=3)
        assert node_a5(state) == "Yes"

    def test_yes_when_zero_warbands(self):
        """Rally when zero Warbands on map."""
        state = _make_state()
        assert node_a5(state) == "Yes"

    def test_no_when_many_warbands_and_no_rally_benefit(self):
        """No Rally when 5+ Warbands and Rally wouldn't place enough."""
        state = _make_state()
        # Place 5+ Warbands on map with no rally opportunities
        _place_aedui_force(state, AEDUI_REGION, warbands=6)
        refresh_all_control(state)
        # Still might say Yes if Rally would place pieces — check carefully
        result = node_a5(state)
        # With Aedui control of Aedui region, Rally could place Warbands
        # This is scenario-dependent — we test the threshold logic works


# ===================================================================
# A6: Low resources and die roll
# ===================================================================

class TestNodeA6:
    """A6 decision node tests."""

    def test_no_when_resources_4_plus(self):
        """No Raid when Aedui have 4+ Resources."""
        state = _make_state()
        state["resources"][AEDUI] = 5
        assert node_a6(state) == "No"

    def test_depends_on_roll_when_low_resources(self):
        """Raid depends on die roll when Resources 0-3."""
        state = _make_state()
        state["resources"][AEDUI] = 2
        # Try multiple seeds; should get both outcomes
        results = set()
        for s in range(20):
            st = _make_state(seed=s)
            st["resources"][AEDUI] = 2
            results.add(node_a6(st))
        # Should see both Yes and No across different seeds
        assert "Yes" in results or "No" in results


# ===================================================================
# Battle estimation helpers
# ===================================================================

class TestBattleEstimation:
    """Test battle estimation helpers."""

    def test_estimate_losses_basic(self):
        """Basic loss estimation: 6 Warbands attack 2 Auxilia."""
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=6)
        place_piece(state, MANDUBII, ARVERNI, WARBAND, 4)
        losses_inflicted, losses_suffered = _estimate_battle_losses(
            state, MANDUBII, AEDUI, ARVERNI, SCENARIO_PAX_GALLICA)
        # 6 Warbands × 0.5 = 3 inflicted
        assert losses_inflicted == 3
        # 4 Warbands × 0.5 = 2 suffered
        assert losses_suffered == 2

    def test_estimate_losses_with_fort_halving(self):
        """Fort halves attack losses."""
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=6)
        place_piece(state, MANDUBII, ROMANS, AUXILIA, 4)
        place_piece(state, MANDUBII, ROMANS, FORT)
        losses_inflicted, _ = _estimate_battle_losses(
            state, MANDUBII, AEDUI, ROMANS, SCENARIO_PAX_GALLICA)
        # 6 × 0.5 = 3, halved by Fort = 1.5 → 1
        assert losses_inflicted == 1

    def test_would_force_high_value_loss(self):
        """Force loss on Ally when enemy has no expendable pieces."""
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=4)
        state["tribes"][TRIBE_MANDUBII]["allied_faction"] = ARVERNI
        place_piece(state, MANDUBII, ARVERNI, ALLY)
        # Arverni has only Ally, no Warbands — any loss hits it
        assert _would_force_loss_on_high_value(
            state, MANDUBII, AEDUI, ARVERNI, SCENARIO_PAX_GALLICA)

    def test_no_force_when_shielded(self):
        """Don't force high-value loss when shielded by expendable."""
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=2)
        state["tribes"][TRIBE_MANDUBII]["allied_faction"] = ARVERNI
        place_piece(state, MANDUBII, ARVERNI, ALLY)
        place_piece(state, MANDUBII, ARVERNI, WARBAND, 10)
        # 2 × 0.5 = 1 loss; 10 expendable → can't reach Ally
        assert not _would_force_loss_on_high_value(
            state, MANDUBII, AEDUI, ARVERNI, SCENARIO_PAX_GALLICA)

    def test_retreat_halves_losses_prevents_high_value(self):
        """Enemy Retreat halves losses — may protect high-value targets.

        Per §8.6.2: must account for "a possible enemy Retreat".
        6 Aedui Warbands → 3 raw losses.  Enemy has 1 Warband + Ally.
        Without Retreat: 3 losses > 1 expendable → hits Ally.
        With Retreat: 3/2=1 loss ≤ 1 expendable → does NOT reach Ally.
        """
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=6, hidden=False)
        state["tribes"][TRIBE_MANDUBII]["allied_faction"] = ARVERNI
        place_piece(state, MANDUBII, ARVERNI, ALLY)
        place_piece(state, MANDUBII, ARVERNI, WARBAND, 1)
        # Enemy has mobile pieces → could Retreat
        # Without ambush: losses halved → 1 loss ≤ 1 expendable
        assert not _would_force_loss_on_high_value(
            state, MANDUBII, AEDUI, ARVERNI, SCENARIO_PAX_GALLICA,
            ambush_possible=False)

    def test_ambush_prevents_retreat_forces_high_value(self):
        """Ambush prevents Retreat — full losses hit high-value target.

        Same setup as above, but with Ambush: enemy can't Retreat.
        """
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=6, hidden=False)
        state["tribes"][TRIBE_MANDUBII]["allied_faction"] = ARVERNI
        place_piece(state, MANDUBII, ARVERNI, ALLY)
        place_piece(state, MANDUBII, ARVERNI, WARBAND, 1)
        # With ambush: full 3 losses > 1 expendable → hits Ally
        assert _would_force_loss_on_high_value(
            state, MANDUBII, AEDUI, ARVERNI, SCENARIO_PAX_GALLICA,
            ambush_possible=True)

    def test_settlements_count_as_allies_in_ariovistus(self):
        """Per A8.6.2: count Settlements as Allies for Battle conditions.

        In Ariovistus, a lone Settlement is a high-value target like an Ally.
        """
        state = _make_state(scenario=SCENARIO_ARIOVISTUS)
        _place_aedui_force(state, SUGAMBRI, warbands=4, hidden=False)
        # German Settlement with no expendable pieces
        place_piece(state, SUGAMBRI, GERMANS, SETTLEMENT)
        # Any loss hits the Settlement → high-value
        assert _would_force_loss_on_high_value(
            state, SUGAMBRI, AEDUI, GERMANS, SCENARIO_ARIOVISTUS,
            ambush_possible=True)

    def test_settlements_not_counted_in_base_game(self):
        """Settlements do not count as high-value in base game scenarios.

        In Ariovistus, a lone Settlement triggers high-value. In base game,
        it would not (A8.6.2 only applies in Ariovistus). We test using
        Ariovistus scenario with a Settlement to confirm it IS counted,
        then compare against base scenario where def_settlements = 0
        (Germans can't have Settlements in base game — validated by the
        piece system).
        """
        # Ariovistus: Settlement counts → high-value
        state_a = _make_state(scenario=SCENARIO_ARIOVISTUS)
        _place_aedui_force(state_a, SUGAMBRI, warbands=4, hidden=False)
        place_piece(state_a, SUGAMBRI, GERMANS, SETTLEMENT)
        assert _would_force_loss_on_high_value(
            state_a, SUGAMBRI, AEDUI, GERMANS, SCENARIO_ARIOVISTUS,
            ambush_possible=True)

        # Base game: without Settlement, just Warbands → not high-value
        state_b = _make_state(scenario=SCENARIO_PAX_GALLICA)
        _place_aedui_force(state_b, MANDUBII, warbands=4, hidden=False)
        place_piece(state_b, MANDUBII, GERMANS, WARBAND, 2)
        # 2 losses vs 2 expendable → can't reach any high-value
        assert not _would_force_loss_on_high_value(
            state_b, MANDUBII, AEDUI, GERMANS, SCENARIO_PAX_GALLICA,
            ambush_possible=True)


# ===================================================================
# Battle enemies — victory gate
# ===================================================================

class TestBattleEnemies:
    """Test _get_battle_enemies victory gating for Romans."""

    def test_excludes_romans_when_not_at_victory(self):
        """Don't Battle Romans when Aedui not at victory."""
        state = _make_state()
        enemies = _get_battle_enemies(state, SCENARIO_PAX_GALLICA)
        assert ROMANS not in enemies

    def test_includes_gauls_and_germans(self):
        """Always Battle Gauls and Germans."""
        state = _make_state()
        enemies = _get_battle_enemies(state, SCENARIO_PAX_GALLICA)
        assert ARVERNI in enemies
        assert BELGAE in enemies
        assert GERMANS in enemies


# ===================================================================
# Rally process
# ===================================================================

class TestRally:
    """Test node_a_rally."""

    def test_rally_places_citadel_in_city(self):
        """Rally replaces City Ally with Citadel."""
        state = _make_state()
        state["resources"][AEDUI] = 10  # Rally costs 1/Region — §3.3.1
        _place_aedui_force(state, AEDUI_REGION, warbands=3,
                           ally_tribe=TRIBE_AEDUI)
        refresh_all_control(state)
        result = node_a_rally(state)
        assert result["command"] == ACTION_RALLY
        plan = result["details"]["rally_plan"]
        assert len(plan["citadels"]) > 0

    def test_rally_falls_through_to_raid_when_nothing(self):
        """Rally with nothing to place falls through to Raid."""
        state = _make_state()
        # No pieces on map, no available pieces useful
        # Zero out all available
        state["available"][AEDUI][WARBAND] = 0
        state["available"][AEDUI][ALLY] = 0
        state["available"][AEDUI][CITADEL] = 0
        result = node_a_rally(state)
        # Should fall through to Raid, then Pass
        assert result["command"] in (ACTION_RAID, ACTION_PASS)


# ===================================================================
# Raid process
# ===================================================================

class TestRaid:
    """Test node_a_raid."""

    def test_raid_passes_when_insufficient_gain(self):
        """Raid Passes when can't gain 2+ Resources."""
        state = _make_state()
        # No Hidden Warbands anywhere → no Raid possible
        result = node_a_raid(state)
        assert result["command"] == ACTION_PASS

    def test_raid_prefers_player_at_victory_over_nonroman_enemy(self, monkeypatch):
        """§8.6.4: Raid priority (1) players at 0+ victory margin before
        (2) other non-Roman enemies. In a Region holding both a player Belgae
        at victory and a Non-player Arverni, the steal targets Belgae.
        """
        import fs_bot.bots.aedui_bot as ab
        state = _make_state(non_players={AEDUI, ARVERNI})  # Belgae is a player
        state["resources"][BELGAE] = 5
        state["resources"][ARVERNI] = 5
        _place_aedui_force(state, MANDUBII, warbands=2, hidden=True)
        _place_enemy_force(state, MANDUBII, BELGAE, warbands=1)
        _place_enemy_force(state, MANDUBII, ARVERNI, warbands=1)
        refresh_all_control(state)
        # Control "at victory": Belgae at +1, everyone else below.
        monkeypatch.setattr(ab, "calculate_victory_margin",
                            lambda st, f: 1 if f == BELGAE else -1)
        _, plan = _would_raid_gain_enough(state, SCENARIO_PAX_GALLICA)
        mandubii = [e for e in plan if e["region"] == MANDUBII
                    and e["target"] is not None]
        assert mandubii and mandubii[0]["target"] == BELGAE

    def test_raid_works_with_hidden_warbands_and_targets(self):
        """Raid succeeds with Hidden Warbands near enemy."""
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=2, hidden=True)
        _place_aedui_force(state, CARNUTES, warbands=2, hidden=True)
        _place_enemy_force(state, MANDUBII, ARVERNI, warbands=2)
        _place_enemy_force(state, CARNUTES, BELGAE, warbands=2)
        enough, plan = _would_raid_gain_enough(state, SCENARIO_PAX_GALLICA)
        assert enough
        assert len(plan) >= 2


# ===================================================================
# March process
# ===================================================================

class TestMarch:
    """Test node_a_march."""

    def test_march_frost_redirects_to_raid(self):
        """March during Frost redirects to Raid."""
        state = _make_state()
        state["frost"] = True
        result = node_a_march(state)
        # Falls through to Raid, then Pass
        assert result["command"] in (ACTION_RAID, ACTION_PASS)

    def test_march_spreads_to_adjacent(self):
        """March spreads Hidden Aedui to adjacent regions."""
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=4, hidden=True)
        _place_enemy_force(state, AEDUI_REGION, ARVERNI,
                           ally_tribe=TRIBE_AEDUI)
        refresh_all_control(state)
        result = node_a_march(state)
        if result["command"] == ACTION_MARCH:
            plan = result["details"]["march_plan"]
            assert plan["origin"] is not None or plan["control_destination"]

    def test_march_does_not_spread_from_control_critical_region(self):
        """§8.6.5 'Lose no Aedui Control': the spread March must not move
        Warbands out of a Region if doing so would drop Aedui Control there
        (the planner now mirrors the executor's keep rule, not a bare leave-1).
        """
        # MANDUBII: 3 Aedui Warbands vs 2 Arverni Warbands -> Aedui Control (3>2),
        # and Control needs all 3 to stay, so 0 are spare.
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=3, hidden=True)
        _place_enemy_force(state, MANDUBII, ARVERNI, warbands=2)
        # An enemy Ally next door makes CARNUTES a tempting spread target.
        _place_enemy_force(state, CARNUTES, ARVERNI, ally_tribe=TRIBE_CARNUTES)
        refresh_all_control(state)
        assert is_controlled_by(state, MANDUBII, AEDUI)
        result = node_a_march(state)
        if result["command"] == ACTION_MARCH:
            plan = result["details"]["march_plan"]
            assert plan.get("origin") != MANDUBII

    def test_diviciacus_marches_to_largest_warband_group(self):
        """Per A8.6.5: Diviciacus joins largest Aedui Warband group.

        Place Diviciacus in Sequani (1 wb), largest group in Mandubii (5 wb).
        After March, diviciacus_destination should be Mandubii.
        """
        state = _make_state(scenario=SCENARIO_ARIOVISTUS)
        place_piece(state, SEQUANI, AEDUI, LEADER, leader_name=DIVICIACUS)
        _place_aedui_force(state, SEQUANI, warbands=2, hidden=True)
        _place_aedui_force(state, MANDUBII, warbands=5, hidden=True)
        refresh_all_control(state)
        result = node_a_march(state)
        if result["command"] == ACTION_MARCH:
            plan = result["details"]["march_plan"]
            assert plan.get("diviciacus_destination") == MANDUBII

    def test_diviciacus_stays_if_already_with_largest(self):
        """Per A8.6.5: no extra March if Diviciacus already with largest."""
        state = _make_state(scenario=SCENARIO_ARIOVISTUS)
        _place_aedui_force(state, MANDUBII, warbands=5, hidden=True)
        place_piece(state, MANDUBII, AEDUI, LEADER, leader_name=DIVICIACUS)
        _place_aedui_force(state, SEQUANI, warbands=2, hidden=True)
        refresh_all_control(state)
        result = node_a_march(state)
        if result["command"] == ACTION_MARCH:
            plan = result["details"]["march_plan"]
            assert plan.get("diviciacus_destination") is None


# ===================================================================
# Ambush check
# ===================================================================

class TestAmbush:
    """Test _check_ambush."""

    def test_ambush_when_retreat_helps_enemy(self):
        """Ambush when enemy retreat would lessen removals."""
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=6, hidden=True)
        place_piece(state, MANDUBII, ARVERNI, WARBAND, 3)
        battle_plan = [{"region": MANDUBII, "target": ARVERNI}]
        result = _check_ambush(state, battle_plan, SCENARIO_PAX_GALLICA)
        assert result == MANDUBII

    def test_no_ambush_when_hidden_insufficient(self):
        """No Ambush when fewer Hidden Aedui than Hidden enemy."""
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=1, hidden=True)
        place_piece(state, MANDUBII, ARVERNI, WARBAND, 3)
        battle_plan = [{"region": MANDUBII, "target": ARVERNI}]
        result = _check_ambush(state, battle_plan, SCENARIO_PAX_GALLICA)
        assert result is None


# ===================================================================
# Diviciacus counterattack safety — A8.6.2
# ===================================================================

class TestDiviciacusCounterattackSafety:
    """Per A8.6.2: do not Battle where Diviciacus could take counterattack Loss."""

    def test_skip_battle_where_diviciacus_would_take_loss(self):
        """Skip Battle region if counterattack would hit Diviciacus.

        Diviciacus in Mandubii with 1 Warband vs Belgae with 4 Warbands.
        Counterattack: 4×0.5 = 2 losses. Expendable = 1 Warband.
        2 >= 1 → Diviciacus would take a hit → skip.
        """
        state = _make_state(scenario=SCENARIO_ARIOVISTUS)
        state["can_play_event"] = False
        place_piece(state, MANDUBII, AEDUI, LEADER, leader_name=DIVICIACUS)
        _place_aedui_force(state, MANDUBII, warbands=1, hidden=False)
        _place_enemy_force(state, MANDUBII, BELGAE, warbands=4)
        # Also need an Ally to trigger high-value check
        state["tribes"][TRIBE_MANDUBII]["allied_faction"] = BELGAE
        place_piece(state, MANDUBII, BELGAE, ALLY)
        refresh_all_control(state)
        result = node_a_battle(state)
        # Should skip Mandubii because Diviciacus would take a counterattack hit
        battle_regions = [bp["region"] for bp in
                          result.get("details", {}).get("battle_plan", [])]
        assert MANDUBII not in battle_regions

    def test_allow_battle_where_diviciacus_safe(self):
        """Allow Battle if Diviciacus wouldn't take counterattack Loss.

        Diviciacus in Mandubii with 6 Warbands vs enemy with only Ally.
        Counterattack: 0 → Diviciacus safe.
        """
        state = _make_state(scenario=SCENARIO_ARIOVISTUS)
        state["can_play_event"] = False
        place_piece(state, MANDUBII, AEDUI, LEADER, leader_name=DIVICIACUS)
        _place_aedui_force(state, MANDUBII, warbands=6, hidden=False)
        state["tribes"][TRIBE_MANDUBII]["allied_faction"] = BELGAE
        place_piece(state, MANDUBII, BELGAE, ALLY)
        refresh_all_control(state)
        result = node_a_battle(state)
        # Should include Mandubii — counterattack is 0
        if result["command"] == ACTION_BATTLE:
            battle_regions = [bp["region"] for bp in
                              result["details"]["battle_plan"]]
            assert MANDUBII in battle_regions


# ===================================================================
# Trade SA
# ===================================================================

class TestTrade:
    """Test Trade SA determination."""

    def test_trade_when_battled_and_second_eligible(self):
        """Trade after Battle when 2nd Eligible."""
        state = _make_state()
        state["is_second_eligible"] = True
        # Give Aedui some controlled regions with enemy pieces
        _place_aedui_force(state, AEDUI_REGION, warbands=6,
                           ally_tribe=TRIBE_AEDUI)
        _place_roman_force(state, AEDUI_REGION, auxilia=2)
        refresh_all_control(state)
        sa, regions, details = _determine_trade_sa(
            state, SCENARIO_PAX_GALLICA, battled=True)
        assert sa == SA_ACTION_TRADE

    def test_no_trade_when_resources_high_and_not_battled(self):
        """No Trade when Resources >= 10 and not Battled."""
        state = _make_state()
        state["resources"][AEDUI] = 15
        state["resources"][ROMANS] = 10
        sa, _, _ = _determine_trade_sa(
            state, SCENARIO_PAX_GALLICA, battled=False)
        # Should fall through to Suborn
        assert sa in (SA_ACTION_SUBORN, SA_ACTION_NONE)

    def test_trade_estimate_counts_aedui_allies_and_citadels(self):
        """Trade estimate counts Aedui Allies + Citadels per §4.4.1.

        Not Aedui-Controlled regions with other factions' pieces.
        """
        state = _make_state(
            non_players={ARVERNI, BELGAE, AEDUI, ROMANS})
        # Place Aedui Ally and Citadel on map
        _place_aedui_force(state, AEDUI_REGION, warbands=3,
                           ally_tribe=TRIBE_AEDUI, citadel=True)
        _place_aedui_force(state, MANDUBII, ally_tribe=TRIBE_MANDUBII)
        refresh_all_control(state)
        est = _estimate_trade_resources(state, SCENARIO_PAX_GALLICA)
        # 2 Allies + 1 Citadel = 3 base; NP Romans agree → ×2 = 6 + subdued
        # At minimum, estimate should be >= 6 (the Aedui pieces)
        assert est >= 6

    def test_trade_estimate_matches_real_trade_mechanic(self):
        """The Trade estimate equals the actual Trade gain (real §3.2.1 Supply
        Lines, §4.4.1 yields) — no approximation. With no Aedui Allies/Citadels
        but a Subdued Tribe in the Aedui-Controlled Aedui Region, §4.4.1 yields
        +1 for that Subdued Tribe (even without Roman agreement), so the
        estimate reflects it (not 0, as the old approximation assumed)."""
        import copy
        from fs_bot.commands.sa_trade import trade
        from fs_bot.engine.victory import calculate_victory_score
        state = _make_state()
        _place_aedui_force(state, AEDUI_REGION, warbands=3)
        refresh_all_control(state)
        # Mirror the function's Roman-agreement determination: the estimate
        # always assumes agreement (NP Rome per §8.6.3; player Rome resolves
        # live at execution — see QUESTIONS.md).
        expected = trade(copy.deepcopy(state),
                         roman_agreed=True)["resources_gained"]
        est = _estimate_trade_resources(state, SCENARIO_PAX_GALLICA)
        assert est == expected

    def test_trade_estimate_assumes_player_roman_agreement(self):
        """Trade estimate assumes a player Rome agrees, at any victory score.

        The old heuristic assumed refusal at Roman victory score >= 10 and
        halved the estimate. The estimate now always assumes agreement (the
        alliance default; actual declaration resolves at execution), so the
        yield is doubled regardless of Rome's score. See QUESTIONS.md.
        """
        from fs_bot.engine.victory import calculate_victory_score
        state = _make_state(non_players={ARVERNI, BELGAE, AEDUI})
        # Romans are player faction — not in non_players
        _place_aedui_force(state, AEDUI_REGION, warbands=3,
                           ally_tribe=TRIBE_AEDUI, citadel=True)
        refresh_all_control(state)
        # Give Romans a high victory score — must no longer matter
        count = 0
        for tribe_name, tribe_info in state["tribes"].items():
            if count >= 15:
                break
            if tribe_info.get("allied_faction") is None:
                tribe_info["allied_faction"] = ROMANS
                count += 1
        assert calculate_victory_score(state, ROMANS) >= 10
        est = _estimate_trade_resources(state, SCENARIO_PAX_GALLICA)
        # 1 Ally + 1 Citadel = 2 base, agreement assumed → at least 4
        assert est >= 4

    def test_trade_triggers_with_player_rome_at_high_score(self):
        """Regression: Trade triggers when only Roman agreement clears >2.

        Player Rome at victory score >= 10, Aedui poor (precondition met),
        not 2nd Eligible: 1 Ally + 1 Citadel yields 2 un-doubled (old
        heuristic: no trigger, fell through to Suborn) but >2 with the
        agreement now assumed — so Trade must trigger (§8.6.3).
        """
        from fs_bot.engine.victory import calculate_victory_score
        state = _make_state(non_players={ARVERNI, BELGAE, AEDUI})
        state["resources"][AEDUI] = 4          # precondition: 0-9
        state["is_second_eligible"] = False    # trigger must come from >2
        _place_aedui_force(state, AEDUI_REGION, warbands=3,
                           ally_tribe=TRIBE_AEDUI, citadel=True)
        refresh_all_control(state)
        count = 0
        for tribe_name, tribe_info in state["tribes"].items():
            if count >= 15:
                break
            if tribe_info.get("allied_faction") is None:
                tribe_info["allied_faction"] = ROMANS
                count += 1
        assert calculate_victory_score(state, ROMANS) >= 10
        sa, regions, details = _determine_trade_sa(
            state, SCENARIO_PAX_GALLICA, battled=False)
        assert sa == SA_ACTION_TRADE
        assert details["trade_resources"] > 2

    def test_executed_trade_np_rome_pays_agreed_rate(self):
        """_execute_trade resolves NP Roman agreement — §8.6.3 (always agree).

        Regression: the executor used to call trade() with the default
        roman_agreed=False, paying the un-doubled rate even in all-bot games.
        """
        import copy
        from fs_bot.commands.sa_trade import trade
        from fs_bot.engine.execute import _execute_trade
        state = _make_state(
            non_players={ARVERNI, BELGAE, AEDUI, ROMANS})
        _place_aedui_force(state, AEDUI_REGION, warbands=3,
                           ally_tribe=TRIBE_AEDUI, citadel=True)
        refresh_all_control(state)
        expected = trade(copy.deepcopy(state),
                         roman_agreed=True)["resources_gained"]
        result = _execute_trade(state, AEDUI)
        assert result["executed"] is True
        assert result["result"]["resources_gained"] == expected

    def test_executed_trade_player_rome_consults_agent(self):
        """_execute_trade asks a player Rome via the AGREEMENT agent hook.

        Agent refusal → un-doubled rate; no agent (or defer) → the alliance
        default applies and the Romans are treated as agreeing.
        """
        import copy
        from fs_bot.commands.sa_trade import trade
        from fs_bot.engine.execute import _execute_trade

        def _fresh():
            st = _make_state(non_players={ARVERNI, BELGAE, AEDUI})
            _place_aedui_force(st, AEDUI_REGION, warbands=3,
                               ally_tribe=TRIBE_AEDUI, citadel=True)
            refresh_all_control(st)
            return st

        # Player Rome refuses via the agent hook.
        state = _fresh()
        seen = []

        def refuse(st, faction, request):
            if (faction == ROMANS
                    and request.get("request_type")
                    == "trade_roman_agreement"):
                seen.append(request)
                return False
            return None

        state["decision_agent"] = refuse
        base = trade(copy.deepcopy(state),
                     roman_agreed=False)["resources_gained"]
        result = _execute_trade(state, AEDUI)
        assert seen, "agent was not consulted for Roman Trade agreement"
        assert result["result"]["resources_gained"] == base

        # No agent: default is agreement (doubled).
        state2 = _fresh()
        doubled = trade(copy.deepcopy(state2),
                        roman_agreed=True)["resources_gained"]
        result2 = _execute_trade(state2, AEDUI)
        assert result2["result"]["resources_gained"] == doubled
        assert doubled > base


# ===================================================================
# Suborn SA
# ===================================================================

class TestSuborn:
    """Test Suborn SA determination."""

    def test_suborn_places_ally(self):
        """Suborn places Aedui Ally on empty tribe."""
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=2, hidden=True)
        sa, regions, details = _determine_suborn_sa(
            state, SCENARIO_PAX_GALLICA)
        if sa == SA_ACTION_SUBORN:
            plan = details["suborn_plan"]
            assert len(plan) > 0
            has_place_ally = any(
                a["action"] == "place_ally"
                for sp in plan for a in sp["actions"]
            )
            assert has_place_ally

    def test_suborn_remove_ally_skips_citadel_tribe(self):
        """§4.4.2: Suborn removes an Ally disc, not a Citadel. When a Region
        holds both an enemy Ally (on a non-city tribe) and an enemy Citadel
        (on the city tribe), the planner must target the Ally-backed tribe so
        the executor does not refuse ('No Arverni Ally to remove') and does
        not clear the wrong (Citadel) tribe.
        """
        state = _make_state()
        state["resources"][AEDUI] = 10
        _place_aedui_force(state, CARNUTES, warbands=2, hidden=True)
        # Arverni Ally on Aulerci (non-city) and Citadel on Carnutes (city).
        place_piece(state, CARNUTES, ARVERNI, ALLY)
        state["tribes"][TRIBE_AULERCI]["allied_faction"] = ARVERNI
        place_piece(state, CARNUTES, ARVERNI, CITADEL)
        state["tribes"][TRIBE_CARNUTES]["allied_faction"] = ARVERNI
        refresh_all_control(state)
        sa, regions, details = _determine_suborn_sa(state, SCENARIO_PAX_GALLICA)
        assert sa == SA_ACTION_SUBORN
        removes = [a for sp in details["suborn_plan"]
                   for a in sp["actions"] if a["action"] == "remove_ally"]
        assert removes, "expected a remove_ally once both tribes are allied"
        for a in removes:
            assert a["tribe"] == TRIBE_AULERCI
            assert a["tribe"] != TRIBE_CARNUTES

    def test_suborn_no_remove_ally_when_only_citadel(self):
        """§4.4.2: a Citadel-only enemy presence has no removable Ally disc;
        the planner must not propose remove_ally there.
        """
        state = _make_state()
        state["resources"][AEDUI] = 10
        _place_aedui_force(state, CARNUTES, warbands=2, hidden=True)
        # Only an Arverni Citadel (city tribe), no Ally disc anywhere.
        place_piece(state, CARNUTES, ARVERNI, CITADEL)
        state["tribes"][TRIBE_CARNUTES]["allied_faction"] = ARVERNI
        refresh_all_control(state)
        sa, regions, details = _determine_suborn_sa(state, SCENARIO_PAX_GALLICA)
        if sa == SA_ACTION_SUBORN:
            removes = [a for sp in details["suborn_plan"]
                       for a in sp["actions"]
                       if a["action"] == "remove_ally"
                       and a.get("target_faction") == ARVERNI]
            assert removes == []

    def test_suborn_skips_faction_restricted_tribe_for_ally(self):
        """§1.4.2: cannot place an Aedui Ally at a Tribe restricted to another
        Faction (Suebi -> Germans). The planner must not propose place_ally
        there (executor refuses 'Cannot place Aedui Ally at Suebi ...').
        """
        state = _make_state()
        state["resources"][AEDUI] = 10
        _place_aedui_force(state, SUGAMBRI, warbands=2, hidden=True)
        sa, regions, details = _determine_suborn_sa(state, SCENARIO_PAX_GALLICA)
        if sa == SA_ACTION_SUBORN:
            for sp in details["suborn_plan"]:
                for a in sp["actions"]:
                    if a["action"] == "place_ally":
                        assert a["tribe"] != TRIBE_SUEBI_NORTH

    def test_suborn_needs_hidden_warband(self):
        """Suborn requires Hidden Aedui Warband in region."""
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=2, hidden=False)
        sa, _, _ = _determine_suborn_sa(state, SCENARIO_PAX_GALLICA)
        assert sa == SA_ACTION_NONE

    def test_suborn_caps_at_3_pieces_per_region(self):
        """Suborn enforces §4.4.2 cap of 3 pieces per region.

        Place 1 Ally (1 piece, 1 ally) + should cap Warbands/removals at 2 more.
        """
        state = _make_state()
        state["resources"][AEDUI] = 10  # Suborn costs 2/Ally, 1/piece — §4.4.2
        _place_aedui_force(state, MANDUBII, warbands=2, hidden=True)
        # Lots of available Warbands and enemy pieces to affect
        state["available"][AEDUI][WARBAND] = 10
        _place_enemy_force(state, MANDUBII, ARVERNI, warbands=5)
        _place_enemy_force(state, MANDUBII, BELGAE, warbands=3)
        _place_roman_force(state, MANDUBII, auxilia=2)
        sa, regions, details = _determine_suborn_sa(
            state, SCENARIO_PAX_GALLICA)
        assert sa == SA_ACTION_SUBORN
        plan = details["suborn_plan"]
        for region_entry in plan:
            assert len(region_entry["actions"]) <= 3

    def test_suborn_caps_at_1_ally_per_region(self):
        """Suborn enforces §4.4.2 cap of 1 Ally per region.

        Even with available Allies, only 1 Ally action per region.
        """
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=2, hidden=True)
        state["available"][AEDUI][ALLY] = 5
        sa, regions, details = _determine_suborn_sa(
            state, SCENARIO_PAX_GALLICA)
        if sa == SA_ACTION_SUBORN:
            plan = details["suborn_plan"]
            for region_entry in plan:
                ally_actions = [
                    a for a in region_entry["actions"]
                    if a["action"] in ("place_ally", "remove_ally")
                ]
                assert len(ally_actions) <= 1


# ===================================================================
# Quarters
# ===================================================================

class TestQuarters:
    """Test node_a_quarters."""

    def test_leaves_devastated_without_ally(self):
        """Leave Devastated region with no Ally/Citadel."""
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=3)
        state["spaces"][MANDUBII]["devastated"] = True
        plan = node_a_quarters(state)
        assert len(plan["leave_devastated"]) > 0
        assert plan["leave_devastated"][0]["from"] == MANDUBII

    def test_stays_in_devastated_with_ally(self):
        """Stay in Devastated region when Ally present."""
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=3,
                           ally_tribe=TRIBE_MANDUBII)
        state["spaces"][MANDUBII]["devastated"] = True
        plan = node_a_quarters(state)
        assert len(plan["leave_devastated"]) == 0


# ===================================================================
# Agreements
# ===================================================================

class TestAgreements:
    """Test node_a_agreements."""

    def test_harass_arverni_not_romans(self):
        """Harass Vercingetorix but NOT Romans."""
        state = _make_state()
        assert node_a_agreements(state, ARVERNI, "harassment") is True
        assert node_a_agreements(state, ROMANS, "harassment") is False

    def test_never_agree_retreat_arverni(self):
        """Never agree to Retreat for Arverni."""
        state = _make_state()
        assert node_a_agreements(state, ARVERNI, "retreat") is False

    def test_agree_retreat_np_roman(self):
        """Always agree to Retreat for NP Roman."""
        state = _make_state(non_players={ARVERNI, BELGAE, AEDUI, ROMANS})
        assert node_a_agreements(state, ROMANS, "retreat") is True

    def test_transfer_resources_to_romans(self):
        """Transfer to NP Romans when Romans low, Aedui high (§8.6.6)."""
        state = _make_state(
            non_players={ARVERNI, BELGAE, AEDUI, ROMANS})
        state["resources"][ROMANS] = 1
        state["resources"][AEDUI] = 25
        assert node_a_agreements(state, ROMANS, "resources") is True

    def test_transfer_gated_by_player_roman_score(self):
        """§8.6.6 NOTE: the transfer honours the player-Roman victory
        tiers — score < 10 yes, above 12 never."""
        state = _make_state()          # Romans are a player here
        state["resources"][ROMANS] = 1
        state["resources"][AEDUI] = 25
        # Bare board: every Tribe Subdued counts for Rome — score > 12,
        # so a player Rome gets nothing.
        from fs_bot.engine.victory import calculate_victory_score
        assert calculate_victory_score(state, ROMANS) > 12
        assert node_a_agreements(state, ROMANS, "resources") is False
        # Ally most Tribes to the Arverni to push the Roman score < 10.
        count = 0
        for tribe_name, tribe_info in state["tribes"].items():
            if tribe_info.get("allied_faction") is None and count < 25:
                tribe_info["allied_faction"] = ARVERNI
                count += 1
        assert calculate_victory_score(state, ROMANS) < 10
        assert node_a_agreements(state, ROMANS, "resources") is True

    def test_no_transfer_when_aedui_low(self):
        """No transfer when Aedui Resources < 21."""
        state = _make_state()
        state["resources"][ROMANS] = 0
        state["resources"][AEDUI] = 15
        assert node_a_agreements(state, ROMANS, "resources") is False

    def test_no_transfer_to_arverni(self):
        """Never transfer Resources to Arverni."""
        state = _make_state()
        state["resources"][AEDUI] = 30
        assert node_a_agreements(state, ARVERNI, "resources") is False

    def test_frumentum_transfer_to_np_romans(self):
        """Per A8.6.6: Frumentum transfers half Resources to NP Romans."""
        state = _make_state(
            scenario=SCENARIO_ARIOVISTUS,
            non_players={ARVERNI, BELGAE, AEDUI, ROMANS})
        state["resources"][AEDUI] = 20
        result = node_a_agreements(state, ROMANS, "frumentum_transfer")
        assert isinstance(result, dict)
        assert result["agree"] is True
        assert result["amount"] == 10  # half of 20

    def test_frumentum_no_transfer_to_player_romans(self):
        """Per A8.6.6: no Frumentum transfer to player Romans."""
        state = _make_state(
            scenario=SCENARIO_ARIOVISTUS,
            non_players={ARVERNI, BELGAE, AEDUI})
        state["resources"][AEDUI] = 20
        result = node_a_agreements(state, ROMANS, "frumentum_transfer")
        assert result is False

    def test_admagetobriga_aedui_agree_with_executor_pieces(self):
        """Provisional PR-02: Aedui lend when the executor joins Battle."""
        state = _make_state(scenario=SCENARIO_ARIOVISTUS)
        _place_roman_force(state, MANDUBII, auxilia=2)
        result = node_a_agreements(
            state, ROMANS, "admagetobriga_warbands",
            context={"region": MANDUBII, "executing_faction": ROMANS})
        assert result is True

    def test_admagetobriga_aedui_refuse_without_executor_pieces(self):
        """Provisional PR-02: Aedui refuse when the executor is absent."""
        state = _make_state(scenario=SCENARIO_ARIOVISTUS)
        # No Roman pieces in Mandubii
        result = node_a_agreements(
            state, ROMANS, "admagetobriga_warbands",
            context={"region": MANDUBII, "executing_faction": ROMANS})
        assert result is False

    def test_refuse_germans_retreat_in_ariovistus(self):
        """Per A8.4: refuse Germans (not Arverni) in Ariovistus.

        In Ariovistus, Germans replace Arverni as the hostile faction,
        so Aedui refuse Retreat/Supply/Quarters to Germans and Belgae.
        """
        state = _make_state(scenario=SCENARIO_ARIOVISTUS)
        # Germans should be refused
        assert node_a_agreements(state, GERMANS, "retreat") is False
        assert node_a_agreements(state, GERMANS, "supply_line") is False
        assert node_a_agreements(state, GERMANS, "quarters") is False
        # Belgae still refused
        assert node_a_agreements(state, BELGAE, "retreat") is False

    def test_arverni_not_refused_retreat_in_ariovistus(self):
        """Per A8.4: Arverni are game-run in Ariovistus.

        Arverni won't normally request in Ariovistus, but if they did,
        they are NOT in the refuse list (Germans replaced them).
        """
        state = _make_state(scenario=SCENARIO_ARIOVISTUS)
        # Arverni not in refuse list — falls through to other logic
        # (returns False because Arverni are not Romans either)
        result = node_a_agreements(state, ARVERNI, "retreat")
        # Not refused by the faction check — falls to the end → False
        assert result is False

    def test_refuse_arverni_retreat_in_base_game(self):
        """In base game, still refuse Arverni per §8.6.6."""
        state = _make_state(scenario=SCENARIO_PAX_GALLICA)
        assert node_a_agreements(state, ARVERNI, "retreat") is False
        assert node_a_agreements(state, ARVERNI, "supply_line") is False


# ===================================================================
# Diviciacus
# ===================================================================

class TestDiviciacus:
    """Test node_a_diviciacus."""

    def test_inactive_without_capability(self):
        """No Diviciacus effect without capability."""
        state = _make_state()
        assert node_a_diviciacus(state, {"phase": "roman_command"}) is False

    def test_agrees_during_roman_command_low_score(self):
        """Agrees during Roman Command when victory < 13."""
        state = _make_state()
        from fs_bot.cards.card_effects import execute_event
        execute_event(state, 38)
        # Roman victory = subdued + dispersed + roman_allies — §7.2
        # In empty state all tribes are subdued (score ~30), so we need to
        # give most tribes an allied_faction to reduce subdued count below 13.
        count = 0
        for tribe_name, tribe_info in state["tribes"].items():
            if count >= 20:
                break
            tribe_info["allied_faction"] = ARVERNI  # Not Roman → not subdued
            count += 1
        # Now Roman score = remaining subdued (<= 10) + 0 dispersed + 0 allies
        assert node_a_diviciacus(
            state, {"phase": "roman_command"}) is True

    def test_refuses_during_roman_command_high_score(self):
        """Refuses during Roman Command when victory >= 13."""
        state = _make_state()
        from fs_bot.cards.card_effects import execute_event
        execute_event(state, 38)
        # Set many tribes to subdued/dispersed/allied to push Roman score up
        # Roman score = subdued + dispersed + roman_allies
        # We need >= 13
        count = 0
        for tribe_name, tribe_info in state["tribes"].items():
            if count >= 13:
                break
            tribe_info["allied_faction"] = ROMANS
            count += 1
        assert node_a_diviciacus(
            state, {"phase": "roman_command"}) is False

    def test_refuses_when_scouting_aedui(self):
        """Refuses when Romans are Scouting Aedui."""
        state = _make_state()
        from fs_bot.cards.card_effects import execute_event
        execute_event(state, 38)
        assert node_a_diviciacus(
            state, {"phase": "roman_command",
                    "action": "scout", "target": AEDUI}) is False


# ===================================================================
# Full flowchart driver
# ===================================================================

class TestExecuteAeduiTurn:
    """Test execute_aedui_turn main driver."""

    def test_runs_in_base_scenario(self):
        """Aedui bot runs in base game scenarios."""
        state = _make_state(scenario=SCENARIO_PAX_GALLICA)
        state["can_play_event"] = False
        result = execute_aedui_turn(state)
        assert "command" in result

    def test_runs_in_ariovistus_scenario(self):
        """Aedui bot runs in Ariovistus scenarios."""
        state = _make_state(scenario=SCENARIO_ARIOVISTUS)
        state["can_play_event"] = False
        result = execute_aedui_turn(state)
        assert "command" in result

    def test_pass_on_a1(self):
        """Full flowchart passes on A1 condition."""
        # Find a seed that gives roll 1-4
        for s in range(100):
            state = _make_state(seed=s)
            state["next_card_faction_order"] = [AEDUI, ROMANS]
            state["current_card_faction_order"] = [ROMANS, AEDUI]
            result = execute_aedui_turn(state)
            if result["command"] == ACTION_PASS:
                break
        assert result["command"] == ACTION_PASS

    def test_event_on_a2_a3(self):
        """Full flowchart plays Event when A2=Yes and A3=No."""
        state = _make_state()
        state["can_play_event"] = True
        state["current_card_id"] = 9  # Mons Cevenna — normal card
        from fs_bot.rules_consts import SEQUANI
        place_piece(state, SEQUANI, AEDUI, WARBAND)
        # Make sure A1 says No
        state["next_card_faction_order"] = [ROMANS, AEDUI]
        state["current_card_faction_order"] = [ROMANS, AEDUI]
        result = execute_aedui_turn(state)
        assert result["command"] == ACTION_EVENT

    def test_battle_on_a4(self):
        """Full flowchart Battles on A4 condition."""
        state = _make_state()
        state["resources"][AEDUI] = 1
        state["can_play_event"] = False
        # Place forces to trigger A4
        _place_aedui_force(state, MANDUBII, warbands=6)
        state["tribes"][TRIBE_MANDUBII]["allied_faction"] = ARVERNI
        place_piece(state, MANDUBII, ARVERNI, ALLY)
        refresh_all_control(state)
        result = execute_aedui_turn(state)
        assert result["command"] == ACTION_BATTLE

    def test_rally_on_a5(self):
        """Full flowchart Rallies on A5 condition (few Warbands)."""
        state = _make_state()
        state["can_play_event"] = False
        state["resources"][AEDUI] = 10  # Rally costs 1/Region — §3.3.1
        # Place few Warbands + Ally so Rally has somewhere to place
        _place_aedui_force(state, AEDUI_REGION, warbands=2,
                           ally_tribe=TRIBE_AEDUI)
        refresh_all_control(state)
        result = execute_aedui_turn(state)
        # Should Rally (A5 triggers on <5 Warbands)
        assert result["command"] == ACTION_RALLY

    def test_dispatch_routes_to_aedui(self):
        """bot_dispatch routes Aedui faction to aedui_bot."""
        state = _make_state()
        state["can_play_event"] = False
        result = dispatch_bot_turn(state, AEDUI)
        assert "command" in result


# ===================================================================
# Raid estimation
# ===================================================================

class TestRaidEstimation:
    """Test _would_raid_gain_enough."""

    def test_no_gain_without_hidden_warbands(self):
        """No raid gain without Hidden Warbands."""
        state = _make_state()
        enough, plan = _would_raid_gain_enough(state, SCENARIO_PAX_GALLICA)
        assert not enough

    def test_gain_with_targets(self):
        """Gain Resources raiding enemy-occupied regions."""
        state = _make_state()
        _place_aedui_force(state, MANDUBII, warbands=2, hidden=True)
        _place_aedui_force(state, CARNUTES, warbands=2, hidden=True)
        place_piece(state, MANDUBII, ARVERNI, WARBAND, 2)
        place_piece(state, CARNUTES, BELGAE, WARBAND, 2)
        enough, plan = _would_raid_gain_enough(state, SCENARIO_PAX_GALLICA)
        assert enough
        assert len(plan) >= 2

    def test_no_raid_romans_when_np(self):
        """Don't raid NP Romans."""
        state = _make_state(non_players={ARVERNI, BELGAE, AEDUI, ROMANS})
        _place_aedui_force(state, MANDUBII, warbands=2, hidden=True)
        place_piece(state, MANDUBII, ROMANS, AUXILIA, 2)
        # Only Romans in the region — should not raid them as NP
        enough, plan = _would_raid_gain_enough(state, SCENARIO_PAX_GALLICA)
        # Check plan doesn't target Romans
        roman_targets = [p for p in plan if p.get("target") == ROMANS]
        assert len(roman_targets) == 0
