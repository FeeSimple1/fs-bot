"""Restore only the parent Harvest/Senate functions in an isolated process."""
import ast
import hashlib
import json
from pathlib import Path
import sys

from fs_bot import rules_consts as rc
from fs_bot.engine import winter
from fs_bot.cards import card_effects
from fs_bot.tools.balance_smoke import SCENARIOS, play_bot_game
from fs_bot.tools.validation_metadata import source_identity

parent = Path(sys.argv[1])
output = Path(sys.argv[2])
restored = {}
for module, relative, names in [
    (winter, 'fs_bot/engine/winter.py',
     {'harvest_phase', '_harvest_earnings', 'senate_phase', '_senate_marker_shift'}),
    (card_effects, 'fs_bot/cards/card_effects.py', {'_apply_senate_shift'}),
]:
    path = parent / relative
    raw = path.read_bytes()
    nodes = [node for node in ast.parse(raw).body
             if isinstance(node, ast.FunctionDef) and node.name in names]
    assert {node.name for node in nodes} == names
    namespace = dict(module.__dict__)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec'), namespace)
    for name in names:
        setattr(module, name, namespace[name])
    restored[relative] = {'file_sha256': hashlib.sha256(raw).hexdigest(),
                          'functions': sorted(names)}

records = {}
for scenario in SCENARIOS:
    for seed in range(1, 21):
        record = play_bot_game(scenario, seed)
        records[f'{scenario}|{seed}'] = record
    print(scenario, 'complete', flush=True)
expected = json.loads((output.parent / 'parent/balance.json').read_text())['games']
assert set(records) == set(expected)
assert records == expected, {k: [expected[k], records[k]] for k in records
                             if records[k] != expected[k]}
output.write_text(json.dumps({
    'source': source_identity(),
    'counterfactual': 'Only parent Harvest and Senate behavior restored in memory; '
                      'the repaired Scout and Battle paths remain active.',
    'restored': restored, 'games': records,
    'all_100_winners_and_lengths_match_parent': True,
}, indent=2) + '\n')
print('All 100 counterfactual outcomes match the parent exactly.', flush=True)
