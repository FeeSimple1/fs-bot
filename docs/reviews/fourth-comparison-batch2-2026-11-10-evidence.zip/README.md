# Batch 2 verification

Run from the repository root on the matching Python source. Use fresh output
paths and the listed hash seeds. The parent is 55fa4847f3da9112ec1c6d42542341f12859297d.

```sh
python -m pytest -q -n 4 --junitxml=pytest.xml
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 25-28 --card-edition second-edition --workers 2 --out bots
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 25-28 --card-edition second-edition --out fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 25-28 --card-edition second-edition --out fuzz987.json
cmp fuzz0.json fuzz987.json
PYTHONHASHSEED=0 PYTHONPATH="$PWD" python run_balance.py balance.json
```

Both pytest commands use pytest with pytest-xdist available for the full
suite. Copy the repaired test_comparison_event_commands.py outside the
parent checkout and run pytest on that path with PYTHONPATH pointing at
the parent to reproduce the failed cases. The legacy grants probe uses that
same test file alongside the script. Run it on the parent with the
arguments legacy-grants-parent.json parent, then on the repair with
legacy-grants-parent.json repair.

To reproduce the game traces, run trace_game_changes.py with the parent
output directory, repaired output directory, and output filename. Run
once from each checkout with PYTHONHASHSEED=0 and PYTHONPATH pointing
at that checkout. changed-outcomes.json records the first differing
draw from identical starting boards and the ending outcomes.
