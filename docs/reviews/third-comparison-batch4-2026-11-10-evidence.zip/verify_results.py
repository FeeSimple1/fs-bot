"""Verify source identities, exact coverage, audit fields and paired results."""
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

repo = Path(sys.argv[1]).resolve()
out = Path(__file__).resolve().parent
sys.path.insert(0, str(repo))
from fs_bot import rules_consts as rc
from fs_bot.tools.validation_metadata import source_identity


def read(name):
    return json.loads((out / name).read_text())


def counts(name):
    suites = list(ET.parse(out / name).getroot().iter('testsuite'))
    return {key: sum(int(suite.get(key, 0)) for suite in suites)
            for key in ('tests', 'failures', 'errors', 'skipped')}


identity = read('source.json')
assert source_identity()['source_sha256'] == identity['source_sha256']
unit, parent = counts('pytest.xml'), counts('parent-regressions.xml')
assert unit == {'tests': 9686, 'failures': 0, 'errors': 0, 'skipped': 0}, unit
assert parent == {'tests': 104, 'failures': 68, 'errors': 0, 'skipped': 0}, parent
keys = {(s, n) for s in rc.ALL_SCENARIOS for n in range(21, 25)}
bots = [json.loads(line) for line in (out / 'bots/games.jsonl').read_text().splitlines()]
assert len(bots) == len(keys) and {(r['scenario'], r['seed']) for r in bots} == keys
assert read('bots/metadata.json')['source_sha256'] == identity['source_sha256']
for row in bots:
    assert row['source_sha256'] == identity['source_sha256']
    assert all(row[k] for k in ('completed', 'game_completed', 'audit_completed'))
    assert not row['errors'] and not row['integrity_findings']
    assert all(d['severity'] == 'legal-decline' for d in row['diagnostics'])
    assert len(row['final_ranking']) == 4 and row['final_state_sha256']
    assert not row['engine_ranking_output_missing'] and not row['winner_differs_from_highest_margin']
old_bots = {(r['scenario'], r['seed']): r for r in
            map(json.loads, (out / 'parent/bots/games.jsonl').read_text().splitlines())}
parent_sha = '407a932c9ded7d54facf434fff2c24c1e0837af3f565166ae51604ae0308851c'
assert read('parent/source.json')['source_sha256'] == parent_sha
assert all(r['source_sha256'] == parent_sha for r in old_bots.values())
fuzz = read('fuzz0.json')
assert fuzz == read('fuzz987.json')
assert (out / 'fuzz0.txt').read_bytes() == (out / 'fuzz987.txt').read_bytes()
assert fuzz['metadata']['source_sha256'] == identity['source_sha256']
assert all(fuzz['metadata'][k] for k in ('reactive', 'events', 'replay'))
assert fuzz['games'] == 20 and fuzz['hard_findings'] == 0
assert {(r['scenario'], r['seed']) for r in fuzz['records']} == keys
assert all(r['game_completed'] and not r['findings'] for r in fuzz['records'])
balance = read('balance.json')
assert balance['source']['source_sha256'] == identity['source_sha256']
assert balance['guardrail_exit'] == 0
balance_keys = {f'{s}|{n}' for s in rc.ALL_SCENARIOS for n in range(1, 21)}
assert set(balance['games']) == balance_keys
old_balance = read('parent/balance.json')['games']
assert read('parent/balance.json')['source']['source_sha256'] == parent_sha
baseline_sha = hashlib.sha256((repo / 'fs_bot/tools/balance_baseline.json').read_bytes()).hexdigest()
assert baseline_sha == '5c14af61d455068527ed2032857192f849eb854b7e0bf4793d475e2974ab262a'
changes = [{'scenario_seed': k, 'parent': old_balance[k], 'repaired': balance['games'][k]}
           for k in sorted(balance_keys) if old_balance[k] != balance['games'][k]]
summary = {
    'source': identity,
    'parent_source': {'commit': '9c180986c5bde4f56c5a92e7ed2173bfc7603f82',
                      'source_sha256': parent_sha},
    'pytest': unit, 'new_cases': parent['tests'], 'parent_regressions': parent,
    'bots': {'games': len(bots), 'audit_failures': 0,
             'winner_changes_from_parent': sum(r['winner'] != old_bots[r['scenario'], r['seed']]['winner'] for r in bots),
             'final_state_changes_from_parent': sum(r['final_state_sha256'] != old_bots[r['scenario'], r['seed']]['final_state_sha256'] for r in bots)},
    'mixed': {k: fuzz[k] for k in ('games', 'human_turns', 'event_turns', 'events_ok', 'partial', 'hard_findings', 'batch_digest')},
    'mixed_hashes_identical': True,
    'mixed_case_changes_from_parent': sum(a != b for a, b in zip(fuzz['records'], read('parent/fuzz0.json')['records'])),
    'balance': {'games': 100, 'guardrail_exit': 0, 'band': 0.15,
                'winner_changes_from_parent': sum(balance['games'][k]['winner'] != old_balance[k]['winner'] for k in balance_keys),
                'length_changes_from_parent': sum(balance['games'][k]['cards'] != old_balance[k]['cards'] for k in balance_keys),
                'baseline_sha256': baseline_sha, 'baseline_updated': False},
    'balance_changes': changes,
    'bot_and_mixed_seeds': [21, 22, 23, 24], 'balance_seeds': list(range(1, 21)),
    'card_edition': 'legacy', 'hash_seeds': [0, 987],
}
(out / 'verification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
