"""Verify an inconsistent older journal stops through normal file commands."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
from fs_bot import rules_consts as rc
from fs_bot.state.serialize import load_game, save_game, decode, encode
from fs_bot.tools import llm_seat

with tempfile.TemporaryDirectory() as directory:
    args = SimpleNamespace(dir=str(Path(directory) / 'game'),
                           scenario=rc.SCENARIO_GREAT_REVOLT, seed=46,
                           seat=rc.ROMANS, output_dir=str(Path(directory) / 'replay'))
    path = Path(args.dir) / 'save.json'
    with contextlib.redirect_stdout(io.StringIO()):
        llm_seat.cmd_init(args)
        assert llm_seat.cmd_play(args) == 0
        for _ in range(40):
            state, meta, log = load_game(path, validate=True)
            pending = meta['assistant_session']['pending']
            if decode(pending['request'])['kind'] == 'turn':
                break
            assert llm_seat.cmd_submit(SimpleNamespace(dir=args.dir, decision_id=pending['id'],
                                      response=json.dumps({'use_default': True}))) == 0
        else:
            raise AssertionError('Expected a normal human turn')
        plan = {'action': 'command', 'player_action': {
            'command': rc.CMD_RECRUIT, 'regions': [rc.PROVINCIA], 'sa': 'No SA',
            'details': {'recruit_plan': [
                {'region': rc.PROVINCIA, 'action': 'place_auxilia', 'count': 1}]}}}
        assert llm_seat.cmd_submit(SimpleNamespace(dir=args.dir, decision_id=pending['id'],
                                  response=json.dumps(plan))) == 0
    state, meta, log = load_game(path, validate=True)
    journal = meta['assistant_session']['journal']
    assert journal[0]['action'] == 'command'
    # Recreate only the saved contradiction produced by the prior writer.
    journal[0]['assistant_response'] = {'action': 'pass'}
    save_game(state, path, meta=meta, log=log)
    before = encode(state)
    text = io.StringIO()
    with contextlib.redirect_stdout(text):
        assert llm_seat.cmd_play(args) == 0
    resumed, _, resumed_log = load_game(path, validate=True)
    assert 'conflicts with its accepted action history' in text.getvalue()
    assert encode(resumed) == before and resumed_log == log
    replay_text = io.StringIO()
    with contextlib.redirect_stdout(replay_text):
        status = llm_seat.cmd_replay(args)
    assert status == 2
    assert 'conflicts with its accepted action history' in replay_text.getvalue()
    print(json.dumps({'resume_stopped': True, 'board_rng_preserved': True,
                      'committed_log_preserved': True, 'replay_exit': status}, indent=2))
