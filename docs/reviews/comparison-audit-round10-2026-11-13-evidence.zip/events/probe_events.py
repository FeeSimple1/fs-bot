"""Read-only public-dispatch witnesses for EV10-01 and EV10-02.

Usage: python probe_events.py --repo /path/to/fs-bot
No production monkeypatches, direct private Event execution, or raw piece edits.
"""
import argparse
import copy
import json
import sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, default=Path('/workspace/scratch/521fc7ecea8c/falling-sky'))
args = parser.parse_args()
sys.path.insert(0, str(args.repo))
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, get_available
from fs_bot.bots.bot_common import should_decline_event
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.cards.card_effects import _ally_tribe, _unally_tribe
from fs_bot.cards.event_eval import is_event_effective
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT, ACTION_COMMAND_SA, get_sop_factions
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import validate_state, check_structural_integrity

EFFECT_FIELDS = ('spaces', 'tribes', 'available', 'resources', 'senate',
                 'legions_track', 'fallen_legions', 'removed_pieces',
                 'markers', 'capabilities', 'capability_owners',
                 'eligibility', 'forced_ineligible', 'stay_eligible', 'event_modifiers')


def checks(state):
    value = {'census': validate_state(state),
             'structure': check_structural_integrity(state),
             'provincia_fort': count_pieces(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)}
    assert value['census'] == value['structure'] == []
    assert value['provincia_fort'] == 1
    return value


def ready(scenario, card, seed=1):
    state = setup_scenario(scenario, seed=seed)
    state.update(current_card=card, current_card_id=card, can_play_event=True,
                 non_player_factions=set(get_sop_factions(state)))
    checks(state)
    return state


def ally(state, tribe, faction):
    _unally_tribe(state, tribe)
    if faction is not None:
        assert _ally_tribe(state, tribe, faction)
    checks(state)


def changed(before, after):
    return [key for key in EFFECT_FIELDS if before.get(key) != after.get(key)]


def deltas(before, after):
    return {f'{fac}/{piece}': count_pieces(after, rc.ATREBATES, fac, piece)
            - count_pieces(before, rc.ATREBATES, fac, piece)
            for fac, piece in [(rc.AEDUI, rc.WARBAND), (rc.ROMANS, rc.AUXILIA),
                               (rc.ROMANS, rc.FORT), (rc.BELGAE, rc.WARBAND)]}


def natural(state, faction):
    pre = checks(state)
    before = copy.deepcopy(state)
    untouched = encode(state)
    decline = should_decline_event(state, state['current_card'], faction)
    assert encode(state) == untouched, 'availability check changed board or RNG'
    action = dispatch_bot_turn(state, faction)
    assert action['command'] == rc.FIRST_DID_EVENT, action
    result = execute_decision(state, faction, {'action': ACTION_EVENT, 'bot_action': action})
    assert result['executed'] and not result.get('errors'), result
    return {'before_integrity': pre, 'after_integrity': checks(state),
            'should_decline': decline, 'action': action, 'result': result,
            'changed_effect_fields': changed(before, state),
            'atrebates_deltas': deltas(before, state)}


def alternative(state, faction):
    state = copy.deepcopy(state)
    state['can_play_event'] = False
    before = copy.deepcopy(state)
    action = dispatch_bot_turn(state, faction)
    assert action['command'] not in (rc.FIRST_DID_EVENT, 'Pass'), action
    result = execute_decision(state, faction, {'action': ACTION_COMMAND_SA, 'bot_action': action})
    assert result['executed'] and not result.get('errors'), result
    return {'action': action, 'result': result, 'after_integrity': checks(state),
            'changed_effect_fields': changed(before, state)}


availability = []
for scenario in (rc.SCENARIO_ARIOVISTUS, rc.SCENARIO_GALLIC_WAR):
    for card, faction, tribe, owner in [
            ('A69', rc.BELGAE, rc.TRIBE_BELLOVACI, None),
            ('A69', rc.BELGAE, rc.TRIBE_BELLOVACI, rc.AEDUI),
            ('A51', rc.AEDUI, rc.TRIBE_REMI, rc.BELGAE),
            ('A51', rc.ROMANS, rc.TRIBE_REMI, rc.BELGAE)]:
        state = ready(scenario, card)
        ally(state, tribe, owner)
        fallback = alternative(state, faction)
        observed = natural(state, faction)
        assert not observed['should_decline']
        assert observed['changed_effect_fields'] == []
        availability.append({'scenario': scenario, 'card': card, 'faction': faction,
                             'tribe': tribe, 'allied_faction': owner,
                             'observed': observed, 'event_disabled_control': fallback})

positive = []
for scenario in (rc.SCENARIO_ARIOVISTUS, rc.SCENARIO_GALLIC_WAR):
    for card, faction in [('A69', rc.BELGAE), ('A51', rc.ROMANS), ('A51', rc.AEDUI)]:
        state = ready(scenario, card)
        observed = natural(state, faction)
        assert observed['changed_effect_fields']
        if card == 'A69':
            assert observed['atrebates_deltas']['Belgae/Warband'] == 6
        else:
            assert observed['atrebates_deltas']['Romans/Auxilia'] == 4
        positive.append({'scenario': scenario, 'card': card, 'faction': faction,
                         'fixture': 'original physical scenario setup', 'observed': observed})

ownership = []
for scenario in (rc.SCENARIO_ARIOVISTUS, rc.SCENARIO_GALLIC_WAR):
    for romans_np in (True, False):
        state = ready(scenario, 'A51', seed=317)
        if not romans_np:
            state['non_player_factions'].discard(rc.ROMANS)
        available = get_available(state, rc.AEDUI, rc.WARBAND)
        assert available >= 4
        explicit = copy.deepcopy(state)
        observed = natural(state, rc.AEDUI)
        assert observed['atrebates_deltas']['Romans/Auxilia'] == 4
        assert observed['atrebates_deltas']['Aedui/Warband'] == 0
        explicit['non_player_factions'].discard(rc.AEDUI)
        before = copy.deepcopy(explicit)
        result = execute_decision(explicit, rc.AEDUI, {
            'action': ACTION_EVENT, 'player_action': {'command': rc.FIRST_DID_EVENT,
                'details': {'card_id': 'A51', 'text_preference': rc.EVENT_UNSHADED,
                            'event_params': {'piece_type': rc.WARBAND}}}})
        assert result['executed'] and not result.get('errors'), result
        delta = deltas(before, explicit)
        assert delta['Aedui/Warband'] == 4 and delta['Romans/Auxilia'] == 0
        ownership.append({'scenario': scenario, 'roman_non_player': romans_np,
                          'aedui_warbands_available_before': available,
                          'observed': observed,
                          'explicit_human_warband_control': {
                              'result': result, 'after_integrity': checks(explicit),
                              'atrebates_deltas': delta}})

print(json.dumps({'audited_commit': 'ae238c6482a792dda98af4f1f9b11abf820a3964',
                  'availability_witnesses': availability,
                  'prerequisite_positive_controls': positive,
                  'self_benefit_witnesses': ownership,
                  'summary': {'availability_witnesses': len(availability),
                              'executed_non_event_controls': len(availability),
                              'positive_controls': len(positive),
                              'self_benefit_witnesses': len(ownership),
                              'explicit_warband_controls': len(ownership)}},
                 indent=2, sort_keys=True))
