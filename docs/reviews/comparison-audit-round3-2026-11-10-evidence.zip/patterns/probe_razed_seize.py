"""XC3-02. Sacking's permanent Dispersed status is lost through Seize."""
import copy
import json
from fs_bot import rules_consts as rc
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import validate_state, check_structural_integrity
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.winter import spring_phase
from fs_bot.commands.seize import get_dispersible_tribes, calculate_forage
from fs_bot.engine.game_engine import ACTION_EVENT, ACTION_COMMAND


def clean(s):
    assert not validate_state(s), validate_state(s)
    assert not check_structural_integrity(s), check_structural_integrity(s)


def main():
    s = setup_scenario(rc.SCENARIO_GREAT_REVOLT, seed=5)
    s['non_player_factions'] = set()
    s['current_card'] = s['current_card_id'] = 23
    event = {'command': rc.FIRST_DID_EVENT, 'details': {'card_id': 23,
             'text_preference': rc.EVENT_UNSHADED,
             'event_params': {'target_city': rc.CITY_ALESIA}}}
    event_result = execute_decision(s, rc.ROMANS, {'action': ACTION_EVENT, 'player_action': event})
    assert event_result['executed']
    assert s['tribes'][rc.TRIBE_MANDUBII]['status'] == rc.MARKER_RAZED
    clean(s)
    # Only Roman-allied Lingones should earn 2. Razed Mandubii earns none.
    forensic = {'sacking_accepted': True, 'razed_status': s['tribes'][rc.TRIBE_MANDUBII]['status'],
                'forage_expected': 2, 'forage_actual': calculate_forage(s, rc.MANDUBII, []),
                'dispersible': get_dispersible_tribes(s, rc.MANDUBII)}
    assert forensic['forage_actual'] == 4
    assert rc.TRIBE_MANDUBII in forensic['dispersible']
    control = copy.deepcopy(s)
    spring_phase(control)
    spring_phase(control)
    assert control['tribes'][rc.TRIBE_MANDUBII]['status'] == rc.MARKER_RAZED

    action = {'command': rc.CMD_SEIZE, 'regions': [rc.MANDUBII], 'sa': 'No SA',
              'details': {'disperse_tribes': {rc.MANDUBII: [rc.TRIBE_MANDUBII]}}}
    result = execute_decision(s, rc.ROMANS, {'action': ACTION_COMMAND, 'player_action': action})
    assert result['executed'] and not result['errors']
    assert s['tribes'][rc.TRIBE_MANDUBII]['status'] == rc.MARKER_DISPERSED
    clean(s)
    forensic.update(seize_accepted=True, status_after_seize=s['tribes'][rc.TRIBE_MANDUBII]['status'],
                    forage_after_illegal_redispersal=result['forage_resources_total'])
    spring_phase(s)
    forensic['after_first_spring'] = s['tribes'][rc.TRIBE_MANDUBII]['status']
    spring_phase(s)
    forensic['after_second_spring'] = s['tribes'][rc.TRIBE_MANDUBII]['status']
    assert forensic['after_first_spring'] == rc.MARKER_DISPERSED_GATHERING
    assert forensic['after_second_spring'] is None
    clean(s)
    forensic['control_after_two_springs'] = control['tribes'][rc.TRIBE_MANDUBII]['status']
    forensic['validator_errors'] = []
    print(json.dumps(forensic, indent=2))

if __name__ == '__main__':
    main()
