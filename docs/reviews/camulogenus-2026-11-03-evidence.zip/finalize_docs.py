"""Publish documentation only after the final frozen suite and matrix pass."""
import json
from pathlib import Path
import xml.etree.ElementTree as ET
from integration_matrix import identity, protected_files

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'fs-bot'
attempt = 'attempt3'
matrix = json.loads((HERE / attempt / 'integration-results.json').read_text())
source = json.loads((HERE / f'candidate-source-{attempt}.json').read_text())
assert matrix['passed'] and not matrix['failures']
assert identity() == source
assert protected_files() == json.loads((HERE / 'protected-before.json').read_text())
assert matrix['parent_comparison']['all_editions_semantic_changes'] == 0

def suite(name):
    root = ET.parse(HERE / name).getroot()
    rows = list(root.iter('testsuite'))
    result = {key: sum(int(row.attrib.get(key, 0)) for row in rows)
              for key in ('tests', 'failures', 'errors', 'skipped')}
    result['seconds'] = sum(float(row.attrib.get('time', 0)) for row in rows)
    assert not any(result[key] for key in ('failures', 'errors', 'skipped'))
    return result

full = suite('candidate-suite-final.xml')
parent = suite('parent-suite.xml')
results = {
    'accepted': True, 'date': '2026-11-03', 'timezone': 'America/Chicago',
    'parent_commit': source['commit'], 'final_source': {k: v for k, v in source.items() if k != 'files'},
    'python': matrix['python'], 'full_suite': full, 'parent_full_suite': parent,
    'new_cases': full['tests'] - parent['tests'],
    'independent_parent_proof': {'cases': 25, 'failed_existing_behavior': 24, 'passed_control': 1,
                                 'missing_api_failures': 0},
    'gameplay_matrix': matrix,
    'original_audit': {'total': 50, 'closed': 20, 'open': 30, 'percent': 40,
                       'BE-01': 'partial: numeric 67 and 70 repaired;4/9/17/58/65 remain'},
    'prior_attempts': {'attempt1': 'Superseded by the confirmed default resident-Battle repair.',
                      'attempt2': 'Source changed during validation; interrupted and never accepted.'},
    'remote_ci': 'Reported separately after publication; local results are not remote CI evidence.'}
(HERE / 'acceptance-results.json').write_text(json.dumps(results, indent=2) + '\n')
(REPO / 'docs/reviews/camulogenus-2026-11-03-results.json').write_text(json.dumps(results, indent=2) + '\n')

report = f'''# Camulogenus March choices — 3 November 2026

Date convention: America/Chicago. Parent: `{source['commit']}`.
This is a partial repair of BE-01 in the original human-choice audit.
Supplied rules, canonical constants and the balance baseline are unchanged.
No new provisional ruling is introduced.

## Behavior and sources

Numeric 70 unshaded gives the Roman beneficiary the whole-benefit acceptance
decision, even when another faction plays the Event. After acceptance, Romans
choose one destination among Atrebates, Carnutes and Mandubii, then ordered
groups from one or several original Regions. Each group specifies Legions,
Auxilia, Caesar participation and a complete route. The four-Legion limit is
shared across all groups. Ordinary two-step movement and Caesar's third step
apply; dropoffs, Successor/Diviciacus Leader movement and ungranted activities
are rejected. Empty movement can leave a normal Battle at the chosen destination.

Card Reference 70 and its Tips govern these exceptions; §§3.2.2, 3.2.4,
5.1.3 and 5.4 govern the underlying Commands and partial execution. The Tip's
moving-force language is read in its March context: it explains why stationary
pieces do not flip. The separate Battle uses the destination's normal force.
This contextual reading is supported by Card 72's explicit contrasting restriction
that its moved group Battles alone; it is not claimed to be a designer clarification.

Exact physical cohorts are reserved before movement. Arrivals cannot join a
later group; selected pieces cannot move twice. Only participating Auxilia
(including cooperating Aedui Warbands) change visibility. Physical ownership,
Control and inventories remain intact. Cooperation is separately authorized
for March and Battle; refused March loans reoffer planning without asking for
whole-benefit acceptance again.

The related default-planner bug is also repaired: failed movement must not
cancel the separately granted Battle when Roman Forces are already at the
destination. Regressions cover a destroyed mover, a mover removed before its
first step, and static-only resident Forces. Human default selection recognizes
a legal static-only destination; other NPC target priorities are retained.

Terminal menus show card/board information and preserve `board`/`b` inspection.
Durable missing, invalid or wrong-seat responses remain pending with stable
identifiers and board/RNG rollback. Tests use actual assistant play/submit/replay
commands, including saved physical formation and following Battle decisions.
The save schema is unchanged; old response logs can encounter new decisions,
so exact replay across revisions is not promised.

## Verification

Accepted Python source: **{source['python_files']} files**, SHA-256
`{source['python_sha256']}`. Python **{matrix['python']}**.
The source was frozen for the final suite and matrix; all **49 protected files**
matched their parent hashes.

| Check | Result |
|---|---|
| Parent full suite | {parent['tests']:,} passed |
| Final full suite | {full['tests']:,} passed; no failures, errors or skips |
| Added regression cases | {full['tests'] - parent['tests']} |
| Independent parent proof | 24 existing-behavior failures and one passing control; no missing-API failures |
| Bot games | 120 accepted: 100 legacy seeds 1–20 and 10 each original/second-edition seeds 201–202, all five scenarios |
| Parent comparison | All 120 recorded gameplay results unchanged on the same Python runtime |
| Bot hash repeats | Five exact matches, one per scenario |
| Mixed-player runs | 30 distinct scenario/seed/edition cases, 120 executions including replay and both hash seeds |
| Mixed findings | Zero hard findings and zero partial plans; complete JSON/stdout match across hashes |
| Strict census | 60 executions across three editions and both hashes; legal declines only |
| Balance | Existing 100-game baseline and 15-point band unchanged; maximum shift 10 points |

The mixed-player generator now exercises Camulogenus acceptance and authored
movement instead of silently relying on the old planner. It reports 24 rejected
generated plans across the 30 distinct cases (eight per edition); these rejected
inputs are distinct from engine errors and partial execution. Fixed-seed results
are bounded evidence, not an exhaustive strategy or rules-compliance proof.
Unchanged bot records are not a complete turn-by-turn trajectory comparison.

Earlier development failures and validation attempts are retained. Attempt1
passed its matrix but was superseded after review confirmed the existing default
resident-Battle defect. Attempt2's source changed while checks were running;
those results are not accepted. The final matrix was rerun on attempt3. Its first full-suite runner ended without a completion report; candidate-suite-final.xml is the completed accepted rerun on the same frozen source.
Fixture imports and overly broad test wrappers were corrected during development;
these are not reported as production bugs. A duplicate physical-formation prompt
introduced during this implementation was caught and fixed before publication.

Machine-readable results: [results JSON](camulogenus-2026-11-03-results.json).
Raw logs, manifests, prepared patches, parent/candidate records and verification
scripts: [evidence ZIP](camulogenus-2026-11-03-evidence.zip), with an internal
file-size/SHA-256 index. GitHub CI is checked separately after publication.

## Remaining work

Original audit: **20/50 closed (40%), 30 open**. BE-01 remains open for numeric
4/9/17/58/65. Numeric67 was repaired previously; this repair completes numeric 70.
The 34 unverified inventory rows, two unadopted source questions and twelve
provisional rulings remain separate from that denominator.
'''
(REPO / 'docs/reviews/camulogenus-2026-11-03.md').write_text(report)

progress_path = REPO / 'docs/human-choice-progress.json'
progress = json.loads(progress_path.read_text())
progress['tested_source'] = {'commit': source['commit'], 'python_sha256': source['python_sha256'],
    'python_files': source['python_files'], 'working_tree_changes': True,
    'note': 'Camulogenus partial BE-01 repair prepared over this parent; final suite and matrix use these exact Python bytes.'}
progress['notes'].append('Camulogenus whole-benefit and March choices are repaired; BE-01 remains open for 4/9/17/58/65. See reviews/camulogenus-2026-11-03.md.')
progress_path.write_text(json.dumps(progress, indent=2) + '\n')

status_path = REPO / 'docs/current-status.md'
status = status_path.read_text()
section = f'''### 3 November Camulogenus — partial BE-01 repair

The [Camulogenus report](reviews/camulogenus-2026-11-03.md) covers Roman
whole-benefit acceptance and exact March planning on numeric 70: multiple
original groups, one named destination, four Legions total, moving-only
visibility and separate cooperation. It also repairs default planners skipping
a possible resident Battle after the moving group is lost or removed.

The final source passes **{full['tests']:,} tests** and 120 audited bot games,
with all 120 recorded results unchanged against a fresh same-runtime parent.
Five bot hash repeats, 30 mixed cases / 120 executions with replay and cross-hash
checks, and 60 strict-census executions pass. The balance baseline and band
remain unchanged. Rejected generated inputs are reported separately.

**20/50 original findings remain closed (40%);30 remain open.** BE-01 remains
open for 4/9/17/58/65; 67 and 70 are repaired. Two unadopted source questions,
twelve provisional rulings and 34 unverified inventory rows remain separate.

'''
status = status.replace('## Follow-up repairs\n\n', '## Follow-up repairs\n\n' + section, 1)
status_path.write_text(status)
old_path = REPO / 'docs/reviews/event-battle-choices-2026-11-03.md'
old = old_path.read_text()
old = old.replace('## Restored choices\n', '**Later disposition, 3 November 2026:** [Camulogenus](camulogenus-2026-11-03.md) now supplies the whole-benefit acceptance and March choices recorded below as open. Historical results are unchanged.\n\n## Restored choices\n', 1)
old_path.write_text(old)
print(json.dumps({'full_tests': full['tests'], 'added': results['new_cases'], 'source': source['python_sha256']}))
