# Independent review: EXP-07 / EXP-10

Scope: source interpretation and implementation review of A5 unshaded evacuation and A22 shaded Intimidate. Baseline main `95e7a206d5b6ff410d949573724cb2b145ed23d8`. No production edits by reviewer.

## EXP-07 — A5 Gallia Togata unshaded

Confirmed source boundaries:

- `Reference Documents/Ariovistus/A Card Reference`, A5: each non-Roman moves its pieces in Cisalpina to its Home Regions or removes them. This names the affected owner as decision-maker. "Pieces" includes structures; no prohibited non-Roman piece may remain.
- This is direct Event movement, not a March grant. Preserve physical owner and Hidden/Revealed/Scouted state; do not apply March hiding/adjacency/Control-retention procedures.
- `Chapter 5`, 5.1.1: normal stacking applies except where Event text explicitly changes it. A5 changes Cisalpina's permitted occupants; it does not authorize destination Tribe/City/Settlement stacking violations.
- `Chapter 1`, 1.4.2: Allies require legal Tribe circles, Citadels require Cities, no placement on Dispersed Tribes, protected home-city and Suebi ownership remain. `Chapter A1`, A1.4.2: one Settlement per Region.
- `Chapter A1`, A1.3.1: German Home Regions include Regions with Settlements. Exclude Cisalpina even if its outgoing Settlement makes it Home. Existing Settlement Homes already have a Settlement; outgoing Settlement cannot stack there.
- Exact physical structure provenance must follow Tribe metadata, including Colony's additional Tribe. Card71 can put another owner's Ally in Cisalpina in addition to Nori; this is a real legal multiple-owner evacuation case.
- Aedui Diviciacus removal follows A1's out-of-play/no-Successor behavior through existing piece helpers.

Non-player defaults:

- 8.4.1: never voluntarily remove own pieces; relocate each piece if legal, remove only if no legal Home destination remains.
- 8.3.2 NOTE plus 8.4.1: Leader destination with most own pieces; as able, end movement with at least four own Warbands accompanying the Leader.
- 8.4.1 own-piece priority and City/Remi Ally priorities apply; A8 gives Settlements equal Citadel priority.
- 8.3.4 and 8.2.3: unspecified equal legal choices use seeded randomness. A8.2.3 sends Arverni actions to Arverni Phase instructions only as applicable; A6.2.2's March-specific adjacency/Control restrictions do not apply to direct A5 movement.

Affected-owner resolution order:

- Apply Chapter5 5.1's generic selection authority: the Event executor chooses the order of affected owner groups. A5 expressly delegates each owner's disposition/destination, but does not delegate group order. Each owner then chooses its own complete allocation on the live board after earlier owners resolve.
- No simultaneous or fixed-order provision was found. Printed Faction Order in 2.3 governs eligibility; Cards47/48 explicitly impose initiative order when that is intended. A5 does not.
- This matters because owners may contest empty Tribe slots: German Settlement Homes can overlap Belgic Homes, and Colony71 permits two affected Allies in Cisalpina. Existing fixed Arverni/Aedui/Belgae/Germans order should become an executor-selectable order rather than an authoritative priority.
- Reviewer initially flagged this as a possible source gap, then agreed with root on the ordinary application of generic 5.1 after checking for contrary provisions. No new provisional ruling is needed.

## EXP-10 — A22 Dread shaded

Confirmed source composition:

- CardA22 shaded permits one added Warband Reveal to remove one extra piece.
- A4.6.2 ordinary Intimidate uses one or two Hidden German Warbands. With A22 shaded it may use up to three, but the added participant must pay for an actual additional removal; a third marker-only Reveal is not licensed.
- A3.4.3 says the Warbands Raiding with Ariovistus can free Intimidate "at the same time". Therefore the Reveal of a third actual Raider under shaded Card8 Baggage Trains can simultaneously satisfy A22's added Reveal. Requiring a fourth Hidden Warband merely because engine resolution is sequential would change this rule.
- Without A22, even Baggage's three Raiders give only ordinary Intimidate's maximum two participants/removals. With A22 and only one or two Raiders, one further eligible Hidden Warband may be Revealed for an added removal, subject to total three.
- At least one actual Raider is necessary to earn intrinsic free Raid Intimidate. Actual credits must never be fabricated from the entire Revealed force.
- A29 shaded confines its Raid grant to the placed surviving cohort. The fresh A22 added participant must also come from the scoped eligible cohort, never a resident substituted counter. Its offensive choice belongs to the A29 executor, not necessarily the physical German seat; physical owner remains German.
- One targeted Faction, no target Leader, protected Romans with unshaded Dread, normal target types, exact physical visibility, and no unrelated extra benefit all remain.

Correction to review history: reviewer initially proposed a blanket requirement for a fresh post-Raid bonus Reveal and a maximum two existing Raider credits. This was retracted after reading A3.4.3's simultaneous language with Card8 and A22. The source composition above is the final review view; no new provisional owner ruling is being substituted.

Recommended high-value regressions:

1. Baggage three actual Raiders, no remaining Hidden Germans, Dread shaded: three removals succeed.
2. Same physical state without Dread: no more than two removals.
3. One Raider plus one eligible Hidden German, Dread: exactly two removals and one additional Reveal.
4. A29 same case with only a resident Hidden German outside the placed cohort: bonus rejected; ordinary actual Raider credit remains legal.
5. Durable human request/save/load/replay with explicit fresh bonus and executor ownership; malformed/default responses cannot silently spend extra counters or claim more credits.

## Implementation review

Pending final implementation availability. Early Dread changes preserve the scoped physical view through count/flip helpers and add capability-aware limits to ordinary planning and execution; final validator/default/CLI review still required.

### Stable Dread implementation review

Reviewed the final code delta in `fs-dread-intimidate` and all 41 cases in `fs_bot/tests/test_dread_intimidate.py`. No open implementation defect found. Confirmed centralized capability-aware cap, actual credit/fresh Reveal separation, Baggage third Raider/no fourth counter, strict boolean bonus protocol, one-Faction/Leader/protected-Roman restrictions, capability-side precedence over legacy immunity, A45 default, both ordinary CLI paths, NPC detached Raid preview and remaining-Hidden ordinary-SA recomputation, A29 executor/cohort boundary, and invalid/pending/save/resume/replay behavior. Awaiting implementer's test-run results before final evidence handoff.

### A5 initial implementation review

Found one concrete wiring defect during initial read: `apply_allocation` omitted the required `removed_piece_type` argument to `clear_allied_tribe`. Communicated immediately; implementer corrected it before targeted tests. Continued review pending complete A5 tests and stable code. Source/default/group-order policy remains consistent with review above.

### Dread related unshaded marker correction

Reviewed the additional four capability-side/removal cases and `validate_recruit_region` change. CardA22 explicitly says Intimidate **and Intimidated markers** have no effect on Romans. Reusing the lifecycle-aware immunity helper for Recruit is source-supported; ordinary Devastation restrictions and other factions' Rally remain unchanged. No duplicate Roman bot/CLI marker gate was found. Dread now has 45 added parametrized cases. This related fix does not count as another audit finding closure.

### Stable A5 implementation review

Reviewed `cards/gallia_evacuation.py`, `cli/gallia_evacuation.py`, shared free-action wiring and the complete new A5 test file. No remaining legal-state implementation defect found after the helper-signature correction. Confirmed physical owner/visibility cohorts, exact Tribe metadata including Colony, complete allocation validation on detached board/RNG, live destination occupancy, Settlement-created German Homes, Diviciacus removed-pool behavior, executor order then affected-owner allocation, NP preservation/Leader escort/seeded choices, automatic expansion Arverni, CLI board/b and EOF behavior, and pending second-owner rollback/save/load/exact replay.

Implementer reports 29 focused A5 cases passing before full suite. One test of an impossible legacy Cisalpina Citadel is being labeled solely conservative invalid-save containment. It must not assert a new source ruling that Citadels can never replace a City Ally: §1.4.2 says they take the place of an Allied Tribe there, and no legal Cisalpina Citadel exists for this Event to evacuate.

Both implementation deltas are cleared for frozen full-suite testing. Final commit IDs and run counts remain to be recorded by implementers/root.
