# EXP-10 Dread Intimidate handoff

Base: `95e7a206d5b6ff410d949573724cb2b145ed23d8`.
Branch: `repair/dread-intimidate-2026-11-02`.
Implementation worktree: `fs-dread-intimidate`.
Final commit: `53d79cf72d65ae962ebcd0440d93c218ecc88afc`. Not pushed.

## Source contract

Sources are supplied `Reference Documents/Ariovistus/A Card Reference` A22, `Chapter A4` A4.6.2, `Chapter A3` A3.4.3/A3.2.1, `Chapter A8` A8.7.1, and base `Card Reference` card 8. Full quotations/context and independent review are in `dread-source-review.md`.

A22 shaded: “Intimidate may Reveal 1 added Warband to remove 1 extra piece.” Ordinary Intimidate therefore has a maximum of three physical Hidden participants/removals. The original one-Faction, no-enemy-Leader, eligible-piece and Region restrictions remain.

A3.4.3's “such Warbands ... may free Intimidate at the same time” allows actual Raiders to supply simultaneous Reveal credits. Without Dread, a third Raider permitted by Baggage Trains does not increase ordinary Intimidate's two-participant limit. With Dread, three actual Raiders can provide three removals; no fourth Hidden counter is required. With one or two actual Raiders, Dread can optionally Reveal one additional genuinely Hidden eligible Warband for one extra removal, up to three total. This is a compositional reading of supplied text, independently reviewed and accepted by root and effects reviewer, not an additional provisional ruling or purported designer clarification.

A29's actual surviving newly placed cohort remains the physical scope for any fresh Dread participant; resident Ariovistus still supplies the distinct presence prerequisite, and the Event executor makes the choice. A subsequent ordinary Intimidate SA uses remaining Hidden participants after the intrinsic Raid effect. It never reuses actual Raider credit or the fresh bonus counter.

Related same-card correction authorized by root: unshaded A22 immunity now applies to Intimidated markers blocking Roman Recruit as well as Intimidate removals. Active Capability side overrides stale old modifier saves; legacy modifier-only saves remain compatible. Ordinary no-Dread, shaded, removed-side, Devastation and other-Faction restrictions remain.

## Public reactive request and response

Existing kind `raid_intimidate`, exact target fields, explicit decline/default and marker-only behavior remain. With inactive shaded Dread, request shape remains unchanged. With active shaded Dread the request additionally contains:

- `max_raider_removals`: maximum using actual Raiders alone (at most three).
- `extra_warband_available`: whether one eligible Hidden participant remains in physical/Event scope.
- `max_with_extra`: maximum with one fresh participant plus at most two actual Raiders, or zero when unavailable.
- Existing `max_removals` is the maximum over both choices.

Responses still accept `{"targets": [...]}`. This uses actual Raider credits only, including the simultaneous third Raider when supported. Optional `"extra_warband": true` explicitly selects one fresh Hidden participant. It requires shaded Dread, an eligible available counter, and two or three actual removals. `false` is accepted; non-boolean values are rejected. No extra Reveal is permitted for zero/one-removal or marker-only answers. Additional unrecognized response fields and forged credits are rejected. Targets retain exact faction/piece/visibility and one-Faction/Leader protections. Existing empty targets means ordinary marker-only, not decline.

CLI and random-player reactive policy consume the same request limits and emit the explicit extra choice. CLI retains early Finish only where the selected participant choice permits it. Preview/validation remains detached, RNG unchanged. Pending invalid response retains the decision ID, authoritative live board and journal; save/resume logs and replay the exact extra-counter choice.

## Implementation scope

Shared ordinary limit/capacity/immunity in `commands/sa_intimidate.py`; typed ordinary/intrinsic engine adapter; German NPC selector and after-Raid budget; A45 default and applicability probe; ordinary/timing/raid CLI; random reactive sampler; Roman Recruit marker validation. New regressions in `tests/test_dread_intimidate.py`.

No protected Reference Documents, canonical constants, historical baseline, or project-wide progress documentation changed. Parent owns documentation and integration. No push by this agent.

## Evidence

- `dread-witness.py` runs against either baseline or repaired source.
- `dread-witness-before.txt`: ordinary three rejected, intrinsic two-plus-fresh leaves one Roman Auxilia, unshaded marker incorrectly blocks Recruit.
- `dread-witness-after.txt`: ordinary three removes three, intrinsic two-plus-fresh flips exactly one additional WB and removes three, unshaded Recruit legal.
- `dread-baseline-source/` is a reproducible temporary extraction of only `fs_bot/` at base95e7a20 for this witness. It need not be included in the persistent review archive; script/base hash suffice to reproduce it.
- `dread-focused-initial.txt`: existing affected-path suite, 44 passed.
- `dread-new-tests-first.txt`: preserved first new-test run, 32 passed / 3 fixture failures (Legion source flag, missing fixture modifier dict, timing scope).
- `dread-new-tests-second.txt`: preserved second run, 39 passed / 2 fixture import errors. Both early failures were test setup mistakes, not hidden product failures.
- `dread-focused-final.txt`: 129 passed, affected-path sweep before adding four Recruit cases.
- `dread-new-tests-final.txt`: all 45 new cases passed, including related Recruit correction.
- `dread-full-final.txt`: preserved first full suite, 6,521 passed / 1 legacy error-message regex failure. Restored the inactive-Dread error wording instead of changing the established test.
- `dread-message-compatibility.txt`: 141 passed after restoring legacy error text.
- `dread-full-final-02.txt`: frozen final full rerun, **6,522 passed in 113.18 seconds**, exit 0. Run completed before committing; only this external handoff updated afterward.

Read-only independent source/implementation reviews completed by dread_source_review and root/effects_review. The latter cleared the stable delta and four Recruit cases before the final full suite.

## Unchanged separate audit caveat

Reviewer noted `_check_intimidate_before_battle` excludes the whole selected defender Faction, while A8.7.1 excludes pieces guaranteed removed by the immediately following Battle. Existing tests expressly enforce whole-Faction exclusion. This is outside EXP-10 and requires a separate source-backed combat-projection review; it is not claimed fixed or added to completed findings.

Follow-up lead details: `fs_bot/bots/german_bot.py::_check_intimidate_before_battle` currently passes `exclude_faction=bp.get("target")` to the selector, with a comment saying all defenders are handled by Battle. `fs_bot/tests/test_german_bot.py::TestIntimidatePriority::test_intimidate_before_battle_excludes_defender` (around line 906) enforces that every selected target differs from the Battle defender. The literal source is `Reference Documents/Ariovistus/Chapter A8`, A8.7.1 INTIMIDATE, lines 139–142: “Intimidate to remove enemy pieces that would not be guaranteed to be removed in an immediately subsequent Battle.”

Suggested witness for that future audit: Ariovistus plus four Hidden German Warbands against six leaderless player Roman Auxilia, with a legal Roman Retreat destination and no effect forcing Ambush or forbidding Retreat. Supply a legal Battle plan for that Region, verify the battle-loss/Retreat projection leaves removable Roman pieces not guaranteed lost, and then inspect the pre-Battle Intimidate selector. Its unconditional defender exclusion currently yields no Roman targets. The future repair must establish the exact guaranteed-loss projection and post-Intimidate Battle legality rather than merely deleting the exclusion. This candidate was not executed or counted as a verified repair regression in EXP-10.
