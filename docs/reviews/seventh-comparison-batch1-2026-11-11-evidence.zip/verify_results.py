"""Check the seventh comparison Batch 1 evidence against its source."""

from collections import Counter
import json
from pathlib import Path
import platform
import re
import sys
from xml.etree import ElementTree
from zipfile import ZipFile

from fs_bot import rules_consts as rc
from fs_bot.state.serialize import decode
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


def load(path):
    return json.loads(path.read_bytes())


def key(row):
    return row['scenario'], row['seed'], row['card_edition']


def games(raw):
    rows = [json.loads(line) for line in raw.splitlines()]
    keyed = {key(row): row for row in rows}
    assert len(keyed) == len(rows)
    return keyed


def prefire_effects(card):
    effects = []
    for entry in card['prefire']:
        removed = entry['attacking_pieces_before'] - entry['attacking_pieces_after']
        rolled = entry['rng_before'] != entry['rng_after']
        if removed or rolled:
            effects.append((entry['region'], entry['attacker'], removed, rolled))
    return effects


def explain(row):
    prior, current = row['prior'], row['current']
    assert (prior['card'], prior['before'], prior['rng_before']) == (
        current['card'], row['same_start'], row['same_rng'])
    assert prior['after'] != current['after']
    reasons = []
    if prefire_effects(prior) != prefire_effects(current):
        reasons.append('Slingers prefire')
    for old, new in zip(prior['battles'], current['battles']):
        if tuple(old[k] for k in ('region', 'attacker', 'defender')) != tuple(
                new[k] for k in ('region', 'attacker', 'defender')):
            continue
        if old['horse_regions'] != new['horse_regions'] and old['result'] != new['result']:
            reasons.append('Horse Losses')
        for stage, inflictor in (('attack', new['attacker']), ('counterattack', new['defender'])):
            if inflictor != rc.GERMANS:
                continue
            old_rolls = decode((old['result'].get(stage) or {}).get('rolls', []))
            new_rolls = decode((new['result'].get(stage) or {}).get('rolls', []))
            if ((rc.FORT, 3, False) in map(tuple, old_rolls)
                    and (rc.FORT, 3, True) in map(tuple, new_rolls)):
                reasons.append('Stalwart Fort roll')
    return list(dict.fromkeys(reasons))


def main(evidence):
    root = Path(evidence)
    identity = load(root / 'source.json')
    assert source_identity()['source_sha256'] == identity['source_sha256']
    counts, differences = {}, {}
    earlier = Path('docs/reviews/sixth-comparison-batch5-2026-11-11-evidence.zip')
    with ZipFile(earlier) as archive:
        parent_identity = json.loads(archive.read('source.json'))
        for label, edition, seeds in (('legacy', 'legacy', range(1, 21)),
                                     ('second', 'second-edition', range(41, 45))):
            filename = f'bots-{label}/games.jsonl'
            old = games(archive.read(filename))
            current = games((root / filename).read_bytes())
            assert old.keys() == current.keys() == {
                (scenario, seed, edition) for scenario in SCENARIOS for seed in seeds}
            for case, row in current.items():
                assert old[case]['source_sha256'] == parent_identity['source_sha256']
                assert row['commit'] == identity['commit']
                assert row['source_sha256'] == identity['source_sha256']
                assert all(row[field] for field in ('completed', 'game_completed',
                                                   'audit_completed', 'final_state_sha256'))
                assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row)
                assert len(row['final_ranking']) == len(row['engine_final_ranking']) == 4
                assert all(item['severity'] == 'legal-decline' for item in row['diagnostics'])
                if row['final_state_sha256'] != old[case]['final_state_sha256']:
                    differences[case] = (old[case], row)
            counts[label] = dict(games=len(current),
                final_boards_changed=sum(case in differences for case in current),
                winners_changed=sum(r['winner'] != old[k]['winner'] for k, r in current.items()),
                lengths_changed=sum(r['cards'] != old[k]['cards'] for k, r in current.items()),
                interludes=sum(r['interlude_completed'] for r in current.values()))
            if label == 'legacy':
                legacy = current

    trace = load(root / 'first-changes.json')
    assert trace['source'] == identity
    assert {key(row) for row in trace['games']} == differences.keys()
    reasons = Counter()
    for row in trace['games']:
        old, current = differences[key(row)]
        assert (row['prior_winner'], row['current_winner']) == (old['winner'], current['winner'])
        found = explain(row)
        assert found, key(row)
        reasons.update(found)

    fuzz0, fuzz987 = (root / 'fuzz0.json').read_bytes(), (root / 'fuzz987.json').read_bytes()
    assert fuzz0 == fuzz987 and (root / 'fuzz0.log').read_bytes() == (root / 'fuzz987.log').read_bytes()
    fuzz = json.loads(fuzz0)
    assert fuzz['games'] == len(fuzz['records']) == 20 and fuzz['hard_findings'] == 0
    assert {(r['scenario'], r['seed'], r['card_edition']) for r in fuzz['records']} == {
        (scenario, seed, 'second-edition') for scenario in SCENARIOS for seed in range(41, 45)}
    assert all(r['game_completed'] and not r['findings'] for r in fuzz['records'])
    assert fuzz['metadata']['source_sha256'] == identity['source_sha256']
    assert fuzz['metadata']['commit'] == identity['commit']

    balance_log = (root / 'balance.log').read_text()
    assert 'OK: balance within band.' in balance_log
    balance = re.findall(r'^\[(.+) seed=\s*(\d+)\] winner=(.+) \((\d+) cards\)$',
                         balance_log, re.MULTILINE)
    assert len(balance) == 100
    balance_games = {f'{scenario}|{seed}': dict(winner=winner, cards=int(cards))
                     for scenario, seed, winner, cards in balance}
    assert balance_games == {f'{s}|{seed}': dict(winner=row['winner'], cards=row['cards'])
                             for (s, seed, _), row in legacy.items()}
    baseline = load(Path('fs_bot/tools/balance_baseline.json'))['games']
    assert balance_games.keys() == baseline.keys()
    assert all(r['winner'] == baseline[k]['winner'] for k, r in balance_games.items())
    assert sum(r['cards'] != baseline[k]['cards'] for k, r in balance_games.items()) == 1

    suites = list(ElementTree.parse(root / 'pytest.xml').getroot().iter('testsuite'))
    tests = sum(int(s.attrib['tests']) for s in suites)
    assert tests == 10011 and not any(int(s.attrib.get(k, 0)) for s in suites
                                    for k in ('errors', 'failures', 'skipped'))
    assert '20 passed' in (root / 'directed.log').read_text()
    assert '13 failed, 7 passed' in (root / 'parent-regressions.log').read_text()

    summary = dict(source=identity, python=platform.python_version(),
        full_tests=tests, directed_tests=20, parent_defect_reproductions=13,
        paired_outcomes=counts, first_divergence_causes=dict(reasons),
        mixed_player={k: fuzz[k] for k in ('games', 'human_turns', 'event_turns',
            'events_ok', 'partial', 'hard_findings', 'batch_digest')},
        balance=dict(games=100, band=0.15, winners_changed=0, lengths_changed=1))
    (root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main(sys.argv[1])
