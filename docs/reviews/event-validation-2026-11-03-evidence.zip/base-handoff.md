# BE-11 handoff — reviewed source, awaiting combined baseline investigation

Base: `8db858b14cd13856059d42db1ad3931e523b5ed4`. Worktree: `fs-base-event-validation`; branch `repair/base-event-validation-2026-11-03`. No commit: root explicitly requested a patch after the full-suite balance canary failed. Apply `base-ready.patch` (full-index binary diff, only fs_bot code/tests). All task source is staged and frozen.

## Validation result and limitations

- 84 new regression cases pass (`base-new-05.log`).
- Frozen full command: `/workspace/scratch/534c265c65f4/fs-test-venv/bin/python -m pytest -q -n 2`.
- Result: **6,634 passed, 1 failed** in 114.59 seconds (`base-full-01.log`). The only failure is `test_selfplay_tools.py::test_bot_balance_canary`.
- The 15-game smoke found The Gallic War Romans 0/3 baseline to 2/3 current, exceeding its unchanged 40% band. The six changed winners are Ariovistus|2, Pax Gallica?|2, Reconquest of Gaul|3, The Gallic War|1, The Gallic War|2, and The Great Revolt|3. This does not establish a cause; root will investigate on combined source before any baseline decision.
- Protected Reference Documents, rules_consts.py, balance baseline and test thresholds are unchanged. `git diff --cached --check` passes.
- Independent agent `event_validation_review` cleared this scoped implementation, subject to the full suite. Its latest review confirmed Card41 restricted-City stacking, Card42 Belgica-before-count priority and expansion faction-order swap.
- No standalone causal trace is available: external helper `base-trace.py` failed to serialize tuple-key state. Root asked to stop and trace only final combined code. `fs-base-event-before` is a detached read-only base worktree, if useful; the helper and its failed output are not part of the patch.
- Real SeatSession durable Event rejection requires the separate German Allegiances shared fix. This patch adds `rejected: true` to its explicit object-envelope guard, but intentionally does not duplicate the other agent's common rejection-marker/turn-hook changes. Root should run its real retry/save/load/replay regression on integrated source and can parameterize with Card40 mixed piece types or explicit falsey event_params. Our regression suite verifies raw atomic rejection and detached prefix/CLI state; it does not claim a standalone durable SeatSession fix.

## Source-grounded behavior

All sources are already in the repository. CLAUDE.md, Reference Documents inventory and current/provisional docs were read. No outside sources or new provisional rulings are used.

- `Reference Documents/Card Reference`, Card40: "Place up to any 3 Warbands, 2 Auxilia, or 1 Ally in each Region adjacent to Cisalpina." Its Tips allow any faction's Warbands/Allies and different types in different Regions, naming Ubii, Sequani and Provincia. The validator now rejects mixed types within one Region, aggregate overlimits, wrong native piece types, invalid geography/Tribes and malformed counts. Zero placement remains legal and +4 Resources still applies. Available shortages remain partial effects.
- Card41: own Avaricum Ally/Citadel gates optional own-piece effects within one of Bituriges: at most two Allies; one Ally-to-Citadel replacement; one Fort placement; then Resources from own Ally/Citadel/Fort pieces. New placements may be selected for the later replacement. Every Ally removal/placement updates the exact Tribe metadata.
- Card41 replacement follows literal Chapter5 §5.1.1: unavailable incoming pieces or stacking-illegal replacement means remove the source Ally. Thus a human may choose a non-City Ally, a faction with no native Citadels, an exhausted Citadel pool, or a faction-restricted City; the source Ally is removed, and no illegal Citadel is created. Root/reviewer explicitly approved this interpretation. Non-Roman Fort placement cannot create a foreign piece. NP defaults do not sacrifice an own Ally for a removal-only replacement.
- Card42 unshaded: one alternative, at most four Allied Tribes under Roman Control OR at most two adjacent to Roman Control. Counts cannot be mixed. Geographic scope is determined before removals change Control. Optional zero is valid; optional explicit `mode` may be `controlled`/`adjacent`; old valid plans with omitted mode remain inferable.
- Adjacent authorized Card42 shaded repair: one to three Roman/Aedui Allies in Supply Lines computed as if both agree, exactly as its Tips state. Zero only if no eligible targets exist. Citadels are excluded. The mandatory lower bound is checked after the tail planning checkpoint, preserving unfinished prefix planning.
- Card51 unshaded: select any single Region within one of Treveri, then replace exactly min(4, original eligible Warbands there), then the Aedui free Command. An explicitly selected empty Region is legal under §5.1.3 and still grants the Command; missing Region is malformed. Human selection is not forced to maximize targets across Regions. Scouted/Revealed/Hidden sources are explicit. Newly placed Aedui counters cannot be selected again as replacement sources.
- Chapter5 §5.1.1 availability/stacking fallback and §5.1.3 partial execution apply separately from the printed selection contract. Mandatory complete quotas are checked only after the final timing checkpoint. Counter cohort tracking preserves legal voluntary reclamation without borrowing newly created counters.
- Chapter8 §§8.2.3/8.3.1/8.4.1 guide NP defaults. Aedui Roman Wine instructions only target player Arverni/Belgae (base), or player Germans/Belgae (Ariovistus); Belgae instructions select Belgica Regions first. The latter priority applies before maximizing a branch's total quota. Scenario-aware target order uses existing A8.4 swap helper. Random ties use the seeded game RNG; NP availability probes use detached copies.

## Implementation/API changes

New `fs_bot/cards/base_event_limits.py` owns selection validators, map pools, exact eligible targets, Surus original-source execution, and NP Avaricum/Roman Wine defaults. New `fs_bot/cli/base_event_limits.py` owns source-aware collectors. Existing card handlers remain integration points with their established timing-step names.

Event plans:

- 40U: `placements`: list of `{region, piece_type, count?, faction?, tribe?}`. Ally requires exact Tribe; default count1 and executor faction. Per-Region type exclusive and total cap enforced. `40.placements` timing retained.
- 41: `ally_placements` (max2 `{tribe, region?, faction?, count?}`), optional `citadel_upgrade_tribe`, optional `fort_region`. `41.allies`, `41.citadel`, `41.fort`, `41.resources` retained.
- 42: `removals`: list of exact `{tribe, faction?, region?, count?}` with count1; U optional `mode`. `42.removals` retained.
- 51U: required `region`; `replacements`: list of `{from_faction, piece_state?, count?, region?}` in that Region. `51.replacements` retained; namespace `surus.original.` records selected physical originals through existing generic timed cohort support.
- All permit existing timing actions at appropriate entry/stage points; unknown per-card fields and wrong list/object shapes reject.
- Global human Event explicit `event_params` must be an object: []/False/0/None/empty string are rejected atomically with `rejected: true`. Omitted `event_params` retains prior behavior. NP behavior is unchanged by this guard.

Integration merge points: `cards/card_effects.py` handlers40/41/42/51; `cards/event_conditions.py` early42 NP availability; `cards/param_schema.py` explicit schemas and named region pools; `cards/surus.py` empty-Region NP fallback; `cli/human_plan.py` collector dispatch; `engine/execute.py` object guard and _derive_card_41/_derive_card_42 wrappers. Other agents own A-cards and65, so conflicts should be local dispatch/header context only.

## Regressions / corrected obsolete assertions

`test_base_event_limits.py`: 84 cases cover overlimit/mixed-region/type/faction/count rejection, exact legal nondefault choices, available shortages, all Card41 removal-only outcomes including restricted Bibracte, Roman Wine quota/geography/supply and NP policy, Surus exact originals/no replacement recycling/empty selection, explicit falsey envelope atomicity, detached CLI/prefix behavior, board inspection and EOF.

Two existing tests were corrected for source-inconsistent expectations:

1. `test_param_schema.test_card_40_rejects_non_listed_piece_types` no longer accepts count5 silently clamped to3. It requires rejection and unchanged board.
2. `test_execute_integration.TestShadedDerivers.test_card42_shaded_never_removes_own_ally` now uses a Roman actor removing an Aedui Ally, preserving its no-own-casualty purpose. Its former forced Aedui actor targeting Romans contradicted the specific player-Arverni/Belgae-only instruction.

Earlier failed focused runs are retained, including fixture corrections (native Citadel pool count, exact number of Ally targets, Tribe-vs-Region constant, exhausted Ally supply, equal City priority comparison). These did not require loosening rules. Frozen full log is the decisive run.

## Suggested controlled-document update

BE-11 closes original Cards40U/41/42U/51U full selection validation and their CLI legal choices. Note additionally the authorized42S eligibility/minimum correction, matching41/42 NP defaults, and typed human Event payload guard. Describe complete human quotas versus permitted partial execution and exact source ownership rather than claiming all Event validation is done. Mention exact selected empty Surus Region remains legal. Pair with BE12 rejection markers to document invalid Event plans preserving the pending turn, not consuming eligibility or saving invalid journal records.

Do not update authoritative sources or provisional ruling register. No independent new rules-choice item arose. Do not claim full green until root resolves the unchanged balance canary on combined source. Root owns inventory/progress counts and documentation.
