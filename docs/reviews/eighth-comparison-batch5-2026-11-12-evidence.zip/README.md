# Aedui Battle and Rally verification

The parent was Falling Sky commit `2a91f8104b1454bdbb9770d69ff7499cdaad250a`.
The final runs use Python 3.12.14 and the working-tree Python digest in
`source-verified.json`. Run `verify_results.py` on the matching repaired
source with the archive extracted. It checks the per-game outcomes, replay
pairs, first changes, test totals, and independent balance sample.

The parent matrix and mixed samples come from the Batch 4 evidence archive.
The directed cases use ordinary public dispatch, the Sequence of Play, and
the Druids Event resolver. The parent run loads the new cases with the
parent's engine. The full and focused JUnit files record the final suite.

```sh
export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
python -m pytest -q -n 5 --show-capture=no --junitxml=pytest-final.xml
python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out final-legacy
python -m fs_bot.tools.run_batch --seeds 45-48 --card-edition second-edition --workers 1 --out final-second
python -m fs_bot.tools.player_fuzz --seeds 45-48 --card-edition second-edition --out fuzz0-final.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 45-48 --card-edition second-edition --out fuzz987-final.json
python -m fs_bot.tools.player_fuzz --seeds 201-203 --card-edition second-edition --out fuzz-ci0.json
PYTHONHASHSEED=7 python -m fs_bot.tools.player_fuzz --seeds 201-203 --card-edition second-edition --out fuzz-ci7.json
python -m fs_bot.tools.balance_smoke --seeds 1-20
```

Run `compare_cases.py` inside the evidence directory to recover the paired
seed lists. From either source checkout, set `PYTHONPATH` to that checkout
and invoke `trace_aedui.py` with the corresponding paths to
`legacy-changed.json second-changed.json` or
`--mixed mixed-changed.json ci-changed.json`. Hash seed 0 applies to both
sides. The tracer keeps the per-card board and RNG hashes, Aedui plans and
execution, and the compact outcome for each replayed game.
