# Sixth comparison repair Batch 1 evidence

The parent is `6946a274407b38aebd6f27b8b6d60a1c6dc60b12`. The final Python
source hash and all accepted run identities are recorded in `final/source.json`
and `final/summary.json`. `SHA256SUMS.json` covers every other archive member.

Run the following from the relevant checkout with Python 3.12, pytest and
pytest-xdist. Use fresh output paths.

```sh
PYTHONHASHSEED=0 python -m pytest -q -n 5 --dist loadfile --tb=short --show-capture=no --junitxml=pytest.xml
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 3 --out bots-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 41-44 --card-edition second-edition --workers 2 --out bots-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
```

The committed baseline matches `final/balance-baseline-reviewed.json`. The
initial failed comparison used the same game logic before the test fixture
update. Its 100 outcomes match the final audited legacy records. The archive
keeps the earlier full-suite failure and out-of-band comparison under
`candidate`, with their distinct source identity.

The new test file is copied here for reproduction on the parent. Fourteen
cases fail for the documented behavior and four controls pass.

```sh
PYTHONPATH=. PYTHONHASHSEED=0 python -m pytest -q --tb=short /path/to/evidence/test_sixth_comparison_events.py
```

The paired records use the audited parent outcomes already published in the
fifth repair and sixth audit evidence. Both sets match the parent Python
source hash. Each trace checks its requested source hash, winner, game length
and final board digest. Run the trace command in each matching checkout,
then compare the traces using the third command.

```sh
PYTHONPATH=. PYTHONHASHSEED=0 python /path/to/evidence/trace_events.py /path/to/evidence/trace-parent-input.json /path/to/parent-trace.json
PYTHONPATH=. PYTHONHASHSEED=0 python /path/to/evidence/trace_events.py /path/to/evidence/final/trace-input.json /path/to/repaired-trace.json
python /path/to/evidence/compare_event_traces.py /path/to/parent-trace.json /path/to/repaired-trace.json /path/to/first-divergences.json
```

`final/first-divergences.json` retains the card, choices and before/after
piece counts for the first difference in each of 20 changed-winner cases.
`final/paired-outcomes.json` covers all 120 paired game keys. The full final
bot and mixed-player records are included.
