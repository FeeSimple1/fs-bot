# Eleventh comparison audit evidence

The audit reviewed Falling Sky commit
`702d60a3754ce94a73ead0d0148d647232ecd816` on Python 3.12.14.
Its 626 Python files have SHA-256
`489efe1d5b60a36f47ac5b7b46fd47595246d770606e32f6fa78d5b5b8d6a9e0`.
`validation/source.json` and `validation/protected-sources.json` identify the
inputs. The report and ledger describe eight open findings and five repair
batches. `SHA256SUMS` covers every other archive member.

## Directed reproduction

Use the repository's test environment and extract this archive. From any
directory, run the following with the audited source available locally.

```bash
python /path/to/evidence/run_witnesses.py --repo /path/to/fs-bot
```

The runner verifies the source digest and protected references, runs the five
probes at hash seeds 0 and 987, and compares outputs to the preserved records.
Each probe asserts the observed failures and controls. Repairs will change
those expectations. The lane reports give supplied-rule anchors, implementation
locations, fixture construction, limits and earlier-audit distinctions.

## General validation

From the audited repository, set `OUT` to a new absolute output directory.
Install the repository's development test requirements. The recorded parallel
test run also used pytest-xdist. An ordinary `python -m pytest -q` runs the same
suite sequentially.

```bash
PYTHONHASHSEED=0 python -m pytest -q -n 4 -o cache_dir="$OUT/pytest-cache" --junitxml="$OUT/pytest.xml"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 57-60 --card-edition second-edition --workers 2 --out "$OUT/bots"
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 57-60 --card-edition second-edition --out "$OUT/fuzz0.json"
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 57-60 --card-edition second-edition --out "$OUT/fuzz987.json"
PYTHONPATH=. python /path/to/evidence/validation/verify_validation.py
```

The final verifier checks the existing archived records against the audited
checkout and writes its derived summaries beside them. Exact original commands,
exit codes and timings are preserved in `validation/commands.json`. The first
pytest launch rejected a relative cache path before collection. Its log and
successful retry are both retained. The suite passed all 10,379 tests. All
20 bot games completed, with 329 legal-decline diagnostics and two Interludes.
Twenty mixed-seat cases match byte for byte across hash seeds and include
internal replay. Four soft partial plans and 40 rejected random plans remain
in the records, with zero hard findings.

The local full suite includes the existing 15-game canary. The 100-game balance
guardrail and other GitHub successes belong to the audited commit and are
recorded in `parent-github-checks.json`. `comparator-review.md` and each lane
report identify the actual Liberty or Death code inspected. The general test
and game samples provide bounded coverage alongside the directed findings.
