import json,sys
from pathlib import Path
from fs_bot import rules_consts as rc
from fs_bot.tools import run_batch as batch
from fs_bot.state.serialize import encode
from fs_bot.cards import circumvallation as cv
rows=[];clears=[]
original=batch.play_card
if '--disable-cleanup' in sys.argv:
    cv.clear_without_romans=lambda state,region: None
if hasattr(cv,'clear_without_romans'):
    original_clear=cv.clear_without_romans
    def clear(state,region):
        before=rc.MARKER_CIRCUMVALLATION in state.get('markers',{}).get(region,{})
        original_clear(state,region)
        if before and rc.MARKER_CIRCUMVALLATION not in state['markers'][region]:
            clears.append({'current_card':state['current_card'],'region':region,
                           'romans':encode(state['spaces'][region].get('pieces',{}).get(rc.ROMANS,{}))})
    cv.clear_without_romans=clear

def card(state,*args,**kwargs):
    result=original(state,*args,**kwargs)
    rows.append({'card':result.get('card_id'), 'state':encode({k:state.get(k) for k in
        ('scenario','spaces','tribes','markers','resources','rng','interlude_completed','deck','current_card')})})
    return result
batch.play_card=card
record=batch.play_one((rc.SCENARIO_GALLIC_WAR,1,'legacy'))
Path(sys.argv[1]).write_text(json.dumps({'record':record,'cards':rows,'clears':clears},indent=2)+'\n')
