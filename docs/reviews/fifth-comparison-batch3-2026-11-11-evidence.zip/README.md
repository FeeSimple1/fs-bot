# Fifth comparison repair Batch 3 evidence

The parent is Falling Sky commit `e9a4088376619ee3b59f6d4fdd13b9a3a2f4db0b`.
`summary.json` identifies the tested Python sources and records the checks.
`SHA256SUMS.json` contains the archive checksums. `parent-witnesses.json`
reproduces the original fifth-audit observations on the Batch 2 parent.

Run these checks from the relevant checkout with Python 3.12, pytest and
pytest-xdist. Use a fresh results directory for each matrix.

```sh
PYTHONHASHSEED=0 python -m pytest -q -n 5 --tb=short --show-capture=no
PYTHONHASHSEED=0 python -m pytest -q --tb=short --show-capture=no fs_bot/tests/test_fifth_comparison_free_march.py fs_bot/tests/test_event_free_choices.py
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out /path/to/results/bots-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 29-32 --card-edition second-edition --workers 2 --out /path/to/results/bots-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 29-32 --card-edition second-edition --out /path/to/results/fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 29-32 --card-edition second-edition --out /path/to/results/fuzz987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
```

Run the new test file against a disposable parent checkout to reproduce the
ten expected failures and eight passing controls. `PYTHONPATH=.` selects the
parent code when the test file is outside the checkout.

```sh
PYTHONPATH=. PYTHONHASHSEED=0 python -m pytest -q --tb=short --show-capture=no /path/to/evidence/test_fifth_comparison_free_march.py
```

The 120 paired bot records use the Batch 2 evidence as their parent.
The directed durable tests cover live drop-offs, rejecting and correcting
illegal replies under the same decision ID, and replay with older defaults.
