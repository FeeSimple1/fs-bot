"""Reproduce fifth-audit observations against a supplied fs-bot checkout.

Usage: python run_probes.py /path/to/fs-bot /path/to/new-results
Assertions intentionally describe defects on the audited source. The Optimates
section records an unresolved interpretation, not an expected repair.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys


def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    repo, out = (Path(arg).resolve() for arg in sys.argv[1:])
    evidence = Path(__file__).resolve().parent
    if not (repo / 'fs_bot').is_dir():
        raise SystemExit('The first argument must contain the fs_bot package.')
    out.mkdir(parents=True, exist_ok=False)
    digest = hashlib.sha256()
    for path in sorted((repo / 'fs_bot').rglob('*.py')):
        digest.update(str(path.relative_to(repo)).encode() + b'\0' + path.read_bytes())
    source = digest.hexdigest()
    expected = json.loads((evidence / 'validation/source.json').read_text())
    if source != expected['source_sha256']:
        raise SystemExit('Python source differs from the audited revision. '
                         'Use the recorded audit commit to reproduce these observations.')
    cases = [
        ('bots/probe_bots.py', 'bots/probe_bots-output.json'),
        ('battle/probe_battle.py', 'battle/probe_battle.json'),
        ('events/probe_events.py', 'events/observed.json'),
        ('frontend/probe_frontend.py', 'frontend/probe-output.json'),
        ('lifecycle/probe_lifecycle.py', 'lifecycle/probe_lifecycle.json'),
    ]
    env = dict(os.environ, PYTHONPATH=str(repo), PYTHONHASHSEED='0',
               PYTHONDONTWRITEBYTECODE='1')
    rows = []
    for script, original in cases:
        path = evidence / script
        prefix = script.replace('/', '--').removesuffix('.py')
        run = subprocess.run([sys.executable, str(path)], cwd=repo, env=env,
                             capture_output=True, timeout=300)
        (out / (prefix + '.json')).write_bytes(run.stdout)
        (out / (prefix + '.stderr')).write_bytes(run.stderr)
        try:
            same = json.loads(run.stdout) == json.loads((evidence / original).read_bytes())
        except (ValueError, UnicodeError):
            same = False
        row = {'script': script, 'script_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
               'exit_code': run.returncode, 'matches_recorded_json': same,
               'output': prefix + '.json', 'stderr': prefix + '.stderr'}
        rows.append(row)
        print(f'{script}: exit={run.returncode}, matches={same}', flush=True)
    summary = {'source_sha256': source, 'audited_commit': expected['commit'],
               'python': sys.version.split()[0], 'witnesses': rows,
               'all_pass': all(r['exit_code'] == 0 and r['matches_recorded_json'] for r in rows)}
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    return 0 if summary['all_pass'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
