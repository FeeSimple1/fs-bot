from pathlib import Path
import hashlib,json,platform,re,subprocess,xml.etree.ElementTree as ET,zipfile
from fs_bot.tools.validation_metadata import source_identity
prefix='scout-allocations-2026-11-04';result=json.loads(Path('/tmp/fs-scout-results.json').read_text())
assert source_identity()['source_sha256']==result['source']['source_sha256']=='51e1c13b45ee217dcbeeaabea806ea094575b8cac1fe54258a1948b5ac5edf2c'
suite=ET.parse('/tmp/fs-scout-full.xml').getroot().find('testsuite')
assert suite.attrib['tests']=='8320' and all(suite.attrib[k]=='0' for k in ('errors','failures','skipped'))
assert Path('/tmp/test_scout_allocations_parent.py').read_bytes()==Path('fs_bot/tests/test_scout_allocations.py').read_bytes()
proof=ET.parse('/tmp/fs-scout-parent.xml').getroot().find('testsuite')
assert proof.attrib['tests']=='20' and proof.attrib['failures']=='13' and proof.attrib['errors']=='0'
assert all('assert' in t.find('failure').attrib['message'].lower() for t in proof if t.find('failure') is not None)
log=Path('/tmp/fs-scout-targeted-accepted.log').read_text();assert re.search(r'\n337 passed in ',log) and 'failed' not in log
result['full_suite']=suite.attrib;result['parent_suite']=proof.attrib;result['python']=platform.python_version()
Path('docs/reviews/'+prefix+'-results.json').write_text(json.dumps(result,indent=2)+'\n')
p=Path('docs/reviews/'+prefix+'.md');s=p.read_text().replace('Final full suite pending.',f"**8,320 tests pass** in the final full suite ({float(suite.attrib['time']):.2f} seconds), with zero failures, errors or skips.").replace('Parent behavioral proof pending.', '''The unchanged new tests run against existing APIs in an isolated parent:
**13 behavioral failures** reproduce ignored grouped targets, wrong visibility,
missing rejection and incomplete consent targeting; **seven controls pass**,
with 40 cases deselected. No missing helper import is counted as proof.''').replace('Results pending final inspection.', '''All ten native-bot records complete and audit cleanly, with no errors or
integrity findings, four ranked factions, consistent winner/ranking fields and
nonempty final hashes. Every gameplay field and final hash matches the parent;
only elapsed seconds, commit and source digest are excluded from comparison.
Both mixed-seat outputs agree in complete JSON across hash seeds: 356 human
turns, 96 Event attempts, 90 successful Events, zero hard findings, zero partials,
batch digest `d899b5732da10db5`. Internal replay makes 40 executions in total.''');balance = result['balance_smoke']
s = s.replace('BALANCE_REPORT_PLACEHOLDER', (
    'The 100-game historical balance check covers all five scenarios and seeds 1–20. '
    f"It passes the unchanged 15-point band, with a largest difference of "
    f"{balance['maximum_absolute_delta_percentage_points']} percentage points and "
    f"{balance['historical_baseline_winner_changes']} different winners versus the historical baseline. "
    "The ten directly paired games compare against the parent commit."
))
p.write_text(s)
p=Path('docs/current-status.md');s=p.read_text().replace('Validation: see the final report and machine-readable results.', '''**8,320 tests pass**, including 60 new cases; 337 targeted tests pass. Ten
native-bot gameplay records/final hashes match parent. Forty mixed executions
agree across hash seeds with zero hard findings or partials. The 100-game
balance check passes its unchanged band. See the report
for frozen source provenance and evidence bounds.''',1);p.write_text(s)
entries={}
for name in ('fs-scout-full.xml', 'fs-scout-full.log'):
 entries['rejected/obsolete-yes-no-fixture/'+name]=Path('/tmp/fs-scout-pre-fixture/'+name).read_bytes()
entries['rejected/obsolete-yes-no-fixture/README.txt']=b'Source f08673faf7d18b01fb60823f202be8b0a85733e55ce7acbf1572c6c13a27b4c5: 8319 passed and one old yes/no collector script failed with EOF. The accepted source updates that script to finish both menus and assert (None, None). This run is not accepted evidence.\n'
for file in ['/tmp/fs-scout-full.xml','/tmp/fs-scout-full.log','/tmp/fs-scout-balance.log','/tmp/fs-scout-targeted-accepted.log','/tmp/fs-scout-parent.xml','/tmp/fs-scout-parent.log','/tmp/test_scout_allocations_parent.py','/tmp/fs-scout-mixed0.json','/tmp/fs-scout-mixed0.log','/tmp/fs-scout-mixed987.json','/tmp/fs-scout-mixed987.log','/tmp/fs-scout-verify.py','/tmp/fs-scout-package.py']:
 entries['accepted/'+Path(file).name]=Path(file).read_bytes()
for label,directory in [('parent','/tmp/fs-scout-bots-parent'),('accepted','/tmp/fs-scout-bots-final')]:
 for p in Path(directory).iterdir():
  if p.is_file():entries[label+'/bots/'+p.name]=p.read_bytes()
entries['accepted/results.json']=json.dumps(result,indent=2).encode()
entries['accepted/source.patch']=subprocess.check_output(['git','diff','HEAD','--','fs_bot'])
name='fs_bot/tests/test_scout_allocations.py';entries['accepted/'+name]=Path(name).read_bytes()
protected=[p for p in Path('Reference Documents').rglob('*') if p.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
entries['accepted/protected-inputs.json']=json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected},indent=2).encode()
entries['commands.txt']=b'''Accepted source: parent a7fc41005705d0255034b4239d9f5091d28176c0 plus accepted/source.patch and accepted/fs_bot/tests/test_scout_allocations.py.
python -m pytest -q --junitxml=/tmp/fs-scout-full.xml
python -m pytest -q fs_bot/tests/test_scout_allocations.py fs_bot/tests/test_special_activities.py fs_bot/tests/test_action_window_frontends.py fs_bot/tests/test_diviciacus*.py fs_bot/tests/test_dumnorix_action_windows.py fs_bot/tests/test_assistant_session.py fs_bot/tests/test_human_plan.py::TestHumanPlanCollection::test_sa_collector_contract_build_scout
In isolated unmodified parent checkout, with unchanged new test file copied outside the tree:
PYTHONPATH=/tmp/fs-scout-parent python -m pytest -q /tmp/test_scout_allocations_parent.py -k 'dispatcher_uses_one_auxilia_for_two_factions or native_selects_exact_target_visibility or legacy_count_only_targets or native_legacy_multi_faction or later_invalid_group_restores_prior_reveal or two_groups_cannot_reuse or scout_reveal_can_work_in_britannia or grouped_targets_are_visible' --junitxml=/tmp/fs-scout-parent.xml
In parent and accepted trees separately, with distinct output directories:
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --games 2 --workers 2 --out OUT
In accepted tree:
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out /tmp/fs-scout-mixed0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out /tmp/fs-scout-mixed987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
PYTHONPATH=. python /tmp/fs-scout-verify.py
PYTHONPATH=. python /tmp/fs-scout-package.py
'''
entries['README.txt']=b'Accepted Python source 51e1c13b45ee217dcbeeaabea806ea094575b8cac1fe54258a1948b5ac5edf2c over parent a7fc41005705d0255034b4239d9f5091d28176c0. Apply source.patch and add the accepted test file to reconstruct frozen sources. Full suite:8320 passed; 60 new cases. Isolated-parent proof:13 behavioral failures, seven controls pass, 40 deselected. All ten native-bot records/final hashes match parent except timing/source provenance. Mixed outputs agree in complete JSON across hash seeds0/987 with zero hard findings/partials and 40 executions including replay. The 100-game historical balance guard passes its unchanged 15-point band.\n'
entries['SHA256SUMS.txt']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(entries.items())).encode()
p=Path('docs/reviews/'+prefix+'-evidence.zip')
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(entries.items()):z.writestr(name,data)
print(json.dumps({'full_suite':suite.attrib,'targeted':337,'evidence_bytes':p.stat().st_size,'source':result['source']}))
