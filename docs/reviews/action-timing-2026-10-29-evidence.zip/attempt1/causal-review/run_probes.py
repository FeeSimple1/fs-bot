from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,json,os,subprocess,time
ROOT=Path(__file__).resolve().parent
PYTHON='/workspace/scratch/534c265c65f4/fs-test-venv/bin/python'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def run(job):
 folder,side,cwd=job
 out=folder/(side+'.probe.json');log=folder/(side+'.probe.log')
 argv=[PYTHON,str(ROOT/'probe_boundary.py'),'--folder',str(folder),'--side',side]
 if out.exists():
  d=json.loads(out.read_text());assert d['output_state_matches_trace'] and d['output_payload_matches_trace'];return {'folder':str(folder),'side':side,'reused':True,'output_sha256':sha(out)}
 start=time.monotonic()
 with log.open('x') as stream: proc=subprocess.run(argv,cwd=cwd,env=dict(os.environ,PYTHONHASHSEED='0'),stdout=stream,stderr=subprocess.STDOUT)
 status={'folder':str(folder),'side':side,'cwd':str(cwd),'argv':argv,'PYTHONHASHSEED':'0','exit_code':proc.returncode,'seconds':time.monotonic()-start,'output_sha256':sha(out) if out.exists() else None,'log_sha256':sha(log)}
 (folder/(side+'.probe.status.json')).write_text(json.dumps(status,indent=2,sort_keys=True)+'\n')
 return status

jobs=[]
for p in sorted(ROOT.glob('*/semantic-review.json')):
 report=json.loads(p.read_text());first=report['first_mechanical_difference']
 if not first or not(first['changed_domains']==['rng'] or report['provisional_category'].startswith('Roman decision')):continue
 for side,cwd in [('parent',Path('/workspace/scratch/534c265c65f4/fs-action-timing-parent')),('candidate',ROOT.parent/'python-source')]:jobs.append((p.parent,side,cwd))
statuses=[]
with ThreadPoolExecutor(max_workers=4) as pool:
 for result in pool.map(run,jobs):statuses.append(result)
report={'scripts':{p.name:sha(p) for p in (Path(__file__),ROOT/'probe_boundary.py')},'cases':len(jobs)//2,'statuses':statuses,'all_passed':all(s.get('reused') or s['exit_code']==0 for s in statuses)}
(ROOT/'probe-matrix.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'cases':report['cases'],'all_passed':report['all_passed']}))
raise SystemExit(0 if report['all_passed'] else 1)
