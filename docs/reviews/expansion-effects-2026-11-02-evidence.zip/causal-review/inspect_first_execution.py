"""Replay just the captured first differing execution with read-only RNG tracing."""
import gzip, hashlib, json, sys
from pathlib import Path
root = Path(__file__).resolve().parent
sys.path.insert(0, str(root.parents[1] / 'fs-bot'))
from fs_bot.cards import gallia_evacuation as evacuation
from fs_bot.engine import execute
from fs_bot.state.serialize import decode, encode
pair = json.loads((root/'first-divergence.json').read_text())
row=pair['candidate']; state=decode(row['before']); decision=decode(row['decision'])
original=evacuation._random_slot
calls=[]
def sha(rng):
    return hashlib.sha256(json.dumps(encode(rng),sort_keys=True).encode()).hexdigest()
def traced(board, options):
    before=sha(board['rng']); slot=original(board,options)
    calls.append({'options': options, 'selected':slot,'rng_before_sha256':before,
                  'rng_after_sha256':sha(board['rng'])})
    return slot
evacuation._random_slot=traced
result=execute.execute_decision(state,row['faction'],decision)
assert encode(result)==row['result']
assert encode(state)==row['after']
record={'execution_replay_exact':True,'random_slot_calls':calls,
        'before_regions':{r:row['before']['spaces'][r] for r in ('Cisalpina','Sugambri','Ubii')},
        'parent_after_regions':{r:pair['parent']['after']['spaces'][r] for r in ('Cisalpina','Sugambri','Ubii')},
        'candidate_after_regions':{r:row['after']['spaces'][r] for r in ('Cisalpina','Sugambri','Ubii')},
        'changed_tribes':{t:{'before':row['before']['tribes'][t],
            'parent':pair['parent']['after']['tribes'][t], 'candidate':row['after']['tribes'][t]}
            for t in row['before']['tribes'] if pair['parent']['after']['tribes'][t]!=row['after']['tribes'][t]}}
(root/'first-execution-replay.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'execution_replay_exact':True,'random_slot_calls':calls},indent=2))
