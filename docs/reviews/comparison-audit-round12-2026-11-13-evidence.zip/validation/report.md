# Twelfth audit independent validation

Fresh held-out validation used clean Falling Sky commit `1563e41d84f61dfce43ce4008106eca2a1639aed`, Python 3.12.14. The 629-file Python source SHA-256 is `7cb64407ff5594eb2bbd671a8159c408410fa8cc26e7a784da7afe0fd47363db`. The comparator is Liberty or Death commit `2991ea279062773548ec390a1da75f3e85381702`. All 47 supplied reference files and `fs_bot/rules_consts.py` match the captured hash inventory and the previous audit inventory.

| Check | Result |
| --- | --- |
| Fresh full pytest suite | 10,449 passed, zero failures/errors/skips, five external anyio deprecation warnings, 122.71 seconds |
| Audited second-edition bot games | 20 attempted, 20 completed across all five scenarios and seeds 71–74 |
| Bot errors, integrity and ranking issues | Zero in each category |
| Bot diagnostics | 142 per-game groups and 329 individual occurrences, all independently reclassified as legal declines |
| Bot Interlude | The Gallic War seed 71 |
| Mixed second-edition cases | 20 completed per hash seed, 0 and 987, including internal replay for 80 executions total |
| Mixed process comparison | Complete JSON and stdout are byte-identical |
| Mixed activity per sample | 617 human turns, 152 Event turns, 136 executed Events |
| Mixed findings | Zero hard findings, five partial plans, 37 rejected random plans |
| Mixed Interlude | The Gallic War seed 74 |

Five partial plans occurred in four completed games, comprising Pax Gallica seed 71, Great Revolt seed 71, Reconquest seed 73 and Gallic War seed 74. Gallic War accounts for two partial plans. These results remain visible in the archived records. Every sampled game completed without a hard finding. The batch digest is `680a3a9d4d2bcc8afc4d455da17026034565dbec47dee685ccbd6091bb863b26`.

Every bot record was checked for all three completion flags, emitted and recomputed ranking agreement, winner eligibility, census and structural integrity, diagnostic severity, exact source and edition identity, and final-state digest. The raw diagnostics and their recalculated severity appear in `diagnostic-review.json`. Exact scenario/seed coverage and per-game checks appear in `bot-record-checks.json` and `mixed-record-checks.json`.

The required fresh full test suite passed 10,449 tests, including the existing 15-game legacy balance canary. All 14 prior GitHub checks on this exact audited commit also passed. The fresh sample adds previously unused held-out seeds. The separate 100-game balance guardrail was not rerun and no balance baseline was changed. Sampled legal execution cannot establish every printed bot priority or rule interpretation, so directed witnesses undergo separate review.

## Reproduction

From the audited checkout, run the commands below with a new output folder selected as `OUT`. `REPO` is the audited checkout. The Python environment used here was `/workspace/scratch/4aba5bd9b1ab/fs-bot/.venv/bin/python`.

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 python -m pytest -q -n 4 -o cache_dir="$OUT/pytest-cache" --junitxml="$OUT/full.xml"
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 71-74 --card-edition second-edition --workers 1 --out "$OUT/bots"
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 71-74 --card-edition second-edition --out "$OUT/fuzz0.json" > "$OUT/fuzz0.log"
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 71-74 --card-edition second-edition --out "$OUT/fuzz987.json" > "$OUT/fuzz987.log"
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$REPO" python "$OUT/verify_validation.py"
```

`verify_validation.py` validates the saved records without rerunning gameplay. `source.json`, `protected-sources.json` and `reference-inventory.txt` identify the audited inputs. `baseline-github-checks.json` and `baseline-test-summary.json` preserve the prior baseline checks. Directed evidence review and probe reruns are recorded separately in `independent-review.json` and the `review` folder.
