# Independent review of eleventh-audit directed witnesses

All eight reported groups are supported by the bounded source and public-path evidence below. This review uses the supplied Falling Sky references and current source at `702d60a3754ce94a73ead0d0148d647232ecd816`. It evaluates actual public consequences and matched controls, and distinguishes earlier repairs from newly exercised consumers. Reproducer success means a claimed defect and its controls reproduced; it does not mean the defect is fixed. Exact commands, source snapshots, and output hashes are retained in `reruns.json`.

## BM11-01: active Abatis defeats Divination's claimed guaranteed high-value Loss

Independently read the final six-case probe and the direct A34 path. In the principal case, raw calculation and live resolver both inflict three Losses. Public A34 nevertheless selects Battle for the Aedui beneficiary because `_high_value_forced` assumes the third Loss must reach the Belgic Ally. The real human defender declines Retreat, removes the two Warbands, then chooses the active Abatis for the third Loss. The Ally survives. A no-Ariovistus variant has the same failure, so this is not the round-10 cancellation arithmetic bug. No-Abatis, lower-Loss, no-Ally, and repaired Stalwart controls behave correctly.

Supplied Chapter 3 lines 323–338 permits a defender to choose its Ally or Fort after all other pieces have gone. A64 acts as a Fort (A Card Reference 288–292). The high-value set in Chapter 8 lines 448–462 names Leaders, Allies, Citadels and Legions, not Forts; the player has a legal way to avoid such a Loss. Chapter 8 lines 105–118 applies the beneficiary's flowchart to A34. The ordinary Aedui predicate already returns false on the same position.

This is a newly confirmed A34 consumer of the earlier NP6-02 target-guarantee class, not a new general class or a failure of the repaired ordinary consumer. BM10 used an inactive marker suppressing Ariovistus doubling; this case uses an active marker absorbing a correctly calculated Loss. Both independent hash runs match the frozen result. Controlled legal positions establish the choice error, not natural-game frequency.

## NP11-01: Belgic March misses newly legal Enlist

All seven Belgic cases reproduce. The principal ordinary March moves the named Leader so that a legal Enlist can Hide two Revealed German Warbands at Treveri. The pre-March board has no Enlist; the bot's No SA label survives the move and both Germans remain Revealed. An authored Enlist label on the same action reaches the live selector and hides both. Preexisting legal Enlist works, stale-positive Enlist declines, and Command-only, absent-German, and scoped-free-command controls preserve their restrictions.

Chapter 8 lines 410–412 explicitly requires Enlist after the ordinary Belgic March, using the chain at 315–338. The conditional location is the actual post-March Leader position. This extends the stale pre-Command SA family to a distinct Belgic March consumer. NP9-02 covered Arverni Rally and Belgic Raid; NP10-01 covered Arverni March. The fixture uses Pax Gallica, where named Ambiorix is legal; its persistent Devastated markers are disclosed synthetic legal state, not a claim of a naturally reached history. The scoped free-command case is a lower API control, not the principal public witness.

## NP11-02: the surrounded German Leader branch is unreachable

The five German cases confirm a separate branch error. All real piece pools are placed, the G1b and Rally gates are inactive, and no faction initially wins. Ariovistus in Ubii and every adjacent Region is under German Control, while a non-German-Control destination can be approached through Treveri. The public bot incorrectly Raids and leaves Ariovistus with 26 Warbands. A public authored March moves Ariovistus and 25 Warbands to Treveri, leaves one in Ubii, retains Control and pays one Resource. Adjacent-target March, Frost, and absent-Leader controls behave as specified.

A8.7.5 lines 221–241 requires a surrounded Leader and his able Warbands to move toward a Region without German Control; it does not require the immediate destination itself to lack German Control. Code `german_bot.py:1483–1496` first requires every adjacent Region to have German Control, then searches those same adjacent Regions for one without it. That conjunction is impossible. This is not merely an undesirable random choice or a broken legality executor: the selected flowchart branch cannot ever supply its destination. The explicit legal move proves the public consequence. Prior post-Command SA and ordinary March destination repairs concern other decisions.

## EV11-01: Lucterius admission and restoration plan

All six natural bot executions are ineffective: named Vercingetorix is already present in two cases, while an Available leader or on-map Successor lacks the target parameter in four cases. Four matched explicit target controls restore Vercingetorix; named-leader controls correctly do nothing. All six Event-disabled controls execute an ordinary Command with effects. Queries preserve board and RNG, and all physical setup/execution checks pass.

Card 19 (Card Reference 181–190) conditions shaded text on a Successor on-map or Available, and then requires placement. Chapter 8's ineffective-Event gate precedes its Auto 1–4 branch; the Carnyx is not authorization for a no-op. This is absent Non-player admission/target production, beyond BE2-04's explicit target legality and same-Region restoration. These two subcases concern one card's automated execution and should remain grouped.

## EV11-02: Assembly of Gaul omits required resource targets

Six source-valid natural Events leave Resources untouched with Carnutes Subdued. Explicit target controls drain the printed eight Resources from the proper player enemies; Arverni-Allied Carnutes controls correctly do nothing. Card 52 (Card Reference 518–526) requires one or more targets when its condition holds. Roman/Aedui Event instructions specify Arverni/Belgae in base scenarios and eligible expansion targets; Chapter 8 section 8.2.1 gives those instructions priority. The fixture preserves those seat distinctions and does not use game-run Arverni as an expansion Resource target.

This is a missing automatic target producer, separate from BE2-02's duplicate-drain validation and earlier shaded Assembly free-action work. The explicit Event handler can carry out the required outcome on the same board.

## EV11-03: Shifting Loyalties follows acquisition order instead of Roman instructions

Three principal cases acquire beneficial unshaded Titus Labienus before player-Belgae shaded Commius. Natural Roman execution removes Titus rather than Commius. Reversed acquisition controls remove Commius, exposing dictionary insertion order rather than the printed priority. Explicit Commius removal works in all three scenarios.

Card 50 permits one Capability removal; Roman instruction sheets require a shaded Capability affecting player Arverni/Belgae, or Germans/Belgae in expansion, before the Roman fallback. Card 12 unshaded benefits Roman SA reach; card 55 shaded benefits Belgic Rally. This is a concrete loss of a beneficial Roman Capability while the required enemy target survives. Earlier capability menu/type and Event acquisition repairs concern different consumers. Independent source review and both hash runs support this bounded priority finding.

## LC11-01: Interlude incorrectly protects three expansion Arverni Homes

All 54 public third-Winter cases reproduced. Each of Veneti, Carnutes and Pictones retains four Arverni Warbands while the equal four-Warband Sequani cohort is entirely removed, across twelve seeds per Home. Ordinary Mandubii/Sequani controls remove either cohort (7/5), the named Arverni Region remains last, and explicit human removal from each other Home succeeds. The public Winter reaches the Interlude with no threshold winner and retains physical integrity.

The supplied Gallic War scenario is decisive: its Adjust Forces introduction explicitly exempts the German player and Arverni from the general Home-last rule, then the Arverni reduction paragraph singles out the Arverni Region as last. It also explicitly tells Non-players to remove Region by Region at random. Chapter 8 sections 8.3.4 and 8.4.1 do not add a different Region-protection tier: equal candidate Regions randomize; physical removal priorities apply once spaces are selected.

The proof is not just an improbable sample. `_np_arverni_reductions` partitions every expansion Home after all ordinary Regions. With a four-Warband reduction exhausted in Sequani, the other Home has zero chance of selection. The correct exception for the named Arverni Region is broadened to Veneti/Carnutes/Pictones. This is a distinct Non-player ordering consumer; human eligibility and exact reduction quotas are separate. Final probe marks Romans human for the explicit Britannia decline, preserving source legality. The fixture supplies a third-Winter cursor; it does not claim a naturally played history or complete-board cross-hash coverage beyond the recorded result.

## UI11-01: terminal Winter Campaign cannot compose borrowed Enlist with a Command

The final probe's five terminal failures and nine controls reproduce identically. Public shaded 63/A63 acquisition grants the window. Choosing the offered borrowing Enlist mode generates a standalone SA plan that is rejected as an unknown free Enlist sub-Command; both action slots remain unused. The exact combined borrowed Raid+Enlist plan succeeds in a saved/reloaded SeatSession in every scenario, consumes two action slots, gains two Resources, and reveals the actual German Warbands. Ordinary terminal borrowing and the distinct free-German March mode work in both representative rulesets.

Card 63/A63 allows two Commands/SAs after Harvest. Chapter 4 section 4.5.1 permits lending German Warbands to the accompanying Belgic Command, and A4.5.1's four-piece/no-Ariovistus constraints are respected by these two-Warband fixtures. The backend already executes the lawful combination; the terminal authoring path offers the borrow option without composing the required Command. This differs from prior Winter Campaign duplicate-Battle validation and live March drop-offs, and from ordinary Enlist cohort/visibility repairs. The result is interface reachability, not a claim that the durable API cannot represent the action.

## Scope

No production implementation, rule reference, or balance baseline was changed in this lane. Passing baseline tests and random games do not supersede these directed findings. Earlier findings are cited as scoped mechanisms and controls rather than silently counted again. Each report remains limited to its actual public entrypoints, physical fixtures, and source-supported consequence.
