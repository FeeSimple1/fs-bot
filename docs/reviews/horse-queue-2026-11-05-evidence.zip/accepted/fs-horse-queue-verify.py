from pathlib import Path
import json
import re
import subprocess
import xml.etree.ElementTree as ET
from fs_bot import rules_consts as rc
from fs_bot.tools.validation_metadata import source_identity

parent='fee12ab101a2aa079ed4c295295f39ac2ad1f02a'
source=source_identity()
assert source['source_sha256']=='0b00cd086e6c6b5956ee0bdaa831617b168b67de39b2e3553abe1dfe65cfe958'
assert len(list(Path('fs_bot').rglob('*.py')))==523
records={}
for label,directory in [('parent','/tmp/fs-horse-queue-bots-parent'),('accepted','/tmp/fs-horse-queue-bots-final')]:
    rows=[json.loads(line) for line in Path(directory+'/games.jsonl').read_text().splitlines()]
    records[label]={(row['scenario'],row['seed']):row for row in rows}
    assert len(rows)==10 and set(records[label])=={(s,n) for s in rc.ALL_SCENARIOS for n in (1,2)}
    for row in rows:
        assert all(row[key] for key in ('completed','game_completed','audit_completed','final_state_sha256'))
        assert not row['errors'] and not row['integrity_findings']
        assert len(row['final_ranking'])==4 and not row['winner_differs_from_highest_margin']
        assert not row['engine_ranking_output_missing']
        assert all(d['severity']=='legal-decline' for d in row['diagnostics'])
ignored={'seconds','commit','source_sha256'}
for key,old in records['parent'].items():
    new=records['accepted'][key]
    assert {k:v for k,v in old.items() if k not in ignored}=={k:v for k,v in new.items() if k not in ignored},key
assert records['accepted'][rc.SCENARIO_GALLIC_WAR,1]['interlude_completed']
assert json.loads(Path('/tmp/fs-horse-queue-bots-parent/metadata.json').read_text())['source_sha256']=='693cfe397282ec48411d56011afbf5c600f836858376ddd08430e1eb2fc190a2'
assert json.loads(Path('/tmp/fs-horse-queue-bots-final/metadata.json').read_text())['source_sha256']==source['source_sha256']
mixed=json.loads(Path('/tmp/fs-horse-queue-mixed0.json').read_text())
assert mixed==json.loads(Path('/tmp/fs-horse-queue-mixed987.json').read_text())
assert not mixed['hard_findings'] and mixed['partial']==0 and all(r['game_completed'] for r in mixed['records'])
assert mixed['metadata']['source_sha256']==source['source_sha256']
protected=[p for p in Path('Reference Documents').rglob('*') if p.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
assert len(protected)==49
for path in protected:
    assert path.read_bytes()==subprocess.check_output(['git','show',parent+':'+str(path)])
proof=ET.parse('/tmp/fs-horse-queue-proof-parent.xml').getroot().find('testsuite')
assert proof.attrib['tests']=='5' and proof.attrib['failures']=='3' and proof.attrib['errors']=='0'
assert all(('assert' in t.find('failure').attrib['message'].lower() or
            'did not raise' in t.find('failure').attrib['message'].lower())
           for t in proof if t.find('failure') is not None)
accepted_proof=ET.parse('/tmp/fs-horse-queue-proof-final.xml').getroot().find('testsuite')
assert accepted_proof.attrib['tests']=='5' and accepted_proof.attrib['failures']=='0' and accepted_proof.attrib['errors']=='0'
assert re.search(r'\n226 passed in ',Path('/tmp/fs-horse-queue-targeted.log').read_text())
log=Path('/tmp/fs-horse-queue-balance.log').read_text()
rows=re.findall(r'^\[(.*?) seed=\s*(\d+)\] winner=(.*?) \((\d+) cards\)$',log,re.M)
assert len(rows)==100 and {(s,int(n)) for s,n,_,_ in rows}=={(s,n) for s in rc.ALL_SCENARIOS for n in range(1,21)}
deltas=[abs(int(v)) for v in re.findall(r'\(([+-]\d+)%\)',log)]
assert deltas and max(deltas)<=15 and 'OK: balance within band' in log
changes=int(re.search(r'OK: balance within band \((\d+) winner changes\)',log)[1])
result={'date':'2026-11-05','timezone':'America/Chicago','source':source,'python_files':523,
        'protected_files':49,'protected_files_unchanged':True,'new_tests':28,'targeted_passed':226,
        'parent_proof':{'behavioral_failures':3,'controls_passed':2,'accepted_passed':5},
        'bots':{'games':10,'all_completed_and_audited':True,'gameplay_and_final_hashes_equal':True,
                'interlude_exercised':{'scenario':rc.SCENARIO_GALLIC_WAR,'seed':1},'excluded':sorted(ignored)},
        'mixed':mixed,'mixed_complete_json_equal':True,'hash_seeds':[0,987],'mixed_executions_including_replay':40,
        'balance':{'games':100,'band_percentage_points':15,'maximum_absolute_delta_percentage_points':max(deltas),
                   'historical_baseline_winner_changes':changes,'baseline_unchanged':True,'passed':True},
        'progress':{'closed':39,'total':50,'percent':78,'open':11},
        'remaining':'BE-09 remains open for mandatory Card 13/59-shaded queue timing pending Q-CAPABILITY-QUEUE-TIMING; three source questions remain. Original bundle remains 39/50 closed. Separate mechanics leads and source questions retain their dispositions.'}
Path('/tmp/fs-horse-queue-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':source,'bots_equal':10,'mixed_equal':True,'hard_findings':0,'partials':0,
                  'new_cases':28,'targeted':226,'balance_max_delta_pp':max(deltas)}))
