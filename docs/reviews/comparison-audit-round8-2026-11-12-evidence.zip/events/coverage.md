# Eighth audit — Events lane

Audited FS commit: e62b0360c1b91032741ef8f6afa4d247c8ea2437. Comparator: LoD2991ea279062773548ec390a1da75f3e85381702. Reference Documents and PR01–PR13 are the only rule authorities.

Read CLAUDE.md, adopted-ruling register, prior comparison ledgers through round7, and relevant source/instruction text. Used LoD event_audit.py's complete-Event outcome boundary as an engineering comparison lens. No outside rule material was used.

Three confirmed mechanisms are in findings.json: numeric2 Belgic mandatory decline; conditional numeric3/5 shaded effectiveness; missing Roman numeric32 movement producer. Their witnesses traverse actual dispatch_bot_turn and execute_decision, with complete free-action resolution, actual seeded RNG, canonical physical operations, permanent Provincia Fort, matching positive controls, and pre/post validate_state plus check_structural_integrity. The numeric32 explicit control uses public execute_decision. No repository tests or production edits were made.

Reproduce from fs-bot:

```
PYTHONPATH=. .venv/bin/python ../audit8-work/events/probe_events.py
```

The output's game_effects_unchanged compares every stored state field except RNG, decision-agent callback, and the Event's temporary executing_faction/event_params context. Those context fields can be absent before a turn and cleaned up to None afterward; that is not a game effect. This distinction was corrected during fixture development before the final run.

Earlier Oppida, Procillus, Divico, Rhenus Bridge, card2 capability-hook, and numeric32 geography findings are excluded. PR12 forecasting is not extended to card2: the witness proves only its unambiguous zero-Legion decline. No claim is made about other numeric2 target rankings or the Arverni numeric32 plan. Separate unresolved Circumvallation persistence and other source questions are excluded. This is focused mechanism coverage, not exhaustive Event or capability certification and not an encounter-frequency study.

The finalized witness was also rerun with PYTHONHASHSEED=0 and987; both runs passed and their JSON outputs match byte-for-byte. The working repository status remained clean.
