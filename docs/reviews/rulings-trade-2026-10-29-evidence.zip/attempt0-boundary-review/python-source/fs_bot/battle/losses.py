"""
Battle Losses — Calculation and resolution per §3.2.4, §3.3.4, §3.4.4.

Losses sub-procedure:
  a) Calculate how many Losses.
  b) Owner resolves Losses one by one.

Reference:
  §3.2.4 LOSSES, §3.3.4 LOSSES, §3.4.4 LOSSES,
  §4.2.3 Besiege, §4.3.3 Ambush, §4.5.3 Belgic Ambush,
  A3.2.4, A3.3.4, A3.4.4, A1.4 (Diviciacus, Ariovistus, Settlements)
  battle_procedure_flowchart.txt
"""

import math

from fs_bot.rules_consts import (
    EVENT_UNSHADED,
    # Factions
    ROMANS, ARVERNI, AEDUI, BELGAE, GERMANS,
    FACTIONS,
    # Piece types
    LEADER, LEGION, AUXILIA, WARBAND, FORT, ALLY, CITADEL, SETTLEMENT,
    HARD_TARGET_PIECES, FLIPPABLE_PIECES, MOBILE_PIECES,
    # Piece states
    HIDDEN, REVEALED, SCOUTED,
    # Leaders
    CAESAR, AMBIORIX, ARIOVISTUS_LEADER, DIVICIACUS,
    LEADER_FACTION,
    # Scenarios
    BASE_SCENARIOS, ARIOVISTUS_SCENARIOS,
    # Regions
    PROVINCIA,
    # Battle constants
    LOSS_ROLL_THRESHOLD,
    DIVICIACUS_LOSS_ROLL_THRESHOLD,
    DIE_SIDES, DIE_MIN, DIE_MAX,
)
from fs_bot.board.pieces import (
    get_effective_faction_pieces,
    count_pieces, count_pieces_by_state, get_leader_in_region,
    remove_piece, flip_piece, clear_allied_tribe,
)


# ============================================================================
# LOSSES STEP (a) — CALCULATE LOSSES COUNT
# ============================================================================


def _a33_motivation_active(state):
    """A33 shaded CAPABILITY "Motivation" (Ariovistus): "Defending Germans
    suffer 1/2 Losses whether or not Retreating and inflict +1 Counterattack
    Loss." Source: A Card Reference, card A33.

    A31 unshaded ("Event effects benefitting Germans in Battle are
    cancelled") suppresses it: capabilities count as Event effects —
    designer Q&A, BGG thread 2079436 (and errata-thread Abatis
    clarification: marker/card text = "Event effects").
    """
    from fs_bot.rules_consts import EVENT_SHADED
    from fs_bot.cards.capabilities import is_capability_active
    if state.get("event_modifiers", {}).get(
            "card_A31_cancel_german_benefits"):
        return False
    return is_capability_active(state, "A33", EVENT_SHADED)

def calculate_losses(state, region, attacking_faction, defending_faction,
                     *, is_retreat=False, is_counterattack=False,
                     double_auxilia=False, allied_factions=(),
                     warband_full_loss=False, arverni_legion_override=None):
    """Calculate the number of Losses inflicted.

    Per §3.2.4/§3.3.4/§3.4.4 LOSSES:
      Losses = (A + B), possibly halved, rounded down.

    Where the "enemy" is the faction causing the losses:
      - In Attack step: enemy = attacker's pieces
      - In Counterattack step: enemy = defender's pieces (survivors)

    A:
      - If defending vs Caesar attacking: Legions × 2
      - If defending vs Ambiorix attacking: Warbands × 1
      - If defending vs Ariovistus (A3.2.4): double total losses unless
        defender has Fort or Citadel
      - Otherwise: Legions × 1 or Warbands × ½

    B:
      - Leader × 1 and Auxilia × ½

    Halving: Defender Fort, Citadel, or Retreat → halve the sum.

    After halving, round fractions down.

    Args:
        state: Game state dict.
        region: Region where battle occurs.
        attacking_faction: The faction whose pieces cause losses
            (attacker during Attack, defender during Counterattack).
        defending_faction: The faction taking losses
            (defender during Attack, attacker during Counterattack).
        is_retreat: True if the defender declared Retreat (halves losses).
        is_counterattack: True if this is the Counterattack step.

    Returns:
        Integer number of Losses (rounded down).
    """
    space = state["spaces"][region]
    # "Enemy" = the faction causing losses
    enemy_faction = attacking_faction
    enemy_pieces = get_effective_faction_pieces(state, region, enemy_faction)

    # Count enemy pieces causing losses
    enemy_leader = get_leader_in_region(state, region, enemy_faction)
    enemy_legions = enemy_pieces.get(LEGION, 0)
    enemy_auxilia = _count_all_flippable(enemy_pieces, AUXILIA)
    enemy_warbands = _count_all_flippable(enemy_pieces, WARBAND)
    # Combined Battle (e.g. card 45 "using Aedui pieces as your own"; A28
    # "treating Arverni and allied Warbands/Auxilia as your own"): allied
    # Factions' mobile pieces add to the attacker's Loss-causing force.
    for _af in allied_factions:
        _ap = get_effective_faction_pieces(state, region, _af)
        enemy_legions += _ap.get(LEGION, 0)
        enemy_auxilia += _count_all_flippable(_ap, AUXILIA)
        enemy_warbands += _count_all_flippable(_ap, WARBAND)

    # Determine leader-based modifiers
    # Caesar × 2 Legions only when Caesar is the ATTACKER (not counterattack)
    # — §3.2.4: "A Defender taking such Losses when Caesar is Attacking"
    caesar_attacking = (
        enemy_leader == CAESAR
        and not is_counterattack
    )
    # A31 shaded CAPABILITY "Stalwart": named enemy Leaders do not double
    # Losses to Germans.
    from fs_bot.cards.capabilities import is_capability_active
    from fs_bot.rules_consts import EVENT_SHADED as _ESH
    _a31_stalwart = (defending_faction == GERMANS
                     and is_capability_active(state, "A31", _ESH))
    if _a31_stalwart:
        caesar_attacking = False

    # Ambiorix × 1 Warbands only when Ambiorix is the ATTACKER
    # — §3.3.4: "when Ambiorix (yellow, Belgic Leader) is Attacking"
    ambiorix_attacking = (
        enemy_leader == AMBIORIX
        and not is_counterattack
        and not _a31_stalwart
    )

    # Ariovistus doubles total losses — A3.2.4, A3.4.4
    # "The Ariovistus piece in Battle causes the enemy to take double Losses
    #  unless that enemy is Defending with Fort or Citadel."
    # NOTE per A3.2.4: "An Attacker, even with a Fort or Citadel, fighting
    # Ariovistus would take double Losses in any German counterattack."
    ariovistus_in_battle = (
        enemy_leader == ARIOVISTUS_LEADER
        and state["scenario"] in ARIOVISTUS_SCENARIOS
    )

    # Component A: Legions or Warbands
    if caesar_attacking:
        # §3.2.4: "two per Legion instead of just one per Legion"
        # Card 15 shaded: Caesar doubles the Loss of 1 Legion only.
        if is_capability_active(state, 15, _ESH) and enemy_legions > 0:
            component_a = enemy_legions + 1
        else:
            component_a = enemy_legions * 2
        # A28 can put borrowed Warbands beside Caesar; his Legion bonus
        # does not replace their ordinary contribution (§3.2.4, A28).
        component_a += enemy_warbands * (1.0 if warband_full_loss else 0.5)
    elif ambiorix_attacking:
        # §3.3.4: "one for each Belgic Warband, not just ½"
        component_a = enemy_warbands * 1
    else:
        # Normal: Legions × 1 or Warbands × ½
        component_a = enemy_legions * 1 + enemy_warbands * (
            1.0 if warband_full_loss else 0.5)

    # Component B: Leader × 1 and Auxilia × ½
    leader_value = 1 if enemy_leader is not None else 0
    # double_auxilia (e.g. A17 'double Losses by Auxilia'): Auxilia cause
    # 1 Loss each instead of 1/2.
    aux_factor = 1.0 if double_auxilia else 0.5
    # Card 59 unshaded (Germanic Horse): Roman Auxilia inflict 1 Loss each
    # in the flagged Region this Battle Command (attack and counterattack).
    if (enemy_faction == ROMANS
            and state.get("event_modifiers", {}).get(
                "card59_unshaded_region") == region):
        aux_factor = 1.0
    component_b = leader_value + enemy_auxilia * aux_factor

    total = component_a + component_b

    # Card 30 (Vercingetorix's Elite) shaded: the acting Arverni's 2 "Legion"
    # Warbands inflict 1 Loss each, not 1/2. arverni_legion_override lets the
    # caller pass the count that SURVIVED an earlier absorb step (the Tip: if
    # the picked Warbands were removed, the Counterattack gains no Legion bonus).
    _legion_wb = (arverni_legion_override if arverni_legion_override is not None
                  else card30_arverni_legion_warbands(state, region,
                                                      attacking_faction))
    if _legion_wb:
        _wb_factor = 1.0 if warband_full_loss else 0.5
        total += _legion_wb * (1.0 - _wb_factor)

    # Ariovistus doubling — A3.2.4, A3.4.4
    # Doubles total losses unless enemy (faction taking losses) is Defending
    # with Fort or Citadel. But an Attacker always takes double in
    # counterattack even with Fort/Citadel.
    if ariovistus_in_battle and not state.get("event_modifiers", {}).get(
            "card_A31_no_ario_double"):
        defender_pieces = get_effective_faction_pieces(state, region, defending_faction)
        _m2 = state.get("markers", {}).get(region, {})
        from fs_bot.rules_consts import MARKER_ABATIS as _MAB
        has_fort_or_citadel = (
            defender_pieces.get(FORT, 0) > 0
            or defender_pieces.get(CITADEL, 0) > 0
            or _m2.get(_MAB) == defending_faction  # A64: acts as a Fort
        )
        if is_counterattack:
            # "An Attacker, even with a Fort or Citadel, fighting Ariovistus
            # would take double Losses in any German counterattack."
            total *= 2
        elif not has_fort_or_citadel:
            total *= 2

    # A33 shaded CAPABILITY "Motivation": "Defending Germans suffer 1/2
    # Losses whether or not Retreating and inflict +1 Counterattack Loss."
    _motivation = _a33_motivation_active(state)

    # Card A64 Abatis: defender-owned marker acts as a Fort and negates all
    # Losses caused by Auxilia (attack step only — "When you defend"). A31
    # interactions per BGG errata thread 2072553 clarification 1.
    _abatis = False
    if not is_counterattack:
        from fs_bot.rules_consts import MARKER_ABATIS
        _m = state.get("markers", {}).get(region, {})
        _abatis = _m.get(MARKER_ABATIS) == defending_faction
        if _abatis:
            if (defending_faction == GERMANS and state.get(
                    "event_modifiers", {}).get(
                        "card_A31_cancel_german_benefits")):
                _abatis = False
            elif (enemy_faction == GERMANS
                    and is_capability_active(state, "A31", _ESH)):
                _abatis = False
        if _abatis:
            # recompute component B without the negated Auxilia
            total -= enemy_auxilia * aux_factor

    # Halving: Defender's Fort, Citadel, or Retreat — §3.2.4, §3.3.4
    # "The above sum is cut in half for Defenders who are either Retreating
    # or have a Citadel or Fort."
    # Only applies during the Attack step (not Counterattack).
    # The Attacker never gets halving during Counterattack.
    if not is_counterattack:
        defender_pieces = get_effective_faction_pieces(state, region, defending_faction)
        has_fort = defender_pieces.get(FORT, 0) > 0
        has_citadel = defender_pieces.get(CITADEL, 0) > 0

        # §4.2.3: "A Defender with a Citadel still suffers only half Losses
        # that Battle, even after the Citadel is removed"
        # This is handled by the caller tracking citadel_at_start.

        # Motivation halves defending Germans' Losses "whether or not
        # Retreating"; halving applies once (never quartered).
        motivated_defender = _motivation and defending_faction == GERMANS

        # Card 27 unshaded: Arverni attack inflicts 1 fewer Defender
        # Loss before any halving.
        if (enemy_faction == ARVERNI
                and is_capability_active(state, 27, EVENT_UNSHADED)):
            total = max(0.0, total - 1)

        # Card 59 shaded: the owner doubles the enemy's Losses in the
        # flagged Region unless the Defender has Fort/Citadel.
        if (state.get("event_modifiers", {}).get(
                "card59_shaded_region") == region
                and not (has_fort or has_citadel)):
            from fs_bot.cards.capabilities import get_capability_owner
            if get_capability_owner(state, 59) == enemy_faction:
                total *= 2

        if (is_retreat or has_fort or has_citadel or motivated_defender
                or _abatis):
            total = total / 2
    else:
        # Card 59 shaded (Tips): the owner ALSO doubles when defending —
        # their Counterattack in the flagged Region — unless they defend
        # with a Citadel.
        if (state.get("event_modifiers", {}).get(
                "card59_shaded_region") == region):
            from fs_bot.cards.capabilities import get_capability_owner
            if (get_capability_owner(state, 59) == enemy_faction
                    and enemy_pieces.get(CITADEL, 0) == 0):
                total *= 2

        # Motivation: the German Counterattack (Germans firing back, i.e.
        # attacking_faction == GERMANS here) inflicts +1 Loss. Applied after
        # any Ariovistus doubling, as a flat rider, and only when a
        # Counterattack actually occurs with at least one Loss-capable step
        # (callers skip the Counterattack entirely when no Germans survive).
        if _motivation and enemy_faction == GERMANS:
            total += 1

    # Round down — §3.2.4: "round any fractions down"
    total = int(total)

    # Card 15 unshaded: Battles with Roman Leader AND Legion — final
    # Losses Romans inflict +2; final Losses against Romans -1.
    if is_capability_active(state, 15, EVENT_UNSHADED):
        if (get_leader_in_region(state, region, ROMANS) is not None
                and count_pieces(state, region, ROMANS, LEGION) > 0):
            if enemy_faction == ROMANS:
                total += 2
            if defending_faction == ROMANS:
                total = max(0, total - 1)

    return total


def _count_all_flippable(faction_pieces, piece_type):
    """Count all instances of a flippable piece type across all states."""
    total = 0
    for ps in (HIDDEN, REVEALED, SCOUTED):
        total += faction_pieces.get(ps, {}).get(piece_type, 0)
    return total


def card30_arverni_legion_warbands(state, region, faction):
    """Card 30 (Vercingetorix's Elite) shaded capability: "In any Battles with
    their Leader, Arverni pick 2 Arverni Warbands — they take & inflict Losses
    as if Legions." Returns how many such "Legion" Warbands apply right now
    (0, 1, or 2): 0 unless the capability is active, the Faction is Arverni, and
    the Arverni Leader is in the Battle Region.
    """
    from fs_bot.rules_consts import ARVERNI, WARBAND, EVENT_SHADED
    from fs_bot.cards.capabilities import is_capability_active
    if faction != ARVERNI or not is_capability_active(state, 30, EVENT_SHADED):
        return 0
    if get_leader_in_region(state, region, ARVERNI) is None:
        return 0
    f_pieces = get_effective_faction_pieces(state, region, ARVERNI)
    from fs_bot.cards.edition import uses_second_edition
    limit = 4 if uses_second_edition(state) else 2
    return min(limit, _count_all_flippable(f_pieces, WARBAND))


# ============================================================================
# LOSSES STEP (b) — RESOLVE LOSSES
# ============================================================================

def resolve_losses(state, region, faction, num_losses, *,
                   is_retreat=False, is_ambush=False,
                   caesar_counterattacks=False,
                   loss_order=None, abatis_defender=False):
    """Resolve Losses for a faction, removing pieces one by one.

    The owner chooses which pieces to lose (for a bot, this will be
    automated by bot flowchart logic; for now we use a default priority).

    Rules for loss resolution:
    - Leader, Legion, Fort, Citadel: Roll 1-3 to remove (die roll).
      EXCEPTION: Ambush → auto-remove (no roll) UNLESS Caesar will
      Counterattack, in which case still roll 1-3. — §4.3.3, §4.5.3
    - Warband, Auxilia, Ally, Settlement: Remove automatically (no roll).
    - Retreat: Allies, Forts, Citadels FIRST. — §3.2.4
    - No Retreat: Allies, Forts, Citadels LAST. — §3.2.4
    - Provincia Fort never absorbs Losses — §1.4.2, §3.2.4
    - Diviciacus: only removed on roll of 1 (not 1-3) — A3.2.4
    - Diviciacus: may not absorb Losses until last possible piece — A3.2.4
    - Germanic Settlements absorb Losses as if Germanic Allies — A3.2.4
    - In base game, Germans remove Scouted→Revealed→Hidden Warbands,
      then Allies from Cities last — §3.4.5
    - In Ariovistus, Arverni remove Scouted→Revealed→Hidden Warbands,
      then Allies from Cities last, then Citadels — A3.2.4

    Args:
        state: Game state dict.
        region: Region where battle occurs.
        faction: Faction taking Losses.
        num_losses: Number of Losses to resolve.
        is_retreat: If True, Allies/Forts/Citadels must go FIRST.
        is_ambush: If True, hard targets auto-removed (no roll).
        caesar_counterattacks: If True (Caesar rolled high enough), hard
            targets still get die rolls even during Ambush.
        loss_order: Optional list of (piece_type, piece_state_or_None) tuples
            specifying the order in which the owner chooses to lose pieces.
            If None, uses default priority ordering.

    Returns:
        dict with battle results:
            "removed": list of (piece_type, count) removed
            "rolls": list of (piece_type, roll_value, removed_bool)
            "losses_taken": int — actual pieces removed
            "losses_absorbed": int — losses absorbed by surviving rolls
    """
    # A20 projects only Warbands. Its game-run Arverni casualty ownership
    # and provisional origin tie break must not expose human loss choices
    # or consume nonparticipating Allied Tribes/Citadels at the destination.
    from fs_bot.cards.morbihan_display import resolve_projected_losses
    projected = resolve_projected_losses(state, region, faction, num_losses)
    if projected is not None:
        return projected

    result = {
        "removed": [],
        "rolls": [],
        "losses_taken": 0,
        "losses_absorbed": 0,
    }

    # Use die rolls for hard targets?
    # Normal: yes. Ambush: no (auto-remove). Exception: Caesar counterattacks.
    use_rolls = not is_ambush or caesar_counterattacks

    # Card 30 (Vercingetorix's Elite) shaded: up to 2 Arverni Warbands "take
    # Losses as if Legions" — they get the §3.2.4 save roll. Track how many
    # such Legion-Warbands remain alive (decrement only when one is removed).
    arverni_legions_alive = card30_arverni_legion_warbands(state, region, faction)
    card30_active = arverni_legions_alive > 0

    # Card A64 Abatis + errata-thread Clarification 1: "the Abatis marker
    # absorbs Losses and can thereby be removed in the same way as a Fort
    # when defending." Same last-priority tier as Forts; NP default spends
    # the marker before real hard pieces. Only the Attack step's defender
    # qualifies ("When you defend") — abatis_defender is set by that call.
    from fs_bot.rules_consts import MARKER_ABATIS as _MAB_RL
    _abatis_available = (
        abatis_defender
        and state.get("markers", {}).get(region, {}).get(_MAB_RL)
        == faction)

    remaining = num_losses
    while remaining > 0:
        # Build the priority list of pieces to take losses
        piece_order = _build_loss_priority(
            state, region, faction, is_retreat=is_retreat,
            loss_order=loss_order,
        )

        _hard_tier = (ALLY, CITADEL, FORT)
        if _abatis_available and (
                not piece_order or piece_order[0][0] in _hard_tier
                or is_retreat):
            # The marker absorbs like a Fort: a die roll per assigned
            # Loss (1-3 removes it); Ambush auto-removes (§4.3.3
            # semantics for hard targets) unless Caesar counterattacks.
            if not is_ambush or caesar_counterattacks:
                roll = state["rng"].randint(DIE_MIN, DIE_MAX)
                removed = roll <= LOSS_ROLL_THRESHOLD
                result["rolls"].append(("Abatis", roll, removed))
            else:
                removed = True
            remaining -= 1
            if removed:
                state["markers"][region].pop(_MAB_RL, None)
                _abatis_available = False
                result["removed"].append(("Abatis", 1))
                result["losses_taken"] += 1
            else:
                result["losses_absorbed"] += 1
            continue

        if not piece_order:
            # No more pieces to remove — stop
            break

        # Take the first available piece from the priority list (default), or
        # let a human/LLM agent choose which present piece absorbs this Loss.
        chosen = piece_order[0]
        if loss_order is None:
            from fs_bot.engine.agent import consult_agent, LOSS_ORDER
            _resp = consult_agent(state, faction, {
                "kind": LOSS_ORDER, "region": region, "faction": faction,
                "num_losses": remaining, "is_retreat": is_retreat,
                "is_ambush": is_ambush, "pieces": list(piece_order)})
            if _resp:
                _present = set(piece_order)
                for _e in _resp:
                    if tuple(_e) in _present:
                        chosen = tuple(_e)
                        break
        piece_type, piece_state = chosen[:2]
        physical_owner = chosen[2] if len(chosen) == 3 else None

        # Determine if this is a hard target that gets a die roll
        is_hard_target = piece_type in HARD_TARGET_PIECES
        # Card 30 shaded: a surviving Arverni "Legion" Warband absorbs via the
        # §3.2.4 save roll, just like a Legion (and may be targeted repeatedly).
        is_legion_warband = (piece_type == WARBAND and arverni_legions_alive > 0)

        # Provincia Fort never absorbs Losses — §1.4.2
        if piece_type == FORT and region == PROVINCIA:
            # Skip this piece — can never be removed in battle
            # This shouldn't normally appear because _build_loss_priority
            # filters it out, but safety check
            break

        # Diviciacus special handling — A3.2.4
        leader_name = None
        is_diviciacus = False
        if piece_type == LEADER:
            leader_name = get_leader_in_region(state, region, faction)
            is_diviciacus = (leader_name == DIVICIACUS)

        if (is_hard_target or is_legion_warband) and use_rolls:
            # Roll to remove — §3.2.4
            roll = state["rng"].randint(DIE_MIN, DIE_MAX)

            if is_diviciacus:
                # Diviciacus: removed only on roll of 1 — A3.2.4
                threshold = DIVICIACUS_LOSS_ROLL_THRESHOLD
            else:
                threshold = LOSS_ROLL_THRESHOLD
                # Card 10 unshaded: "Battle rolls remove Forts on 1-2
                # not 1-3" — Roman Forts are more defensible.
                if piece_type == FORT:
                    from fs_bot.cards.capabilities import (
                        is_capability_active as _ica10)
                    if _ica10(state, 10, EVENT_UNSHADED):
                        threshold = 2

            if roll <= threshold:
                # Remove the piece
                _remove_battle_piece(state, region, faction,
                                     piece_type, piece_state, physical_owner)
                if is_legion_warband:
                    arverni_legions_alive -= 1
                result["rolls"].append((piece_type, roll, True))
                result["removed"].append((piece_type, 1))
                result["losses_taken"] += 1
            else:
                # Survived — Loss absorbed without removing
                result["rolls"].append((piece_type, roll, False))
                result["losses_absorbed"] += 1
        elif is_hard_target and not use_rolls:
            # Ambush auto-remove (no roll) — §4.3.3
            _remove_battle_piece(state, region, faction,
                                 piece_type, piece_state, physical_owner)
            result["rolls"].append((piece_type, None, True))
            result["removed"].append((piece_type, 1))
            result["losses_taken"] += 1
        else:
            # Soft target: auto-remove — §3.2.4
            _remove_battle_piece(state, region, faction,
                                 piece_type, piece_state, physical_owner)
            result["removed"].append((piece_type, 1))
            result["losses_taken"] += 1

        remaining -= 1

    if card30_active:
        result["legion_warbands_surviving"] = arverni_legions_alive

    return result


def _build_loss_priority(state, region, faction, *, is_retreat=False,
                         loss_order=None):
    """Build the ordered list of pieces eligible to take Losses.

    Returns a list of (piece_type, piece_state_or_None) tuples in order
    of loss priority.

    Ordering rules:
    - Retreat: Allies/Forts/Citadels/Settlements FIRST, then others.
    - No Retreat: Others first, Allies/Forts/Citadels/Settlements LAST.
    - Provincia Fort is NEVER eligible — §1.4.2
    - Diviciacus: may not absorb until last possible piece — A3.2.4
    - In base game, Germans: Scouted→Revealed→Hidden Warbands, then
      Allies from Cities last — §3.4.5
    - In Ariovistus, Arverni: Scouted→Revealed→Hidden Warbands, then
      Allies from Cities last, then Citadels — A3.2.4
    """
    if loss_order is not None:
        if get_leader_in_region(state, region, faction) != DIVICIACUS:
            return loss_order
        # A1.4/A3.2.4 is a restriction, not merely an NP preference.
        # Explicit priorities cannot make Diviciacus absorb a Loss while
        # another piece can do so, nor repeatedly select a removed piece.
        legal = _build_loss_priority(state, region, faction,
                                     is_retreat=is_retreat)
        for preferred in loss_order:
            for candidate in legal:
                if (preferred[0] == candidate[0]
                        and (preferred[1] is None or preferred[1] == candidate[1])
                        and (len(preferred) < 3 or
                             (len(candidate) == 3 and preferred[2] == candidate[2]))):
                    return [candidate]
        return legal

    scenario = state["scenario"]
    space = state["spaces"][region]
    f_pieces = get_effective_faction_pieces(state, region, faction)

    # Build lists of available pieces
    available_pieces = []

    # Check for special German or Arverni loss ordering
    is_german_base = (faction == GERMANS and scenario in BASE_SCENARIOS)
    is_german_ariovistus = (
        faction == GERMANS and scenario in ARIOVISTUS_SCENARIOS
    )
    is_arverni_ariovistus = (
        faction == ARVERNI and scenario in ARIOVISTUS_SCENARIOS
    )

    # --- Collect static pieces (Allies, Forts, Citadels, Settlements) ---
    static_pieces = []

    # Allies
    ally_count = f_pieces.get(ALLY, 0)
    for _ in range(ally_count):
        static_pieces.append((ALLY, None))

    # Settlements — treated as Allies for loss purposes — A3.2.4
    settlement_count = f_pieces.get(SETTLEMENT, 0)
    for _ in range(settlement_count):
        static_pieces.append((SETTLEMENT, None))

    # Forts — but NOT the Provincia permanent Fort
    fort_count = f_pieces.get(FORT, 0)
    if region == PROVINCIA and fort_count > 0:
        # Provincia Fort never absorbs Losses — §1.4.2
        fort_count = max(0, fort_count - 1)
    for _ in range(fort_count):
        static_pieces.append((FORT, None))

    # Citadels
    citadel_count = f_pieces.get(CITADEL, 0)
    for _ in range(citadel_count):
        static_pieces.append((CITADEL, None))

    # --- Collect mobile/other pieces ---
    other_pieces = []

    # Leader
    leader_name = f_pieces.get(LEADER)
    is_diviciacus = (leader_name == DIVICIACUS)
    has_leader = leader_name is not None

    # Special loss ordering for Germans in base game — §3.4.5
    # and Arverni in Ariovistus — A3.2.4
    if is_german_base or is_german_ariovistus or is_arverni_ariovistus:
        # Scouted Warbands first, then Revealed, then Hidden
        scouted_wb = f_pieces.get(SCOUTED, {}).get(WARBAND, 0)
        revealed_wb = f_pieces.get(REVEALED, {}).get(WARBAND, 0)
        hidden_wb = f_pieces.get(HIDDEN, {}).get(WARBAND, 0)
        for _ in range(scouted_wb):
            other_pieces.append((WARBAND, SCOUTED))
        for _ in range(revealed_wb):
            other_pieces.append((WARBAND, REVEALED))
        for _ in range(hidden_wb):
            other_pieces.append((WARBAND, HIDDEN))
    else:
        # Normal ordering for warbands (Hidden first per remove_piece default)
        wb_total = _count_all_flippable(f_pieces, WARBAND)
        for _ in range(wb_total):
            other_pieces.append((WARBAND, None))

    # Auxilia
    aux_total = _count_all_flippable(f_pieces, AUXILIA)
    for _ in range(aux_total):
        other_pieces.append((AUXILIA, None))

    # Legions
    legion_count = f_pieces.get(LEGION, 0)
    for _ in range(legion_count):
        other_pieces.append((LEGION, None))

    # Leader — added last in "other" for normal, or excluded until end
    # for Diviciacus
    if has_leader and not is_diviciacus:
        other_pieces.append((LEADER, None))

    # Build final ordering based on retreat status
    if is_retreat:
        # Retreat: Allies/Forts/Citadels/Settlements FIRST — §3.2.4
        result = static_pieces + other_pieces
    else:
        # No Retreat: Allies/Forts/Citadels/Settlements LAST — §3.2.4
        result = other_pieces + static_pieces

    # Diviciacus: "may not absorb Losses until he is the last possible
    # piece to do so" — A3.2.4
    if has_leader and is_diviciacus:
        result.append((LEADER, None))

    # Filter to only pieces actually present
    result = _filter_to_present(state, region, faction, result)
    from fs_bot.commands.sa_enlist import borrowed_loss_choices
    result = borrowed_loss_choices(state, region, faction, result)
    from fs_bot.battle.combined import loss_choices
    result = loss_choices(state, region, faction, result)
    from fs_bot.engine.diviciacus import loss_choices as diviciacus_losses
    result = diviciacus_losses(state, region, faction, result)
    # Humans choose among the offered pieces, so putting Diviciacus last
    # does not enforce "last possible piece". Do not offer him at all until
    # every other eligible piece, including cooperating Auxilia, is gone.
    if is_diviciacus and any(entry[0] != LEADER for entry in result):
        result = [entry for entry in result if entry[0] != LEADER]
    return result


def _filter_to_present(state, region, faction, piece_list):
    """Filter a priority list to only pieces actually in the region.

    Tracks how many of each (piece_type, piece_state) we've already
    "claimed" to avoid duplicates.
    """
    space = state["spaces"][region]
    f_pieces = get_effective_faction_pieces(state, region, faction)

    # Track remaining counts
    remaining = {}
    # Leader
    if f_pieces.get(LEADER) is not None:
        remaining[(LEADER, None)] = 1
    # Legions
    remaining[(LEGION, None)] = f_pieces.get(LEGION, 0)
    # Forts (minus Provincia permanent)
    fort_count = f_pieces.get(FORT, 0)
    if region == PROVINCIA and fort_count > 0:
        fort_count = max(0, fort_count - 1)
    remaining[(FORT, None)] = fort_count
    # Allies
    remaining[(ALLY, None)] = f_pieces.get(ALLY, 0)
    # Citadels
    remaining[(CITADEL, None)] = f_pieces.get(CITADEL, 0)
    # Settlements
    remaining[(SETTLEMENT, None)] = f_pieces.get(SETTLEMENT, 0)

    # Flippable pieces — specific states
    for pt in FLIPPABLE_PIECES:
        for ps in (HIDDEN, REVEALED, SCOUTED):
            remaining[(pt, ps)] = f_pieces.get(ps, {}).get(pt, 0)
        # Also track the None-state total (for non-specific ordering)
        remaining[(pt, None)] = _count_all_flippable(f_pieces, pt)

    filtered = []
    # Track consumed counts to avoid double-counting
    consumed = {}

    for piece_type, piece_state in piece_list:
        key = (piece_type, piece_state)
        avail = remaining.get(key, 0) - consumed.get(key, 0)
        if avail > 0:
            filtered.append((piece_type, piece_state))
            consumed[key] = consumed.get(key, 0) + 1
            # For flippable pieces with None state, also consume from the
            # None bucket (and vice versa)
            if piece_type in FLIPPABLE_PIECES and piece_state is not None:
                none_key = (piece_type, None)
                consumed[none_key] = consumed.get(none_key, 0) + 1
            elif piece_type in FLIPPABLE_PIECES and piece_state is None:
                # Need to consume from the most available specific state
                # (remove_piece handles this automatically)
                pass

    return filtered


def _remove_battle_piece(state, region, faction, piece_type, piece_state,
                         physical_owner=None):
    """Remove a single piece as a battle loss.

    Legions go to Fallen (§1.4.1).
    All other pieces go to Available.
    Removing an ALLY or CITADEL also clears the matching allied tribe in
    state["tribes"] (the dict is authoritative for victory and must stay in
    sync with on-map pieces).
    """
    if piece_type == LEGION:
        remove_piece(state, region, faction, LEGION, 1, to_fallen=True)
    elif piece_type in FLIPPABLE_PIECES:
        remove_piece(state, region, faction, piece_type, 1,
                     piece_state=piece_state, physical_owner=physical_owner)
    else:
        remove_piece(state, region, faction, piece_type, 1)
        if piece_type in (ALLY, CITADEL):
            clear_allied_tribe(state, region, faction, piece_type)
