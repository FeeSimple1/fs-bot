"""Verify final source, evidence provenance and acceptance before publication."""
from pathlib import Path
import json
import subprocess
import xml.etree.ElementTree as ET
from integration_matrix import identity, protected_files

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'fs-bot'
read = lambda p: json.loads((HERE / p).read_text())
source = read('candidate-source-attempt2.json')
assert identity() == source
assert protected_files() == read('protected-before.json')
matrix = read('attempt1/integration-results.json')
assert matrix['passed'] and not matrix['failures']
assert matrix['bot_games'] == 150
assert matrix['bot_hash_seed_repeat_executions'] == 25
assert matrix['mixed_seat_distinct_cases'] == 220
assert matrix['mixed_seat_executions_including_replay_and_hash_repeat'] == 880
assert matrix['strict_census_executions'] == 20
assert all(x['hard_findings'] == x['partial'] == 0 for x in matrix['fuzz'].values())
bridge = read('production-equivalence-attempt1-to-attempt2.json')
assert bridge['all_non_test_python_files_identical']
assert bridge['only_changed_python_files'] == ['fs_bot/tests/test_seize_rally_actions.py']
assert bridge['gameplay_python_sha256'] == matrix['source']['python_sha256']
assert bridge['final_python_sha256'] == source['python_sha256']
causal = read('causal-review/causal-source-review.json')
assert causal['all_reviewed'] and not causal['unexplained_first_divergences']
assert causal['paired_changed_outcome_games'] == 29
assert causal['complete_trace_executions'] == 58
assert causal['base_records_semantically_identical'] == 60
assert causal['seize_rally_integration_cases'] == 4
assert causal['candidate_source_sha256'] == matrix['source']['python_sha256']

def junit(name):
    suites = list(ET.parse(HERE / name).getroot().iter('testsuite'))
    return {key: sum(int(s.get(key, '0')) for s in suites)
            for key in ('tests', 'failures', 'errors', 'skipped')}
parent = junit('parent-suite.xml')
first = junit('candidate-suite.xml')
final = junit('candidate-suite-attempt2.xml')
assert parent == {'tests': 7149, 'failures': 0, 'errors': 0, 'skipped': 0}
assert first == {'tests': 7205, 'failures': 1, 'errors': 0, 'skipped': 0}
assert final == {'tests': 7205, 'failures': 0, 'errors': 0, 'skipped': 0}
subprocess.run(['git', 'diff', '--check'], cwd=REPO, check=True)
progress = json.loads((REPO / 'docs/human-choice-progress.json').read_text())
assert progress['total'] == len(progress['findings']) == 50
assert progress['closed'] == sum(r['status'] == 'closed' for r in progress['findings']) == 19
assert progress['open'] == 31
assert progress['tested_source']['python_sha256'] == source['python_sha256']
result = {
    'date': '2026-11-03', 'timezone': 'America/Chicago', 'accepted': True,
    'parent_commit': source['commit'],
    'final_source': {k:v for k,v in source.items() if k != 'files'},
    'production_source_sha256': bridge['production_sha256'],
    'production_file_count': bridge['production_file_count'],
    'full_suite': final, 'parent_full_suite': parent,
    'preserved_first_suite': first,
    'focused_python312': {'version': '3.12.14', 'passed': 114, 'log': 'focused-python312-attempt2.log'},
    'gameplay_matrix': matrix,
    'test_only_source_equivalence': bridge,
    'causal_review': {k:v for k,v in causal.items() if k != 'rows'},
    'protected_files_unchanged': True,
    'progress': {'closed': 19, 'total': 50, 'open': 31, 'percent': 38,
                 'separate_phase_defects_repaired': 7},
    'limits': ['Game records preserve attempt1 source labels; final test-only revision has identical production bytes.',
               'First-divergence review is not an exhaustive proof of all later decisions.',
               'Remote CI follows the published commit and is separate from this local acceptance.'],
}
(HERE / 'acceptance-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'accepted': True, 'tests': final['tests'], 'matrix_checks': len(matrix['checks_passed']),
                  'source': source['python_sha256']}))
