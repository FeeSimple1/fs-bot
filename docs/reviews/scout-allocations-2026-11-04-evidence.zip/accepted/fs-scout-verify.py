from pathlib import Path
import json,re,subprocess
from fs_bot import rules_consts as rc
from fs_bot.tools.validation_metadata import source_identity
parent='a7fc41005705d0255034b4239d9f5091d28176c0';source=source_identity()
assert source['source_sha256']=='51e1c13b45ee217dcbeeaabea806ea094575b8cac1fe54258a1948b5ac5edf2c'
records={}
for label,directory in [('parent','/tmp/fs-scout-bots-parent'),('final','/tmp/fs-scout-bots-final')]:
 rows=[json.loads(x) for x in Path(directory+'/games.jsonl').read_text().splitlines()]
 records[label]={(r['scenario'],r['seed']):r for r in rows}
 assert len(rows)==10 and set(records[label])=={(s,n) for s in rc.ALL_SCENARIOS for n in (1,2)}
 for row in rows:
  assert all(row[k] for k in ('completed','game_completed','audit_completed','final_state_sha256'))
  assert not row['errors'] and not row['integrity_findings']
  assert len(row['final_ranking'])==4 and not row['winner_differs_from_highest_margin'] and not row['engine_ranking_output_missing']
  assert all(d['severity']=='legal-decline' for d in row['diagnostics'])
ignored={'seconds','commit','source_sha256'}
for k,p in records['parent'].items():
 c=records['final'][k]
 assert {f:v for f,v in p.items() if f not in ignored}=={f:v for f,v in c.items() if f not in ignored},k
assert json.loads(Path('/tmp/fs-scout-bots-final/metadata.json').read_text())['source_sha256']==source['source_sha256']
x=json.loads(Path('/tmp/fs-scout-mixed0.json').read_text());y=json.loads(Path('/tmp/fs-scout-mixed987.json').read_text())
assert x==y and not x['hard_findings'] and x['partial']==0 and all(r['game_completed'] for r in x['records'])
assert x['metadata']['source_sha256']==source['source_sha256']
protected=[p for p in Path('Reference Documents').rglob('*') if p.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
assert len(protected)==49
for p in protected:assert p.read_bytes()==subprocess.check_output(['git','show',parent+':'+str(p)])
result={'date':'2026-11-04','timezone':'America/Chicago','source':source,'python_files':len(list(Path('fs_bot').rglob('*.py'))),'protected_files':len(protected),'protected_files_unchanged':True,'targeted_passed':337,'new_tests':60,'parent_proof':{'behavioral_failures':13,'controls_passed':7,'deselected':40},'bots':{'games':10,'all_completed_and_audited':True,'all_gameplay_fields_and_final_hashes_equal':True,'excluded':sorted(ignored)},'mixed':x,'mixed_complete_json_equal':True,'hash_seeds':[0,987],'mixed_executions_including_replay':40,'original_progress':{'closed':35,'total':50,'percent':70,'open':15},'remaining':'CV-PERSISTENCE, BATTLE-RAMPAGE-VICTIM, BE-09 and the NPC Intimidate targeting lead remain open'}
balance_log = Path('/tmp/fs-scout-balance.log').read_text()
games = re.findall(r'^\[(.*?) seed=\s*(\d+)\] winner=(.*?) \((\d+) cards\)$', balance_log, re.M)
assert len(games) == 100 and {(scenario, int(seed)) for scenario, seed, _, _ in games} == {
    (scenario, seed) for scenario in rc.ALL_SCENARIOS for seed in range(1, 21)}
deltas = [abs(int(value)) for value in re.findall(r'\(([+-]\d+)%\)', balance_log)]
assert deltas and max(deltas) <= 15 and 'OK: balance within band' in balance_log
changes = re.search(r'OK: balance within band \((\d+) winner changes\)', balance_log)
result['balance_smoke'] = {
    'games': len(games), 'seeds': list(range(1, 21)), 'scenarios': list(rc.ALL_SCENARIOS),
    'band_percentage_points': 15, 'maximum_absolute_delta_percentage_points': max(deltas),
    'historical_baseline_winner_changes': int(changes[1]) if changes else 0,
    'baseline_unchanged': True, 'passed': True,
}
Path('/tmp/fs-scout-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':source,'new_tests':60,'targeted':337,'bots_equal':10,'mixed_equal':True,'hard_findings':x['hard_findings'],'partials':x['partial'],'human_turns':x['human_turns'],'event_turns':x['event_turns'],'events_ok':x['events_ok'],'protected':len(protected)}))
