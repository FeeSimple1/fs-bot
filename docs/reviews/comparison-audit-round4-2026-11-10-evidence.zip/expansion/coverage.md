# Expansion partition — fourth comparative audit

Audited FS commit b951908af2b21cc87a7e27d9a5314b3f257d0147.
Comparator commit 2991ea279062773548ec390a1da75f3e85381702.
No production/reference edits. All Reference Documents filenames inventoried.

Comparison prompts came from lod-bot coin-implementation-lessons.md, especially card-handler boundaries, data-shape mismatches, and forced/free actions, and lod_ai/event_choices.py lines 10–28 (handler revalidation and actual candidate lists), 108–121 (owner-specific piece types), 124–138 (mandatory versus optional quantities). LoD's automatic fallback behavior is not adopted for Falling Sky's durable human input. FS's supplied references govern the two findings.

Reviewed direct expansion handlers A5–A70, branching into expansion_validation.py, event_piece_plans.py, all_gaul_gathers.py, publius.py, parley.py, kinship.py, divination.py, arduenna.py, and relevant execute.py dispatch. Examined previous 50/21/15 ledgers plus current status and provisional rules to exclude closed reports. Read A Card Reference, Chapter 5, A6 and Arverni aid; Chapter 1 native piece types; relevant clauses in provisional ruling register. Interlude scope inspected via callsites, without claiming exhaustive independent lifecycle coverage.

Confirmed evidence comprises 7 fresh cases on full scenario setup, 4 observed defect cases and 3 legal controls. All pass durable input validation, preview, and actual execution. Census and structure remain clean before and after. Assertions intentionally record bad current behavior so the portable audit runner can verify reproduction; repair regressions must reverse those assertions to source-expected behavior.

Rejected or unpromoted leads

- A35 optional mobile placement owner/type mismatches can collapse to zero, but the effect is up-to and no material new rules outcome was established.
- A35 shaded optional Settlement grammar was not promoted to a mandatory-minimum claim; source interpretation is not sufficiently clear for a new finding.
- A27/A32 remove-Allies handlers do not hit Cities among their named Tribes, so the previous A24 Citadel bug does not transfer there.
- A23 Parley already requires a legal whole meeting and applies faction-aware stacking filters.
- A17 includes bounded group checks, Caesar-free destinations, free March and mandatory possible post-March Battle. No new issue confirmed.
- A29/A30/A36/A43/A45 and A56/A65 already have explicit quota/target/owner pipelines. Their earlier findings were not counted again.
- A20 projected forces already preserve physical origins and Scouted survivors. A target tie-order suspicion lacks a clear distinct source basis and is not a confirmed finding.
- A60 repeated source Allies become non-Roman after the first replacement, so repeated entries do not inflate replacements.
- A64 repeated marker placement across several executions is not a demonstrated reachable game case and is not counted.
- A69 first exploratory probes used an empty initialized board. Final evidence replaces those with untouched Ariovistus setup and reproduces both failures with ample valid supply.

Run from any matching repository checkout

```sh
PYTHONPATH="$PWD" python /path/to/expansion/probe_expansion.py
```

The script requires only the game's standard-library dependencies. observed.json retains the accepted final output. No randomized full-game result is claimed by this partition.
