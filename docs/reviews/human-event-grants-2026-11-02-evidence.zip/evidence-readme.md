# Event-grant repair evidence

Parent: d3241e7ad0ed5e11a88d114958e886221dd36db9.
Final Python source: 13e96378e7f0960ffb6b4104d76cc75c5120d444.
See integration-ledger.json for five logical code commits and their full suites;
source-verification.json verifies exact Python/protected hashes and JUnit totals.

integration_checks.py runs the fixed matrix from a sibling fs-bot checkout.
Use an interpreter with the repository's test dependencies. Adjust the REPO/path
variables to local checkout locations; do not change the seed/profile inventory.
Raw records and metadata are under bots-* and parent-bots. Mixed-seat and strict
census JSON/logs retain both hash seeds. Source remained frozen for accepted runs.
The causal-review directory records only the six paired changed-outcome cases.

Implementation-agent and independent reviewer handoffs separate supplied source
rules, accepted changes and failed/superseded attempts. Logs marked incomplete,
failed, before, superseded or earlier attempts are not final validation passes.
In particular, final-documentation-incomplete.log has no completion report;
final-documentation-02 is the accepted unchanged-source rerun.

Draft implementation Python files and unrelated preexisting temporary archives
are excluded. evidence-index.json records the SHA-256 and size of every included
file except itself. package_evidence.py writes and verifies the archive.
The public review/results outside the archive describe final dispositions and
limits; the original audit inventory and balance baseline are unchanged.
