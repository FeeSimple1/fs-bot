# Seventh comparison Batch 3 validation

The repair was tested on parent `0e0f4efd1f224db1b726fe47c92af8a8c8318603`
with Python 3.12.14. `source.json` identifies the tested Python bytes.
The seventh Batch 2 evidence supplies the paired parent game records.
The seventh audit archive supplies the original Surus witness.
`SHA256SUMS` covers the archived files.

Run the verifier from the repaired repository root with its Python
environment active.

```sh
PYTHONPATH=. python /path/to/evidence/verify_results.py /path/to/evidence
```

The validation runs used a fresh output directory and these commands.

```sh
PYTHONHASHSEED=0 python -m pytest -q -n 5 --junitxml=pytest.xml
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out bots-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 41-44 --card-edition second-edition --workers 2 --out bots-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 41-44 --card-edition second-edition --out fuzz987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
```

`directed.log` records the 11 new March tests. Running the same test file
on the parent reproduces seven failures and passes four controls.
`audit-before.json` matches the original audit's six Surus cases.
The bot records match their paired outcomes, including final state hashes,
rankings and diagnostics. The mixed-player results match between hash seeds
and retain the prior batch's replay digest.
