# Fifth comparison repair Batch 2 evidence

The parent is Falling Sky commit `5661bf08db76eda71b73102665068d62e23daa83`.
`summary.json` identifies the repaired Python sources and records the
verification results. `SHA256SUMS.json` contains the archive checksums.

Run these checks from the relevant checkout with Python 3.12, pytest and
pytest-xdist. Use a fresh results directory for each matrix. The focused
log includes the Interlude, Winter and release compatibility tests.

```sh
PYTHONHASHSEED=0 python -m pytest -q -n 5
PYTHONHASHSEED=0 python -m pytest -q fs_bot/tests/test_interlude*.py fs_bot/tests/test_fourth_comparison_interlude.py fs_bot/tests/test_fifth_comparison_interlude.py fs_bot/tests/test_release_compatibility.py fs_bot/tests/test_winter.py
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out /path/to/results/bots-legacy
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 29-32 --card-edition second-edition --workers 2 --out /path/to/results/bots-second
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 29-32 --card-edition second-edition --out /path/to/results/fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 29-32 --card-edition second-edition --out /path/to/results/fuzz987.json
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
```

To reproduce the parent failures, copy the three test files under `tests/`
to `fs_bot/tests/` in a disposable parent checkout and run this selection.

```sh
PYTHONHASHSEED=0 python -m pytest -q fs_bot/tests/test_fifth_comparison_interlude.py fs_bot/tests/test_interlude_aedui_choices.py::test_bibracte_is_restored_when_only_a_colony_ally_survives_in_its_region fs_bot/tests/test_interlude_arverni_choices.py::test_cadurci_does_not_prevent_gergovia_restoration_and_reinforcement
```

`trace_interludes.py` replays the games in each matrix that reached the
Interlude. It records the board before the Winter card, the two faction
adjustments, and the final board. Use the archived Batch 1 bot records for
the parent. The trace checks each final board and result against its
original game record.

```sh
PYTHONPATH=. PYTHONHASHSEED=0 python /path/to/evidence/trace_interludes.py /path/to/results/interludes.json /path/to/results/bots-legacy/games.jsonl /path/to/results/bots-second/games.jsonl
```
