"""Reproducible bounded review of every changed legacy winner/card record.

No engine sources or stored balance baseline are modified.  An unsourced
numeric-67 policy change is reported as a blocker, not explained away by RNG.
"""
import collections
import gzip
import hashlib
import json
from pathlib import Path

out = Path(__file__).resolve().parent
evidence = out.parent
workspace = evidence.parent
expected_parent = 'c3c3cd4fd4370f4367db759106b7418449bcc0c27b34ceae2e93c014c64b3bf4'
expected_candidate = '67ee7ff3b52b0c639cf29e96397bb237814b6bfe16a863d0966c11e27860b52c'
load_records = lambda p: {r['scenario'] + '|' + str(r['seed']): r
    for r in map(json.loads, p.read_text().splitlines())}
parent_records = load_records(workspace / 'fuzz-determinism-2026-11-02/bots/games.jsonl')
candidate_records = load_records(evidence / 'attempt2/bots-legacy/games.jsonl')
baseline = json.loads((evidence / 'balance-baseline-before.json').read_text())['games']
outcome = lambda r: {k: r[k] for k in ('winner', 'cards')}
assert len(parent_records) == len(candidate_records) == len(baseline) == 100
assert all(r['completed'] for r in candidate_records.values())
changed = [key for key in parent_records
    if outcome(parent_records[key]) != outcome(candidate_records[key])]
assert len(changed) == 21


def key(row):
    return {k: row[k] for k in ('index', 'card_index', 'card', 'stage', 'faction')}


def board(row):
    result = {k: v for k, v in row['board'].items() if k != '_card_turn'}
    if 'event_modifiers' in result:
        result['event_modifiers'] = {k: v for k, v in result['event_modifiers'].items()
            if k != 'card_67_target_regions'}
    return result


def choice(row):
    return {k: v for k, v in row.get('decision', {}).items() if k != 'execution'}


def load_trace(name, label, expected):
    scenario, seed = name.rsplit('|', 1)
    stem = scenario.lower().replace(' ', '-').replace('?', '') + '-' + seed
    path = out / f'{label}-{stem}.jsonl.gz'
    summary = json.loads((out / f'{label}-{stem}-summary.json').read_text())
    assert summary['source']['source_sha256'] == expected
    assert summary['python'] == '3.10.22' and summary['hash_seed'] == '0'
    with gzip.open(path, 'rt') as source:
        rows = [json.loads(line) for line in source]
    assert len(rows) == summary['checkpoints']
    records = parent_records if label == 'parent-e37b965' else candidate_records
    assert outcome(summary) == outcome(records[name]), (name, label, summary)
    return rows, str(path.relative_to(evidence)), hashlib.sha256(path.read_bytes()).hexdigest()


def classify(name, parent, candidate):
    card = parent['card']
    if card == 68:
        assert parent['board']['tribes']['Remi']['allied_faction'] != parent['faction']
        return {'classification': 'remi_beneficiary_eligibility', 'status': 'intended',
            'explanation': 'Bot declines shaded Remi Influence because it does not own Remi; parent selected an ineffective Event. Candidate follows its normal Command instead.',
            'authority': ['Card Reference 68', 'Chapter 8, 8.2.3',
                'Arverni/Belgae Event Instructions, Remi Influence'],
            'remi_owner': parent['board']['tribes']['Remi']['allied_faction']}
    if card == 35:
        orders = [[item.get('kind') for item in row['result']['free_actions']]
                  for row in (parent, candidate)]
        return {'classification': 'gallic_shouts_order_choice', 'status': 'intended',
            'explanation': 'The printed free Command and Limited Command can run in either order. Candidate makes the otherwise unprioritized NP order choice with seeded randomness, rather than fixing Command first.',
            'authority': ['Card Reference 35', 'Chapter 8, 8.2.3 last bullet and 8.3.4'],
            'parent_order': orders[0], 'candidate_order': orders[1],
            'same_effect_immediately': board(parent) == board(candidate),
            'rng_only_at_first_difference': board(parent) == board(candidate)
                and choice(parent) == choice(candidate) and parent['rng'] != candidate['rng']}
    if card == 46:
        assert parent['faction'] == 'Germans'
        return {'classification': 'german_excluded_from_gallic_benefit', 'status': 'intended',
            'explanation': 'Celtic Rites grants a Gallic faction the Command. German NP cannot select itself, so it now declines the Event per 8.2.3 instead of receiving the unauthorized German free Command.',
            'authority': ['Card Reference 46', 'Chapter 8, 8.2.3 beneficiary bullet']}
    assert card == 67
    if name == 'The Great Revolt|6':
        return {'classification': 'unsourced_target_origin_exclusion', 'status': 'blocker',
            'explanation': 'Parent moves five pre-existing Nervii Warbands to Treveri. Candidate excludes both Event target Regions as origins and instead moves two Atrebates Warbands. Initial Nervii forces are legal origins; this is not the already-moved-arrivals correction. Engine agent independently confirmed the exclusion is an inherited A67 heuristic without a cited rule.',
            'authority': ['Card Reference 67 Tips', 'Chapter 3, 3.3.2'],
            'required_followup': 'Root must resolve the numeric67 origin policy and refreeze/revalidate before baseline acceptance.'}
    assert name in ('The Great Revolt|5', 'The Great Revolt|9', 'The Gallic War|18')
    return {'classification': 'arduenna_prevents_repeated_movement', 'status': 'intended',
        'explanation': 'Parent moves a group into Nervii and then moves those arrivals again to Treveri within the same March. Candidate retains original origin cohorts and does not remarch arrivals; subsequent Command choices use that corrected board.',
        'authority': ['Card Reference 67 Tips', 'Chapter 3, 3.3.2: no piece more than once']}


reviews, files = [], []
for name in changed + ['The Great Revolt|3']:
    left, lp, lh = load_trace(name, 'parent-e37b965', expected_parent)
    right, rp, rh = load_trace(name, 'candidate-67ee7ff', expected_candidate)
    files.extend([{'path': lp, 'sha256': lh}, {'path': rp, 'sha256': rh}])
    first, annotation_first = None, None
    for index, (a, b) in enumerate(zip(left, right)):
        assert key(a) == key(b), ('unaligned before first change', name, key(a), key(b))
        if annotation_first is None and a != b:
            annotation_first = key(a)
        if board(a) != board(b) or a['rng'] != b['rng'] or choice(a) != choice(b):
            first = {'checkpoint': key(a),
                'matching_meaningful_prefix_checkpoints': index,
                'prior_raw_board_equal': left[index-1]['board'] == right[index-1]['board'],
                'prior_meaningful_board_equal': board(left[index-1]) == board(right[index-1]),
                'prior_rng_equal': left[index-1]['rng'] == right[index-1]['rng'],
                'post_meaningful_board_equal': board(a) == board(b),
                'post_rng_equal': a['rng'] == b['rng'],
                'parent_choice': choice(a), 'candidate_choice': choice(b),
                **classify(name, a, b)}
            stem = name.rsplit('|', 1)[0].lower().replace(' ', '-').replace('?', '') + '-' + name.rsplit('|', 1)[1]
            (out / f'first-semantic-{stem}.json').write_text(json.dumps(
                {'parent': a, 'candidate': b}, indent=2) + '\n')
            break
    if first is None:
        assert name == 'The Great Revolt|3' and len(left) == len(right) == 427
        first = {'classification': 'inherited_only_exact_trajectory_match', 'status': 'intended',
            'matching_meaningful_prefix_checkpoints': 427,
            'explanation': 'Final source and immediate parent match all 427 board/RNG/choice checkpoints. The old-baseline winner difference predates this bundle.'}
    reviews.append({'game': name, 'older_baseline': baseline[name],
        'parent': outcome(parent_records[name]), 'candidate': outcome(candidate_records[name]),
        'parent_trace': lp, 'candidate_trace': rp, 'first_annotation_difference': annotation_first,
        'first_meaningful_difference': first})

baseline_review = []
for name in sorted(baseline):
    old, parent, candidate = baseline[name], outcome(parent_records[name]), outcome(candidate_records[name])
    if old == parent == candidate:
        continue
    category = ('inherited_only' if parent == candidate else 'new_only' if old == parent
        else 'cancelled_prior_drift' if old == candidate else 'overlap_prior_and_new')
    baseline_review.append({'game': name, 'category': category, 'older_baseline': old,
        'parent': parent, 'candidate': candidate, 'included_in_27_baseline_updates': old != candidate,
        'winner_changed_vs_baseline': old['winner'] != candidate['winner'],
        'cards_changed_vs_baseline': old['cards'] != candidate['cards'],
        'previous_review': ('docs/reviews/named-event-effects-2026-11-02.md; '
            'docs/reviews/named-event-effects-2026-11-02-results.json, causal_review (16 pairs independently verified)')
            if old != parent else None})

summary = {'status': 'blocked by one independently confirmed unsourced NPC67 policy change',
    'baseline_refresh_approved': False, 'source': {
        'parent_commit': 'e37b965e5ce420e29e486c7221661e51b9803282',
        'parent_sha256': expected_parent, 'candidate_sha256': expected_candidate},
    'runtime': {'python': '3.10.22', 'PYTHONHASHSEED': 0, 'parallel_games': 1},
    'counts': {'matrix_records_compared': 100, 'changed_parent_outcome_records': len(changed),
        'changed_parent_records_reviewed': 21, 'cleared_changed_parent_records': 20,
        'blocked_changed_parent_records': 1, 'additional_inherited_control_pairs': 1,
        'trace_pairs': 22, 'verified_trace_files': 44,
        'first_cause_categories': dict(collections.Counter(r['first_meaningful_difference']['classification'] for r in reviews if r['game'] in changed)),
        'all_old_parent_final_categories': dict(collections.Counter(r['category'] for r in baseline_review)),
        'older_baseline_updated_records': sum(r['included_in_27_baseline_updates'] for r in baseline_review),
        'older_baseline_winner_changes': sum(r['winner_changed_vs_baseline'] for r in baseline_review),
        'older_baseline_card_count_changes': sum(r['cards_changed_vs_baseline'] for r in baseline_review)},
    'normalization': [
        '_card_turn embeds result receipts; ignore it when comparing meaningful board state.',
        'decision.execution is an attached receipt; compare the chosen action/bot_action instead.',
        'card_67_target_regions is a write-only legacy marker (one parent source occurrence, no reader); ignore its cleanup but retain it in raw traces.'],
    'method_limits': ['First intended differences do not establish that one correction alone caused every later action or winner.',
        'Previous 16 inherited record changes reuse their named-event causal review; only Great Revolt3 is independently retraced here.',
        'One compressed Great Revolt5 candidate trace was truncated despite a successful summary. The bad compressed bytes were overwritten during recapture and were NOT retained. The original successful summary remains in capture.log; the replacement reproduces the outcome and passes full gzip/checkpoint-count validation.'],
    'reviews': reviews, 'baseline_record_classification': baseline_review,
    'trace_integrity': files}
(out / 'review-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'status': summary['status'], 'counts': summary['counts']}, indent=2))
