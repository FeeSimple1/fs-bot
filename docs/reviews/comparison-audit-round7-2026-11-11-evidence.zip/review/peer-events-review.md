# Independent review of frontend and bot findings

Reviewed by the Event partition against Falling Sky references and current source `c67d501711471bf790d805c017c2125b2c254639`.

Accept **FE7-01, NP7-01 and NP7-02**, all medium priority. Both final witness scripts rerun successfully; parsed JSON exactly matches the authors' final recorded output. Files are `peer-events-surus-rerun.json` and `peer-events-bots-rerun.json`.

| Finding | Source and evidence assessment |
|---|---|
| FE7-01 | Chapter3 3.4 applies ordinary German differences to Event-guided Commands; 3.4.2 permits one moving group per origin. Surus grants a selected-force Command without waiving that rule. The terminal, authored and durable paths all accept the forbidden split while single-group full/subset controls work. No new save/replay defect is claimed. |
| NP7-01 | Base8.5.1/8.7.1 and A8.7.1 explicitly require considering Ambush in Battle Loss comparisons. All three legal Ambush alternatives satisfy the favorable-loss requirement, but the gates reject them before SA selection. Revealed/no-SA controls establish the boundary. This differs from earlier ordinary Counterattack arithmetic repairs. |
| NP7-02 | Shaded Baggage Trains permits three Raiders, and 8.1.3/8.3 plus the individual Raid rules require maximizing the active priority. Four ordinary bot plans still use two; authored three-flip actions and capability-absent two-flip controls establish the mechanism. No Leader or Special Ability competes for the third Hidden Warband. |

All fixtures use canonical helpers and pass conservation/structure checks. Earlier original Enlist/Surus interface, German phase movement and forecast repairs were compared and do not duplicate these findings. Controlled fixtures establish defects, not encounter frequencies or winner impact. A31/Abatis remains excluded.
