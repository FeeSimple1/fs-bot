"""Small frozen-source policy checks, without drawing strategy-strength claims."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

REPO = Path('/workspace/scratch/534c265c65f4/fs-bot')
sys.path.insert(0, str(REPO))
import fs_bot.rules_consts as rc
from fs_bot.agents.heuristic import PROFILES
from fs_bot.tools.validation_metadata import source_identity


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-source', required=True)
    args = parser.parse_args()
    before = source_identity()
    assert before['source_sha256'] == args.expected_source, before
    root = Path(__file__).resolve().parent
    jobs = [
        ('strategy-base', rc.SCENARIO_GREAT_REVOLT, '1',
         ','.join(name for name, profile in PROFILES.items() if profile['faction'] != rc.GERMANS)),
        ('strategy-expansion', rc.SCENARIO_ARIOVISTUS, '1', 'G-GROW,G-BATTLE'),
        ('strategy-interlude', rc.SCENARIO_GALLIC_WAR, '1-3', 'G-GROW,G-BATTLE,RANDOM:Germans'),
    ]
    records, commands, codes = [], [], []
    for name, scenario, seeds, profiles in jobs:
        target = root / (name + '.jsonl')
        assert not target.exists(), 'Use fresh evidence paths'
        command = [sys.executable, '-m', 'fs_bot.tools.heuristic_selfplay',
                   '--scenario', scenario, '--seeds', seeds, '--profiles', profiles,
                   '--card-edition', 'second-edition', '--out', str(target)]
        with (root / (name + '.log')).open('w') as log:
            process = subprocess.run(command, cwd=REPO, stdout=log, stderr=subprocess.STDOUT)
        commands.append(command)
        codes.append(process.returncode)
        records.extend(json.loads(line) for line in target.read_text().splitlines())
    after = source_identity()
    failed = [dict(label=r['label'], scenario=r['scenario'], seed=r['seed'],
                   error=r.get('error'), diagnostics=r.get('diagnostics'),
                   integrity_findings=r.get('integrity_findings'))
              for r in records if not r.get('completed')]
    interludes = [dict(label=r['label'], seed=r['seed'], decisions=r.get('decisions_by_faction'))
                 for r in records if r.get('interlude_completed')
                 and r.get('decisions_by_faction', {}).get(rc.GERMANS, 0) > 0
                 and r.get('decisions_by_faction', {}).get(rc.ARVERNI, 0) > 0]
    stable = before['source_sha256'] == after['source_sha256'] == args.expected_source
    result = dict(classification='functional policy smoke, not a strategy ranking study',
                  source_before=before, source_after=after, source_stable=stable,
                  commands=commands, exit_codes=codes, games=len(records), failures=failed,
                  actual_interlude_handovers=interludes)
    (root / 'strategy-smoke-review.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    return 0 if stable and not any(codes) and not failed and interludes and len(records) == 20 else 1


if __name__ == '__main__':
    raise SystemExit(main())
