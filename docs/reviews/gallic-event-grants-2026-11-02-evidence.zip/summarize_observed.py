"""Report retained measurements, including cases from rejected acceptance runs.

This never runs a game and never replaces an acceptance result. In particular,
outcome comparisons from a rejected matrix are observations, not acceptance.
"""
from collections import Counter
from pathlib import Path
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
out = HERE / sys.argv[1]
read = lambda p: json.loads(p.read_text())
records = lambda p: [json.loads(line) for line in p.read_text().splitlines()]
protected = read(out / 'protected-before.json')
base_path = HERE.parent / 'fs-bot/fs_bot/tools/balance_baseline.json'
assert hashlib.sha256(base_path.read_bytes()).hexdigest() == protected['fs_bot/tools/balance_baseline.json']
baseline = read(base_path)['games']
before = read(out / 'source-manifest-before.json')
after = read(out / 'source-manifest-after.json')
accepted = read(out / 'integration-results.json')
editions = ('legacy', 'original', 'second-edition')
bots = {edition: records(out / ('bots-' + edition) / 'games.jsonl') for edition in editions}
parent = {(r['scenario'], r['seed']): r for r in records(out / 'parent-bots-legacy/games.jsonl')}
bot_counts, bot_failures = {}, []
for edition, rows in bots.items():
    assert all(r['source_sha256'] == before['python_sha256'] and r['commit'] == before['commit'] for r in rows)
    bot_counts[edition] = {'recorded': len(rows), 'engine_completed': sum(r['game_completed'] for r in rows),
                           'audit_completed': sum(r['audit_completed'] for r in rows),
                           'errors': sum(len(r['errors']) for r in rows),
                           'integrity_findings': sum(len(r['integrity_findings']) for r in rows),
                           'ranking_disagreements': sum(r['winner_differs_from_highest_margin'] for r in rows),
                           'missing_engine_rankings': sum(r['engine_ranking_output_missing'] for r in rows)}
    for row in rows:
        bad = [d for d in row['diagnostic_occurrences'] if d['severity'] != 'legal-decline']
        if bad or not row['completed']:
            bot_failures.append({k: row[k] for k in ('scenario', 'seed', 'card_edition', 'errors', 'integrity_findings')} | {'diagnostics': bad})

differences, rates = [], []
rows = bots['legacy']
for row in rows:
    previous = parent[row['scenario'], row['seed']]
    if any(row[key] != previous[key] for key in ('winner', 'cards')):
        differences.append({'scenario': row['scenario'], 'seed': row['seed'],
                            'before': {key: previous[key] for key in ('winner', 'cards')},
                            'after': {key: row[key] for key in ('winner', 'cards')},
                            'candidate_audit_completed': row['audit_completed']})
for scenario in sorted({r['scenario'] for r in rows}):
    old = Counter(baseline[f'{scenario}|{seed}']['winner'] for seed in range(1, 21))
    new = Counter(row['winner'] for row in rows if row['scenario'] == scenario)
    for faction in sorted(set(old) | set(new)):
        rates.append({'scenario': scenario, 'faction': faction, 'before_wins': old[faction], 'after_wins': new[faction],
                      'percentage_point_change': 5 * (new[faction] - old[faction])})

mixed = {}
for edition in editions:
    a, b = [read(out / f'fuzz-{edition}-{seed}.json') for seed in ('0', '7')]
    mixed[edition] = {'distinct_cases': a['games'], 'executions_with_hash_repeat_and_replay': 2 * (a['games'] + b['games']),
                      'cross_hash_json_equal': a == b,
                      'cross_hash_stdout_equal': (out / f'fuzz-{edition}-0.log').read_bytes() == (out / f'fuzz-{edition}-7.log').read_bytes(),
                      'engine_completed_hash0': sum(r['game_completed'] for r in a['records']),
                      'engine_completed_hash7': sum(r['game_completed'] for r in b['records']),
                      'hard_findings_per_hash': [a['hard_findings'], b['hard_findings']],
                      'soft_partial_per_hash': [a['partial'], b['partial']],
                      'hash0_failed_records': [r for r in a['records'] if r['findings'] or not r['game_completed']]}
census = [read(out / f'census-{seed}.json') for seed in ('0', '7')]
summary = {'acceptance_passed': accepted['passed'], 'source_unchanged_during_matrix': before == after,
           'source': {key: value for key, value in before.items() if key != 'files'},
           'scope': 'Observed counts and comparisons from retained raw records; does not supersede acceptance verdict.',
           'bots': bot_counts, 'bot_failures': bot_failures,
           'mixed': mixed, 'mixed_distinct_cases': sum(r['distinct_cases'] for r in mixed.values()),
           'mixed_executions': sum(r['executions_with_hash_repeat_and_replay'] for r in mixed.values()),
           'strict_census_executions': sum(r['games'] for r in census),
           'strict_census_completed': sum(r['completed'] for r in census),
           'strict_census_failures': [r['failures'] for r in census],
           'legacy_parent_outcome_changes': differences,
           'legacy_parent_final_state_changes': sum(r['final_state_sha256'] != parent[r['scenario'], r['seed']]['final_state_sha256'] for r in rows),
           'unchanged_baseline': {'rate_changes': rates, 'within_15pp_band': all(abs(r['percentage_point_change']) <= 15 for r in rates),
                                  'max_absolute_change_pp': max(abs(r['percentage_point_change']) for r in rates)}}
(out / 'observed-records-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: summary[key] for key in ('acceptance_passed', 'source_unchanged_during_matrix', 'bots', 'mixed_distinct_cases', 'mixed_executions', 'strict_census_completed', 'legacy_parent_outcome_changes', 'legacy_parent_final_state_changes')}, indent=2))
print('baseline max pp:', summary['unchanged_baseline']['max_absolute_change_pp'])
