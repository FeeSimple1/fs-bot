# Independent review of round 9 bot findings

Reviewer: lifecycle lane. Reviewed unchanged Falling Sky commit `f4c8372c396981c0a31dc6f4545e67f8c6f2e981`.

**Disposition: both proposed repair groups confirmed, medium priority.** This review inspected the complete witness source, checked the relevant supplied rules and production consumers independently, and reran `bots/probe_bots.py` at `PYTHONHASHSEED=0`. The result matches `bots/probe_bots-output.json` byte-for-byte; captured separately as `lifecycle/independent-bots-output.json`. The 16 public-dispatch executions, detached validated mechanic control, and 34 census/structural checks all passed their assertions describing the defects and controls. No production code or witness code was modified.

## NP9-01 — Devastate selection must count removals

`Reference Documents/Chapter 8:645–655` requires actual forced removal of a Legion/two Auxilia or the stated enemy/own removal condition. `Reference Documents/Chapter 4:121–130` removes floor(one quarter of Arverni Warbands) and floor(one third of each other faction's mobile pieces). These are not interchangeable with mere piece presence or comparative stack size.

The live `_check_devastate` in `fs_bot/bots/arverni_bot.py:1271–1289` treats any Roman Legion or at least two Auxilia as sufficient, and compares total Roman/Aedui pieces against total Arverni pieces in the third branch. The public Rally cases demonstrate actual own losses without enemy losses for the first two false positives, and a missed legal 1-for-1 Devastate against three Aedui Warbands. A legal detached direct-mechanic control verifies the exact latter losses without patching the predicate. Three Legions, one Auxilium, and Command-only controls distinguish genuine threshold behavior from lack of SA authority. These are source-backed selection errors, not a disagreement over strategy.

## NP9-02 — Post-Command opportunities and fallback decisions

Arverni: `Chapter 8:661–675,700–712` expressly puts Entreat after Rally when Devastate is unavailable. `node_v_rally` at `arverni_bot.py:929` evaluates its SA before the new Hidden Warbands exist. `_execute_sa_confirmed` at `execute.py:4784–4786` returns early for No SA, so the new legal Entreat is never considered. The unmodified public path leaves the Roman Auxilia in place; an already-present-Hidden control performs Entreat. The supplied-SA-label execution control leaves target determination to the real live executor and demonstrates the post-Rally replacement is legal, affordable and available.

Belgae: `Chapter 8:303–334,376–391` requires Rampage after Raid, then Enlist if no Rampage is possible; the Enlist instructions include a German March in place to Hide two or more Revealed Warbands. `node_b_raid` at `belgae_bot.py:964–975` chooses its SA on the pre-Raid board. `execute.py:4901–4908` correctly refuses the stale post-Raid Rampage but returns without trying Enlist. The public witness reveals both Hidden Belgic Warbands by Raid, retains both Revealed German Warbands, and reports a declined SA even though the actual live Enlist chooser offers March-to-Hide. The source-required Enlist-label control calls the unmodified executor, which rederives and completes that legal German March. An additional initial Belgic Hidden Warband preserves a valid Rampage; no German target and Command-only controls remain properly empty.

Grouping these two consumers under one late-state SA repair group is conservative and reasonable. Their fixtures establish the two stated ordinary-command branches only. NP8-02 previously repaired the separate Aedui Rally-to-Suborn transition; it did not repair these Arverni and Belgic consumers. Source-required control labels are explicitly identified and are not represented as unmodified dispatch results.

No reachability, encounter-frequency, or full-campaign claim is made by these controlled valid positions. The witnesses use canonical physical helpers, scenario-valid troops and Leaders, explicit ordinary-command permissions, and the public dispatch/execution pipeline without monkeypatching. All findings retain that scope.
