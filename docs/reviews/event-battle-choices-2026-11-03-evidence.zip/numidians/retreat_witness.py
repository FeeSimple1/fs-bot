"""§8.4.3 last-piece Retreat must account for revised 11's doubled Auxilia."""
from fs_bot import rules_consts as rc
from fs_bot.state.state_schema import build_initial_state
from fs_bot.board.pieces import place_piece, count_pieces
from fs_bot.board.control import refresh_all_control
from fs_bot.engine.execute import _resolve_fixed_event_battle

state = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=1)
state['non_player_factions'] = {rc.ROMANS, rc.BELGAE}
place_piece(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA, 6)
place_piece(state, rc.CARNUTES, rc.ROMANS, rc.LEGION, from_legions_track=True)
place_piece(state, rc.CARNUTES, rc.BELGAE, rc.WARBAND, 6)
place_piece(state, rc.ATREBATES, rc.BELGAE, rc.WARBAND)
refresh_all_control(state)
action = {'details': {'battle_plan': [{'region': rc.CARNUTES, 'target': rc.BELGAE}]}}
result = _resolve_fixed_event_battle(state, rc.ROMANS, action,
                                    double_auxilia=True, auxilia_only_attack=True)
print('defender_retreated:', result['defender_retreated'])
print('defender_losses:', result['attack']['losses_taken'])
print('surviving_Belgic_Warbands_in_Carnutes:',
      count_pieces(state, rc.CARNUTES, rc.BELGAE, rc.WARBAND))
