"""Frozen legacy baseline comparison; never updates the committed baseline."""
import argparse
from collections import Counter
import json
from pathlib import Path
import subprocess
import sys

REPO = Path('/workspace/scratch/534c265c65f4/fs-bot')
sys.path.insert(0, str(REPO))
import fs_bot.rules_consts as rc
from fs_bot.tools.validation_metadata import source_identity


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-source', required=True)
    args = parser.parse_args()
    before = source_identity()
    assert before['source_sha256'] == args.expected_source, before
    root = Path(__file__).resolve().parent
    output = root / 'baseline-legacy'
    baseline_bytes = subprocess.check_output(
        ['git', 'show', 'HEAD:fs_bot/tools/balance_baseline.json'], cwd=REPO)
    (root / 'baseline-before.json').write_bytes(baseline_bytes)
    baseline = json.loads(baseline_bytes)['games']
    cmd = [sys.executable, '-m', 'fs_bot.tools.run_batch', '--seeds', '1-20',
           '--card-edition', 'legacy', '--workers', '4', '--out', str(output)]
    with (root / 'baseline-legacy.log').open('w') as log:
        run = subprocess.run(cmd, cwd=REPO, stdout=log, stderr=subprocess.STDOUT)
    records = [json.loads(line) for line in (output / 'games.jsonl').read_text().splitlines()]
    expected = {(scenario, seed) for scenario in rc.ALL_SCENARIOS for seed in range(1, 21)}
    actual = {(record['scenario'], record['seed']) for record in records}
    findings = []
    if len(records) != 100 or actual != expected:
        findings.append('Not exactly one record per requested scenario/seed')
    changes = []
    for record in records:
        key = f"{record['scenario']}|{record['seed']}"
        old = baseline.get(key)
        new = {key: record[key] for key in ('winner', 'cards')}
        if old != new:
            changes.append(dict(scenario=record['scenario'], seed=record['seed'], before=old, after=new))
        if any(record.get(key) is not True for key in ('completed', 'game_completed', 'audit_completed')):
            findings.append(dict(key=key, kind='incomplete', record=record))
        if (record.get('error') or record.get('errors') or record.get('integrity_findings')
                or any(d['severity'] != 'legal-decline' for d in record.get('diagnostics', []))):
            findings.append(dict(key=key, kind='audit-findings', record=record))
    rates = {}
    for scenario in rc.ALL_SCENARIOS:
        old = Counter(baseline[f'{scenario}|{seed}']['winner'] for seed in range(1, 21))
        new = Counter(record['winner'] for record in records if record['scenario'] == scenario)
        rates[scenario] = {faction: dict(before=old[faction], after=new[faction],
            before_rate=old[faction]/20, after_rate=new[faction]/20,
            percentage_point_change=5*(new[faction]-old[faction])) for faction in rc.FACTIONS
            if faction in old or faction in new}
    after = source_identity()
    stable = before['source_sha256'] == after['source_sha256'] == args.expected_source
    report = dict(command=cmd, exit_code=run.returncode, source_before=before, source_after=after,
                  source_stable=stable, expected_games=100, recorded_games=len(records),
                  coverage_exact=actual == expected and len(records) == 100,
                  findings=findings, changed_records=len(changes),
                  changed_winners=sum(change['before']['winner'] != change['after']['winner']
                                      for change in changes if change['before']),
                  changes=changes, rates=rates,
                  legal_declines=sum(d['count'] for record in records for d in record['diagnostics']
                                     if d['severity'] == 'legal-decline'))
    (root / 'baseline-comparison.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('exit_code', 'source_stable', 'recorded_games',
          'coverage_exact', 'changed_records', 'changed_winners', 'legal_declines')}, indent=2))
    print('finding_count=', len(findings))
    return 0 if stable and not findings and run.returncode == 0 else 1


if __name__ == '__main__':
    raise SystemExit(main())
