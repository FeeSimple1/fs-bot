"""Fifth audit witnesses. Run with PYTHONPATH pointing to the audited fs-bot root.

Assertions freeze observed defects, not desired repaired behavior. All positions
are controlled empty-map states with the permanent Provincia Fort and legal
pieces placed using production helpers. No claim of natural sampled reach.
"""
from copy import deepcopy
from io import StringIO
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, place_piece
from fs_bot.cli.display import HumanTurnDisplay
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.free_actions import validate_free_action_response
from fs_bot.engine.game_engine import ACTION_EVENT, ACTION_COMMAND, ACTION_COMMAND_SA, _action_transaction
from fs_bot.state.serialize import decode, encode, load_game, save_game
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.tools.seat_session import DecisionPending, SeatSession, board_copy


def clean(state):
    census, structure = validate_state(state), check_structural_integrity(state)
    assert census == structure == [], (census, structure)


def board(actor):
    state = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=4)
    state.update(current_card=52, current_card_id=52, next_card=49,
                 card_edition='second-edition', executing_faction=None,
                 event_params=None, non_player_factions=set())
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    place_piece(state, rc.CARNUTES, actor, rc.WARBAND if actor == rc.AEDUI else rc.AUXILIA)
    clean(state)
    return state


def play_event(state, actor):
    return execute_decision(state, actor, {'action': ACTION_EVENT, 'player_action': {
        'command': rc.FIRST_DID_EVENT, 'sa': 'No SA', 'details': {
            'card_id': 52, 'event_params': {}, 'text_preference': rc.EVENT_SHADED}}})


def crossing_plan(destination=rc.BRITANNIA, ability=True):
    plan = {'command': rc.CMD_MARCH, 'sa': 'No SA', 'details': {
        'origins': [rc.MORINI], 'destinations': [destination],
        'routes': {rc.MORINI: [destination]}, 'groups': {rc.MORINI: {rc.WARBAND: 1}}}}
    if ability:
        plan.update(sa=rc.SA_SUBORN, sa_timing='after')
        plan['details']['suborn_plan'] = [{'region': rc.CARNUTES,
                                          'actions': [{'action': 'place_warband'}]}]
    return plan


def crossing_board():
    state = board(rc.AEDUI)
    place_piece(state, rc.MORINI, rc.AEDUI, rc.WARBAND, 2)
    state['resources'][rc.AEDUI] = 10
    clean(state)
    return state


def grant_agent(plan, requests):
    def agent(state, actor, request):
        requests.append(deepcopy(request))
        if request['kind'] == 'free_action':
            return deepcopy(plan)
    return agent


def crossing_case(destination, ability):
    state = crossing_board()
    plan = crossing_plan(destination, ability)
    requests = []
    state['decision_agent'] = grant_agent(plan, requests)
    result = play_event(state, rc.AEDUI)
    clean(state)
    assert result['executed'] and not result.get('rejected'), result
    grant = result['free_actions'][0]['result']
    assert grant['executed'] and not grant['errors'], grant
    assert count_pieces(state, destination, rc.AEDUI, rc.WARBAND) == 1
    assert count_pieces(state, rc.CARNUTES, rc.AEDUI, rc.WARBAND) == (2 if ability else 1)
    assert state['resources'][rc.AEDUI] == 10
    return {'result': result, 'requests': requests,
            'destination_warbands': count_pieces(state, destination, rc.AEDUI, rc.WARBAND),
            'carnutes_warbands': count_pieces(state, rc.CARNUTES, rc.AEDUI, rc.WARBAND),
            'resources': state['resources'][rc.AEDUI], 'census': [], 'structure': []}


def make_session(state, meta=None, log=None):
    seat = SeatSession(state, {'seat': rc.AEDUI} if meta is None else meta,
                       [] if log is None else log, HumanTurnDisplay(StringIO()))
    def agent(live, faction, request):
        if request['kind'] == 'free_action':
            return seat.reactive(live, faction, request)
    state['decision_agent'] = agent
    return seat


def step(seat):
    def driver(*args):
        pass
    driver.transaction_checkpoint = seat.checkpoint
    driver.transaction_restore = seat.restore
    with _action_transaction(seat.state, driver):
        return play_event(seat.state, rc.AEDUI)


def durable_crossing():
    state = crossing_board()
    initial = deepcopy(state)
    seat = make_session(state)
    try:
        step(seat)
        raise AssertionError('Expected the Event Command to remain pending')
    except DecisionPending:
        pass
    pending = deepcopy(seat.data['pending'])
    assert decode(pending['request'])['request_type'] == 'event_command'
    assert encode(board_copy(state)) == encode(initial)
    # Preview is isolated even though it incorrectly accepts the prohibited plan.
    request = decode(pending['request'])
    before = encode(board_copy(state))
    validation_error = validate_free_action_response(state, rc.AEDUI, request, crossing_plan())
    assert validation_error is None
    assert encode(board_copy(state)) == before
    with TemporaryDirectory() as tmp:
        path = Path(tmp) / 'save.json'
        save_game(state, path, meta=seat.meta, log=seat.log)
        restored, meta, log = load_game(path, validate=True)
        resumed = make_session(restored, meta, log)
        assert resumed.data['pending'] == pending
        resumed.import_inbox({'decision_id': pending['id'], 'response': crossing_plan()})
        result = step(resumed)
        resumed.finish()
        assert result['executed'] and resumed.data['pending'] is None
        assert decode(log[-1]['assistant_response']) == crossing_plan()
        clean(restored)
        assert count_pieces(restored, rc.BRITANNIA, rc.AEDUI, rc.WARBAND) == 1
        assert count_pieces(restored, rc.CARNUTES, rc.AEDUI, rc.WARBAND) == 2
        records = iter(log)
        def replay(live, actor, req):
            if req['kind'] == 'free_action':
                row = next(records)
                assert decode(row['assistant_request']) == dict(req, faction=actor)
                return decode(row['assistant_response'])
        initial['decision_agent'] = replay
        assert play_event(initial, rc.AEDUI) == result
        assert next(records, None) is None
        assert encode(board_copy(initial)) == encode(board_copy(restored))
        return {'pending_id': pending['id'], 'preview_error': validation_error,
                'preview_board_and_rng_unchanged': True, 'save_load_preserves_pending': True,
                'illegal_grant_accepted': True, 'clears_pending': True, 'replay_identical': True,
                'census': [], 'structure': []}


def dropoff_board():
    state = board(rc.ROMANS)
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.AUXILIA, 2)
    state['resources'][rc.ROMANS] = 10
    clean(state)
    return state


def dropoff_plan():
    return {'command': rc.CMD_MARCH, 'sa': 'No SA', 'details': {
        'origins': [rc.PROVINCIA], 'destinations': [rc.MANDUBII],
        'routes': {rc.PROVINCIA: [rc.SEQUANI, rc.MANDUBII]},
        'groups': {rc.PROVINCIA: {rc.AUXILIA: 2}}}}


def dropoff_case(event):
    state, requests = dropoff_board(), []
    plan = dropoff_plan()
    def agent(live, actor, request):
        requests.append(deepcopy(request))
        if request['kind'] == 'free_action':
            return deepcopy(plan)
        if request['kind'] == 'march_dropoff':
            assert request['region'] == rc.SEQUANI
            return {'dropoffs': [{'faction': rc.ROMANS, 'piece_type': rc.AUXILIA,
                                  'piece_state': rc.HIDDEN, 'count': 1}]}
    agent.supports_march_dropoffs = True
    state['decision_agent'] = agent
    result = (play_event(state, rc.ROMANS) if event else execute_decision(
        state, rc.ROMANS, {'action': ACTION_COMMAND, 'player_action': plan}))
    assert result['executed'] and not result.get('rejected'), result
    clean(state)
    kinds = [r['kind'] for r in requests]
    assert kinds.count('march_dropoff') == (0 if event else 1), kinds
    assert count_pieces(state, rc.SEQUANI, rc.ROMANS, rc.AUXILIA) == (0 if event else 1)
    assert count_pieces(state, rc.MANDUBII, rc.ROMANS, rc.AUXILIA) == (2 if event else 1)
    return {'result': result, 'requests': requests,
            'sequani_auxilia': count_pieces(state, rc.SEQUANI, rc.ROMANS, rc.AUXILIA),
            'mandubii_auxilia': count_pieces(state, rc.MANDUBII, rc.ROMANS, rc.AUXILIA),
            'census': [], 'structure': []}


def main():
    state = crossing_board()
    before = encode(state)
    ordinary = execute_decision(state, rc.AEDUI, {
        'action': ACTION_COMMAND_SA, 'player_action': crossing_plan()})
    assert ordinary['rejected'] and 'Britannia' in ordinary['reason']
    assert encode(state) == before
    output = {
        'FE5-01': {'illegal_event_crossing': crossing_case(rc.BRITANNIA, True),
                   'ordinary_crossing_control': ordinary,
                   'ordinary_rejection_board_rng_unchanged': True,
                   'legal_event_crossing_without_ability': crossing_case(rc.BRITANNIA, False),
                   'legal_event_mainland_march_with_ability': crossing_case(rc.NERVII, True),
                   'durable_save_resume_replay': durable_crossing()},
        'FE5-02': {'event_march': dropoff_case(True), 'ordinary_march_control': dropoff_case(False)},
    }
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
