"""Human player plan collection -- Phase 6 (mixed human/bot games).

After a human picks an action TYPE (menus.prompt_action), this module collects
the concrete plan (which Command, Regions, targets, Special Activity, Event
side) and returns it as a ``player_action`` dict in the same shape bot
flowcharts emit. ``engine.execute.execute_decision`` then applies it through the
same machinery used for bot turns, so a human turn resolves identically.

Design: present ONLY legal choices (a Region must hold the acting Faction's
pieces, a Battle needs an enemy present, etc.). This is the human-side analogue
of the "no illegal moves" hard-block in menus.prompt_action -- the executors and
mechanic functions remain the final validators.

The plan shapes mirror what each command executor consumes (engine/execute.py):
Seize ``regions`` + ``details['disperse_regions']``; Raid ``details['raid_plan']``;
Rally ``details['rally_plan']``; Battle ``details['battle_plan']``; Recruit
``details['recruit_plan']``; March ``details['origins']`` + ``['destinations']``.
"""

from fs_bot.rules_consts import (
    ROMAN_COMMANDS, GALLIC_COMMANDS, GERMAN_COMMANDS,
    ROMAN_SPECIAL_ABILITIES, AEDUI_SPECIAL_ABILITIES, BELGAE_SPECIAL_ABILITIES,
    ARVERNI_SPECIAL_ABILITIES_BASE, ARVERNI_SPECIAL_ABILITIES_ARIOVISTUS,
    GERMAN_SPECIAL_ABILITIES_BASE, GERMAN_SPECIAL_ABILITIES_ARIOVISTUS,
    ROMANS, ARVERNI, AEDUI, BELGAE, GERMANS,
    FACTIONS, LEGION, AUXILIA, WARBAND,
    EVENT_SHADED, EVENT_UNSHADED, ARIOVISTUS_SCENARIOS,
)
from fs_bot.engine.game_engine import (
    ACTION_COMMAND, ACTION_COMMAND_SA, ACTION_LIMITED_COMMAND,
    ACTION_EVENT, ACTION_PASS,
)
from fs_bot.map.map_data import (get_playable_regions_for_state, get_adjacent_for_state,
                                 is_adjacent)
from fs_bot.board.pieces import count_pieces, get_leader_in_region
from fs_bot.cli.menus import prompt_choice, prompt_yes_no

_SA_NONE = "No SA"

_FACTION_COMMANDS = {
    ROMANS: ROMAN_COMMANDS,
    ARVERNI: GALLIC_COMMANDS, AEDUI: GALLIC_COMMANDS, BELGAE: GALLIC_COMMANDS,
    GERMANS: GERMAN_COMMANDS,
}


def _faction_special_abilities(faction, scenario):
    ario = scenario in ARIOVISTUS_SCENARIOS
    if faction == ROMANS:
        return ROMAN_SPECIAL_ABILITIES
    if faction == AEDUI:
        return AEDUI_SPECIAL_ABILITIES
    if faction == BELGAE:
        return BELGAE_SPECIAL_ABILITIES
    if faction == ARVERNI:
        return (ARVERNI_SPECIAL_ABILITIES_ARIOVISTUS if ario
                else ARVERNI_SPECIAL_ABILITIES_BASE)
    if faction == GERMANS:
        return (GERMAN_SPECIAL_ABILITIES_ARIOVISTUS if ario
                else GERMAN_SPECIAL_ABILITIES_BASE)
    return ()


def _mobile_count(state, region, faction):
    n = (count_pieces(state, region, faction, LEGION)
         + count_pieces(state, region, faction, AUXILIA)
         + count_pieces(state, region, faction, WARBAND))
    if get_leader_in_region(state, region, faction) is not None:
        n += 1
    return n


def _playable_regions(state, faction=None):
    """Playable Regions, intersected with the current Event's selection scope."""
    regions = get_playable_regions_for_state(state, faction)
    allowed = state.get("_cli_allowed_regions")
    return [r for r in regions if allowed is None or r in allowed]


def _march_routes(state, origin, faction, group=None):
    """Offer full legal routes for the selected group, including normal March.

    The movement-only mechanic checks each prospective step on a detached
    board. It neither resolves Harassment nor rolls dice, so route options
    never peek at future outcomes or consume a live player's reactions.
    """
    required = state.get("_cli_required_destinations")
    from fs_bot.commands.march import _max_steps_for_group, march_group, MarchError
    from fs_bot.board.pieces import PieceError
    from fs_bot.board.pieces import get_leader_in_region
    from fs_bot.rules_consts import LEADER
    leader = get_leader_in_region(state, origin, faction)
    if group is None:
        group = {pt: count_pieces(state, origin, faction, pt)
                 for pt in (LEGION, AUXILIA, WARBAND)}
        group[LEADER] = leader
    else:
        group = dict(group)
        group[LEADER] = leader if group.get(LEADER) else None
    maximum = _max_steps_for_group(state, origin, faction, group)
    routes = []
    def visit(board, current, route):
        if len(route) == maximum:
            return
        for region in sorted(get_adjacent_for_state(board, current, faction)):
            if region == origin or region in route:
                continue
            sim = _planning_copy(board)
            try:
                outcome = march_group(sim, faction, current, [region], group, free=True)
            except (MarchError, PieceError):
                continue
            if outcome['path'] != [current, region]:
                continue
            path = route + [region]
            if required is None or region in required:
                routes.append(path)
            if not outcome['stopped_reason'] and not (required is not None and region in required):
                visit(sim, region, path)
    visit(state, origin, [])
    return sorted(routes, key=lambda path: (len(path), path))


def _check_selected_march_route(state, faction, origin, route, group, stdin, stdout):
    """Re-pick if a subset leaves behind the Leader needed for a long route."""
    routes = _march_routes(state, origin, faction, group)
    if route in routes:
        return route
    if not routes:
        stdout.write("This group cannot reach a permitted destination.\n")
        return None
    stdout.write("This group cannot complete that route. Choose a route for its selected pieces.\n")
    return prompt_choice(stdin, stdout, f"  March the {origin} group along which route?",
                         [(" → ".join(path), path) for path in routes])


def _regions_with_pieces(state, faction):
    return [r for r in _playable_regions(state, faction)
            if count_pieces(state, r, faction) > 0]


def _enemies_in_region(state, region, faction):
    return [f for f in FACTIONS
            if f != faction and count_pieces(state, region, f) > 0]


def _battle_regions(state, faction):
    out = []
    for r in _playable_regions(state, faction):
        if (_mobile_count(state, r, faction) > 0
                and _enemies_in_region(state, r, faction)):
            out.append(r)
    return out


def _subdued_tribes(state, region):
    from fs_bot.map.map_data import get_tribes_in_region
    out = []
    for t in get_tribes_in_region(region, state["scenario"]):
        ti = state.get("tribes", {}).get(t, {})
        if ti.get("allied_faction") is None and ti.get("status") is None:
            out.append(t)
    return out


def _pick_regions(stdin, stdout, prompt, candidates, *, at_least_one=True,
                  single=False, max_regions=None):
    """Pick Region(s) from ``candidates`` (each pickable once). ``single``
    collects exactly one; otherwise add Regions until "(done)"."""
    chosen, remaining = [], list(candidates)
    while remaining and (max_regions is None or len(chosen) < max_regions):
        opts = [(r, r) for r in remaining]
        if not single and (chosen or not at_least_one):
            opts.append(("(done)", None))
        pick = prompt_choice(stdin, stdout, prompt, opts)
        if pick is None:
            break
        chosen.append(pick)
        remaining.remove(pick)
        if single:
            break
    return chosen


def _collect_battle(state, faction, stdin, stdout, single, *, excluded=()):
    regions = [r for r in _battle_regions(state, faction) if r not in excluded]
    if not regions:
        return None
    picked = _pick_regions(stdin, stdout, "Battle in which Region(s)?",
                           regions, single=single,
                           max_regions=state.get("_cli_command_max_regions"))
    plan = []
    for r in picked:
        enemies = _enemies_in_region(state, r, faction)
        target = prompt_choice(stdin, stdout, f"  Defender in {r}?",
                               [(f, f) for f in enemies])
        plan.append({"region": r, "target": target})
    return {"battle_plan": plan} if plan else None


def _collect_raid(state, faction, stdin, stdout, single, *, excluded=()):
    from fs_bot.cli.action_windows import available
    if available(state):
        from fs_bot.cli.command_timing import collect_raid
        return collect_raid(state, faction, stdin, stdout, single, excluded=excluded)
    from fs_bot.board.pieces import count_pieces_by_state
    from fs_bot.commands.common import _is_devastated
    from fs_bot.commands.raid import (
        get_valid_steal_targets, max_raiders_per_region, validate_raid_region,
    )
    from fs_bot.commands.sa_enlist import borrowed_count
    from fs_bot.rules_consts import BASE_SCENARIOS, HIDDEN

    # Reserve victim Resources across every chosen flip/Region. The menu
    # must not execute Raid: that would reveal pieces, roll policy dice, or
    # ask the intrinsic Intimidate question before this plan is submitted.
    planning = dict(state, resources=dict(state['resources']))

    def can_gain(region):
        return (not _is_devastated(state, region)
                and not (faction == GERMANS and state['scenario'] in BASE_SCENARIOS))

    regions = [r for r in _regions_with_pieces(state, faction)
               if r not in excluded
               and validate_raid_region(state, r, faction, allow_base_germans=True)[0]
               and (can_gain(r) or get_valid_steal_targets(planning, r, faction))]
    if not regions:
        return None
    picked = _pick_regions(stdin, stdout, "Raid in which Region(s)?",
                           regions, single=single,
                           max_regions=state.get("_cli_command_max_regions"))
    plan = []
    for r in picked:
        hidden = count_pieces_by_state(state, r, faction, WARBAND, HIDDEN)
        maximum = min(hidden, max_raiders_per_region(state, faction))
        if not can_gain(r):
            maximum = min(maximum, sum(planning['resources'][target]
                for target in get_valid_steal_targets(planning, r, faction)))
        if not maximum:
            stdout.write(f'  No Resources remain to Raid in {r}.\n')
            continue
        number = (prompt_choice(stdin, stdout,
                  f'  Raid with how many Hidden Warbands in {r}?',
                  [(str(n), n) for n in range(1, maximum + 1)])
                  if maximum > 1 else 1)
        borrowed = borrowed_count(state, r, HIDDEN) if faction == BELGAE else 0
        owners_left = {GERMANS: borrowed, BELGAE: hidden - borrowed}
        borrowing = borrowed > 0
        for index in range(number):
            opts = [(f'steal from {target}', target)
                    for target in get_valid_steal_targets(planning, r, faction)]
            if can_gain(r):
                opts.append(('gain 1 Resource', None))
            target = prompt_choice(stdin, stdout,
                                   f'  Raid {index + 1} target in {r}?', opts)
            entry = {'region': r, 'target': target}
            if borrowing:
                owners = [(owner, owner) for owner in (GERMANS, BELGAE)
                          if owners_left[owner] > 0]
                owner = (prompt_choice(stdin, stdout,
                         'Reveal a Warband belonging to which Faction?', owners)
                         if len(owners) > 1 else owners[0][1])
                entry['physical_owner'] = owner
                owners_left[owner] -= 1
            if target is not None:
                planning['resources'][target] -= 1
            plan.append(entry)
    return {"raid_plan": plan} if plan else None


def _collect_march(state, faction, stdin, stdout, single, *, excluded=()):
    origins_c = [r for r in _regions_with_pieces(state, faction)
                 if r not in excluded and _mobile_count(state, r, faction) > 0
                 and _march_routes(state, r, faction)]
    if not origins_c:
        return None
    origins = _pick_regions(stdin, stdout, "March OUT of which Region(s)?",
                            origins_c, single=single,
                            max_regions=state.get("_cli_command_max_regions"))
    if not origins:
        return None
    # One destination per origin, chosen explicitly (other origins are
    # valid destinations -- chained marches like A->B while B->C are legal).
    # Emitted as exact routes so the executor marches each group precisely
    # where told instead of pooling destinations by nearest path.
    destinations = []
    routes = {}
    for o in origins:
        candidates = _march_routes(state, o, faction)
        if not candidates:
            continue
        route = prompt_choice(stdin, stdout,
                              f"  March the {o} group along which route?",
                              [(" → ".join(path), path) for path in candidates])
        routes[o] = route
        d = route[-1]
        if d not in destinations:
            destinations.append(d)
    if not destinations:
        return None
    # Sec.3.2.2: the marching group is the player's own selection -- offer a
    # subset per origin (all-mobile remains the default).
    groups = {}
    from fs_bot.board.pieces import get_leader_in_region
    for o in origins:
        cap = {}
        partial = False
        for pt in (LEGION, AUXILIA, WARBAND):
            n = count_pieces(state, o, faction, pt)
            if n <= 0:
                continue
            pick = prompt_choice(
                stdin, stdout,
                f"  March how many {pt}s from {o}? (of {n})",
                [(f"all {n}", n)] + [(str(k), k) for k in range(n - 1, -1, -1)])
            cap[pt] = pick
            if pick < n:
                partial = True
        if get_leader_in_region(state, o, faction) is not None:
            from fs_bot.rules_consts import LEADER
            take = prompt_yes_no(stdin, stdout,
                                 f"  March the Leader from {o}?",
                                 default=True)
            cap[LEADER] = take
            if not take:
                partial = True
        if partial:
            groups[o] = cap
        from fs_bot.commands.sa_enlist import borrowed_count
        if faction == BELGAE and borrowed_count(state, o):
            total = cap.get(WARBAND, 0)
            loan = borrowed_count(state, o)
            own = count_pieces(state, o, faction, WARBAND) - loan
            cap["german_warbands"] = prompt_choice(stdin, stdout,
                f"Of these {total} Warbands, how many are German?",
                [(str(k), k) for k in range(min(total, loan), max(0, total - own) - 1, -1)])
            groups[o] = cap
        routes[o] = _check_selected_march_route(
            state, faction, o, routes[o], cap, stdin, stdout)
        if routes[o] is None:
            return None
    destinations = list(dict.fromkeys(route[-1] for route in routes.values()))
    plan = {"origins": origins, "destinations": destinations,
            "routes": routes}
    if groups:
        plan["groups"] = groups

    # Sec.3.2.2/3.3.2 (A3.4.2): any number of groups may leave an origin,
    # but no piece may March twice. Keep offering groups from the remaining
    # original pieces, including a Leader left behind by the first group.
    extra = []
    from fs_bot.rules_consts import LEADER
    for o in origins:
        if o not in groups:
            continue  # first group takes everything -- nothing remains
        remaining = {pt: count_pieces(state, o, faction, pt)
                     - int(groups[o].get(pt, 0) or 0)
                     for pt in (LEGION, AUXILIA, WARBAND)}
        leader_remaining = (get_leader_in_region(state, o, faction) is not None
                            and not groups[o].get(LEADER))
        from fs_bot.commands.sa_enlist import borrowed_count
        loan_remaining = (borrowed_count(state, o)
                          - groups[o].get("german_warbands", 0)
                          if faction == BELGAE else 0)
        group_number = 2
        while leader_remaining or any(v > 0 for v in remaining.values()):
            candidates = _march_routes(state, o, faction,
                                       dict(remaining, **{LEADER: leader_remaining}))
            if not candidates:
                stdout.write("The remaining pieces cannot reach a permitted destination.\n")
                break
            label = "SECOND" if group_number == 2 else f"group {group_number}"
            if not prompt_yes_no(stdin, stdout,
                                 f"March a {label} group from {o}?" if group_number == 2
                                 else f"March {label} from {o}?",
                                 default=False):
                break
            route = prompt_choice(stdin, stdout,
                                  f"  Group {group_number} from {o} along which route?",
                                  [(" → ".join(path), path) for path in candidates])
            group = {}
            for pt, avail in remaining.items():
                if avail <= 0:
                    continue
                pick = prompt_choice(
                    stdin, stdout,
                    f"  Group {group_number}: how many {pt}s? (of {avail})",
                    [(str(k), k) for k in range(avail, -1, -1)])
                if pick:
                    group[pt] = pick
            if leader_remaining and prompt_yes_no(
                    stdin, stdout, f"  March the Leader with group {group_number} from {o}?",
                    default=True):
                group[LEADER] = True
            if not group:
                stdout.write("No pieces selected for this group.\n")
                continue
            route = _check_selected_march_route(
                state, faction, o, route, group, stdin, stdout)
            if route is None:
                continue
            if faction == BELGAE and borrowed_count(state, o) and group.get(WARBAND):
                total = group[WARBAND]
                own = remaining[WARBAND] - loan_remaining
                group["german_warbands"] = prompt_choice(stdin, stdout,
                    f"Of these {total} Warbands, how many are German?",
                    [(str(k), k) for k in range(min(total, loan_remaining),
                                                max(0, total - own) - 1, -1)])
                loan_remaining -= group["german_warbands"]
            extra.append({"origin": o, "route": route, "group": group})
            for pt in remaining:
                remaining[pt] -= group.get(pt, 0)
            if group.get(LEADER):
                leader_remaining = False
            if route[-1] not in destinations:
                destinations.append(route[-1])
            group_number += 1
    if extra:
        plan["extra_groups"] = extra
    return plan


def _collect_rally(state, faction, stdin, stdout, single, *, excluded=()):
    from fs_bot.cli.recruit_rally import collect
    return collect(state, faction, stdin, stdout, single, rally=True, excluded=excluded)


def _collect_recruit(state, faction, stdin, stdout, single, *, excluded=()):
    from fs_bot.cli.recruit_rally import collect
    return collect(state, faction, stdin, stdout, single, rally=False, excluded=excluded)


def _collect_seize(state, faction, stdin, stdout, single, *, excluded=()):
    from fs_bot.cli.action_windows import available
    if available(state):
        from fs_bot.cli.command_timing import collect_seize
        return collect_seize(state, faction, stdin, stdout, single, excluded=excluded)
    from fs_bot.commands.seize import get_dispersible_tribes
    regions = _playable_regions(state, faction)
    cand = [r for r in regions if r not in excluded and count_pieces(state, r, ROMANS) > 0]
    if not cand:
        return None
    picked = _pick_regions(stdin, stdout, "Seize in which Region(s)?",
                           cand, single=single,
                           max_regions=state.get("_cli_command_max_regions"))
    disperse = []
    for r in picked:
        if get_dispersible_tribes(state, r) and prompt_yes_no(
                stdin, stdout, f"  Disperse Subdued Tribes in {r}?",
                default=True):
            disperse.append(r)
    return {"_regions": picked, "disperse_regions": disperse}


def _citadel_upgrade_tribes(state, region, faction):
    """City Tribes in ``region`` holding ``faction``'s Ally -- Citadel
    upgrade candidates (Sec.3.3.1, Gallic Factions)."""
    from fs_bot.rules_consts import TRIBE_TO_CITY
    if faction not in (AEDUI, ARVERNI, BELGAE):
        return []
    from fs_bot.map.map_data import get_tribes_in_region
    out = []
    for t in get_tribes_in_region(region, state["scenario"]):
        ti = state.get("tribes", {}).get(t, {})
        if ti.get("allied_faction") == faction and t in TRIBE_TO_CITY:
            out.append(t)
    return out


def _enemy_ally_tribes(state, region, faction):
    """(tribe, owner) pairs for enemy Allied Tribes in ``region``."""
    from fs_bot.map.map_data import get_tribes_in_region
    out = []
    for t in get_tribes_in_region(region, state["scenario"]):
        owner = state.get("tribes", {}).get(t, {}).get("allied_faction")
        if owner and owner != faction:
            out.append((t, owner))
    return out


# --------------------------------------------------------------------- #
# Special Activity plan collectors -- one per SA whose executor needs a
# concrete plan (engine/execute.py shapes). SAs absent here either need
# no plan (Trade; Build/Scout recompute Sec.8.8-faithful plans against the
# board) or only Region names (Devastate, Settle), which the generic
# picker in _collect_command covers.
# --------------------------------------------------------------------- #

def _collect_suborn(state, faction, stdin, stdout, *, pending=None):
    """Choose all legal §4.4.2 native pieces, with A38/43 and exact states."""
    from fs_bot.cli.action_windows import available
    if available(state):
        from fs_bot.cli.sa_timing import collect_suborn
        return collect_suborn(state, faction, stdin, stdout)
    from fs_bot.rules_consts import ALLY
    from fs_bot.commands.sa_suborn import (
        legal_suborn_operations, suborn_limits, suborn_region_limit,
        suborn_preview, validate_suborn_region)
    sim = _planning_copy(state)
    plan, selected = [], []
    maximum = suborn_region_limit(sim)
    max_pieces, max_allies = suborn_limits(sim)

    def grouped(operations):
        groups = {}
        for operation in operations:
            action, owner, piece = (operation[key] for key in
                                     ("action", "faction", "piece_type"))
            if piece == ALLY and action == "remove" and owner != faction:
                label = "remove an enemy Ally"
            elif piece == ALLY and action == "place" and owner == faction:
                label = "place your Ally at a Subdued Tribe"
            elif piece == WARBAND and action == "place" and owner == faction:
                label = "place a Warband"
            elif piece == ALLY and action == "remove":
                label = "remove your Ally"
            elif piece == ALLY and action == "place":
                label = f"place a {owner} Ally at a Subdued Tribe"
            else:
                label = f"{action} a {owner} {piece}"
            groups.setdefault(label, []).append(operation)
        # Keep the existing common shortcuts, followed by every other legal
        # Faction/type combination. This order never removes a legal choice.
        labels = [label for label in ("place your Ally at a Subdued Tribe",
                  "remove an enemy Ally", "place a Warband") if label in groups]
        labels.extend(label for label in groups if label not in labels)
        return [(label, groups[label]) for label in labels]

    while len(plan) < maximum:
        regions = [region for region in _regions_with_pieces(sim, faction)
                   if region not in selected and validate_suborn_region(sim, region)[0]
                   and legal_suborn_operations(sim, region)]
        if not regions:
            break
        choices = [(region, region) for region in regions]
        choices.append(("(done)", None))
        region = prompt_choice(stdin, stdout, "Suborn in which Region?", choices)
        if region is None:
            break
        # Test the Hidden/Leader gates once on selecting this Region. A later
        # operation may legally remove the last Hidden Aedui Warband here.
        region_start = sim
        operations, cancelled = [], False
        while len(operations) < max_pieces:
            ally_count = sum(op["piece_type"] == ALLY for op in operations)
            available = [op for op in legal_suborn_operations(sim, region)
                         if op["piece_type"] != ALLY or ally_count < max_allies]
            options = grouped(available)
            options.append(("(done)", None))
            if operations:
                options.append(("(undo last operation)", "undo"))
            options.append(("(cancel this Region)", "cancel"))
            if not available and not operations:
                break
            pick = prompt_choice(stdin, stdout,
                f"Suborn action {len(operations) + 1} of up to {max_pieces}:", options)
            if pick is None:
                break
            if pick == "cancel":
                sim, operations, cancelled = region_start, [], True
                break
            if pick == "undo":
                operations.pop()
                sim, _ = suborn_preview(region_start, region, operations)
                continue
            if pick[0]["piece_type"] == ALLY:
                placing = pick[0]["action"] == "place"
                operation = prompt_choice(stdin, stdout,
                    "Ally which Tribe?" if placing else "Remove which Ally?",
                    [(op["tribe"] if placing else
                      f"{op['tribe']} ({op['faction']})", op) for op in pick]
                    + [("(back)", None)])
            elif len(pick) > 1:
                operation = prompt_choice(stdin, stdout,
                    f"Remove which {pick[0]['faction']} {pick[0]['piece_type']}?",
                    [(op["piece_state"], op) for op in pick]
                    + [("(back)", None)])
            else:
                operation = pick[0]
            if operation is None:
                continue
            operations.append(operation)
            sim, _ = suborn_preview(region_start, region, operations)
        if operations:
            selected.append(region)
            plan.append({"region": region, "actions": operations})
        elif not cancelled:
            # Explicitly finishing an empty Region finishes this SA; the
            # cancel choice above instead returns to Region selection.
            break
    if not plan:
        return None, None
    return selected, {"suborn_plan": plan}


def _collect_entreat(state, faction, stdin, stdout, *, pending=None):
    """Arverni Entreat (Sec.4.3.1): replace/remove enemy Allies or pieces in
    Arverni-Controlled Regions (1 Resource each)."""
    from fs_bot.cli.action_windows import available
    if available(state):
        from fs_bot.cli.sa_timing import collect_entreat
        return collect_entreat(state, faction, stdin, stdout)
    entries = []
    while True:
        regions = _regions_with_pieces(state, faction)
        if not regions:
            return None, None
        opts = [(r, r) for r in regions]
        if entries:
            opts.append(("(done)", None))
        region = prompt_choice(stdin, stdout,
                               "Entreat in which Region?", opts)
        if region is None:
            break
        enemy_allies = _enemy_ally_tribes(state, region, faction)
        acts = []
        for t, owner in enemy_allies:
            acts.append((f"replace {owner} Ally at {t} with yours",
                         {"action": "replace_ally", "region": region,
                          "tribe": t, "target_faction": owner}))
            acts.append((f"remove {owner} Ally at {t}",
                         {"action": "remove_ally", "region": region,
                          "tribe": t, "target_faction": owner}))
        for f in _enemies_in_region(state, region, faction):
            for pt in (WARBAND, AUXILIA):
                if count_pieces(state, region, f, pt) > 0:
                    acts.append(
                        (f"replace a {f} {pt} with your Warband",
                         {"action": "replace_piece", "region": region,
                          "piece_type": pt, "target_faction": f}))
        if not acts:
            stdout.write(f"  (no Entreat target in {region})\n")
            if entries:
                break
            return None, None
        acts.append(("(cancel this Region)", None))
        pick = prompt_choice(stdin, stdout, f"Entreat action in {region}:",
                             acts)
        if pick is not None:
            entries.append(pick)
        if not prompt_yes_no(stdin, stdout, "Entreat in another Region?",
                             default=False):
            break
    if not entries:
        return None, None
    return entries, None      # plan rides in sa_regions


def _collect_rampage(state, faction, stdin, stdout, *, pending=None):
    """Belgic Rampage (Sec.4.5.2): Regions with Hidden Belgic Warbands and an
    enemy; each entry names the target Faction."""
    from fs_bot.cli.action_windows import available
    if available(state):
        from fs_bot.cli.sa_timing import collect_rampage
        return collect_rampage(state, faction, stdin, stdout)
    from fs_bot.rules_consts import HIDDEN
    from fs_bot.board.pieces import count_pieces_by_state
    cands = [r for r in _regions_with_pieces(state, faction)
             if count_pieces_by_state(state, r, faction, WARBAND,
                                      HIDDEN) > 0
             and _enemies_in_region(state, r, faction)]
    if not cands:
        return None, None
    picked = _pick_regions(stdin, stdout, "Rampage in which Region(s)?",
                           cands)
    entries = []
    for r in picked:
        target = prompt_choice(stdin, stdout, f"  Rampage target in {r}?",
                               [(f, f) for f in
                                _enemies_in_region(state, r, faction)])
        entries.append({"region": r, "target": target})
    if not entries:
        return None, None
    return entries, None      # plan rides in sa_regions


def _collect_intimidate(state, faction, stdin, stdout, *, pending=None):
    """German Intimidate (A4.6.2): flip Hidden Warbands to remove that many
    pieces of ONE Faction per Region (1-2 per Region)."""
    from fs_bot.cli.action_windows import available
    if available(state):
        from fs_bot.cli.sa_timing import collect_intimidate
        return collect_intimidate(state, faction, stdin, stdout)
    from fs_bot.rules_consts import HIDDEN, ALLY
    from fs_bot.board.pieces import count_pieces_by_state
    cands = [r for r in _regions_with_pieces(state, faction)
             if count_pieces_by_state(state, r, faction, WARBAND,
                                      HIDDEN) > 0]
    if not cands:
        return None, None
    picked = _pick_regions(stdin, stdout,
                           "Intimidate in which Region(s)?", cands)
    plan = []
    for r in picked:
        from fs_bot.board.pieces import get_leader_in_region
        targets = [f for f in _enemies_in_region(state, r, faction)
                   if get_leader_in_region(state, r, f) is None
                   and any(count_pieces(state, r, f, pt)
                           for pt in (WARBAND, AUXILIA, ALLY))
                   and not (f == ROMANS and state.get("event_modifiers", {}).get(
                       "card_A22_no_intimidate_romans"))]
        target = prompt_choice(stdin, stdout,
                               f"  Intimidate which Faction in {r}?",
                               [(f, f) for f in targets] +
                               [("Place an Intimidated marker only", None)])
        if target is None:
            plan.append({"region": r, "target_faction": None,
                         "target_piece": None, "target_state": None})
            continue
        flips = min(2, count_pieces_by_state(state, r, faction, WARBAND,
                                             HIDDEN))
        reserved = {}
        for _ in range(flips):
            pts = [(pt, pt) for pt in (WARBAND, AUXILIA, ALLY)
                   if count_pieces(state, r, target, pt) > reserved.get(pt, 0)]
            if not pts:
                break
            pts.append(("(stop here)", None))
            pt = prompt_choice(stdin, stdout,
                               f"  Remove which {target} piece in {r}?",
                               pts)
            if pt is None:
                break
            reserved[pt] = reserved.get(pt, 0) + 1
            plan.append({"region": r, "target_faction": target,
                         "target_piece": pt, "target_state": None})
    if not plan:
        return None, None
    return picked, {"intimidate_plan": plan}


def _collect_enlist(state, faction, stdin, stdout, *, pending=None,
                    before_state=None, borrow_only=False):
    """Choose Enlist's timing board before any removal or borrowing menu."""
    if borrow_only:
        sub = 'borrow'
    else:
        sub = prompt_choice(stdin, stdout, "Enlist the Germans to:",
            [("Battle", "german_battle"), ("March", "german_march"),
             ("hide (flip Warbands Hidden)", "german_march_hide"),
             ("Rally", "german_rally"), ("Raid", "german_raid"),
             ("lend Warbands to the Belgic Command", "borrow")])
    if sub == 'borrow' and before_state is not None:
        state = before_state
    from fs_bot.cli.action_windows import prepare, inspect_board
    state, timing = prepare(state, faction, stdin, stdout,
                            stage='special_ability', sa='Enlist')
    with inspect_board(state, stdout):
        regions, details = _collect_enlist_details(
            state, faction, stdin, stdout, pending=pending, _sub=sub)
    if details is not None and timing:
        details.setdefault('sa_details', {})['timing_actions'] = timing
    elif timing:
        return [], {'sa_details': {'timing_actions': timing}}
    return regions, details


def _collect_enlist_details(state, faction, stdin, stdout, *, pending=None,
                            before_state=None, borrow_only=False, _sub=None):
    """Choose either borrowed Warbands or a free German Command (§4.5.1)."""
    from fs_bot.commands.sa_enlist import validate_enlist_region
    from fs_bot.rules_consts import HIDDEN, REVEALED, SCOUTED
    from fs_bot.board.pieces import count_pieces_by_state
    if _sub is not None:
        sub = _sub
    elif borrow_only:
        sub = "borrow"
    else:
        sub = prompt_choice(stdin, stdout, "Enlist the Germans to:",
                            [("Battle", "german_battle"),
                             ("March", "german_march"),
                             ("hide (flip Warbands Hidden)", "german_march_hide"),
                             ("Rally", "german_rally"),
                             ("Raid", "german_raid"),
                             ("lend Warbands to the Belgic Command", "borrow")])
    if sub == "borrow":
        state = before_state if before_state is not None else state
        candidates = [r for r in _playable_regions(state, GERMANS)
                      if validate_enlist_region(state, r)[0]]
        if not candidates:
            return None, None
        regions = _pick_regions(stdin, stdout, "Enlist in which Regions?", candidates)
        if state["scenario"] not in ARIOVISTUS_SCENARIOS:
            return regions, {"enlist": {"type": "borrow", "regions": regions}}
        selected = {}
        budget = 4 if state["scenario"] in ARIOVISTUS_SCENARIOS else float("inf")
        for region in regions:
            selected[region] = {}
            for ps in (HIDDEN, REVEALED, SCOUTED):
                n = min(budget, count_pieces_by_state(state, region, GERMANS, WARBAND, ps))
                count = (prompt_choice(stdin, stdout,
                         f"Borrow how many {ps} German Warbands in {region}?",
                         [(str(k), k) for k in range(n, -1, -1)]) if n else 0)
                selected[region][ps] = count
                budget -= count
        return regions, {"enlist": {"type": "borrow", "regions": regions,
                                     "warbands": selected}}
    german_regions = [r for r in _playable_regions(state, GERMANS)
                      if validate_enlist_region(state, r)[0]
                      and (sub == "german_rally" or count_pieces(state, r, GERMANS, WARBAND))]
    if not german_regions:
        return None, None
    ed = {"type": sub}
    if sub == "german_march":
        origin = prompt_choice(stdin, stdout, "March Germans FROM:",
                               [(r, r) for r in german_regions])
        dests = list(get_adjacent_for_state(state, origin, GERMANS))
        ed["origin"] = origin
        ed["destination"] = prompt_choice(stdin, stdout,
                                          "March Germans TO:",
                                          [(r, r) for r in dests])
        region = origin
    else:
        region = prompt_choice(stdin, stdout, "In which Region?",
                               [(r, r) for r in german_regions])
        ed["region"] = region
    ario = state["scenario"] in ARIOVISTUS_SCENARIOS
    if ario and sub in ("german_battle", "german_march", "german_march_hide"):
        # The human selects the actual counters: visibility matters to Battle,
        # March and hiding, and A4.5.1 affects at most four in total.
        selected, left = {}, 4
        for ps in (HIDDEN, REVEALED, SCOUTED):
            limit = min(left, count_pieces_by_state(state, region, GERMANS, WARBAND, ps))
            n = (prompt_choice(stdin, stdout, f"Use how many {ps} German Warbands?",
                               [(str(k), k) for k in range(limit, -1, -1)])
                 if limit else 0)
            selected[ps] = n
            left -= n
        ed["warbands"] = selected
    elif sub == "german_march":
        n = count_pieces(state, region, GERMANS, WARBAND)
        ed["warbands"] = prompt_choice(stdin, stdout, "March how many German Warbands?",
                                      [(str(k), k) for k in range(n, 0, -1)])
    if sub in ("german_battle", "german_raid"):
        enemies = _enemies_in_region(state, region, GERMANS)
        opts = [(f, f) for f in enemies]
        if sub == "german_raid" and state["scenario"] in ARIOVISTUS_SCENARIOS:
            opts.append(("(just gain 1 Resource)", None))
        if not opts:
            return None, None
        if sub == "german_raid":
            limit = min(2, count_pieces_by_state(state, region, GERMANS, WARBAND, HIDDEN))
            if not limit:
                return None, None
            n = prompt_choice(stdin, stdout, "Raid with how many Hidden German Warbands?",
                              [(str(k), k) for k in range(limit, 0, -1)])
            ed["actions"] = []
            for i in range(n):
                target = prompt_choice(stdin, stdout, f"  Raid {i + 1} target in {region}?", opts)
                ed["actions"].append({"type": "steal", "target": target} if target
                                     else {"type": "gain"})
        else:
            ed["target"] = prompt_choice(stdin, stdout,
                                         f"  Target in {region}?", opts)
    if sub == "german_rally":
        from fs_bot.cli.recruit_rally import collect_enlist_rally
        ed = collect_enlist_rally(state, region, stdin, stdout)
        if ed is None:
            return None, None
    return [region], {"enlist": ed}


def _collect_build(state, faction, stdin, stdout, *, pending=None):
    """Roman Build SA (Sec.4.2.1) -- returns (sa_regions, extra)."""
    from fs_bot.cli.action_windows import available
    if available(state):
        from fs_bot.cli.roman_timing import collect_build
        return collect_build(state, faction, stdin, stdout, pending=pending)
    single = False
    from fs_bot.commands.sa_build import validate_build_region
    from fs_bot.map.map_data import get_tribes_in_region
    from fs_bot.rules_consts import ROMANS, FORT
    cands = [r for r in _regions_with_pieces(state, ROMANS)
             if validate_build_region(state, r)[0]]
    # Sec.4.1: the SA may resolve AFTER the Command — a March's
    # destinations become Build-eligible once the group arrives, so
    # offer them too (the executor validates against the post-March
    # board; the plan preview rejects anything still illegal).
    if pending is not None and pending.get("command") == "March":
        det = pending.get("details") or {}
        dests = list(det.get("destinations") or [])
        for eg in det.get("extra_groups") or []:
            dests.extend(eg.get("route") or [])
        for routes in (det.get("routes") or {}).values():
            dests.extend(routes)
        for d in dests:
            d = d[0] if isinstance(d, (list, tuple)) else d
            from fs_bot.commands.common import check_leader_proximity
            from fs_bot.rules_consts import CAESAR
            if d in _playable_regions(state, faction) and d not in cands and check_leader_proximity(
                    state, d, ROMANS, CAESAR, "Build")[0]:
                cands.append(d)
    if not cands:
        return None, None
    picked = _pick_regions(stdin, stdout, "Build in which Region(s)?",
                           cands, single=single)
    if not picked:
        return None, None
    plan = {"forts": [], "subdue": [], "allies": []}
    for r in picked:
        opts = []
        if count_pieces(state, r, ROMANS, FORT) == 0:
            opts.append(("place a Fort", "fort"))
        enemy_allied = [t for t, ti in state["tribes"].items()
                        if ti.get("allied_faction") not in (None, ROMANS)
                        and _tribe_in_region(state, t, r)]
        if enemy_allied:
            opts.append(("Subdue an enemy Ally", "subdue"))
        subdued = [t for t, ti in state["tribes"].items()
                   if ti.get("allied_faction") is None
                   and ti.get("status") is None
                   and _tribe_in_region(state, t, r)]
        if subdued:
            opts.append(("place a Roman Ally", "ally"))
        if not opts:
            continue
        act = prompt_choice(stdin, stdout, f"  Build action in {r}?", opts)
        if act == "fort":
            plan["forts"].append(r)
        elif act == "subdue":
            t = prompt_choice(stdin, stdout, f"  Subdue which Tribe in {r}?",
                              [(x, x) for x in enemy_allied])
            plan["subdue"].append({"region": r, "tribe": t})
        elif act == "ally":
            t = prompt_choice(stdin, stdout, f"  Ally which Tribe in {r}?",
                              [(x, x) for x in subdued])
            plan["allies"].append({"region": r, "tribe": t})
    if not (plan["forts"] or plan["subdue"] or plan["allies"]):
        return None, None
    return picked, {"build_plan": plan}


def _tribe_in_region(state, tribe, region):
    from fs_bot.rules_consts import TRIBE_TO_REGION
    return TRIBE_TO_REGION.get(tribe) == region


def _collect_scout(state, faction, stdin, stdout, *, pending=None):
    """Roman Scout SA (Sec.4.2.2) -- player moves Auxilia, then Reveals."""
    from fs_bot.cli.action_windows import available
    if available(state):
        from fs_bot.cli.roman_timing import collect_scout
        return collect_scout(state, faction, stdin, stdout, pending=pending)
    from fs_bot.rules_consts import (ROMANS, AUXILIA, WARBAND, HIDDEN,
                                     REVEALED, BRITANNIA, CAESAR, FACTIONS)
    from fs_bot.board.pieces import (count_pieces_by_state,
                                     get_leader_in_region, find_leader)
    moves = []
    sources = [r for r in _regions_with_pieces(state, ROMANS)
               if count_pieces(state, r, ROMANS, AUXILIA) > 0
               and r != BRITANNIA]
    while sources:
        if not prompt_yes_no(stdin, stdout, "Move Auxilia?", default=False):
            break
        src = prompt_choice(stdin, stdout, "Move Auxilia FROM:",
                            [(r, r) for r in sources])
        dests = [d for d in sorted(get_adjacent_for_state(state, src, ROMANS))
                 if d != BRITANNIA]
        dst = prompt_choice(stdin, stdout, "  INTO which Region?",
                            [(d, d) for d in dests])
        avail = count_pieces(state, src, ROMANS, AUXILIA)
        n = prompt_choice(stdin, stdout, f"  How many? (of {avail})",
                          [(str(k), k) for k in range(1, avail + 1)])
        for ps in (REVEALED, HIDDEN):
            c = min(n, count_pieces_by_state(state, src, ROMANS,
                                             AUXILIA, ps))
            if c > 0:
                moves.append({"from_region": src, "to_region": dst,
                              "count": c, "piece_state": ps})
                n -= c
        sources = [r for r in _regions_with_pieces(state, ROMANS)
                   if count_pieces(state, r, ROMANS, AUXILIA) > 0
                   and r != BRITANNIA]
    # Reveal targets -- within 1 of Caesar (same Region as Successor),
    # needs a Hidden Roman Auxilia there (Sec.4.2.2).
    targets = []
    caesar_region = find_leader(state, ROMANS)
    if caesar_region is not None:
        named = get_leader_in_region(state, caesar_region, ROMANS) == CAESAR
        for r in sorted(_regions_with_pieces(state, ROMANS)):
            if count_pieces_by_state(state, r, ROMANS, AUXILIA, HIDDEN) == 0:
                continue
            in_range = (r == caesar_region
                        or (named and is_adjacent(r, caesar_region)))
            if not in_range:
                continue
            for enemy in FACTIONS:
                if enemy == ROMANS:
                    continue
                hid = count_pieces_by_state(state, r, enemy, WARBAND, HIDDEN)
                if hid > 0 and prompt_yes_no(
                        stdin, stdout,
                        f"Reveal {enemy} Warbands in {r}?", default=True):
                    targets.append({"region": r, "enemy": enemy,
                                    "hidden": hid})
    if not moves and not targets:
        return None, None
    regions = sorted({m["from_region"] for m in moves}
                     | {t["region"] for t in targets})
    return regions, {"scout_plan": {"auxilia_moves": moves,
                                    "scout_targets": targets}}


_SA_COLLECTORS = {
    "Build": _collect_build,
    "Scout": _collect_scout,
    "Suborn": _collect_suborn,
    "Entreat": _collect_entreat,
    "Rampage": _collect_rampage,
    "Intimidate": _collect_intimidate,
    "Enlist": _collect_enlist,
}


_COMMAND_COLLECTORS = {
    "Battle": _collect_battle, "Raid": _collect_raid, "March": _collect_march,
    "Rally": _collect_rally, "Recruit": _collect_recruit,
    "Seize": _collect_seize,
}


def _collect_command_plan(state, faction, cmd, stdin, stdout, single=False,
                          *, excluded=()):
    maximum = state.get("_cli_max_regions")
    if maximum is not None:
        state = dict(state, _cli_command_max_regions=max(0, maximum - len(set(excluded))))
        if state["_cli_command_max_regions"] == 0:
            return None
    collector = _COMMAND_COLLECTORS.get(cmd)
    from fs_bot.cli.diviciacus import choose_regions, planning_scope
    cooperation = choose_regions(state, faction, "command", stdin, stdout,
                                 excluded=excluded)
    with planning_scope(state, faction, cooperation, "command"):
        details = (collector(state, faction, stdin, stdout, single, excluded=excluded)
                   if collector else None)
    if details is None:
        return None
    if cooperation is not None:
        details["diviciacus_regions"] = cooperation
    action = {"command": cmd, "regions": [], "sa": _SA_NONE,
              "sa_regions": [], "details": {}}
    if cmd == "Seize":
        action["regions"] = details.pop("_regions", [])
    action["details"] = details
    return action


def _planning_copy(state):
    from fs_bot.cli.action_windows import planning_copy
    return planning_copy(state)


def _preview_command(state, faction, action):
    """Plan later choices on a copy; never spend Resources or RNG on live state."""
    from fs_bot.engine.execute import execute_decision, _execute_bot_command
    from fs_bot.commands.common import is_free_action
    sim = _planning_copy(state)
    if is_free_action(sim, faction):
        _execute_bot_command(sim, faction, action, with_sa=True)
    else:
        execute_decision(sim, faction, {"player_action": action})
    return sim


def _preview_sa(state, faction, action):
    """Resolve an SA on a detached planning board, including authored timing."""
    from fs_bot.engine.action_windows import scope
    from fs_bot.engine.execute import _execute_sa
    with scope(state, actor=faction, plan=action, phase='sequence_of_play'):
        return _execute_sa(state, faction, action)


def _preview_borrow(state, faction, action):
    from fs_bot.commands.sa_enlist import begin_borrow
    from fs_bot.engine.action_windows import scope, window
    with scope(state, actor=faction, plan=action, phase='sequence_of_play'):
        window(state, 'special_ability', author=faction, sa='Enlist',
               timing_actions=((action.get('details') or {}).get('sa_details') or {}).get('timing_actions'))
        begin_borrow(state, action)


def _collect_sa_plan(state, faction, action, stdin, stdout, *, sa=None,
                     standalone=False, before_state=None, allowed_sas=None,
                     allowed_regions=None):
    from fs_bot.engine.action_validation import compatible_sa
    if allowed_regions is not None:
        state = dict(state, _cli_allowed_regions=allowed_regions)
        if before_state is not None:
            before_state = dict(before_state, _cli_allowed_regions=allowed_regions)
    sas = [s for s in _faction_special_abilities(faction, state["scenario"])
           if (action.get("command") is None or compatible_sa(action["command"], s))
           and (not standalone or s not in ("Ambush", "Besiege"))
           and (allowed_sas is None or s in allowed_sas)]
    if not sas:
        return action
    if sa is None:
        sa = prompt_choice(stdin, stdout, "Which Special Activity?",
                           [(s, s) for s in sas])
    if sa in ("Ambush", "Besiege") and before_state is not None:
        # These SAs modify the coming Battle; an unmodified preview must not
        # remove their targets or attackers from the selection menu.
        state = before_state
    from fs_bot.cli.action_windows import prepare, inspect_board
    if sa not in ('Ambush', 'Besiege', 'Enlist'):
        state, timing = prepare(state, faction, stdin, stdout,
                                stage='special_ability', sa=sa)
        if timing:
            action['details'].setdefault('sa_details', {}).setdefault(
                'timing_actions', []).extend(timing)
    from fs_bot.cli.diviciacus import choose_regions, planning_scope
    with inspect_board(state, stdout):
        cooperation = choose_regions(state, faction, "special_ability", stdin, stdout)
        if cooperation is not None:
            action["details"]["diviciacus_sa_regions"] = cooperation
        with planning_scope(state, faction, cooperation, "special_ability"):
            return _collect_sa_details(state, faction, action, stdin, stdout, sa,
                                       before_state)


def _collect_sa_details(state, faction, action, stdin, stdout, sa, before_state):
    if sa == "Trade":
        # Supply declarations and the final board determine legal Regions.
        # Ask at execution, after the preceding Command/SA portion resolves.
        action["sa"] = sa
        action["sa_regions"] = []
        stdout.write("Trade declarations and any River Commerce Region choice follow at resolution.\n")
        return action
    collector = _SA_COLLECTORS.get(sa)
    from fs_bot.cli.action_windows import available
    if sa in ('Settle', 'Devastate') and available(state):
        from fs_bot.cli.sa_timing import collect_scalar
        collector = lambda board, actor, src, out, **kw: collect_scalar(board, actor, sa, src, out)
    if collector is not None:
        kwargs = {"before_state": before_state} if sa == "Enlist" else {}
        sa_regions, extra = collector(state, faction, stdin, stdout,
                                      pending=action, **kwargs)
        if sa_regions is None:
            stdout.write(f"  (no legal {sa} plan -- Command only)\n")
            return action
        action["sa_regions"] = sa_regions
        if extra:
            extra = dict(extra)
            if 'sa_details' in extra:
                action['details'].setdefault('sa_details', {}).update(extra.pop('sa_details'))
            action["details"].update(extra)
    else:
        cand = _regions_with_pieces(state, faction)
        if sa in ("Ambush", "Besiege"):
            from fs_bot.commands.sa_ambush import validate_ambush_region
            from fs_bot.commands.sa_besiege import validate_besiege_region
            battle_plan = (action.get("details") or {}).get("battle_plan")
            targets = ({e["region"]: [e["target"]] for e in battle_plan}
                       if battle_plan else
                       {r: _enemies_in_region(state, r, faction) for r in cand})
            cand = [r for r in cand if any(
                (validate_ambush_region(state, r, faction, enemy)[0]
                 if sa == "Ambush" else validate_besiege_region(state, r, enemy)[0])
                for enemy in targets.get(r, []))]
        if sa == "Devastate":
            from fs_bot.commands.sa_devastate import validate_devastate_region
            cand = [r for r in cand if validate_devastate_region(state, r)[0]]
        if cand:
            action["sa_regions"] = _pick_regions(
                stdin, stdout, f"{sa} in which Region(s)? (optional)",
                cand, at_least_one=False, single=(sa == "Ambush" and faction == AEDUI))
    action["sa"] = sa
    return action


def _collect_command(state, faction, engine_action, stdin, stdout, *,
                     allowed_commands=None, allowed_regions=None, max_regions=None,
                     required_destinations=None, allowed_sas=None):
    from copy import deepcopy
    from fs_bot.engine.action_validation import compatible_sa, command_regions
    from fs_bot.engine.game_engine import is_frost
    from fs_bot.engine.execute import _execute_sa
    from fs_bot.commands.common import is_free_action
    state = dict(state)
    if allowed_regions is not None:
        state["_cli_allowed_regions"] = allowed_regions
    if max_regions is not None:
        state["_cli_max_regions"] = max_regions
    if required_destinations is not None:
        state["_cli_required_destinations"] = required_destinations
    single = engine_action == ACTION_LIMITED_COMMAND
    commands = [c for c in _FACTION_COMMANDS.get(faction, ())
                if (allowed_commands is None or c in allowed_commands)
                and (c != "March" or not is_frost(state) or is_free_action(state, faction))]
    if not commands:
        return None
    available_sas = [s for s in _faction_special_abilities(faction, state["scenario"])
                     if (allowed_sas is None or s in allowed_sas)
                     and any(compatible_sa(c, s) for c in commands)]
    choices = [(c, c) for c in commands]
    if engine_action == ACTION_COMMAND_SA and available_sas:
        choices.append(("Special Activity first, then Command", "sa_first"))
        if any(c not in ("March", "Battle") for c in commands):
            choices.append(("Command, Special Activity, then continue Command", "sa_during"))
        if faction == BELGAE and "Enlist" in available_sas:
            choices.append(("Command first, with borrowed German Warbands", "enlist_command_first"))
        stdout.write("Choose a Command for Command-first timing, or an order below.\n")
    cmd = prompt_choice(stdin, stdout, "Which Command?", choices)
    if cmd == "enlist_command_first":
        cmd = prompt_choice(stdin, stdout, "Which Command?", [(c, c) for c in commands])
        regions, details = _collect_enlist(state, faction, stdin, stdout, borrow_only=True)
        if regions is None:
            return None
        action = {"command": cmd, "regions": [], "sa": "Enlist", "sa_regions": regions,
                  "details": details, "sa_timing": "before"}
        from fs_bot.commands.sa_enlist import begin_borrow
        sim = _planning_copy(state)
        _preview_borrow(sim, faction, action)
        command = _collect_command_plan(sim, faction, cmd, stdin, stdout)
        if command is None:
            return None
        action["regions"] = command["regions"]
        action["details"].update(command["details"])
        return action
    if cmd == "sa_first":
        action = {"command": None, "regions": [], "sa": _SA_NONE,
                  "sa_regions": [], "details": {}, "sa_timing": "before"}
        action = _collect_sa_plan(state, faction, action, stdin, stdout,
                                  allowed_sas=available_sas)
        legal = [c for c in commands if compatible_sa(c, action["sa"])]
        if not legal:
            return None
        cmd = prompt_choice(stdin, stdout, "Which accompanying Command?",
                            [(c, c) for c in legal])
        action["command"] = cmd
        sim = _planning_copy(state)
        from fs_bot.commands.sa_enlist import is_borrow_plan, begin_borrow
        if is_borrow_plan(action):
            _preview_borrow(sim, faction, action)
        else:
            _preview_sa(sim, faction, action)
        command = _collect_command_plan(sim, faction, cmd, stdin, stdout)
        if command is None:
            return None
        action["regions"] = command["regions"]
        action["details"].update(command["details"])
        return action
    if cmd == "sa_during":
        # These Commands resolve independently one selected Region at a time.
        # March groups and Battle-wide capabilities need a shared resolution
        # context; offer their before/after paths rather than reset that context.
        legal = [c for c in commands if c not in ("March", "Battle")]
        cmd = prompt_choice(stdin, stdout, "Which Command to interrupt?",
                            [(c, c) for c in legal])
        from fs_bot.rules_consts import BASE_SCENARIOS
        if cmd == 'Rally' and faction == ARVERNI and state['scenario'] in BASE_SCENARIOS:
            from fs_bot.cli.recruit_rally import collect_interrupted
            return collect_interrupted(state, faction, stdin, stdout,
                                       allowed_sas=available_sas)
        stdout.write("Select the Regions to resolve BEFORE the Special Activity.\n")
        first = _collect_command_plan(state, faction, cmd, stdin, stdout)
        if first is None:
            return None
        sim = _preview_command(state, faction, first)
        action = deepcopy(first)
        action = _collect_sa_plan(sim, faction, action, stdin, stdout,
                                  standalone=True, allowed_sas=available_sas)
        from fs_bot.commands.sa_enlist import is_borrow_plan, begin_borrow
        if is_borrow_plan(action):
            _preview_borrow(sim, faction, action)
        else:
            _preview_sa(sim, faction, action)
        stdout.write("Continue the same Command in additional Regions.\n")
        second = _collect_command_plan(sim, faction, cmd, stdin, stdout,
                                       excluded=command_regions(first))
        if second is None:
            if is_borrow_plan(action):
                # A loan cannot apply retroactively to the already resolved part.
                return first
            action["sa_timing"] = "after"
            return action
        action["sa_timing"] = "during"
        action["details"]["command_parts"] = [first, second]
        return action
    action = _collect_command_plan(state, faction, cmd, stdin, stdout, single)
    if action is None:
        return None
    if engine_action == ACTION_COMMAND_SA and any(
            compatible_sa(cmd, s) for s in available_sas):
        if prompt_yes_no(stdin, stdout, "Add a Special Activity?", default=False):
            sim = _preview_command(state, faction, action)
            action = _collect_sa_plan(sim, faction, action, stdin, stdout,
                                      before_state=state, allowed_sas=available_sas)
            action["sa_timing"] = "after"
            from fs_bot.commands.sa_enlist import is_borrow_plan, begin_borrow
            if is_borrow_plan(action):
                sim = _planning_copy(state)
                _preview_borrow(sim, faction, action)
                stdout.write("Plan the Command with its borrowed German Warbands.\n")
                command = _collect_command_plan(sim, faction, cmd, stdin, stdout)
                if command is None:
                    return None
                action["regions"] = command["regions"]
                action["details"].update(command["details"])
    return action


# --------------------------------------------------------------------- #
# Event parameter collection -- the human analogue of the NP derivers
# (Sec.8.2.3). Keys a card's handler reads from event_params are extracted
# from its source, then prompted with typed pickers; every key may be
# skipped (the executor reports 'not applicable' and the validation loop
# in menus.prompt_action lets the player re-plan).
# --------------------------------------------------------------------- #

def _card_param_keys(state, card_id):
    """Ordered event_params keys the card's handler reads (schema keys)."""
    from fs_bot.cards.param_schema import card_param_schema
    return list(card_param_schema(card_id, state.get("scenario"),
                                  state.get("card_edition")))


def _kind_options(state, kind, spec):
    """(label, value) menu options for a schema kind."""
    from fs_bot.cards.param_schema import kind_values
    from fs_bot.rules_consts import SENATE_UP, SENATE_DOWN
    vals = kind_values(state, kind, spec)
    if kind == "direction":
        return [("Uproar (up)", SENATE_UP), ("Adulation (down)",
                                             SENATE_DOWN)]
    if kind == "count":
        return [(str(v), v) for v in vals]
    if kind == "capability":
        from fs_bot.cards.card_data import get_card
        from fs_bot.cards.capabilities import get_active_capabilities
        active = get_active_capabilities(state)
        return [(f"{card_id}: {get_card(card_id, state['scenario']).title} "
                 f"({active[card_id]})", card_id) for card_id in vals]
    return [((str(v) if v is not None else "(none)"), v) for v in vals]


def _prompt_event_param(state, key, spec, stdin, stdout):
    """Prompt a typed value for one event_params key per its schema spec;
    None to skip the key entirely."""
    kind = spec.get("kind", "value")
    if kind == "omit":
        return None
    skip = ("(skip)", "__skip__")

    def _pick(prompt, opts):
        v = prompt_choice(stdin, stdout, prompt, list(opts) + [skip])
        return None if v == "__skip__" else v

    if kind == "entries":
        fields = spec.get("entry_fields") or {"region": "region"}
        entries = []
        while prompt_yes_no(stdin, stdout,
                            f"Add a {key} entry?", default=not entries):
            e = {}
            for sub, sub_kind in fields.items():
                e[sub] = prompt_choice(
                    stdin, stdout, f"  {sub}:",
                    _kind_options(state, sub_kind, spec))
            entries.append(e)
        # Explicit [] declines Card 44's granted Raid; omission requests
        # its default plan. Keep that choice available in the typed menu.
        return entries if spec.get("allow_empty") else entries or None
    if kind in ("regions", "factions") or kind.startswith("list:"):
        item = kind[5:] if kind.startswith("list:") else kind[:-1]
        out = []
        while True:
            opts = [(label, v) for label, v in
                    _kind_options(state, item, spec) if v not in out]
            if not opts:
                break
            v = _pick(f"{key} (add one):", opts)
            if v is None:
                break
            out.append(v)
        return out or None
    return _pick(f"{key}:", _kind_options(state, kind, spec))


def _collect_timed_event_entries(state, faction, card_id, shaded, params,
                                 key, spec, stdin, stdout):
    """Plan each typed operation against the actual completed Event prefix."""
    from fs_bot.cards.event_preview import preview_event_prefix, EventStepUnavailable
    from fs_bot.cli.action_windows import prepare, planning_copy, inspect_board
    from fs_bot.commands.common import CommandError
    from fs_bot.board.pieces import PieceError
    original, entries = planning_copy(state), []
    step = spec['event_step']
    fields = spec.get('entry_fields') or {'region': 'region'}
    while len(entries) < spec.get('max_entries', float('inf')):
        try:
            stage = preview_event_prefix(original, faction, card_id, shaded,
                dict(params, **{key: entries}), step=step, index=len(entries))
        except EventStepUnavailable:
            break  # The opposite Event side's schema can include this key.
        if not prompt_yes_no(stdin, stdout, f'Add a {key} entry?', default=not entries):
            break
        prepared, actions = prepare(stage, faction, stdin, stdout,
                                     stage='event_step', step=step, index=len(entries))
        while True:
            entry = {}
            with inspect_board(prepared, stdout):
                for sub, sub_kind in fields.items():
                    entry[sub] = prompt_choice(stdin, stdout, f'  {sub}:',
                                              _kind_options(prepared, sub_kind, spec))
            if actions:
                entry['timing_actions'] = actions
            try:
                preview_event_prefix(original, faction, card_id, shaded,
                    dict(params, **{key: entries + [entry]}), step=step, index=len(entries) + 1)
            except EventStepUnavailable:
                # A completed quota can stop the Event before another entry.
                # Keep timing already confirmed at this last boundary without
                # trapping the player in a menu no entry can satisfy.
                if actions:
                    params.setdefault('stage_timing_actions', {})[
                        f'{step}:{len(entries)}'] = actions
                stdout.write('This Event has no further entries at this step.\n')
                return entries if spec.get('allow_empty') else entries or None
            except (CommandError, PieceError, ValueError, TypeError, KeyError) as exc:
                stdout.write(f'This Event entry cannot be applied: {exc}\n')
                continue
            entries.append(entry)
            break
    return entries if spec.get('allow_empty') else entries or None


def _collect_event_params(state, faction, card_id, shaded, stdin, stdout):
    """event_params for a human Event: standard (derived) choices when
    available and accepted, else per-key typed prompts."""
    if card_id == 47:
        from fs_bot.cli.council import collect_params
        return collect_params(state, faction, stdin, stdout)
    if card_id == 21:
        from fs_bot.cards.province import collect_params
        return collect_params(state, shaded, stdin, stdout)
    if card_id == 16:
        from fs_bot.cli.ambacti import collect_params
        return collect_params(state, faction, shaded, stdin, stdout)
    if card_id == 37:
        from fs_bot.cards.boii import collect_params
        return collect_params(state, faction, shaded, stdin, stdout)
    if card_id == "A23":
        from fs_bot.cards.parley import collect_params
        return collect_params(state, stdin, stdout)
    if card_id == "A37":
        from fs_bot.cards.all_gaul_gathers import collect_params
        return collect_params(state, faction, shaded, stdin, stdout)
    if card_id == "A28":
        from fs_bot.cards.admagetobriga import collect_battle_plan
        return collect_battle_plan(state, faction, stdin, stdout)
    if card_id == "A34":
        from fs_bot.cards.divination import collect_beneficiary
        return collect_beneficiary(state, faction, shaded, stdin, stdout)
    from fs_bot.engine.execute import _derive_event_params
    derived = None
    try:
        derived = _derive_event_params(_planning_copy(state), faction, card_id, shaded)
    except Exception:
        derived = None
    if derived:
        stdout.write(f"Standard choices for this Event: {derived}\n")
        if prompt_yes_no(stdin, stdout, "Use them?", default=True):
            return dict(derived)
    from fs_bot.cards.param_schema import card_param_schema
    schema = card_param_schema(card_id, state.get("scenario"),
                               state.get("card_edition"))
    params = {}
    for key, spec in schema.items():
        from fs_bot.cli.action_windows import available
        if spec.get('kind') == 'entries' and spec.get('event_step') and available(state):
            v = _collect_timed_event_entries(state, faction, card_id, shaded,
                                             params, key, spec, stdin, stdout)
        else:
            v = _prompt_event_param(state, key, spec, stdin, stdout)
        if v is not None:
            params[key] = v
    return params


def _maybe_collect_transfer(state, faction, action, stdin, stdout):
    """Offer a Sec.1.5.2 Resource gift riding this Command/Event execution.
    Menu-driven (first option "No") so scripted input declines naturally;
    one grouped gift per action (documented simplification)."""
    from fs_bot.rules_consts import BASE_SCENARIOS
    stock = state["resources"].get(faction, 0)
    if stock <= 0:
        return action
    others = [f for f in FACTIONS
              if f != faction
              and not (state["scenario"] in BASE_SCENARIOS
                       and f == GERMANS)]
    if not others:
        return action
    # Blank means no gift; closed input means the turn is still pending.
    if not prompt_yes_no(stdin, stdout,
                         "Give Resources to another Faction with this "
                         "action (Sec.1.5.2)?", default=False):
        return action
    to = prompt_choice(stdin, stdout, "Give Resources to whom?",
                       [(f, f) for f in others])
    amt = prompt_choice(stdin, stdout, f"Give how many to {to}?",
                        [(str(n), n) for n in range(1, min(stock, 12) + 1)])
    action.setdefault("details", {})["transfers"] = [{"to": to, "amount": amt}]
    return action


def _collect_player_action(state, faction, engine_action, stdin, stdout):
    """Collect a human's full plan for a chosen action TYPE.

    Returns a ``player_action`` dict (bot-action shape) for a Command or Event,
    or None for Pass / when the player has no legal concrete action (the caller
    then treats it as a Pass-equivalent no-op).
    """
    if engine_action == ACTION_PASS:
        return None
    if engine_action == ACTION_EVENT:
        card_id = state.get("current_card")
        side = prompt_choice(
            stdin, stdout, "Play which side of the Event?",
            [("Unshaded  (the FIRST text on the card)", EVENT_UNSHADED),
             ("Shaded    (the SECOND text, after CAPABILITY if shown)",
              EVENT_SHADED)])
        details = {"card_id": card_id, "text_preference": side}
        params = _collect_event_params(
            state, faction, card_id, side == EVENT_SHADED, stdin, stdout)
        if params:
            details["event_params"] = params
        return _maybe_collect_transfer(
            state, faction,
            {"command": "Event", "regions": [], "sa": _SA_NONE,
             "sa_regions": [], "details": details}, stdin, stdout)
    if engine_action in (ACTION_COMMAND, ACTION_COMMAND_SA,
                         ACTION_LIMITED_COMMAND):
        action = _collect_command(state, faction, engine_action, stdin,
                                  stdout)
        if action is not None:
            action = _maybe_collect_transfer(state, faction, action,
                                             stdin, stdout)
        return action
    return None


def collect_player_action(state, faction, engine_action, stdin, stdout):
    """Prepare action-start timing before deriving the human's legal plan."""
    if engine_action == ACTION_PASS:
        return None
    from fs_bot.cli.action_windows import available, prepare, inspect_board
    if not available(state):
        return _collect_player_action(state, faction, engine_action, stdin, stdout)
    sim, timing = prepare(state, faction, stdin, stdout, stage='action_start')
    with inspect_board(sim, stdout):
        action = _collect_player_action(sim, faction, engine_action, stdin, stdout)
    if action is not None and timing:
        action.setdefault('details', {})['timing_actions'] = timing
    return action
