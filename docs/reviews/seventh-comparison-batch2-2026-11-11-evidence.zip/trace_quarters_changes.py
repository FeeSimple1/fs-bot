"""Replay paired games and locate their first different card and Quarters phase."""

from concurrent.futures import ProcessPoolExecutor
from contextlib import ExitStack, redirect_stdout
from functools import wraps
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import sys
from unittest.mock import patch

from fs_bot.cli.dispatcher import make_decision_func
from fs_bot.engine import winter
from fs_bot.engine.game_engine import get_sop_factions, play_card, start_game
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.tools.validation_metadata import source_identity


def digest(value):
    return sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def board_digest(state):
    return digest({key: value for key, value in state.items() if key != 'decision_agent'})


def key(row):
    return row['scenario'], row['seed'], row['card_edition']


def trace(task):
    row, parent = task
    scenario, seed, edition = key(row)
    state = setup_scenario(scenario, seed=seed, card_edition=edition)
    state['non_player_factions'] = set(get_sop_factions(state))
    bot = make_decision_func({}, stdin=StringIO(), stdout=StringIO(), pause=False)
    cards, quarters, ties = [], [], []
    run_quarters = winter.quarters_phase

    @wraps(run_quarters)
    def watch_quarters(board, *args, **kwargs):
        if board is not state:
            return run_quarters(board, *args, **kwargs)
        before = board_digest(board)
        rng_before = digest(board['rng'].getstate())
        ties.clear()
        result = run_quarters(board, *args, **kwargs)
        quarters.append(dict(before=before, rng_before=rng_before,
                             after=board_digest(board), rng_after=digest(board['rng'].getstate()),
                             ties=list(ties), result=encode(result)))
        return result

    with ExitStack() as stack:
        stack.enter_context(redirect_stdout(StringIO()))
        stack.enter_context(patch.object(winter, 'quarters_phase', watch_quarters))
        if parent is not None:
            from fs_bot.bots import quarters as bot_quarters
            select = bot_quarters.random_select

            @wraps(select)
            def watch_tie(board, choices):
                chosen = select(board, choices)
                if board is state and len(choices) > 1:
                    ties.append(encode(dict(choices=choices, chosen=chosen)))
                return chosen

            stack.enter_context(patch.object(bot_quarters, 'random_select', watch_tie))
        start_game(state)
        for draw in range(1, 201):
            quarters.clear()
            before = board_digest(state)
            rng_before = digest(state['rng'].getstate())
            result = play_card(state, bot, execute=True)
            card = dict(draw=draw, card=result['card'], before=before, rng_before=rng_before,
                        after=board_digest(state), quarters=list(quarters))
            if parent is not None:
                prior = parent['cards'][draw - 1]
                assert (prior['card'], prior['before'], prior['rng_before']) == (
                    card['card'], before, rng_before)
                if prior['after'] != card['after']:
                    return dict(scenario=scenario, seed=seed, card_edition=edition,
                                prior_winner=parent['winner'], current_winner=row['winner'],
                                draw=draw, card=card['card'], prior=prior, current=card)
            else:
                cards.append(card)
            if result['game_over']:
                break
    assert parent is None, f'No first changed card for {key(row)}'
    assert (result['winner'], draw, card['after']) == (
        row['winner'], row['cards'], row['final_state_sha256'])
    return dict(scenario=scenario, seed=seed, card_edition=edition, winner=row['winner'], cards=cards)


def main(inputs, output, parent_file=None):
    rows = json.loads(Path(inputs).read_text())
    parents = {} if not parent_file else {key(row): row for row in
        json.loads(Path(parent_file).read_text())['games']}
    assert not parent_file or parents.keys() == {key(row) for row in rows}
    with ProcessPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(trace, ((row, parents.get(key(row))) for row in rows)))
    Path(output).write_text(json.dumps(dict(source=source_identity(), games=results), indent=2) + '\n')
    print(f'{len(results)} games traced')


if __name__ == '__main__':
    main(*sys.argv[1:])
