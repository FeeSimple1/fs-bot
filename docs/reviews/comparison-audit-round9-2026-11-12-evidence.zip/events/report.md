# Ninth comparison audit — Event lane

**Audited commit:** `f4c8372c396981c0a31dc6f4545e67f8c6f2e981`. No production changes.

Read complete reference inventory, all prior comparison ledgers, human-choice inventory/status, relevant Event sources/handlers/derivers and thirteen rulings. Comparator lessons are engineering-only: integrate producers and consumers, inspect handlers against source, exercise actual public paths. No external game authorities used.

Three confirmed groups: one high, two medium. The script asserts existing defects and controls; both hash-seed outputs match. All pre/post inventory and structural checks are empty, including the illegal A40 stack (these validators do not enforce that stacking restriction).

## EV9-01 — Alpine Tribes non-player placement never selects higher-priority own Allies

**Priority:** medium.

**Expected:** On the controlled Ariovistus board, either Romans or Aedui should place three own Allies in three eligible Regions. Chapter 8 gives own Allies priority over other mobile pieces. With no own mobile counters Available, those same three Allied Tribe placements remain possible.

**Observed:** Unmodified dispatch selects A40 unshaded. Romans place six Auxilia; Aedui place nine Warbands; neither places any Ally. When their respective mobile pools are empty, both select and successfully execute the entire Event without any game effect, despite three legal own Ally placements. An explicit source-required Ally plan on the same public executor places three Allies with no errors.

**Cause:** _derive_card_A40 chooses one mobile piece type from faction identity, iterates near Cisalpina, and returns no plan when that pool is empty. It contains no Ally branch. Public NPC execution uses that derived plan.

**Controls:** Same board, explicit three-Allies plan at Nori/Ubii/Sequani places three own Allies for both factions, including empty-mobile pools. With all nearby Tribes already Allied to Germans, Aedui instead legally place nine Warbands, demonstrating that mobile placement is a valid lower-priority fallback.

**Prior Distinction:** Round-two coverage A40/unshaded was only supported-limited-witness for zero and three-Region mixed category limits; EXP-08 fixed shaded A40 optional quantities. BE7-01 repaired Oppida dependent Citadel placements. None covers A40 NPC omission of the Ally category. This is separate from EV9-03 stacking validation.

**Fixture:** build_initial_state Ariovistus seed1, permanent Provincia Fort, ten Resources per seated faction, four NPC seats, current Event A40; no other Forces. Empty-mobile cases place the entire own mobile pool at Carnutes through place_piece. Three-Allies controls use public execute_decision with authored parameters only.

**Repair Scope:** Derive legal own Allied Tribe choices first under §§8.2.3/8.3.1, respecting one category per Region, three-Region maximum, available counters, ordinary Tribe stacking, live map restrictions and seeded tie selection. Use own mobile fallback only after Ally opportunities are exhausted. Preserve optional human quantity/category choices and shaded behavior.

**Limits:** Constructed lawful positions, not sampled encounter rates. Confirmed for Romans and Aedui unshaded A40; no claim about German/Belgic shaded instructions or full priority coverage of all Events.

**Sources:** `Reference Documents/Ariovistus/A Card Reference:196-205`; `Reference Documents/Chapter 8:120-157`.

**Implementation:** `fs_bot/engine/execute.py:6382-6410`; `fs_bot/engine/execute.py:3456-3467`; `fs_bot/cards/card_effects.py:3250-3285`.

**Evidence:** `probe_events.py:alpine_allies`; `probe_events-output.json:alpine_allies`.

## EV9-02 — Romans select Lost Eagle without its Fallen Legion or qualifying destination

**Priority:** medium.

**Expected:** Unshaded numeric33 is ineffective unless a Fallen Legion exists and a playable Region contains both a Roman Legion and a non-Aedui Warband. Romans must continue their flowchart when either prerequisite is absent.

**Observed:** Roman public dispatch selects Lost Eagle and the public executor reports executed=true while board, pieces, resources, Senate and eligibility remain unchanged. Directed Great Revolt/Reconquest cases isolate zero Fallen, no qualifying Warband, and only an Aedui Warband beside a Legion. An untouched Pax physical setup with current Event33 independently produces the zero-Fallen no-op. With the Event disabled, directed boards have a non-Pass Recruit continuation.

**Cause:** The generic PLACES_LEGIONS effectiveness flag accepts any Legion on the track or in Fallen. Numeric33 has no specialized np_event_available branch. The handler correctly refuses placement when Fallen or destination is absent, so the missing preselection check consumes the bot Event opportunity.

**Controls:** Add only the missing Fallen Legion (via place_piece from track then remove_piece to Fallen) or non-Aedui Warband. On every paired control, the same dispatch/execution now places exactly one Fallen Legion at Sequani. Aedui-only Warbands explicitly do not meet the printed target requirement. Numeric33 is excluded from expansion cases because A33 replaces it.

**Prior Distinction:** WS3-02 concerned shaded Lost Eagle Senate suppression and expiry; it did not inspect unshaded selection. EV8-02 concerned shaded Pompey/Gallia Togata conditional removals. This is a new source-pool/Region prerequisite consumer, with no reopened shaded-lifetime issue.

**Fixture:** Sparse canonical Great Revolt and Reconquest seed1, permanent Provincia Fort, one Legion and two Auxilia at Sequani, optional single Arverni or Aedui Warband and zero/one Fallen. The screen prevents an enemy threat branch preceding Event. All physical preparation uses canonical helpers. Separate untouched Pax setup changes only current card/can-play/NPC metadata.

**Repair Scope:** Share a current-state unshaded33 applicability predicate requiring actual Fallen supply plus legal target geometry with NPC Event selection. Preserve human partial/no-effect execution policy, shaded Senate effect, allowed non-Aedui factions, and seeded target choices where applicable.

**Limits:** Base scenarios only. The unchanged physical Pax setup is not a natural drawn-card game trace. No rate or balance inference. Early exploratory numeric33 expansion-current states were rejected from final evidence because the card is replaced in those decks.

**Sources:** `Reference Documents/Card Reference:327-336`; `Reference Documents/Chapter 8:30-37`; `Reference Documents/roman_bot_event_instructions.txt:10-12`.

**Implementation:** `fs_bot/cards/event_eval.py:335-339`; `fs_bot/cards/event_eval.py:1127-1133`; `fs_bot/cards/event_conditions.py:119-125`; `fs_bot/cards/card_effects.py:1402-1433`.

**Evidence:** `probe_events.py:lost_eagle`; `probe_events-output.json:lost_eagle`.

## EV9-03 — Alpine Tribes places non-Romans in Cisalpina after Gallia Togata forbids them

**Priority:** high.

**Expected:** After actual unshaded A5 activation, Cisalpina permits only Roman pieces. A40 may place non-Romans in other legal nearby Regions, but supplies no explicit stacking exception. The Aedui bot must filter Cisalpina out, and the live handler must not place an authored non-Roman cohort there.

**Observed:** Public A5 activation places its marker and three Roman Auxilia. The subsequent ordinary Aedui A40 bot Event places three Aedui Warbands into Cisalpina, although is_region_playable(state,Cisalpina,Aedui) is false. A separate public authored A40 with only that forbidden placement also succeeds. Both preserve physical census and structural invariants, showing why those checks alone miss the rule violation.

**Cause:** A40 derivation queries static scenario/capability geography without recipient faction or Gallia Togata regional marker. Its handler checks only static adjacency to Cisalpina and then calls the physical placement helper. Neither consumer checks the active Roman-only stacking restriction.

**Controls:** The same authored Aedui placement succeeds before A5, when Cisalpina is legally playable. After A5, three Aedui Warbands in each of Ubii/Sequani/Provincia remain legal; a Roman two-Auxilia placement in Cisalpina also remains legal and increases its three existing Auxilia to five.

**Prior Distinction:** BE5-02 covered Colony creation in forbidden geography; BE5-03 covered Forced Marches recognizing legal Cisalpina. This is the distinct A40 placement producer and live handler bypassing active faction stacking. EV9-01 covers NPC piece-category preference, not location legality; the authored consumer proves the independence.

**Fixture:** build_initial_state Ariovistus seed1 with permanent Provincia Fort, current A5, four NPC seats and ten Resources. Invoke real public A5 unshaded execution, set current Event A40, then invoke unmodified Aedui dispatch plus public execution. No marker is manually assigned.

**Repair Scope:** Use recipient-aware live geography and stacking for A40 candidate generation and every placement category in the live handler; preserve legitimate Roman Cisalpina placement, nearby non-Roman placements, category/Region caps, optional quantities and event transaction behavior. The geography check must read active Event markers rather than only capability IDs.

**Limits:** Confirmed in Ariovistus after a real A5 activation. No Interlude or base-game A40 reachability claim. Chapter5 §5.1.1 expressly requires Event text to change stacking; A40 geographic range alone is not such an override under §5.1.2.

**Sources:** `Reference Documents/Ariovistus/A Card Reference:9-13`; `Reference Documents/Ariovistus/A Card Reference:196-205`; `Reference Documents/Chapter 5:25-36`.

**Implementation:** `fs_bot/engine/execute.py:6390-6407`; `fs_bot/cards/card_effects.py:3244-3285`; `fs_bot/map/map_data.py:390-403`.

**Evidence:** `probe_events.py:alpine_stacking`; `probe_events-output.json:alpine_stacking`.

## Reproduction

From the audited repository root:

```sh
PYTHONHASHSEED=0 PYTHONPATH=. .venv/bin/python /path/to/events/probe_events.py
PYTHONHASHSEED=987 PYTHONPATH=. .venv/bin/python /path/to/events/probe_events.py
```

These are directed source witnesses, not encounter-frequency estimates. The parent validation lane handles full-suite and game checks. No game rules, protected sources, provisional rulings, or production files changed.

## Exclusions

- Cicero-at-Firm source-tip/ordinary-shift distinction: no new conclusion or ruling; outside confirmed findings.
- Known Circumvallation persistence and pending source questions were not recounted.
- Early numeric33 expansion fixtures were excluded as unavailable card identities.
