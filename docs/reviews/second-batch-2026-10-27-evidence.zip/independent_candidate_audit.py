"""Independent, read-only audit of the proposed balance data replacement."""
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
repo = root.parent / "fs-bot"
run = root / "attempt1"
expected_digest = "6a104c1fd391446cd9485aa20adc3c94862923e4fa624e5d48c68a99dd475b64"
scenarios = ("Pax Gallica?", "Reconquest of Gaul", "The Great Revolt", "Ariovistus", "The Gallic War")
factions = {"Romans", "Arverni", "Aedui", "Belgae", "Germans"}
failures = []


def check(condition, description):
    if not condition:
        failures.append(description)


def read(name):
    return json.loads((run / name).read_text())


source = read("source.json")
candidate_bytes = (run / "balance-candidate.json").read_bytes()
candidate = json.loads(candidate_bytes)
prior_bytes = (run / "balance-baseline.json").read_bytes()
prior = json.loads(prior_bytes)
committed_bytes = subprocess.check_output(["git", "show", "HEAD:fs_bot/tools/balance_baseline.json"], cwd=repo)
check(prior_bytes == committed_bytes == (repo / "fs_bot/tools/balance_baseline.json").read_bytes(),
      "Repository or archived baseline differs from committed HEAD baseline")
check(set(candidate) == {"games"}, "Unexpected candidate top-level keys")
expected_keys = {f"{s}|{n}" for s in scenarios for n in range(1, 21)}
check(set(candidate["games"]) == set(prior["games"]) == expected_keys, "Candidate or baseline key coverage differs from five scenarios x seeds 1-20")
rows = [json.loads(line) for line in (run / "bots-legacy/games.jsonl").read_text().splitlines()]
keys = [f"{r['scenario']}|{r['seed']}" for r in rows]
check(len(keys) == len(set(keys)) == 100 and set(keys) == expected_keys, "Audited legacy record coverage differs from exact matrix")
for key, row in zip(keys, rows):
    check(set(candidate["games"][key]) == {"winner", "cards"}, f"{key}: candidate has fields other than winner/cards")
    check(candidate["games"][key] == {"winner": row["winner"], "cards": row["cards"]}, f"{key}: candidate differs from audited record")
    check(all(row.get(k) is True for k in ("completed", "game_completed", "audit_completed")), f"{key}: incomplete audit/game")
    check(not row.get("error") and row.get("errors") == [] and row.get("integrity_findings") == [], f"{key}: errors or integrity findings")
    check(row.get("card_edition") == "legacy" and row.get("source_sha256") == expected_digest and row.get("commit") == source["commit"], f"{key}: edition/source mismatch")
    for field in ("diagnostics", "diagnostic_occurrences"):
        check(isinstance(row.get(field), list) and all(d.get("severity") == "legal-decline" for d in row[field]), f"{key}: nonlegal/missing {field}")
    ending = row.get("ending_scenario")
    eligible = factions - ({"Arverni"} if ending in ("Ariovistus", "The Gallic War") else {"Germans"})
    ranking = row.get("final_ranking", [])
    check(ending in scenarios and len(ranking) == 4 and {r[0] for r in ranking} == eligible, f"{key}: invalid ending or faction ranking")
    check(all(len(r) == 2 and type(r[1]) is int for r in ranking), f"{key}: malformed ranking")
    check(ranking == row.get("engine_final_ranking"), f"{key}: emitted ranking disagreement")
    check([r[1] for r in ranking] == sorted([r[1] for r in ranking], reverse=True), f"{key}: margins out of order")
    check(row.get("winner") == row.get("highest_margin_leader") == ranking[0][0], f"{key}: winner disagrees with ranking")
    check(row.get("winner_differs_from_highest_margin") is False and row.get("engine_ranking_output_missing") is False, f"{key}: ranking audit flag")
    check(row.get("threshold_qualifiers") == [f for f, margin in ranking if margin > 0], f"{key}: threshold qualifiers disagreement")
    check(bool(re.fullmatch("[0-9a-f]{64}", row.get("final_state_sha256", ""))), f"{key}: final state digest missing")

changes = {name: sum(predicate(prior["games"][k], candidate["games"][k]) for k in expected_keys)
           for name, predicate in {"records": lambda a, b: a != b,
                                   "winners": lambda a, b: a["winner"] != b["winner"],
                                   "card_counts": lambda a, b: a["cards"] != b["cards"]}.items()}
check(changes == {"records": 35, "winners": 28, "card_counts": 23}, "Change totals differ from expected counts")
old_roman = sum(prior["games"][f"The Gallic War|{n}"]["winner"] == "Romans" for n in range(1, 21))
new_roman = sum(candidate["games"][f"The Gallic War|{n}"]["winner"] == "Romans" for n in range(1, 21))
drift = Fraction(new_roman - old_roman, 20)
check(old_roman == 12 and new_roman == 8 and drift == Fraction(-1, 5), "Original Roman drift differs from -20 percentage points")
check(abs(drift) > Fraction(3, 20), "Original guardrail unexpectedly passes")
check('ap.add_argument("--band", type=float, default=0.15)' in (repo / "fs_bot/tools/balance_smoke.py").read_text(), "Balance tool tolerance differs from 15 points")
freeze = read("freeze.json")
check(freeze["balance_band_exact"] == "3/20" and freeze["balance_baseline_updated"] is False, "Frozen balance policy changed")
hasher = hashlib.sha256()
for path in sorted((repo / "fs_bot").rglob("*.py")):
    hasher.update(str(path.relative_to(repo)).encode() + b"\0" + path.read_bytes())
check(hasher.hexdigest() == source["source_sha256"] == expected_digest, "Frozen Python source digest mismatch")
test_status = read("tests.status.json")
check(test_status["exit_code"] == 0 and test_status["source"]["source_sha256"] == test_status["source_after"]["source_sha256"] == expected_digest, "Full suite exit or source mismatch")
suites = ET.parse(run / "tests.xml").getroot().findall(".//testsuite")
test_counts = {k: sum(int(s.attrib[k]) for s in suites) for k in ("tests", "errors", "failures", "skipped")}
check(test_counts == {"tests": 4921, "errors": 0, "failures": 0, "skipped": 0}, "JUnit suite counts mismatch")
results = read("results.json")
check(results["passed"] is False and results["balance"]["passed"] is False
      and results["failures"] == ["balance/The Gallic War/Romans: drift -1/5 exceeds unchanged 3/20 band"],
      "Original failed guardrail report was lost or altered")
report = {"candidate_data_audit_passed": not failures, "failures": failures,
          "scope": "Candidate data integrity only; no causal rule-mechanism approval or baseline replacement authorization.",
          "source_sha256": expected_digest, "legacy_records_checked": len(rows), "candidate_keys": len(expected_keys),
          "candidate_sha256": hashlib.sha256(candidate_bytes).hexdigest(),
          "old_baseline_sha256": hashlib.sha256(prior_bytes).hexdigest(),
          "repository_baseline_unchanged": prior_bytes == (repo / "fs_bot/tools/balance_baseline.json").read_bytes(),
          "changes": changes, "original_balance_passed": False,
          "gallic_war_romans": {"old_wins": old_roman, "candidate_wins": new_roman,
                                "sample": 20, "exact_drift": str(drift), "percentage_point_drift": float(100 * drift)},
          "band_percentage_points": 15, "pytest": dict(test_counts, exit_code=test_status["exit_code"]),
          "new_games_executed": 0}
with (run / "independent-candidate-review.json").open("x") as stream:
    json.dump(report, stream, indent=2, sort_keys=True)
    stream.write("\n")
print(json.dumps(report, indent=2))
raise SystemExit(1 if failures else 0)
