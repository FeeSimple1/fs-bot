import copy,json,sys
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from fs_bot import rules_consts as r
from fs_bot.state.state_schema import build_initial_state,validate_state,check_structural_integrity
from fs_bot.board.pieces import place_piece,count_pieces
from fs_bot.engine.execute import execute_decision
from fs_bot.engine import game_engine as ge

def state():
 s=build_initial_state(r.SCENARIO_GREAT_REVOLT,seed=1)
 place_piece(s,r.PROVINCIA,r.ROMANS,r.FORT)
 s.update(current_card=52,current_card_id=52,non_player_factions=set())
 place_piece(s,r.CARNUTES,r.ROMANS,r.AUXILIA)
 place_piece(s,r.PROVINCIA,r.ROMANS,r.AUXILIA,4)
 place_piece(s,r.PROVINCIA,r.ROMANS,r.LEADER,leader_name=r.CAESAR)
 assert validate_state(s)==check_structural_integrity(s)==[]
 return s

def plan(sa):
 details={'recruit_plan':[{'region':r.PROVINCIA,'action':'place_auxilia','count':1}]}
 if sa==r.SA_SCOUT:details['scout_plan']={'auxilia_moves':[{'from_region':r.PROVINCIA,'to_region':r.SEQUANI,'count':1,'piece_state':r.HIDDEN}],'scout_targets':[]}
 else:details['build_plan']={'allies':[{'region':r.PROVINCIA,'tribe':r.TRIBE_HELVII}]}
 return {'command':r.CMD_RECRUIT,'regions':[r.PROVINCIA],'sa':sa,'sa_timing':'after','details':details}

records=[]
for first,second in [(r.SA_SCOUT,r.SA_BUILD),(r.SA_BUILD,r.SA_SCOUT)]:
 s=state();requests=[]
 def agent(st,f,request):
  if request['kind']!='free_action':return None
  requests.append(copy.deepcopy(request))
  # Second would be supplied if requested; the Event returns after first.
  return plan(first) if len(requests)==1 else plan(second)
 s['decision_agent']=agent
 result=execute_decision(s,r.ROMANS,{'action':ge.ACTION_EVENT,'player_action':{'command':'Event','sa':'No SA','details':{'card_id':52,'text_preference':r.EVENT_SHADED}}})
 assert result['executed'],result
 assert len(requests)==1,requests
 assert validate_state(s)==check_structural_integrity(s)==[]
 row={'first_sa':first,'second_sa_ready':second,'requests':requests,'result':result,'auxilia_provincia':count_pieces(s,r.PROVINCIA,r.ROMANS,r.AUXILIA),'auxilia_sequani':count_pieces(s,r.SEQUANI,r.ROMANS,r.AUXILIA),'helvii_ally':s['tribes'][r.TRIBE_HELVII]['allied_faction'],'fort_provincia':count_pieces(s,r.PROVINCIA,r.ROMANS,r.FORT)}
 if first==r.SA_SCOUT:assert row['auxilia_sequani']==1 and row['helvii_ally'] is None
 else:assert row['helvii_ally']==r.ROMANS and row['auxilia_sequani']==0
 records.append(row)
out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True);(out/'observations.json').write_text(json.dumps(records,indent=2,default=str));print(json.dumps(records,indent=2,default=str))
