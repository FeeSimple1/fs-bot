"""Verify the tenth-audit Batch 1 tests, game pairs and first Event changes."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
from xml.etree import ElementTree

from fs_bot import rules_consts as rc
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


ROOT = Path(__file__).resolve().parent
REPO = Path(__import__('fs_bot').__file__).resolve().parent.parent
PARENT = '62cb21484da257600c6ebddc04d2e531d545965e'
PARENT_DIGEST = '39076dca68ec449cf766e40256c765d2d36693c50989a2b0552745f208f94d45'
BALANCE_ROW = re.compile(r'^\[(.+) seed= *(\d+)\] winner=(.+) \((\d+) cards\)$', re.M)


def load(path):
    return json.loads((ROOT / path).read_bytes())


def check_tests():
    reports = {'parent-directed': (23, 18), 'directed': (23, 0),
               'focused': (366, 0), 'full': (10302, 0)}
    result = {}
    for name, (tests, failures) in reports.items():
        suite, = ElementTree.parse(ROOT / f'{name}.xml').iter('testsuite')
        counts = {'tests': tests, 'failures': failures, 'errors': 0, 'skipped': 0}
        assert all(int(suite.get(key)) == value for key, value in counts.items()), name
        result[name] = dict(counts, passed=tests - failures, seconds=float(suite.get('time')))
    return result


def read_games(folder, edition, seeds, digest):
    metadata = load(f'{folder}/metadata.json')
    assert metadata['source_sha256'] == digest
    assert metadata['card_edition'] == edition and metadata['hash_seed'] == 0
    assert metadata['seeds'] == list(seeds)
    rows = [json.loads(line) for line in (ROOT / folder / 'games.jsonl').read_text().splitlines()]
    games = {(row['scenario'], row['seed']): row for row in rows}
    assert len(rows) == len(games) == 5 * len(seeds)
    assert set(games) == {(scenario, seed) for scenario in SCENARIOS for seed in seeds}
    for row in rows:
        assert row['source_sha256'] == digest and row['card_edition'] == edition
        assert row['completed'] and row['game_completed'] and row['audit_completed']
        assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row)
        assert len(row['final_state_sha256']) == 64
        assert all(d['severity'] == 'legal-decline' for d in row['diagnostic_occurrences'])
    return games


def compare_games(parent, repair):
    assert parent.keys() == repair.keys()
    changed = sorted(key for key in parent
                     if parent[key]['final_state_sha256'] != repair[key]['final_state_sha256'])
    return {
        'games': len(repair), 'interludes': sum(r['interlude_completed'] for r in repair.values()),
        'diagnostic_occurrences': sum(len(r['diagnostic_occurrences']) for r in repair.values()),
        'changed_final_states': len(changed), 'changed_games': changed,
        'changed_winners': sum(parent[key]['winner'] != repair[key]['winner'] for key in parent),
        'changed_card_counts': sum(parent[key]['cards'] != repair[key]['cards'] for key in parent),
    }


def event_action(row, faction):
    return next((e for e in row['events'] if e['faction'] == faction), None)


def first_changes(parent, repair, expected, digest):
    original = load('trace-legacy-parent-event.json')
    corrected = load('trace-legacy-repair-event.json')
    assert original['source'] == {'commit': PARENT, 'dirty': False, 'source_sha256': PARENT_DIGEST}
    assert corrected['source']['commit'] == PARENT and corrected['source']['source_sha256'] == digest
    cases = []
    for before, after in zip(original['games'], corrected['games']):
        assert before['task'] == after['task']
        scenario, seed, edition = before['task']
        assert edition == 'legacy'
        key = (scenario, seed)
        for game, batch in ((before, parent), (after, repair)):
            assert game['outcome'] == {k: batch[key][k] for k in game['outcome']}
        for old, new in zip(before['cards'], after['cards']):
            assert old['before'] == new['before'] and old['card'] == new['card']
            if old['after'] != new['after']:
                break
        else:
            raise AssertionError((key, 'no changed card'))
        assert old['atrebates_before'] == new['atrebates_before']
        card = old['card']
        tribes = old['atrebates_before']['tribes']
        if card == 'A69':
            ev = event_action(old, rc.BELGAE)
            assert ev and ev['result']['shaded'] and ev['before'] == ev['after']
            assert event_action(new, rc.BELGAE) is None
            assert tribes[rc.TRIBE_BELLOVACI]['allied_faction'] != rc.BELGAE
            reason = 'Bellovaci is not a Belgic Ally'
        elif card == 'A51':
            ev = event_action(old, rc.AEDUI)
            placed = event_action(new, rc.AEDUI)
            assert ev and ev['result']['executed'] and not ev['result']['shaded']
            if placed is None:
                assert tribes[rc.TRIBE_REMI]['allied_faction'] == rc.BELGAE
                assert ev['before'] == ev['after']
                reason = 'Remi is a Belgic Ally'
            else:
                assert ev['before'] == placed['before']
                old_pieces = ev['before']['pieces']
                old_after = ev['after']['pieces']
                new_after = placed['after']['pieces']
                auxilia = f'{rc.ROMANS}/{rc.AUXILIA}'
                warband = f'{rc.AEDUI}/{rc.WARBAND}'
                fort = f'{rc.ROMANS}/{rc.FORT}'
                assert old_after[auxilia] == old_pieces[auxilia] + 4
                assert new_after[auxilia] == old_pieces[auxilia]
                assert new_after[warband] == old_pieces[warband] + min(4, ev['before']['available'][warband])
                assert old_after[fort] == new_after[fort]
                reason = 'Bibrax places Aedui Warbands'
        else:
            raise AssertionError((key, card))
        cases.append({'scenario': scenario, 'seed': seed, 'card': card,
                      'first_changed_card': old['ordinal'], 'reason': reason})
    assert sorted((r['scenario'], r['seed']) for r in cases) == expected
    return cases


def check_balance(parent, repair):
    log = (ROOT / 'balance.log').read_text()
    assert 'OK: balance within band (6 winner changes)' in log
    smoke = {(s, int(k)): {'winner': f, 'cards': int(n)} for s, k, f, n in BALANCE_ROW.findall(log)}
    assert len(smoke) == 100
    assert smoke == {key: {field: row[field] for field in ('winner', 'cards')}
                     for key, row in repair.items()}
    baseline = json.loads((REPO / 'fs_bot/tools/balance_baseline.json').read_text())['games']
    assert baseline == {f'{s}|{k}': {field: row[field] for field in ('winner', 'cards')}
                        for (s, k), row in parent.items()}
    scenario_wins = {}
    for scenario in SCENARIOS:
        counts = [Counter(row['winner'] for (s, _), row in records.items() if s == scenario)
                  for records in (parent, repair)]
        drift = max(abs(counts[0][f] - counts[1][f]) for f in rc.FACTIONS) * 5
        scenario_wins[scenario] = {'old_wins': counts[0], 'new_wins': counts[1], 'drift_points': drift}
    largest = max(r['drift_points'] for r in scenario_wins.values())
    assert largest == 10
    return {'games': 100, 'largest_shift_points': largest, 'band_points': 15,
            'winner_and_card_counts_agree': True, 'scenario_wins': scenario_wins}


def check_mixed(digest):
    for ext in ('json', 'log'):
        assert (ROOT / f'fuzz0.{ext}').read_bytes() == (ROOT / f'fuzz987.{ext}').read_bytes()
    current = load('fuzz0.json')
    prior = load('parent-fuzz0.json')
    assert prior['metadata']['source_sha256'] == PARENT_DIGEST
    assert current['metadata']['source_sha256'] == digest
    assert all(current['metadata'][key] for key in ('replay', 'events', 'reactive'))
    assert current['metadata']['card_edition'] == 'second-edition'
    assert current['metadata']['seeds'] == list(range(53, 57))
    assert current['records'] == prior['records']
    assert current['games'] == len(current['records']) == 20 and current['hard_findings'] == 0
    assert all(r['game_completed'] and not r['findings'] for r in current['records'])
    keys = ('games', 'human_turns', 'event_turns', 'events_ok', 'partial', 'hard_findings', 'batch_digest')
    return {key: current[key] for key in keys}


def main():
    source = load('source.json')
    digest = source['source_sha256']
    assert source_identity()['source_sha256'] == digest
    assert source['commit'] == PARENT and source['dirty']
    protected = load('protected-sources.json')
    assert len(protected) == 48
    assert all(hashlib.sha256((REPO / path).read_bytes()).hexdigest() == sha
               for path, sha in protected.items())
    suites = check_tests()
    games = {}
    for edition, seeds in (('legacy', range(1, 21)), ('second-edition', range(53, 57))):
        parent = read_games(f'parent-{edition}', edition, seeds, PARENT_DIGEST)
        repair = read_games(edition, edition, seeds, digest)
        counts = compare_games(parent, repair)
        if edition == 'legacy':
            assert (counts['changed_final_states'], counts['changed_winners'], counts['changed_card_counts']) == (15, 6, 5)
            counts['first_changes'] = first_changes(parent, repair, counts['changed_games'], digest)
            balance = check_balance(parent, repair)
        else:
            assert counts['changed_final_states'] == 0
        games[edition] = counts
    result = {'source': source, 'suites': suites, 'bot_games': games,
              'balance': balance, 'mixed': check_mixed(digest), 'protected_files': len(protected)}
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
