# Sixth audit lifecycle partition

Audited fs-bot `86fb0c2d8ddf86a4548a863dc9c9da27d0c708ad` against supplied Falling Sky references and adopted rulings. Read-only comparator: lod-bot `2991ea279062773548ec390a1da75f3e85381702`, `coin-implementation-lessons.md` and `docs/audit_set_but_never_applied_s76.md`; patterns used only, not game-rule authority.

Three confirmed groups: WS6-01 German Rally per-Region Ally quota, WS6-02 repeated incoming March pieces, WS6-03 nested player-Control destination priority. `probe_lifecycle.py` emits `probe_lifecycle.json`. It intentionally asserts the audited behavior and includes controls; these are evidence probes, not regression tests claiming the behavior is correct. Both direct public command procedures and complete `germans_phase` integration reproduce each finding. Fixtures retain the permanent Provincia Fort, use canonical piece and Tribe helpers, and pass census and structure before/after. They are controlled states, not claims of natural sampled-game reachability.

Reviewed without a new confirmed finding in this partition:

- Winter phase order, final-Winter/Interlude gate, first-Winter exception consumption, Harvest-before-Winter-Campaign sequencing.
- Spring Successor entry, Scouted and Revealed cleanup, Dispersed/Razed cycling, Intimidated removal, all-seat Eligibility reset.
- Senate Lost Eagle lifetime, skip/force-position exceptions, Fallen halves, Ariovistus combined lower-row limit, Auxilia placement.
- Interlude home-Tribe restoration (fifth fix), named Leader placement, force reductions, Cisalpina relocation, expedition qualification, resource conversion, Nori removal, deck/excluded-Capability handling, first-second-half-Winter flags.
- Sequence eligibility update and immediate ineligibility checks; pending-card advancement and Winter replay transaction boundaries.
- Automatic Arverni Phase target selection, Raid reserve and Battle orchestration inspected; Battle capability integration is being checked in the Battle partition.

Coverage is a targeted source/code review, not exhaustive testing of every branch or edition. Existing Optimates question remains uncounted. Static suspicions about other geography helpers are not findings here.

Prior audit ledgers checked for overlapping titles and mechanisms, including original human-choice inventory and later 21/15/16/11-group ledgers. Guided Event movement findings do not cover the separate §6.2 automatic Germans Phase command implementation.
