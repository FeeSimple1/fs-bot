# Expansion partition, third comparison audit

Audited Falling Sky `3c23a3414c3e870e274ef63c278db8cb3f1ee747`, compared with
Liberty or Death `2991ea279062773548ec390a1da75f3e85381702`.
Only the supplied Falling Sky references and adopted project decisions govern
rules conclusions. Liberty or Death supplies audit patterns.

`probe.py` reproduces four new grouped findings in eleven controlled cases.
Its assertions deliberately preserve the defective outcomes. Run with
`PYTHONPATH=/path/to/fs-bot python expansion/probe.py` from this evidence root.
`observed.json` records the source digest, validator/executor results and board
checks. No gameplay code was modified.

The cases enter through the durable response validator, action validator and
ordinary `execute_decision`. All constructed positions pass pool and structural
validation before and after execution. They are initialized controlled positions,
not save-file modifications or full naturally reached game transcripts.
Procillus's Colony is created by card71. Nasua's Dispersed marker is created by
Seize; Spring produces its Gathering side. The Stalwart comparison activates59,
then A31, before an ordinary Battle. All three families include positive controls.

Coverage included a read of the A-prefix card texts and handler layer, close
inspection of expansion placement validation and Event targets, the A29/A69
cohort grant module, and A31/A33/Abatis loss consumers. A19, A29, A35, A31/59
received new executable boundary witnesses. Previous EX2 finding scopes and
original inventory rows were checked for overlap. This is not an exhaustive
claim about every expansion effect or interlude state.

Rejected or limited leads

- A33 Motivation correctly checks the A31 unshaded cancellation flag in both
  loss calculators; it is not counted.
- A36 shaded and A43 unshaded have their mandatory quotas and exact source
  validation in `expansion_validation`; static review did not justify a new
  finding. A29 shaded is a separate unsupported side of that module.
- A60 shaded's restriction to Ally/Auxilia is explicitly printed, so its failure
  to replace Roman Legions or Forts is correct.
- The A24/A27/A32 scarcity-allocation question remains unproven here. Fixed
  iteration ordering was observed but no new confirmed rules conclusion is
  claimed for scarcity or complete Arverni Phase paths.
- A69 resident-force participation was not counted; no conclusion about the
  scope of “They Ambush” was established in this pass.
- The broader A31 cancellation surface is a repair-review lead. The confirmed
  dynamic finding is specifically standing shaded59 against shadedA31.

The preliminary `probe_candidates.py` and its output are exploration artifacts;
use `probe.py` and `observed.json` for the final reproducible record.
