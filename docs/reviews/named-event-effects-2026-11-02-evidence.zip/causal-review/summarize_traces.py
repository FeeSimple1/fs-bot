"""Verify bounded paired outcomes/prefixes and retain each first differing row."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
pairs = json.loads((root.parent/'matrix-01/parent-differences.json').read_text())
manifests = {label: json.loads((root/f'{label}-manifest.json').read_text()) for label in ('parent','candidate')}

def sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()

def changed_keys(a, b):
    return sorted(k for k in set(a) | set(b) if a.get(k) != b.get(k))

reports = []
for expected in pairs:
    key = expected['scenario'], expected['seed']
    records = {}
    paths = {}
    for label in manifests:
        matches = [e for e in manifests[label]['games'] if (e['scenario'],e['seed']) == key]
        assert len(matches) == 1
        entry = matches[0]
        path = root/entry['file']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256']
        with gzip.open(path, 'rt') as f:
            records[label] = json.load(f)
        assert records[label]['outcome'] == expected['before' if label == 'parent' else 'after']
        paths[label] = path.name
    parent, candidate = records['parent'], records['candidate']
    first = next((i for i,(a,b) in enumerate(zip(parent['trace'],candidate['trace'])) if a != b), None)
    assert first is not None, ('No differing row within changed game',key)
    a,b = parent['trace'][first],candidate['trace'][first]
    assert parent['trace'][:first] == candidate['trace'][:first]
    same_before = a['before'] == b['before']
    row = {'scenario':key[0], 'seed':key[1], 'before_outcome':parent['outcome'],
           'after_outcome':candidate['outcome'], 'trace_index_zero_based':first,
           'kind':a['kind'], 'card':a['card'], 'actor':a['faction'],
           'played_card_count':a['card_index'], 'same_event_identity': all(a.get(k)==b.get(k) for k in ('kind','card','faction','card_index')),
           'all_earlier_rows_identical':True, 'same_complete_pre_state':same_before,
           'same_declared_decision':a.get('decision')==b.get('decision'),
           'changed_before_keys':changed_keys(a['before'],b['before']),
           'changed_after_keys':changed_keys(a['after'],b['after']),
           'changed_regions':changed_keys(a['after']['spaces'],b['after']['spaces']),
           'parent_decision':a.get('decision'), 'candidate_decision':b.get('decision'),
           'parent_result':a.get('result'), 'candidate_result':b.get('result'),
           'rng': {'before_equal':a['before']['rng']==b['before']['rng'],
                   'after_equal':a['after']['rng']==b['after']['rng'],
                   'parent_consumed_rng':a['before']['rng']!=a['after']['rng'],
                   'candidate_consumed_rng':b['before']['rng']!=b['after']['rng'],
                   'parent_before_sha256':sha(a['before']['rng']),
                   'candidate_before_sha256':sha(b['before']['rng']),
                   'parent_after_sha256':sha(a['after']['rng']),
                   'candidate_after_sha256':sha(b['after']['rng'])},
           'trace_files':paths, 'cause_review':'pending'}
    name = f"first-{key[0].replace(' ','-').replace('?','')}-{key[1]}.json"
    (root/name).write_text(json.dumps({'summary':row,'parent':a,'candidate':b},sort_keys=True)+'\n')
    row['first_rows_file'] = name
    reports.append(row)
report = {'scope':'Exactly new parent winner/card differences; earliest recorded divergence, not exhaustive downstream winner attribution.',
          'method':'Real run_game with balance_smoke callback; live-only execute snapshots exclude previews; legacy edition, PYTHONHASHSEED=0.',
          'source':{l:manifests[l]['source'] for l in manifests}, 'pairs':reports,
          'groups': dict(Counter(f"{r['kind']}:{r['card']}:{r['actor']}" for r in reports)),
          'requires_boundary_investigation': [r['first_rows_file'] for r in reports if not r['same_complete_pre_state']]}
(root/'first-divergences.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'pairs':len(reports),'groups':report['groups'],'requires_boundary_investigation':report['requires_boundary_investigation']},indent=2))
