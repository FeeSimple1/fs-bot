"""Verify raw independent tenth-audit reruns without normalizing diagnostic drift."""
import hashlib
import json
from pathlib import Path
import re
import shutil

ROOT = Path(__file__).resolve().parent
AUDIT = ROOT.parent.parent
REPO = AUDIT.parent / 'falling-sky'
PYTHON = '/workspace/scratch/4aba5bd9b1ab/fs-bot/.venv/bin/python'
SCRIPTS = {lane: AUDIT / lane / f'probe_{lane}.py'
           for lane in ('battle', 'bots', 'events', 'frontend', 'lifecycle')}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def differences(x, y, path='$'):
    if type(x) != type(y):
        return [(path, x, y)]
    if isinstance(x, dict):
        if x.keys() != y.keys():
            return [(path, x, y)]
        return [d for key in x for d in differences(x[key], y[key], f'{path}.{key}')]
    if isinstance(x, list):
        if len(x) != len(y):
            return [(path, x, y)]
        return [d for i, (a, b) in enumerate(zip(x, y))
                for d in differences(a, b, f'{path}[{i}]')]
    return [] if x == y else [(path, x, y)]


records = []
for lane, script in SCRIPTS.items():
    outputs = [ROOT / f'{lane}-{seed}.json' for seed in (0, 987)]
    same = outputs[0].read_bytes() == outputs[1].read_bytes()
    payload, other = [json.loads(p.read_text()) for p in outputs]
    drift = differences(payload, other)
    extra = {}
    if lane == 'battle':
        assert len(payload['cases']) == 5 and len(payload['public_battle_controls']) == 2
    elif lane == 'bots':
        assert payload['case_count'] == len(payload['cases']) == 9
    elif lane == 'events':
        assert payload['summary'] == dict(availability_witnesses=8, executed_non_event_controls=8,
                                         positive_controls=6, self_benefit_witnesses=4,
                                         explicit_warband_controls=4)
    elif lane == 'frontend':
        assert len(payload['UI10-01']) == 3 and len(payload['UI10-02']['cases']) == 7
    elif lane == 'lifecycle':
        assert payload['assertions_passed'] and len(payload['cases']) == 7
        assert len(payload['full_winter_cases']) == 2
        assert drift and not same
        assert all(re.fullmatch(r'\$\.full_winter_cases\[1\]\.agreement_requests\[\d+\]\.request\.context\.region', path)
                   for path, _, _ in drift), drift
        final_digests = []
        for a, b in zip(payload['full_winter_cases'], other['full_winter_cases']):
            assert a['final_board_and_rng_sha256'] == b['final_board_and_rng_sha256']
            assert a['final_rng_sha256'] == b['final_rng_sha256']
            assert a['after'] == b['after'] and a['winter_result'] == b['winter_result']
            final_digests.append({k: a[k] for k in ('name', 'final_board_and_rng_sha256', 'final_rng_sha256')})
        for seed, path in zip((0, 987), outputs):
            assert (ROOT / f'lifecycle-{seed}.log').read_bytes() == path.read_bytes()
            assert path.read_bytes() == (AUDIT / f'lifecycle/results.hash{seed}.json').read_bytes()
        extra = {'differences': [dict(path=p, hash0=a, hash987=b) for p, a, b in drift],
                 'full_board_and_rng_equal': True, 'final_digests': final_digests,
                 'note': 'Raw supply_line agreement representative contexts differ. No normalization applied. UI10-03 separately proves saved journal replay can fail on the changed request.'}
    if lane != 'lifecycle':
        assert same, lane
        assert outputs[0].read_bytes() == (AUDIT / lane / 'results.json').read_bytes()
    snapshot = ROOT / f'{lane}-probe.py'
    shutil.copyfile(script, snapshot)
    commands = []
    for seed in (0, 987):
        command = f'PYTHONHASHSEED={seed} {PYTHON} {script} --repo {REPO}'
        if lane == 'lifecycle':
            command += f' --out {ROOT}/lifecycle-{seed}.json > {ROOT}/lifecycle-{seed}.log'
        else:
            command += f' > {ROOT}/{lane}-{seed}.json'
        commands.append(command)
    records.append({'lane': lane, 'script': str(script), 'script_sha256': sha(script),
                    'preserved_script': snapshot.name, 'hash_seeds': [0, 987],
                    'exit_codes': [0, 0], 'commands': commands,
                    'stdout_sha256_by_hash': {str(seed): sha(path) for seed, path in zip((0, 987), outputs)},
                    'byte_identical_stdout': same, 'outputs': [p.name for p in outputs], **extra})
replay_script = AUDIT / 'frontend/probe_quarters_replay.py'
replay_outputs = [ROOT / f'quarters-replay-{seed}.json' for seed in (0, 987)]
assert replay_outputs[0].read_bytes() == replay_outputs[1].read_bytes()
assert replay_outputs[0].read_bytes() == (AUDIT / 'frontend/quarters-replay-results.json').read_bytes()
replay = json.loads(replay_outputs[0].read_text())
assert replay['multiple_host_regions']['resume_hash987']['error'] == 'Saved decision no longer matches its board/request; replay stopped.'
assert replay['multiple_host_regions']['resume_hash0']['error'] is None
assert replay['single_region_control']['resume_hash987']['error'] is None
assert all(v['board_and_rng_unchanged'] and not v['census'] and not v['structure']
           for group in replay.values() for v in group.values())
shutil.copyfile(replay_script, ROOT / 'quarters-replay-probe.py')
supplemental = {'finding': 'UI10-03', 'script': str(replay_script),
                'script_sha256': sha(replay_script),
                'preserved_script': 'quarters-replay-probe.py',
                'outer_hash_seeds': [0, 987], 'internal_record_hash': 0,
                'internal_resume_hash_seeds': [0, 987],
                'exit_codes': [0, 0], 'byte_identical_stdout': True,
                'stdout_sha256': sha(replay_outputs[0]),
                'outputs': [p.name for p in replay_outputs],
                'commands': [f'PYTHONHASHSEED={seed} {PYTHON} {replay_script} --repo {REPO} > {ROOT}/quarters-replay-{seed}.json' for seed in (0,987)]}
summary = {'audited_commit': 'ae238c6482a792dda98af4f1f9b11abf820a3964',
           'source_sha256': '39076dca68ec449cf766e40256c765d2d36693c50989a2b0552745f208f94d45',
           'lanes': records, 'supplemental_replay_probe': supplemental,
           'all_finalized_lane_reruns_byte_identical': all(r['byte_identical_stdout'] for r in records),
           'preliminary_battle_note': 'Preserved preliminary outputs contained different hash_seed metadata. Finalized probe omitted this field and synchronized both current-card fields. Final battle outputs are byte-identical.'}
(ROOT / 'reruns.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
