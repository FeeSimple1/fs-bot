Accepted Spring validation, Python32fc2e1f... at base commita537511 (dirty during runs).
150 audited bot games (100legacy1-20;25original201-205;25second-edition201-205),80 mixed replay executions and50 strict census executions.
Original full suite:5225 passed/1 compatibility-fixture failure, exit1. Original baseline:GallicWarArverni4/20 to0/20 (-20pp), failed unchanged15pp band. Both failures remain preserved.
Source-reviewed compatibility JSON expectation updated with history; final manifest0e1609c9.... Baseline candidate815b6f36... reviewed and installed after9 paired causal cases.
Final full suite5226 passed, exit0; fresh100balance exactly matches every reviewed winner/cards, exit0. Local checks are separate from remoteCI, which is not claimed as run.
Two Interlude tie order mappings are legal implementation drift, not old-rule violations. Early bookkeeping/reporting differences are distinguished from actual placement/RNG differences.
19 diagnostic game executions =18 accepted paired traces plus1 GallicWar14 artifact recapture. The original truncated gzip remains as failed artifact evidence; current-recaptured.json.gz is the accepted trace.
Earlier historical raw baseline records retain actual04b metadata/source071485; new clean-a537511 baseline traces match those exact final hashes. No historical evidence relabeled.
MANIFEST.json hashes every other archive member. frozen-python-source contains all315 executed Python files, including originally untracked modules/tests.
The results.json verifier still exits1 solely to preserve the original band failure; final-acceptance.json and fresh balance-final files record the separate reviewed acceptance.
