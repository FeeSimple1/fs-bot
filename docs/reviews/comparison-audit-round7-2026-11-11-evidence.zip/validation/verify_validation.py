"""Verify seventh comparison unchanged-source audit evidence, not game-rule coverage."""
from collections import Counter
import json
from pathlib import Path
import platform
import sys
from xml.etree import ElementTree
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity

p = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent
identity = json.loads((p / 'source.json').read_bytes())
assert identity['commit'] == 'c67d501711471bf790d805c017c2125b2c254639'
assert identity['dirty'] is False
assert source_identity()['source_sha256'] == identity['source_sha256'] == '2ae5b3cedb16cfed6969442ebe9fefba99ed0f03933cd30c78a4deb6c002e801'
expected = {(s, n, 'second-edition') for s in SCENARIOS for n in range(41, 45)}
rows = [json.loads(line) for line in (p / 'bots-second/games.jsonl').read_text().splitlines()]
assert len(rows) == len(expected) == 20
assert {(r['scenario'], r['seed'], r['card_edition']) for r in rows} == expected
for row in rows:
    assert all(row[k] for k in ('completed', 'game_completed', 'audit_completed', 'final_state_sha256')), row
    assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row), row
    assert len(row['final_ranking']) == len(row['engine_final_ranking']) == 4, row
    assert all(d['severity'] == 'legal-decline' for d in row['diagnostics']), row
    assert row['commit'] == identity['commit'] and row['source_sha256'] == identity['source_sha256'], row
fuzz0 = json.loads((p / 'fuzz0.json').read_bytes())
assert (p / 'fuzz0.json').read_bytes() == (p / 'fuzz987.json').read_bytes()
assert (p / 'fuzz0.log').read_bytes() == (p / 'fuzz987.log').read_bytes()
assert fuzz0['games'] == len(fuzz0['records']) == 20
assert fuzz0['hard_findings'] == 0
assert fuzz0['metadata']['source_sha256'] == identity['source_sha256']
assert fuzz0['metadata']['commit'] == identity['commit']
assert {(r['scenario'], r['seed'], r['card_edition']) for r in fuzz0['records']} == expected
assert all(r['game_completed'] and not r['findings'] for r in fuzz0['records'])
suites = list(ElementTree.parse(p / 'pytest.xml').getroot().iter('testsuite'))
tests = sum(int(s.attrib.get('tests', 0)) for s in suites)
assert tests == 9991
assert not any(int(s.attrib.get(k, 0)) for s in suites for k in ('errors', 'failures', 'skipped'))
summary = {
    'source': identity,
    'python': platform.python_version(),
    'python_files': len(list((Path(__import__('fs_bot').__file__).parent).rglob('*.py'))),
    'pytest': {'passed': tests, 'seconds': sum(float(s.attrib['time']) for s in suites)},
    'bots': {'games': len(rows), 'complete': len(rows), 'interludes': sum(r['interlude_completed'] for r in rows),
             'seeds': [41, 42, 43, 44], 'edition': 'second-edition', 'scenarios': list(SCENARIOS),
             'diagnostics': dict(Counter(d['severity'] for r in rows for d in r['diagnostics']))},
    'mixed': {k: fuzz0[k] for k in ('games', 'human_turns', 'event_turns', 'events_ok', 'partial', 'hard_findings', 'batch_digest')},
    'hash_seeds': [0, 987], 'mixed_exact_bytes_match': True,
    'baseline_changed': False, 'balance_matrix_run': False,
}
if (p / 'github-actions.json').exists():
    runs = json.loads((p / 'github-actions.json').read_bytes())['workflow_runs']
    summary['github_actions'] = [{k: r.get(k) for k in ('id', 'name', 'head_sha', 'status', 'conclusion', 'html_url')} for r in runs]
(p / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
