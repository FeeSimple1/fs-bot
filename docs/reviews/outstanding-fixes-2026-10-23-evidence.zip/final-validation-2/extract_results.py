#!/usr/bin/env python3
"""Extract outcome statistics and evidence without running games or importing the engine.

Use --batch-only to inspect an intermediate/failed batch. The JSON is always
written, but exit status is nonzero when the selected acceptance checks fail.
Win rates use completed, audited games; failed attempts are counted separately.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import statistics


def read_json(path):
    return json.loads(path.read_text())


def records(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def key(row):
    return [row['scenario'], row['seed']]


def complete(row):
    return (all(row.get(flag) is True for flag in ('completed', 'game_completed', 'audit_completed'))
            and not row.get('error') and not row.get('errors') and not row.get('integrity_findings'))


def summarize(matrix):
    metadata = read_json(matrix / 'batch-hash0/metadata.json')
    rows = records(matrix / 'batch-hash0/games.jsonl')
    scenarios = metadata['scenarios']
    first, last = metadata['seeds']
    expected = {(scenario, seed) for scenario in scenarios for seed in range(first, last + 1)}
    observed = [(row['scenario'], row['seed']) for row in rows]
    failures, diagnostic_incidents = [], Counter()
    error_groups, diagnostic_groups = defaultdict(list), defaultdict(list)
    for row in rows:
        if not complete(row):
            failures.append(key(row))
        for error in row.get('errors', []):
            error_groups[(error.get('stage'), error.get('error_type'), error.get('error'))].append(key(row))
        for diagnostic in row.get('diagnostics', []):
            diagnostic_incidents[diagnostic['severity']] += diagnostic['count']
            if diagnostic['severity'] != 'legal-decline':
                diagnostic_groups[diagnostic['message']].append({
                    'scenario': row['scenario'], 'seed': row['seed'],
                    'incidents': diagnostic['count'], 'faction': diagnostic['faction'],
                    'card': diagnostic['example'][2], 'severity': diagnostic['severity']})
    completed = [row for row in rows if complete(row)]
    factions = sorted({faction for row in rows for faction, _ in row.get('final_ranking', [])})
    ranking_bad = [key(row) for row in completed if
                   row.get('engine_ranking_output_missing') is not False
                   or not isinstance(row.get('final_ranking'), list)
                   or len(row['final_ranking']) != 4
                   or row.get('winner_differs_from_highest_margin') is not False]
    hash_bad = [key(row) for row in rows if
                not isinstance(row.get('final_state_sha256'), str)
                or len(row['final_state_sha256']) != 64
                or any(c not in '0123456789abcdef' for c in row['final_state_sha256'])]
    outcome_stats = {}
    for scenario in scenarios:
        attempted = [row for row in rows if row['scenario'] == scenario]
        valid = [row for row in completed if row['scenario'] == scenario]
        wins = Counter(row['winner'] for row in valid)
        cards = [row['cards'] for row in valid]
        final = sum(row['ended_on_final_winter'] is True for row in valid)
        timing = Counter(('final-winter' if row['ended_on_final_winter'] else 'before-final-winter',
                          row['termination']) for row in valid)
        outcome_stats[scenario] = {
            'attempted': len(attempted), 'completed': len(valid),
            'failed': len(attempted) - len(valid), 'rate_denominator': len(valid),
            'wins': {faction: wins[faction] for faction in factions},
            'win_rate_percent': {faction: 100 * wins[faction] / len(valid) if valid else None
                                 for faction in factions},
            'before_final_winter': len(valid) - final, 'on_final_winter': final,
            'terminations': dict(Counter(row['termination'] for row in valid)),
            'termination_by_timing': [{'timing': when, 'reason': reason, 'games': n}
                                      for (when, reason), n in sorted(timing.items())],
            'interlude_games': sum(row.get('interlude_completed') is True for row in valid),
            'ending_scenarios': dict(Counter(row['ending_scenario'] for row in valid)),
            'cards': {'total': sum(cards), 'mean': statistics.mean(cards) if cards else None,
                      'median': statistics.median(cards) if cards else None,
                      'minimum': min(cards) if cards else None, 'maximum': max(cards) if cards else None},
            'winter_counts': dict(sorted(Counter(row['winters'] for row in valid).items())),
        }
    coverage = len(rows) == len(expected) and len(set(observed)) == len(rows) and set(observed) == expected
    state_digest = hashlib.sha256()
    for row in sorted(rows, key=lambda row: (row['scenario'], row['seed'])):
        state_digest.update(json.dumps([row['scenario'], row['seed'], row.get('final_state_sha256')],
                                       separators=(',', ':')).encode() + b'\n')
    return {
        'source': {name: metadata.get(name) for name in
                   ('commit', 'source_sha256', 'python', 'hash_seed', 'seeds', 'scenarios', 'all_factions_bots')},
        'games': len(rows), 'completed': len(completed), 'coverage_exact': coverage,
        'failed_games': failures, 'crash_games': [key(row) for row in rows if row.get('errors') or row.get('error')],
        'errors': [{'stage': stage, 'type': kind, 'message': message, 'games': games}
                   for (stage, kind, message), games in error_groups.items()],
        'diagnostic_incidents': dict(diagnostic_incidents),
        'nonlegal_incidents': sum(n for severity, n in diagnostic_incidents.items() if severity != 'legal-decline'),
        'nonlegal_groups': dict(diagnostic_groups),
        'integrity_games': [key(row) for row in rows if row.get('integrity_findings')],
        'completed_game_ranking_failures': ranking_bad, 'invalid_final_hash_games': hash_bad,
        'ordered_final_hashes_sha256': state_digest.hexdigest(), 'outcomes': outcome_stats,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--matrix', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--prior-failed', type=Path)
    parser.add_argument('--batch-only', action='store_true')
    args = parser.parse_args()
    result = {'schema_version': 1, 'batch': summarize(args.matrix)}
    manifest = read_json(args.matrix / 'manifest.json')
    result['manifest'] = manifest
    verification_path = args.matrix / 'verification.json'
    result['matrix_verification'] = read_json(verification_path) if verification_path.exists() else None
    if args.prior_failed:
        prior = summarize(args.prior_failed)
        # Historical outcomes are intentionally not promoted as final statistics.
        result['prior_failed_batch'] = {k: v for k, v in prior.items() if k != 'outcomes'}
    artifacts = ['manifest.json', 'batch-hash0/metadata.json', 'batch-hash0/games.jsonl',
                 'batch-hash0/summary.json', 'bots-hash7.jsonl', 'fuzz-hash0.log', 'fuzz-hash7.log',
                 'census-hash0.json', 'census-hash7.json', 'verification.json']
    result['artifacts'] = {name: {'bytes': (args.matrix / name).stat().st_size,
                                'sha256': hashlib.sha256((args.matrix / name).read_bytes()).hexdigest()}
                           for name in artifacts if (args.matrix / name).exists()}
    batch = result['batch']
    issues = []
    for field in ('failed_games', 'nonlegal_incidents', 'integrity_games',
                  'completed_game_ranking_failures', 'invalid_final_hash_games'):
        if batch[field]:
            issues.append(field)
    if not batch['coverage_exact'] or batch['games'] != 1000 or len(batch['outcomes']) != 5:
        issues.append('exact_1000_game_coverage')
    if manifest['source_sha256'] != batch['source']['source_sha256']:
        issues.append('source_digest_mismatch')
    if any(not item['source_unchanged'] or item['returncode'] for item in manifest['stages'].values()):
        issues.append('failed_or_changed_source_stage')
    if not args.batch_only:
        verification = result['matrix_verification']
        if verification is None or verification.get('failures'):
            issues.append('full_matrix_verification')
    result['acceptance'] = {'scope': 'batch-only' if args.batch_only else 'full-matrix',
                            'passed': not issues, 'issues': issues}
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'acceptance': result['acceptance'], 'games': batch['games'],
                      'completed': batch['completed'], 'nonlegal_incidents': batch['nonlegal_incidents'],
                      'outcomes': batch['outcomes']}, indent=2))
    return bool(issues)


if __name__ == '__main__':
    raise SystemExit(main())
