"""Save and resume the Arverni's Leader choice on another faction's Event."""

from copy import deepcopy
from io import StringIO
import json
from pathlib import Path
import tempfile

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import find_leader, get_leader_in_region, place_piece, remove_piece
from fs_bot.cli.display import HumanTurnDisplay
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT, _action_transaction
from fs_bot.state.serialize import decode, encode, load_game, save_game
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import check_structural_integrity, validate_state
from fs_bot.tools.seat_session import DecisionPending, SeatSession, board_copy


def resolve(session):
    def driver(*_args):
        raise AssertionError('The Event must consult only its reactive beneficiary.')

    driver.transaction_checkpoint = session.checkpoint
    driver.transaction_restore = session.restore
    driver.transaction_complete = session.transaction_complete
    with _action_transaction(session.state, driver):
        return execute_decision(session.state, rc.BELGAE, {
            'action': ACTION_EVENT,
            'bot_action': {'command': rc.FIRST_DID_EVENT, 'details': {
                'card_id': 19, 'text_preference': rc.EVENT_SHADED,
            }},
        })


def make_session(state, meta, log):
    session = SeatSession(state, meta, log, HumanTurnDisplay(StringIO()))
    state['decision_agent'] = session.reactive
    return session


def main():
    state = setup_scenario(rc.SCENARIO_RECONQUEST, seed=1)
    state.update(current_card=19, current_card_id=19, can_play_event=True,
                 non_player_factions={rc.BELGAE, rc.AEDUI, rc.ROMANS})
    origin = find_leader(state, rc.ARVERNI)
    remove_piece(state, origin, rc.ARVERNI, rc.LEADER)
    place_piece(state, origin, rc.ARVERNI, rc.LEADER, leader_name=rc.SUCCESSOR)
    original = encode(board_copy(state))
    session = make_session(state, {'seat': rc.ARVERNI}, [])
    try:
        resolve(session)
    except DecisionPending:
        pass
    else:
        raise AssertionError('The other faction’s Event must pause for the Arverni.')
    pending = deepcopy(session.data['pending'])
    assert encode(board_copy(state)) == original
    request = decode(pending['request'])
    assert request['kind'] == 'spring_leader' and request['source'] == 'event'
    assert request['faction'] == rc.ARVERNI and not request['can_defer']
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder) / 'game.json'
        save_game(state, path, meta=session.meta, log=session.log)
        state, meta, log = load_game(path, validate=True)
    resumed = make_session(state, meta, log)
    assert resumed.data['pending'] == pending
    choice = {'region': rc.BITURIGES}
    assert resumed.import_inbox({'decision_id': pending['id'], 'response': choice})
    result = resolve(resumed)
    resumed.finish()
    assert result['executed'] and get_leader_in_region(state, rc.BITURIGES, rc.ARVERNI) == rc.VERCINGETORIX
    assert validate_state(state) == check_structural_integrity(state) == []
    assert [decode(row['assistant_response']) for row in resumed.log] == [choice]
    print(json.dumps({'request': request, 'result': result, 'accepted': choice,
                      'leader': [rc.BITURIGES, rc.VERCINGETORIX],
                      'pending_id_preserved': True, 'rollback_board_and_rng_preserved': True},
                     indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
