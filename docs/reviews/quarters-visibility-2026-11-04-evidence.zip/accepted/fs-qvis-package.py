from pathlib import Path
import hashlib,json,platform,re,subprocess,xml.etree.ElementTree as ET,zipfile
from fs_bot.tools.validation_metadata import source_identity
prefix='quarters-visibility-2026-11-04';result=json.loads(Path('/tmp/fs-qvis-results.json').read_text())
assert source_identity()['source_sha256']==result['source']['source_sha256']=='8dc4932e3aef23aa039773d005d44c7a492f1618d4b44d054f1b2fa68254c13d'
suite=ET.parse('/tmp/fs-qvis-full.xml').getroot().find('testsuite')
assert suite.attrib['tests']=='8104' and all(suite.attrib[k]=='0' for k in ('errors','failures','skipped'))
assert Path('/tmp/test_quarters_visibility_parent.py').read_bytes()==Path('fs_bot/tests/test_quarters_visibility.py').read_bytes()
proof=ET.parse('/tmp/fs-qvis-parent.xml').getroot().find('testsuite')
assert proof.attrib['tests']=='41' and proof.attrib['failures']=='29' and proof.attrib['errors']=='0'
assert sum(t.find('failure') is not None for t in proof)==29
assert all('Each relocation must contain piece, origin, destination, and count' in t.find('failure').attrib['message'] for t in proof if t.find('failure') is not None)
target_log=Path('/tmp/fs-qvis-targeted-frozen.log').read_text()
match=re.search(r'\n(\d+) passed in ',target_log)
assert match and int(match[1])==129 and 'failed' not in target_log
result['targeted_passed']=int(match[1])
result['full_suite']=suite.attrib;result['parent_suite']=proof.attrib;result['python']=platform.python_version()
result['balance_smoke_rerun']=False
result['balance_scope']='Legacy NPC plans are unchanged; ten parent/current audited gameplay records and final hashes agree. No new 100-game historical balance claim.'
Path('docs/reviews/'+prefix+'-results.json').write_text(json.dumps(result,indent=2)+'\n')
p=Path('docs/reviews/'+prefix+'.md');s=p.read_text().replace('Final full suite pending.',f"**8,104 tests pass** in the final full suite ({float(suite.attrib['time']):.2f} seconds), with zero failures, errors or skips. **129 targeted tests pass**.");s=s.replace('Results pending final inspection.', '''All ten native-bot records complete and audit successfully, with no errors or
integrity findings, four ranked factions, consistent winner/ranking fields and
nonempty final hashes. Every gameplay field and final hash matches the parent;
only elapsed seconds, commit and source digest are excluded from comparison.
Both mixed-seat outputs agree in complete JSON across hash seeds: 247 human
turns, 77 Event attempts, 75 successful Events, zero hard findings, zero partials,
batch digest `5dd20da48e8e672b`. Internal replay makes 40 executions in total.''');p.write_text(s)
p=Path('docs/current-status.md');s=p.read_text().replace('Validation: see the final report and machine-readable results.', '''**8,104 tests pass**, including 56 new cases; 129 targeted tests pass. Ten
native-bot gameplay records/final hashes match parent. Forty mixed executions
agree across hash seeds with zero hard findings or partials. See the report
for the frozen source digest and evidence bounds.''',1);p.write_text(s)
entries={}
for file in ['/tmp/fs-qvis-full.xml','/tmp/fs-qvis-full.log','/tmp/fs-qvis-targeted-frozen.log','/tmp/fs-qvis-parent.xml','/tmp/fs-qvis-parent.log','/tmp/test_quarters_visibility_parent.py','/tmp/fs-qvis-mixed0.json','/tmp/fs-qvis-mixed0.log','/tmp/fs-qvis-mixed987.json','/tmp/fs-qvis-mixed987.log','/tmp/fs-qvis-verify.py','/tmp/fs-qvis-package.py']:
 entries['accepted/'+Path(file).name]=Path(file).read_bytes()
for label,directory in [('parent','/tmp/fs-qvis-bots-parent'),('accepted','/tmp/fs-qvis-bots-final')]:
 for p in Path(directory).iterdir():
  if p.is_file():entries[label+'/bots/'+p.name]=p.read_bytes()
entries['accepted/results.json']=json.dumps(result,indent=2).encode()
entries['accepted/source.patch']=subprocess.check_output(['git','diff','HEAD','--','fs_bot'])
entries['accepted/fs_bot/tests/test_quarters_visibility.py']=Path('fs_bot/tests/test_quarters_visibility.py').read_bytes()
protected=[p for p in Path('Reference Documents').rglob('*') if p.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
entries['accepted/protected-inputs.json']=json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected},indent=2).encode()
entries['commands.txt']=b'''Accepted source: parent 0a006caca41b297ec8842d51d973bcf2c9f29e55 plus accepted/source.patch and accepted/fs_bot/tests/test_quarters_visibility.py.
python -m pytest -q --junitxml=/tmp/fs-qvis-full.xml
python -m pytest -q fs_bot/tests/test_quarters_visibility.py fs_bot/tests/test_quarters_decisions.py fs_bot/tests/test_quarters_relocation_step.py fs_bot/tests/test_spring_winter_windows.py
In isolated unmodified parent checkout, with unchanged new test file copied outside the tree:
PYTHONPATH=/tmp/fs-qvis-parent python -m pytest -q /tmp/test_quarters_visibility_parent.py -k 'owner_selects_exact_adjacent_visibility or roman_supplied_provincia_step_preserves_selected_visibility or roman_adjacent_arrival_may_take_later_provincia_step_in_same_visibility or original_cohort_departure_does_not_take_same_type_arrivals or legacy_four_entries_keep_hidden_first_selection or invalid_or_overclaimed_cohorts_are_atomic' --junitxml=/tmp/fs-qvis-parent.xml
In parent and accepted trees separately, with distinct output directories:
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --games 2 --workers 2 --out OUT
In accepted tree:
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out /tmp/fs-qvis-mixed0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 1-2 --out /tmp/fs-qvis-mixed987.json
PYTHONPATH=. python /tmp/fs-qvis-verify.py
PYTHONPATH=. python /tmp/fs-qvis-package.py
'''
entries['README.txt']=b'Accepted Python source 8dc4932e3aef23aa039773d005d44c7a492f1618d4b44d054f1b2fa68254c13d over parent 0a006caca41b297ec8842d51d973bcf2c9f29e55. Apply source.patch and add accepted/fs_bot/tests/test_quarters_visibility.py to reconstruct frozen Python sources. Full suite:8104 passed; 56 new cases. Isolated-parent proof:29 behavioral failures, 12 controls pass, 15 deselected. All ten native-bot records/final hashes match parent except timing/source provenance. Mixed outputs agree in complete JSON across hash seeds0/987, with zero hard findings and zero partials, 40 executions including replay. This is not a new 100-game balance study or full rules-compliance proof. See report for bounds.\n'
entries['SHA256SUMS.txt']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(entries.items())).encode()
p=Path('docs/reviews/'+prefix+'-evidence.zip')
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(entries.items()):z.writestr(name,data)
print(json.dumps({'full_suite':suite.attrib,'targeted':result['targeted_passed'],'evidence_bytes':p.stat().st_size,'source':result['source']}))
