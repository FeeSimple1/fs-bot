"""Trace the first changed card with live Battle inputs and outcomes."""

from concurrent.futures import ProcessPoolExecutor
from contextlib import ExitStack, redirect_stdout
from functools import wraps
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import sys
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.battle import resolve as battle_rules
from fs_bot.board.pieces import count_pieces
from fs_bot.cli.dispatcher import make_decision_func
from fs_bot.engine import arverni_phase, execute, germans_battle, slingers_choice
from fs_bot.engine.game_engine import get_sop_factions, play_card, start_game
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.tools.validation_metadata import source_identity


def digest(value):
    return sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def board_digest(state):
    return digest({key: value for key, value in state.items() if key != 'decision_agent'})


def key(row):
    return row['scenario'], row['seed'], row['card_edition']


def trace(task):
    row, parent = task
    scenario, seed, edition = key(row)
    state = setup_scenario(scenario, seed=seed, card_edition=edition)
    state['non_player_factions'] = set(get_sop_factions(state))
    bot = make_decision_func({}, stdin=StringIO(), stdout=StringIO(), pause=False)
    battles, prefire, decisions, cards = [], [], [], []
    resolve_battle = battle_rules.resolve_battle
    fire_slingers = slingers_choice.fire

    def decide(board, faction, options, position):
        decision = bot(board, faction, options, position)
        decisions.append(encode(dict(faction=faction, position=position, decision=decision)))
        return decision

    @wraps(resolve_battle)
    def resolve(board, region, attacking_faction, defending_faction, **kwargs):
        if board is not state:
            return resolve_battle(board, region, attacking_faction, defending_faction, **kwargs)
        details = dict(region=region, attacker=attacking_faction, defender=defending_faction,
            capability_sides={c: board.get('capabilities', {}).get(c) for c in (10, 13, 59, 'A31')},
            horse_regions={flag: board.get('event_modifiers', {}).get(flag) for flag in
                           ('card59_unshaded_region', 'card59_shaded_region')},
            attacker_force=count_pieces(board, region, attacking_faction),
            defender_force=count_pieces(board, region, defending_faction),
            options={k: kwargs[k] for k in ('is_ambush', 'ignore_fort', 'ignore_citadel',
                    'extra_losses', 'attacker_stays_hidden', 'double_auxilia',
                    'retreat_declaration') if k in kwargs})
        result = resolve_battle(board, region, attacking_faction, defending_faction, **kwargs)
        battles.append(encode(dict(details, result=result)))
        return result

    @wraps(fire_slingers)
    def fire(board, region, attacker):
        if board is not state:
            return fire_slingers(board, region, attacker)
        before = count_pieces(board, region, attacker)
        auxilia = count_pieces(board, region, rc.ROMANS, rc.AUXILIA)
        rng_before = digest(board['rng'].getstate())
        result = fire_slingers(board, region, attacker)
        prefire.append(dict(region=region, attacker=attacker, roman_auxilia=auxilia,
            attacking_pieces_before=before,
            attacking_pieces_after=count_pieces(board, region, attacker),
            rng_before=rng_before, rng_after=digest(board['rng'].getstate())))
        return result

    with ExitStack() as stack:
        stack.enter_context(redirect_stdout(StringIO()))
        for module in (battle_rules, execute, arverni_phase, germans_battle):
            stack.enter_context(patch.object(module, 'resolve_battle', resolve))
        stack.enter_context(patch.object(slingers_choice, 'fire', fire))
        start_game(state)
        for draw in range(1, 201):
            battles.clear()
            prefire.clear()
            decisions.clear()
            before = board_digest(state)
            rng_before = digest(state['rng'].getstate())
            result = play_card(state, decide, execute=True)
            card = dict(draw=draw, card=result['card'], before=before, rng_before=rng_before,
                        after=board_digest(state), decisions=list(decisions),
                        battles=list(battles), prefire=list(prefire))
            if parent is not None:
                prior = parent['cards'][draw - 1]
                assert (prior['card'], prior['before'], prior['rng_before']) == (
                    card['card'], before, rng_before)
                if prior['after'] != card['after']:
                    return dict(scenario=scenario, seed=seed, card_edition=edition,
                        prior_winner=parent['winner'], current_winner=row['winner'],
                        draw=draw, card=card['card'], same_start=before, same_rng=rng_before,
                        prior=prior, current=card)
            else:
                cards.append(card)
            if result['game_over']:
                break
    assert parent is None, f'No first changed card for {key(row)}'
    assert (result['winner'], draw, card['after']) == (
        row['winner'], row['cards'], row['final_state_sha256'])
    return dict(scenario=scenario, seed=seed, card_edition=edition, winner=row['winner'], cards=cards)


def main(inputs, output, parent_file=None):
    rows = json.loads(Path(inputs).read_text())
    parents = {} if not parent_file else {key(row): row for row in
        json.loads(Path(parent_file).read_text())['games']}
    with ProcessPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(trace, ((row, parents.get(key(row))) for row in rows)))
    Path(output).write_text(json.dumps(dict(source=source_identity(), games=results), indent=2) + '\n')
    print(f'{len(results)} games traced')


if __name__ == '__main__':
    main(*sys.argv[1:])
