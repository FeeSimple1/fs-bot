# Independent source and implementation review — BE-11 / BE-12 / EXP-09

Baseline: `8db858b14cd13856059d42db1ad3931e523b5ed4`.
Reviewer makes no production edits or commits. Full `CLAUDE.md`, the supplied
47-file reference inventory, current status, documentation orientation and
the nine adopted provisional rulings were consulted. Only supplied sources
govern this review; protected inputs remain unchanged.

## Source contracts confirmed before implementation

### Shared Event rules

Chapter 5 §5.1 assigns otherwise-unspecified selections to the executor and
requires literal instruction order. Named actors retain expressly assigned
actions/choices. §5.1.1 explicitly removes a replacement target if its new
piece is unavailable or would violate stacking; a validator must not reject
that otherwise-legal selection. §5.1.3 requires possible fixed effects within
the selections the text permits. These rules distinguish invalid excesses
from legal partial execution.

Chapter 1 §§1.4.1–1.4.3 require Available pools, exact Tribe/City stacking,
faction-restricted homes, one Fort per Region, and newly placed mobile pieces
Hidden even when replacing Revealed/Scouted pieces. Non-player policy is not
human legality. Chapter 8 §§8.2.3, 8.3.4 and 8.4.1 govern maximum effects,
beneficiary self-selection, structure/faction/visibility priorities and seeded
equal choices. Their source clauses must also govern newly necessary defaults.

### BE-11 — base Events

- **40 unshaded:** each Region adjacent to Cisalpina independently chooses
  Warbands (at most three), Auxilia (at most two), or one Ally. The alternatives
  cannot mix piece types inside one Region. Tips explicitly permit any
  faction's Warbands or Allies; type can differ between Regions. Zero is legal
  under “up to”. The executor still receives four Resources.
- **41, single text:** Avaricum must be executor's Ally or Citadel. Optional
  effects use its own pieces, in Bituriges and adjacent Regions: up to two
  Allies, one own Ally replaced by a Citadel if legal/Available, and one Roman Fort when
  executor is Roman. Then award Resources for its Allies, Citadels and Forts
  in that complete area, including newly placed pieces. Exact Tribe metadata
  must follow any replacement. Per §5.1.1, a selected non-City Ally is removed
  without placing an illegal Citadel; the same removal fallback applies to an
  exhausted or nonexistent native Citadel pool. The source does not distinguish
  those forms of unavailability. No Roman Citadel can be placed. This differs
  from the optional Fort's pure placement, which has no removal component.
- **42 unshaded:** choose one alternative: up to four Allies in Roman Control,
  or up to two Allies in Regions adjacent to Roman Control. Overlap between
  geographic sets does not create a mixed higher quota. Citadels are excluded.
- **42 shaded, same-card correction:** one through three Roman/Aedui Allies
  from Roman-Aedui Supply Lines. Tips define the Supply Line assuming both
  factions agree. No actual agreement input or random roll should determine
  the target set. An empty list is only possible when there are no targets.
- **51 unshaded:** one selected Region within one of Treveri; replace exactly
  four Warbands if present, otherwise all available targets in that selected
  Region, then grant Aedui the free Command. The text does not require the
  selected Region to contain Warbands, and §5.1.3 explicitly works within
  allowed selections, so a selected empty legal Region does not cancel the
  subsequent Command. Missing the Region itself is distinct from that legal
  empty selection. Replacement shortage removes instead of suppressing the
  selection. Humans are not required to select an NP-preferred Region.

### BE-12 — German Allegiances, card 65 shaded

The executor chooses five Germanic Warbands and one German Ally where it has
Control, with target shortage handled by §5.1.3. Each target may be removed
or replaced by its own corresponding piece: Gallic Warband, Roman Auxilia,
or Ally. The parenthetical “Auxilia for Warbands” is the Roman counterpart
convention, not permission to place nonexistent Gallic Auxilia.

One verb applies jointly to the Warbands and Ally without a “then” or separate
ordered instruction, so player-ordered exact entries are legal. A replacement
blocked by Available pieces or stacking still removes the German target.
Physical visibility and exact Tribe are selectable; new replacement troops
are Hidden. Ordinary enemy removal/own replacement cannot itself remove the
executor's Control, but genuine timing interruptions must recheck current
conditions without changing selected physical identities.

### EXP-09 — expansion Events

- **A29 unshaded:** executor chooses one Gaul or Roman beneficiary, then that
  named actor chooses placement of its own pieces among Regions containing
  Settlements. “Gauls” still includes Arverni in Ariovistus (A5.1.1); Germans
  are excluded. Allies are up to two; the separate alternative is five
  Warbands or three Auxilia, as possible. Faction and normal piece types cannot
  vary across entries to evade one beneficiary's limits.
- **A30 unshaded:** remove all Arverni, including Scouted Warbands and static
  pieces, from one selected Region within one of Sequani. The existing complete
  removal repair remains; this batch must constrain the Region.
- **A36 shaded:** the grammatical subject Germans governs both placement and
  removal, so the German seat chooses the two Settlements, four Warbands and
  two Ally removals, as possible, among Regions within one of Sugambri.
  Settlement limit remains one per Region. Printed order puts placement before
  Ally removal; choices must respect the resulting board.
- **A43 unshaded:** executor selects two Arverni Allies and two Arverni
  Warbands within one of Bibracte, replacing with Roman/Aedui counterparts.
  Targets are exact when available. The Bibracte stacking override is printed
  only on shaded text: choosing a Roman Ally replacement at Bibracte in the
  unshaded effect removes the Arverni Ally but cannot place the Roman one.
- **A45 unshaded:** up to three non-German Allies in Celtica and within one
  Region of any Intimidated marker, including the marker's own Region. Normal
  Tribe restrictions still apply. Zero placements are legal.

#### A29 fixed troop count reading

“Up to 2 Allies” and “either 5 Warbands or 3 Auxilia” are separate coordinated
noun phrases. The bound directly modifies the first; the second has fixed
numerals. Supplied parallels distinguish local optional counts: A35 unshaded
places one Ally and then up to eight Warbands/four Auxilia; A51 unshaded places
four troops and a Fort, then removes up to six Warbands; base 19 repeats “up
to” on its separate optional branches. §5.1.3 requires the possible fixed
troop effect. Roman Harudes instructions additionally require all three
Auxilia or “No Romans”, restricting normal Available-shortfall execution.
No contrary supplied clarification was found. This is a source reading,
not an official designer clarification or a newly adopted project ruling.

## Implementation review

Initial source conclusions and edge cases were sent to each implementer and
root before code review. Reviewed each final helper, handler integration,
selection owner, defaults, explicit schema, dedicated CLI and relevant tests.
This was a source/code review, not another independent full-suite run; the
implementers and root own frozen-source execution and integration checks.

- **BE-12 cleared:** commit `b17e2f6d8297501c16288cfd5de04ae61b19a774`.
  Implementer reports 39 new cases, 203 focused cases, and all 6,590 full-suite
  tests passing in 118.21 seconds. Reviewed exact target/visibility budgets,
  mandatory total, per-counter replacement choice, Available/stacking fallback,
  current Control after timing interruptions, seeded defaults and the printed
  Belgae effectiveness condition. CLI allows exact nondefault physical pieces
  and mixed removal/replacement. Durable invalid-plan retry, unchanged pending
  decision, journal/save/replay and legal empty-target execution are covered.
- **BE-11 cleared; final combined evidence below:** 84 new cases
  pass. The isolated full suite finished with 6,634 passes and one balance
  canary failure in 114.59 seconds; that failure requires reviewed first-
  divergence evidence before any baseline refresh.
  Reviewed exclusive Alpine piece-type quotas, Avaricum ownership and optional
  effects, Roman Wine branch quotas and assumed-agreement Supply, and Surus
  exact original-piece ledger. Prefix previews defer full mandatory completion
  checks until the corresponding operation tail. Human menus offer legal
  nondefault choices, optional empty selections where printed, and board/b
  inspection on detached planning boards.
- **EXP-09 cleared; final combined evidence below:** 189 focused cases,
  including the first 51 new mechanical/CLI
  cases, pass. Its isolated full suite finished with 6,599 passes and three
  failures in 128.57 seconds: the balance canary, plus two A37 checks requiring
  the historical seed-3 trajectory to reach a specific Event. The implementer
  preserved those A37 semantic assertions in exact parent board fixtures;
  these were independently verified as described below. A29 and A36 delegate
  choices to the named owner;
  the executing seat cannot pre-author another seat's placement plan. Tests
  cover required totals, shortage, exact geographic conjunctions, replacement
  fallback, typed fields, nondefault owner responses, invalid retry, stable
  pending identity, save/replay and detached board/RNG previews. Existing outer
  timing authority is preserved by the normal engine and CLI. The final
  raw/no-frame preview validation uses the original `executing_faction` as its
  fallback authority rather than the beneficiary; reviewed both added rejection
  regressions. A final 58-case focused run passed after these changes.

### Concrete review corrections incorporated

1. Avaricum must remove a selected source Ally even if no legal/Available
   Citadel can replace it. The actual placement now also checks the restricted
   City's faction restriction; otherwise an exceptional Arverni Ally at
   Bibracte could have created an illegal Arverni Citadel. NPC defaults exclude
   removal-only own-Ally upgrades.
2. Roman Wine's Belgae-specific “Belgica Regions first” instruction must
   inform the choice between the controlled and adjacent branches, before
   maximizing other removals. Within a branch, City/Remi and faction priorities
   still apply. Faction targeting uses the shared scenario-aware ordering,
   including Ariovistus's Arverni/German substitution.
3. A45 defaults must benefit the bot's own faction; they cannot fill optional
   slots with foreign Allies after exhausting its own stock. Effectiveness now
   checks an actual own placement. A supplied false piece-type field is
   rejected instead of ignored. An unrelated coastal-pool insertion was
   removed from the change.
4. A43 NPC self-only defaults and effectiveness must distinguish unavailable
   own replacements from actual replacement opportunities for another legal
   recipient. The implementation compares achievable placements under stock
   and stacking limits; if both recipients have no incoming pieces, the
   remaining mandatory removal is still possible. See the source distinction
   below; this does not restrict human recipient selection.

### Shared rejection and discoverability checks

The durable test exposed an engine-level bug: a rejected human Event could
consume its decision even after the handler rolled its board changes back.
The final fix marks genuine structural/execution rejections with
`rejected: true`; `_maybe_execute` returns those human Events to pending.
Unmarked ineffective Events remain playable, preserving the existing test
and the rules. Reviewed marker propagation through structural validation,
missing executable plans, caught execution failures, Event failures and the
malformed `event_params` guard. Bot behavior is unchanged.

**Integration requirement:** retain both BE-11's object-shape guard for every
human Event and BE-12's explicit rejection marker on that guard. The isolated
branches touch this same code. A broad Event rejection rule without the marker
would wrongly reject the established legal-ineffective case.

Reviewed the resolved combined hooks on the frozen 417-file Python source with
SHA256 `29f477d5382d87fac2abc4fe9e93ff4b8ca7abcfbad08e5bd0abb9bff2dfb9b5`:
all three applicability paths, NPC derivation dispatch, dedicated CLI branches,
schema overrides, the global human object guard and its explicit rejection
marker are retained. Root reports 201 focused integration cases passing.
No merge omission or conflict artifact was found in this narrow check.

Delegating card handlers makes AST-only schema discovery incomplete. Explicit
per-card overrides now advertise the legal parameter fields and operation
steps. Dedicated CLI menus handle interdependent choices; relevant NPC/default
derivers provide executable generation paths instead of relying on independent
random form fields. This was inspected alongside the schema regression tests;
the root's integrated diagnostics remain the final reachability check.

### A43 human selection versus NPC benefit policy

Section 5.1.3 expressly operates within selections allowed by the text. A human
may choose the Roman or Aedui recipient and then apply the explicit §5.1.1
removal fallback when that selected counterpart cannot be placed, including
the Roman-at-Bibracte case. The §8.2.3 example separately requires a bot to
maximize the effect while selecting its own benefits; if another recipient
could place more counters, a bot that cannot fulfill the self-only replacement
declines the Event. If neither recipient can place, removal remains the possible
effect. Root accepted this narrow composition of the supplied rules. It is not
a new project ruling or a restriction imported into human legality.

No unresolved source question or new provisional ruling remains from this
scoped review. Protected reference files and rules constants were not edited.
The original isolated failures and old baseline were retained while root
integrated the branches and collected paired-game/first-divergence evidence.
Final refresh clearance after that review is recorded below; no threshold
change is approved or needed.

### A37 historical-position regression review

The old A37 tests assumed the complete seed-3 game would always reach the same
Event decision. Correcting earlier Event outcomes can legitimately invalidate
that premise. Both replacement fixtures contain the exact pre-`_maybe_execute`
position and Aedui decision from untouched parent `8db858b`, with source commit,
scenario, seed, card and faction metadata. Reviewer independently replayed both
parent games in `fs-base-event-before` and compared the entire encoded board and
decision to the saved fixtures: both matched exactly.

The revised tests still exercise `_maybe_execute`, not a hand-written execution
result. They retain successful partial Event execution, the named NP move
refusal, legal-decline census classification and absence of the old “no adjacent
group to move” diagnostic. They additionally assert that the Aedui Ally count
actually increases. This preserves the original semantic regression without
requiring unrelated earlier decisions to follow their old trajectory.

### Combined first-cause review

The first combined matrix passed 150 bot games, 120 mixed/replay cases and 20
census games without hard diagnostics. The unchanged 100-game balance band
failed at a maximum 20 percentage-point difference against its old baseline.
Against the exact batch parent, 50 winner/card-count pairs differ. All 50 saved
first-divergence positions have identical complete pre-states and localize to
this batch's cards (41, 42, 65, A29, A30, A36, A43, A45).

Reviewer independently inspected all 20 base-card first positions:

- Ten Aedui Roman Wine declines correctly enforce the printed restriction to
  human enemy seats; all relevant enemy seats in these games are Non-player.
- Two Belgae Roman Wine declines have no eligible assumed-agreement Supply
  targets.
- Four Roman Wine Roman executions now remove the legal two adjacent enemy
  Allies where the old path removed nothing. Targets obey the scenario's
  German/Arverni faction priority.
- Two Belgae Roman Wine executions correctly select Belgica/Remi before
  competing non-Belgica Allies.
- Two Avaricum executions use genuine seeded equal-choice selection. Great
  Revolt seed 8 changes the chosen legal Citadel from Bituriges to Mandubii;
  Reconquest seed 8 reaches the same board but consumes a previously omitted
  tie-breaking random draw.

Reviewer additionally checked all 13 Card65 predicates directly against raw
Control, German piece counts and exact Allied Tribes: all seven Arverni and
three Aedui positions lack any eligible German target, and all three Belgae
positions lack an eligible German Ally. Their printed Ally/Citadel-gain
condition therefore fails even in the two cases with eligible German Warbands.

For the 17 expansion pairs, reviewer checked all seven A45 decline positions:
six have every geographically eligible Tribe already allied, while the seventh
has no Intimidated Region. Representative complete A29/A30/A36/A43 board deltas
were checked against the source alongside the expansion agent's full group
review: two Allies/five Warbands for A29; all two Arverni Allies for A30; two
Settlements/four Warbands/two Ally removals for A36; and two Allies/two Warbands
for A43, including normal restricted-home removal-only replacement fallback.

A43's one Warband from Mandubii followed by one from Sequani is legal: the card
limits pieces, not Regions, and the Event achieves its full two replacements.
Section 8.3.1's continuation requirement exhausts the selected Region before
selecting another; it does not add a separate largest-stack-first instruction.

No unintended behavior was found in these first causes. This is bounded
first-cause evidence, not a claim that every later decision in a changed game
has been audited. Final A30 correction/source-freeze checks are resolved below.
Failed comparisons remain in the evidence, and comparison thresholds remain
unchanged.

All 50 captured parent rows replay exactly. Three candidate decision payloads
differ only in the order of the old plural `sa_details.trade_regions` metadata
after sorted JSON serialization. Reviewer inspected
`causal-review/metadata-equivalence.json`, its checker and the Trade executor:
execution reads the singular `trade_region`, not that plural metadata. The
checker asserts the frozen source manifest, then compares both following
execution results and full state/RNG from identical snapshots; all three are
equal. This resolves the capture/reload exception without changing production
code or claiming byte-identical payloads.

The expansion author also identified a narrow generic A30 default issue:
§8.3.1 selects Regions by Citadels, Allies, then other pieces; §8.4.1's
Leader-first priority begins only after spaces are selected. Reviewer confirms
the A30 score should follow that distinction. Ordinary Ariovistus trajectories
do not put an Arverni Leader together with A30, but the default should still be
correct in that supplied counterexample. Reviewed and cleared
`exp-a30-priority.patch`: its score is Citadels, Allies, all other Arverni
pieces, and a deliberate Leader-versus-Citadel test failed before and passes
afterward without board/RNG mutation. The implementer's 246 focused cases
pass. Root applied that narrow patch and checked final matrix/output
equivalence while preserving the original traced-source identity.

### Final independent clearance

Final prepared Python source: 417 files, SHA256
`ed4c0d64f358e0f71a3852520d94ee71c6e561a46b8f8a53fc52b1edff23af9f`.
Reviewer compared both manifests: only the reviewed A30 helper and its test
differ from the originally traced source. Reviewed `final-a30-replay.py` and
its result: the script verifies the complete manifest before and after replay,
and both captured A30 executions match their earlier result, complete board and
RNG exactly on final source. Neither input contains an Arverni Leader.

Reviewer independently compared matrix-01 and matrix-02 outputs:

- All 150 bot records match in every game field, including final-state hashes;
  only runtime and correctly attributed source/commit metadata are excluded.
- All six mixed/replay JSON outputs (three card editions, hash seeds 0/7) match
  after removing source metadata.
- Both strict census outputs match after removing source metadata.

**Cleared:** the three repaired findings, merged routing, all reviewed follow-up
corrections, and a documented refresh of the original 100-game balance baseline
at unchanged comparison thresholds. No scoped review blocker remains. The old
failed comparisons and the 100 original-source traces must keep their original
source labels; they are not relabeled as final-source traces. Root owns the
final baseline refresh, complete test run, documentation, commit and push.

### Final evidence and user/API documentation review

Created `final-source-equivalence.json` and `final-source-equivalence.md`
outside the sealed causal-review directory. They preserve input file hashes,
normalized comparison hashes, source manifests, the two-file delta and the
refresh clearance. While creating them, reviewer independently reran both
captured A30 executions on the final source and rechecked all 417 Python file
hashes before and after; results, complete post-states and RNG matched exactly.

Reviewed the root-owned changes to `AGENT_INTERFACE.md`, `PLAYING.md`,
`CHATGPT_README.md`, `README.md`, `BUILD_PLAN.md`, `CHANGELOG.md`,
`docs/README.md`, `docs/current-status.md` and the historical audit's closure
notice against the handlers and source contracts. Two concrete clarifications
were requested and verified in the edited documentation:

- The playing guide now scopes its quantity/area enforcement statement to
  the repaired menus instead of implying all remaining Event audit work is
  complete.
- Card41's API row now requires an executor Ally/Citadel at Avaricum rather
  than ambiguous ownership, explicitly says Control is insufficient, and
  identifies Fort placement as Roman-only.

No other concrete discrepancy was found in those reviewed user/API changes.
Root continues to own final report/progress-register completion and release
checks; this documentation review does not certify unwritten later edits.

### Source-review correction before acceptance

Reviewer initially suggested restricting Card41's Citadel selection to an
actual City and questioned nonexistent native pools. Root applied the explicit
§5.1.1 replacement exception without adding an unstated exception. Reviewer
agrees and retracted the City-only/native-pool restriction: selection may remove
an own Ally where replacement cannot occur, while never placing an illegal
piece. The implementer received this correction and regression requests.
