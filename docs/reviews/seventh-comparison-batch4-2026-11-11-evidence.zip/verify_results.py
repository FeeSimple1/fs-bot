"""Check Batch 4 evidence, paired Event traces, and the reviewed baseline."""

from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
import re
import sys
from xml.etree import ElementTree
from zipfile import ZipFile

from fs_bot import rules_consts as rc
from fs_bot.tools.balance_smoke import _rates
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


def load(path):
    return json.loads(path.read_bytes())


def key(row):
    return row['scenario'], row['seed'], row['card_edition']


def games(raw):
    rows = [json.loads(line) for line in raw.splitlines()]
    keyed = {key(row): row for row in rows}
    assert len(keyed) == len(rows)
    return keyed


def outcomes(rows):
    return {f'{s}|{seed}': dict(winner=row['winner'], cards=row['cards'])
            for (s, seed, _), row in rows.items()}


def balance_games(path):
    rows = re.findall(r'^\[(.+) seed=\s*(\d+)\] winner=(.+) \((\d+) cards\)$',
                      path.read_text(), re.MULTILINE)
    assert len(rows) == 100
    return {f'{scenario}|{seed}': dict(winner=winner, cards=int(cards))
            for scenario, seed, winner, cards in rows}


def explain(row):
    old, new = row['prior'], row['current']
    card = row['card']
    assert (old['card'], old['before'], old['rng_before']) == (
        new['card'], new['before'], new['rng_before'])
    assert old['after'] != new['after'] and old['decisions'] and new['decisions']
    prior = old['effects'][0]
    assert prior['card'] == card and prior['executed']
    if card in (18, 'A18'):
        assert prior['shaded'] and prior['after'] == prior['before'] and not new['effects']
        assert any(c['card'] == card and c['kind'] == 'effectiveness' and c['result'] is False
                   for c in new['checks'])
        return f'Rhenus Bridge {card} declined'
    if card == 28 and any(c['card'] == card and c['kind'] == 'availability'
                          and c['faction'] == prior['faction'] and c['result'] is False
                          for c in new['checks']):
        assert prior['after'] == prior['before']
        return 'Oppida declined'

    current = new['effects'][0]
    assert (current['card'], current['faction'], current['shaded'], current['before']) == (
        card, prior['faction'], prior['shaded'], prior['before'])
    assert current['executed'] and new['plans'] != old['plans']
    if card == 28:
        def citadels(entry):
            return sum(p == [entry['faction'], rc.CITADEL] for p in entry['after'].values())
        if citadels(current) > citadels(prior):
            return 'Oppida additional Citadel'
        assert any(p['rng_before'] != p['rng_after'] for p in new['plans'])
        return 'Oppida tie-break'

    assert prior['before'] == prior['after'] and current['before'] != current['after']
    assert new['plans'][0]['params'] and old['plans'][0]['params'] is None
    if card == 'A19':
        assert not current['shaded']
        choices = {e['tribe'] for e in new['plans'][0]['params']['replacements']}
        assert 1 <= len(choices) <= 3
        assert choices == {t for t in current['before'] if current['before'][t] != current['after'].get(t)}
        return 'Procillus applied replacements'
    assert card == 'A26' and current['shaded']
    for placement in new['plans'][0]['params']['placements']:
        region = placement['region']
        before, after = current['before'][region], current['after'][region]
        assert after['warbands'] - before['warbands'] == placement['count']
        if current['faction'] == rc.GERMANS and before['german_control']:
            assert after['german_control']
    return 'Divico placed Warbands'


def verify_matrix(root, archive, identity, label, edition, seeds):
    path = f'bots-{label}/games.jsonl'
    previous = games(archive.read(path))
    current = games((root / path).read_bytes())
    assert previous.keys() == current.keys() == {
        (scenario, seed, edition) for scenario in SCENARIOS for seed in seeds}
    parent_digest = json.loads(archive.read('source.json'))['source_sha256']
    metadata = load(root / f'bots-{label}/metadata.json')
    assert all(metadata[field] == value for field, value in identity.items())
    assert metadata['hash_seed'] == 0 and metadata['card_edition'] == edition
    differences = {}
    for case, row in current.items():
        assert previous[case]['source_sha256'] == parent_digest
        assert all(row[field] == identity[field] for field in ('commit', 'source_sha256'))
        assert all(row[field] for field in ('completed', 'game_completed',
                                           'audit_completed', 'final_state_sha256'))
        assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row)
        assert len(row['final_ranking']) == len(row['engine_final_ranking']) == 4
        assert all(item['severity'] == 'legal-decline' for item in row['diagnostics'])
        prior = previous[case]
        if row['final_state_sha256'] != prior['final_state_sha256']:
            differences[case] = (prior, row)
        else:
            assert (prior['winner'], prior['cards']) == (row['winner'], row['cards'])
    summary = dict(games=len(current), final_states_changed=len(differences),
                   winners_changed=sum(a['winner'] != b['winner'] for a, b in differences.values()),
                   lengths_changed=sum(a['cards'] != b['cards'] for a, b in differences.values()),
                   interludes=sum(r['interlude_completed'] for r in current.values()))
    return previous, current, differences, summary


def main(evidence):
    root = Path(evidence)
    identity = load(root / 'source.json')
    assert source_identity()['source_sha256'] == identity['source_sha256']
    prior_report = Path('docs/reviews/seventh-comparison-batch3-2026-11-11-evidence.zip')
    with ZipFile(prior_report) as archive:
        prior, legacy, legacy_diff, legacy_counts = verify_matrix(
            root, archive, identity, 'legacy', 'legacy', range(1, 21))
        _, _, second_diff, second_counts = verify_matrix(
            root, archive, identity, 'second', 'second-edition', range(41, 45))

    differences = legacy_diff | second_diff
    trace = load(root / 'first-changes.json')
    assert trace['source'] == identity
    assert len(trace['games']) == len(differences) and {key(r) for r in trace['games']} == differences.keys()
    causes = Counter()
    for row in trace['games']:
        a, b = differences[key(row)]
        assert (row['prior_winner'], row['current_winner']) == (a['winner'], b['winner'])
        causes[explain(row)] += 1

    fuzz0, fuzz987 = (root / 'fuzz0.json').read_bytes(), (root / 'fuzz987.json').read_bytes()
    assert fuzz0 == fuzz987 and (root / 'fuzz0.log').read_bytes() == (root / 'fuzz987.log').read_bytes()
    fuzz = json.loads(fuzz0)
    assert fuzz['games'] == len(fuzz['records']) == 20 and fuzz['hard_findings'] == 0
    assert {key(r) for r in fuzz['records']} == {
        (scenario, seed, 'second-edition') for scenario in SCENARIOS for seed in range(41, 45)}
    assert all(r['game_completed'] and not r['findings'] for r in fuzz['records'])
    assert all(fuzz['metadata'][field] == value for field, value in identity.items())

    before = load(root / 'baseline-prior.json')['games']
    refreshed = load(Path('fs_bot/tools/balance_baseline.json'))['games']
    assert 'FAIL: a faction win rate moved beyond the band.' in (root / 'balance-before.log').read_text()
    assert 'OK: balance within band.' in (root / 'balance.log').read_text()
    assert balance_games(root / 'balance-before.log') == balance_games(root / 'balance.log') == refreshed
    assert before == outcomes(prior) and refreshed == outcomes(legacy)
    assert refreshed.keys() == before.keys()
    updated = {k for k in refreshed if refreshed[k] != before[k]}
    assert updated <= {f'{s}|{seed}' for s, seed, _ in legacy_diff}
    shifts = {}
    for scenario in SCENARIOS:
        rates_before, rates_after = _rates(before, scenario), _rates(refreshed, scenario)
        for faction, rate in rates_before.items():
            shift = rates_after[faction] - rate
            if abs(shift) > Fraction(15, 100):
                shifts[f'{scenario}|{faction}'] = int(shift * 100)
    assert shifts == {f'{rc.SCENARIO_PAX_GALLICA}|{rc.ROMANS}': 25}

    suites = list(ElementTree.parse(root / 'pytest.xml').getroot().iter('testsuite'))
    tests = sum(int(s.attrib['tests']) for s in suites)
    assert tests == 10068 and not any(int(s.attrib.get(k, 0)) for s in suites
                                    for k in ('errors', 'failures', 'skipped'))
    assert '10068 passed' in (root / 'pytest-before.log').read_text()
    assert '25 passed' in (root / 'directed.log').read_text()
    assert '21 failed, 4 passed' in (root / 'parent-regressions.log').read_text()
    assert '451 passed' in (root / 'focused.log').read_text()
    audit = Path('docs/reviews/comparison-audit-round7-2026-11-11-evidence.zip')
    with ZipFile(audit) as archive:
        assert (root / 'audit-before.json').read_bytes() == archive.read('events/probe_events-output.json')

    summary = dict(source=identity, python=fuzz['metadata']['python'], full_tests=tests,
        directed_tests=25, parent_defect_reproductions=21, focused_tests=451,
        paired_outcomes=dict(legacy=legacy_counts, second=second_counts), first_differences=dict(causes),
        mixed_player={k: fuzz[k] for k in ('games', 'human_turns', 'event_turns',
            'events_ok', 'partial', 'hard_findings', 'batch_digest')},
        balance=dict(games=len(refreshed), band=0.15, records_updated=len(updated),
            winners_changed=legacy_counts['winners_changed'], lengths_changed=legacy_counts['lengths_changed'],
            prior_baseline_out_of_band_points=shifts))
    (root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main(sys.argv[1])
