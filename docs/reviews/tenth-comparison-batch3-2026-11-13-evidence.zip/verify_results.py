"""Check the tenth-audit Provincia repair against the recorded parent."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
from xml.etree import ElementTree

from fs_bot import rules_consts as rc
from fs_bot.state.serialize import decode
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


ROOT = Path(__file__).resolve().parent
REPO = Path(__import__('fs_bot').__file__).resolve().parent.parent
PARENT = '6faed3125b53959bada75eb368947eda7f04d99a'
PARENT_DIGEST = '9c5604c6ea038ced05ad35d4b67f7219b15be116f5c685acf178a8eea8a8b833'
BALANCE_ROW = re.compile(r'^\[(.+) seed= *(\d+)\] winner=(.+) \((\d+) cards\)$', re.M)


def load(name):
    return json.loads((ROOT / name).read_bytes())


def check_suites():
    expected = {'parent-untagged': (19, 12), 'directed': (21, 0),
                'directed987': (21, 0), 'focused': (176, 0), 'full': (10329, 0)}
    results = {}
    for name, (tests, failures) in expected.items():
        suite, = ElementTree.parse(ROOT / f'{name}.xml').iter('testsuite')
        counts = {'tests': tests, 'failures': failures, 'errors': 0, 'skipped': 0}
        assert all(int(suite.get(key)) == value for key, value in counts.items()), name
        results[name] = dict(counts, passed=tests - failures, seconds=float(suite.get('time')))
    return results


def read_games(folder, edition, seeds, digest):
    metadata = load(f'{folder}/metadata.json')
    assert metadata['source_sha256'] == digest and metadata['hash_seed'] == 0
    assert metadata['card_edition'] == edition and metadata['seeds'] == list(seeds)
    rows = [json.loads(line) for line in (ROOT / folder / 'games.jsonl').read_text().splitlines()]
    games = {(row['scenario'], row['seed']): row for row in rows}
    assert len(rows) == len(games) == 5 * len(seeds)
    assert set(games) == {(scenario, seed) for scenario in SCENARIOS for seed in seeds}
    for row in rows:
        assert row['source_sha256'] == digest and row['card_edition'] == edition
        assert row['completed'] and row['game_completed'] and row['audit_completed']
        assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row)
        assert len(row['final_state_sha256']) == 64
        assert all(d['severity'] == 'legal-decline' for d in row['diagnostic_occurrences'])
    return games


def compare_games(parent, repair):
    assert parent.keys() == repair.keys()
    changes = [key for key in repair if parent[key]['final_state_sha256']
               != repair[key]['final_state_sha256']]
    return {'games': len(repair), 'changed_final_states': len(changes),
            'changed_winners': sum(parent[key]['winner'] != row['winner']
                                   for key, row in repair.items()),
            'changed_card_counts': sum(parent[key]['cards'] != row['cards']
                                       for key, row in repair.items()),
            'interludes': sum(row['interlude_completed'] for row in repair.values()),
            'diagnostic_occurrences': sum(len(row['diagnostic_occurrences'])
                                          for row in repair.values())}, changes


def check_traces(parent, repair, changed, digest):
    assert not load('trace-second-edition-tasks.json') and not load('trace-mixed-tasks.json')
    traces = [decode(load(f'trace-{side}.json')) for side in ('parent', 'repair')]
    assert [trace['source']['source_sha256'] for trace in traces] == [PARENT_DIGEST, digest]
    assert all(not trace['mixed'] for trace in traces)
    assert [tuple(task[:2]) for task in load('trace-legacy-tasks.json')] == changed
    first_changes = []
    for before, after in zip(*(trace['games'] for trace in traces), strict=True):
        assert before['task'] == after['task']
        key = tuple(after['task'][:2])
        for record, runs in ((before, parent), (after, repair)):
            assert all(runs[key][field] == value for field, value in record['outcome'].items())
        old, new = next((x, y) for x, y in zip(before['quarters'], after['quarters'])
                        if x['after'] != y['after'] or x['result'] != y['result'])
        assert old['before'] == new['before']
        assert old['winter'] == new['winter'] and old['romans']['before'] == new['romans']['before']
        direct = [move[:4] for move in new['romans']['moves'] if move[-1] == 'adjacent']
        assert direct and all(move[2] == rc.PROVINCIA for move in direct)
        first_changes.append({'scenario': key[0], 'seed': key[1], 'winter': new['winter'],
                              'direct_moves': direct,
                              'cards': [before['outcome']['cards'], after['outcome']['cards']],
                              'payment': [r['result']['roman_quartering']['total_cost']
                                          for r in (old, new)]})
    assert len(first_changes) == len(changed) == 3
    return first_changes


def check_balance(repair):
    log = (ROOT / 'balance.log').read_text()
    assert 'OK: balance within band (6 winner changes)' in log
    records = {(s, int(k)): (f, int(n)) for s, k, f, n in BALANCE_ROW.findall(log)}
    assert len(records) == 100
    assert records == {key: (row['winner'], row['cards']) for key, row in repair.items()}
    baseline = json.loads((REPO / 'fs_bot/tools/balance_baseline.json').read_text())['games']
    drift = {}
    for scenario in SCENARIOS:
        old = Counter(baseline[f'{s}|{k}']['winner'] for s, k in records if s == scenario)
        new = Counter(f for (s, _), (f, _) in records.items() if s == scenario)
        drift[scenario] = max(abs(old[f] - new[f]) for f in rc.FACTIONS) * 5
    assert max(drift.values()) == 10
    return {'games': 100, 'largest_shift_points': 10, 'band_points': 15, 'drift_by_scenario': drift}


def check_mixed(digest):
    for extension in ('json', 'log'):
        assert (ROOT / f'fuzz0.{extension}').read_bytes() == (ROOT / f'fuzz987.{extension}').read_bytes()
    current = load('fuzz0.json')
    prior = load('parent-fuzz0.json')
    assert prior['metadata']['source_sha256'] == PARENT_DIGEST
    assert current['metadata']['source_sha256'] == digest
    assert all(current['metadata'][key] for key in ('replay', 'events', 'reactive'))
    assert current['metadata']['card_edition'] == 'second-edition'
    assert current['metadata']['seeds'] == list(range(53, 57))
    assert current['records'] == prior['records']
    assert current['games'] == len(current['records']) == 20 and current['hard_findings'] == 0
    assert all(row['game_completed'] and not row['findings'] for row in current['records'])
    fields = ('games', 'human_turns', 'event_turns', 'events_ok', 'partial', 'hard_findings', 'batch_digest')
    return {key: current[key] for key in fields}


def main():
    source = load('source.json')
    digest = source['source_sha256']
    assert source_identity()['source_sha256'] == digest
    assert source['commit'] == PARENT and source['dirty']
    protected = load('protected-sources.json')
    assert len(protected) == 48
    assert all(hashlib.sha256((REPO / name).read_bytes()).hexdigest() == sha
               for name, sha in protected.items())
    suites = check_suites()
    games = {}
    for edition, seeds in (('legacy', range(1, 21)), ('second-edition', range(53, 57))):
        parent = read_games(f'parent-{edition}', edition, seeds, PARENT_DIGEST)
        repair = read_games(edition, edition, seeds, digest)
        counts, changed = compare_games(parent, repair)
        assert counts['changed_winners'] == 0
        games[edition] = counts
        if edition == 'legacy':
            balance = check_balance(repair)
            changes = check_traces(parent, repair, changed, digest)
        else:
            assert not changed
    result = {'source': source, 'suites': suites, 'bot_games': games, 'first_changes': changes,
              'balance': balance, 'mixed': check_mixed(digest), 'protected_files': len(protected)}
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
