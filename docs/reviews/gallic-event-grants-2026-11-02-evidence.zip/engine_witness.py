"""Same public Event calls against parent/candidate; no patched expectations."""
import json
import sys
sys.path.insert(0, sys.argv[1])
from fs_bot import rules_consts as r
from fs_bot.state.state_schema import build_initial_state, validate_state
from fs_bot.engine.execute import _execute_event
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.board.pieces import place_piece, count_pieces, count_pieces_by_state

for card in (35, 46, 67):
    s = build_initial_state(r.SCENARIO_GREAT_REVOLT, seed=67)
    s['current_card'], s['next_card'] = card, 47
    s['non_player_factions'] = set()
    s['resources'][r.AEDUI] = 0
    s['eligibility'][r.AEDUI] = r.INELIGIBLE
    _ally_tribe(s, r.TRIBE_AEDUI, r.AEDUI)
    _ally_tribe(s, r.TRIBE_SEQUANI, r.AEDUI)
    if card == 67:
        place_piece(s, r.ATREBATES, r.AEDUI, r.WARBAND, 4)
        place_piece(s, r.TREVERI, r.AEDUI, r.WARBAND, piece_state=r.SCOUTED)
    requests = []
    def agent(board, owner, request):
        kind = request.get('request_type')
        requests.append([owner, kind, request.get('max_regions')])
        if kind == 'gallic_event_beneficiary': return {'faction': r.AEDUI}
        if kind == 'gallic_command_order': return {'order': ['limited_command','command']}
        if owner != r.AEDUI: return {'decline': True}
        if kind == 'arduenna_accept': return {'accept': True}
        if kind == 'arduenna_march':
            return {'command':r.CMD_MARCH,'regions':[r.ATREBATES],'sa':'No SA','details':{'march_plan':{
                'origins':[r.ATREBATES],'destinations':[r.TREVERI],
                'routes':{r.ATREBATES:[r.TREVERI]},'groups':{r.ATREBATES:{r.WARBAND:2}}}}}
        if kind == 'arduenna_command':
            return {'command':r.CMD_RAID,'regions':[r.TREVERI],'sa':'No SA',
                    'details':{'raid_plan':[{'region':r.TREVERI,'target':None}]}}
        regions = [r.AEDUI_REGION] if request.get('max_regions') == 1 else [r.AEDUI_REGION,r.SEQUANI]
        return {'command':r.CMD_RALLY,'regions':regions,'sa':'No SA','details':{'rally_plan':{
            'steps':[{'region':region,'action':'place_warbands','count':1} for region in regions]}}}
    s['decision_agent'] = agent
    result = _execute_event(s,r.ROMANS,{'command':'Event','details':{'card_id':card,
        'text_preference':r.EVENT_SHADED,'event_params':{'faction':r.AEDUI}}},human=True)
    print(json.dumps({'card':card,'executed':result['executed'],'reason':result.get('reason'),
        'requests':requests,'aedui_warbands':{region:count_pieces(s,region,r.AEDUI,r.WARBAND)
          for region in (r.AEDUI_REGION,r.SEQUANI,r.ATREBATES,r.TREVERI)},
        'treveri_visibility':{visibility:count_pieces_by_state(s,r.TREVERI,r.AEDUI,r.WARBAND,visibility)
          for visibility in (r.HIDDEN,r.REVEALED,r.SCOUTED)},
        'eligibility':{f:s['eligibility'][f] for f in (r.ROMANS,r.AEDUI)},
        'stay_eligible':s.get('stay_eligible',[]),'state_errors':validate_state(s)}))
