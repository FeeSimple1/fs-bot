# Independent final-source equivalence review

Reviewed 3 November 2026 by `/root/event_validation_review`.

**Passed.** The final A30 correction changes only two Python files, and the final validation results preserve all measured outcomes and state hashes. The documented original 100-game baseline refresh is cleared with the existing thresholds unchanged. This clearance does not waive the final full test suite.

## Source identity

- Original integrated/traced source: `29f477d5382d87fac2abc4fe9e93ff4b8ca7abcfbad08e5bd0abb9bff2dfb9b5` (417 Python files).
- Final source: `ed4c0d64f358e0f71a3852520d94ee71c6e561a46b8f8a53fc52b1edff23af9f` (417 Python files).
- Parent of the repair batch: `8db858b14cd13856059d42db1ad3931e523b5ed4`.
- Only changed Python files: `fs_bot/cards/expansion_validation.py` and `fs_bot/tests/test_expansion_event_validation.py`.

The two-file delta is the reviewed A30 Region-priority correction and its deliberate Leader-versus-Citadel regression. The complete final manifest was independently verified before and after the bounded replay check.

## Independent comparison

| Evidence | Comparison | Result |
|---|---|---|
| Bot legacy | 100 matrix-01/matrix-02 records | Every game field and final-state hash matches |
| Bot original edition | 25 records | Every game field and final-state hash matches |
| Bot second edition | 25 records | Every game field and final-state hash matches |
| Mixed/replay | Six outputs: 30 distinct cases, 120 executions including hash repeat and replay | Identical excluding source metadata |
| Strict census | Two outputs, 20 executions | Identical excluding source metadata |
| Captured A30 | Ariovistus and Gallic War seed 18 | Independently rerun on final source: exact result, complete post-state and RNG |

Bot comparisons exclude only runtime, source SHA and commit metadata. They explicitly verify the original/final source labels before comparing all other fields. Mixed/replay and census comparisons remove only their top-level metadata. Exact input file hashes, normalized comparison hashes and source-file delta hashes are recorded in `final-source-equivalence.json`.

## Baseline-refresh clearance

All 50 earliest parent/candidate divergences were checked against the supplied rules and localized to the repaired cards. Final source differs only by the reviewed A30 correction, and the matrix and bounded replay comparisons above show the measured outcomes are unchanged. A documented refresh of the original 100-game baseline is therefore cleared at its unchanged 0.15 band; the existing 15-game canary's 0.40 band also remains unchanged.

Preserve the old failed comparisons and baseline hash `207a129589d2bb17bec17319e70de7c8cf44d1572dc6aaca73cd0b39a9b5b8d3`. Preserve all 100 sealed original-source traces under their original source identity; these comparisons do not relabel them as final-source traces.

Three candidate captured decision payloads have different ordering in unused plural Trade metadata after sorted JSON reload. The separate `causal-review/metadata-equivalence.json` proves identical next execution results and complete state/RNG for those exceptions. First-divergence review does not claim that every downstream move was individually audited. Root owns baseline refresh, the final full test suite, documentation, commit and push.
