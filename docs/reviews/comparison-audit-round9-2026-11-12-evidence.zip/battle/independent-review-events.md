# Independent review: ninth-audit Event lane

Reviewer lane: battle. Audited Falling Sky commit `f4c8372c396981c0a31dc6f4545e67f8c6f2e981`.

**Disposition: approve the three bounded mechanisms in the corrected Event probe.** No engine or reference changes were made in this review.

Read the entire corrected `events/probe_events.py`, its output, the applicable source clauses, the actual producers/handlers/effectiveness consumers and comparison ledgers through round eight. Reran the corrected probe independently with `PYTHONHASHSEED=123` and `PYTHONPATH=.` using the repository `.venv/bin/python`. All assertions and pre/post census and structural checks passed, and its parsed JSON exactly matches the Event lane's hash-0 output. Independent output is `independent-events-output.json`. Reviewed probe SHA-256: `f1b2f1b84b3ffa2ad3667f2b26df8d317178872929988403d765a08d44bde839`.

## A40 placement priorities

A Card Reference A40 (lines196–205) expressly permits an Ally as an alternative to Auxilia/Warbands in each of three Regions near Cisalpina. Chapter8 lines120–132 and149–157 require self-benefit and prioritize Allies before other pieces. The reviewed sparse Ariovistus boards have at least three legal Subdued Tribal targets and sufficient own Allies. They are valid constructed positions, not claimed naturally sampled games.

Unmodified dispatch chooses A40 for Romans/Aedui. The public executor places six Auxilia or nine Warbands and no Allies, while an explicitly supplied source-permitted three-Ally plan succeeds on the same initial board. With every own mobile counter already on the map, dispatch still selects A40 and execution does nothing despite those same available Ally placements. The case with every nearby Tribe already Allied correctly places Warbands, isolating the missing Ally priority rather than proposing universal Ally placement. The specific three Ally locations in the control prove an available maximum; they do not claim those tied locations are uniquely mandated.

The cause is `_derive_card_A40` (`fs_bot/engine/execute.py:6382`), which imports and selects only Auxilia/Warbands and never enters an Ally branch. The public handler already supports the Ally alternative (`fs_bot/cards/card_effects.py:3276`). This is not BE7-01's Oppida second-step Citadel opportunity nor BE6-02's A35/A60 missing parameters.

## Numeric33 Lost Eagle effectiveness

Card Reference numeric33 (lines327–336) requires both a Fallen Legion and a Region already containing a Legion plus a non-Aedui Warband. Chapter8 lines30–37 requires declining an Event that cannot affect the current board. The handler (`fs_bot/cards/card_effects.py:1402`) correctly returns without placement when these prerequisites fail. The ordinary effectiveness path lacks this exact shared condition (`fs_bot/cards/event_eval.py:985` onward; generic placement flag around lines1131–1136).

The corrected probe covers no Fallen Legion, no eligible co-location, and only an Aedui Warband in both Great Revolt and Reconquest. Public Roman dispatch picks and executes an unchanged-board Event in each case, even though disabling only Event availability yields a non-Pass Recruit continuation. Supplying the missing prerequisite makes the same public path place one Fallen Legion. An untouched physical Pax setup, with only current-card/seat metadata set, also selects the no-op.

**Reachability correction made during review:** Numeric33 is replaced by A33 in Ariovistus/Gallic War's first half. The initial expansion examples were rejected as deck-unreachable and removed; the frozen corrected probe uses only Great Revolt, Reconquest and Pax. This is independent of WS3-02's shaded Lost Eagle Senate-window defect and of the eighth audit's numeric3/numeric5 removal prerequisites.

## A40 ignores active A5 Roman-only Cisalpina stacking

A Card Reference A5 lines9–13 makes Cisalpina Roman-only. Chapter5 lines33–36 requires an Event to explicitly change stacking to override it. A40 supplies a geographic placement area, not an express stacking override. Section5.1.2 current-Event precedence does not turn every broad placement area into such an explicit stacking change.

The probe actually executes A5, then A40. The public Aedui bot places three Warbands in Cisalpina even though the production state-aware geography query says the Region is not playable by Aedui. A direct authored A40 placement is accepted too. The identical plan with A5 absent is legal; Roman Auxilia under active A5 are legal; Aedui placements in the other three eligible Regions remain available. All physical counts and structural checks remain clean, so they do not enforce this particular stacking rule.

The producer uses scenario-only geography (`fs_bot/engine/execute.py:6390`), and the handler checks proximity but not the physical recipient's state-aware access (`fs_bot/cards/card_effects.py:3258`–3284). This newly witnessed A40 consumer is distinct from BE5-02 Colony placement and BE5-03 Forced Marches geography. Repair should cover bot planning and public validation, preserving ordinary Cisalpina access when A5 is absent and Roman placement while it is active.

## Limits

These witnesses establish the specified mechanisms and their controls. They are not encounter-frequency or balance measurements and do not establish comprehensive Event coverage. No extra finding is counted for each scenario or each unmet Lost Eagle prerequisite. The shadow `_derive_event_params` read in the probe is diagnostic; the defect witness itself uses unmodified public bot dispatch and `execute_decision`, not a manually injected bad bot plan.
