"""Verify the sixth comparison Batch 5 evidence against the two audited trees."""

from collections import Counter
import json
from pathlib import Path
import re
import sys
from xml.etree import ElementTree
from zipfile import ZipFile

from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


def load(path):
    return json.loads(path.read_bytes())


def jsonl(raw):
    return [json.loads(line) for line in raw.splitlines()]


def key(row):
    return row['scenario'], row['seed'], row['card_edition']


def balance_games(path):
    matches = re.findall(r'^\[(.+) seed=\s*(\d+)\] winner=(.+) \((\d+) cards\)$',
                         path.read_text(), re.MULTILINE)
    assert len(matches) == 100
    return {f'{scenario}|{seed}': dict(winner=winner, cards=int(cards))
            for scenario, seed, winner, cards in matches}


def main(root):
    evidence = Path(root)
    identity = load(evidence / 'source.json')
    assert source_identity()['source_sha256'] == identity['source_sha256']
    b4_report = Path('docs/reviews/sixth-comparison-batch4-2026-11-11-evidence.zip')
    paired, trace_checks = {}, Counter()
    with ZipFile(b4_report) as archive:
        for label, edition, seeds in (('legacy', 'legacy', range(1, 21)),
                                       ('second', 'second-edition', range(41, 45))):
            filename = f'bots-{label}/games.jsonl'
            parent = {key(row): row for row in jsonl(archive.read('final/' + filename))}
            rows = jsonl((evidence / filename).read_bytes())
            current = {key(row): row for row in rows}
            assert len(rows) == len(current) == len(SCENARIOS) * len(seeds)
            assert parent.keys() == current.keys() == {
                (scenario, seed, edition) for scenario in SCENARIOS for seed in seeds}
            for row in rows:
                assert row['commit'] == identity['commit']
                assert row['source_sha256'] == identity['source_sha256']
                assert all(row[field] for field in ('completed', 'game_completed', 'audit_completed'))
                assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row)
                assert all(item['severity'] == 'legal-decline' for item in row['diagnostics'])
                assert row['final_state_sha256']

            changed = {case for case, row in current.items()
                       if row['final_state_sha256'] != parent[case]['final_state_sha256']}
            trace = load(evidence / f'first-changes-{label}.json')
            assert trace['source'] == identity
            assert {key(row) for row in trace['games']} == changed
            for row in trace['games']:
                case = key(row)
                assert (row['prior_winner'], row['current_winner']) == (parent[case]['winner'], current[case]['winner'])
                assert row['same_start'] and row['same_rng'] and row['checks']
                trace_checks.update(check['check'] for check in row['checks'])
            paired[label] = dict(games=len(rows), final_boards_changed=len(changed),
                winners_changed=sum(row['winner'] != parent[case]['winner'] for case, row in current.items()),
                interludes=sum(row['interlude_completed'] for row in rows))

    fuzz0, fuzz987 = (evidence / 'fuzz0.json').read_bytes(), (evidence / 'fuzz987.json').read_bytes()
    assert fuzz0 == fuzz987
    assert (evidence / 'fuzz0.log').read_bytes() == (evidence / 'fuzz987.log').read_bytes()
    fuzz = json.loads(fuzz0)
    assert fuzz['games'] == len(fuzz['records']) == 20 and fuzz['hard_findings'] == 0
    assert fuzz['metadata']['source_sha256'] == identity['source_sha256']

    audited_games = {f"{row['scenario']}|{row['seed']}": dict(winner=row['winner'], cards=row['cards'])
                     for row in jsonl((evidence / 'bots-legacy/games.jsonl').read_bytes())}
    baseline = load(Path('fs_bot/tools/balance_baseline.json'))['games']
    assert balance_games(evidence / 'balance.log') == balance_games(evidence / 'prior-balance-check.log') == baseline == audited_games
    assert 'OK: balance within band.' in (evidence / 'balance.log').read_text()
    assert 'FAIL: a faction win rate moved beyond the band.' in (evidence / 'prior-balance-check.log').read_text()
    previous = load(evidence / 'prior-balance-baseline.json')['games']
    assert previous.keys() == baseline.keys()

    tests = ElementTree.parse(evidence / 'pytest.xml').getroot().find('testsuite').attrib
    assert int(tests['tests']) == 9991
    assert not any(int(tests[field]) for field in ('errors', 'failures', 'skipped'))
    assert '15 passed' in (evidence / 'directed.log').read_text()
    assert '9 failed, 6 passed' in (evidence / 'parent-regressions.log').read_text()

    output = dict(source=identity, full_tests=int(tests['tests']), directed_tests=15,
                  parent_defect_reproductions=9, paired_outcomes=paired,
                  first_divergence_checks=dict(trace_checks),
                  mixed_player={k: fuzz[k] for k in ('games', 'human_turns', 'event_turns',
                                                     'events_ok', 'partial', 'hard_findings', 'batch_digest')},
                  balance=dict(games=len(baseline), band=0.15,
                               winners_changed_from_prior_baseline=sum(
                                   row['winner'] != previous[case]['winner'] for case, row in baseline.items())))
    (evidence / 'summary.json').write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps(output, indent=2))


if __name__ == '__main__':
    main(sys.argv[1])
