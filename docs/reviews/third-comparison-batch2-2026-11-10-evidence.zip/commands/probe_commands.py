"""Round 3 command witnesses. Assertions freeze defects at 3c23a34.

Usage: python probe_commands.py /path/to/fs-bot
No gameplay code is changed. All starting boards pass census + structural checks.
"""
import json
import sys
from copy import deepcopy
from pathlib import Path

sys.path.insert(0, str(Path(sys.argv[1]).resolve()))
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import (
    clear_allied_tribe, count_pieces, count_pieces_by_state, move_piece,
    place_piece, remove_piece,
)
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_COMMAND, ACTION_COMMAND_SA
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import check_structural_integrity, validate_state
from fs_bot.tools.seat_session import validate_response


def position():
    state = setup_scenario(rc.SCENARIO_GREAT_REVOLT, seed=1)
    state['non_player_factions'] = set()
    return state


def clean(state):
    assert validate_state(state) == [], validate_state(state)
    assert check_structural_integrity(state) == [], check_structural_integrity(state)


def run(state, faction, action, action_type=ACTION_COMMAND):
    clean(state)
    submitted = {'action': action_type, 'player_action': action}
    accepted = validate_response(state, {'kind': 'turn', 'faction': faction,
                                         'options': [action_type]}, submitted)
    assert accepted == submitted
    result = execute_decision(state, faction, submitted)
    assert result['executed'] and not result.get('errors'), result
    assert validate_state(state) == [], validate_state(state)
    return result


def battle(region, defender, **extras):
    return {'command': rc.CMD_BATTLE, 'sa': 'No SA', 'regions': [region],
            'details': {'battle_plan': [{'region': region, 'target': defender}], **extras}}


def scout_nonregion():
    state = position()
    # Untouched scenario position. No Gallia Togata capability/Event is active.
    assert not state['capabilities']
    action = {'command': rc.CMD_SEIZE, 'sa': rc.SA_SCOUT, 'sa_timing': 'before',
              'regions': [rc.PROVINCIA], 'details': {
                  'disperse_tribes': {rc.PROVINCIA: []},
                  'scout_plan': {'auxilia_moves': [{
                      'from_region': rc.PROVINCIA, 'to_region': rc.CISALPINA,
                      'count': 1, 'piece_state': rc.HIDDEN}], 'scout_targets': []}}}
    result = run(state, rc.ROMANS, action, ACTION_COMMAND_SA)
    assert result['sa_execution']['executed']
    assert count_pieces(state, rc.CISALPINA, rc.ROMANS, rc.AUXILIA) == 1
    clean(state)  # Integrity checks also fail to notice the nonplayable Region.
    return {'result': result, 'illegal_cisalpina_auxilia': 1,
            'census_errors': validate_state(state), 'structural_errors': check_structural_integrity(state)}


def entreat_city_citadel():
    state = position()
    # Controlled, census-valid position: Belgic Citadel at Sequani plus an
    # actual Belgic Ally disc at Helvetii in the same Region.
    for tribe in (rc.TRIBE_SEQUANI, rc.TRIBE_HELVETII):
        remove_piece(state, rc.SEQUANI, rc.ARVERNI, rc.ALLY)
        clear_allied_tribe(state, rc.SEQUANI, rc.ARVERNI, rc.ALLY, tribe=tribe)
    place_piece(state, rc.SEQUANI, rc.BELGAE, rc.CITADEL)
    state['tribes'][rc.TRIBE_SEQUANI]['allied_faction'] = rc.BELGAE
    place_piece(state, rc.SEQUANI, rc.BELGAE, rc.ALLY)
    state['tribes'][rc.TRIBE_HELVETII]['allied_faction'] = rc.BELGAE
    move_piece(state, rc.CARNUTES, rc.SEQUANI, rc.ARVERNI, rc.LEADER)
    place_piece(state, rc.SEQUANI, rc.ARVERNI, rc.WARBAND, 5, piece_state=rc.HIDDEN)
    initial = deepcopy(state)
    action = {'command': rc.CMD_RAID, 'sa': rc.SA_ENTREAT, 'sa_timing': 'before',
              'sa_regions': [{'region': rc.SEQUANI, 'action': 'replace_ally',
                              'target_faction': rc.BELGAE, 'tribe': rc.TRIBE_SEQUANI}],
              'details': {'raid_plan': [{'region': rc.SEQUANI, 'target': None}]}}
    result = run(state, rc.ARVERNI, action, ACTION_COMMAND_SA)
    assert result['sa_execution']['executed']
    assert count_pieces(state, rc.SEQUANI, rc.BELGAE, rc.CITADEL) == 1
    assert count_pieces(state, rc.SEQUANI, rc.BELGAE, rc.ALLY) == 0
    assert state['tribes'][rc.TRIBE_SEQUANI]['allied_faction'] == rc.ARVERNI
    assert state['tribes'][rc.TRIBE_HELVETII]['allied_faction'] == rc.BELGAE
    assert check_structural_integrity(state) == ['Sequani/Belgae: Citadel has no matching allied City Tribe']
    # Positive control: selecting the actual Ally disc is legal and consistent.
    legal = deepcopy(action)
    legal['sa_regions'][0]['tribe'] = rc.TRIBE_HELVETII
    legal_result = run(initial, rc.ARVERNI, legal, ACTION_COMMAND_SA)
    clean(initial)
    assert initial['tribes'][rc.TRIBE_SEQUANI]['allied_faction'] == rc.BELGAE
    assert initial['tribes'][rc.TRIBE_HELVETII]['allied_faction'] == rc.ARVERNI
    return {'result': result, 'tribes': {t: state['tribes'][t] for t in
            (rc.TRIBE_SEQUANI, rc.TRIBE_HELVETII)}, 'structural_errors': check_structural_integrity(state),
            'legal_helvetii_control': legal_result}


def battle_absent_attacker():
    state = position()
    assert count_pieces(state, rc.MORINI, rc.ROMANS) == 0
    before = state['resources'][rc.ROMANS]
    assert count_pieces_by_state(state, rc.MORINI, rc.BELGAE, rc.WARBAND, rc.HIDDEN) == 4
    result = run(state, rc.ROMANS, battle(rc.MORINI, rc.BELGAE))
    assert state['resources'][rc.ROMANS] == before - 2
    assert count_pieces_by_state(state, rc.MORINI, rc.BELGAE, rc.WARBAND, rc.HIDDEN) == 0
    assert count_pieces_by_state(state, rc.MORINI, rc.BELGAE, rc.WARBAND, rc.REVEALED) == 4
    clean(state)
    return {'result': result, 'roman_forces': count_pieces(state, rc.MORINI, rc.ROMANS),
            'roman_resources_before': before, 'roman_resources_after': state['resources'][rc.ROMANS],
            'belgic_hidden_before': 4, 'belgic_hidden_after': 0, 'belgic_revealed_after': 4}


def forged_battle_powers():
    initial = position()
    move_piece(initial, rc.BITURIGES, rc.TREVERI, rc.AEDUI, rc.WARBAND, 4, piece_state=rc.HIDDEN)
    place_piece(initial, rc.TREVERI, rc.GERMANS, rc.WARBAND, 6, piece_state=rc.HIDDEN)
    observations = []
    for extra, expected in (({}, 6), ({'warband_full_loss': True}, 4),
                            ({'allied_factions': [rc.AEDUI, rc.AEDUI]}, 2)):
        state = deepcopy(initial)
        result = run(state, rc.AEDUI, battle(rc.TREVERI, rc.GERMANS, **extra))
        remaining = count_pieces(state, rc.TREVERI, rc.GERMANS, rc.WARBAND)
        assert remaining == expected
        clean(state)
        observations.append({'injected': extra, 'result': result, 'german_warbands_before': 8,
                             'german_warbands_after': remaining})

    # The other two exposed flags override the defender's actual declaration.
    initial = position()
    move_piece(initial, rc.BITURIGES, rc.SEQUANI, rc.AEDUI, rc.WARBAND, 4, piece_state=rc.HIDDEN)
    place_piece(initial, rc.SEQUANI, rc.ARVERNI, rc.WARBAND, 4, piece_state=rc.HIDDEN)
    for answer, extras in ((False, {}), (False, {'force_retreat': True}),
                           (True, {}), (True, {'no_retreat': True})):
        state = deepcopy(initial)
        seen = []
        def agent(board, owner, request):
            if request['kind'] == 'agreement':
                return False
            if request['kind'] == 'retreat':
                seen.append({'owner': owner, 'request': deepcopy(request), 'answer': answer})
                return {'retreat': answer, 'region': None}
            return None
        state['decision_agent'] = agent
        result = run(state, rc.AEDUI, battle(rc.SEQUANI, rc.ARVERNI, **extras))
        remaining = count_pieces(state, rc.SEQUANI, rc.ARVERNI, rc.WARBAND)
        clean(state)
        if extras.get('no_retreat'):
            assert seen == [] and remaining == 3
        elif extras.get('force_retreat'):
            assert seen and not seen[0]['answer'] and remaining == 0
        else:
            assert seen and remaining == (0 if answer else 3)
        observations.append({'injected': extras, 'defender_requested_retreat': answer,
                             'declaration_requests': len(seen), 'arverni_warbands_after': remaining,
                             'result': result})
    return observations


result = {'CM3-01': scout_nonregion(), 'CM3-02': entreat_city_citadel(),
          'CM3-03': battle_absent_attacker(), 'CM3-04': forged_battle_powers()}
print(json.dumps(result, indent=2, sort_keys=True))
