import json
from pathlib import Path
out=Path(__file__).parent
findings=[
 {
 'id':'BE4-01','title':'Shaded Hostages accepts mismatched Tribe/Region and a non-Gallic Ally recipient','severity':'high','status':'confirmed',
 'expected':'Card 22 shaded places a Gallic Ally and any one Warband at each of one or two Subdued Tribes in Regions containing Roman pieces. Tribe and Region must identify the same place, and the Ally must be Arverni, Aedui, or Belgic.',
 'observed':'Accepted target Catuvellauni plus supplied Region Provincia allies Catuvellauni in empty Britannia to Belgae while placing the Warband in Provincia. A separate accepted Helvii target with faction Romans places a Roman Ally despite the Gallic restriction. The legal Helvii/Provincia/Belgae control places both pieces together.',
 'rule_sources':[{'path':'Reference Documents/Card Reference','lines':'219-224','rule':'Card 22 shaded'}, {'path':'Reference Documents/Chapter 5','lines':'5-13','rule':'5.1 literal Event execution'}],
 'code_sources':[{'path':'fs_bot/cards/card_effects.py','lines':'1062-1088','issue':'reads supplied region and tribe independently; never restricts Ally faction'}],
 'newness':'Earlier BE-06/07/08 Hostages work and base-piece-choices report covered unshaded physical removal/replacement choices. Original inventory base-22-*-shaded was marked supported. BE-11 was specifically 40/41/42/51. No previous closed group reported 22 shaded target geography or Ally owner.',
 'witness':'witness.py hostages()','observations':'observed.json editions.{original,second-edition}.BE4-01',
 'fixture':'Great Revolt setup seed 4, remove Helvii Roman Ally via _unally_tribe to create legal Subdued target; Roman garrison stays in Provincia; Britannia has zero Romans.',
 'validation':'All three authored turn paths pass durable validation and detached preview, preserve preview board/RNG, execute, and have clean pre/post census and structure.'
 },
 {
 'id':'BE4-02','title':'Celtic Rites applies repeated Resource losses and permits omitting its mandatory target','severity':'high','status':'confirmed',
 'expected':'Card 46 unshaded selects one or more distinct Gallic Factions; each selected Faction loses three Resources once and is Ineligible through next card.',
 'observed':'With Arverni at 20 Resources, target_factions=[Arverni,Arverni] is accepted and reduces Resources to 14. The single-entry control leaves17. An empty list executes successfully without affecting any faction, despite legal targets.',
 'rule_sources':[{'path':'Reference Documents/Card Reference','lines':'459-466','rule':'Card 46 unshaded'}, {'path':'Reference Documents/Chapter 5','lines':'52-54','rule':'5.1.3 mandatory attainable effects'}],
 'code_sources':[{'path':'fs_bot/cards/card_effects.py','lines':'1792-1800','issue':'iterates raw repeated target list without minimum or uniqueness'}],
 'newness':'Prior BE2-02 was specifically Assembly of Gaul52 and its duplicate drain, now repaired. BE-03 concerned Celtic Rites shaded beneficiary/eligibility. Original 46 unshaded inventory rows were supported; this is a separate still-open card-specific consumer of that repeated-selection family.',
 'witness':'witness.py celtic_rites()','observations':'observed.json editions.{original,second-edition}.BE4-02',
 'fixture':'Great Revolt setup seed4; Arverni Resources set to20, all-human seats.',
 'validation':'Durable turn acceptance, successful isolated preview and execution; pre/post census and structure clean. Empty target recorded alongside duplicate rather than counted separately.'
 },
 {
 'id':'BE4-03','title':'Druids ignores beneficiary restrictions, distinctness, initiative order and mandatory Commands','severity':'high','status':'confirmed',
 'expected':'Card48 selects one to three distinct Gallic Factions, which execute one free Limited Command each in printed Aedui-Arverni-Belgae order. Possible Commands cannot be waived as optional.',
 'observed':'An accepted Roman target gets free Recruit and places an Auxilia. Repeating Aedui gives two free Rally Commands and two new Warbands instead of the control one. [Belgae,Aedui,Arverni] executes in submitted order. Empty targets in an all-human state commit no grant; a selected Aedui can explicitly decline even though the legal control Rally is available.',
 'rule_sources':[{'path':'Reference Documents/Card Reference','lines':'478-485','rule':'Card48'}, {'path':'Reference Documents/Chapter 5','lines':'5-13,52-54','rule':'5.1 and5.1.3'}],
 'code_sources':[{'path':'fs_bot/cards/card_effects.py','lines':'1848-1857','issue':'copies arbitrary target list into modifier'}, {'path':'fs_bot/engine/execute.py','lines':'2065-2075','issue':'raw target order/duplicates/non-Gallic factions and optional generic free Command'}, {'path':'fs_bot/engine/execute.py','lines':'927-974','issue':'allow_decline defaults true and is not disabled by Druids'}],
 'newness':'Original base-48 inventory rows marked supported with no finding. Earlier Command duplicate fixes govern Regions, not distinct Event beneficiaries. Council47 has explicit validators and initiative normalization but Druids48 does not. Previous BE-03 covers35/46/67/68, not48.',
 'witness':'witness.py druids()','observations':'observed.json editions.{original,second-edition}.BE4-03',
 'fixture':'Unchanged Great Revolt setup seed4 with all-human seats; callback supplies a legal one-piece Recruit/Rally in own normal Region.',
 'validation':'Seven accepted cases per edition, including positive single-target and printed-order controls; all pre/post census and structure checks clean. No claim about whose eligibility the final sentence affects.'
 },
 {
 'id':'BE4-04','title':'Shaded Germanic Horse can be gifted to a different Faction instead of the Gallic executor','severity':'high','status':'confirmed',
 'expected':'Card59 shaded says If Gallic, take this card. The Gallic executing Faction takes it; the Event does not authorize selecting another beneficiary.',
 'observed':'Belgae executing59S with faction=Aedui makes Aedui the recorded owner. Roman executor can also award it to Aedui. A subsequent ordinary Aedui Battle with four Warbands removes four of eight German Warbands. The legal Belgic self-acquisition control removes only two in the same Aedui Battle.',
 'rule_sources':[{'path':'Reference Documents/Card Reference','lines':'602-617','rule':'Card59 shaded and combat Tip'}, {'path':'Reference Documents/Chapter 5','lines':'5-13','rule':'5.1 literal Event recipient'}],
 'code_sources':[{'path':'fs_bot/cards/card_effects.py','lines':'2162-2177','issue':'accepts arbitrary Gallic faction parameter as Capability owner'}],
 'newness':'BE-09 and Horse5November repairs cover owner-scoped Battle Region decisions, activation timing, and Fort/Abatis limits. EX3-04 covers Stalwart cancellation. Neither covers how59S is acquired. Original inventory correctly described If Gallic executor takes Capability, but tied its reported gap to BE-09 Region choice only.',
 'witness':'witness.py germanic_horse()','observations':'observed.json editions.{original,second-edition}.BE4-04',
 'fixture':'Great Revolt setup seed4; use Available pools to place4 Aedui and8 German Warbands at Pictones; all-human seats. Base Germans do not Retreat.',
 'validation':'Accepted Event and succeeding ordinary Battle on both editions. Owner changes flow into actual casualty count. Before/after census and structural checks clean.'
 }
]
(out/'findings.json').write_text(json.dumps(findings,indent=2)+'\n')
coverage={
 'partition':'Base Event handlers, revised base cards, planning and human choices',
 'audited_commit':'b951908af2b21cc87a7e27d9a5314b3f257d0147',
 'rules_authority':'Supplied Reference Documents/Card Reference, Chapter5; adopted rulings reviewed, none changes these findings.',
 'comparator':{'repository':'FeeSimple1/lod-bot','path':'/workspace/scratch/4efb99cfe9ce/lod-bot-comparison','materials':['coin-implementation-lessons.md sections B,C,D,F,G','lod_ai/event_choices.py collection-layer ownership, exact count and option predicates'], 'use':'Engineering search patterns only. Compared beneficiary ownership, printed list cardinality, exact physical location and downstream effect consumers.'},
 'prior_review':['docs/human-choice-progress.json','docs/reviews/human-choice-audit-2026-10-29-inventory.json relevant base22/46/48/59 rows','docs/reviews/comparison-audit-2026-11-10.json','docs/reviews/comparison-audit-round3-2026-11-10.json','docs/reviews/event-validation-2026-11-03.md','docs/reviews/horse-choice-2026-11-05.md','docs/current-status.md'],
 'source_inventory':'Enumerated all Reference Documents files before targeted reading.',
 'static_review':'Scanned base Event handlers1-72, corresponding direct-effect printed clauses and related delegated helpers. Focused on still-unwrapped direct target lists and mistaken generalized ownership. This is not full per-card-state proof.',
 'dynamic_coverage':{'editions':['original','second-edition'],'scenario':'The Great Revolt','seed':4,'total_cases':32,'by_group':{'BE4-01':6,'BE4-02':6,'BE4-03':14,'BE4-04':6}},
 'rejected_or_unclaimed':[
  {'lead':'Card64 shaded could replace an occupied third Allied Tribe', 'disposition':'Rejected: _ally_tribe rejects already Allied or Dispersed circles; it does not implicitly replace.'},
  {'lead':'Card48 eligibility of all beneficiaries', 'disposition':'Not claimed: final Become Eligible wording versus executor interpretation is outside these witnesses; no new ruling invented.'},
  {'lead':'Card52 shaded second Special Ability', 'disposition':'Handed to frontend partition. Existing QUESTIONS records single-SA as correct NP flowchart behavior; human second-SA may remain distinct.'},
  {'lead':'General omitted-target no-ops in direct Event handlers', 'disposition':'Not exhaustively promoted. Only verified46 and48 omission cases included within their already-confirmed card groups.'},
  {'lead':'Razed/Colony and earlier mandatory expansion effects', 'disposition':'Previous rounds repaired these; not recounted.'},
  {'lead':'Circumvallation persistence', 'disposition':'Known followup excluded.'}
 ],
 'artifacts':{'final_script':'witness.py','final_output':'observed.json','findings':'findings.json','exploratory':['probe.py','probe-initial.json','probe-second.json','probe-third.json','horse-probe.py','horse-probe.json']},
 'exploratory_note':'First two generic Druids probes used wrong action labels then lacked legitimate Rally/Recruit prerequisites. These are preserved distinctly; final witness uses real setup and legal exact actions. No engine failure was claimed from those fixture errors.',
 'reproduce':'cd <audited-repo> && PYTHONPATH=. python <evidence-dir>/witness.py',
 'production_changes':False,
 'limits':'Controlled public-API witnesses, not whole-game frequency estimates. No web sources, no reference modifications, and no proposed fixes implemented.'
}
(out/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
