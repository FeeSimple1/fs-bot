"""Trace the changed legacy Gallic War games through the normal batch runner."""

import argparse
import hashlib
import json

from fs_bot import rules_consts as rc
from fs_bot.engine.victory import check_any_victory
from fs_bot.state.serialize import encode
from fs_bot.tools import run_batch
from fs_bot.tools.validation_metadata import source_identity


def digest(value):
    return hashlib.sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def snapshot(state):
    return {key: value for key, value in state.items() if key != 'decision_agent'}


def trace(seed):
    cards = []
    play = run_batch.play_card

    def record(state, *args, **kwargs):
        card = state['current_card']
        row = {
            'number': len(cards) + 1, 'card': card,
            'before_sha256': digest(snapshot(state)),
            'before_rng_sha256': digest(state['rng'].getstate()),
        }
        if card == rc.WINTER_CARD:
            row.update(winter_count_before=state['winter_count'],
                       remaining_winters=state['deck'].count(rc.WINTER_CARD),
                       threshold_winner_before=check_any_victory(state))
        result = play(state, *args, **kwargs)
        after = snapshot(state)
        row.update(after_sha256=digest(after), game_over=result['game_over'],
                   winner=result.get('winner'))
        if card == rc.WINTER_CARD:
            winter = result['winter_result']
            row.update(is_final=winter['is_final'],
                       phases=list(winter['winter_result']['phases']))
            cached = after.get('_resolved_card')
            if cached:
                after['_resolved_card'] = {
                    **cached, 'winter_result': {**cached['winter_result'], 'is_final': None},
                }
            row['after_without_finality_sha256'] = digest(after)
        cards.append(row)
        return result

    run_batch.play_card = record
    try:
        result = run_batch.play_one((rc.SCENARIO_GALLIC_WAR, seed, 'legacy'))
    finally:
        run_batch.play_card = play
    assert result['completed'] and result['audit_completed'], result['errors']
    assert cards[-1]['after_sha256'] == result['final_state_sha256']
    return {'seed': seed, 'cards': cards, 'outcome': {
        key: result[key] for key in ('winner', 'cards', 'winters', 'termination',
                                     'ended_on_final_winter', 'final_state_sha256')
    }}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('seeds', type=int, nargs='+')
    args = parser.parse_args()
    print(json.dumps({'source': source_identity(), 'games': [trace(seed) for seed in args.seeds]},
                     indent=2, sort_keys=True))
