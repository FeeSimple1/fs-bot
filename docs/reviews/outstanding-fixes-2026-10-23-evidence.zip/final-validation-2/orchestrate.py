#!/usr/bin/env python3
"""Run the agreed final matrix, then check every acceptance invariant.

This is scratch orchestration, not repository code. No games run on import.
The run_batch CLI requires hash seed zero; bot-replay directly calls the same
play_one instrument under hash seed seven, retaining full per-game records.
"""
import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'fs-bot'
STAGES = ('batch', 'bots-hash7', 'fuzz-hash0', 'fuzz-hash7',
          'census-hash0', 'census-hash7')
DEFECTS = {'illegal', 'wasteful-sa', 'ineffective-event', 'other-refused'}


def load_tools():
    if str(REPO) not in sys.path:
        sys.path.insert(0, str(REPO))
    from fs_bot.tools.run_batch import SCENARIOS, play_one
    return SCENARIOS, play_one


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def source_identity():
    digest = hashlib.sha256()
    for path in sorted((REPO / 'fs_bot').rglob('*.py')):
        digest.update(str(path.relative_to(REPO)).encode() + b'\0' + path.read_bytes())
    return {'commit': subprocess.check_output(
                ['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
            'source_sha256': digest.hexdigest()}


def commands():
    python = sys.executable
    return {
        'batch': (0, [python, '-m', 'fs_bot.tools.run_batch', '--games', '200',
                      '--workers', '4', '--out', str(HERE / 'batch-hash0')]),
        'bots-hash7': (7, [python, str(Path(__file__).resolve()), 'bot-replay']),
        **{f'fuzz-hash{seed}': (seed, [python, '-m', 'fs_bot.tools.player_fuzz',
                                      '--seeds', '1-40']) for seed in (0, 7)},
        **{f'census-hash{seed}': (seed, [python, '-m', 'fs_bot.tools.error_census',
                                        '--seeds', '1-20', '--strict', '--top', '1000',
                                        '--out', str(HERE / f'census-hash{seed}.json')])
           for seed in (0, 7)},
    }


def run(stage):
    identity = source_identity()
    manifest_path = HERE / 'manifest.json'
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        if manifest['source_sha256'] != identity['source_sha256']:
            raise RuntimeError('Source changed since this matrix began; use a fresh output directory.')
    else:
        manifest = dict(identity, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                        commands={name: {'hash_seed': seed, 'argv': argv}
                                  for name, (seed, argv) in commands().items()}, stages={})
        write_json(manifest_path, manifest)
    for name in (STAGES if stage == 'all' else [stage]):
        if name in manifest['stages']:
            raise RuntimeError(f'{name} already ran; preserve its evidence instead of overwriting it.')
        seed, argv = commands()[name]
        output = HERE / f'{name}.log'
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        print(f'Starting {name}; output {output}', flush=True)
        env = dict(os.environ, PYTHONHASHSEED=str(seed))
        with output.open('w') as stream:
            completed = subprocess.run(argv, cwd=REPO, env=env, stdout=stream,
                                       stderr=subprocess.STDOUT, check=False)
        after = source_identity()
        manifest['stages'][name] = {
            'started_utc': started,
            'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'returncode': completed.returncode,
            'source_unchanged': after['source_sha256'] == identity['source_sha256'],
        }
        write_json(manifest_path, manifest)
        print(f'Finished {name}; exit={completed.returncode}', flush=True)
        if after['source_sha256'] != identity['source_sha256']:
            raise RuntimeError('Mechanics changed during validation; results are not a single-source matrix.')
        if completed.returncode:
            return completed.returncode
    return 0


def bot_replay():
    if os.environ.get('PYTHONHASHSEED') != '7':
        raise RuntimeError('bot-replay requires PYTHONHASHSEED=7 at Python startup.')
    scenarios, play_one = load_tools()
    tasks = [(scenario, seed) for scenario in scenarios for seed in range(1, 6)]
    with ProcessPoolExecutor(max_workers=4) as pool:
        records = list(pool.map(play_one, tasks))
    (HERE / 'bots-hash7.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in records))
    print(f'games={len(records)} completed={sum(bool(r.get("completed")) for r in records)}')
    return 0 if all(r.get('completed') for r in records) else 1


def read_records(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def verify():
    scenarios, _ = load_tools()
    failures = []
    report = {'failures': failures}
    def require(condition, message):
        if not condition:
            failures.append(message)
    manifest = json.loads((HERE / 'manifest.json').read_text())
    require(manifest['source_sha256'] == source_identity()['source_sha256'],
            'Current mechanics differ from the tested source.')
    require(set(manifest['stages']) == set(STAGES), 'One or more matrix stages are missing.')
    for name, result in manifest['stages'].items():
        require(result['returncode'] == 0, f'{name} returned {result["returncode"]}.')
        require(result['source_unchanged'], f'{name} ran while mechanics changed.')

    records = read_records(HERE / 'batch-hash0/games.jsonl')
    expected = {(scenario, seed) for scenario in scenarios for seed in range(1, 201)}
    keys = [(r['scenario'], r['seed']) for r in records]
    require(len(records) == 1000 and len(set(keys)) == 1000 and set(keys) == expected,
            'Batch must contain exactly 1,000 unique games, seeds 1–200 in each of five scenarios.')
    severe, severity, diagnostic_games, bad_records = [], Counter(), Counter(), []
    for record in records:
        key = [record['scenario'], record['seed']]
        if (not all(record.get(flag) for flag in ('completed', 'game_completed', 'audit_completed'))
                or record.get('errors') or record.get('error') or record.get('integrity_findings')
                or record.get('engine_ranking_output_missing') is not False
                or not isinstance(record.get('final_ranking'), list)
                or len(record.get('final_ranking', [])) != 4
                or record.get('winner_differs_from_highest_margin') is not False
                or not isinstance(record.get('final_state_sha256'), str)
                or not record.get('final_state_sha256')):
            bad_records.append(record)
        seen = set()
        for diagnostic in record.get('diagnostics', []):
            severity[diagnostic['severity']] += diagnostic['count']
            seen.add(diagnostic['severity'])
            if diagnostic['severity'] != 'legal-decline':
                severe.append({'game': key, 'diagnostic': diagnostic})
        diagnostic_games.update(seen)
    report['batch'] = {'games': len(records), 'games_by_scenario': dict(Counter(r['scenario'] for r in records)),
                       'severity_incidents': dict(severity), 'severity_games': dict(diagnostic_games),
                       'failed_games': len(bad_records), 'nonlegal_diagnostic_groups': len(severe)}
    write_json(HERE / 'batch-failed-games.json', bad_records)
    write_json(HERE / 'batch-nonlegal-diagnostics.json', severe)
    require(not bad_records, f'{len(bad_records)} batch games failed completion/error/integrity/ranking/hash checks.')
    require(not severe, f'{len(severe)} nonlegal diagnostic groups require investigation.')
    metadata = json.loads((HERE / 'batch-hash0/metadata.json').read_text())
    require(metadata['source_sha256'] == manifest['source_sha256'], 'Batch source digest mismatch.')

    baseline = {(r['scenario'], r['seed']): r for r in records}
    repeats = read_records(HERE / 'bots-hash7.jsonl')
    repeat_keys = [(r['scenario'], r['seed']) for r in repeats]
    require(len(repeats) == 25 and len(set(repeat_keys)) == 25 and set(repeat_keys) == {
        (scenario, seed) for scenario in scenarios for seed in range(1, 6)},
        'Cross-hash bot sample must contain all five scenarios, seeds 1–5.')
    fields = ('final_state_sha256', 'winner', 'cards', 'winters', 'diagnostics',
              'diagnostic_occurrences', 'completed', 'errors', 'integrity_findings',
              'final_ranking', 'termination', 'interlude_completed')
    mismatches = []
    for repeat in repeats:
        key = (repeat['scenario'], repeat['seed'])
        for field in fields:
            if repeat.get(field) != baseline.get(key, {}).get(field):
                mismatches.append({'scenario': key[0], 'seed': key[1], 'field': field,
                                   'hash0': baseline.get(key, {}).get(field), 'hash7': repeat.get(field)})
    write_json(HERE / 'bot-hash-mismatches.json', mismatches)
    report['bot_cross_hash'] = {'games': len(repeats), 'compared_fields': fields, 'mismatches': len(mismatches)}
    require(not mismatches, f'{len(mismatches)} bot cross-hash field mismatches.')

    fuzz = [(HERE / f'fuzz-hash{seed}.log').read_text() for seed in (0, 7)]
    require(fuzz[0] == fuzz[1], 'Player-fuzz output differs between hash seeds 0 and 7.')
    for seed, output in zip((0, 7), fuzz):
        require('games=200 ' in output and 'hard-findings=0 ' in output and 'findings: none' in output,
                f'Player-fuzz hash {seed} did not verify 200 games with zero hard findings.')
    report['player_fuzz'] = {'games_per_hash': 200, 'replay_enabled': True,
                             'exact_output_match': fuzz[0] == fuzz[1], 'output': fuzz[0]}

    census = [json.loads((HERE / f'census-hash{seed}.json').read_text()) for seed in (0, 7)]
    require(census[0] == census[1], 'Strict census JSON differs between hash seeds 0 and 7.')
    for seed, result in zip((0, 7), census):
        require(result['games'] == 100, f'Census hash {seed} must cover 100 games.')
        require(not any(n for severity, n in result['by_severity'].items() if severity != 'legal-decline'),
                f'Census hash {seed} contains nonlegal incidents.')
    report['census'] = {'games_per_hash': 100, 'exact_json_match': census[0] == census[1],
                        'by_severity': census[0]['by_severity']}
    write_json(HERE / 'verification.json', report)
    print(json.dumps(report, indent=2))
    return 1 if failures else 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('commands', 'run', 'bot-replay', 'verify'))
    parser.add_argument('--stage', choices=('all',) + STAGES, default='all')
    args = parser.parse_args()
    if args.mode == 'commands':
        print(json.dumps({name: {'PYTHONHASHSEED': seed, 'argv': argv}
                          for name, (seed, argv) in commands().items()}, indent=2))
        return 0
    if args.mode == 'run':
        return run(args.stage)
    return bot_replay() if args.mode == 'bot-replay' else verify()


if __name__ == '__main__':
    raise SystemExit(main())
