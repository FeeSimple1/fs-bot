# EXP-02 / EXP-03 movement handoff

Worktree `/workspace/scratch/534c265c65f4/fs-human-event-movement`; branch `repair/event-movement-2026-11-02`; base d3241e7.

## EXP-02 — A19 Captured

Commit: **e71a63a0893bd5eb0ed53cbcfcf3f4b320866484**.

Authority: A Card Reference A19: “March all Romans in 1 Region to an adjacent one with Germans. Romans Ineligible through next card.” Chapter 5 §§5.1, 5.1.3, 5.4 and Chapter 3 §3.2.2. German NP instruction alone adds “no Fort” and “Germans will outnumber Romans.”

- New `cards/procillus.py`; executor selects an origin and adjacent destination containing German pieces. Roman Leader/Legions/Auxilia all March; static Forts/Allies stay. Ordinary March hiding/stop handling applies. One hop has no intermediate Region and therefore no Harassment.
- `kind: free_action`, `request_type: procillus_march`, `card_id: A19`, `acting_faction: Romans`, `moves: [{origin, destination}, ...]`, `allow_decline: false`. Owner is Event executor, including non-Germans. Response exactly `{origin, destination}` or explicit `{use_default: true}`; no subset counts, alternate actor, or decline.
- NPC German default retains no-Fort/outnumber priority. Human legality has neither restriction. Existing ineligibility/next-card lifecycle remains.
- CLI: `cli/procillus.py`; validator dispatch only in shared `engine/free_actions.py`. Durable generic free_action infrastructure needs no special schema.
- Focused final: 175 passed, `movement-a19-focused-03.log`. Full: 6292 passed, `movement-a19-full-02.log` (102.53s).
- Failures retained: first focused typo used nonexistent CMD_EVENT test symbol; first full 2 historical assertions explicitly codified audited old defects. Updated non-German assertion and explicitly marked the German NPC fixture. No passing test was deleted.

## EXP-03 — A67 Arduenna

Commit: **6a25c9020cf828a3328d0df5735f63083d0474e0**. Independent source/mechanics review cleared the final changes.

Authority: A Card Reference A67: “A Faction other than Arverni may free March into either or both the Nervii or Treveri Regions, then execute a free Command except March in one or both, then flip all friendly pieces there to Hidden.” Chapter 5 §5.1 assigns beneficiary selection to executor; §5.1.3 requires possible later portions; §5.1.1 removes Scouted marker instead of immediately hiding a Scouted counter. Chapter 3 §3.1 requires at least one selected Region. Base Card Reference 67 Tips discuss origins that could normally March to the destinations; parallel Card72 Tips explicitly require relocation for “March into”. Parent/reviewer agreed single leading “may” covers the complete sequence (contrast Card6’s separate “may” clauses): beneficiary may decline before any changes; an accepted sequence requires mechanically possible March and Command; unavailable portions alone are skipped. No in-place March.

- Dedicated `cards/arduenna.py`, `cards/arduenna_march.py`, `cli/arduenna.py`. Existing German safe-surplus/Control/target-priority calculation extracted as `german_plan`, preserving old NP sequence. Base67 resolver untouched. German whole-grant/default refusal remains unchanged when that NP resolver has no safe Control/Battle plan; Revealed/Scouted residents alone cannot turn the refusal into a Hide-only Event.
- Four free_action request types: `arduenna_faction` (executor; `{faction: <offered non-Arverni playable faction>}`); `arduenna_accept` (beneficiary; `{accept: true}` or `{decline: true}` before movement); `arduenna_march` (beneficiary; ordinary full March action, every nonempty explicit route ends in Nervii/Treveri); `arduenna_command` (beneficiary; ordinary non-March Command restricted to one/both targets, no SA).
- Entire-grant defaults remain distinct from accepted-stage defaults. After acceptance, March/Command decline is invalid. Mechanical witnesses establish possibility; they **do not** substitute arbitrary plans when NP defaults decline. Explicit unavailable `{use_default: true}` stays invalid/pending with same ID. Raw callback None retains documented fallback contract. Mandatory requests set `validate_default_response: true`.
- **Dependency:** EXP-01 commit 60267c74b5e2ba99931bdd3812dda2bbe28cec91 owns the 9-line `SeatSession.validate_default_response` hook. It is copied locally for full-suite validation but intentionally omitted from the A67 commit. Integrate EXP-01 first (already parent intent).
- Command witness derives legal ordinary Raid, Battle, Rally/Recruit and Seize plans with detached board/RNG; command request is generated from the live post-March board, including actual Harassment survivors.
- Live Diviciacus refusal or another explicit/default no-effect result cannot discard a compulsory stage when a fresh witness remains. The same beneficiary receives a new `attempt` and `previous_error`; prior accepted stages stay completed. Tests cover March and Command refusals plus save/replay while the March retry is pending. Raw None remains the documented one-attempt fallback.
- No early Hide via legacy `flip_hidden_regions`. Final Hide covers all friendly target residents and arrivals. Reveal→Hidden, Scouted→Revealed once. No source constants/reference edits.
- March form initial physical groups once. Aggregate counts reject duplicate/overallocated mobile pieces. Exact per-owner/visibility cohorts persist across earlier groups, later origins and voluntary removal windows. An arrival cannot move or hide again as a later origin’s initial piece. Diviciacus borrowed counters preserve owner and Scouted state. Split groups can stop at one target while another continues through it; only continuing pieces suffer Harassment.
- Narrow shared execution hooks: trusted `initial_group` argument on `_march_with_harassment` (no response can set it); A67-only handler selection in `_execute_free_bot_command`; ordinary non-A67 calls unchanged. Standard movement timing retained. Registered A67 cohorts clean up in finally.
- Narrow CLI hooks: `arduenna_faction`/`arduenna_accept` collectors; mandatory-default validation before accepting menu selection; `_cli_arduenna_transit` lets A67 routes continue through one target to the other. Existing default destination-stop behavior preserved for other cards.
- Validation rejects `explicit_moves`, alternate plan fields, extraneous `command_parts`, wrong endpoints, forced-stop overlong paths, extra group wrong endpoints, illegal counts and SA injection. Preview validation consumes no live callback/RNG.
- Focused final: `movement-a67-focused-12.log`, 135 passed. Includes typed mechanics, four-stage durable save/replay, invalid stable IDs, unavailable default pending, CLI reachability, physical cohorts/Diviciacus, source-scoped movement, Harassment/dropoff separation, before-formation removal, moving-group removal and future-origin removal.
- Full checkpoint `movement-a67-full-01.log`: 6323 passed (117.82s), superseded by the refusal-retry correction. Second checkpoint `movement-a67-full-02.log`: 6326 passed (123.74s), superseded only by the German NP whole-grant refusal guard. Final full `movement-a67-full-03.log`: **6328 passed (115.69s)** before commit. Failures and superseded focused logs retained individually. Draft files in evidence are superseded implementation drafts, not final source.

## Integration and remaining checks

Root owns guide/status/progress changes. Add the above request contracts to AGENT_INTERFACE and player-facing ownership/whole-sequence/default notes to PLAYING/CHATGPT_README as appropriate. Audit IDs EXP-02 and EXP-03 can be closed only after final integrated validation. Existing historical source snapshots remain historical.

New pending-request shapes necessarily alter replay signatures for newly reached repaired paths; no durable save schema/version bump. Existing raw fallback contract remains separate from durable input, and old saves lacking these newly introduced choices have no fabricated historical responses.

No push performed. The untracked `docs/reviews/.recruit-rally-2026-10-29-evidence.zip.CKXJVP` observed in this worktree was not created intentionally by this task and is not staged.
