import hashlib,json,sys
from copy import deepcopy
from pathlib import Path
from fs_bot import rules_consts as rc
from fs_bot.tools import run_batch as batch
from fs_bot.engine import execute as ex
from fs_bot.state.serialize import encode
from fs_bot.tools.validation_metadata import source_identity
cards=[];calls=[];live=None
original_card=batch.play_card;original_rampage=ex._execute_rampage

def sha(value):
    return hashlib.sha256(json.dumps(encode(value),sort_keys=True,separators=(',',':')).encode()).hexdigest()

def rampage(state,faction,action):
    if state is not live:return original_rampage(state,faction,action)
    before=[]
    for entry in action.get('sa_regions',[]):
        if not isinstance(entry,dict):continue
        r=entry.get('region');target=entry.get('target')
        before.append({'entry':deepcopy(entry),'pieces':deepcopy(state['spaces'].get(r,{}).get('pieces',{}))})
    result=original_rampage(state,faction,action)
    calls.append({'card_index':len(cards),'card':state['current_card'],'command':action.get('command'),
                  'before':before,'result':deepcopy(result)})
    return result

def card(state,*args,**kwargs):
    global live
    live=state;resolved=state['current_card']
    result=original_card(state,*args,**kwargs)
    cards.append({'resolved_card':resolved,'state_sha256':sha({k:v for k,v in state.items() if k!='decision_agent'}),
                  'spaces':deepcopy(state['spaces']),'markers':deepcopy(state['markers']),
                  'resources':deepcopy(state['resources']),'rng_sha256':sha(state['rng'])})
    live=None
    return result
batch.play_card=card;ex._execute_rampage=rampage
record=batch.play_one((rc.SCENARIO_RECONQUEST,2,'legacy'))
Path(sys.argv[1]).write_text(json.dumps({'source':source_identity(),'record':record,'cards':cards,'rampage_calls':calls},indent=2)+'\n')
