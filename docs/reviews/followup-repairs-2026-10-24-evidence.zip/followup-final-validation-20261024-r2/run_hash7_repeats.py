"""Cross-hash bot repeats; compare full result records with hash-0 studies."""
import argparse
from concurrent.futures import ProcessPoolExecutor
import json
import os
from pathlib import Path
import platform
import sys

REPO = Path('/workspace/scratch/534c265c65f4/fs-bot')
sys.path.insert(0, str(REPO))
from fs_bot.tools.run_batch import play_one, SCENARIOS
from fs_bot.tools.validation_metadata import source_identity


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-source', required=True)
    args = parser.parse_args()
    assert os.environ.get('PYTHONHASHSEED') == '7'
    before = source_identity()
    assert before['source_sha256'] == args.expected_source, before
    root = Path(__file__).resolve().parent
    target = root / 'bot-hash7-repeats.jsonl'
    assert not target.exists(), 'Preserve prior evidence; use a fresh directory'
    tasks = [(scenario, seed, edition) for edition in ('legacy', 'original', 'second-edition')
             for scenario in SCENARIOS for seed in range(201, 206)]
    records = []
    with ProcessPoolExecutor(max_workers=4) as pool, target.open('x') as log:
        for record in pool.map(play_one, tasks):
            record.update(source_sha256=before['source_sha256'], commit=before['commit'])
            records.append(record)
            log.write(json.dumps(record, sort_keys=True) + '\n')
            log.flush()
    after = source_identity()
    bad = [record for record in records if not record.get('completed')]
    stable = before['source_sha256'] == after['source_sha256'] == args.expected_source
    metadata = dict(source_before=before, source_after=after, source_stable=stable,
                    python=platform.python_version(), hash_seed=7,
                    scenarios=list(SCENARIOS), seeds=list(range(201, 206)),
                    editions=['legacy', 'original', 'second-edition'], expected_games=75,
                    recorded_games=len(records), unsuccessful_games=len(bad))
    (root / 'bot-hash7-repeats-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
    print(json.dumps(metadata, indent=2))
    for record in bad:
        print(json.dumps(record, sort_keys=True))
    return 0 if stable and not bad and len(records) == 75 else 1


if __name__ == '__main__':
    raise SystemExit(main())
