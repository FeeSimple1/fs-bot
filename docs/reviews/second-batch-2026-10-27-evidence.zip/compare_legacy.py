"""Compare accepted-size legacy records with retained earlier evidence; no games."""
import argparse
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load_records(path):
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    mapping = {(row["scenario"], row["seed"]): row for row in rows}
    assert len(rows) == len(mapping) == 100
    return mapping


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attempt", required=True)
    args = parser.parse_args()
    run = ROOT / args.attempt
    current = load_records(run / "bots-legacy/games.jsonl")
    first_root = ROOT.parent / "first-batch-validation/attempt3"
    first = load_records(first_root / "bots-legacy/games.jsonl")
    old = json.loads((run / "balance-baseline.json").read_text())["games"]
    assert current.keys() == first.keys()
    fields = ("winner", "cards", "interlude_completed", "termination", "final_ranking", "final_state_sha256")
    report = {"source": json.loads((run / "source.json").read_text()),
              "first_source": json.loads((first_root / "source.json").read_text()),
              "games": len(current), "scenarios": {}, "records": []}
    for (scenario, seed), row in current.items():
        prior = first[scenario, seed]
        before = old[f"{scenario}|{seed}"]
        report["records"].append({"scenario": scenario, "seed": seed, "baseline": before,
            "first_batch": {key: prior[key] for key in fields},
            "current_batch": {key: row[key] for key in fields},
            "winner_changed_from_first": prior["winner"] != row["winner"],
            "winner_changed_from_baseline": before["winner"] != row["winner"]})
    for scenario in sorted({s for s, _ in current}):
        before = Counter(old[f"{scenario}|{n}"]["winner"] for n in range(1, 21))
        prior = Counter(first[scenario, n]["winner"] for n in range(1, 21))
        after = Counter(current[scenario, n]["winner"] for n in range(1, 21))
        delta = {f: Fraction(after[f] - before[f], 20) for f in before.keys() | after.keys()}
        report["scenarios"][scenario] = {"baseline_wins": dict(before), "first_batch_wins": dict(prior),
            "current_wins": dict(after), "exact_rate_change": {f: str(d) for f, d in delta.items()},
            "original_band_passed": all(abs(d) <= Fraction(3, 20) for d in delta.values()),
            "winner_changes_from_first": [r["seed"] for r in report["records"] if r["scenario"] == scenario and r["winner_changed_from_first"]]}
    report["winner_changes_from_first"] = sum(r["winner_changed_from_first"] for r in report["records"])
    report["winner_changes_from_baseline"] = sum(r["winner_changed_from_baseline"] for r in report["records"])
    with (run / "legacy-paired-comparison.json").open("x") as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({k: v for k, v in report.items() if k != "records"}, indent=2))


if __name__ == "__main__":
    main()
