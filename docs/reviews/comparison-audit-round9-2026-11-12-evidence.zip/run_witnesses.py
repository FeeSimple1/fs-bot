#!/usr/bin/env python3
"""Reproduce round-nine observed defects on the audited Python source bytes."""
import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile
from pathlib import Path

EXPECTED='57a94d20440986063d7f86224a6074fa0ea2ce471e58e24e9c5dd349ec799033'
CASES=[('events','probe_events.py','probe_events-output.json',False),
       ('bots','probe_bots.py','probe_bots-output.json',True),
       ('lifecycle','probe_lifecycle.py','results.json',True),
       ('frontend','probe_frontend.py','probe_frontend-output.json',True)]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo',type=Path,required=True)
args=parser.parse_args();repo=args.repo.resolve();evidence=Path(__file__).resolve().parent
digest=hashlib.sha256();files=sorted((repo/'fs_bot').rglob('*.py'))
for p in files: digest.update(str(p.relative_to(repo)).encode()+b'\0'+p.read_bytes())
if len(files)!=616 or digest.hexdigest()!=EXPECTED:
    raise SystemExit('Source differs from audited revision; these assertions preserve defects, not repaired expectations.')
results=[]
for lane,script,output,repo_argument in CASES:
    observed=[]
    for seed in (0,987):
        with tempfile.TemporaryDirectory(prefix='fs-audit9-') as temporary:
            work=Path(temporary)/lane;work.mkdir()
            shutil.copy2(evidence/lane/script,work/script)
            command=[sys.executable,str(work/script)]
            if repo_argument: command += ['--repo',str(repo)]
            env=dict(os.environ,PYTHONPATH=str(repo),PYTHONHASHSEED=str(seed),PYTHONDONTWRITEBYTECODE='1')
            run=subprocess.run(command,cwd=repo,env=env,capture_output=True)
            if run.returncode: raise SystemExit(run.stderr.decode())
            observed.append(run.stdout);json.loads(run.stdout)
    expected=(evidence/lane/output).read_bytes()
    assert observed[0]==observed[1]==expected, f'{lane}: output mismatch'
    results.append({'lane':lane,'hash_seeds':[0,987],'exact_match':True,'output_sha256':hashlib.sha256(expected).hexdigest()})
print(json.dumps({'source_sha256':EXPECTED,'python_files':len(files),'all_witnesses_match':True,'results':results},indent=2))
