"""Capture one validation command and its exit status outside the source tree."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[2] / 'fs-bot'
out = Path(__file__).resolve().parent
name, seed = sys.argv[1:3]
command = [str(root / '.venv/bin/python'), *sys.argv[3:]]
env = dict(os.environ, PYTHONHASHSEED=seed, PYTHONDONTWRITEBYTECODE='1')
record = {'name': name, 'command': command, 'cwd': str(root),
          'environment': {'PYTHONHASHSEED': seed, 'PYTHONDONTWRITEBYTECODE': '1'},
          'started_unix': time.time(), 'log': name + '.log'}
(out / (name + '-execution.json')).write_text(json.dumps(record, indent=2) + '\n')
with (out / record['log']).open('wb') as log:
    result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
record.update(exit_status=result.returncode, finished_unix=time.time())
record['seconds'] = record['finished_unix'] - record['started_unix']
(out / (name + '-execution.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
raise SystemExit(result.returncode)
