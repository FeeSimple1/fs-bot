"""Observed-defect witnesses at b23c8cd; run from fs-bot with PYTHONPATH=."""
import json
from fs_bot import rules_consts as rc
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import build_initial_state, validate_state
from fs_bot.state.serialize import encode
from fs_bot.board.pieces import count_pieces, find_leader, get_leader_in_region, get_available, place_piece, remove_piece
from fs_bot.cards.card_effects import _unally_tribe, _ally_tribe
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.victory import calculate_victory_score
from fs_bot.tools.seat_session import validate_response


def initial(edition):
    return setup_scenario(rc.SCENARIO_GREAT_REVOLT, seed=4, card_edition=edition,
                          faction_owners={rc.BELGAE:'Tester'})


def play(s, card, params, shaded=False, actor=rc.BELGAE):
    assert validate_state(s) == [], validate_state(s)
    s['current_card'] = s['current_card_id'] = card
    decision={'action':'event','player_action':{'command':'Event','details':{
        'card_id':card, 'text_preference':rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,
        'event_params':params}}}
    validate_response(s, {'kind':'turn','faction':actor,'options':['event']}, decision)
    result=execute_decision(s, actor, decision)
    assert result['executed'], result
    assert validate_state(s) == [], validate_state(s)
    return result


def successor(s, faction):
    origin=find_leader(s, faction)
    remove_piece(s, origin, faction, rc.LEADER)
    place_piece(s, origin, faction, rc.LEADER, leader_name=rc.SUCCESSOR)
    return origin


records=[]
for edition in ('original','second-edition'):
    s=initial(edition)
    assert count_pieces(s,rc.BRITANNIA,rc.ROMANS)==0
    play(s,7,{'target_region':rc.BRITANNIA})
    assert count_pieces(s,rc.BRITANNIA,rc.ROMANS,rc.LEGION)==1
    assert count_pieces(s,rc.BRITANNIA,rc.ROMANS,rc.AUXILIA)==1
    records.append({'case':'alaudae_without_roman_control','edition':edition,'region':rc.BRITANNIA,'placed_legions':1,'placed_auxilia':1})

    s=initial(edition)
    from fs_bot.map.map_data import get_adjacent
    leader=find_leader(s,rc.ROMANS)
    assert rc.BRITANNIA not in [leader,*get_adjacent(leader,s['scenario'])]
    play(s,11,{'target_region':rc.BRITANNIA,'region':rc.BRITANNIA})
    assert count_pieces(s,rc.BRITANNIA,rc.ROMANS,rc.AUXILIA)==3
    records.append({'case':'numidians_beyond_leader_range','edition':edition,'region':rc.BRITANNIA,'roman_leader_region':leader,'placed_auxilia':3})

    s=initial(edition)
    assert count_pieces(s,rc.TREVERI,rc.BELGAE,rc.CITADEL)==0
    before=count_pieces(s,rc.TREVERI,rc.ROMANS,rc.LEGION)
    play(s,23,{'target_region':rc.TREVERI},True)
    assert count_pieces(s,rc.TREVERI,rc.ROMANS,rc.LEGION)==before-1
    assert s['fallen_legions']==1 and s['forced_ineligible'][rc.ROMANS]==1
    records.append({'case':'sacking_no_citadel','edition':edition,'legions_before':before,'legions_after':before-1,'fallen':1,'roman_forced_ineligible':1})

    s=initial(edition)
    _unally_tribe(s,rc.TRIBE_CARNUTES)
    assert s['resources'][rc.ARVERNI]==20
    play(s,52,{'target_factions':[rc.ARVERNI,rc.ARVERNI]})
    assert s['resources'][rc.ARVERNI]==4
    records.append({'case':'assembly_repeated_target','edition':edition,'before':20,'after':4,'legal_after_one_target':12})

    s=initial(edition)
    assert s['tribes'][rc.TRIBE_REMI]['allied_faction']==rc.ROMANS
    assert s['tribes'][rc.TRIBE_BELLOVACI]['allied_faction']==rc.BELGAE
    assert get_available(s,rc.ROMANS,rc.ALLY)>0
    before=encode(s['tribes'])
    play(s,68,{'replacements':[]})
    assert encode(s['tribes'])==before
    records.append({'case':'remi_mandatory_replacement_omitted','edition':edition,'eligible_target':rc.TRIBE_BELLOVACI,'remi_owner':rc.ROMANS,'tribes_unchanged':True})

    s=initial(edition)
    origin=successor(s,rc.ARVERNI)
    play(s,19,{'target_region':origin},True)
    assert get_leader_in_region(s,origin,rc.ARVERNI)==rc.SUCCESSOR
    records.append({'case':'lucterius_same_region_successor','edition':edition,'region':origin,'leader_after':rc.SUCCESSOR,'expected':rc.VERCINGETORIX})

    s=initial(edition)
    assert get_leader_in_region(s,find_leader(s,rc.ARVERNI),rc.ARVERNI)==rc.VERCINGETORIX
    origin=find_leader(s,rc.ARVERNI)
    destination=rc.BRITANNIA
    play(s,19,{'target_region':destination},True)
    assert find_leader(s,rc.ARVERNI)==destination
    records.append({'case':'lucterius_living_vercingetorix_relocation','edition':edition,'from':origin,'to':destination,'gate_should_fail':True})

    s=initial(edition)
    origin=successor(s,rc.BELGAE)
    play(s,56,{'target_region':rc.TREVERI},True)
    assert find_leader(s,rc.BELGAE)==origin and get_leader_in_region(s,origin,rc.BELGAE)==rc.SUCCESSOR
    records.append({'case':'ambiorix_on_map_successor_ignored','edition':edition,'leader_after':rc.SUCCESSOR,'region_after':origin,'selected_legal_destination':rc.TREVERI})

    s=initial(edition)
    remove_piece(s,find_leader(s,rc.BELGAE),rc.BELGAE,rc.LEADER)
    play(s,56,{'target_region':rc.BRITANNIA},True)
    assert find_leader(s,rc.BELGAE)==rc.BRITANNIA
    records.append({'case':'ambiorix_illegal_destination','edition':edition,'region_after':rc.BRITANNIA})

    s=build_initial_state(rc.SCENARIO_GREAT_REVOLT,seed=4)
    s['card_edition']=edition
    for region in (rc.MORINI,rc.ATREBATES,rc.CARNUTES):
        place_piece(s,region,rc.BELGAE,rc.WARBAND)
    assert _ally_tribe(s,rc.TRIBE_BELLOVACI,rc.BELGAE)
    assert _ally_tribe(s,rc.TRIBE_CARNUTES,rc.BELGAE)
    remove_piece(s,rc.CARNUTES,rc.BELGAE,rc.ALLY)
    place_piece(s,rc.CARNUTES,rc.BELGAE,rc.CITADEL)
    place_piece(s,rc.CARNUTES,rc.BELGAE,rc.LEADER,leader_name=rc.AMBIORIX)
    score=calculate_victory_score(s,rc.BELGAE)
    assert score==9,score
    play(s,56,{},False)
    assert find_leader(s,rc.BELGAE)==rc.CARNUTES
    records.append({'case':'flight_double_counts_citadel','edition':edition,'victory_score':score,'leader_survives':True,'expected':'Ambiorix removed'})
print(json.dumps(records,indent=2))
