"""Verify fixed-seed games, replay evidence, tests and the reviewed balance band."""
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

from fs_bot import rules_consts as rc
from fs_bot.tools.run_batch import SCENARIOS
from fs_bot.tools.validation_metadata import source_identity

ROOT = Path(__file__).resolve().parent
FINAL = ROOT / 'final'
PARENT_HASH = '09142109dba91e116889900e85b10d03e52500840adf8039cd54012094f5f4f5'


def read_json(path):
    return json.loads(path.read_text())


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def game_key(row):
    return tuple(row[key] for key in ('scenario', 'seed', 'card_edition'))


def outcomes(rows):
    return {f'{scenario}|{seed}': {'winner': row['winner'], 'cards': row['cards']}
            for (scenario, seed, edition), row in rows.items() if edition == 'legacy'}


def verify_matrix(path, edition, seeds, source_hash):
    rows = [json.loads(line) for line in (path / 'games.jsonl').read_text().splitlines()]
    expected = {(scenario, seed, edition) for scenario in SCENARIOS for seed in seeds}
    assert len(rows) == len(expected) and {game_key(row) for row in rows} == expected
    meta = read_json(path / 'metadata.json')
    assert meta['source_sha256'] == source_hash and meta['seeds'] == list(seeds)
    assert meta['card_edition'] == edition and meta['hash_seed'] == 0 and meta['all_factions_bots']
    for row in rows:
        assert row['source_sha256'] == source_hash
        assert all(row[field] for field in (
            'completed', 'game_completed', 'audit_completed', 'final_state_sha256')), row
        assert not any(row[field] for field in (
            'errors', 'integrity_findings', 'engine_ranking_output_missing',
            'winner_differs_from_highest_margin')), row
        assert len(row['final_ranking']) == len(row['engine_final_ranking']) == 4
        assert all(diagnostic['severity'] == 'legal-decline' for diagnostic in row['diagnostics']), row
    return {game_key(row): row for row in rows}


def paired_matrices(parent_path, final_hash):
    before, after, tables = {}, {}, {}
    for label, edition, seeds in (('bots-legacy', 'legacy', range(1, 21)),
                                  ('bots-second', 'second-edition', range(41, 45))):
        previous = verify_matrix(parent_path / label, edition, seeds, PARENT_HASH)
        current = verify_matrix(FINAL / label, edition, seeds, final_hash)
        scenario_counts = {}
        for scenario in SCENARIOS:
            keys = [key for key in current if key[0] == scenario]
            scenario_counts[scenario] = {
                'winner_changes': sum(previous[key]['winner'] != current[key]['winner'] for key in keys),
                'board_changes': sum(previous[key]['final_state_sha256'] != current[key]['final_state_sha256']
                                     for key in keys),
            }
            if scenario == rc.SCENARIO_ARIOVISTUS:
                for key in keys:
                    ignore = {'commit', 'source_sha256', 'seconds'}
                    assert {k: v for k, v in previous[key].items() if k not in ignore} == {
                        k: v for k, v in current[key].items() if k not in ignore}
        tables[edition] = {
            'games': len(current), 'seeds': list(seeds),
            'winner_changes': sum(r['winner_changes'] for r in scenario_counts.values()),
            'board_changes': sum(r['board_changes'] for r in scenario_counts.values()),
            'interludes': sum(row['interlude_completed'] for row in current.values()),
            'diagnostics': sum(len(row['diagnostic_occurrences']) for row in current.values()),
            'scenario_counts': scenario_counts,
        }
        before.update(previous)
        after.update(current)
    return before, after, tables


def paired_records(before, after):
    ordered = [key for edition in ('legacy', 'second-edition') for key in sorted(after)
               if key[2] == edition]
    changes = []
    for scenario, seed, edition in ordered:
        key = (scenario, seed, edition)
        previous, current = before[key], after[key]
        changes.append(dict(scenario=scenario, seed=seed, card_edition=edition,
                            previous={k: previous[k] for k in ('winner', 'cards', 'final_state_sha256')},
                            current={k: current[k] for k in ('winner', 'cards', 'final_state_sha256')}))
    write_json(FINAL / 'paired-outcomes.json', changes)
    changed_boards = [key for key in ordered
                      if before[key]['final_state_sha256'] != after[key]['final_state_sha256']]
    write_json(ROOT / 'trace-parent-input.json', [before[key] for key in changed_boards])
    write_json(ROOT / 'trace-repaired-input.json', [after[key] for key in changed_boards])
    return changed_boards


def verify_balance(before, after):
    baseline = read_json(Path('fs_bot/tools/balance_baseline.json'))
    previous, current = outcomes(before), outcomes(after)
    assert baseline['games'] == previous and len(previous) == len(current) == 100
    pattern = r'\[(.*) seed=\s*(\d+)\] winner=(.+) \((\d+) cards\)'
    output = (FINAL / 'balance.log').read_text()
    logged = {}
    for line in output.splitlines():
        match = re.fullmatch(pattern, line)
        if match:
            scenario, seed, winner, cards = match.groups()
            key = f'{scenario}|{int(seed)}'
            assert key not in logged
            logged[key] = {'winner': winner, 'cards': int(cards)}
    assert logged == current and 'OK: balance within band' in output
    shifts = []
    for scenario in SCENARIOS:
        old, new = [Counter(row['winner'] for key, row in results.items()
                            if key.startswith(scenario + '|')) for results in (previous, current)]
        for faction in sorted(old.keys() | new.keys()):
            rate_delta = Fraction(new[faction] - old[faction], 20)
            assert abs(rate_delta) <= Fraction(15, 100)
            shifts.append(dict(scenario=scenario, faction=faction,
                               previous_wins=old[faction], current_wins=new[faction],
                               change_points=int(rate_delta * 100)))
    write_json(FINAL / 'balance-baseline.json', baseline)
    return dict(games=100, band_points=15, max_change_points=max(abs(r['change_points']) for r in shifts),
                changed_winners=sum(previous[key]['winner'] != current[key]['winner'] for key in current),
                win_rates=shifts)


def verify_fuzz(source, after):
    assert (FINAL / 'fuzz0.json').read_bytes() == (FINAL / 'fuzz987.json').read_bytes()
    assert (FINAL / 'fuzz0.log').read_bytes() == (FINAL / 'fuzz987.log').read_bytes()
    fuzz = read_json(FINAL / 'fuzz0.json')
    assert fuzz['metadata']['source_sha256'] == source['source_sha256']
    assert fuzz['metadata']['replay'] and fuzz['metadata']['events'] and fuzz['metadata']['reactive']
    assert fuzz['games'] == len(fuzz['records']) == 20 and fuzz['hard_findings'] == 0
    assert {game_key(row) for row in fuzz['records']} == {key for key in after if key[2] == 'second-edition'}
    assert all(row['game_completed'] and row['digest'] and not row['findings'] for row in fuzz['records'])
    return dict({k: fuzz[k] for k in ('games', 'human_turns', 'event_turns', 'events_ok',
                                    'hard_findings', 'partial', 'batch_digest')},
                hash_seeds=[0, 987], exact_match=True)


def verify_camulogenus(before, after):
    key = (rc.SCENARIO_RECONQUEST, 20, 'legacy')
    first_matrix = ROOT / 'first-matrix'
    failed = read_json(first_matrix / 'failed-game.json')
    source = read_json(first_matrix / 'source.json')
    assert game_key(failed) == key and failed['source_sha256'] == source['source_sha256']
    assert failed['game_completed'] and not failed['audit_completed']
    fault, = [row for row in failed['diagnostic_occurrences'] if row['severity'] != 'legal-decline']
    assert fault['card'] == 70 and fault['faction'] == rc.ARVERNI
    assert 'No Special Ability with March into/out of Britannia' in fault['message']
    assert after[key]['completed'] and after[key]['final_state_sha256'] != failed['final_state_sha256']
    assert before[key]['completed']
    return dict(scenario=key[0], seed=key[1], edition=key[2], card=70,
                winner=after[key]['winner'], cards=after[key]['cards'])


def main(parent_path, *options):
    source = read_json(FINAL / 'source.json')
    assert source['source_sha256'] == source_identity()['source_sha256']
    before, after, bots = paired_matrices(Path(parent_path), source['source_sha256'])
    changed_boards = paired_records(before, after)
    if options == ('prepare-traces',):
        print(f'{len(changed_boards)} changed boards across {len(after)} paired records')
        return
    suites = list(ET.parse(FINAL / 'pytest.xml').getroot().iter('testsuite'))
    passed = sum(int(suite.attrib['tests']) for suite in suites)
    assert passed == 9931
    assert not any(int(suite.attrib[k]) for suite in suites for k in ('errors', 'failures', 'skipped'))
    assert '6 failed, 5 passed' in (FINAL / 'parent-regressions.log').read_text()
    assert '1 failed, 1 passed' in (FINAL / 'parent-camulogenus.log').read_text()
    traces = read_json(FINAL / 'first-divergences.json')
    assert traces['parent']['source_sha256'] == PARENT_HASH
    assert traces['repaired']['source_sha256'] == source['source_sha256']
    assert [game_key(row) for row in traces['changes']] == changed_boards
    assert traces['changed_winners'] == sum(r['winner_changes'] for r in bots.values())

    summary = dict(source=source, parent_source_sha256=PARENT_HASH, pytest_passed=passed,
                   regressions=dict(added=13, parent_failures=7, parent_controls_passed=6),
                   bots=bots, mixed=verify_fuzz(source, after), balance=verify_balance(before, after),
                   first_change_counts=traces['first_change_counts'],
                   first_card_counts=traces['first_card_counts'],
                   camulogenus=verify_camulogenus(before, after))
    write_json(FINAL / 'summary.json', summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main(*sys.argv[1:])
