"""Region has another enemy initially; Romans arrive from the first Battle."""
import json
from fs_bot import rules_consts as r
from fs_bot.state.state_schema import build_initial_state
from fs_bot.board.pieces import place_piece
from fs_bot.cards import base_arduenna_np as p
from fs_bot.cards.arduenna import command_request
from fs_bot.engine.free_actions import validate_free_action_response

s = build_initial_state(r.SCENARIO_GREAT_REVOLT, seed=5)
s['current_card'], s['next_card'] = 67, 3
s['non_player_factions'] = {r.ARVERNI, r.ROMANS, r.AEDUI, r.BELGAE}
place_piece(s, r.NERVII, r.ARVERNI, r.WARBAND, 4)
place_piece(s, r.TREVERI, r.ARVERNI, r.WARBAND, 10)
place_piece(s, r.TREVERI, r.AEDUI, r.WARBAND, 11)
place_piece(s, r.NERVII, r.ROMANS, r.LEGION, 4, from_legions_track=True)
action = {'command': r.CMD_BATTLE, 'sa': 'No SA', 'sa_regions': [],
          'regions': [r.NERVII, r.TREVERI], 'details': {'battle_plan': [
              {'region': r.NERVII, 'target': r.ROMANS},
              {'region': r.TREVERI, 'target': r.ROMANS}]}}
print(json.dumps({
    'public_validation': validate_free_action_response(s, r.ARVERNI, command_request(r.ARVERNI, 67), action),
    'legal_two_battle_forecast': p.predicted_legion_losses(s, [r.NERVII, r.TREVERI]),
    'selected_plan': p.plan(s),
}, indent=2))
