"""Round-nine Event witnesses at f4c8372. Assertions describe current defects.
Run from repository: PYTHONPATH=. .venv/bin/python ../audit9-work/events/probe_events.py
No production changes or production monkeypatching. Controlled sparse boards are explicit.
"""
from copy import deepcopy
import json
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, get_available, place_piece, remove_piece
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.bots.bot_common import should_decline_event
from fs_bot.engine.execute import execute_decision, _derive_event_params
from fs_bot.engine.game_engine import ACTION_EVENT, get_sop_factions
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.state.serialize import encode


def checks(s):
    out = {'census': validate_state(s), 'structure': check_structural_integrity(s)}
    assert out == {'census': [], 'structure': []}, out
    assert count_pieces(s, rc.PROVINCIA, rc.ROMANS, rc.FORT) == 1
    return out


def ready(s, card):
    s.update(current_card=card, current_card_id=card, can_play_event=True,
             non_player_factions=set(get_sop_factions(s)))
    checks(s)
    return s


def sparse(card, scenario=rc.SCENARIO_ARIOVISTUS):
    s = build_initial_state(scenario, seed=1)
    place_piece(s, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    s['resources'].update({f: 10 for f in s['resources']})
    return ready(s, card)


def fingerprint(s):
    return encode({k: s[k] for k in ('spaces', 'tribes', 'available', 'resources', 'senate',
                                   'eligibility', 'capabilities', 'legions_track', 'fallen_legions')})


def totals(s, f):
    return {p: sum(count_pieces(s, r, f, p) for r in s['spaces'])
            for p in (rc.ALLY, rc.WARBAND, rc.AUXILIA, rc.LEGION)}


def run_bot(s, f):
    before = fingerprint(s)
    start = totals(s, f)
    pre = checks(s)
    declined = should_decline_event(s, s['current_card'], f)
    assert not declined
    a = dispatch_bot_turn(s, f)
    assert a['command'] == rc.FIRST_DID_EVENT, a
    params = _derive_event_params(deepcopy(s), f, s['current_card'], False)
    result = execute_decision(s, f, {'action': ACTION_EVENT, 'bot_action': a})
    assert result['executed'] and not result.get('errors'), result
    return {'pre': pre, 'declined': declined, 'action': a, 'derived_params': params,
            'result': result, 'before_totals': start, 'after_totals': totals(s, f),
            'game_effects_unchanged': before == fingerprint(s), 'post': checks(s)}


def explicit(s, f, params):
    before = totals(s, f)
    pre = checks(s)
    a = {'command': rc.FIRST_DID_EVENT, 'regions': [], 'sa': 'No SA', 'sa_regions': [],
         'details': {'card_id': s['current_card'], 'text_preference': rc.EVENT_UNSHADED,
                     'event_params': params}}
    result = execute_decision(s, f, {'action': ACTION_EVENT, 'player_action': a})
    assert result['executed'] and not result.get('errors'), result
    return {'pre': pre, 'action': a, 'result': result, 'before_totals': before,
            'after_totals': totals(s, f), 'post': checks(s)}


def fallback(s, f):
    s = deepcopy(s)
    s['can_play_event'] = False
    a = dispatch_bot_turn(s, f)
    assert a['command'] not in (rc.FIRST_DID_EVENT, 'Pass'), a
    return a


def alpine_allies():
    out = []
    for faction, piece, quota in ((rc.ROMANS, rc.AUXILIA, 6), (rc.AEDUI, rc.WARBAND, 9)):
        for supply in ('normal', 'no_mobile_available'):
            s = sparse('A40')
            if supply == 'no_mobile_available':
                place_piece(s, rc.CARNUTES, faction, piece, count=get_available(s, faction, piece))
            control = deepcopy(s)
            before = totals(s, faction)
            observed = run_bot(s, faction)
            assert totals(s, faction)[rc.ALLY] == before[rc.ALLY] == 0
            assert totals(s, faction)[piece] == before[piece] + (quota if supply == 'normal' else 0)
            if supply == 'no_mobile_available':
                assert observed['game_effects_unchanged']
            placements = [{'region': r, 'tribe': t, 'faction': faction, 'piece_type': rc.ALLY, 'count': 1}
                          for r, t in ((rc.CISALPINA, rc.TRIBE_NORI), (rc.UBII, rc.TRIBE_UBII),
                                       (rc.SEQUANI, rc.TRIBE_SEQUANI))]
            required = explicit(control, faction, {'placements': placements})
            assert totals(control, faction)[rc.ALLY] == 3
            assert totals(control, faction)[piece] == before[piece]
            out.append({'faction': faction, 'supply': supply, 'observed': observed,
                        'three_ally_control': required})
    # When no Ally can be placed, ordinary own troop placements really are legal.
    s = sparse('A40')
    for tribe in (rc.TRIBE_NORI, rc.TRIBE_UBII, rc.TRIBE_SEQUANI, rc.TRIBE_HELVETII, rc.TRIBE_HELVII):
        assert _ally_tribe(s, tribe, rc.GERMANS)
    control = run_bot(s, rc.AEDUI)
    assert totals(s, rc.AEDUI)[rc.ALLY] == 0 and totals(s, rc.AEDUI)[rc.WARBAND] == 9
    return {'cases': out, 'all_nearby_tribes_already_allied_control': control}


def fallen(s):
    place_piece(s, rc.PROVINCIA, rc.ROMANS, rc.LEGION, from_legions_track=True)
    remove_piece(s, rc.PROVINCIA, rc.ROMANS, rc.LEGION, to_fallen=True)


def lost_eagle():
    out = []
    for scenario in (rc.SCENARIO_GREAT_REVOLT, rc.SCENARIO_RECONQUEST):
        for case in ('no_fallen', 'no_target', 'aedui_only'):
            s = sparse(33, scenario)
            if case != 'no_fallen':
                fallen(s)
            # A Legion plus one WB cannot threaten that Legion: two Auxilia
            # screen the zero-Loss WB attack and prevent hostile Control.
            place_piece(s, rc.SEQUANI, rc.ROMANS, rc.LEGION, from_legions_track=True)
            place_piece(s, rc.SEQUANI, rc.ROMANS, rc.AUXILIA, count=2)
            if case == 'no_fallen':
                place_piece(s, rc.SEQUANI, rc.ARVERNI, rc.WARBAND)
            elif case == 'aedui_only':
                place_piece(s, rc.SEQUANI, rc.AEDUI, rc.WARBAND)
            control = deepcopy(s)
            alternate = fallback(s, rc.ROMANS)
            observed = run_bot(s, rc.ROMANS)
            assert observed['game_effects_unchanged']
            if case == 'no_fallen':
                fallen(control)
            else:
                place_piece(control, rc.SEQUANI, rc.ARVERNI, rc.WARBAND)
            controls = run_bot(control, rc.ROMANS)
            assert not controls['game_effects_unchanged']
            assert controls['after_totals'][rc.LEGION] == controls['before_totals'][rc.LEGION] + 1
            assert control['fallen_legions'] == 0
            out.append({'scenario': scenario, 'case': case, 'observed': observed,
                        'both_prerequisites_control': controls, 'available_flowchart_continuation': alternate})
    untouched = []
    for scenario in (rc.SCENARIO_PAX_GALLICA,):
        s = ready(setup_scenario(scenario, seed=1), 33)
        assert s['fallen_legions'] == 0
        result = run_bot(s, rc.ROMANS)
        assert result['game_effects_unchanged']
        untouched.append({'scenario': scenario, 'result': result})
    return {'directed': out, 'untouched_physical_setups': untouched}


def alpine_stacking():
    from fs_bot.map.map_data import is_region_playable
    s = sparse('A5')
    activation = explicit(s, rc.ROMANS, {})
    assert not is_region_playable(s, rc.CISALPINA, rc.AEDUI)
    ready(s, 'A40')
    controlled = deepcopy(s)
    roman_control = deepcopy(s)
    manual = deepcopy(s)
    before = count_pieces(s, rc.CISALPINA, rc.AEDUI, rc.WARBAND)
    observed = run_bot(s, rc.AEDUI)
    assert count_pieces(s, rc.CISALPINA, rc.AEDUI, rc.WARBAND) == before + 3
    assert not is_region_playable(s, rc.CISALPINA, rc.AEDUI)
    def placements(faction, piece, count, regions):
        return {'placements': [{'region': r, 'faction': faction, 'piece_type': piece, 'count': count}
                               for r in regions]}
    bad = placements(rc.AEDUI, rc.WARBAND, 3, [rc.CISALPINA])
    accepted_invalid = explicit(manual, rc.AEDUI, bad)
    assert count_pieces(manual, rc.CISALPINA, rc.AEDUI, rc.WARBAND) == 3
    unrestricted = sparse('A40')
    unmarked = explicit(unrestricted, rc.AEDUI, bad)
    assert is_region_playable(unrestricted, rc.CISALPINA, rc.AEDUI)
    legal_other_regions = explicit(controlled, rc.AEDUI,
        placements(rc.AEDUI, rc.WARBAND, 3, [rc.UBII, rc.SEQUANI, rc.PROVINCIA]))
    assert count_pieces(controlled, rc.CISALPINA, rc.AEDUI) == 0
    legal_roman = explicit(roman_control, rc.ROMANS,
        placements(rc.ROMANS, rc.AUXILIA, 2, [rc.CISALPINA]))
    assert count_pieces(roman_control, rc.CISALPINA, rc.ROMANS, rc.AUXILIA) == 5
    return {'real_A5_activation': activation, 'bot_forbidden_placement': observed,
            'authored_forbidden_placement': accepted_invalid,
            'same_authored_plan_without_A5_control': unmarked,
            'three_other_regions_control': legal_other_regions,
            'Roman_recipient_under_A5_control': legal_roman,
            'census_note': 'Physical census and structure remain clean despite the forbidden stack.'}


if __name__ == '__main__':
    print(json.dumps({'alpine_allies': alpine_allies(), 'lost_eagle': lost_eagle(), 'alpine_stacking': alpine_stacking()}, indent=2, sort_keys=True))
