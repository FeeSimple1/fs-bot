"""Verify the paired Event repair, replay traces, and reviewed baseline."""

import json
import re
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree

from fs_bot.state.serialize import decode
from fs_bot.tools.balance_smoke import BASELINE_PATH
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


ROOT = Path(__file__).resolve().parent
PARENT = '0443eecba4d717bbfc6a89fc9d83e1645e13807b'
PARENT_DIGEST = 'bcad6fe110ef49ed588afd657e09cdbb9bb908679f4a7a08fda8c4a214f740cd'
BASELINE_PATTERN = re.compile(r'^\[(.+) seed= *([0-9]+)\] winner=(.+) \(([0-9]+) cards\)$', re.M)


def load(name):
    return json.loads((ROOT / name).read_text())


def key(row):
    return row['scenario'], row['seed'], row['card_edition']


def tests(name):
    suites = list(ElementTree.parse(ROOT / name).iter('testsuite'))
    return {k: sum(int(s.get(k, 0)) for s in suites)
            for k in ('tests', 'failures', 'errors', 'skipped')}


def batch(path, seeds, edition, digest):
    meta = load(f'{path}/metadata.json')
    assert meta['source_sha256'] == digest and meta['hash_seed'] == 0
    assert set(meta['scenarios']) == set(SCENARIOS)
    assert meta['seeds'] == list(seeds) and meta['card_edition'] == edition
    records = [json.loads(line) for line in (ROOT / path / 'games.jsonl').read_text().splitlines()]
    games = {key(r): r for r in records}
    assert len(games) == len(records) == len(seeds) * len(SCENARIOS)
    assert games.keys() == {(s, n, edition) for s in SCENARIOS for n in seeds}
    for row in records:
        assert row['source_sha256'] == digest
        assert all(row[k] is True for k in ('completed', 'game_completed', 'audit_completed'))
        assert not row.get('error') and not row['errors'] and not row['integrity_findings']
        assert not _outcome_issues(row)
        assert len(row['final_state_sha256']) == 64
        assert all(d['severity'] == 'legal-decline' for d in row['diagnostics'])
        assert all(d['severity'] == 'legal-decline' for d in row['diagnostic_occurrences'])
        assert sum(d['count'] for d in row['diagnostics']) == len(row['diagnostic_occurrences'])
    return games


def compare(old, new):
    fields = ('final_state_sha256', 'cards', 'winters', 'winner', 'termination',
              'ended_on_final_winter', 'diagnostic_occurrences', 'final_ranking')
    assert old.keys() == new.keys()
    differences = {field: [list(k) for k in sorted(new) if new[k][field] != old[k][field]]
                   for field in fields}
    return {'games': len(new), 'interludes': sum(r['interlude_completed'] for r in new.values()),
            'diagnostic_incidents': sum(len(r['diagnostic_occurrences']) for r in new.values()),
            'differences': differences}


def fuzz_pair(first, second, seeds, digest):
    for extension in ('json', 'log'):
        assert (ROOT / f'{first}.{extension}').read_bytes() == (ROOT / f'{second}.{extension}').read_bytes()
    data = load(f'{first}.json')
    assert data['metadata']['source_sha256'] == digest
    assert all(data['metadata'][k] for k in ('reactive', 'events', 'replay'))
    expected = {(s, n, 'second-edition') for s in SCENARIOS for n in seeds}
    assert len(data['records']) == data['games'] == len(expected)
    assert {key(r) for r in data['records']} == expected
    assert all(r['game_completed'] and not r['findings'] for r in data['records'])
    assert not data['hard_findings']
    for field in ('human_turns', 'event_turns', 'events_ok', 'partial'):
        assert data[field] == sum(r[field] for r in data['records'])
    return data


def trace_pairs(kind, old, new, keys, digest):
    def traces(side, expected_digest):
        trace = decode(load(f'trace_{kind}_{side}.json'))
        assert trace['source']['source_sha256'] == expected_digest
        rows = {tuple(row['task']): row for row in trace['games']}
        assert set(rows) == set(keys) and len(rows) == len(trace['games'])
        return rows

    first = []
    parent, repaired = traces('parent', PARENT_DIGEST), traces('final', digest)
    for task in sorted(keys):
        for trace, recorded in ((parent, old), (repaired, new)):
            assert all(recorded[task][field] == value
                       for field, value in trace[task]['outcome'].items())
        a, b = next((a, b) for a, b in zip(parent[task]['cards'], repaired[task]['cards'])
                    if (a['after_sha256'], a['actions']) != (b['after_sha256'], b['actions']))
        assert a['card'] == b['card'] and a['ordinal'] == b['ordinal']
        assert a['before_sha256'] == b['before_sha256'] and a['before_rng_sha256'] == b['before_rng_sha256']
        card = a['card']
        actors = {2: ('Belgae',), 3: ('Belgae', 'Arverni', 'Germans'),
                  5: ('Belgae', 'Arverni'), 'A5': ('Belgae', 'Germans'), 32: ('Romans',)}
        old_event = next(e for e in a['events'] if e['card'] == card and not e['human']
                         and e['faction'] in actors[card])
        new_event = next((e for e in b['events'] if e['card'] == card and not e['human']
                          and e['faction'] == old_event['faction']), None)
        row = {'task': task, 'card': card, 'ordinal': a['ordinal'],
               'faction': old_event['faction']}
        if card == 32:
            assert not (old_event['params'] or {}).get('moves')
            assert new_event is not None and new_event['result']['executed']
            moves = new_event['params']['moves']
            assert moves and all('Britannia' not in (m['from_region'], m['to_region']) for m in moves)
            row['moves'] = moves
        else:
            assert new_event is None
            if card == 2:
                assert not old_event['result'].get('free_actions')
            elif card == 3:
                assert old_event['track_legions'] > 4
            else:
                assert old_event['senate'] == 'Adulation'
        first.append(row)
    return first


def balance_records(name):
    matches = BASELINE_PATTERN.findall((ROOT / name).read_text())
    values = {f'{scenario}|{seed}': {'winner': winner, 'cards': int(cards)}
              for scenario, seed, winner, cards in matches}
    assert len(matches) == len(values)
    return values


def balance(legacy, parent):
    def matrix(rows):
        return {f'{scenario}|{seed}': {k: r[k] for k in ('winner', 'cards')}
                for (scenario, seed, _), r in rows.items()}
    current = balance_records('balance-final.log')
    assert current == balance_records('balance-before-baseline.log') == matrix(legacy)
    assert balance_records('parent/balance-final.log') == matrix(parent)
    assert current == load('balance-baseline-verified.json')['games']
    assert current == json.loads(BASELINE_PATH.read_text())['games']
    canary = balance_records('canary-final.log')
    assert canary == {k: v for k, v in current.items() if int(k.rsplit('|', 1)[-1]) <= 3}
    assert all('OK: balance within band' in (ROOT / name).read_text()
               for name in ('balance-final.log', 'balance-before-baseline.log', 'canary-final.log'))
    old = load('balance-baseline-before.json')['games']
    assert current.keys() == old.keys()
    changes = {k: {'from': old[k], 'to': current[k]} for k in current if current[k] != old[k]}
    assert len(changes) == 10
    return {'games': len(current), 'canary_games': len(canary),
            'band_percentage_points': 15, 'canary_band_percentage_points': 40,
            'changes': changes}


def main():
    source = load('source-final.json')
    digest = source['source_sha256']
    assert source['commit'] == PARENT and source['python_files'] == 615
    assert source_identity()['source_sha256'] == digest
    parent_tests, focused, initial, full = (tests(n) for n in
        ('parent-final.xml', 'focused-final.xml', 'pytest-before-baseline.xml', 'pytest-final.xml'))
    assert parent_tests == dict(tests=18, failures=15, errors=0, skipped=0)
    assert focused == dict(tests=861, failures=0, errors=0, skipped=0)
    assert initial == dict(tests=10178, failures=1, errors=0, skipped=0)
    assert full == dict(tests=10178, failures=0, errors=0, skipped=0)
    failed = [row.get('name') for row in ElementTree.parse(ROOT / 'pytest-before-baseline.xml').iter('testcase')
              if row.find('failure') is not None]
    assert failed == ['test_bot_balance_canary']

    comparisons, parent_bots, repaired_bots = {}, {}, {}
    for name, edition, seeds in (('final-legacy', 'legacy', range(1, 21)),
                                 ('final-second', 'second-edition', range(45, 49))):
        old = batch(f'parent/{name}', seeds, edition, PARENT_DIGEST)
        new = batch(name, seeds, edition, digest)
        comparisons[edition] = compare(old, new)
        parent_bots.update(old)
        repaired_bots.update(new)
        if edition == 'legacy':
            verified_balance = balance(new, old)
    bot_keys = {tuple(task) for task in load('bot-changed.json')}
    assert bot_keys == {k for k in repaired_bots if repaired_bots[k]['final_state_sha256']
                        != parent_bots[k]['final_state_sha256']}
    bot_traces = trace_pairs('bots', parent_bots, repaired_bots, bot_keys, digest)
    assert Counter(row['card'] for row in bot_traces) == {2: 4, 3: 8, 5: 2, 32: 5}

    fuzz = fuzz_pair('fuzz0-final', 'fuzz987-final', range(45, 49), digest)
    old_fuzz = load('parent/fuzz0-final.json')
    assert old_fuzz['metadata']['source_sha256'] == PARENT_DIGEST
    old_mixed = {key(row): row for row in old_fuzz['records']}
    new_mixed = {key(row): row for row in fuzz['records']}
    assert old_mixed.keys() == new_mixed.keys()
    mixed_keys = {tuple(task) for task in load('mixed-changed.json')}
    assert mixed_keys == {k for k in new_mixed if old_mixed[k] != new_mixed[k]}
    mixed_traces = trace_pairs('mixed', old_mixed, new_mixed, mixed_keys, digest)
    assert Counter(row['card'] for row in mixed_traces) == {2: 1, 3: 1, 32: 1}
    ci_fuzz = fuzz_pair('fuzz-ci0', 'fuzz-ci7', range(201, 204), digest)

    def mixed_summary(data, hashes):
        return {**{k: data[k] for k in ('games', 'human_turns', 'event_turns', 'events_ok',
                                       'partial', 'hard_findings', 'batch_digest')},
                'hash_seeds': hashes, 'json_and_stdout_match': True}
    print(json.dumps({
        'source': source, 'parent_directed': parent_tests, 'focused': focused,
        'initial_suite': initial, 'full_suite': full, 'bots': comparisons,
        'bot_first_differences': bot_traces, 'mixed_first_differences': mixed_traces,
        'mixed': mixed_summary(fuzz, [0, 987]), 'ci_mixed': mixed_summary(ci_fuzz, [0, 7]),
        'balance': verified_balance,
    }, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
