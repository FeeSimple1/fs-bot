"""Check the Roman Quarters repair evidence from a checkout of Batch 2."""

from collections import Counter
from pathlib import Path
from xml.etree import ElementTree
import json
import re

from fs_bot import rules_consts as rc
from fs_bot.tools.balance_smoke import BASELINE_PATH
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity


ROOT = Path(__file__).resolve().parent
PARENT_COMMIT = "1299b41ad4d1dac7db68dde4a4628bb9410c2d40"
PARENT_RUN_BASE = "5f7d0583f29784812f65eca9829c9b631ce43820"
PARENT_DIGEST = "4504d842ed230694a914f640a63900bd630243701805b3ea70d483129eac8217"
REPAIR_DIGEST = "9c2c9c927fc544966796c9fac5ff086e9152dec48148966ba41c88672a379144"
BALANCE_LINE = re.compile(r"^\[(.+) seed= *(\d+)\] winner=(.+) \((\d+) cards\)$", re.M)


def load(path):
    return json.loads((ROOT / path).read_text())


def test_totals(path, tests, failures=0):
    suite, = ElementTree.parse(ROOT / path).iter("testsuite")
    expected = {"tests": tests, "failures": failures, "errors": 0, "skipped": 0}
    assert all(int(suite.get(field)) == value for field, value in expected.items()), path
    return expected


def batch(path, edition, seeds, commit, digest):
    metadata = load(path / "metadata.json")
    assert metadata["commit"] == commit and metadata["source_sha256"] == digest
    assert metadata["hash_seed"] == 0 and metadata["card_edition"] == edition
    assert set(metadata["scenarios"]) == set(SCENARIOS) and metadata["seeds"] == list(seeds)
    rows = [json.loads(line) for line in (ROOT / path / "games.jsonl").read_text().splitlines()]
    records = {(row["scenario"], row["seed"]): row for row in rows}
    assert len(rows) == len(records) == len(SCENARIOS) * len(seeds)
    assert records.keys() == {(scenario, seed) for scenario in SCENARIOS for seed in seeds}
    for row in records.values():
        assert all(row[field] for field in ("completed", "game_completed", "audit_completed"))
        assert row["commit"] == commit and row["source_sha256"] == digest
        assert row["card_edition"] == edition
        assert not row["errors"] and not row["integrity_findings"] and not _outcome_issues(row)
        assert len(row["final_state_sha256"]) == 64
        assert all(d["severity"] == "legal-decline" for d in row["diagnostics"])
        assert all(d["severity"] == "legal-decline" for d in row["diagnostic_occurrences"])
        assert sum(d["count"] for d in row["diagnostics"]) == len(row["diagnostic_occurrences"])
    return records


def compare_batches(folder, edition, seeds):
    before = batch(Path("parent") / folder, edition, seeds, PARENT_RUN_BASE, PARENT_DIGEST)
    after = batch(Path("repair") / folder, edition, seeds, PARENT_COMMIT, REPAIR_DIGEST)
    ignored = {"commit", "source_sha256", "seconds"}
    for key, row in after.items():
        assert {k: v for k, v in row.items() if k not in ignored} == {
            k: v for k, v in before[key].items() if k not in ignored
        }, key
    return after


def compare_replay(stem, second_hash, seeds):
    for extension in ("json", "log"):
        assert (ROOT / f"repair/{stem}0.{extension}").read_bytes() == (
            ROOT / f"repair/{stem}{second_hash}.{extension}"
        ).read_bytes()
    before = load(f"parent/{stem}0.json")
    after = load(f"repair/{stem}0.json")
    for run, commit, digest in (
        (before, PARENT_RUN_BASE, PARENT_DIGEST),
        (after, PARENT_COMMIT, REPAIR_DIGEST),
    ):
        assert run["metadata"]["commit"] == commit
        assert run["metadata"]["source_sha256"] == digest
        assert run["metadata"]["card_edition"] == "second-edition"
        assert run["metadata"]["seeds"] == list(seeds)
        assert all(run["metadata"][k] for k in ("reactive", "events", "replay"))
        assert run["games"] == len(run["records"]) == len(SCENARIOS) * len(seeds)
        assert {(r["scenario"], r["seed"]) for r in run["records"]} == {
            (scenario, seed) for scenario in SCENARIOS for seed in seeds
        }
        assert not run["hard_findings"]
        assert all(r["game_completed"] and not r["findings"] for r in run["records"])
        for field in ("human_turns", "event_turns", "events_ok", "partial"):
            assert run[field] == sum(record[field] for record in run["records"])
    assert {k: v for k, v in after.items() if k != "metadata"} == {
        k: v for k, v in before.items() if k != "metadata"
    }
    return {k: after[k] for k in (
        "games", "human_turns", "event_turns", "events_ok", "partial", "hard_findings", "batch_digest"
    )}


def verify_witness():
    cases = load("parent/witness/results.json")["cases"]
    assert len(cases) == len(SCENARIOS) == len({case["scenario"] for case in cases})
    for case in cases:
        assert case["save_load_identical"]
        faulty = case["defective"]["result"]["roman_quartering"]
        authored = case["complete_payment_control"]["result"]["roman_quartering"]
        assert faulty["total_cost"] == 2 and faulty["rolls"][rc.NERVII]["rolls"] == [2, 5]
        assert case["defective"]["after"]["destination_auxilia"] == 2
        assert authored["total_cost"] == 6 and not authored["rolls"]
        assert case["complete_payment_control"]["after"]["destination_auxilia"] == 3
    return len(cases)


def main():
    assert source_identity()["source_sha256"] == REPAIR_DIGEST
    identity = load("repair/source.json")
    assert identity["commit"] == PARENT_COMMIT and identity["source_sha256"] == REPAIR_DIGEST
    tests = {
        "parent_directed": test_totals("parent/directed.xml", 10, failures=8),
        "repair_directed": test_totals("repair/directed.xml", 10),
        "repair_focused": test_totals("repair/focused.xml", 249),
        "repair_full": test_totals("repair/full.xml", 10240),
    }
    failures = Counter(
        node.get("name").split("[")[0]
        for node in ElementTree.parse(ROOT / "parent/directed.xml").iter("testcase")
        if node.find("failure") is not None
    )
    assert failures == {
        "test_roman_quarters_pays_for_resident_and_arriving_auxilia": 5,
        "test_roman_quarters_combines_two_arrivals_and_keeps_free_garrison": 3,
    }
    legacy = compare_batches("legacy", "legacy", range(1, 21))
    second = compare_batches("second", "second-edition", range(49, 53))
    balance_log = (ROOT / "repair/balance.log").read_text()
    balance_rows = BALANCE_LINE.findall(balance_log)
    balance = {f"{s}|{seed}": {"winner": w, "cards": int(c)} for s, seed, w, c in balance_rows}
    expected = {
        f"{scenario}|{seed}": {"winner": row["winner"], "cards": row["cards"]}
        for (scenario, seed), row in legacy.items()
    }
    assert len(balance_rows) == len(balance) == len(expected) == 100
    assert balance == expected == json.loads(BASELINE_PATH.read_text())["games"]
    assert "OK: balance within band." in balance_log
    verified = {
        "source": identity,
        "tests": tests,
        "parent_witness_scenarios": verify_witness(),
        "bot_games": len(legacy) + len(second),
        "interludes": sum(row["interlude_completed"] for row in (*legacy.values(), *second.values())),
        "mixed_main": compare_replay("fuzz", 987, range(49, 53)),
        "mixed_additional": compare_replay("fuzz-ci", 7, range(201, 204)),
        "balance_games": len(balance),
    }
    print(json.dumps(verified, indent=2))


if __name__ == "__main__":
    main()
