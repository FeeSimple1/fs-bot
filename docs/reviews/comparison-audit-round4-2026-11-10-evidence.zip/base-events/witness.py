"""Round 4 audit witnesses. Run from audited repo with PYTHONPATH=.
Assertions deliberately freeze observed defects; this is evidence, not desired regressions.
No production source modifications. All fixtures derive from real Great Revolt setup.
"""
import json
from fs_bot import rules_consts as rc
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import validate_state, check_structural_integrity
from fs_bot.board.pieces import count_pieces, place_piece
from fs_bot.cards.card_effects import _unally_tribe
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.moves import validate_player_action
from fs_bot.tools.seat_session import validate_response, board_copy
from fs_bot.state.serialize import encode


def clean(state):
    result = {'census': validate_state(state), 'structure': check_structural_integrity(state)}
    assert result == {'census': [], 'structure': []}, result
    return result


def board(card, edition):
    state = setup_scenario(rc.SCENARIO_GREAT_REVOLT, seed=4)
    state.update(current_card=card, card_edition=edition, non_player_factions=set())
    clean(state)
    return state


def event(state, card, params, *, actor=rc.BELGAE, shaded=False):
    decision = {'action': 'event', 'player_action': {
        'command': rc.FIRST_DID_EVENT, 'details': {
            'card_id': card, 'text_preference': rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,
            'event_params': params}}}
    before_checks = clean(state)
    validate_response(state, {'kind': 'turn', 'faction': actor, 'options': ['event']}, decision)
    before = encode(board_copy(state))
    ok, info = validate_player_action(state, actor, decision['player_action'])
    assert ok, info
    assert encode(board_copy(state)) == before, 'Preview changed live board or RNG'
    result = execute_decision(state, actor, decision)
    assert result['executed'] and not result.get('errors'), result
    return {'decision': decision, 'durable_validation': 'accepted', 'preview_ok': ok,
            'preview_preserved_board_rng': True, 'before_checks': before_checks,
            'result': result, 'after_checks': clean(state)}


def warbands(state, faction):
    return sum(count_pieces(state, region, faction, rc.WARBAND) for region in state['spaces'])


def celtic_rites(edition):
    out = {}
    for label, targets, expected in [('control', [rc.ARVERNI], 17),
                                     ('duplicate', [rc.ARVERNI, rc.ARVERNI], 14),
                                     ('empty', [], 20)]:
        state = board(46, edition)
        state['resources'][rc.ARVERNI] = 20
        observed = event(state, 46, {'target_factions': targets})
        assert state['resources'][rc.ARVERNI] == expected
        observed.update(before_resources=20, after_resources=expected,
                        forced_ineligible=state.get('forced_ineligible', {}))
        out[label] = observed
    return out


def hostages(edition):
    out = {}
    for label, tribe, owner in [('control', rc.TRIBE_HELVII, rc.BELGAE),
                                 ('wrong_region', rc.TRIBE_CATUVELLAUNI, rc.BELGAE),
                                 ('non_gallic_ally', rc.TRIBE_HELVII, rc.ROMANS)]:
        state = board(22, edition)
        # Normal legal fixture adjustment: return Helvii's Roman Ally disc to
        # Available. The Roman garrison remains in Provincia. Britannia is empty.
        _unally_tribe(state, rc.TRIBE_HELVII)
        assert count_pieces(state, rc.BRITANNIA, rc.ROMANS) == 0
        before_wb = count_pieces(state, rc.PROVINCIA, rc.BELGAE, rc.WARBAND)
        observed = event(state, 22, {'target_tribes': [{
            'tribe': tribe, 'region': rc.PROVINCIA, 'faction': owner,
            'warband_faction': rc.BELGAE}]}, shaded=True)
        assert state['tribes'][tribe]['allied_faction'] == owner
        assert count_pieces(state, rc.PROVINCIA, rc.BELGAE, rc.WARBAND) == before_wb + 1
        observed.update(chosen_tribe=tribe, ally_owner=owner,
                        roman_pieces_in_britannia=0,
                        after_tribes={t: state['tribes'][t] for t in
                                      (rc.TRIBE_HELVII, rc.TRIBE_CATUVELLAUNI)},
                        added_belgic_warbands_in_provincia=1)
        out[label] = observed
    return out


def druids(edition):
    out = {}
    cases = [('control_one', [rc.AEDUI], False),
             ('control_order', [rc.AEDUI, rc.ARVERNI, rc.BELGAE], False),
             ('roman_recipient', [rc.ROMANS], False),
             ('duplicate', [rc.AEDUI, rc.AEDUI], False),
             ('wrong_order', [rc.BELGAE, rc.AEDUI, rc.ARVERNI], False),
             ('empty', [], False), ('decline_mandatory', [rc.AEDUI], True)]
    for label, targets, decline in cases:
        state = board(48, edition)
        seen = []
        before = {f: warbands(state, f) for f in rc.GALLIC_FACTIONS}
        before_aux = count_pieces(state, rc.PROVINCIA, rc.ROMANS, rc.AUXILIA)
        def agent(st, faction, request):
            if request['kind'] != 'free_action':
                return None
            seen.append(faction)
            if decline:
                return {'decline': True}
            region = {rc.ROMANS: rc.PROVINCIA, rc.AEDUI: rc.AEDUI_REGION,
                      rc.ARVERNI: rc.ARVERNI_REGION, rc.BELGAE: rc.MORINI}[faction]
            if faction == rc.ROMANS:
                return {'command': rc.CMD_RECRUIT, 'sa': 'No SA', 'regions': [region],
                        'details': {'recruit_plan': [{'region': region,
                             'action': 'place_auxilia', 'count': 1}]}}
            return {'command': rc.CMD_RALLY, 'sa': 'No SA', 'regions': [region],
                    'details': {'rally_plan': {'steps': [{'region': region,
                         'action': 'place_warbands', 'count': 1}]}}}
        state['decision_agent'] = agent
        observed = event(state, 48, {'target_factions': targets})
        assert seen == targets
        gains = {f: warbands(state, f) - before[f] for f in rc.GALLIC_FACTIONS}
        aux_gain = count_pieces(state, rc.PROVINCIA, rc.ROMANS, rc.AUXILIA) - before_aux
        assert gains[rc.AEDUI] == (0 if decline else targets.count(rc.AEDUI))
        assert aux_gain == targets.count(rc.ROMANS)
        observed.update(actual_command_order=seen, added_warbands=gains,
                        added_roman_auxilia=aux_gain)
        out[label] = observed
    return out


def germanic_horse(edition):
    out = {}
    for label, actor, params, expected_owner, expected_survivors in [
        ('control', rc.BELGAE, {}, rc.BELGAE, 6),
        ('gift_to_other_gaul', rc.BELGAE, {'faction': rc.AEDUI}, rc.AEDUI, 4),
        ('roman_gift', rc.ROMANS, {'faction': rc.AEDUI}, rc.AEDUI, 4),
    ]:
        state = board(59, edition)
        place_piece(state, rc.PICTONES, rc.AEDUI, rc.WARBAND, 4)
        place_piece(state, rc.PICTONES, rc.GERMANS, rc.WARBAND, 8)
        observed = event(state, 59, params, actor=actor, shaded=True)
        assert state['capability_owners'][59] == expected_owner
        battle = {'action': 'command', 'player_action': {
            'command': rc.CMD_BATTLE, 'details': {'battle_plan': [
                {'region': rc.PICTONES, 'target': rc.GERMANS}]}}}
        validate_response(state, {'kind': 'turn', 'faction': rc.AEDUI,
                                 'options': ['command']}, battle)
        battle_result = execute_decision(state, rc.AEDUI, battle)
        assert battle_result['executed'] and not battle_result.get('errors')
        survivors = count_pieces(state, rc.PICTONES, rc.GERMANS, rc.WARBAND)
        assert survivors == expected_survivors
        observed.update(capability_owner=expected_owner, ensuing_battle=battle,
                        battle_result=battle_result, germans_before=8,
                        germans_after=survivors, final_checks=clean(state))
        out[label] = observed
    return out


def main():
    data = {'audited_commit': 'b951908af2b21cc87a7e27d9a5314b3f257d0147',
            'fixture': 'Great Revolt, seed 4; all-human seats; documented helper-only adjustments',
            'editions': {}}
    for edition in ('original', 'second-edition'):
        data['editions'][edition] = {'BE4-01': hostages(edition),
                                    'BE4-02': celtic_rites(edition),
                                    'BE4-03': druids(edition),
                                    'BE4-04': germanic_horse(edition)}
    print(json.dumps(data, indent=2, sort_keys=True, default=str))

if __name__ == '__main__':
    main()
