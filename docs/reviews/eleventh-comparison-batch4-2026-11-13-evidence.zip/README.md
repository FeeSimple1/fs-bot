# Eleventh comparison repair Batch 4 evidence

Batch 4 closes UI11-01. The parent is
`0c2e6fa8098480ac84676d5e61dcb119ae8a3a4d`. The repaired Python source SHA-256
is `95e58d60023a24eec5f2ca576b9d010f20faf4e23b4cacc2ae3e7c034a4c152d`
across 628 files. The verifier reads the paired game records and protected
source hashes from the committed Batch 2 and Batch 3 evidence. Run
`sha256sum -c SHA256SUMS` from the extracted directory.

## Reproduce

Use Python 3.12.14 with pytest and pytest-xdist. From the repaired checkout,
set `EVIDENCE` to the extracted archive, `PARENT` to a clean checkout of the
tested parent, and `OUT` to an empty absolute output directory.

```bash
PYTHONHASHSEED=0 python "$EVIDENCE/probe_frontend.py" --repo "$PARENT"
PYTHONHASHSEED=0 python "$EVIDENCE/probe_frontend.py" --repo . --repaired
PYTHONHASHSEED=987 python "$EVIDENCE/probe_frontend.py" --repo . --repaired
PYTHONHASHSEED=0 python -m pytest -q -n 6 -o "cache_dir=$OUT/.pytest_cache" --junitxml="$OUT/full.xml"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 1-20 --card-edition legacy --workers 2 --out "$OUT/legacy"
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 57-60 --card-edition second-edition --workers 2 --out "$OUT/second-edition"
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 57-60 --card-edition second-edition --out "$OUT/fuzz0.json"
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 57-60 --card-edition second-edition --out "$OUT/fuzz987.json"
PYTHONHASHSEED=0 python -m fs_bot.tools.balance_smoke --seeds 1-20
PYTHONPATH=. python "$EVIDENCE/verify_results.py"
```

From the parent checkout, reproduce the nine expected failures with the
archived test module and selector.

```bash
PYTHONPATH=. PYTHONHASHSEED=0 python -m pytest -q "$EVIDENCE/test_eighth_comparison_winter_campaign.py" -k 'terminal_campaign and (enlist or borrowed_march)'
```

The directed repair run includes `fs_bot/tests/*winter_campaign*.py`,
`fs_bot/tests/*enlist*.py`, plus `test_action_window_frontends.py`,
`test_ninth_comparison_frontend.py`, `test_tenth_comparison_frontends.py`
and `test_ordinary_march_dropoffs.py` under `fs_bot/tests`.
