"""Verify publication links, tested source, protected inputs and evidence."""
from pathlib import Path
from urllib.parse import unquote
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'fs-bot'
manifest = json.loads((HERE / 'prepared-source.json').read_text())
protected = json.loads((HERE / 'protected-before.json').read_text())
for mapping in (manifest['files'], protected):
    for name, digest in mapping.items():
        assert hashlib.sha256((REPO / name).read_bytes()).hexdigest() == digest, name
suite = ET.parse(HERE / 'after-full.xml').getroot().find('testsuite')
assert int(suite.attrib['tests']) == 6886
assert all(int(suite.attrib[k]) == 0 for k in ('errors', 'failures', 'skipped'))
results = json.loads((REPO / 'docs/reviews/colony-event-defaults-2026-11-02-results.json').read_text())
assert results['passed'] and results['exact_cross_hash_json_and_stdout_match']
assert results['baseline']['passed'] and results['baseline']['unchanged']
progress = json.loads((REPO / 'docs/human-choice-progress.json').read_text())
assert progress['total'] == len(progress['findings']) == 50
assert progress['closed'] == sum(f['status'] == 'closed' for f in progress['findings']) == 18
assert progress['open'] == 32
changed = subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], cwd=REPO, text=True).splitlines()
markdown = {REPO / name for name in changed if name.endswith('.md')}
markdown.add(REPO / 'docs/reviews/colony-event-defaults-2026-11-02.md')
links = 0
for path in markdown:
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text()):
        target = target.split('#', 1)[0]
        if not target or '://' in target or target.startswith('mailto:'):
            continue
        assert (path.parent / unquote(target)).resolve().exists(), (path, target)
        links += 1
assert '**pending**' not in (REPO / 'docs/reviews/colony-event-defaults-2026-11-02.md').read_text()
archive = REPO / 'docs/reviews' / results['evidence_archive']['path']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == results['evidence_archive']['sha256']
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    index = json.loads(z.read('evidence-index.json'))
    for name, item in index.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == item['sha256']
proof = {'python_files_unchanged': len(manifest['files']),
         'protected_inputs_unchanged': len(protected), 'full_tests_passed': 6886,
         'markdown_files_checked': len(markdown), 'local_links_resolve': links,
         'original_findings_closed': 18, 'original_findings_open': 32,
         'archive_content_verified': True, 'passed': True}
(HERE / 'release-preflight.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof, indent=2))
