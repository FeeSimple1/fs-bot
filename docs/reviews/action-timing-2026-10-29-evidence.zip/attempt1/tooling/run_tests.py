"""Run the full suite on a prepared freeze; never launches simulation matrix."""
from __future__ import annotations

import argparse
from pathlib import Path

from common import (ROOT, PYTHON, BASELINE_SHA, read, write_json, identity,
                    validate_current, verify_snapshots, fixture_files, execute,
                    pytest_argv, verify_test_inventory)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--source-sha256', required=True)
    parser.add_argument('--workers', type=int, default=6)
    args = parser.parse_args()
    if Path(args.attempt).name != args.attempt or args.workers < 1:
        parser.error('simple attempt name and positive workers required')
    run = ROOT / args.attempt
    freeze = read(run / 'freeze.json')
    source = validate_current(args.source_sha256, freeze)
    verify_snapshots(run, freeze)
    verify_test_inventory(run, freeze, include_results=False)
    if (run / 'tests.xml').exists():
        parser.error('existing full-suite output must be preserved; use a new attempt')
    argv = pytest_argv(run, workers=args.workers)
    fixtures = fixture_files()
    status = execute(run, 'tests', argv, 0, freeze)
    status.update(source=source, source_after=identity(), pytest_workers=args.workers,
                  balance_baseline_sha256=BASELINE_SHA, check='tests',
                  fixture_files_before=fixtures, fixture_files_after=fixture_files())
    write_json(run / 'tests.status.json', status)
    if status['runner_exit_code'] == 0:
        try:
            status['exact_collection'] = verify_test_inventory(run, freeze)
        except (ValueError, KeyError, OSError) as exc:
            status.update(runner_exit_code=125, collection_error=str(exc))
        write_json(run / 'tests.status.json', status)
    print({key: status[key] for key in ('exit_code', 'runner_exit_code', 'source_changed')})
    return status['runner_exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
