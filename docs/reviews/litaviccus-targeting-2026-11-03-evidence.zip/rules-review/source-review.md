# Independent Litaviccus review — 3 November 2026

Parent: `4f33e09347d809846d61e8cc25ebf711100372fc`. Local reference documents only. The owner adopted PR-12's conservative human-response model; that model remains provisional, distinct from the printed requirements below.

## Printed scope

- Numeric45 shaded grants one free Battle against Romans using Aedui pieces as the executor's own, with Ambush if able (`Card Reference`,45). The normal Ambush Leader/range condition remains; the tip changes the combined Hidden-piece comparison and does not waive other prerequisites.
- The base Belgic Event instruction says to force the most Losses on Legions; if none, treat the Event as No Belgae. Both pre-Event availability and actual target selection must use that same condition.
- Under §§8.2.3/8.5.1, retain per-Region Battle safety: inflict more Losses than suffered and no Loss on Ambiorix, with Roman Defender Loss rolls assumed to remove their pieces. The Event already supplies the Battle Command; normal under-threat triggers must not prevent a smaller printed Event force from participating or force a March instead.
- Equal best candidates use the state's seeded RNG (§8.3.4); previews do not consume it. Actual human reactions and saving rolls remain live after selection.
- §8.4.3 defines the NP Roman Retreat response. PR-12 supplies the lower forecast across human standing/Retreat choices, retaining ordinary default casualty order rather than optimizing every human casualty selection. Uncertain legal host responses and non-Defender-loss saving rolls must not be sampled from future live RNG.
- §8.4.4 Frost/player-victory restrictions still apply; this ruling does not waive them.
- The new NP selector applies to base numeric45 for Belgae. Ariovistus uses A45 Savage Dictates, a separate Event; other executors and human legal target choices remain separate.

## Confirmed adjacent physical-force defect

The original witness `combined-force-parent-witness.py` uses a direct NP helper to expose the old mechanics: two Aedui Hidden Warbands attack four Roman Auxilia without Ambush. They cause one Roman Loss, after which the three surviving Auxilia inflict one Counterattack Loss. The old path leaves both Aedui counters Hidden and untouched. Correct Battle participation removes one and Reveals the survivor, while preserving Aedui physical ownership/Available and Control accounting.

After the selector repair, the NP correctly declines this zero-Legion position. The durable regression therefore explicitly uses human Belgic/Arverni execution of the same legal grant; that isolates the physical participation bug without bypassing the repaired NP instruction.

Aedui participation includes the card's printed "pieces", not just Warbands. When the optional base Diviciacus Leader is present, his ordinary Leader contribution and physical loss rules remain his own. He must not be renamed to Ambiorix, Vercingetorix, or a Successor to grant the executing faction an otherwise absent Special Ability permission. A28's narrower mobile-only cohort must remain narrow when its helper is reused.

## Independent cases

`fs_bot/tests/test_litaviccus_np_independent.py` covers:

1. The one exposed Legion beats a larger Auxilia-only Roman stack in all three base scenarios.
2. Zero predicted Legion Losses produces No Belgae before Event commitment, for human and NP Romans.
3. A small Aedui-only force participates and Ambushes using the nearby actual Belgic Leader.
4. Aedui-only Counterattack loss and Reveal work for human Belgae and Arverni.
5. NP Romans and conservative human Romans produce the one-Legion Retreat forecast rather than two standing Losses.
6. Fort halving and Auxilia absorption precede Legion exposure.
7. Equal inflicted/suffered Losses fail the printed regional Battle safety test.
8. Forecast/availability do not consult human callbacks, sample live future dice, or mutate state.
9. Expansion scenarios do not activate the base selector.
10. Equal-target random choice occurs only on commitment.
11. A live human can stand after the forecast assumed safer Retreat, and real rolls determine the resulting two Legion removals.

Initial independent suite: **17 passed** on the candidate (`independent-candidate-attempt1.log`). The identical final file on the verified detached parent gives **17 failures** (`independent-parent-final.log`): **eight behavioral failures against existing public APIs**, plus **nine expected imports of the new forecast API absent from the parent**. This is not a claim of seventeen separate parent bugs. The parent log prints both HEAD4f33e09347d809846d61e8cc25ebf711100372fc and the imported execute.py path. The earlier15-case parent attempt remains intact.

Review of the candidate source found no acceptance blocker in the bounded selector/combined-force change: availability and execution use the same positive maximum, the full Battle simulation uses the scoped physical Aedui cohort, named Leader identity stays native, human stances/host decisions and uncertain saves are detached, Defender Loss rolls use the published assumption, and ordinary safety/Frost checks filter candidate Regions. Shared A28 defaults remain mobile-only. Full project validation remains the parent agent's responsibility.


## Additional independent forecast finding

The initial17-case candidate pass preceded an additional18th regression. `prefire-caesar-witness.py` demonstrates that revalidating Ambush in the forecast observer *after* Slingers prefire loses the status already established *before* prefire by canonical execution. With Ambiorix +3 Hidden Warbands versus Caesar +3 Legions +2 Hidden Auxilia, Slingers removes one Warband. The real Battle remains an Ambush; Caesar's escape can permit a Counterattack touching Ambiorix. The initial forecast instead rechecked2 Hidden versus2, omitted Caesar's escape branch and incorrectly accepted this unsafe target. The failing candidate JSON and isolated regression log are preserved. Engine owner was notified for a bounded metadata/parity correction; no change to ordinary Battle timing is requested.

The root also identified a combined Ally casualty priority concern. Section8.4.1 requires ordinary Allies to be lost before City/Remi Allies across the entire combined force, not merely within each physical owner. The cohort owner was given the source confirmation and a Mandubii/Senones example.


## Final acceptance review

- **18 independent tests passed** on the final candidate (`independent-candidate-final.log`).
- Identical final file on verified parent4f33: **18 failed** (`independent-parent-final18.log`), classified as **eight existing-API behavioral regressions plus ten expected missing-new-API imports**.
- The new Caesar/prefire regression now passes. `prefire-caesar-candidate-after.json` includes both safe and unsafe escape outcomes and `plan: null`; the preceding before-fix artifacts remain retained. The observer now conveys canonical `is_ambush` instead of recomputing eligibility after prefire.
- Combined NPC Allied Tribe Losses use ordinary-then-City/Remi tiers across physical owners and preserve exact Tribe identity through removal. Human choices and A28's mobile-only defaults remain separate.
- Requested Loss totals, including the projected A20 path, record inflicted Losses even when too few counters remain to absorb them. The selector compares these full totals under8.5.1 rather than capped removals.

No remaining acceptance blocker found in this bounded independent review. No production files were edited by this reviewer. Full project validation and publication belong to the parent agent.
