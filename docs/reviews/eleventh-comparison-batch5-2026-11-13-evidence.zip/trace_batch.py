"""Find the first changed public Command in paired audited bot games."""

import argparse
from contextlib import redirect_stdout
from concurrent.futures import ProcessPoolExecutor
from copy import deepcopy
import hashlib
from io import StringIO
import json
from pathlib import Path
import sys


def trace(case):
    from fs_bot import rules_consts as rc
    from fs_bot.board.control import is_controlled_by
    from fs_bot.board.pieces import count_pieces, find_leader
    from fs_bot.bots import german_bot
    from fs_bot.cli.dispatcher import make_decision_func
    from fs_bot.engine import execute
    from fs_bot.engine.game_engine import get_sop_factions, play_card, start_game
    from fs_bot.map.map_data import get_adjacent_for_state
    from fs_bot.state.serialize import encode
    from fs_bot.state.setup import setup_scenario
    from fs_bot.tools.seat_session import fingerprint, board_copy

    edition, scenario, seed = case
    state = setup_scenario(scenario, seed=seed, card_edition=edition)
    state['non_player_factions'] = set(get_sop_factions(state))
    bot = make_decision_func({}, stdin=StringIO(), stdout=StringIO(), pause=False)
    dispatch = {'german_expand': [], 'belgic_march': []}
    actions, cards = [], []
    original_expand = german_bot.node_g_march_expand
    original_belgic = execute._execute_belgic_live_enlist
    original_execute = execute.execute_decision
    index = 0

    def expansion(board):
        origin = find_leader(board, rc.GERMANS)
        neighbors = get_adjacent_for_state(board, origin, rc.GERMANS) if origin else ()
        before_rng = fingerprint(board['rng'])
        action = original_expand(board)
        if action['command'] == rc.CMD_MARCH or (origin and neighbors and all(
                is_controlled_by(board, r, rc.GERMANS) for r in (origin, *neighbors))):
            dispatch['german_expand'].append({
                'card_index': index, 'card': board['current_card'], 'origin': origin,
                'german_control': [r for r in board['spaces'] if is_controlled_by(board, r, rc.GERMANS)],
                'neighboring_regions': list(neighbors),
                'warbands': {r: count_pieces(board, r, rc.GERMANS, rc.WARBAND) for r in board['spaces']
                             if count_pieces(board, r, rc.GERMANS, rc.WARBAND)},
                'resources': board['resources'][rc.GERMANS], 'action': deepcopy(action),
                'rng_before': before_rng, 'rng_after': fingerprint(board['rng']),
            })
        return action

    def enlist(board, faction, action, **kwargs):
        result = original_belgic(board, faction, action, **kwargs)
        if action.get('command') == rc.CMD_MARCH and (result.get('executed') or result.get('errors')):
            dispatch['belgic_march'].append({
                'card_index': index, 'card': board['current_card'],
                'leader': find_leader(board, rc.BELGAE), 'result': deepcopy(result),
            })
        return result

    def recorded(board, faction, decision):
        before = fingerprint(board_copy(board))
        result = original_execute(board, faction, decision)
        actions.append({
            'faction': faction, 'before': before, 'after': fingerprint(board_copy(board)),
            'decision': deepcopy(decision), 'result': deepcopy(result),
        })
        return result

    german_bot.node_g_march_expand = expansion
    execute._execute_belgic_live_enlist = enlist
    execute.execute_decision = recorded
    try:
        with redirect_stdout(StringIO()):
            start_game(state)
            while state['current_card'] is not None:
                index += 1
                before = fingerprint(board_copy(state))
                identity = state['current_card']
                result = play_card(state, bot, execute=True)
                cards.append({'card_index': index, 'card': identity, 'before': before,
                              'after': fingerprint(board_copy(state)), 'actions': actions})
                actions = []
                if result.get('game_over'):
                    break
    finally:
        german_bot.node_g_march_expand = original_expand
        execute._execute_belgic_live_enlist = original_belgic
        execute.execute_decision = original_execute
    final = hashlib.sha256(json.dumps(
        encode({k: v for k, v in state.items() if k != 'decision_agent'}),
        sort_keys=True).encode()).hexdigest()
    return {'edition': edition, 'scenario': scenario, 'seed': seed, 'cards': cards,
            'winner': result['winner'], 'final_state_sha256': final, **dispatch}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--cases', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--workers', type=int, default=3)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo.resolve()))
    cases = json.loads(args.cases.read_text())
    with ProcessPoolExecutor(max_workers=args.workers) as pool, args.out.open('w') as output:
        for row in pool.map(trace, cases):
            output.write(json.dumps(row, sort_keys=True) + '\n')


if __name__ == '__main__':
    main()
