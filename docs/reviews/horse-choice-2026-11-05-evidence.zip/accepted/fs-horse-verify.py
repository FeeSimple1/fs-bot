from pathlib import Path
import json
import re
import subprocess
import xml.etree.ElementTree as ET
from fs_bot import rules_consts as rc
from fs_bot.tools.validation_metadata import source_identity

parent='1322980ee13241feba3057cdb04a2cd8a00349a5'
source=source_identity()
assert source['source_sha256']=='693cfe397282ec48411d56011afbf5c600f836858376ddd08430e1eb2fc190a2'
assert len(list(Path('fs_bot').rglob('*.py')))==520
records={}
for label,directory in [('parent','/tmp/fs-horse-bots-parent'),('accepted','/tmp/fs-horse-bots-final')]:
    rows=[json.loads(line) for line in Path(directory+'/games.jsonl').read_text().splitlines()]
    records[label]={(row['scenario'],row['seed']):row for row in rows}
    assert len(rows)==10 and set(records[label])=={(s,n) for s in rc.ALL_SCENARIOS for n in (1,2)}
    for row in rows:
        assert all(row[key] for key in ('completed','game_completed','audit_completed','final_state_sha256'))
        assert not row['errors'] and not row['integrity_findings']
        assert len(row['final_ranking'])==4 and not row['winner_differs_from_highest_margin']
        assert not row['engine_ranking_output_missing']
        assert all(d['severity']=='legal-decline' for d in row['diagnostics'])
ignored={'seconds','commit','source_sha256'}
changed=[]
for key,old in records['parent'].items():
    new=records['accepted'][key]
    if {k:v for k,v in old.items() if k not in ignored}!={k:v for k,v in new.items() if k not in ignored}:
        changed.append(key)
assert changed==[(rc.SCENARIO_GREAT_REVOLT,2)]
traces={label:json.loads(Path('/tmp/fs-horse-trace-'+label+'.json').read_text()) for label in ('parent','final','counterfactual')}
def comparable(row):return {k:v for k,v in row.items() if k not in ignored}
assert comparable(traces['parent']['result'])==comparable(traces['counterfactual']['result'])
assert comparable(traces['parent']['result'])==comparable(records['parent'][changed[0]])
assert comparable(traces['final']['result'])==comparable(records['accepted'][changed[0]])
assert traces['counterfactual']['intervention']=='old Horse selection policy'
assert traces['final']['source']==source
first=next(i for i,(old,new) in enumerate(zip(traces['parent']['trace'],traces['final']['trace'])) if old!=new)
assert first==11
old,new=(traces[label]['trace'][first] for label in ('parent','final'))
assert old['before_position_without_horse_flags']==new['before_position_without_horse_flags']
assert old['card']==new['card']==20 and old['region']==new['region']==rc.PICTONES
assert old['horse']['card59_shaded_region']==rc.NERVII
assert new['horse']['card59_shaded_region']==rc.PICTONES
assert old['result']['attack']['losses_requested']==2 and new['result']['attack']['losses_requested']==4
assert records['accepted'][rc.SCENARIO_GALLIC_WAR,1]['interlude_completed']
assert json.loads(Path('/tmp/fs-horse-bots-parent/metadata.json').read_text())['source_sha256']=='c3d6381742446be9489e203652053fe1596fdb0f5eac7a4f1c33c1afce87e205'
assert json.loads(Path('/tmp/fs-horse-bots-final/metadata.json').read_text())['source_sha256']==source['source_sha256']
mixed=json.loads(Path('/tmp/fs-horse-mixed0.json').read_text())
assert mixed==json.loads(Path('/tmp/fs-horse-mixed987.json').read_text())
assert not mixed['hard_findings'] and mixed['partial']==0 and all(r['game_completed'] for r in mixed['records'])
assert mixed['metadata']['source_sha256']==source['source_sha256']
protected=[p for p in Path('Reference Documents').rglob('*') if p.is_file()]+[Path('fs_bot/rules_consts.py'),Path('fs_bot/tools/balance_baseline.json')]
assert len(protected)==49
for path in protected:
    assert path.read_bytes()==subprocess.check_output(['git','show',parent+':'+str(path)])
proof=ET.parse('/tmp/fs-horse-proof-parent.xml').getroot().find('testsuite')
assert proof.attrib['tests']=='9' and proof.attrib['failures']=='7' and proof.attrib['errors']=='0'
assert all(('assert' in t.find('failure').attrib['message'].lower() or
            'did not raise' in t.find('failure').attrib['message'].lower())
           for t in proof if t.find('failure') is not None)
accepted_proof=ET.parse('/tmp/fs-horse-proof-final.xml').getroot().find('testsuite')
assert accepted_proof.attrib['tests']=='9' and accepted_proof.attrib['failures']=='0' and accepted_proof.attrib['errors']=='0'
assert re.search(r'\n364 passed in ',Path('/tmp/fs-horse-targeted.log').read_text())
log=Path('/tmp/fs-horse-balance.log').read_text()
rows=re.findall(r'^\[(.*?) seed=\s*(\d+)\] winner=(.*?) \((\d+) cards\)$',log,re.M)
assert len(rows)==100 and {(s,int(n)) for s,n,_,_ in rows}=={(s,n) for s in rc.ALL_SCENARIOS for n in range(1,21)}
deltas=[abs(int(v)) for v in re.findall(r'\(([+-]\d+)%\)',log)]
assert deltas and max(deltas)<=15 and 'OK: balance within band' in log
changes=int(re.search(r'OK: balance within band \((\d+) winner changes\)',log)[1])
result={'date':'2026-11-05','timezone':'America/Chicago','source':source,'python_files':520,
        'protected_files':49,'protected_files_unchanged':True,'new_tests':64,'targeted_passed':364,
        'parent_proof':{'behavioral_failures':7,'controls_passed':2,'accepted_passed':9},
        'bots':{'games':10,'all_completed_and_audited':True,'gameplay_and_final_hashes_equal':False,'identical_games':9,'changed_games':1,'changed_game':{'scenario':rc.SCENARIO_GREAT_REVOLT,'seed':2,'first_battle_difference':first,'card':20,'region':rc.PICTONES,'old_selected_region':rc.NERVII,'selected_region':rc.PICTONES,'old_attack_losses':2,'attack_losses':4,'old_policy_reproduces_parent':True},
                'interlude_exercised':{'scenario':rc.SCENARIO_GALLIC_WAR,'seed':1},'excluded':sorted(ignored)},
        'mixed':mixed,'mixed_complete_json_equal':True,'hash_seeds':[0,987],'mixed_executions_including_replay':40,
        'balance':{'games':100,'band_percentage_points':15,'maximum_absolute_delta_percentage_points':max(deltas),
                   'historical_baseline_winner_changes':changes,'baseline_unchanged':True,'passed':True},
        'progress':{'closed':39,'total':50,'percent':78,'open':11},
        'remaining':'BE-09 remains open for the prospective queue Card 13/59 choices. Original bundle remains 39/50 closed. Separate mechanics leads and source questions retain their dispositions.'}
Path('/tmp/fs-horse-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':source,'bots_equal':9,'changed_game_explained':True,'mixed_equal':True,'hard_findings':0,'partials':0,
                  'new_cases':64,'targeted':364,'balance_max_delta_pp':max(deltas)}))
