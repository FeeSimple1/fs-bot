# EXP-07 / EXP-10 validation evidence

The report and machine-readable results beside this archive identify the
accepted source revision and results. This archive retains raw measurements,
commands, implementation/review handoffs and reproducible witnesses.

- `integration-results.json`, `integration-commands.json` and
  `integration_checks.py`: accepted frozen-source matrix and its assertions.
- `bots-*`: 150 fresh audited games, exact edition/seed metadata and raw rows.
- `parent-bots-legacy`: 100 **reused** parent records from the preceding
  Event-grant report. `task-baseline.json` proves the published immediate
  parent has identical Python bytes; these are not fresh runs in this task.
- `parent-differences.json` versus `baseline-differences.json`: distinguish
  the additional outcome change from the earlier changes already in main.
- `fuzz-*` and `census-*`: mixed-seat replay/hash repeats and strict census.
- `causal-review/`: bounded paired trace investigation of the one additional
  parent outcome difference, with exact revisions and raw traces.
- `gallia-full-01.log`, `dread-full-final-02.txt`, `integrated-full-01.log`
  and `final-docs.log`/`final-docs.xml`: accepted suites at their named stages.
  Standalone branch test counts differ from the final combined source.
- Earlier `gallia-targeted-01.log`, `dread-new-tests-first.txt`,
  `dread-new-tests-second.txt`, and `dread-full-final.txt` retain fixture or
  compatibility failures. These are not accepted final-source passes.
- `dread-witness.py` and its before/after outputs preserve three original
  failures. The disposable parent extraction is omitted; recreate `fs_bot/`
  at the recorded task-base commit to rerun the script.
- Source handoffs preserve review corrections and the separately unverified
  NPC pre-Battle lead. No new provisional ruling was adopted.
- `protected-before.json` / `protected-after.json`: all 49 protected inputs
  are unchanged. `source-manifest.json` records final Python file hashes.
- `evidence-index.json` records every packaged entry's bytes and SHA-256;
  the archive was reopened and checked against this manifest and ZIP CRCs.

Focused tests overlap full-suite coverage. Replay/hash repeats are executions,
not additional independent game positions. These bounded checks do not prove
exhaustive correctness or statistically conclusive balance.
