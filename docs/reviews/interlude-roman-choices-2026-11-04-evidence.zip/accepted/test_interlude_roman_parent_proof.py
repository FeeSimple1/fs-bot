from copy import deepcopy
import pytest
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces, count_pieces_by_state
from fs_bot.engine.interlude import _step3_britannia, _step5_spring, run_interlude
from fs_bot.state.state_schema import build_initial_state
from fs_bot.state.setup import setup_scenario
from fs_bot.state.serialize import encode


def position():
    state = build_initial_state(rc.SCENARIO_GALLIC_WAR, seed=41)
    state['non_player_factions'] = {rc.AEDUI, rc.BELGAE, rc.GERMANS}
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.LEADER, leader_name=rc.CAESAR)
    for region in (rc.PROVINCIA, rc.MORINI):
        place_piece(state, region, rc.ROMANS, rc.LEGION, 4, from_legions_track=True)
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.AUXILIA, 2)
    place_piece(state, rc.MORINI, rc.ROMANS, rc.AUXILIA, 3, piece_state=rc.REVEALED)
    return state


def test_explicit_expedition_quantities_and_regions():
    state = position()
    plan = {'conduct': True, 'harvest': {rc.PROVINCIA: 2, rc.MORINI: 1},
            'legions': {rc.PROVINCIA: 1, rc.MORINI: 3},
            'auxilia': [{'region': rc.MORINI, 'piece_state': rc.REVEALED, 'count': 2}]}
    result = _step3_britannia(state, plan)
    assert result['legions_to_britannia'] == 4
    assert result['auxilia_to_britannia'] == 2
    assert count_pieces(state, rc.PROVINCIA, rc.ROMANS, rc.LEGION) == 1
    assert count_pieces_by_state(state, rc.BRITANNIA, rc.ROMANS, rc.AUXILIA, rc.REVEALED) == 2


def test_human_is_asked_before_automatic_expedition():
    state = position()
    calls = []
    state['decision_agent'] = lambda board, faction, request: calls.append(faction) or {'conduct': False}
    result = _step3_britannia(state, None)
    assert calls == [rc.ROMANS]
    assert not result['conducted']


def test_human_preserves_marker_through_spring():
    state = position()
    state['tribes'][rc.TRIBE_VENETI]['status'] = rc.MARKER_DISPERSED
    state['decision_agent'] = lambda board, faction, request: (
        {'tribe': rc.TRIBE_VENETI} if request['kind'] == 'interlude_marker' else None)
    result = _step5_spring(state)
    assert state['tribes'][rc.TRIBE_VENETI]['status'] == rc.MARKER_DISPERSED
    assert result['roman_dispersed_kept'] == rc.TRIBE_VENETI


def test_invalid_keep_rejects_entire_interlude_without_changes():
    state = setup_scenario(rc.SCENARIO_GALLIC_WAR, seed=41)
    before = encode(state)
    with pytest.raises(ValueError):
        run_interlude(state, britannia_decision=True, roman_dispersed_keep=rc.TRIBE_NORI)
    assert encode(state) == before


def test_explicit_bool_default_control():
    state = position()
    result = _step3_britannia(state, True)
    assert result['conducted'] and result['legions_to_harvest_box'] == 3
    assert result['legions_to_britannia'] == 3 and result['auxilia_to_britannia'] == 1


def test_explicit_decline_control():
    state = position()
    result = _step3_britannia(state, False)
    assert not result['conducted'] and result['senate_shift'] == 'up'
    assert count_pieces(state, rc.BRITANNIA, rc.BELGAE, rc.ALLY) == 1
    assert count_pieces(state, rc.BRITANNIA, rc.BELGAE, rc.WARBAND) == 2
