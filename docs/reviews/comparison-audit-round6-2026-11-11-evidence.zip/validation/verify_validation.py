"""Verify every record in the sixth audit's unchanged-source validation."""
import json, pathlib, sys, xml.etree.ElementTree as ET
from fs_bot.tools.validation_metadata import source_identity
from fs_bot.tools.run_batch import SCENARIOS
p=pathlib.Path(__file__).resolve().parent
ident=source_identity()
assert ident['commit']=='86fb0c2d8ddf86a4548a863dc9c9da27d0c708ad'
assert ident['source_sha256']=='2423cb1f410650da300914e6569c1637675894cc43a9bd8284dfd92bd3b3ecb7'
expected={(s,n,'second-edition') for s in SCENARIOS for n in range(41,45)}
rows=[json.loads(x) for x in (p/'bots-second/games.jsonl').read_text().splitlines()]
assert len(rows)==20
assert {(r['scenario'],r['seed'],r['card_edition']) for r in rows}==expected
for r in rows:
 assert all(r[k] for k in ['completed','game_completed','audit_completed','final_state_sha256']),r
 assert not any(r[k] for k in ['errors','integrity_findings','engine_ranking_output_missing','winner_differs_from_highest_margin']),r
 assert len(r['final_ranking'])==4 and len(r['engine_final_ranking'])==4,r
 assert all(d['severity']=='legal-decline' for d in r['diagnostics']),r
 assert r['source_sha256']==ident['source_sha256'] and r['commit']==ident['commit']
a=json.loads((p/'fuzz0.json').read_text());b=json.loads((p/'fuzz987.json').read_text())
assert (p/'fuzz0.json').read_bytes()==(p/'fuzz987.json').read_bytes()
assert (p/'fuzz0.log').read_bytes()==(p/'fuzz987.log').read_bytes()
assert len(a['records'])==20 and a['games']==20 and a['hard_findings']==0
assert {(r['scenario'],r['seed'],r['card_edition']) for r in a['records']}==expected
assert all(r['game_completed'] and not r['findings'] for r in a['records'])
t=ET.parse(p/'pytest.xml').getroot(); suites=list(t.iter('testsuite'))
assert sum(int(s.attrib.get('tests',0)) for s in suites)==9900
assert not any(int(s.attrib.get(k,0)) for s in suites for k in ['errors','failures','skipped'])
summary={'source':ident,'pytest':{'passed':9900,'seconds':sum(float(s.attrib['time']) for s in suites)},'bots':{'games':20,'complete':20,'interludes':sum(r['interlude_completed'] for r in rows),'seeds':[41,42,43,44],'edition':'second-edition','scenarios':list(SCENARIOS)},'mixed':{k:a[k] for k in ['games','human_turns','event_turns','events_ok','partial','hard_findings','batch_digest']},'hash_seeds':[0,987],'mixed_exact_bytes_match':True,'baseline_changed':False,'balance_matrix_run':False}
(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
