"""Replay fixed-seed games and locate their first differing Germans Phase call."""
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import sys
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import get_available
from fs_bot.cli.dispatcher import make_decision_func
from fs_bot.commands import march, rally
from fs_bot.engine import winter
from fs_bot.engine.game_engine import get_sop_factions, play_card, start_game
from fs_bot.state.serialize import decode, encode
from fs_bot.state.setup import setup_scenario
from fs_bot.tools.validation_metadata import source_identity


def digest(value):
    return sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def board_digest(state):
    return digest({key: value for key, value in state.items() if key != 'decision_agent'})


def german_material(state):
    return {
        'available_allies': get_available(state, rc.GERMANS, rc.ALLY),
        'available_warbands': get_available(state, rc.GERMANS, rc.WARBAND),
        'allied_tribes': sorted(tribe for tribe, info in state['tribes'].items()
                                if info['allied_faction'] == rc.GERMANS),
        'regions': {region: encode(space['pieces'][rc.GERMANS])
                    for region, space in state['spaces'].items()
                    if space['pieces'].get(rc.GERMANS)},
    }


def game_key(row):
    return tuple(row[key] for key in ('scenario', 'seed', 'card_edition'))


def trace(row):
    scenario, seed, edition = game_key(row)
    state = setup_scenario(scenario, seed=seed, card_edition=edition)
    state['non_player_factions'] = set(get_sop_factions(state))
    bot = make_decision_func({}, stdin=StringIO(), stdout=StringIO(), pause=False)
    cards, calls = [], []

    def instrument(command, execute):
        def tracked(board):
            before = board_digest(board)
            rng = digest(board['rng'].getstate())
            material = german_material(board)
            result = execute(board)
            calls.append(dict(command=command, before=before, after=board_digest(board),
                              rng_before=rng, rng_after=digest(board['rng'].getstate()),
                              result=encode(result), material_before=material,
                              material_after=german_material(board)))
            return result
        return tracked

    tracked_rally = instrument('Rally', rally.germans_phase_rally)
    tracked_march = instrument('March', march.germans_phase_march)
    with (patch.object(rally, 'germans_phase_rally', tracked_rally),
          patch.object(march, 'germans_phase_march', tracked_march),
          patch.object(winter, 'germans_phase_rally', tracked_rally),
          patch.object(winter, 'germans_phase_march', tracked_march),
          redirect_stdout(StringIO())):
        start_game(state)
        for draw in range(1, 201):
            calls.clear()
            before = board_digest(state)
            result = play_card(state, bot, execute=True)
            after = board_digest(state)
            cards.append(dict(draw=draw, card=result['card'], before=before, after=after,
                              calls=list(calls)))
            if result['game_over']:
                break
    assert (result['winner'], draw, after) == (row['winner'], row['cards'], row['final_state_sha256'])
    return dict(scenario=scenario, seed=seed, card_edition=edition, winner=result['winner'],
                final_board=after, cards=cards)


def record_traces(rows_path, output):
    source = source_identity()
    rows = json.loads(Path(rows_path).read_text())
    assert rows and all(row['source_sha256'] == source['source_sha256'] for row in rows)
    with ProcessPoolExecutor(max_workers=2) as pool:
        games = list(pool.map(trace, rows))
    Path(output).write_text(json.dumps(dict(source=source, games=games), indent=2) + '\n')
    print(f'{len(games)} traces match audited winners, game lengths and final boards')


def first_divergence(older, newer):
    assert game_key(older) == game_key(newer) and older['final_board'] != newer['final_board']
    for previous, current in zip(older['cards'], newer['cards']):
        assert (previous['draw'], previous['card'], previous['before']) == (
            current['draw'], current['card'], current['before'])
        if previous['after'] != current['after']:
            break
    else:
        raise AssertionError(game_key(older))

    for old_call, new_call in zip(previous['calls'], current['calls']):
        assert (old_call['command'], old_call['before'], old_call['rng_before']) == (
            new_call['command'], new_call['before'], new_call['rng_before'])
        assert old_call['material_before'] == new_call['material_before']
        if old_call['after'] != new_call['after']:
            break
    else:
        raise AssertionError((game_key(older), current['draw']))

    old_result, new_result = (decode(call['result']) for call in (old_call, new_call))
    if new_call['command'] == 'Rally':
        old_regions = [region for region, _ in old_result['allies_placed']]
        new_regions = [region for region, _ in new_result['allies_placed']]
        assert len(new_regions) == len(set(new_regions))
        reason = ('Rally placed multiple Allies in a Region' if len(old_regions) != len(set(old_regions))
                  else 'Rally changed eligible Tribe choices or seeded ties')
    elif old_result['groups_moved'] != new_result['groups_moved']:
        old_sizes = {origin: size for origin, _, size in old_result['groups_moved']}
        new_sizes = {origin: size for origin, _, size in new_result['groups_moved']}
        assert any(old_sizes[origin] > new_sizes[origin] for origin in old_sizes.keys() & new_sizes.keys())
        reason = 'March used the original groups'
    else:
        old_regions, new_regions = (call['material_after']['regions'] for call in (old_call, new_call))
        assert any(
            pieces.get(rc.REVEALED, {}).get(rc.WARBAND, 0)
            > old_regions.get(region, {}).get(rc.REVEALED, {}).get(rc.WARBAND, 0)
            for region, pieces in new_regions.items()
        )
        reason = 'March kept formerly Scouted Warbands Revealed'
    return dict(scenario=older['scenario'], seed=older['seed'], card_edition=older['card_edition'],
                previous_winner=older['winner'], current_winner=newer['winner'],
                card=current['card'], draw=current['draw'], reason=reason,
                previous=old_call, current=new_call)


def compare_traces(parent_path, repaired_path, output):
    parent = json.loads(Path(parent_path).read_text())
    repaired = json.loads(Path(repaired_path).read_text())
    changes = [first_divergence(older, newer)
               for older, newer in zip(parent['games'], repaired['games'], strict=True)]
    result = dict(
        parent=parent['source'], repaired=repaired['source'], games=len(changes),
        changed_winners=sum(row['previous_winner'] != row['current_winner'] for row in changes),
        first_change_counts=dict(Counter(row['reason'] for row in changes)),
        first_card_counts=dict(Counter(str(row['card']) for row in changes)),
        changes=changes,
    )
    Path(output).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'changes'}, indent=2))


if __name__ == '__main__':
    mode, *paths = sys.argv[1:]
    {'record': record_traces, 'compare': compare_traces}[mode](*paths)
