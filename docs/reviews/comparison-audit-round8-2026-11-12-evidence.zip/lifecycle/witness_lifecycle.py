#!/usr/bin/env python3
"""Read-only eighth audit witnesses; only writes JSON/save evidence beside itself.

Run from fs-bot: .venv/bin/python ../audit8-work/lifecycle/witness_lifecycle.py
Controlled phase fixtures, not claimed full-game play traces. Piece changes use
canonical ally helpers; card history uses production draw_card. Explicit clock
assignment supplies the number of earlier Winters resolved outside this fixture.
"""
import copy
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent / 'fs-bot'
sys.path.insert(0, str(ROOT))
from fs_bot.rules_consts import *
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import validate_state, check_structural_integrity
from fs_bot.state.serialize import save_game, load_game, encode
from fs_bot.state.player_ownership import install
from fs_bot.cards.card_effects import _ally_tribe, _unally_tribe
from fs_bot.engine.game_engine import draw_card, play_card, resolve_winter_card, ACTION_PASS
from fs_bot.engine.winter import run_winter_round
from fs_bot.engine.victory import check_any_victory, calculate_victory_score


def clean(state):
    record = {'validate_state': validate_state(state),
              'check_structural_integrity': check_structural_integrity(state)}
    assert not any(record.values()), record
    return record


def cursor_at_winter(state, ordinal):
    # A legal shuffled setup/rebuilt deck is consumed in its production order.
    while sum(card == WINTER_CARD for card in state['played_cards']) < ordinal:
        draw_card(state)
    assert state['current_card'] == WINTER_CARD


def scores(state):
    return {f: calculate_victory_score(state, f)
            for f in (ROMANS, ARVERNI, AEDUI, BELGAE)}


def pass_decision(state, faction, options, position):
    return {'action': ACTION_PASS}


def probe_winter(state, label):
    pre = clean(state)
    before = {'winter_count': state['winter_count'],
              'played_winters': state['played_cards'].count(WINTER_CARD),
              'remaining_winters': state['deck'].count(WINTER_CARD),
              'ordinary_victor': check_any_victory(state),
              'scores': scores(state)}
    outcome = play_card(state, pass_decision, execute=True)
    wr = outcome['winter_result']
    return {'label': label, 'pre_integrity': pre, 'before': before,
            'is_final': wr['is_final'], 'game_over': outcome['game_over'],
            'winner': outcome.get('winner'),
            'remaining_winters_after': state['deck'].count(WINTER_CARD),
            'phases': list(wr['winter_result']['phases']),
            'victory_result': wr['winter_result']['phases']['victory'],
            'post_integrity': clean(state)}


def interlude_board():
    state = setup_scenario(SCENARIO_GALLIC_WAR, seed=21,
                           faction_owners={f: f for f in (ROMANS, GERMANS, AEDUI, BELGAE)})
    clean(state)
    cursor_at_winter(state, 3)
    state['winter_count'] = 2
    assert check_any_victory(state) is None
    result = run_winter_round(state, britannia_decision=False)
    assert 'interlude' in result and state['winter_count'] == 3
    assert state['deck'].count(WINTER_CARD) == 5
    clean(state)
    # Later-play board fixture: eight additional, unrestricted Allied Tribes
    # lower Roman score from 23 to 15 without creating another threshold winner.
    additions = [(TRIBE_BITURIGES, ARVERNI), (TRIBE_NAMNETES, ARVERNI),
                 (TRIBE_VENETI, ARVERNI), (TRIBE_SENONES, ARVERNI),
                 (TRIBE_CARNUTES, ARVERNI), (TRIBE_PICTONES, ARVERNI),
                 (TRIBE_SUEBI_SOUTH, GERMANS), (TRIBE_NERVII, GERMANS)]
    for tribe, faction in additions:
        assert not state['tribes'][tribe]['allied_faction']
        assert _ally_tribe(state, tribe, faction)
    assert check_any_victory(state) is None
    clean(state)
    # These one-shot flags were consumed in the first post-Interlude Winter.
    state.pop('first_winter_special', None)
    state['first_senate_after_interlude_pending'] = False
    state['first_harvest_after_interlude_pending'] = False
    return state


def final_winter_cases():
    base = interlude_board()
    cases = []
    for ordinal in (3, 4, 5):
        state = copy.deepcopy(base)
        cursor_at_winter(state, ordinal)
        state['winter_count'] = 3 + ordinal - 1
        if ordinal == 4:
            save_game(state, HERE / 'LC8-01-penultimate-before.json')
            replay, _, _ = load_game(HERE / 'LC8-01-penultimate-before.json', validate=True)
            row = probe_winter(state, 'Interlude second-half Winter 4 of 5')
            replay_row = probe_winter(replay, 'validated save/load repeat')
            assert {k: v for k, v in row.items() if k != 'label'} == {
                k: v for k, v in replay_row.items() if k != 'label'}
            assert row['is_final'] is True and row['game_over'] is True
            assert row['before']['ordinary_victor'] is None
            assert row['remaining_winters_after'] == 1
            row['save_load_repeat'] = replay_row
        else:
            row = probe_winter(state, f'Interlude second-half Winter {ordinal} of 5 control')
            assert row['is_final'] == (ordinal == 5)
        cases.append(row)
    # Same rebuilt-deck ordinal in an ordinary Pax game, without cumulative
    # first-half Winters, correctly recognizes that one Winter still remains.
    state = setup_scenario(SCENARIO_PAX_GALLICA, seed=21,
                           faction_owners={f:f for f in (ROMANS, ARVERNI, AEDUI, BELGAE)})
    for tribe in (TRIBE_BITURIGES, TRIBE_NAMNETES, TRIBE_AULERCI,
                  TRIBE_MANDUBII, TRIBE_CARNUTES):
        if not state['tribes'][tribe]['allied_faction']:
            assert _ally_tribe(state, tribe, ARVERNI)
    assert check_any_victory(state) is None
    state.pop('first_winter_special', None)
    cursor_at_winter(state, 4)
    state['winter_count'] = 3
    row = probe_winter(state, 'Ordinary Pax Winter 4 of 5 control')
    assert row['is_final'] is False and row['game_over'] is False
    cases.append(row)
    return cases


def roman_threshold_board():
    state = setup_scenario(SCENARIO_RECONQUEST, seed=21,
                           faction_owners={ROMANS: 'Human'})
    clean(state)
    # Canonical removal to Available of two existing Belgic Ally discs.
    tribes = [t for t, info in state['tribes'].items()
              if info.get('allied_faction') == BELGAE][:2]
    assert len(tribes) == 2
    for tribe in tribes:
        _unally_tribe(state, tribe)
    assert calculate_victory_score(state, ROMANS) == 16
    assert check_any_victory(state) == ROMANS
    clean(state)
    return state


def solo_victory_cases():
    base = roman_threshold_board()
    cases = []
    layouts = [
        ('One human Roman, non-final Winter', {ROMANS: 'Human'}, 1),
        ('Two humans, Roman threshold control', {ROMANS: 'Human', ARVERNI: 'Other'}, 1),
        ('All bots, Roman threshold control', {}, 1),
        ('One human Arverni, Roman bot threshold control', {ARVERNI: 'Human'}, 1),
        ('One human Roman, final Winter control', {ROMANS: 'Human'}, 4),
    ]
    for label, owners, ordinal in layouts:
        state = copy.deepcopy(base)
        install(state, owners)
        cursor_at_winter(state, ordinal)
        state['winter_count'] = ordinal - 1
        if label.startswith('One human Roman, non-final'):
            save_game(state, HERE / 'LC8-02-solo-before.json')
            replay, _, _ = load_game(HERE / 'LC8-02-solo-before.json', validate=True)
            row = probe_winter(state, label)
            replay_row = probe_winter(replay, 'validated save/load repeat')
            assert {k: v for k, v in row.items() if k != 'label'} == {
                k: v for k, v in replay_row.items() if k != 'label'}
            row['save_load_repeat'] = replay_row
        else:
            row = probe_winter(state, label)
        row['human_owners'] = owners
        assert row['game_over'] is True and row['winner'] == ROMANS
        assert row['is_final'] == (ordinal == 4)
        cases.append(row)
    return cases


if __name__ == '__main__':
    result = {'audited_commit': 'e62b0360c1b91032741ef8f6afa4d247c8ea2437',
              'LC8-01': final_winter_cases(), 'LC8-02': solo_victory_cases()}
    (HERE / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
