"""Run the observed-defect witnesses against an fs-bot checkout.

Usage: python run_probes.py /path/to/fs-bot /path/to/output
Exit zero means every witness reproduced its recorded observation.
"""
import json
import os
from pathlib import Path
import subprocess
import sys

scripts = [
    'battle/probe_ambush.py',
    'events/probe_events.py',
    'expansion/probe.py',
    'expansion/coverage_probe.py',
    'movement/probes.py',
    'frontends/probe_action_envelope.py',
    'frontends/probe_durable_action_kind.py',
    'frontends/probe_durable_card_identity.py',
    'patterns/probe_shadow_parts.py',
]
repo = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
assert (repo / 'fs_bot').is_dir(), 'Pass the root of an fs-bot checkout'
output.mkdir(parents=True, exist_ok=False)
env = dict(os.environ, PYTHONPATH=str(repo), PYTHONHASHSEED='0')
results = []
for name in scripts:
    script = Path(__file__).resolve().parent / name
    result = subprocess.run([sys.executable, str(script)], cwd=repo, env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    log = name.replace('/', '_').removesuffix('.py') + '.log'
    (output / log).write_text(result.stdout)
    results.append({'script': name, 'exit_code': result.returncode, 'log': log})
(output / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
raise SystemExit(any(row['exit_code'] for row in results))
