"""Read-only paired exact play_one traces; never changes source or baselines."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
WORKSPACE=Path('/workspace/scratch/534c265c65f4')
PYTHON=WORKSPACE/'fs-test-venv/bin/python'
PARENT=WORKSPACE/'fs-action-timing-parent'
CANDIDATE=HERE.parent/'python-source'
PARENT_RUN=WORKSPACE/'rulings-trade-validation-2026-10-29/attempt3/bots-legacy'
CANDIDATE_RUN=HERE.parent/'diagnostic-bots'

def read_json(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    with path.open('x') as stream: json.dump(value,stream,indent=2,sort_keys=True)
def records(path): return {(r['scenario'],r['seed']):r for r in map(json.loads,path.read_text().splitlines())}
def slug(key): return key[0].lower().replace('?','').replace(' ','-')+f'-{key[1]:02}'

def run(argv,cwd,out):
    start=time.monotonic()
    with (out.with_suffix('.log')).open('x') as log:
        proc=subprocess.run(argv,cwd=cwd,env=dict(os.environ,PYTHONHASHSEED='0',PYTHONUNBUFFERED='1',PYTHONNOUSERSITE='1'),stdout=log,stderr=subprocess.STDOUT)
    status={'argv':list(map(str,argv)),'cwd':str(cwd),'PYTHONHASHSEED':'0','exit_code':proc.returncode,'seconds':time.monotonic()-start}
    write(out.with_suffix('.status.json'),status)
    return status

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--max-seed',type=int,required=True); ap.add_argument('--workers',type=int,default=4); ap.add_argument('--label'); args=ap.parse_args()
    parent_meta=read_json(PARENT_RUN/'metadata.json'); candidate_meta=read_json(CANDIDATE_RUN/'metadata.json')
    old=records(PARENT_RUN/'games.jsonl'); new=records(CANDIDATE_RUN/'games.jsonl')
    expected={ (s,seed) for s in ('Pax Gallica?','Reconquest of Gaul','The Great Revolt','Ariovistus','The Gallic War') for seed in range(1,args.max_seed+1)}
    assert expected <= old.keys() and expected <= new.keys()
    assert parent_meta['source_sha256']=='e19896b1e07bbf425ca5e1f7d1db5113e4db6843c3302bc0ef1eb1bd32304bd0'
    assert candidate_meta['source_sha256']=='c24adb23c9018071ed948e295a96fc4b17649e35fecabd985e77dedbfa32fcc5'
    runlabel=args.label or f'seeds-1-{args.max_seed}'
    manifest={'started':datetime.now(timezone.utc).isoformat(),'scope':sorted(expected),'parent':parent_meta,'candidate':candidate_meta,
              'parent_records_sha256':sha(PARENT_RUN/'games.jsonl'),'candidate_records_sha256':sha(CANDIDATE_RUN/'games.jsonl'),
              'scripts':{p.name:sha(p) for p in (HERE/'compact_trace.py',HERE/'compare_traces.py',Path(__file__))},
              'note':'Paired first-divergence localization only. No baseline authorization or winner causality claim.'}
    write(HERE/f'{runlabel}.manifest.json',manifest)
    jobs=[]
    for key in sorted(expected):
        folder=HERE/slug(key); folder.mkdir(exist_ok=True)
        for side,cwd,meta,record in [('parent',PARENT,parent_meta,old[key]),('candidate',CANDIDATE,candidate_meta,new[key])]:
            out=folder/f'{side}.json.gz'
            if out.exists():
                with gzip.open(out,'rt') as f: captured=json.load(f)
                assert captured['passed'] and captured['source']['source_sha256']==meta['source_sha256'] and captured['record']['final_state_sha256']==record['final_state_sha256']
                continue
            argv=[str(PYTHON),str(HERE/'compact_trace.py'),'--scenario',key[0],'--seed',str(key[1]),'--source-sha256',meta['source_sha256'],'--expected-final-sha256',record['final_state_sha256'],'--out',str(out)]
            jobs.append((key,side,argv,cwd,folder/side))
    failed=[]
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures={pool.submit(run,argv,cwd,out):(key,side) for key,side,argv,cwd,out in jobs}
        for future in as_completed(futures):
            key,side=futures[future]; status=future.result()
            print(json.dumps({'case':key,'side':side,'exit_code':status['exit_code'],'seconds':round(status['seconds'],3)}),flush=True)
            if status['exit_code']: failed.append((key,side))
    if failed:
        write(HERE/f'{runlabel}.failed.json',failed);return 1
    summaries=[]
    for key in sorted(expected):
        folder=HERE/slug(key); out=folder/'comparison.json'
        if not out.exists():
            argv=[str(PYTHON),str(HERE/'compare_traces.py'),'--baseline',str(folder/'parent.json.gz'),'--current',str(folder/'candidate.json.gz'),
                  '--baseline-source-sha256',parent_meta['source_sha256'],'--baseline-final-sha256',old[key]['final_state_sha256'],
                  '--current-source-sha256',candidate_meta['source_sha256'],'--current-final-sha256',new[key]['final_state_sha256'],'--out',str(out)]
            result=run(argv,CANDIDATE,folder/'compare')
            if result['exit_code']: return result['exit_code']
        comparison=read_json(out); first=comparison.get('first_state_or_decision_difference') or {}
        summaries.append({'scenario':key[0],'seed':key[1],'parent_winner':old[key]['winner'],'candidate_winner':new[key]['winner'],
           'parent_cards':old[key]['cards'],'candidate_cards':new[key]['cards'],'parent_completed':old[key]['completed'],'candidate_completed':new[key]['completed'],
           'first_boundary':first.get('current_boundary'),'changed_domains':first.get('changed_state_domains'),'rng_changed':first.get('rng_changed'),
           'payload_differs':first.get('payload_differs'),'same_boundary':first.get('same_boundary'),'comparison':str(out)})
    write(HERE/f'{runlabel}.localizations.json',summaries)
    print(json.dumps({'completed_pairs':len(summaries),'localizations':str(HERE/f'{runlabel}.localizations.json')}),flush=True)
    return 0

if __name__=='__main__': raise SystemExit(main())
