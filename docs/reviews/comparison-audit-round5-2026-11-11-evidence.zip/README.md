# Fifth Falling Sky audit evidence

Audited engine commit `bd30d522e8baa2d303b9e372d7d9c550351e91a5`.
Python-source SHA-256
`31e50801e3a187cf7c9def52e09df7ef5b39a895f55d32a4abfe0a08a42d2341`.
Comparator `FeeSimple1/lod-bot` at
`2991ea279062773548ec390a1da75f3e85381702` supplied implementation clues.
Falling Sky's supplied references govern all conclusions.

The report and ledger identify 11 open repair groups, 7 high and 4 medium.
No engine repairs are included. Optimates phase counting is an unconfirmed
source question and is outside that count.

## Reproduce targeted observations

Use Python 3.10 or later and a checkout of the audited source. The recorded
runs use Python 3.12.14. No third-party dependencies are needed for probes.
The output directory must not already exist.

```sh
python run_probes.py /path/to/fs-bot /path/to/new-results
```

The runner checks the Python source digest, runs five scripts, and compares
their parsed JSON with the original output. Documentation-only commits with
the same Python sources are accepted. Each script deliberately asserts the
current defective outcome plus controls. During repairs, replace the defect
assertions with source-correct regression expectations. Do not invert the
Optimates observation without resolving its source question.

## Contents

- `bots`, `battle`, `events`, `frontend`, `lifecycle` contain final accepted
  probes, captured JSON, source/code references and bounded coverage notes.
- `review` contains independent verification and final reruns, including
  script/output hashes. `root-rerun` contains the root's separate matched run.
- `validation` contains the full-suite log, all 20 bot records and both
  20-case mixed-seat hash/replay runs. `summary.json` records their inspected
  results. The original 9,806 tests all passed.
- `root-coverage.md` records search scope and limitations.
- `SHA256SUMS.json` hashes all other package files.

The ordinary game samples use second-edition cards and seeds 29–32 in all
five scenarios. All bot records pass their audit. Both mixed JSON and text
outputs match exactly across hash seeds 0 and 987, with zero hard findings
and two soft partial plans in each run. The two hash runs plus their internal
replays represent 80 executions of 20 distinct cases.

Reproduce general checks from the engine checkout with pytest and optional
pytest-xdist installed for the parallel suite command:

```sh
python -m pytest -q -n 4
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 29-32 --card-edition second-edition --workers 2 --out /path/to/new-bots
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 29-32 --card-edition second-edition --out /path/to/new-fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 29-32 --card-edition second-edition --out /path/to/new-fuzz987.json
```

Full-suite success and clean sampled games do not establish correctness for
every targeted boundary. Controlled fixtures, public integration paths,
scenario legality checks and limits are disclosed in the per-finding records.
Production code, tests, references and balance baselines remain unchanged.
