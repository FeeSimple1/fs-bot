"""PR-12 Litaviccus targeting acceptance matrix. Game execution requires an explicit --run gate.

Run only after the coordinating agent freezes the candidate source. Every
attempt gets a new matrix label; failed output is retained rather than reused.
"""
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
from pathlib import Path
import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'fs-bot'
PARENT = HERE.parent / 'fs-litaviccus-before'
PRIOR = HERE.parent / 'event-battle-choices-2026-11-03'
PARENT_RECORDS = PRIOR / 'attempt1'
GAMEPLAY_PARENT_SHA = '7d627253f5b38bdedcfe5c84214a5476f68898d1f9cd11d50ef29377a42fe108'
EXPECTED_PARENT = '4f33e09347d809846d61e8cc25ebf711100372fc'
EXPECTED_PARENT_SHA = '7d627253f5b38bdedcfe5c84214a5476f68898d1f9cd11d50ef29377a42fe108'
sys.path.insert(0, str(REPO))
from fs_bot import rules_consts as rc

SCENARIOS = (rc.SCENARIO_PAX_GALLICA, rc.SCENARIO_RECONQUEST,
             rc.SCENARIO_GREAT_REVOLT, rc.SCENARIO_ARIOVISTUS,
             rc.SCENARIO_GALLIC_WAR)


def read_json(path):
    return json.loads(path.read_text())


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def identity(repo=REPO):
    paths = sorted((repo / 'fs_bot').rglob('*.py'),
                   key=lambda path: path.relative_to(repo).as_posix())
    files = {path.relative_to(repo).as_posix():
             hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
    digest = hashlib.sha256()
    for path in paths:
        digest.update(path.relative_to(repo).as_posix().encode() + b'\0' + path.read_bytes())
    commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
    changed = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD', '--', 'fs_bot'],
                                      cwd=repo, text=True).splitlines()
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard',
                                        '--', 'fs_bot'], cwd=repo, text=True).splitlines()
    return {'commit': commit, 'python_sha256': digest.hexdigest(),
            'python_files': len(paths),
            'python_worktree_changes': any(name.endswith('.py') for name in changed + untracked),
            'files': files}


def protected_files():
    paths = [p for p in sorted((REPO / 'Reference Documents').rglob('*')) if p.is_file()]
    paths += [REPO / 'fs_bot/rules_consts.py', REPO / 'fs_bot/tools/balance_baseline.json']
    return {path.relative_to(REPO).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in paths}


def jobs(out):
    result = []
    for edition, seeds in [('legacy', '1-20'), ('original', '201-205'),
                           ('second-edition', '201-205')]:
        name = 'bots-' + edition
        result.append({'name': name, 'hash_seed': '0',
                       'args': ['-m', 'fs_bot.tools.run_batch', '--seeds', seeds,
                                '--card-edition', edition, '--workers', '2',
                                '--out', str(out / name)]})
    for edition, seeds in [('legacy', '1-40'), ('original', '201-202'),
                           ('second-edition', '201-202')]:
        for seed in ('0', '7'):
            name = f'fuzz-{edition}-{seed}'
            result.append({'name': name, 'hash_seed': seed,
                           'args': ['-m', 'fs_bot.tools.player_fuzz', '--seeds', seeds,
                                    '--card-edition', edition, '--out', str(out / (name + '.json'))]})
    for seed in ('0', '7'):
        name = f'census-{seed}'
        result.append({'name': name, 'hash_seed': seed,
                       'args': ['-m', 'fs_bot.tools.error_census', '--seeds', '201-202',
                                '--strict', '--out', str(out / (name + '.json'))]})
    result.append({'name': 'bot-repeat-7', 'hash_seed': '7',
                   'args': [str(HERE / 'repeat_bots.py'), '--out', str(out / 'bot-repeat-7.json')]})
    return result


def checked_records(path, edition, seeds):
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    expected = {(scenario, seed) for scenario in SCENARIOS for seed in seeds}
    assert len(rows) == len(expected), (path, 'record count', len(rows))
    assert {(row['scenario'], row['seed']) for row in rows} == expected, (path, 'coverage')
    for row in rows:
        case = (row['scenario'], row['seed'], edition)
        assert all(row.get(key) is True for key in ('completed', 'game_completed', 'audit_completed')), (case, 'completion/audit')
        assert not row['errors'] and not row['integrity_findings'], (case, 'engine errors or integrity')
        assert row['card_edition'] == edition and row['final_state_sha256'], (case, 'edition/state hash')
        assert len(row['final_ranking']) == 4, (case, 'ranking size')
        assert not row['engine_ranking_output_missing'] and not row['winner_differs_from_highest_margin'], (case, 'ranking missing/disagreement')
        assert all(entry['severity'] == 'legal-decline' for entry in row['diagnostics']), (case, 'non-legal diagnostic')
    return rows


def verify(out, before, protected, runs):
    checks = []
    failures = []

    def check(name, action):
        try:
            value = action()
        except Exception as exc:
            failures.append({'check': name, 'error': repr(exc)})
            return None
        checks.append(name)
        return value

    check('source identity and all Python files unchanged', lambda: require(identity() == before))
    check('all protected inputs unchanged', lambda: require(protected_files() == protected))
    check('all subprocess exits zero', lambda: require(all(run['exit_code'] == 0 for run in runs)))
    check('every job retained unchanged source and protected inputs',
          lambda: require(all(run.get('source_unchanged_after') and run.get('protected_unchanged_after') for run in runs)))
    bot_games = {}
    for edition, seeds in [('legacy', range(1, 21)), ('original', range(201, 206)),
                           ('second-edition', range(201, 206))]:
        rows = check('bot records ' + edition,
                     lambda edition=edition, seeds=seeds: checked_records(out / ('bots-' + edition) / 'games.jsonl', edition, seeds))
        if rows is not None:
            bot_games[edition] = rows
            check('bot record source identity ' + edition,
                  lambda rows=rows: require(all(row['source_sha256'] == before['python_sha256'] and row['commit'] == before['commit'] for row in rows)))
        def verify_bot_metadata(edition=edition):
            metadata = read_json(out / ('bots-' + edition) / 'metadata.json')
            require(metadata['commit'] == before['commit'])
            require(metadata['source_sha256'] == before['python_sha256'])
            require(metadata['python'] == '3.10.22' and metadata['hash_seed'] == 0)
            require(metadata['all_factions_bots'] is True)
            require(metadata['card_edition'] == edition and set(metadata['scenarios']) == set(SCENARIOS))
        check('bot metadata ' + edition, verify_bot_metadata)

    def verify_bot_hash_repeat():
        repeated = read_json(out / 'bot-repeat-7.json')
        require(repeated['metadata']['source'] == before)
        require(repeated['metadata']['python'] == '3.10.22' and repeated['metadata']['hash_seed'] == 7)
        rows = repeated['records']
        require(len(rows) == 25 and {(r['scenario'], r['seed']) for r in rows} ==
                {(scenario, seed) for scenario in SCENARIOS for seed in range(1, 6)})
        main = {(r['scenario'], r['seed']): r for r in bot_games['legacy']}
        ignored = {'seconds', 'commit', 'source_sha256'}
        for row in rows:
            previous = main[row['scenario'], row['seed']]
            require({k: v for k, v in row.items() if k not in ignored} ==
                    {k: v for k, v in previous.items() if k not in ignored})
        return len(rows)
    bot_hash_repeats = check('25 exact cross-hash bot result repeats', verify_bot_hash_repeat)

    fuzz = {}
    for edition, seeds in [('legacy', range(1, 41)), ('original', range(201, 203)),
                           ('second-edition', range(201, 203))]:
        def verify_fuzz(edition=edition, seeds=seeds):
            a, b = [read_json(out / f'fuzz-{edition}-{seed}.json') for seed in ('0', '7')]
            require(a == b)
            require((out / f'fuzz-{edition}-0.log').read_bytes() ==
                    (out / f'fuzz-{edition}-7.log').read_bytes())
            expected = {(scenario, seed) for scenario in SCENARIOS for seed in seeds}
            require(a['games'] == len(a['records']) == len(expected))
            require({(r['scenario'], r['seed']) for r in a['records']} == expected)
            require(a['hard_findings'] == 0 and not a['by_kind'])
            require(all(r['game_completed'] and not r['findings'] and r['card_edition'] == edition
                        for r in a['records']))
            require(a['metadata']['source_sha256'] == before['python_sha256'])
            require(a['metadata']['commit'] == before['commit'])
            require(a['metadata']['python'] == '3.10.22' and a['metadata']['replay'] is True)
            require(a['metadata']['reactive'] is True and a['metadata']['events'] is True)
            require(a['metadata']['card_edition'] == edition and a['metadata']['seeds'] == list(seeds))
            require(set(a['metadata']['scenarios']) == set(SCENARIOS))
            return {key: a[key] for key in ('games', 'human_turns', 'event_turns', 'events_ok',
                                            'partial', 'hard_findings', 'batch_digest')}
        value = check('exact cross-hash mixed-seat JSON and stdout ' + edition, verify_fuzz)
        if value is not None:
            fuzz[edition] = value

    def verify_census():
        a, b = [read_json(out / f'census-{seed}.json') for seed in ('0', '7')]
        require(a == b)
        require((out / 'census-0.log').read_bytes() == (out / 'census-7.log').read_bytes())
        require(a['games'] == a['completed'] == 10 and not a['failures'])
        require(all(key == 'legal-decline' or count == 0 for key, count in a['by_severity'].items()))
        require(a['metadata']['source_sha256'] == before['python_sha256'])
        require(a['metadata']['commit'] == before['commit'] and a['metadata']['python'] == '3.10.22')
        require(a['metadata']['strict'] is True and a['metadata']['card_edition'] == 'legacy')
        require(a['metadata']['seeds'] == [201, 202] and set(a['metadata']['scenarios']) == set(SCENARIOS))
        require(a['failed_games'] == a['illegal'] == 0)
        return a['by_severity']
    census = check('strict census and exact cross-hash output', verify_census)

    rates = []
    baseline_differences = []
    parent_differences = []
    parent_state_differences = []
    if 'legacy' in bot_games:
        rows = bot_games['legacy']
        baseline = read_json(REPO / 'fs_bot/tools/balance_baseline.json')['games']
        parent = {(r['scenario'], r['seed']): r for r in
                  map(json.loads, (out / 'parent-bots-legacy/games.jsonl').read_text().splitlines())}
        for row in rows:
            key = f"{row['scenario']}|{row['seed']}"
            if any(row[field] != baseline[key][field] for field in ('winner', 'cards')):
                baseline_differences.append({'scenario': row['scenario'], 'seed': row['seed'],
                                             'before': baseline[key],
                                             'after': {field: row[field] for field in ('winner', 'cards')}})
            previous = parent[row['scenario'], row['seed']]
            if any(row[field] != previous[field] for field in ('winner', 'cards')):
                parent_differences.append({'scenario': row['scenario'], 'seed': row['seed'],
                                           'before': {field: previous[field] for field in ('winner', 'cards')},
                                           'after': {field: row[field] for field in ('winner', 'cards')}})
            if row['final_state_sha256'] != previous['final_state_sha256']:
                parent_state_differences.append({'scenario': row['scenario'], 'seed': row['seed'],
                                                 'before': previous['final_state_sha256'],
                                                 'after': row['final_state_sha256']})
        for scenario in SCENARIOS:
            old = Counter(baseline[f'{scenario}|{seed}']['winner'] for seed in range(1, 21))
            new = Counter(row['winner'] for row in rows if row['scenario'] == scenario)
            for faction in sorted(set(old) | set(new)):
                rates.append({'scenario': scenario, 'faction': faction,
                              'before_wins': old[faction], 'after_wins': new[faction],
                              'percentage_point_change': 5 * (new[faction] - old[faction])})
        check('unchanged 15-percentage-point balance band',
              lambda: require(all(abs(row['percentage_point_change']) <= 15 for row in rates)))
    semantic_fields_ignored = {'seconds', 'commit', 'source_sha256'}
    parent_semantic_differences = []
    for edition, rows in bot_games.items():
        previous = {(row['scenario'], row['seed']): row for row in
                    map(json.loads, (out / ('parent-bots-' + edition) / 'games.jsonl').read_text().splitlines())}
        for row in rows:
            old = previous[row['scenario'], row['seed']]
            fields = sorted(k for k in set(row) | set(old)
                            if k not in semantic_fields_ignored and row.get(k) != old.get(k))
            if fields:
                parent_semantic_differences.append({'scenario': row['scenario'], 'seed': row['seed'],
                                                   'card_edition': edition, 'changed_fields': fields})
    check('all 150 NPC gameplay records compared with parent',
          lambda: require(len(bot_games) == 3 and sum(len(rows) for rows in bot_games.values()) == 150))
    write_json(out / 'parent-all-edition-semantic-differences.json', parent_semantic_differences)
    write_json(out / 'baseline-differences.json', baseline_differences)
    write_json(out / 'parent-outcome-differences.json', parent_differences)
    write_json(out / 'parent-state-differences.json', parent_state_differences)
    write_json(out / 'causal-review-needed.json', {
        'scope': 'Every changed semantic result across all 150 games needs first-divergence review; this matrix itself does not run diagnostic traces.',
        'parent_commit': EXPECTED_PARENT, 'candidate_source': {k: v for k, v in before.items() if k != 'files'},
        'pairs': parent_differences,
        'all_edition_semantic_differences': parent_semantic_differences,
        'disposition': ('Causal review required before final acceptance' if parent_semantic_differences
                        else 'No NPC semantic differences'),
        'known_mechanism_to_review': 'Owner-adopted PR-12 Litaviccus prediction and target selection may change outcomes.'})
    result = {'source': {k: v for k, v in before.items() if k != 'files'},
              'python': platform.python_version(), 'checks_passed': checks, 'failures': failures,
              'protected_inputs_unchanged': protected_files() == protected,
              'protected_input_count': len(protected),
              'bot_games': sum(len(rows) for rows in bot_games.values()),
              'bot_hash_seed_repeat_executions': bot_hash_repeats,
              'bot_editions': {edition: len(rows) for edition, rows in bot_games.items()},
              'fuzz': fuzz, 'mixed_seat_distinct_cases': sum(value['games'] for value in fuzz.values()),
              'mixed_seat_executions_including_replay_and_hash_repeat': 4 * sum(value['games'] for value in fuzz.values()),
              'strict_census_executions': 20 if census is not None else 0, 'census_severities': census,
              'planned_counts': {'bots': 150, 'mixed_distinct': 220, 'mixed_executions': 880, 'strict_census_executions': 20, 'bot_hash_seed_repeat_executions': 25},
              'baseline_comparison': {'games': 100, 'passed': bool(rates) and all(abs(r['percentage_point_change']) <= 15 for r in rates),
                                      'rate_changes': rates, 'winner_or_card_count_changes': len(baseline_differences),
                                      'baseline_changed': protected_files().get('fs_bot/tools/balance_baseline.json') != protected['fs_bot/tools/balance_baseline.json'],
                                      'baseline_sha256': protected['fs_bot/tools/balance_baseline.json'], 'existing_band': 0.15},
              'parent_comparison': {'games': 100, 'winner_or_card_count_changes': len(parent_differences),
                                    'final_state_changes': len(parent_state_differences),
                                    'all_editions_games': 150, 'all_editions_semantic_changes': len(parent_semantic_differences),
                                    'causal_review_required': bool(parent_semantic_differences),
                                    'provenance': 'parent-record-provenance.json; exact full Python-byte equivalence with the measured parent source'},
              'scope': 'All five scenarios. Bots: legacy1-20; original/second-edition201-205. Mixed: legacy1-40; original/second-edition201-202, hashes0/7 with replay. Strict census201-202, hashes0/7.',
              'passed': not failures}
    write_json(out / 'integration-results.json', result)
    return result


def require(condition):
    if not condition:
        raise AssertionError('Required check failed; inspect retained per-game output')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', action='store_true', help='Run only after root explicitly freezes source')
    parser.add_argument('--expected-source-sha', help='Required frozen Python SHA-256 from root')
    parser.add_argument('--label', default='matrix-01')
    args = parser.parse_args()
    if '/' in args.label or '\\' in args.label or args.label.startswith('.'):
        parser.error('label must be a plain new directory name')
    out = HERE / args.label
    plan = jobs(out)
    if not args.run:
        summary = {'status': 'Prepared only: no games started', 'expected_python': '3.10.22',
                   'matrix_label': args.label, 'jobs': plan,
                   'counts': {'bots': 150, 'mixed_distinct': 220, 'mixed_executions': 880, 'strict_census_executions': 20, 'bot_hash_seed_repeat_executions': 25}}
        write_json(HERE / 'matrix-plan.json', summary)
        print(json.dumps({key: value for key, value in summary.items() if key != 'jobs'}, indent=2))
        return 0
    if not args.expected_source_sha:
        parser.error('--run requires --expected-source-sha and coordinating root freeze authorization')
    require(platform.python_version() == '3.10.22')
    before = identity()
    require(before['commit'] == EXPECTED_PARENT and before['python_sha256'] == args.expected_source_sha)
    parent = identity(PARENT)
    require(parent['commit'] == EXPECTED_PARENT and parent['python_sha256'] == EXPECTED_PARENT_SHA)
    require(not parent['python_worktree_changes'])
    protected = protected_files()
    require(protected == read_json(HERE / 'protected-before.json') and len(protected) == 49)
    provenance = read_json(HERE / 'parent-provenance-preflight.json')
    require(provenance['all_python_files_identical'] is True)
    require(provenance['parent_source_sha256'] == parent['python_sha256'])
    require(provenance['gameplay_source_sha256'] == GAMEPLAY_PARENT_SHA)
    require(parent['files'] == read_json(HERE / 'parent-source.json')['files'])
    out.mkdir(exist_ok=False)
    write_json(out / 'source-manifest-before.json', before)
    write_json(out / 'protected-before.json', protected)
    for edition, seeds in [('legacy', range(1, 21)), ('original', range(201, 206)),
                           ('second-edition', range(201, 206))]:
        src = PARENT_RECORDS / ('bots-' + edition)
        metadata = read_json(src / 'metadata.json')
        require(metadata['source_sha256'] == GAMEPLAY_PARENT_SHA)
        rows = checked_records(src / 'games.jsonl', edition, seeds)
        require(all(row['source_sha256'] == GAMEPLAY_PARENT_SHA and row['commit'] == metadata['commit']
                    for row in rows))
        dest = out / ('parent-bots-' + edition)
        dest.mkdir()
        for name in ('metadata.json', 'games.jsonl', 'summary.json'):
            require(hashlib.sha256((src / name).read_bytes()).hexdigest() ==
                    provenance['record_file_hashes'][str((src / name).relative_to(PRIOR))])
            shutil.copyfile(src / name, dest / name)
    write_json(out / 'parent-record-provenance.json', provenance)
    write_json(out / 'planned-commands.json', plan)

    def run(job):
        started = time.time()
        env = os.environ.copy()
        env.update(PYTHONHASHSEED=job['hash_seed'], PYTHONPATH=str(REPO))
        command = [sys.executable, *job['args']]
        if identity() != before or protected_files() != protected:
            record = {**job, 'command': command, 'exit_code': -1, 'error': 'Source/protected inputs changed before launch'}
            write_json(out / (job['name'] + '-command.json'), record)
            return record
        with (out / (job['name'] + '.log')).open('w') as stream:
            process = subprocess.run(command, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT)
        record = {**job, 'command': command, 'cwd': str(REPO), 'exit_code': process.returncode,
                  'elapsed_seconds': round(time.time() - started, 3),
                  'source_unchanged_after': identity() == before,
                  'protected_unchanged_after': protected_files() == protected}
        write_json(out / (job['name'] + '-command.json'), record)
        print(f"{job['name']}: exit {process.returncode}", flush=True)
        return record

    with ThreadPoolExecutor(max_workers=3) as executor:
        runs = list(executor.map(run, plan))
    write_json(out / 'integration-commands.json', runs)
    write_json(out / 'source-manifest-after.json', identity())
    result = verify(out, before, protected, runs)
    print(json.dumps({'passed': result['passed'], 'failures': result['failures'],
                      'bot_games': result['bot_games'], 'fuzz': result['fuzz'],
                      'parent_comparison': result['parent_comparison'],
                      'baseline_passed': result['baseline_comparison']['passed']}, indent=2))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
