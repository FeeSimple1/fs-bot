#!/usr/bin/env python3
"""Read-only audit witnesses: execute public rules paths, never patch source/tests.

Run from fs-bot:
 PYTHONPATH=. .venv/bin/python ../audit8-work/frontend/probe_winter_campaign.py

Fixtures are controlled lawful after-Harvest positions, not naturally replayed
scenario games. The public acquisition/execution paths and real SeatSession,
save/load and engine transaction are used. See findings.json for scope.
"""
import copy
import io
import json
from pathlib import Path

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece, count_pieces
from fs_bot.cli.display import HumanTurnDisplay
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import _action_transaction
from fs_bot.engine.moves import validate_player_action
from fs_bot.engine.victory import check_any_victory
from fs_bot.engine.winter_campaign import (
    validate_human_plan, winter_campaign_after_harvest,
)
from fs_bot.state.state_schema import (
    build_initial_state, validate_state, check_structural_integrity,
)
from fs_bot.state.serialize import encode, decode, save_game, load_game
from fs_bot.tools.seat_session import SeatSession, DecisionPending, board_copy, fingerprint

ROOT = Path(__file__).resolve().parent


def checks(state):
    result = {'validate_state': validate_state(state),
              'check_structural_integrity': check_structural_integrity(state)}
    assert not any(result.values()), result
    return result


def digest(state):
    return fingerprint(board_copy(state))


def fixture(owner, scenario=rc.SCENARIO_GREAT_REVOLT, edition='second-edition'):
    state = build_initial_state(scenario, seed=19)
    state['card_edition'] = edition
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    state['non_player_factions'] = set(rc.FACTIONS) - {owner}
    for faction in state['resources']:
        if faction != rc.GERMANS or scenario in rc.ARIOVISTUS_SCENARIOS:
            state['resources'][faction] = 20
    # A focused after-Harvest board must not already have ended at Victory.
    # These sixteen legal off-route Allies put Romans at 14; Aedui have five
    # versus German six, Arverni have five, and Belgae control no Regions.
    allied_tribes = {
        rc.GERMANS: [rc.TRIBE_SUEBI_NORTH, rc.TRIBE_SUGAMBRI,
                     rc.TRIBE_SUEBI_SOUTH, rc.TRIBE_UBII,
                     rc.TRIBE_TREVERI, rc.TRIBE_MENAPII],
        rc.ARVERNI: [rc.TRIBE_ARVERNI, rc.TRIBE_VENETI, rc.TRIBE_NAMNETES,
                     rc.TRIBE_PICTONES, rc.TRIBE_SANTONES],
        rc.AEDUI: [rc.TRIBE_AEDUI, rc.TRIBE_BITURIGES, rc.TRIBE_CADURCI,
                   rc.TRIBE_VOLCAE, rc.TRIBE_BELLOVACI],
    }
    for faction, tribes in allied_tribes.items():
        for tribe in tribes:
            assert tribe in state['tribes']
            assert rc.TRIBE_FACTION_RESTRICTION.get(tribe, faction) == faction
            place_piece(state, rc.TRIBE_TO_REGION[tribe], faction, rc.ALLY)
            state['tribes'][tribe]['allied_faction'] = faction
    assert check_any_victory(state) is None
    card = 'A63' if scenario in rc.ARIOVISTUS_SCENARIOS else 63
    state['current_card'] = card
    acquisition = execute_decision(state, owner, {'action': 'event', 'player_action': {
        'command': 'Event', 'sa': 'No SA', 'details': {
            'card_id': card, 'text_preference': rc.EVENT_SHADED,
            'event_params': {'faction': owner} if card == 63 else {},
        }}})
    assert acquisition['executed'], acquisition
    # Focus the consumer on its printed after-Harvest boundary. No phase or
    # deck/turn reachability claim is made by this controlled fixture.
    state['current_card'] = rc.WINTER_CARD
    assert check_any_victory(state) is None
    return state, acquisition


def battle_fixture(scenario=rc.SCENARIO_GREAT_REVOLT, edition='second-edition'):
    state, acquisition = fixture(rc.AEDUI, scenario, edition)
    place_piece(state, rc.CARNUTES, rc.AEDUI, rc.WARBAND, 12)
    place_piece(state, rc.CARNUTES, rc.BELGAE, rc.WARBAND, 10, piece_state=rc.REVEALED)
    return state, acquisition


def battle_plan(repeat=2):
    return {'command': 'Battle', 'sa': 'No SA', 'details': {'battle_plan': [
        {'region': rc.CARNUTES, 'target': rc.BELGAE} for _ in range(repeat)]}}


def battle_summary(state):
    return {'aedui': count_pieces(state, rc.CARNUTES, rc.AEDUI, rc.WARBAND),
            'belgae': count_pieces(state, rc.CARNUTES, rc.BELGAE, rc.WARBAND),
            'resources': state['resources'][rc.AEDUI]}


def raw_campaign(state, owner, plan):
    requests = []
    def agent(board, faction, request):
        requests.append({'faction': faction, 'request': copy.deepcopy(request)})
        if request['kind'] == 'winter_campaign':
            return plan if request['remaining_actions'] == 2 else {'decline': True}
        return None  # Raw callback's documented fallback; durable witnesses below.
    state['decision_agent'] = agent
    result = winter_campaign_after_harvest(state)
    state.pop('decision_agent', None)
    return result, requests


def new_session(state, owner, meta=None, log=None):
    meta = meta if meta is not None else {'seat': owner, 'scenario': state['scenario'], 'seed': 19}
    log = log if log is not None else []
    session = SeatSession(state, meta, log, HumanTurnDisplay(io.StringIO()))
    state['decision_agent'] = session.reactive
    return session


def driver(session):
    def callback(*args):
        raise AssertionError('No Sequence-of-Play turn belongs in after-Harvest consumer')
    callback.transaction_checkpoint = session.checkpoint
    callback.transaction_restore = session.restore
    callback.transaction_complete = session.transaction_complete
    return callback


def persist_reload(session, path):
    before = digest(session.state)
    journal = copy.deepcopy(session.data['journal'])
    pending = copy.deepcopy(session.data['pending'])
    save_game(session.state, path, meta=session.meta, log=session.log)
    state, meta, log = load_game(path, validate=True)
    resumed = new_session(state, session.seat, meta, log)
    assert digest(state) == before
    assert resumed.data['journal'] == journal and resumed.data['pending'] == pending
    checks(state)
    return resumed


def run_saved_campaign(state, owner, plan, name):
    """Each pending request uses real rollback and a fresh on-disk resume."""
    folder = ROOT / 'sessions' / name
    folder.mkdir(parents=True, exist_ok=True)
    session = new_session(state, owner)
    before = digest(state)
    before_checks = checks(state)
    assert check_any_victory(state) is None
    pauses = []
    first_id = None
    injected_invalid = False
    corrected = False
    rejected_same_id = False
    while len(pauses) < 160:
        try:
            with _action_transaction(session.state, driver(session)):
                result = winter_campaign_after_harvest(session.state)
            session.finish()
            break
        except DecisionPending:
            assert digest(session.state) == before, 'Paused campaign leaked board or RNG changes'
            checks(session.state)
            pending = session.data['pending']
            request = decode(pending['request'])
            live_pending = decode(pending['board'])
            checks(live_pending)
            row = {'id': pending['id'], 'kind': request['kind'],
                   'remaining_actions': request.get('remaining_actions'),
                   'rolled_back_board_rng': True, 'accepted_journal': len(session.data['journal']),
                   'pending_board_sha256': digest(live_pending), 'error': session.error}
            pauses.append(row)
            if request['kind'] == 'winter_campaign' and request['remaining_actions'] == 2:
                if first_id is None:
                    first_id = pending['id']
                    session = persist_reload(session, folder / 'missing_response.json')
                    response = {'command': 'invalid-command'}
                    injected_invalid = True
                elif injected_invalid and not corrected:
                    assert pending['id'] == first_id and session.error
                    assert not session.data['journal'] or all(
                        decode(e['assistant_request'])['kind'] != 'winter_campaign'
                        for e in session.data['journal'])
                    rejected_same_id = True
                    session = persist_reload(session, folder / 'invalid_response.json')
                    response = plan
                    corrected = True
                else:
                    raise AssertionError('Unexpected repeated initial Campaign request')
            elif request['kind'] == 'winter_campaign':
                assert request['remaining_actions'] == 1
                session = persist_reload(session, folder / 'accepted_first_action.json')
                response = {'decline': True}
            elif request['kind'] == 'march_dropoff':
                response = {'dropoffs': [{'faction': owner, 'piece_type': rc.WARBAND,
                                         'piece_state': rc.HIDDEN, 'count': 2}]}
            else:
                response = {'use_default': True}
            # Reload every pending prompt, not merely the Campaign prompts.
            session = persist_reload(session, folder / 'checkpoint.json')
            session.import_inbox({'decision_id': session.data['pending']['id'], 'response': response})
    else:
        raise AssertionError('Session did not finish within bounded prompts')
    assert rejected_same_id
    after_checks = checks(session.state)
    final_hash = digest(session.state)
    session = persist_reload(session, folder / 'finished.json')
    assert digest(session.state) == final_hash
    entries = copy.deepcopy(session.log)
    origin = decode(session.data['origin'])
    replay = new_session(origin, owner)
    replay.data['queue'] = [SeatSession._inbox_entry(e) for e in entries]
    replay.data['expected'] = [
        {'id': e['assistant_id'], 'signature': e['assistant_signature'],
         'request': copy.deepcopy(e['assistant_request']),
         'action_windows_version': e.get('assistant_action_windows_version', 0)}
        for e in entries]
    with _action_transaction(replay.state, driver(replay)):
        replay_result = winter_campaign_after_harvest(replay.state)
    replay.finish()
    assert digest(replay.state) == final_hash
    assert replay_result == result
    assert replay.log == entries and not replay.data['queue']
    checks(replay.state)
    return session.state, {
        'before_checks': before_checks, 'after_checks': after_checks,
        'fixture_has_no_victory_winner': True,
        'before_sha256': before, 'after_sha256': final_hash,
        'pauses': pauses, 'missing_and_invalid_same_id': rejected_same_id,
        'all_pauses_rollback_board_rng': True, 'save_load_journal_pending_preserved': True,
        'verified_replay_same_board_rng_and_log': True,
        'accepted_kinds': [decode(e['assistant_request'])['kind'] for e in entries],
        'result': result,
    }


def duplicate_cases():
    cases = []
    for scenario, edition in [(rc.SCENARIO_GREAT_REVOLT, 'legacy'),
                               (rc.SCENARIO_GREAT_REVOLT, 'second-edition'),
                               (rc.SCENARIO_ARIOVISTUS, 'second-edition')]:
        state, acquired = battle_fixture(scenario, edition)
        before = digest(state)
        before_checks = checks(state)
        used = validate_human_plan(state, rc.AEDUI, battle_plan())
        assert used == 1 and digest(state) == before
        ok, ordinary = validate_player_action(state, rc.AEDUI, battle_plan())
        assert not ok and digest(state) == before
        legal = copy.deepcopy(state)
        legal_result, _ = raw_campaign(legal, rc.AEDUI, battle_plan(1))
        bad = copy.deepcopy(state)
        bad_result, _ = raw_campaign(bad, rc.AEDUI, battle_plan(2))
        assert legal_result['remaining_actions'] == bad_result['remaining_actions'] == 1
        assert battle_summary(legal) == {'aedui': 10, 'belgae': 4, 'resources': 19}
        assert battle_summary(bad) == {'aedui': 10, 'belgae': 0, 'resources': 18}
        cases.append({'scenario': scenario, 'edition': edition, 'acquisition': acquired,
                      'before_checks': before_checks, 'preview_used_actions': used,
                      'preview_live_board_rng_untouched': digest(state) == before,
                      'ordinary_rejection': ordinary, 'before': battle_summary(state),
                      'bad_after': battle_summary(bad), 'legal_after': battle_summary(legal),
                      'bad_result': bad_result, 'legal_result': legal_result,
                      'bad_checks': checks(bad), 'legal_checks': checks(legal)})
    state, _ = battle_fixture()
    final, durable = run_saved_campaign(state, rc.AEDUI, battle_plan(), 'duplicate-battle')
    assert battle_summary(final)['belgae'] == 0
    # Guard already preserved in the shared executor: do not overclaim.
    astate, _ = fixture(rc.AEDUI)
    for region in (rc.CARNUTES, rc.MANDUBII):
        place_piece(astate, region, rc.AEDUI, rc.WARBAND, 6)
        place_piece(astate, region, rc.BELGAE, rc.WARBAND, 5, piece_state=rc.REVEALED)
    ambush = {'command': 'Battle', 'sa': 'Ambush', 'sa_regions': [rc.CARNUTES, rc.MANDUBII],
              'details': {'battle_plan': [{'region': r, 'target': rc.BELGAE}
                                           for r in (rc.CARNUTES, rc.MANDUBII)]}}
    a_before = digest(astate)
    try:
        validate_human_plan(astate, rc.AEDUI, ambush)
    except ValueError as exc:
        ambush_error = str(exc)
    else:
        raise AssertionError('Expected already-fixed Aedui Ambush guard')
    assert 'one Region' in ambush_error and digest(astate) == a_before
    return {'cases': cases, 'durable': durable,
            'aedui_ambush_guard_control': {'error': ambush_error, 'checks': checks(astate),
                                         'board_rng_untouched': True}}


def march_fixture():
    state, acquisition = fixture(rc.ARVERNI)
    place_piece(state, rc.CARNUTES, rc.ARVERNI, rc.LEADER, leader_name=rc.VERCINGETORIX)
    place_piece(state, rc.CARNUTES, rc.ARVERNI, rc.WARBAND, 4)
    plan = {'command': 'March', 'sa': 'No SA', 'details': {
        'origins': [rc.CARNUTES], 'destinations': [rc.SEQUANI],
        'routes': {rc.CARNUTES: [rc.MANDUBII, rc.SEQUANI]},
        'groups': {rc.CARNUTES: {rc.WARBAND: 4, rc.LEADER: True}}}}
    return state, acquisition, plan


def march_summary(state):
    return {'mandubii': count_pieces(state, rc.MANDUBII, rc.ARVERNI, rc.WARBAND),
            'sequani': count_pieces(state, rc.SEQUANI, rc.ARVERNI, rc.WARBAND),
            'resources': state['resources'][rc.ARVERNI]}


def dropoff_cases():
    state, acquired, plan = march_fixture()
    before = digest(state)
    assert validate_human_plan(state, rc.ARVERNI, plan) == 1 and digest(state) == before
    ordinary = copy.deepcopy(state)
    ordinary['current_card'] = 1
    requests = []
    def agent(board, faction, request):
        requests.append(copy.deepcopy(request))
        if request['kind'] == 'march_dropoff':
            return {'dropoffs': [{'faction': rc.ARVERNI, 'piece_type': rc.WARBAND,
                                 'piece_state': rc.HIDDEN, 'count': 2}]}
        return None
    agent.supports_march_dropoffs = True
    ordinary['decision_agent'] = agent
    ordinary_before_checks = checks(ordinary)
    ordinary_result = execute_decision(ordinary, rc.ARVERNI, {'action': 'command', 'player_action': plan})
    assert ordinary_result['executed']
    assert [r['kind'] for r in requests] == ['march_dropoff']
    assert march_summary(ordinary) == {'mandubii': 2, 'sequani': 2, 'resources': 19}
    final, durable = run_saved_campaign(state, rc.ARVERNI, plan, 'missing-dropoff')
    assert 'march_dropoff' not in durable['accepted_kinds']
    assert all(p['kind'] != 'march_dropoff' for p in durable['pauses'])
    assert march_summary(final) == {'mandubii': 0, 'sequani': 4, 'resources': 19}
    return {'acquisition': acquired, 'preview_live_board_rng_untouched': True,
            'ordinary_control': {'before_checks': ordinary_before_checks,
                                 'after_checks': checks(ordinary), 'requests': requests,
                                 'result': ordinary_result, 'after': march_summary(ordinary)},
            'winter_after': march_summary(final), 'durable': durable}


if __name__ == '__main__':
    output = {'UI8-01': duplicate_cases(), 'UI8-02': dropoff_cases()}
    path = ROOT / 'probe_winter_campaign-output.json'
    path.write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'output': str(path), 'duplicate_cases': len(output['UI8-01']['cases']),
                      'durable_sessions': 2, 'verified_replays': 2,
                      'duplicate_battle_outcome': output['UI8-01']['cases'][0]['bad_after'],
                      'winter_dropoff_outcome': output['UI8-02']['winter_after']}, sort_keys=True))
