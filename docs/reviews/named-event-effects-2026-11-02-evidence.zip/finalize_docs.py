from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).resolve().parent;R=E.parent/'fs-bot'
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
m=json.loads((E/'source-manifest.json').read_text())
for name,digest in m['files'].items():assert hashlib.sha256(subprocess.check_output(['git','show',f'{commit}:{name}'],cwd=R)).hexdigest()==digest,name
source={'commit':commit,'python_sha256':m['source']['python_sha256'],'python_files':len(m['files'])}
(E/'source-commit.json').write_text(json.dumps({'source':source,'matches_prepared_manifest':True,'validation_began_on_prepared_source_over':m['source']['base_commit']},indent=2)+'\n')
p=R/'docs/human-choice-progress.json';d=json.loads(p.read_text());d.update(updated='2026-11-02',updated_timezone='America/Chicago',closed=18,open=32,tested_source={**source,'working_tree_changes':True,'note':'Committed Python bytes equal the prepared full-suite/matrix source; documentation-only edits pending.'})
for f in d['findings']:
 if f['id']=='BE-04':f.update(status='closed',commits=[commit],report='reviews/named-event-effects-2026-11-02.md')
assert sum(f['status']=='closed' for f in d['findings'])==18
p.write_text(json.dumps(d,indent=2)+'\n')
r=json.loads((E/'matrix-01/integration-results.json').read_text());r['matrix_source']=r.pop('source');r['source']=source
r.update(audit_progress={'batch_closed':1,'batch_total':1,'closed':18,'open':32,'total':50,'percent':36},full_tests={'combined':6872,'new_cases':144,'engine_new':77,'cli_new':42,'durable_new':25,'final_documentation_status':'pending execution'},protected_inputs={'count':49,'unchanged':True},commits={'task_base':m['source']['base_commit'],'implementation':commit},limits=['34 unverified inventory rows remain separate','Two source questions and nine provisional rulings unchanged','NPC pre-Battle Intimidate projection lead remains outside original50 and unverified','Bounded source/behavior checks do not certify all rules or faction balance'])
r['causal_review']={'status':'independent review in progress','paired_games':16,'diagnostic_executions':32,'winner_changes':10,'length_only_changes':6,'baseline_refresh':False,'metadata_overlap':'Source commit occurred during diagnostics. All422 Python hashes verified before/after; original final Git-metadata equality failure retained.'}
(R/'docs/reviews/named-event-effects-2026-11-02-results.json').write_text(json.dumps(r,indent=2)+'\n')
s=(E/'report-draft.md').read_text()
s=s.replace('{{PROGRESS}}','The [progress register](../human-choice-progress.json) records **18 of 50 findings\nclosed (36%), with 32 open**. This one-finding task is **1/1 complete (100%)**.\nThese percentages count grouped findings, not equal effort units or overall\nrules accuracy. This report uses America/Chicago dates; validation occurred\non 3 November UTC. The preceding report used its UTC date.')
s=s.replace('{{CONTRACT}}','''The new `free_action` request type is `named_event_effect`. It carries the
card identity, named `acting_faction`, legal options and explicit decline/default
support. Romans select Legion source counts, a Rhenus Region or a Sacking City;
Arverni supply ordered exact Tribe removal/placement lists. Unknown fields,
wrong owners, invalid targets and malformed counts reject. A18 retains its old
`region` alias when it agrees with `target_region`.

The initial terminal Event plan defers choices to the live named-owner request.
A same-owner typed Event may also supply its own choices directly. Another
executor cannot supply those choices. A sole strict `decline: true` skips the
optional effect; `use_default: true` explicitly requests the NPC policy.
Gobannitio offers a separate “skip Ally changes; decide Rally” route.
See [AGENT_INTERFACE.md](../../AGENT_INTERFACE.md) for complete response shapes.

Owner responses retain supported component timing steps, but reject ignored
reply-level timing fields, unknown step names and invalid indices. Original
Event timing still includes handler completion and the Gobannitio Rally grant
under the executor's authority. A later legal Legion reclamation can open a
new source allocation; the menu offers it and execution preserves the chosen
timing rather than moving the reclamation earlier. The full possible two-Legion
quota remains enforced.

Old affected transcripts may need newly required owner choices. There is no
persistent save-format version change; numeric26 remains distinct from A26.''')
s=s.replace('{{VALIDATION}}',f'''## Validation and source identity

| Check | Accepted result |
|---|---|
| New regression cases | 144: 77 engine, 42 terminal, 25 durable-session cases |
| Combined focused check | 430 passed |
| Independent focused review | 320 passed with source unchanged throughout |
| Full suite before implementation commit | 6,872 passed; zero failures, errors or skips |
| Full suite before documentation commit | Pending execution |
| Final bot matrix | 150 audited games across five scenarios: legacy seeds1–20, original and second-edition seeds201–205 |
| Mixed-seat replay | 30 distinct cases, seeds201–202 in all three profiles; 120 executions including replay and hash seeds0/7; zero hard findings or partial actions |
| Strict census | 20 executions; only119 legal declines per hash, no errors; matching results across hashes |
| Protected inputs | All49 unchanged: 47 supplied references, rules_consts.py and balance baseline |

Every bot game completed its integrity audit, emitted four rankings and matched
the reported winner. Cross-hash mixed-seat digests match. Focused/full suites
and repeated games overlap and must not be added as independent samples.

Implementation commit: `{commit}`. The tested tree has **422 Python files**,
SHA-256 `{source['python_sha256']}`. The first full suite and matrix measured
these exact bytes as prepared changes over `2edf53e`; the source commit and
later documentation suite use the same bytes. Per-file manifests and the
prepared patch preserve that distinction.

The existing Gobannitio Citadel-as-Ally test now expects rejection of that
illegal target and retains its original unchanged-Citadel assertions. No test
threshold or scenario seed was relaxed. Earlier focused failures are retained,
including witnesses for foreign Spring timing, a reclaimed Legion's late source
choices and an initially rejected outer Rally timing point. Clean-parent
mechanical witnesses demonstrate Card2's missing Legions and A18's remaining
Scouted Warband/Successor; corrected witnesses preserve state integrity.''')
s=s.replace('{{OUTCOMES}}','''## Outcomes and evidence

The original100-game balance comparison passes without a baseline refresh.
Its largest faction win-rate change is **10 percentage points**, within the
unchanged15-point guard. Baseline SHA-256 remains
`cbdfc7883ea0137fd5bf414ebc3bf847ec1774f42bd447d81a74ed268f9496c3`.

**Sixteen games changed winner or length: ten changed winners and six changed
length only.** The bounded causal review ran32 diagnostic games, exactly16
parent/candidate pairs, reproducing their recorded outcomes. The raw first
trace differences have identical complete prefixes and pre-states/RNG.
Eight first causes are Card2 Legion placements; two are Card18 removals; six
change bot decisions under corrected Event availability. Independent source
review of these causes is pending finalization.

New accepted/acting-faction return metadata is distinguished from gameplay
changes. None of these16 first rows differs only in that metadata. In the two
Gallic War A18 cases, the first difference changes the chosen action without
changing the immediate post-state. Their state changes follow at the next
execution; only the earlier decision has the identical-prestate claim.

The source commit overlapped the diagnostic run. All32 games completed and
matched their expected outcomes, and all422 candidate Python hashes passed
both boundary checks. The original final whole-identity check failed because
the Git commit changed. That failure and the real start/end identities remain
in the archive; separate manifest/committed-tree verification confirms no
Python change. These records are not relabeled as an originally clean command,
and no diagnostic games were rerun merely to erase the metadata failure.

[Machine-readable results](named-event-effects-2026-11-02-results.json) and the
[evidence archive](named-event-effects-2026-11-02-evidence.zip) retain source
reviews, witnesses, logs, JUnit results, per-game records, paired traces and
source manifests. Archive packaging and verification are pending. These checks
explain bounded first divergences, not every later move or statistical balance.''')
assert '{{' not in s
(R/'docs/reviews/named-event-effects-2026-11-02.md').write_text(s)
print(json.dumps({'source':source,'closed':18,'total':50}))
