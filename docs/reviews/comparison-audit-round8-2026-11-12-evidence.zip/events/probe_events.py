"""Round-eight Event audit witnesses, for e62b0360c1b91032741ef8f6afa4d247c8ea2437.

Run from fs-bot: PYTHONPATH=. .venv/bin/python ../audit8-work/events/probe_events.py
Assertions pin observed defects, not intended regression expectations.
No production files, reference files, or test suites are changed or invoked.
"""
from copy import deepcopy
import json

from fs_bot import rules_consts as rc
from fs_bot.state.setup import setup_scenario
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.state.serialize import encode
from fs_bot.board.pieces import (
    place_piece, count_pieces, count_pieces_by_state, get_available,
    _count_on_legions_track,
)
from fs_bot.cards.card_effects import _ally_tribe
from fs_bot.bots.bot_dispatch import dispatch_bot_turn
from fs_bot.bots.bot_common import should_decline_event
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT


def checks(state):
    result = {'census_errors': validate_state(state),
              'structure_errors': check_structural_integrity(state)}
    assert result == {'census_errors': [], 'structure_errors': []}, result
    assert count_pieces(state, rc.PROVINCIA, rc.ROMANS, rc.FORT) == 1
    return result


def effect_state(state):
    return encode({key: value for key, value in state.items()
                   if key not in ('rng', 'decision_agent', 'event_params', 'executing_faction')})


def ready(state, card):
    state.update(current_card=card, current_card_id=card, can_play_event=True,
                 non_player_factions={rc.ROMANS, rc.ARVERNI, rc.AEDUI, rc.BELGAE})
    checks(state)
    return state


def board(card):
    state = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=1)
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.FORT)
    for faction in state['resources']:
        state['resources'][faction] = 10
    return ready(state, card)


def bot(state, faction):
    pre = checks(state)
    card = state['current_card_id']
    declined = should_decline_event(state, card, faction)
    assert declined is False
    action = dispatch_bot_turn(state, faction)
    assert action['command'] == 'Event', action
    before = effect_state(state)
    result = execute_decision(state, faction, {'action': ACTION_EVENT, 'bot_action': action})
    assert result['executed'] and not result.get('errors'), result
    return {'pre': pre, 'declined': declined, 'action': action,
            'result': result, 'game_effects_unchanged': before == effect_state(state),
            'post': checks(state)}


def explicit(state, faction, params, shaded=False):
    pre = checks(state)
    action = {'command': 'Event', 'details': {
        'card_id': state['current_card_id'],
        'text_preference': rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,
        'event_params': params}}
    result = execute_decision(state, faction, {'action': ACTION_EVENT, 'player_action': action})
    assert result['executed'] and not result.get('errors'), result
    return {'pre': pre, 'action': action, 'result': result, 'post': checks(state)}


def fallback(state, faction):
    alternate = deepcopy(state)
    alternate['can_play_event'] = False
    action = dispatch_bot_turn(alternate, faction)
    assert action['command'] not in ('Event', 'Pass'), action
    checks(alternate)
    return action


def legiones_without_legions():
    state = board(2)
    place_piece(state, rc.CARNUTES, rc.BELGAE, rc.WARBAND, count=2)
    place_piece(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA)
    assert sum(count_pieces(state, r, rc.ROMANS, rc.LEGION) for r in state['spaces']) == 0
    checks(state)
    positive = deepcopy(state)
    alternate = fallback(state, rc.BELGAE)
    observed = bot(state, rc.BELGAE)
    assert count_pieces(state, rc.CARNUTES, rc.ROMANS, rc.AUXILIA) == 0
    assert not observed['game_effects_unchanged']
    # The matching control introduces one real Legion, without triggering
    # the Belgic four-Warband/Leader threat branch before its Event choice.
    place_piece(positive, rc.CARNUTES, rc.ROMANS, rc.LEGION, from_legions_track=True)
    checks(positive)
    control = bot(positive, rc.BELGAE)
    assert count_pieces(positive, rc.CARNUTES, rc.ROMANS, rc.LEGION) == 0
    return {'no_legion_case': observed,
            'observed_auxilia_removed': 1, 'observed_legion_losses': 0,
            'available_flowchart_continuation': alternate,
            'one_legion_control': control,
            'control_legion_removed': 1,
            'fixture': 'Sparse canonical Great Revolt seed1; permanent Provincia Fort; two Belgic Warbands versus one Roman Auxilia at Carnutes; no other mobile pieces.'}


def conditional_roman_removals():
    rows = []
    for card in (3, 5):
        state = board(card)
        place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.LEGION,
                    from_legions_track=True, count=2)
        place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.AUXILIA, count=2)
        state['senate']['position'] = rc.ADULATION
        checks(state)
        positive = deepcopy(state)
        alternate = fallback(state, rc.ARVERNI)
        before_track = _count_on_legions_track(state)
        assert before_track > 4
        observed = bot(state, rc.ARVERNI)
        assert observed['game_effects_unchanged']
        if card == 3:
            # Move six track Legions onto the board through the canonical
            # helper, meeting Pompey's printed four-or-fewer prerequisite.
            place_piece(positive, rc.PROVINCIA, rc.ROMANS, rc.LEGION,
                        from_legions_track=True, count=before_track - 4)
            expected_removed = 2
        else:
            positive['senate']['position'] = rc.INTRIGUE
            expected_removed = 1
        checks(positive)
        legions = count_pieces(positive, rc.PROVINCIA, rc.ROMANS, rc.LEGION)
        auxilia = count_pieces(positive, rc.PROVINCIA, rc.ROMANS, rc.AUXILIA)
        control = bot(positive, rc.ARVERNI)
        assert count_pieces(positive, rc.PROVINCIA, rc.ROMANS, rc.LEGION) == legions - expected_removed
        assert count_pieces(positive, rc.PROVINCIA, rc.ROMANS, rc.AUXILIA) == auxilia - (2 if card == 5 else 0)
        rows.append({'card': card, 'track_legions_before': before_track,
                     'senate_before': rc.ADULATION, 'unmet_prerequisite': observed,
                     'available_flowchart_continuation': alternate,
                     'met_prerequisite_control': control,
                     'control_legions_removed': expected_removed,
                     'control_auxilia_removed': 2 if card == 5 else 0})
    return rows


def forced_marches_romans():
    state = board(32)
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.LEGION,
                from_legions_track=True, count=2)
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.AUXILIA,
                count=18, piece_state=rc.REVEALED)
    place_piece(state, rc.PROVINCIA, rc.ROMANS, rc.LEADER, leader_name=rc.CAESAR)
    assert _ally_tribe(state, rc.TRIBE_BITURIGES, rc.ARVERNI)
    checks(state)
    control = deepcopy(state)
    # One Roman mobile origin and one enemy-base destination remove all
    # origin/destination and division ambiguities. Two Auxilia Available
    # also satisfy the explicit ordinary Roman March gate in section8.8.3.
    assert get_available(state, rc.ROMANS, rc.AUXILIA) == 2
    observed = bot(state, rc.ROMANS)
    assert observed['game_effects_unchanged']
    moves = [{'from_region': rc.PROVINCIA, 'to_region': rc.BITURIGES,
              'piece_type': piece, 'count': count, **extra}
             for piece, count, extra in (
                 (rc.LEADER, 1, {'leader_name': rc.CAESAR}),
                 (rc.LEGION, 2, {}),
                 (rc.AUXILIA, 18, {'piece_state': rc.REVEALED}))]
    positive = explicit(control, rc.ROMANS, {'moves': moves})
    assert count_pieces(control, rc.BITURIGES, rc.ROMANS) == 21
    assert count_pieces_by_state(control, rc.BITURIGES, rc.ROMANS, rc.AUXILIA, rc.HIDDEN) == 18
    assert count_pieces(control, rc.PROVINCIA, rc.ROMANS) == 1
    # Independent complete setup reproduces the missing producer without
    # changing any physical pieces or Senate/resources from setup.
    pax = ready(setup_scenario(rc.SCENARIO_PAX_GALLICA, seed=1), 32)
    natural_setup = bot(pax, rc.ROMANS)
    assert natural_setup['game_effects_unchanged']
    return {'controlled_bot': observed, 'public_explicit_control': positive,
            'observed_moved': 0, 'control_moved': 21, 'control_auxilia_hidden': 18,
            'untouched_pax_physical_setup': natural_setup,
            'fixture': 'Sparse canonical Great Revolt seed1; only enemy Ally at Bituriges; only Roman mobile group in Provincia; permanent Fort retained. Untouched Pax setup is an additional witness, not the exact-priority proof.'}


if __name__ == '__main__':
    result = {'audited_commit': 'e62b0360c1b91032741ef8f6afa4d247c8ea2437',
              'EV8-01': legiones_without_legions(),
              'EV8-02': conditional_roman_removals(),
              'EV8-03': forced_marches_romans()}
    print(json.dumps(result, indent=2, sort_keys=True))
