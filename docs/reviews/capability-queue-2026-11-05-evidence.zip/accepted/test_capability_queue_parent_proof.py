"""Unchanged old-API behavioral probes: three repair failures, two controls."""
import pytest
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import place_piece
from fs_bot.cards.capabilities import activate_capability, set_capability_owner
from fs_bot.commands.common import free_action_scope
from fs_bot.engine.execute import _execute_battle
from fs_bot.state.state_schema import build_initial_state

REGIONS = (rc.NERVII, rc.TREVERI)

def position(card):
    state = build_initial_state(rc.SCENARIO_GREAT_REVOLT, seed=23)
    state['non_player_factions'] = {rc.BELGAE}
    for r in REGIONS:
        place_piece(state, r, rc.ARVERNI, rc.WARBAND, 6)
        place_piece(state, r, rc.ROMANS, rc.AUXILIA, 4)
    activate_capability(state, card, rc.EVENT_UNSHADED if card == 13 else rc.EVENT_SHADED)
    if card == 59: set_capability_owner(state, 59, rc.ARVERNI)
    return state

@pytest.mark.parametrize('card', [13, 59])
def test_human_reserves_mandatory_capability_to_later_battle(card, monkeypatch):
    state = position(card)
    requests, selected = [], []
    def agent(board, faction, request):
        if request['kind'] == 'capability_window':
            requests.append(request)
            return {'action': 'reserve' if request['region'] == REGIONS[0] else 'activate'}
    state['decision_agent'] = agent
    monkeypatch.setattr('fs_bot.engine.execute.resolve_battle', lambda board, region, *a, **kw:
        selected.append((region, board.get('event_modifiers', {}).get('card59_shaded_region'))) or {})
    prefire=[]
    monkeypatch.setattr('fs_bot.battle.losses.resolve_losses', lambda board, region, *a, **kw: prefire.append(region) or {})
    decision={'command':rc.CMD_BATTLE,'sa':None,'sa_regions':[],
              'details':{'battle_plan':[{'region':r,'target':rc.ROMANS} for r in REGIONS]}}
    with free_action_scope(state, rc.ARVERNI):
        result=_execute_battle(state,rc.ARVERNI,decision,_skip_absent_targets=True)
    assert result['count']==2 and not result['errors']
    assert [r['region'] for r in requests]==list(REGIONS)
    assert requests[-1]['actions']==['activate']
    assert prefire==([REGIONS[1]] if card==13 else [])
    assert selected[-1][1]==(REGIONS[1] if card==59 else None)


def test_pr11_forecast_includes_new_human_use_or_reserve(monkeypatch):
    from fs_bot.cards import base_arduenna_np as policy
    from fs_bot.engine.agent import consult_agent
    state=position(13)
    def controlled(board,*args,**kwargs):
        response=consult_agent(board,rc.ROMANS,{'kind':'capability_window','card_id':13,
            'side':rc.EVENT_UNSHADED,'owner':rc.ROMANS,'region':REGIONS[0],
            'attacker':rc.ARVERNI,'defender':rc.ROMANS,'auxilia':4,'blocked':False,
            'potential_regions':[REGIONS[1]],'actions':['activate','reserve']})
        if response is None or response['action']=='activate':
            consult_agent(board,rc.ROMANS,{'kind':'loss_order','region':REGIONS[0],
                'num_losses':1,'pieces':[(rc.LEGION,None)]})
        return {'executed':True,'errors':[]}
    monkeypatch.setattr('fs_bot.engine.execute._execute_battle',controlled)
    assert policy.predicted_legion_losses(state,REGIONS)==0

@pytest.mark.parametrize('card',[13,59])
def test_npc_first_applicable_use_control(card,monkeypatch):
    state=position(card)
    state['non_player_factions']={rc.ARVERNI,rc.BELGAE,rc.ROMANS}
    selected,prefire=[],[]
    monkeypatch.setattr('fs_bot.engine.execute.resolve_battle',lambda board,region,*a,**kw:
        selected.append(board.get('event_modifiers',{}).get('card59_shaded_region')) or {})
    monkeypatch.setattr('fs_bot.battle.losses.resolve_losses',lambda board,region,*a,**kw:prefire.append(region) or {})
    decision={'command':rc.CMD_BATTLE,'sa':None,'sa_regions':[],
              'details':{'battle_plan':[{'region':r,'target':rc.ROMANS} for r in REGIONS]}}
    with free_action_scope(state,rc.ARVERNI):
        result=_execute_battle(state,rc.ARVERNI,decision,_skip_absent_targets=True)
    assert result['count']==2 and not result['errors']
    assert prefire==([REGIONS[0]] if card==13 else [])
    assert selected==([None,None] if card==13 else [REGIONS[0],REGIONS[0]])
