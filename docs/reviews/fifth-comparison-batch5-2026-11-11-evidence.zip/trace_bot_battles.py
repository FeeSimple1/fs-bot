"""Reproduce audited outcomes and record the first decisions that can differ."""

from concurrent.futures import ProcessPoolExecutor
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import sys
from unittest.mock import patch

from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces
from fs_bot.bots import aedui_bot, german_bot
from fs_bot.cli.dispatcher import make_decision_func
from fs_bot.engine.game_engine import get_sop_factions, play_card, start_game
from fs_bot.state.serialize import encode
from fs_bot.state.setup import setup_scenario
from fs_bot.tools.validation_metadata import source_identity


def digest(value):
    return sha256(json.dumps(encode(value), sort_keys=True).encode()).hexdigest()


def board_digest(state):
    return digest({key: value for key, value in state.items() if key != 'decision_agent'})


def trace(row):
    scenario, seed, edition = (row[key] for key in ('scenario', 'seed', 'card_edition'))
    state = setup_scenario(scenario, seed=seed, card_edition=edition)
    state['non_player_factions'] = set(get_sop_factions(state))
    bot = make_decision_func({}, stdin=StringIO(), stdout=StringIO(), pause=False)
    cards, decisions, forecasts = [], [], []
    german_forecast = german_bot._estimate_battle_losses
    aedui_target = aedui_bot._would_force_loss_on_high_value
    aedui_safety = aedui_bot._counterattack_threatens_diviciacus

    def german_losses(board, region, enemy):
        losses = german_forecast(board, region, enemy)
        forecasts.append(dict(kind='German forecast', region=region, target=enemy, losses=losses))
        return losses

    def aedui_high_value(board, region, attacker, defender, scenario, *, ambush_possible=False):
        qualifies = aedui_target(board, region, attacker, defender, scenario,
                                 ambush_possible=ambush_possible)
        high_value = sum(count_pieces(board, region, defender, piece) for piece in
                         (rc.LEADER, rc.ALLY, rc.CITADEL, rc.LEGION, rc.SETTLEMENT))
        forecasts.append(dict(kind='Aedui target', region=region, target=defender,
                              qualifies=qualifies, high_value=high_value, ambush=bool(ambush_possible)))
        return qualifies

    def aedui_risk(board, region, targets, *args, **kwargs):
        unsafe = aedui_safety(board, region, targets, *args, **kwargs)
        forecasts.append(dict(kind='Diviciacus safety', region=region, targets=targets,
                              unsafe=unsafe, ambush=kwargs.get('is_ambush')))
        return unsafe

    def decide(board, faction, options, position):
        before = board_digest(board)
        choice = bot(board, faction, options, position)
        decisions.append(dict(faction=faction, before=before, choice=encode(choice),
                              rng_after=digest(board['rng'].getstate())))
        return choice

    with (patch.object(german_bot, '_estimate_battle_losses', german_losses),
          patch.object(aedui_bot, '_would_force_loss_on_high_value', aedui_high_value),
          patch.object(aedui_bot, '_counterattack_threatens_diviciacus', aedui_risk),
          redirect_stdout(StringIO())):
        start_game(state)
        for draw in range(1, 201):
            decisions.clear()
            forecasts.clear()
            before = board_digest(state)
            result = play_card(state, decide, execute=True)
            after = board_digest(state)
            cards.append(dict(draw=draw, card=result['card'], before=before, after=after,
                              decisions=list(decisions), forecasts=encode(list(forecasts))))
            if result['game_over']:
                break
    assert (result['winner'], draw, after) == (row['winner'], row['cards'], row['final_state_sha256'])
    return dict(scenario=scenario, seed=seed, card_edition=edition, winner=result['winner'],
                final_board=after, cards=cards)


def main(source_rows, output):
    source = source_identity()
    rows = json.loads(Path(source_rows).read_text())
    assert rows and all(row['source_sha256'] == source['source_sha256'] for row in rows)
    with ProcessPoolExecutor(max_workers=2) as pool:
        games = list(pool.map(trace, rows))
    Path(output).write_text(json.dumps(dict(source=source, games=games), indent=2) + '\n')
    print(f'{len(games)} outcome traces match the audited records')


if __name__ == '__main__':
    main(*sys.argv[1:])
