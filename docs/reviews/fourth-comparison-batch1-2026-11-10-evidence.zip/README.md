# Fourth comparison Batch 1 evidence

Accepted parent `ee05f5f33754aa0362632a965a2249cf00ecc381` and repaired Python
SHA-256 `bc5631828c67b6b02de07e5c3065d3defd3e4714bd08a367aa6fb1037e755eb9`.
`verification.json` records the accepted results and first differing cards.
All commands ran on Python 3.12.14. Run from the repaired repository root
with pytest and optional pytest-xdist available. Choose fresh output paths.

```sh
PYTHONHASHSEED=0 python -m pytest -q -n 4 --junitxml=new-results/pytest.xml
PYTHONHASHSEED=0 python -m fs_bot.tools.run_batch --seeds 25-28 --card-edition second-edition --workers 2 --out new-results/bots
PYTHONHASHSEED=0 python -m fs_bot.tools.player_fuzz --seeds 25-28 --card-edition second-edition --out new-results/fuzz0.json
PYTHONHASHSEED=987 python -m fs_bot.tools.player_fuzz --seeds 25-28 --card-edition second-edition --out new-results/fuzz987.json
PYTHONHASHSEED=0 PYTHONPATH=. python /path/to/evidence/run_balance.py new-results/balance.json
PYTHONHASHSEED=0 PYTHONPATH=. python /path/to/evidence/trace_games.py new-results/trace.json
```

`run_balance.py` records each legacy game from the existing balance runner,
then calls its normal guardrail on those same records. The trace script uses
the balance driver for the legacy games and the audited runner's driver for
the second-edition game. Run it on both revisions for the paired traces.
The clean audit checkout and the third comparison's final repaired checkout
have the same Python bytes. `parent/bots.jsonl` comes from the fourth audit.
`parent/balance.json` comes from the third comparison Batch 4 accepted run.
Both parent data sources record the same Python SHA-256.

Copy `test_fourth_comparison_targets.py` outside the parent checkout, then
run `PYTHONPATH=. python -m pytest -q /path/to/test_fourth_comparison_targets.py`
from that parent. Thirty-four regressions fail and two controls pass.
`exploratory/` retains the failed earlier fixture and menu checks. The suite
and matrices in `accepted/` were run after all corrections.
