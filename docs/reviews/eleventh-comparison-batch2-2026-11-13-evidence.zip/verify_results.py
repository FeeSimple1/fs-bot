"""Verify the recorded eleventh-audit Batch 2 results against the checkout."""

import hashlib
import json
from pathlib import Path
import re
from xml.etree import ElementTree

from fs_bot import rules_consts as rc
from fs_bot.engine.agent import LOSS_ORDER, RETREAT
from fs_bot.tools.error_census import _severity
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity

ROOT = Path(__file__).resolve().parent
REPO = Path(rc.__file__).resolve().parents[1]
PARENT = '52821136c4aa07d2df79dee48edbb1ec09945c12'
PARENT_DIGEST = 'b52ed2a155095cd5b75938a3a02b2cbfe5708b1cf5c6faffda0f77c042f44035'
SEEDS = {'legacy': list(range(1, 21)), 'second-edition': list(range(57, 61))}


def load(name):
    return json.loads((ROOT / name).read_bytes())


def verify_sources():
    source = load('source.json')
    assert source['commit'] == PARENT and source['dirty']
    assert load('parent-source.json') == dict(commit=PARENT, dirty=False, source_sha256=PARENT_DIGEST)
    assert source['source_sha256'] == source_identity()['source_sha256']
    assert source['python_files'] == len(list((REPO / 'fs_bot').rglob('*.py'))) == 628
    protected = load('protected-sources.json')
    references = {p.relative_to(REPO).as_posix() for p in (REPO / 'Reference Documents').rglob('*')
                  if p.is_file()}
    assert set(protected) == references | {'fs_bot/rules_consts.py'}
    for name, digest in protected.items():
        assert hashlib.sha256((REPO / name).read_bytes()).hexdigest() == digest, name
    test_path = 'test_tenth_comparison_battle.py'
    assert (ROOT / test_path).read_bytes() == (REPO / 'fs_bot/tests' / test_path).read_bytes()
    return source, len(protected)


def verify_witnesses():
    before, after = load('parent-witness.json'), load('repair-witness0.json')
    assert (ROOT / 'parent-witness.json').read_bytes() == (ROOT / 'parent-witness-rerun.json').read_bytes()
    assert (ROOT / 'repair-witness0.json').read_bytes() == (ROOT / 'repair-witness987.json').read_bytes()
    expected_changes = {'active_abatis_ariovistus', 'active_abatis_no_ariovistus'}
    changed = set()
    assert len(before['cases']) == len(after['cases']) == 6
    for old, new in zip(before['cases'], after['cases'], strict=True):
        assert old['name'] == new['name'] and old['before'] == new['before']
        assert new['german_resources_after'] == old['german_resources_after'] == 20
        assert new['actual_command'] == new['expected_command']
        assert new['before_validation'] == new['after_validation'] == {'census_errors': [], 'structure_errors': []}
        if new['name'] not in expected_changes:
            assert new == old
            continue
        changed.add(new['name'])
        assert old['actual_command'] == rc.CMD_BATTLE and new['actual_command'] == rc.CMD_MARCH
        assert old['diagnostics']['divination_high_value_gate'] is True
        assert new['diagnostics']['divination_high_value_gate'] is False
        assert old['diagnostics']['raw_losses'] == new['diagnostics']['resolver_losses'] == 3
        assert any(r['request']['kind'] == LOSS_ORDER
                   and any(p[0] == rc.MARKER_ABATIS for p in r['request']['pieces'])
                   for r in old['reactive_requests'])
        assert not any(r['request']['kind'] in (LOSS_ORDER, RETREAT) for r in new['reactive_requests'])
        assert new['after']['belgic_warbands_carnutes'] == 2
        assert new['after']['belgic_ally_aulerci'] == rc.BELGAE
        assert new['after']['abatis_owner'] == rc.BELGAE
    assert changed == expected_changes
    return {'cases': len(after['cases']), 'corrected_march_choices': sorted(changed)}


def verify_tests():
    results = {}
    for name, tests, failures in (('parent-clean-directed', 9, 3), ('directed0', 52, 0),
                                  ('directed987', 52, 0), ('full', 10423, 0)):
        suite, = ElementTree.parse(ROOT / f'{name}.xml').iter('testsuite')
        expected = {'tests': tests, 'failures': failures, 'errors': 0, 'skipped': 0}
        assert all(int(suite.attrib[key]) == count for key, count in expected.items()), name
        results[name] = {**expected, 'passed': tests - failures}
    return results


def read_games(folder, edition, digest):
    meta = load(f'{folder}/metadata.json')
    assert meta['source_sha256'] == digest and meta['hash_seed'] == 0
    assert meta['card_edition'] == edition and meta['seeds'] == SEEDS[edition]
    assert set(meta['scenarios']) == set(SCENARIOS) and meta['all_factions_bots']
    rows = [json.loads(line) for line in (ROOT / folder / 'games.jsonl').read_text().splitlines()]
    games = {(row['scenario'], row['seed']): row for row in rows}
    assert len(rows) == len(games)
    assert games.keys() == {(scenario, seed) for scenario in SCENARIOS for seed in SEEDS[edition]}
    for row in rows:
        assert row['source_sha256'] == digest and row['card_edition'] == edition
        assert row['completed'] and row['game_completed'] and row['audit_completed']
        assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row), row
        assert len(row['final_state_sha256']) == 64
        for diagnostic in row['diagnostic_occurrences']:
            assert diagnostic['severity'] == _severity(diagnostic['kind'], diagnostic['message']) == 'legal-decline'
    return games


def verify_games(digest):
    results, outcomes = {}, {}
    metadata = {'source_sha256', 'commit', 'seconds'}
    for edition in SEEDS:
        parent = read_games(f'parent-{edition}', edition, PARENT_DIGEST)
        games = read_games(edition, edition, digest)
        for key, row in games.items():
            assert {k: v for k, v in row.items() if k not in metadata} == {
                k: v for k, v in parent[key].items() if k not in metadata}, key
        results[edition] = {
            'games': len(games), 'changed_outcomes': 0,
            'interludes': sum(row['interlude_completed'] for row in games.values()),
            'legal_declines': sum(len(row['diagnostic_occurrences']) for row in games.values()),
        }
        outcomes[edition] = games
    return results, outcomes['legacy']


def verify_mixed(digest):
    for ext in ('json', 'log'):
        assert (ROOT / f'fuzz0.{ext}').read_bytes() == (ROOT / f'fuzz987.{ext}').read_bytes()
    old, new = load('parent-fuzz0.json'), load('fuzz0.json')
    assert old['metadata']['source_sha256'] == PARENT_DIGEST
    assert new['metadata']['source_sha256'] == digest
    assert new['metadata']['seeds'] == SEEDS['second-edition']
    assert new['metadata']['card_edition'] == 'second-edition'
    assert all(new['metadata'][flag] for flag in ('events', 'reactive', 'replay'))
    assert old['records'] == new['records'] and old['batch_digest'] == new['batch_digest']
    assert new['games'] == len(new['records']) == 20 and new['hard_findings'] == 0
    assert {(r['scenario'], r['seed']) for r in new['records']} == {
        (scenario, seed) for scenario in SCENARIOS for seed in SEEDS['second-edition']}
    assert all(row['game_completed'] and not row['findings'] for row in new['records'])
    return {key: new[key] for key in ('games', 'human_turns', 'event_turns', 'events_ok',
                                      'partial', 'hard_findings', 'batch_digest')}


def verify_balance(legacy):
    log = (ROOT / 'balance.log').read_text()
    rows = re.findall(r'^\[(.+) seed= *(\d+)\] winner=(.+) \((\d+) cards\)$', log, re.M)
    games = {f'{scenario}|{seed}': {'winner': winner, 'cards': int(cards)}
             for scenario, seed, winner, cards in rows}
    expected = {f'{scenario}|{seed}': {'winner': row['winner'], 'cards': row['cards']}
                for (scenario, seed), row in legacy.items()}
    baseline = load('balance-baseline.json')['games']
    assert (ROOT / 'balance-baseline.json').read_bytes() == (REPO / 'fs_bot/tools/balance_baseline.json').read_bytes()
    assert len(rows) == len(games) == 100 and games == expected == baseline
    assert 'OK: balance within band.' in log
    return {'games': len(games), 'changed_winners': 0, 'changed_card_counts': 0, 'band_points': 15}


def main():
    source, protected = verify_sources()
    digest = source['source_sha256']
    bot_games, legacy = verify_games(digest)
    print(json.dumps(dict(source=source, protected_files=protected, witnesses=verify_witnesses(),
                          tests=verify_tests(), bot_games=bot_games, mixed=verify_mixed(digest),
                          balance=verify_balance(legacy)), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
