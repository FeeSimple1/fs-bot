"""Independent extraction of the frozen follow-up repair evidence."""
from collections import Counter
from pathlib import Path
import hashlib,json,sys,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'fs-bot'
sys.path.insert(0,str(REPO))
from fs_bot import rules_consts as rc
from fs_bot.tools.validation_metadata import source_identity

def read(path):return json.loads((ROOT/path).read_text())
freeze=read('freeze.json'); expected=freeze['source_sha256']
assert source_identity()['source_sha256']==expected
scenarios=[rc.SCENARIO_PAX_GALLICA,rc.SCENARIO_RECONQUEST,rc.SCENARIO_GREAT_REVOLT,rc.SCENARIO_ARIOVISTUS,rc.SCENARIO_GALLIC_WAR]
batches={}; all_records={}
for name,edition,seeds in [('legacy-1000','legacy',range(1,201)),('legacy-heldout-500','legacy',range(201,301)),('original-heldout-500','original',range(201,301)),('second-edition-heldout-500','second-edition',range(201,301))]:
 meta=read(f'{name}/metadata.json');summary=read(f'{name}/summary.json')
 assert meta['source_sha256']==expected and meta['card_edition']==edition
 records=[json.loads(line) for line in (ROOT/name/'games.jsonl').read_text().splitlines()]
 assert len(records)==5*len(seeds)
 assert {(r['scenario'],r['seed']) for r in records}=={(s,n) for s in scenarios for n in seeds}
 for r in records:
  assert all(r.get(k) is True for k in ('completed','game_completed','audit_completed')),r
  assert not any(r.get(k) for k in ('error','errors','integrity_findings')),r
  assert not any(d['severity']!='legal-decline' for d in r['diagnostics']),r
  assert r['source_sha256']==expected and r['card_edition']==edition
  assert r['cards']>0 and len(r['final_state_sha256'])==64
  ranks=r['final_ranking']; end=r['ending_scenario']
  factions={rc.ROMANS,rc.AEDUI,rc.BELGAE,rc.GERMANS if end in (rc.SCENARIO_ARIOVISTUS,rc.SCENARIO_GALLIC_WAR) else rc.ARVERNI}
  assert len(ranks)==4 and {f for f,_ in ranks}==factions
  assert ranks==r['engine_final_ranking'] and ranks[0][0]==r['winner']
  assert not r['winner_differs_from_highest_margin'] and not r['engine_ranking_output_missing']
 for scenario in scenarios:
  group=[r for r in records if r['scenario']==scenario]
  assert summary[scenario]['completed']==len(seeds)
  assert dict(Counter(r['winner'] for r in group))==summary[scenario]['wins']
 batches[name]={'card_edition':edition,'seeds':[min(seeds),max(seeds)],'games':len(records),'summary':summary}
 all_records[name]=records
xml=ET.parse(ROOT/'pytest.xml').getroot()
assert not list(xml.iter('failure')) and not list(xml.iter('error'))
assert len(list(xml.iter('testcase')))>=4425
fuzz=read('fuzz-acceptance.json');assert fuzz['passed'] and fuzz['source_unchanged']
assert fuzz['source_before']['source_sha256']==expected
census=read('census-comparison.json');assert census['accepted'] and census['source_unchanged']
assert census['expected_source_sha256']==expected
optional=read('optional-diviciacus/summary.json');assert optional['accepted'] and optional['completed']==90 and optional['source_unchanged']
assert optional['source_after']['source_sha256']==expected
strategy=read('strategy-smoke-review.json');assert strategy['games']==20 and not strategy['failures'] and strategy['source_stable']
assert strategy['source_before']['source_sha256']==expected
package=read('package/verification.json')
assert package['source_freeze_sha256_before']==package['source_freeze_sha256_after']==expected
assert len(package['unchanged_references'])==47
balance=read('balance-smoke-final-review.json');assert balance['exit_code']==0 and balance['coverage_exact'] and not balance['winner_and_card_differences']
assert balance['source_before']['source_sha256']==expected
baseline=read('baseline-comparison.json');assert not baseline['findings'] and baseline['coverage_exact'] and baseline['source_stable']
assert baseline['source_before']['source_sha256']==expected
expected_baseline={f"{r['scenario']}|{r['seed']}":{'winner':r['winner'],'cards':r['cards']} for r in all_records['legacy-1000'] if r['seed']<=20}
assert expected_baseline==balance['current']
assert expected_baseline==json.loads((REPO/'fs_bot/tools/balance_baseline.json').read_text())['games']
hash7=[json.loads(line) for line in (ROOT/'bot-hash7-repeats.jsonl').read_text().splitlines()]
assert len(hash7)==75
lookup={(r['scenario'],r['seed'],r['card_edition']):r for name,rs in all_records.items() if 'heldout' in name for r in rs}
def stable(r):return {k:v for k,v in r.items() if k not in ('seconds','commit','source_sha256')}
assert {(r['scenario'],r['seed'],r['card_edition']) for r in hash7}=={(s,n,e) for s in scenarios for n in range(201,206) for e in ('legacy','original','second-edition')}
for r in hash7:assert stable(r)==stable(lookup[r['scenario'],r['seed'],r['card_edition']])
result={'accepted':True,'freeze':freeze,'tests':len(list(xml.iter('testcase'))),'bot_games':2500,'batches':batches,'bot_hash_repeats':75,'optional':optional,'fuzz':fuzz,'census':census,'baseline':baseline,'strategy':strategy,'package':package,'source_after':source_identity()}
assert result['source_after']['source_sha256']==expected
(ROOT/'verified-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'accepted':True,'tests':result['tests'],'bot_games':2500,'source_sha256':expected}))
