"""Validate and compare the saved eleventh-audit Batch 1 evidence."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
from xml.etree import ElementTree

from fs_bot import rules_consts as rc
from fs_bot.state.serialize import decode, encode
from fs_bot.tools.error_census import _severity
from fs_bot.tools.run_batch import SCENARIOS, _outcome_issues
from fs_bot.tools.validation_metadata import source_identity

ROOT = Path(__file__).resolve().parent
PARENT = '2963f7f1c8bcb0d2ded319477950b4e3117aba3e'
PARENT_DIGEST = '489efe1d5b60a36f47ac5b7b46fd47595246d770606e32f6fa78d5b5b8d6a9e0'
SEEDS = {'legacy': range(1, 21), 'second-edition': range(57, 61)}
BALANCE_ROW = re.compile(r'^\[(.+) seed= *(\d+)\] winner=(.+) \((\d+) cards\)$', re.M)


def load(name):
    return json.loads((ROOT / name).read_bytes())


def read_games(folder, edition, digest):
    meta = load(f'{folder}/metadata.json')
    assert meta['source_sha256'] == digest and meta['hash_seed'] == 0
    assert meta['card_edition'] == edition and meta['seeds'] == list(SEEDS[edition])
    rows = [json.loads(line) for line in (ROOT / folder / 'games.jsonl').read_text().splitlines()]
    games = {(row['scenario'], row['seed']): row for row in rows}
    expected = {(scenario, seed) for scenario in SCENARIOS for seed in SEEDS[edition]}
    assert len(rows) == len(games) and games.keys() == expected
    for row in rows:
        assert row['source_sha256'] == digest and row['card_edition'] == edition
        assert row['completed'] and row['game_completed'] and row['audit_completed']
        assert not row['errors'] and not row['integrity_findings'] and not _outcome_issues(row), row
        assert len(row['final_state_sha256']) == 64
        for diagnostic in row['diagnostic_occurrences']:
            assert diagnostic['severity'] == _severity(diagnostic['kind'], diagnostic['message']) == 'legal-decline'
    return games


def paired_runs(digest):
    records, tasks, summaries = {}, [], {}
    for edition in SEEDS:
        before = read_games(f'parent-{edition}', edition, PARENT_DIGEST)
        after = read_games(edition, edition, digest)
        records[edition] = before, after
        changed = [key for key in sorted(after)
                   if before[key]['final_state_sha256'] != after[key]['final_state_sha256']]
        tasks.extend({'task': [*key, edition], 'mixed': False} for key in changed)
        summaries[edition] = {
            'games': len(after), 'changed_final_states': len(changed),
            'changed_winners': sum(before[key]['winner'] != row['winner'] for key, row in after.items()),
            'changed_card_counts': sum(before[key]['cards'] != row['cards'] for key, row in after.items()),
            'interludes': sum(row['interlude_completed'] for row in after.values()),
            'diagnostic_occurrences': sum(len(row['diagnostic_occurrences']) for row in after.values()),
        }
    for ext in ('json', 'log'):
        assert (ROOT / f'fuzz0.{ext}').read_bytes() == (ROOT / f'fuzz987.{ext}').read_bytes()
    before, after = load('parent-fuzz0.json'), load('fuzz0.json')
    assert before['metadata']['source_sha256'] == PARENT_DIGEST
    assert after['metadata']['source_sha256'] == digest
    assert after['metadata']['seeds'] == list(SEEDS['second-edition'])
    assert after['metadata']['card_edition'] == 'second-edition'
    assert all(after['metadata'][flag] for flag in ('events', 'reactive', 'replay'))
    assert before['games'] == after['games'] == 20 and after['hard_findings'] == 0
    old_mixed, new_mixed = {}, {}
    for old, new in zip(before['records'], after['records'], strict=True):
        key = new['scenario'], new['seed']
        assert key == (old['scenario'], old['seed']) and new['game_completed'] and not new['findings']
        old_mixed[key], new_mixed[key] = old, new
        if old != new:
            tasks.append({'task': [*key, 'second-edition'], 'mixed': True})
    records['mixed'] = old_mixed, new_mixed
    mixed = {key: after[key] for key in ('games', 'human_turns', 'event_turns', 'events_ok',
                                        'partial', 'hard_findings', 'batch_digest')}
    mixed['changed_cases'] = sum(entry['mixed'] for entry in tasks)
    return records, tasks, {'bot_games': summaries, 'mixed': mixed}


def compare_traces(records, tasks, digest):
    old, new = (decode(load(f'trace-{side}.json')) for side in ('parent', 'repair'))
    assert old['source']['source_sha256'] == PARENT_DIGEST
    assert new['source']['source_sha256'] == digest
    changes = []
    for before, after, entry in zip(old['games'], new['games'], tasks, strict=True):
        task, mixed = entry['task'], entry['mixed']
        assert before['task'] == after['task'] == task and before['mixed'] == after['mixed'] == mixed
        old_records, new_records = records['mixed' if mixed else task[2]]
        key = tuple(task[:2])
        for trace, pair in ((before, old_records), (after, new_records)):
            assert all(value == pair[key][field] for field, value in trace['outcome'].items())
        first = next(((a, b) for a, b in zip(before['cards'], after['cards']) if a != b), None)
        assert first is not None, (entry, 'no differing card')
        a, b = first
        assert a['card'] == b['card'] and a['before'] == b['before'], entry
        assert a['card'] in (19, 50, 52), (entry, a['card'], b['card'])
        changes.append(dict(entry, ordinal=a['ordinal'], card=a['card'],
                            parent_events=a['events'], repair_events=b['events'],
                            parent_actions={f: r['action'] for f, r in a['actions'].items()},
                            repair_actions={f: r['action'] for f, r in b['actions'].items()},
                            winners=[old_records[key].get('winner'), new_records[key].get('winner')]))
    return changes


def balance(records, log_name, baseline):
    games = {f'{scenario}|{seed}': {'winner': winner, 'cards': int(cards)}
             for scenario, seed, winner, cards in BALANCE_ROW.findall((ROOT / log_name).read_text())}
    legacy = records['legacy'][1]
    expected = {f'{scenario}|{seed}': {field: row[field] for field in ('winner', 'cards')}
                for (scenario, seed), row in legacy.items()}
    assert games == expected and len(games) == 100
    assert set(baseline) == set(games)
    shifts = {}
    for scenario in SCENARIOS:
        prefix = scenario + '|'
        prior = Counter(row['winner'] for key, row in baseline.items() if key.startswith(prefix))
        repaired = Counter(row['winner'] for key, row in games.items() if key.startswith(prefix))
        shifts[scenario] = {f: 5 * (repaired[f] - prior[f]) for f in rc.FACTIONS
                            if prior[f] or repaired[f]}
    maximum = max(abs(points) for scenario in shifts.values() for points in scenario.values())
    log = (ROOT / log_name).read_text()
    passed = maximum <= 15
    status = 'OK: balance within band' if passed else 'FAIL: a faction win rate moved beyond the band.'
    assert status in log, status
    return {'games': 100, 'passed': passed, 'largest_shift_points': maximum, 'band_points': 15,
            'drift_by_scenario': shifts,
            'changed_winners': [[key, baseline[key]['winner'], games[key]['winner']]
                                for key in sorted(games) if baseline[key]['winner'] != games[key]['winner']]}


def test_summary():
    summary = {}
    for name, count, failures in (('parent-directed', 41, 35), ('directed987', 41, 0), ('full', 10420, 0)):
        suite, = ElementTree.parse(ROOT / f'{name}.xml').iter('testsuite')
        expected = {'tests': count, 'failures': failures, 'errors': 0, 'skipped': 0}
        assert all(int(suite.attrib[key]) == n for key, n in expected.items()), name
        summary[name] = dict(expected, passed=count - failures, seconds=float(suite.attrib['time']))
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tasks', action='store_true')
    args = parser.parse_args()
    source = load('source.json')
    assert source['commit'] == PARENT and source['dirty']
    assert source['source_sha256'] == source_identity()['source_sha256']
    records, tasks, summary = paired_runs(source['source_sha256'])
    if args.tasks:
        print(json.dumps(tasks, indent=2))
        return
    assert load('trace-tasks.json') == tasks
    repo = Path(__import__('fs_bot').__file__).resolve().parent.parent
    protected = load('protected-sources.json')
    assert len(protected) == 48
    assert all(hashlib.sha256((repo / path).read_bytes()).hexdigest() == sha
               for path, sha in protected.items())
    previous = load('previous-balance-baseline.json')['games']
    result = balance(records, 'balance.log', previous)
    if (ROOT / 'balance-reviewed.log').exists():
        current = json.loads((repo / 'fs_bot/tools/balance_baseline.json').read_bytes())['games']
        revised = balance(records, 'balance-reviewed.log', current)
        assert revised['passed'] and revised['largest_shift_points'] == 0
        assert revised['changed_winners'] == []
        result['reviewed'] = revised
        suite, = ElementTree.parse(ROOT / 'reviewed-guardrail.xml').iter('testsuite')
        assert int(suite.attrib['tests']) == 27
        assert all(int(suite.attrib[key]) == 0 for key in ('failures', 'errors', 'skipped'))
        result['reviewed_guardrail_tests'] = 27
    else:
        assert result['passed'] and previous == json.loads(
            (repo / 'fs_bot/tools/balance_baseline.json').read_bytes())['games']
    assert (ROOT / 'lucterius-session0.json').read_bytes() == (ROOT / 'lucterius-session987.json').read_bytes()
    placement = load('lucterius-session0.json')
    assert placement['pending_id_preserved'] and placement['rollback_board_and_rng_preserved']
    changes = compare_traces(records, tasks, source['source_sha256'])
    assert changes == decode(load('first-changes.json'))
    summary.update(source=source, tests=test_summary(), protected_files=len(protected),
                   balance=result, first_changes=changes, lucterius_session=placement)
    print(json.dumps(encode(summary), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
