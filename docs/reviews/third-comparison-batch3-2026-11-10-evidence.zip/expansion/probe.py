"""Round 3 expansion witnesses. Assertions freeze observed defects, not rules.
Run with PYTHONPATH pointing to the audited fs-bot checkout. No repo edits.
Positions use build_initial_state + normal piece helpers; A19 creates its
Colony through Event 71, A35 creates Dispersed through Seize. They are
controlled census-valid positions, not complete playthrough transcripts.
"""
import json
from fs_bot import rules_consts as rc
from fs_bot.board.pieces import count_pieces, place_piece, get_available
from fs_bot.cards.card_effects import _ally_tribe, execute_event
from fs_bot.commands.seize import seize_in_region
from fs_bot.engine.execute import execute_decision
from fs_bot.engine.game_engine import ACTION_EVENT
from fs_bot.engine.moves import validate_player_action
from fs_bot.state.state_schema import build_initial_state, validate_state, check_structural_integrity
from fs_bot.tools.seat_session import validate_response
from fs_bot.tools.validation_metadata import source_identity


def board(card, faction=rc.BELGAE):
    state = build_initial_state(rc.SCENARIO_ARIOVISTUS, seed=317)
    state.update(non_player_factions=set(), current_card=card, next_card='A67', executing_faction=faction)
    return state


def integrity(state):
    result = {'pool_errors': validate_state(state),
              'structural_errors': check_structural_integrity(state)}
    assert not result['pool_errors'] and not result['structural_errors'], result
    return result


def event(state, card, params, shaded=False):
    integrity(state)
    action = {'command': rc.FIRST_DID_EVENT, 'regions': [], 'sa': 'No SA', 'sa_regions': [],
              'details': {'card_id': card, 'text_preference': rc.EVENT_SHADED if shaded else rc.EVENT_UNSHADED,
                          'event_params': params}}
    decision = {'action': ACTION_EVENT, 'player_action': action}
    validate_response(state, {'kind': 'turn', 'faction': state['executing_faction'],
                             'options': [ACTION_EVENT]}, decision)
    valid, preview = validate_player_action(state, state['executing_faction'], action)
    result = execute_decision(state, state['executing_faction'], decision)
    assert valid and result['executed'], (valid, preview, result)
    return {'response_accepted': True, 'action_valid': valid, 'result': result, **integrity(state)}


def battle_horse(horse, stalwart):
    state = board('A31')
    place_piece(state, rc.ATREBATES, rc.BELGAE, rc.WARBAND, 6)
    place_piece(state, rc.ATREBATES, rc.GERMANS, rc.WARBAND, 8, piece_state=rc.REVEALED)
    state['resources'][rc.BELGAE] = 20
    state['event_params'] = {}
    if horse:
        execute_event(state, 59, shaded=True)
    # A31 is the later standing Event. This is an ordinary Battle, avoiding
    # any question about a newly played one-shot overriding the Capability.
    if stalwart:
        execute_event(state, 'A31', shaded=True)
    integrity(state)
    action = {'command': rc.CMD_BATTLE, 'regions': [rc.ATREBATES], 'sa': 'No SA', 'sa_regions': [],
              'details': {'battle_plan': [{'region': rc.ATREBATES, 'target': rc.GERMANS}]}}
    decision = {'action': 'command', 'player_action': action}
    validate_response(state, {'kind': 'turn', 'faction': rc.BELGAE, 'options': ['command']}, decision)
    valid, preview = validate_player_action(state, rc.BELGAE, action)
    result = execute_decision(state, rc.BELGAE, decision)
    assert valid and result['executed']
    after = count_pieces(state, rc.ATREBATES, rc.GERMANS, rc.WARBAND)
    return {'horse': horse, 'stalwart': stalwart, 'action_valid': valid, 'result': result,
            'german_warbands_before': 8, 'german_warbands_after': after,
            'german_losses': 8-after, **integrity(state)}


def main():
    out = {}
    for name, placements in [('empty', []), ('complete', [
            {'region': rc.TREVERI, 'piece_type': rc.WARBAND, 'count': 4},
            {'region': rc.TREVERI, 'piece_type': rc.SETTLEMENT}])]:
        state = board('A29')
        assert get_available(state, rc.GERMANS, rc.WARBAND) >= 4
        assert get_available(state, rc.GERMANS, rc.SETTLEMENT) >= 1
        out['A29_' + name] = event(state, 'A29', {'placements': placements}, True)
        out['A29_' + name].update(warbands=count_pieces(state, rc.TREVERI, rc.GERMANS, rc.WARBAND),
                                  settlements=count_pieces(state, rc.TREVERI, rc.GERMANS, rc.SETTLEMENT))
    assert out['A29_empty']['warbands'] == out['A29_empty']['settlements'] == 0
    assert out['A29_complete']['warbands'] == 4 and out['A29_complete']['settlements'] == 1

    for colony in (False, True):
        state = board('A19')
        if colony:
            state.update(executing_faction=rc.GERMANS, event_params={'region': rc.SEQUANI})
            execute_event(state, 71)
            tribe = 'Colony_Sequani'
        else:
            tribe = rc.TRIBE_SEQUANI
            assert _ally_tribe(state, tribe, rc.GERMANS)
        place_piece(state, rc.SEQUANI, rc.ROMANS, rc.LEADER, leader_name=rc.CAESAR)
        state['executing_faction'] = rc.BELGAE
        key = 'A19_colony' if colony else 'A19_printed_tribe'
        out[key] = event(state, 'A19', {'replacements': [{'tribe': tribe}]})
        out[key]['ally_after'] = state['tribes'][tribe]['allied_faction']
        assert out[key]['ally_after'] == (rc.GERMANS if colony else rc.ROMANS)

    for status in (None, rc.DISPERSED, rc.DISPERSED_GATHERING):
        state = board('A35')
        if status is not None:
            place_piece(state, rc.TREVERI, rc.ROMANS, rc.AUXILIA)
            seize_in_region(state, rc.TREVERI, [rc.TRIBE_TREVERI], no_rally=True)
            if status == rc.DISPERSED_GATHERING:
                from fs_bot.engine.winter import spring_phase
                spring_phase(state)
                assert state['tribes'][rc.TRIBE_TREVERI]['status'] == status
        key = 'A35_' + str(status)
        out[key] = event(state, 'A35', {'ally_faction': rc.BELGAE, 'piece_faction': rc.BELGAE,
                                       'piece_type': rc.WARBAND, 'count': 0})
        out[key]['tribe_after'] = dict(state['tribes'][rc.TRIBE_TREVERI])
        assert out[key]['tribe_after']['status'] == status
        assert out[key]['tribe_after']['allied_faction'] == (rc.BELGAE if status is None else None)

    out['A31_horse_cases'] = [battle_horse(horse, stalwart) for horse, stalwart in
                             [(False, False), (False, True), (True, False), (True, True)]]
    assert [entry['german_losses'] for entry in out['A31_horse_cases']] == [3, 3, 6, 6]
    print(json.dumps({'source': source_identity(), 'witnesses': out}, indent=2))


if __name__ == '__main__':
    main()
