# Independent fifth-audit review

Audited commit `bd30d522e8baa2d303b9e372d7d9c550351e91a5`. Accepted **11 repair groups, 7 high and 4 medium**, with one separate source question. No gameplay or reference files changed.

All five final scripts were rerun independently with `PYTHONHASHSEED=0` and the audited checkout on `PYTHONPATH`. Each exited zero with empty stderr. Every parsed output exactly matches its partition author’s final JSON. Script hashes were unchanged across each run. `reruns.json` contains scripts, SHA-256 values and output paths. The assertions describe observed defects and controls, not repaired expectations.

| Finding | Review conclusion |
|---|---|
| NP5-01 | A8.6.2 applies to the selected defender and actual Counterattack. Unrelated Germans veto a safe Belgic target; Ariovistus doubling permits a prohibited Diviciacus Loss. Both public execution controls reproduce. |
| NP5-02 | Base8.6.2 requires a real Leader, Ally, Citadel or Legion (plus expansion Settlements). Both base and expansion witnesses have none, yet trigger high-value Battle. A legal Ally-Rally is shown. |
| NP5-03 | A8.7.1 requires comparing actual Attack and surviving Counterattack. Revealed six-versus-six forces guarantee3/1, while Ariovistus plus four versus six guarantees6/0; both incorrectly March. |
| BM5-01 | A31 shaded cancels harmful Battle Events. Numeric15 is retained in Ariovistus under A Setup36–60, so its uncancelled +2 is a valid coexistence witness. |
| BM5-02 | Abatis acts as a Fort when defending. Ordinary eligible casualty choice must include it, and A3.2.4 prevents Diviciacus absorbing while it can. Public fixtures show both omissions. |
| BE5-01 | Cards10/63 shaded require a Gallic recipient. Missing/invalid Roman choice installs an ownerless effect. Live Ballistae and Winter Campaign consumers show the lost benefit, with assigned-Belgae controls. |
| BE5-02 | Card71 selects a Region. Base Cisalpina without Gallia and expansion Britannia are expressly not Regions. Colony stacking exception does not itself declare either a Region. |
| BE5-03 | Card5 makes Cisalpina a Roman Region. Card32 permits movement between Regions other than Britannia. Its old representation lookup incorrectly rejects actual marker-enabled Cisalpina. |
| FE5-01 | Chapter4 4.1.3 and card52 usual-rule clause prohibit Britannia March plus accompanying SA. Canonical free-action plan violates that rule; durable save/resume commits it. |
| FE5-02 | Chapter3 3.2.2 allows Roman transit dropoffs. Identical ordinary callback is honored; Event-granted Command omits its supported live choice. |
| WS5-01 | Bibracte/Gergovia are City/Tribe circles within Regions. Third-Winter reset removes a colocated Legion only when that home Tribe needs restoration, contrary to scope and no-Legion reduction clause. |

## Scope and grouping

The prior 50/21/15/16 ledgers were checked. Several groups extend a previously encountered bug class, but each demonstrates a surviving consumer or requirement beyond the earlier finding’s stated scope. NP5-01 groups two defects in the same Diviciacus safety check. BM5-02 groups both Abatis casualty-selection manifestations. BE5-01 groups the copied recipient-acquisition handlers. No per-card profile or mirrored home-City branch is counted separately.

The controlled positions retain Provincia’s permanent Fort and use physical piece/alliance helpers with clean before/after census and structure. Local source review also checked geography, home-Tribe ownership, card replacement and legal route scope. Interlude witnesses use the full third-Winter path and a human Roman seat that explicitly declines the expedition. This does not prove naturally sampled reach for every position.

## Unresolved and rejected leads

Optimates in Pax Gallica remains **Q-OPTIMATES-PAX-PHASE-COUNT**, outside the confirmed count. “Second Victory Phase” can describe the second scheduled phase despite the first being skipped, or the second actually conducted phase. The supplied sources do not explicitly select a convention. The witness establishes current behavior, not the correct interpretation.

A preliminary concern that Legio X was replaced by A15C was retracted after reading A Setup36–60 and actual deck identities. Numeric15 is retained. Abatis and Allied Tribes share a final casualty tier, so their relative choice is not a fixed mandatory order; Diviciacus’s special last-possible rule still applies. Balearic Slingers/Stalwart timing was not counted. Other exploratory leads remain excluded as described by their partition coverage files.

## Limits

This review verifies the final targeted witnesses, source support, controls and grouping. It does not certify all engine interactions, all action encodings, or all older unverified inventory rows. Root validation supplies the separate full test suite and sampled-game results. The reviewer made no production, test, protected-reference or baseline edits.
