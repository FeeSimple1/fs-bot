"""Verify Batch 3's fixed-seed outcomes, replay digests and test records."""
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

from fs_bot import rules_consts as rc
from fs_bot.tools.run_batch import SCENARIOS
from fs_bot.tools.validation_metadata import source_identity

ROOT = Path(__file__).resolve().parent
FINAL = ROOT / 'final'
PARENT_HASH = 'e2cb669886c9db5e6ef51e807fecd25ae34d491631c89b526a32729c78e6ee24'


def read_json(path):
    return json.loads(path.read_text())


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def key(row):
    return tuple(row[k] for k in ('scenario', 'seed', 'card_edition'))


def verify_matrix(path, edition, seeds, source_hash):
    rows = [json.loads(line) for line in (path / 'games.jsonl').read_text().splitlines()]
    expected = {(scenario, seed, edition) for scenario in SCENARIOS for seed in seeds}
    assert len(rows) == len(expected) and {key(row) for row in rows} == expected
    meta = read_json(path / 'metadata.json')
    assert meta['source_sha256'] == source_hash and meta['seeds'] == list(seeds)
    assert meta['card_edition'] == edition and meta['hash_seed'] == 0 and meta['all_factions_bots']
    for row in rows:
        assert row['source_sha256'] == source_hash
        assert all(row[field] for field in (
            'completed', 'game_completed', 'audit_completed', 'final_state_sha256')), row
        assert not any(row[field] for field in (
            'errors', 'integrity_findings', 'engine_ranking_output_missing',
            'winner_differs_from_highest_margin')), row
        assert len(row['final_ranking']) == len(row['engine_final_ranking']) == 4
        for group in ('diagnostics', 'diagnostic_occurrences'):
            assert all(d['severity'] == 'legal-decline' for d in row[group]), row
    return {key(row): row for row in rows}


def verify_balance(after):
    reviewed = Path('fs_bot/tools/balance_baseline.json')
    baseline = read_json(reviewed)['games']
    current = {f'{scenario}|{seed}': {field: row[field] for field in ('winner', 'cards')}
               for (scenario, seed, edition), row in after.items() if edition == 'legacy'}
    assert len(baseline) == len(current) == 100 and baseline.keys() == current.keys()
    pattern = r'\[(.*) seed=\s*(\d+)\] winner=(.+) \((\d+) cards\)'
    output = (FINAL / 'balance.log').read_text()
    logged = {}
    for line in output.splitlines():
        match = re.fullmatch(pattern, line)
        if match:
            scenario, seed, winner, cards = match.groups()
            game = f'{scenario}|{int(seed)}'
            assert game not in logged
            logged[game] = {'winner': winner, 'cards': int(cards)}
    assert logged == current and 'OK: balance within band' in output
    shifts = []
    for scenario in SCENARIOS:
        old, new = [Counter(row['winner'] for game, row in results.items()
                            if game.startswith(scenario + '|')) for results in (baseline, current)]
        for faction in sorted(old.keys() | new.keys()):
            change = Fraction(new[faction] - old[faction], 20)
            assert abs(change) <= Fraction(15, 100)
            shifts.append(dict(scenario=scenario, faction=faction,
                               reviewed_wins=old[faction], current_wins=new[faction],
                               change_points=int(change * 100)))
    (FINAL / 'balance-baseline.json').write_bytes(reviewed.read_bytes())
    return dict(games=100, band_points=15, max_change_points=max(abs(r['change_points']) for r in shifts),
                changed_winners=sum(baseline[game]['winner'] != current[game]['winner'] for game in current),
                win_rates=shifts)


def verify_fuzz(source, after):
    for suffix in ('json', 'log'):
        assert (FINAL / f'fuzz0.{suffix}').read_bytes() == (FINAL / f'fuzz987.{suffix}').read_bytes()
    fuzz = read_json(FINAL / 'fuzz0.json')
    assert fuzz['metadata']['source_sha256'] == source['source_sha256']
    assert fuzz['metadata']['replay'] and fuzz['metadata']['events'] and fuzz['metadata']['reactive']
    assert fuzz['games'] == len(fuzz['records']) == 20 and fuzz['hard_findings'] == 0
    assert {key(row) for row in fuzz['records']} == {game for game in after if game[2] == 'second-edition'}
    assert all(row['game_completed'] and row['digest'] and not row['findings'] for row in fuzz['records'])
    return dict({k: fuzz[k] for k in ('games', 'human_turns', 'event_turns', 'events_ok',
                                    'hard_findings', 'partial', 'batch_digest')},
                hash_seeds=[0, 987], exact_match=True)


def verify_first_changes(before, after, source):
    traces = read_json(FINAL / 'first-divergences.json')
    assert traces['parent']['source_sha256'] == PARENT_HASH
    assert traces['repaired']['source_sha256'] == source['source_sha256']
    keys = {game for game in after if before[game]['final_state_sha256'] != after[game]['final_state_sha256']}
    assert len(traces['changes']) == len(keys) == 8 and {key(row) for row in traces['changes']} == keys
    reasons = Counter()
    for row in traces['changes']:
        previous, current = (row[version] for version in ('previous', 'current'))
        assert previous['before'] == current['before'] and previous['rng_before'] == current['rng_before']
        old_battles, new_battles = [
            Counter(call['region'] for call in stage['calls'] if call['kind'] == 'Battle')
            for stage in (previous, current)
        ]
        old_fire, new_fire = [[call for call in stage['calls'] if call['kind'] == 'Slingers']
                              for stage in (previous, current)]
        assert not old_fire
        if new_fire:
            fire, = new_fire
            assert fire['attacker'] == rc.GERMANS and fire['capabilities']['13'] == rc.EVENT_UNSHADED
            assert fire['before_pieces'] != fire['after_pieces']
            first_battle = next(call for call in previous['calls'] if call['kind'] == 'Battle')
            assert fire['region'] == first_battle['region']
            assert fire['rng_before'] == first_battle['rng_before']
            assert fire['before_pieces'] == first_battle['before_pieces']
            if row['common_scope'] == 'Free Enlist Command':
                assert fire['before'] == first_battle['before']
        if row['common_scope'] == 'Germans Phase Battle':
            assert row['card'] == 53 and max(old_battles.values()) > 1 and max(new_battles.values()) == 1
            reason = 'Consuetudine one defender per Region'
            if new_fire:
                reason += ' and Slingers initial fire'
        else:
            assert row['common_scope'] == 'Free Enlist Command' and new_fire
            reason = 'Slingers initial fire in a free German Limited Command'
        reasons[reason] += 1
    return dict(boards=len(keys), winners=traces['changed_winners'], reasons=dict(reasons))


def main(parent_path):
    source = read_json(FINAL / 'source.json')
    assert source['source_sha256'] == source_identity()['source_sha256']
    before, after, bots = {}, {}, {}
    for label, edition, seeds in (('bots-legacy', 'legacy', range(1, 21)),
                                  ('bots-second', 'second-edition', range(41, 45))):
        old = verify_matrix(Path(parent_path) / label, edition, seeds, PARENT_HASH)
        new = verify_matrix(FINAL / label, edition, seeds, source['source_sha256'])
        bots[edition] = dict(games=len(new), seeds=list(seeds),
                             interludes=sum(row['interlude_completed'] for row in new.values()),
                             winner_changes=sum(old[game]['winner'] != row['winner'] for game, row in new.items()),
                             board_changes=sum(old[game]['final_state_sha256'] != row['final_state_sha256']
                                               for game, row in new.items()))
        before.update(old)
        after.update(new)
    write_json(FINAL / 'paired-outcomes.json', [
        dict(scenario=game[0], seed=game[1], card_edition=game[2],
             previous={k: before[game][k] for k in ('winner', 'cards', 'final_state_sha256')},
             current={k: after[game][k] for k in ('winner', 'cards', 'final_state_sha256')})
        for game in sorted(after)])
    suites = list(ET.parse(FINAL / 'pytest.xml').getroot().iter('testsuite'))
    passed = sum(int(suite.attrib['tests']) for suite in suites)
    assert passed == 9956
    assert not any(int(suite.attrib[k]) for suite in suites for k in ('errors', 'failures', 'skipped'))
    assert '18 failed, 7 passed' in (FINAL / 'parent-regressions.log').read_text()
    changes = verify_first_changes(before, after, source)
    assert changes['winners'] == sum(row['winner_changes'] for row in bots.values())
    summary = dict(source=source, parent_source_sha256=PARENT_HASH, pytest_passed=passed,
                   regression_cases=25, parent_failures=18, parent_controls_passed=7,
                   bots=bots, mixed=verify_fuzz(source, after), changes=changes,
                   balance=verify_balance(after))
    write_json(FINAL / 'summary.json', summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main(*sys.argv[1:])
